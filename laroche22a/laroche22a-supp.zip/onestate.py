# authors: anonymous

import numpy as np
from utils import choice

class Onestate:
    def __init__(self, nb_actions):
        self.nb_states = 3
        self.nb_actions = nb_actions
        self.is_done = False
        self.initial_state = 0
        self.current_state = self.initial_state
        self.final_state = 0
        self._generate_transition_function()
        self._generate_reward_function()

    def reset(self):
        self.current_state = self.initial_state
        return int(self.current_state)

    def sample_action(self):
        return np.random.randint(self.nb_actions)

    def _get_reward(self, state, action, next_state):
        r = self.reward_function[state, next_state] + (2*np.random.rand()-1)*self.noise 
        return r

    def step(self, state, action):
        next_state = choice(self.nb_states, self.transition_function[int(state), action, :].squeeze())
        reward = self._get_reward(state, action, next_state)
        return reward, next_state, True

    def _generate_transition_function(self):
        self.transition_function = np.zeros((self.nb_states, self.nb_actions, self.nb_states))
        self.transition_function[0,:,2] = 1
        self.transition_function[0,0,1] = 1
        self.transition_function[0,0,2] = 0
        return self.transition_function

    # Reward matrix
    def _generate_reward_function(self):
        self.reward_function = np.zeros((self.nb_states, self.nb_states))
        self.reward_function[0,1] = 1
        return self.reward_function

    def start_state(self):
        return self.initial_state

    def generate_random_policy(self):
        # We use log to have a policy that is further from uniform.
        x = np.log(np.random.rand(self.nb_states,self.nb_actions))
        pi = x/x.sum(axis=1).reshape(self.nb_states,1)
        return pi
