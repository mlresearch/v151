#######################################
#### Run experiments for Fig 5 #####
#######################################

# tensorboard needs to be installed for visualization of the results

#######################################
#######################################
#######################################



import numpy as np
import torch
import torch.optim as optim
from tensorboardX import SummaryWriter
import datetime
import sys


#### change the following line to "from bn_no_resnet import ..." to include bn  ####
#### or to "from skip_no_bn_resnet import ..." to include skip connections      ####
#### ot yo "from resnet import ... " to have a normal ResNet                    ####


from no_resnet import ResNet18,ResNet34,ResNet50,ResNet101,ResNet152,ResNet200,ResNet270,ResNet336, ResNet500

####################################################################################


import torchvision
import torchvision.transforms as transforms

import gc

class MyDataset(torch.utils.data.Dataset):
    def __init__(self, X,Y):
        super().__init__()

        self.X, self.Y = X,Y
        self.N= self.X.shape[0]
        
    def get_item(self, idx):        
        return self.X[idx].to(device), self.Y[idx].to(device)

    def get_all(self):
        return self.X,self.Y


def flat_gradient(net):
    grad_dict  = {k:v.grad for k, v in zip(net.state_dict(), net.parameters())}
    grad_vec = torch.cat([g.contiguous().view(-1) for k,g in grad_dict.items()])
    return grad_vec


def flat_params(model):
    flat_data = []
    for p in model.parameters():
        flat_data.append(p.view(-1))

    return torch.cat(flat_data)

def H_exact(model, data,target,current_depth):
    loss_fn=torch.nn.CrossEntropyLoss() 
    model.train()
    model.zero_grad()
    loss = loss_fn(model(data.transpose(1,3)), target.long())

    if current_depth<200:
        layer_subset=np.random.choice(np.arange(0,current_depth), 50, replace=False) 
    else:
        layer_subset=np.random.choice(np.arange(0,current_depth), 25, replace=False) 


    grad_dict = torch.autograd.grad(loss, list(np.array(list(model.parameters()))[layer_subset]), create_graph=True,allow_unused=True)


    grad_vec=[]
    for i,g in enumerate(grad_dict):
        #if i in layer_subset:
        grad_vec.append(g.contiguous().view(-1))

    grad_vec=torch.cat(grad_vec)
 
    neuron_subset=torch.randperm(len(grad_vec))[:500]
    grad_vec = grad_vec[neuron_subset] 

    H = torch.ones((grad_vec.size(0), grad_vec.size(0)))
    del grad_dict
    for i, grad in enumerate(grad_vec):
        print(i)
        H_i_dict = torch.autograd.grad(grad, list(np.array(list(model.parameters()))[layer_subset]), retain_graph=True,allow_unused=True)
        H_i_vec = torch.cat([g.contiguous().view(-1) for g in H_i_dict])
        H[:, i] = H_i_vec[neuron_subset]
        del H_i_vec,H_i_dict

    return H,grad_vec

def train_net(train_ds,n_epochs = 100, batch_size=32):
    he_init=True
    myint=np.random.randint(100, size=1)
    writer = SummaryWriter(f'logs/figCNN/no_resnet_{myint}')
    rperm = torch.randperm(train_ds.N).to(device)

    depths=[18,34,50,101,152,200,270,336,500]
    for j,model in enumerate([ResNet18,ResNet34,ResNet50,ResNet101,ResNet152,ResNet200,ResNet270,ResNet336,ResNet500]):
        grad_norm=0
        h_diag=0
        h_offdiag=0
        inits=2
        print(model)

        for i in range(inits):

            my_model=model().to(device)
          
            for m in my_model.modules():
                if isinstance(m, torch.nn.Conv2d):
                    torch.nn.init.kaiming_uniform_(m.weight, mode='fan_out', nonlinearity='sigmoid')

            my_model.train()
            my_model.zero_grad()
            x,y = train_ds.get_item(rperm[i*(batch_size):min((i+1)*(batch_size),train_ds.N-1)])
            loss_fn=torch.nn.CrossEntropyLoss() 
            my_model.train()
            my_model.zero_grad()
      

            H,grad=H_exact(my_model,x,y,depths[j]) 
           
            grad_norm+=torch.mean(torch.abs(grad)).detach().item()
            h_diag+=(torch.sum(torch.abs(torch.diag(H)))/H.shape[0]).detach().item() 
            h_offdiag+=(torch.sum(torch.abs(H-torch.diag(H)))/(H.shape[0]**2-H.shape[0])).detach().item() 

            del my_model,H,grad
            gc.collect()


        writer.add_scalar('stats/grad_norm',grad_norm/inits,depths[j])  
        writer.add_scalar('stats/h_diag',h_diag/inits,depths[j])   
        writer.add_scalar('stats/h_offdiag',h_offdiag/inits,depths[j])   

    writer.close()
    return  

time = None

def main():
    global device
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    ########################################################################
    ########################### 2. load data  ##############################
    ########################################################################
    transform = transforms.Compose(
    [transforms.ToTensor()])
    trainset = torchvision.datasets.CIFAR10(root='./data', train=True, download=True, transform=transform)
    train_ds = MyDataset(torch.Tensor(trainset.data),torch.Tensor(trainset.targets))

    ########################################################################
    ######################### 3. pass trough network #######################
    ########################################################################

    train_net(train_ds,batch_size=32)
        
   
    print("done!")

if __name__ == "__main__":
    main()


    