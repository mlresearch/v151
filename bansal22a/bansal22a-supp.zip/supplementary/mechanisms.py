import numpy as np
from scipy.stats import cauchy
from numpy import random
import matplotlib.pyplot as plt
import itertools

alpha = 0.005
delta = 10 ** -6

# Histogram mechanisms

def getTrLapHist(hist, eps):
  paramq = 2 / eps * np.log( 1 + (np.exp(eps) - 1) / (2 * delta))
  loc = -paramq/2
  scale = (1/eps)

  noisyHist = [0]*len(hist)
  
  for i in range(len(hist)):
    while True:
      z = random.laplace(loc, scale)
      if z >= -paramq and z <= 0:
        noisyHist[i] = max(0, hist[i] + z)
        break
  return np.round(noisyHist)

def getBNSHist(hist, eps):
  n = sum(hist)
  g = len(hist)

  lapParam = 2/(eps)
  bnsParam = np.log(2/delta) * (2/eps) + 1
  bnsHist = [0]*g
  for i in range(g):
    if hist[i] == 0:
      continue
    tempVal = hist[i] + random.laplace(0, lapParam)
    if tempVal < bnsParam:
      continue
    bnsHist[i] = tempVal
  return bnsHist

def getPTRmax(hist, eps, k):
  maxIndex = getIndexMax(hist,k)
  scale = (1/eps)

  # Take quality function as min of all margins from maxIndex
  qValue = hist[maxIndex] - k 
  for i in range(maxIndex + 1, len(hist)):
    qValue = min(qValue, k - 1 - hist[i])

  gap = qValue + random.laplace(0, scale)
  paramq = np.log(1/delta) * (1/eps)
  
  if gap <= paramq:
    return np.random.randint(0, len(hist))

  return maxIndex

def getPTRmode(hist, eps):
  scale = (1/eps)

  modeIndex = getIndexMode(hist)
  freq_hist = sorted(hist)

  # quality function. q(S, h) = -1 * abs(h - modeFreq). 

  qValue = freq_hist[-1] - freq_hist[-2]
  gap = qValue + random.laplace(0, scale)
  paramq = np.log(1/delta) * (1/eps)
  
  if gap <= paramq:
    return np.random.randint(0, len(hist))

  return modeIndex

def getSSMax(hist, eps, k):
  beta = eps / (2 * np.log(2 / delta))
  modeIndex = getIndexMode(hist)
  ls = 0
  d_ham = 0
  numBars = len(hist)

  for i in reversed(range(numBars)):
    # make i ans index and compare with rightmost.
    d1 = d_ham + max(0, k - 1 - hist[-1]) + max(0, k - hist[i])
    ls = max(ls, (numBars - 1 - i) * np.exp(-beta * d1))

    # make i ans index and compare with next ans 
    d2 = d_ham + abs(k - hist[i])
    a2 = 0
    for j in range(i - 1, 0, -1):
      if hist[j] >= k:
        a2 = (i - j)
        break 

    ls = max(ls, a2 * np.exp(-beta * d2))
  
    d_ham += max(0, hist[i] - k + 1)

  res = modeIndex + ((ls * 2 ) / eps) * random.laplace(0, 1)      

  res = min(res,len(hist))
  res = max(0, res)

  return res 

def getSSMode(hist, eps):
  beta = eps / (2 * np.log(2 / delta))
  modeIndex = getIndexMode(hist)
  ls = 0
  numBars = len(hist)
  err, _ = errsMode(hist, 0)

  for i in range(len(hist)):

    ls = max(ls, err[i] * np.exp(-beta * abs(hist[i] - 1 - hist[modeIndex])))

  res = modeIndex + ((ls * 2 ) / eps) * random.laplace(0, 1)      

  res = min(res,len(hist))
  res = max(0, res)

  return res 

def getExpAns(hist, eps, err):
  nbar = len(hist)
  probs = [ np.exp( eps * -err[i] / (2 * nbar)) for i in range(nbar)]
  l = sum(probs)
  probs = [ z / l for z in probs]
  return np.random.choice(range(nbar), p=probs)

# function specific routines
def getIndexMax(hist, k):
  for i in reversed(range(len(hist))):
    if hist[i] >= k:
      return i
  return -1

def getIndexMode(hist):
  maxelem = max(hist)
  for i in range(len(hist)):
    if hist[i] == maxelem:
      return i
  return None


# precompute errors and flexible errors for all answers
def errsMax(k, hist, budget):
  maxindex = -1
  fxmaxindex = -1
  for i in reversed(range(len(hist))):
    if hist[i] >= k:
      maxindex = i
      break
  dropped = 0
  for i in reversed(range(maxindex)):
    if hist[i] >= k:
      dropped += hist[i]-k+1
      if (dropped > budget):
        fxmaxindex = i+1
        break
  err = list(map(lambda q: abs(q-maxindex), range(len(hist))))
  fxerr = list(map(lambda q: 0 if (q<=maxindex and q>=fxmaxindex) else min(abs(q-maxindex),abs(fxmaxindex-q)), range(len(hist))))
  return err, fxerr

def errsMode(hist, budget):
  maxelem = max(hist)
  # find smallest value that would work as hist value for flexible mode
  fxmaxelem = min(hist)
  drop = 0
  index = -1
  prevx = maxelem
  for x in sorted(hist,reverse=True):
    index += 1
    drop += index*(prevx-x) 
    if drop > budget:
      fxmaxelem = prevx
      break
    prevx = x
  err = [0]*len(hist)
  fxerr = [0]*len(hist)
  # find distance from closest maxelem to the left
  d = len(hist)
  fd = len(hist)
  for i in range(len(hist)):
    #reset or increment distance 
    d = 0 if hist[i] == maxelem else d+1
    err[i] = d
    fd = 0 if hist[i] >= fxmaxelem else fd+1
    fxerr[i] = fd
  # now check for closeness to the right
  d = len(hist)
  for i in reversed(range(len(hist))):
    #reset or increment distance 
    d = 0 if hist[i] == maxelem else d+1
    err[i] = min(err[i],d)
    fd = 0 if hist[i] >= fxmaxelem else fd+1
    fxerr[i] = min(fxerr[i],fd)
  return err, fxerr

def choosingMechanism(S, indices, params):
  alpha, beta, eps, delta = params[0], params[1], params[2], params[3] 
  scale = 4 / eps
  hist = [S[i] for i in indices]
  m = sum(hist)
  thres = alpha * m / 2

  bS = max(list(map(lambda x: x + random.laplace(0, scale), hist)))
  if bS < thres : 
    # return a random index
    # return random.choice(indices)
    return '*'

  # return as per exponential mechanism
  probs = [0 if i == 0 else np.exp(eps * i / 4) for i in hist]
  probs = [ p / sum(probs) for p in probs]

  return random.choice(indices, p=probs)

def getSanPoints(hist, eps, beta):
  # beta = 0.1 # alpha bound with 1 - beta 
  m = sum(hist)
  log_term = beta * eps * delta/ (320 * np.sqrt(32 * np.log(5 / delta)))
  alpha = (-32 * (np.sqrt(np.log(5/delta)) * np.log(log_term)) / ( eps * m )) ** (1/1.5)
  # alpha = 0.02
  est = [0] * len(hist)
  indices = list(range(len(hist)))
  eps_choose = eps / (np.sqrt(32 * np.log(5 / delta) / alpha))
  delta_choose = alpha * delta / 5
  params = [alpha/2, alpha * beta/ 4, eps_choose, delta_choose]

  for i in range(int(2/alpha)):
    b = choosingMechanism(hist, indices, params)

    if b != '*':
      est[b] = hist[b] + random.laplace(0, 1 / (eps_choose * m))
      # remove the index
      indices = [i for i in indices if i != b]

  return est

def getESAHist(hist, eps):
  m = len(hist)
  res = [0] * m
  t1 = 2 / eps
  t2 = 2 / delta
  t3 =  t1 *(np.log(t2))

  for ii in range(m):
    # calculate noise to be added.
    noise = random.laplace(0, t1) - t3
    nVal = max(0, hist[ii] + noise)

    if nVal <= hist[ii]:
      # use nVal for reporting.
      res[ii] = nVal
    else:
      # return random value.
      res[ii] = np.random.randint(0, len(hist))

  return res


