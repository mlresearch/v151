

# load packages
library(shaff)
library(ranger)
library(mvtnorm)
library(MASS)
library(Matrix)
library(CombMSC)
library(nnls)
library(ggplot2)
library(parallel)


p <- 5

sample_data <- function(a, b, rho1, rho2, alpha, c, d, rho3, rho4, beta, r = 0, nsample){
  
  # Cov
  Covmat1 <- matrix(0, nrow = p, ncol = p)
  diag(Covmat1) <- rep(1, p)
  Covmat1[1,2] <- Covmat1[2,1] <- rho1
  Covmat1[4,5] <- Covmat1[5,4] <- rho2
  Covmat2 <- matrix(0, nrow = p, ncol = p)
  diag(Covmat2) <- rep(1, p)
  Covmat2[1,2] <- Covmat2[2,1] <- rho3
  Covmat2[4,5] <- Covmat2[5,4] <- rho4
  
  # inputs
  X1 <- mvrnorm(n = nsample, mu = rep(0,p), Sigma = Covmat1)
  # X2 <- mvrnorm(n = nsample, mu = rep(0,p), Sigma = Covmat1)
  X2 <- mvrnorm(n = nsample, mu = rep(0,p), Sigma = Covmat2)
  # X2 <- sapply(1:5, rnorm, n = nsample)
  Xnoise <- sapply(1:5, rnorm, n = nsample)
  
  # outputs
  Y1 <- a*X1[,1]*X1[,2]*(X1[,3] > 0) + b*X1[,4]*X1[,5]*(X1[,3] < 0)
  Y2 <- c*X2[,1]*X2[,2]*(X2[,3] > 0) + d*X2[,4]*X2[,5]*(X2[,3] < 0)
  Y <- sqrt(alpha)*Y1 + sqrt(beta)*Y2
  Y <- Y + rnorm(nsample, sd = sqrt(r/(1-r)*var(Y)))
  
  # data
  data <- as.data.frame(cbind(X1, X2, Xnoise, Y)) # 
  colnames(data) <- c(paste('X', 1:(ncol(data)-1), sep=''), 'Y')
  
  return(data)
  
}

block_shap <- function(a, b, cov1, cov2, r = 0){
  
  # basic elements
  V1 <- (a*cov1)^2/2
  V4 <- (b*cov2)^2/2
  V12 <- a^2/2
  V45 <- b^2/2
  V3 <- (a*cov1 - b*cov2)^2/4
  Vall <- V1 + V4 + V12 + V45 + V3
  Vall <- Vall/(1 - r) # noise
  
  # shapley
  shap <- rep(0,p)
  shap[1] <- shap[2] <- (V1/4 + 5/12*V12)/Vall
  shap[4] <- shap[5] <- (V4/4 + 5/12*V45)/Vall
  shap[3] <- (V3 + V1/2 + V4/2 + V12/6 + V45/6)/Vall
  
  return(shap)
  
}

get_theoretical_shapley <- function(a, b, rho1, rho2, alpha, c, d, rho3, rho4, beta, r = 0){
  
  shap1 <- alpha/(alpha + beta) * block_shap(a, b, rho1, rho2)
  shap2 <- beta/(alpha + beta) * block_shap(c, d, rho3, rho4)
  # shap1 <- block_shap(a, b, rho1, rho2)
  # shap2 <- rep(0, 5)
  shap <- c(shap1, shap2) * (1 - r)
  shap <- c(shap, rep(0, 5))
  return(shap) 
  
}


# data parameter
a <- 3
b <- 1
rho1 <- 0.9
rho2 <- 0.5
alpha <- 3
c <- 3
d <- 1
rho3 <- 0.9
rho4 <- 0.5
beta <- 1
r <- 0.05
nsample <- 10000

shapTh <- get_theoretical_shapley(a, b, rho1, rho2, alpha, c, d, rho3, rho4, beta, r)
print(shapTh)

# shap forest parameters
num.trees <- 500
num_varU <- 500
nX <- 15
nrep <- 30
nclust <-  detectCores() - 1

set.seed(10)




### make cluster
cl <- makeCluster(getOption("cl.cores", nclust))
clusterExport(cl, c("sample_data", "shaff", "ranger",
                    "nnls", "p", "nX", "beta", "r", "nsample",
                    "a", "b", "rho1", "rho2", "alpha", "c", "d", "rho3", "rho4",
                    "num.trees", "num_varU", "mvrnorm"))


res <- parLapply(cl, 1:nrep, function(iter){
  data <- sample_data(a, b, rho1, rho2, alpha, c, d, rho3, rho4, beta, r, nsample)
  shap_temp <- shaff(data)
  return(shap_temp)
})
data <- sample_data(a, b, rho1, rho2, alpha, c, d, rho3, rho4, beta, r, nsample)
forest <- ranger(Y ~., data = data)
print(forest$r.square)
Variable <- factor(colnames(data)[-(nX+1)], levels = colnames(data)[-(nX+1)])
dfTh <- cbind(as.data.frame(shapTh), Variable, rep("Theory", nX))
colnames(dfTh) <- c("Shapley", "Variable", "Algo")
resSHAFF <- cbind(as.data.frame(unlist(res)), rep(Variable, nrep), rep(rep("SHAFF", nX), nrep))
colnames(resSHAFF) <- c("Shapley", "Variable", "Algo")
df <- resSHAFF


### Williamson
res <- parLapply(cl, 1:nrep, function(iter){
  data <- sample_data(a, b, rho1, rho2, alpha, c, d, rho3, rho4, beta, r, nsample)
  clock <- Sys.time()
  forest <- ranger(Y ~., data = data, num.trees = num.trees)
  v <- forest$r.squared
  Uall <- sapply(1:num_varU, function(u){
    d <- sample(1:(nX-1), 1)
    U <- sample(1:nX, d)
    return(U)
  })
  V <- sapply(Uall, function(U){
    dataU <- data[, c(U, nX + 1)]
    if (length(U) <= 2){
      max.depth <- 6
    }else{
      max.depth <- NULL
    }
    forestU <- ranger(Y ~., data = dataU, num.trees = num.trees,
                      max.depth = max.depth)
    return(forestU$r.squared)
  })
  Z <- t(sapply(Uall, function(S){
    z <- rep(0, nX)
    z[S] <- 1
    z
  }))
  w <- apply(Z, 1, function(z){
    k <- sum(z)
    (nX - 1)/(choose(nX, k) * k * (nX - k))
  })
  Z <- rbind(rep(0, nX), rep(1, nX), Z)
  Vall <- c(0, v, V)
  w <- c(1000, 1000, w)
  W <- diag(sqrt(w))
  shap_williamson <- nnls(A = W %*% Z, b = W %*% Vall)
  print(Sys.time() - clock)
  return(shap_williamson$x)
})
resWil <- cbind(as.data.frame(unlist(res)), rep(Variable, nrep), rep(rep("Williamson", nX), nrep))
colnames(resWil) <- c("Shapley", "Variable", "Algo")
df <- rbind(df, resWil)


### SAGE
res <- parLapply(cl, 1:nrep, function(iter){
  
  data <- sample_data(a, b, rho1, rho2, alpha, c, d, rho3, rho4, beta, r, nsample)
  
  clock <- Sys.time()
  forest <- ranger(Y ~., data = data, num.trees = num.trees)
  sage <- rep(0, nX)
  ymean <- mean(predict(forest, data[,-(nX+1)])$predictions)
  sig <- var(data$Y)
  m <- 30
  for (iter in 1:nsample){
    i <- sample(1:nsample, 1)
    x <- data[i, -(nX+1)]
    y <- data[i, nX+1]
    lossPrev <- (y - ymean)^2/sig
    S <- sample(1:nX, nX, replace = F)
    s <- c()
    for (j in 1:nX){
      s <- c(s, S[j])
      ik <- sample(1:nsample, m, replace = T)
      xk <- data[ik, -(nX+1)]
      xk[, s] <- x[, s]
      ypred <- mean(predict(forest, xk)$predictions)
      loss <- (y - ypred)^2/sig
      delta <- lossPrev - loss
      sage[S[j]] <- sage[S[j]] + delta
      lossPrev <- loss
    }
  }
  sage <- sage/nsample
  print(Sys.time() - clock)
  return(sage)
  
})
resSAGE <- cbind(as.data.frame(unlist(res)), rep(Variable, nrep), rep(rep("SAGE", nX), nrep))
colnames(resSAGE) <- c("Shapley", "Variable", "Algo")
df <- rbind(df, resSAGE)




## plot results
df$Algo <- factor(df$Algo, levels = c("Theory", "SHAFF", "Williamson", "SAGE"))
shap_plot <- ggplot() + 
  geom_boxplot(data = df, aes(x=Variable, y=Shapley, fill = Algo),
               position=position_dodge(0.5)) +
  geom_point(data = dfTh, aes(x = Variable, y = shapTh), 
             size = 8, color = 'red', shape = 3, stroke = 2) +
  xlab('Variables') +
  ylab('Shapley Effects') +
  theme_classic() +
  theme(axis.line.x = element_line(colour = 'black'),
        axis.line.y = element_line(colour = 'black'),
        text = element_text(size=15),
        plot.title = element_text(hjust = 0.5, size=12, face="italic"))

shap_plot

# save plot
time.end <- gsub(':', '', Sys.time())
time.end <- gsub(' ', '-', time.end)
ggsave(paste0(time.end, '_SHAFF_xp_2.png'), plot = shap_plot, width = 9, height = 6)


