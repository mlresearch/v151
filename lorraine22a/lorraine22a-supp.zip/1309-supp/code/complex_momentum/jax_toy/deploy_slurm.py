import argparse
from deploy import deploy_lrs, deploy_seeds, deploy_inverses, deploy_iters, deploy_regularizer, deploy_losses
from exact_pg import experiment


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Slurm deployment')
    parser.add_argument('--deploy_num', type=int, default=0, help='The deployment number')
    args = parser.parse_args()

    deploy_argss = deploy_regularizer() #deploy_iters() #  # #
    assert args.deploy_num < len(deploy_argss), f"Invalid deployment number: {args.deploy_num}"

    deploy_args = deploy_argss[args.deploy_num]

    print(f"Launching {args.deploy_num}, {deploy_args}")
    experiment(deploy_args)
    print(f"Finished {args.deploy_num}, {deploy_args}")