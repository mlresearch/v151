import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from scipy.stats import truncnorm, norm
from scipy.stats import bernoulli
from scipy.stats import cauchy
import pickle

class Q_bandit:
    '''
    Upper Confidence Bound Bandit
    
    Inputs 
    ============================================
    k: number of arms (int)
    c: exploration constant (standard deviation)
    iters: time horizon (int)
    trunc: truncate the reward distribution
    Variance: noise variance
    bits_unif: number of bits for SQ
    rule: bandit algorithm (ucb or epsilon-greedy)
    quantizer_type: 'our', 'uniform' 
    mu_type: center of quantization rule
    mu: set the average rewards for each of the k-arms.
        Set to "random" for the rewards to be selected from
        a normal distribution. 
        Set to "sequence" for the means to be ordered from 
        0 to k-1.
        Pass a list or array of length = k for user-defined
        values.
    '''
    def __init__(self, k, iters, Variance=1, trunc=None, average=1, quantizer_type=None, bits_unif=3, c=1, mu='random', rule='ucb', mu_type='avg reward', clipp=False, clip_min=0, clip_max=0):
        # Initializations
        self.k = k # Number of arms
        self.c = c # Exploration parameter
        self.iters = iters # Number of iterations
        self.n = 1 # Iterations count
        self.k_n = np.ones(k) # Sample count for each arm
        self.mean_reward = 0 # Total mean reward
        self.q_mean_reward = 0 # Quantized mean reward
        self.regret_mean = 0 # Total regret
        self.reward = np.zeros(iters) # Current reward
        self.q_reward = 0 # Current quantized reward
        self.pulled_ind = 0 # Pulled arm index
        self.regret_all = np.zeros(iters) # Store regrets
        self.pulled_regret = 0 # Regret of current pulled arm
        self.regrets = np.zeros(iters) # Store regrets
        self.bits = np.zeros(iters) # Store used bits
        self.bit = 0 # Current used bits
        self.k_reward_q = np.zeros(k) # Mean reward for each arm
        self.quantizer_type = quantizer_type # Choose quantizer type
        self.average = average # How many quantizer repititions
        self.trunc = trunc # Truncate the distribution
        self.variance =  Variance # Noise variance
        self.bits_unif = bits_unif # Number of bits for SQ
        self.rule = rule # Bandit algorithm
        self.mu_type = mu_type # Center of quantization

        if type(mu) == list or type(mu).__module__ == np.__name__:
            # User-defined averages            
            self.mu = np.array(mu)
        elif mu == 'random':
            # Draw means from probability distribution
            self.mu = 95+np.random.normal(0, 1, k)
        s_mu = sorted(list(self.mu))
        self.delta_min = s_mu[-1]-s_mu[-2]
    # Choose which arm to pull using quantized rewards 
    def pull(self):
        if self.n<= k:
            a = self.n-1
        else:
            if self.rule == 'ucb':
                a = np.argmax(self.k_reward_q+self.c*np.sqrt(np.log(1+self.n*(np.log(self.n)**2))/self.k_n))
            elif self.rule == 'epsilon-greedy':
                epsilon = np.minimum(1,1e-6*self.c*self.k/(self.n*(self.delta_min**2)))
                if bernoulli.rvs(epsilon, size=1)==1:
                    a = np.random.choice(self.k)
                else:
                    a = np.argmax(self.k_reward_q)

        noise = np.sqrt(self.variance)*np.random.normal(0, 1, 1) # Noise to add for the reward
        reward = self.mu[a] + noise # Unquantized reward
        self.mean_reward = (self.mean_reward*(self.n-1)+reward)/self.n # Running mean
        self.regret_mean = (self.regret_mean*(self.n-1)+np.max(self.mu)-reward)/self.n # Running mean 
        self.pulled_regret = np.max(self.mu)-reward # Regret of pulled arm
        self.k_n[a] += 1 # Increase number of samples counter of arm a
        self.n += 1 # Increase total number of samples counter
        self.pulled_ind = a # Set pulled arm index to a
        # If no quantization is used set quantized reward to be same as unquantized
        if self.quantizer_type == None:
            q_reward = reward
        else:
            # Quantize the reward (self.average=1)
            temp_r = 0
            for qu in range(self.average):
                temp_r += self.quantizer(reward)/self.average
            q_reward = temp_r
        
        # Choose center of quantization
        if mu_type == 'avg reward':
            mu_hat = self.q_mean_reward
        elif mu_type == 'avg arm reward':
            mu_hat = self.k_reward_q[a]
        # Update quantized reward averages
        self.q_mean_reward = (self.q_mean_reward*(self.n-2)+q_reward)/(self.n-1)
        self.k_reward_q[a] = (self.k_reward_q[a]*(self.k_n[a]-2)+q_reward)/(self.k_n[a]-1)
        # Calculate number of bits
        diff_floor = np.floor(reward/np.sqrt(self.variance))-np.floor(mu_hat/np.sqrt(self.variance))
        if ((diff_floor>=-2) and (diff_floor<=3)):
            bit_temp = 3
        else:
            if diff_floor>0:
                diff_floor -= 1
            diff_floor = abs(diff_floor)
            power_of_2 = np.floor(np.log2(diff_floor))
            bit_temp = 3+power_of_2+ np.log2((2**power_of_2)+1)
        self.bit = bit_temp
    # Main function: run bandit for a given time horizon 
    def run(self):
        for i in range(self.iters):
            self.pull()
            self.reward[i] = self.mean_reward
            self.regret_all[i] = self.regret_mean
            self.regrets[i] = self.pulled_regret

            self.bits[i] = self.bit
        self.bits = np.cumsum(self.bits)

            
    def reset(self, mu=None):
        # Resets results while keeping settings
        self.n = 1
        self.k_n = np.ones(self.k)
        self.mean_reward = 0
        self.regret_mean = 0
        self.reward = np.zeros(iters)
        self.regret_all = np.zeros(iters)
        self.pulled_regret = 0
        self.regrets = np.zeros(iters)
        self.k_reward_q = np.zeros(self.k)
        self.q_mean_reward = 0
        self.q_reward = 0
        self.bits = np.zeros(iters)
        if mu == 'random':
            self.mu = 95+1*np.random.normal(0, 1, k)
    # Quantizer implementation
    def quantizer(self, reward):
        # Proposed quantizer
        if self.quantizer_type == 'our':
            norm_r = reward/np.sqrt(self.variance)
            norm_f = np.floor(norm_r)
            p = norm_r-norm_f
            q_val = (norm_f + bernoulli.rvs(p, size=1))*np.sqrt(self.variance)
            return q_val
        # SQ with bits_unif bits
        elif self.quantizer_type == 'uniform':
            temp = np.clip(reward,-1*self.trunc,self.trunc)
            scale = (2*self.trunc)/(2**self.bits_unif-1)
            norm_r = (temp+self.trunc)/scale
            norm_f = np.floor(norm_r)
            p = norm_r-norm_f
            q_val = (norm_f + bernoulli.rvs(p, size=p.shape))*scale-self.trunc
            return q_val

## main running function
def run(k, iters, limit, variance, episodes, mu, bits_unif, rule, mu_type, average=1):
    ucb_regrets = np.zeros(iters) # unquantized regrets
    ucb_q_regrets_our = np.zeros(iters) # proposed quantizer regrets
    ucb_q_regrets_unif = np.zeros(iters) # SQ regrets
    ucb_q_bits_our = np.zeros(iters) # number of bits for the proposed scheme
    c = 2*limit/np.sqrt(average) # exploration constant
    std_unif = 2*limit/(2**bits_unif-1)
    # Initialize bandits
    ucb = Q_bandit(k, iters, mu=mu, Variance=variance, c=np.sqrt(variance), rule=rule)
    ucb_q_our = Q_bandit(k, iters, mu=mu, Variance=variance, quantizer_type='our', c= np.sqrt(variance), rule=rule, mu_type=mu_type)
    ucb_q_unif = Q_bandit(k, iters, mu=mu, Variance=variance, quantizer_type='uniform', trunc= limit, bits_unif=bits_unif, c= std_unif, rule=rule)

    # Run experiments
    for i in range(episodes): 
        ucb.reset(mu=mu)
        ucb_q_our.reset(mu=mu)
        ucb_q_unif.reset(mu=mu)
        ucb.run()
        ucb_q_our.run()
        ucb_q_unif.run()
        # Update long-term averages
        ucb_regrets += ucb.regrets / episodes
        ucb_q_regrets_our += ucb_q_our.regrets / episodes
        ucb_q_regrets_unif += ucb_q_unif.regrets / episodes
        ucb_q_bits_our += ucb_q_our.bits / episodes
        print(i)
        
    vars = {
    'unquant_regret': ucb_regrets,
    'regret_proposed': ucb_q_regrets_our,
    'regret_SQ_3': ucb_q_regrets_unif,
    'bits': ucb_q_bits_our
    }
    pickle_out = open("MAB_vars.pickle","wb")
    pickle.dump(vars, pickle_out)
    pickle_out.close()

# running parameters
iters = int(1e5) # time horizon
episodes = 10 # take average over multiple runs

# bandit
# rule = 'epsilon-greedy'
rule = 'ucb'
k = 100 # number of arms
mu = 'random'

# quantization
# mu_type = 'avg arm reward'
mu_type = 'avg reward'
limit = 100 # clipping for SQ
bits_unif = 3

# RVs
variance = 0.1 # subgaussian parameter

## run simulations and save variables
run(k=k, iters=iters, limit=limit, variance=variance, episodes=episodes, mu=mu, bits_unif=bits_unif, rule=rule, mu_type=mu_type)

## load variables and plot

vars = pickle.load(open("MAB_vars.pickle", "rb"))
regrets = vars['unquant_regret']
regrets_our = vars['regret_proposed']
regrets_unif_3 = vars['regret_SQ_3']
bits = vars['bits']

plt.figure(figsize=(12,8))
plt.plot(range(1,regrets.shape[0]+1),np.log10(np.cumsum(regrets)), 's-', color='black', linewidth=2, markevery=5000, label="unquantized UCB")
plt.plot(range(1,regrets_unif_3.shape[0]+1),np.log10(np.cumsum(regrets_unif_3)), '--', color='green', linewidth=2, label="$3$-bits SQ UCB")
plt.plot(range(1,regrets_our.shape[0]+1),np.log10(np.cumsum(regrets_our)), '*-', linewidth=2, markevery=3000, color='blue', label="QuBan UCB")

# plt.plot(range(1,regrets.shape[0]+1),np.log10(np.cumsum(regrets_epsilon)), 's--', color='black', linewidth=2, markevery=5000, label="unquantized $\epsilon$-greedy")
# plt.plot(range(1,regrets_unif_3.shape[0]+1),np.log10(np.cumsum(regrets_unif_3_epsilon)), 'o--', markevery=5000, color='green', linewidth=2, label="$3$-bits SQ $\epsilon$-greedy")
# plt.plot(range(1,regrets_our.shape[0]+1),np.log10(np.cumsum(regrets_our_epsilon)), '*--', linewidth=2, markevery=3000, color='blue', label="QuBan $\epsilon$-greedy")
plt.legend(prop={'size': 23.5},ncol=2, handleheight=2.5, labelspacing=0.05)
plt.ylim([0.3,6.6])
plt.xlabel("Iterations",size=30)
plt.ylabel("$\log_{10}$(regret)",size=30)
plt.grid()
plt.rc('xtick', labelsize=20) 
plt.rc('ytick', labelsize=20) 
plt.ticklabel_format(axis="x", style="sci", scilimits=(0,0))
plt.savefig('regrets_UCB.pdf', dpi=300)
plt.show()