import numpy as np
import gpflow
from gpflow import Parameter
from gpflow import covariances as cov
import tensorflow as tf

from inducing_points import BipartiteGraphInducingPoints, GraphInducingPoints
from utils import sparse_mat_to_sparse_tensor, normalize_adj


class Edge(gpflow.kernels.base.Kernel):

    def __init__(self, base_kernel, feature_mat, sparse):
        super().__init__(None)
        self.base_kernel = base_kernel
        self.sparse = sparse
        self.dense_feature_mat = feature_mat

    def K(self, X, Y=None, presliced=False):
        """
        :param X: Specifies node indices for each edge in the batch. Shape
        [B, 2].
        :param Y: Specifies node indices for each edge in the batch. Shape
        [B', 2].
        :param presliced:
        :return:
        """
        X = tf.reshape(tf.cast(X, tf.int32), [-1, 2])
        X2 = tf.reshape(tf.cast(Y, tf.int32), [-1, 2]) if Y is not None else X

        cov = self.base_kernel.K(self.dense_feature_mat)
        cov_edges = (tf.gather(tf.gather(cov, X[:, 0], axis=0), X2[:, 0], axis=1)
                     * tf.gather(tf.gather(cov, X[:, 1], axis=0), X2[:, 1], axis=1))
        cov_edges += (tf.gather(tf.gather(cov, X[:, 0], axis=0), X2[:, 1], axis=1)
                     * tf.gather(tf.gather(cov, X[:, 1], axis=0), X2[:, 0], axis=1))
        return cov_edges

    def K_diag(self, X, presliced=False):
        return tf.linalg.diag_part(self.K(X))

    def Kzx(self, inducing_points, X):
        X = tf.reshape(tf.cast(X, tf.int32), [-1, 2])
        M = len(inducing_points)
        Z = tf.concat((inducing_points.Z1, inducing_points.Z2), axis=0)   # Shape [2M, D]

        cov = self.base_kernel.K(self.dense_feature_mat, Z)
        cov_edges = (tf.gather(cov, X[:, 0], axis=0)[:, :M]
                     * tf.gather(cov, X[:, 1], axis=0)[:, M:])
        cov_edges += (tf.gather(cov, X[:, 0], axis=0)[:, M:]
                      * tf.gather(cov, X[:, 1], axis=0)[:, :M])
        return tf.transpose(cov_edges)

    def Kzz(self, inducing_points, jitter=None):
        M = len(inducing_points)
        Z = tf.concat((inducing_points.Z1, inducing_points.Z2), axis=0)   # Shape [2M, D]

        cov = self.base_kernel.K(Z)
        cov_edges = cov[:M, :M] * cov[M:, M:]
        cov_edges += cov[:M, M:] * cov[M:, :M]
        if jitter:
            jitter_matrix = tf.eye(cov_edges.shape[0], cov_edges.shape[1], dtype=cov_edges.dtype) * jitter
            cov_edges += jitter_matrix
        return cov_edges


@cov.Kuu.register(BipartiteGraphInducingPoints, Edge)
def Kuu_graph_polynomial(inducing_variable, kernel, jitter=None):
    """
    Computes the covariance matrix between the inducing points (which are not
    associated with any node).
    :param inducing_variable: Set of inducing points of type
    NodeInducingPoints.
    :param kernel: Kernel of type GraphPolynomial.
    :return: Covariance matrix between the inducing variables.
    """
    return kernel.Kzz(inducing_variable, jitter=jitter)


@cov.Kuf.register(BipartiteGraphInducingPoints, Edge, tf.Tensor)
def Kuf_graph_polynomial(inducing_variable, kernel, X):
    """
    Computes the covariance matrix between inducing points (which are not
    associated with any node) and normal inputs.
    :param inducing_variable: Set of inducing points of type
    NodeInducingPoints.
    :param kernel: Kernel of type GraphPolynomial.
    :param X: Normal inputs. Note, however, that to simplify the
    implementation, we pass in the indices of the nodes rather than their
    features directly.
    :return: Covariance matrix between inducing variables and inputs.
    """
    return kernel.Kzx(inducing_variable, X)


@cov.Kuu.register(GraphInducingPoints, Edge)
def Kuu_graph_polynomial(inducing_variable, kernel, jitter=None):
    """
    Computes the covariance matrix between the inducing points (which are not
    associated with any node).
    :param inducing_variable: Set of inducing points of type
    NodeInducingPoints.
    :param kernel: Kernel of type GraphPolynomial.
    :return: Covariance matrix between the inducing variables.
    """
    Z = inducing_variable.Z
    idcs = tf.cast(inducing_variable.edge_indices, tf.dtypes.int32)

    cov = kernel.base_kernel.K(Z)
    cov_edges = (tf.gather(tf.gather(cov, idcs[:, 0], axis=0), idcs[:, 0], axis=1)
                 * tf.gather(tf.gather(cov, idcs[:, 1], axis=0), idcs[:, 1], axis=1))
    cov_edges += (tf.gather(tf.gather(cov, idcs[:, 0], axis=0), idcs[:, 1], axis=1)
                  * tf.gather(tf.gather(cov, idcs[:, 1], axis=0), idcs[:, 0], axis=1))
    if jitter:
        jitter_matrix = tf.eye(cov_edges.shape[0], cov_edges.shape[1],
                               dtype=cov_edges.dtype) * jitter
        cov_edges += jitter_matrix
    return cov_edges


@cov.Kuf.register(GraphInducingPoints, Edge, tf.Tensor)
def Kuf_graph_polynomial(inducing_variable, kernel, X):
    """
    Computes the covariance matrix between inducing points (which are not
    associated with any node) and normal inputs.
    :param inducing_variable: Set of inducing points of type
    NodeInducingPoints.
    :param kernel: Kernel of type GraphPolynomial.
    :param X: Normal inputs. Note, however, that to simplify the
    implementation, we pass in the indices of the nodes rather than their
    features directly.
    :return: Covariance matrix between inducing variables and inputs.
    """
    X = tf.reshape(tf.cast(X, tf.int32), [-1, 2])
    Z = inducing_variable.Z
    idcs = tf.cast(inducing_variable.edge_indices, tf.dtypes.int32)

    cov = kernel.base_kernel.K(kernel.dense_feature_mat, Z)
    cov_edges = (tf.gather(tf.gather(cov, X[:, 0], axis=0), idcs[:, 0], axis=1)
                 * tf.gather(tf.gather(cov, X[:, 1], axis=0), idcs[:, 1], axis=1))
    cov_edges += (tf.gather(tf.gather(cov, X[:, 0], axis=0), idcs[:, 1], axis=1)
                 * tf.gather(tf.gather(cov, X[:, 1], axis=0), idcs[:, 0], axis=1))
    return tf.transpose(cov_edges)