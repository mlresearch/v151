from sklearn.model_selection import train_test_split
from sklearn.utils import check_random_state
import torch
import numpy as np
import pickle
import matplotlib.pyplot as plt

def sort_by_target(cifar):
    reorder_idx = np.array(sorted([(target, i) for i, target in enumerate(cifar.target)]))[:, 1]
    cifar.data = cifar.data[reorder_idx]
    cifar.target = cifar.target[reorder_idx]

def load_data(data_name, class_list = [0,1], test_size=1000):

    def load_raw_cifar10():

        class data_holder:
            def __init__(self):
                self.data = []
                self.target = []
        cifar_10 = data_holder()

        def unpickle(file):
            with open(file, 'rb') as fo:
                dict = pickle.load(fo, encoding='bytes')
            return dict

        num_batch = 6
        for i in range(num_batch):
            batch_name = fr'../data/CIFAR10/raw/data_batch_{i+1}'
            data_single_batch = unpickle(batch_name)
            cifar_10.data.append(data_single_batch[b'data'])
            cifar_10.target.append(data_single_batch[b'labels'])

        cifar_10.data = np.concatenate(cifar_10.data)
        cifar_10.target = np.concatenate(cifar_10.target)

        return cifar_10

    cifar = load_raw_cifar10()
    cifar.target = cifar.target.astype(np.int8) # fetch_openml() returns targets as strings
    sort_by_target(cifar) # fetch_openml() returns an unsorted dataset
        
    print(f'1. Attempting to load/fetch {data_name} data via byte-data')
    X_raw, y_raw = cifar.data, cifar.target
    print('  Done! data shape = %s, max value = %g' % (str(X_raw.shape), np.max(X_raw)))

    # Add uniform noise to dequantize the images
    print('2. Normalizing values between 0 and 1. (skip this step)')
    random_state = 0
    rng = check_random_state(random_state)
    # X_deq = (X_raw + rng.rand(*X_raw.shape)) / 256.0
    X_deq = X_raw
    #X = (X_raw+0.5)/256.0
    print('  Done! After dequantization and normalization: min=%g, max=%g' % (np.min(X_deq), np.max(X_deq)))

    # Selecting only zeros and ones
    print(f'2a. Only selecting specific classes {class_list}')
    sel = []
    for i,t in enumerate(y_raw):
        if t in class_list:
            sel.append(i)
    X = X_deq[sel, :]
    y = y_raw[sel]

    # Create train and test splits of the data
    print('3. Setting up train and test sizes.')
    X_all = X
    y_all = y

    X_train, X_test, y_train, y_test = train_test_split(
        X_all, y_all, test_size=test_size, random_state=rng)
    print(f'All: {X_all.shape}, Train: {X_train.shape}, Test: {X_test.shape})')
    return X_train, X_test, y_train, y_test

if __name__ == '__main__':
    # cifar_10 = load_raw_cifar10()
    # print(f'data has the structure {cifar_10.data.shape}')
    # print(f'targets has the structure {cifar_10.target.shape}')
    # demo = cifar_10.data[2].reshape(32,32,3,order='F').transpose(1,0,2)
    # plt.imshow(demo)
    # print(type(cifar_10.target[2]))
    # plt.show()

    class_list = [0, 1]

    X_train, X_test, y_train, y_test = load_data('CIFAR_10', class_list=class_list, test_size=5000)
    print(f'number of digit 0 samples{len(np.nonzero(y_train==0)[0])}')
    print(f'number of digit 1 samples{len(np.nonzero(y_train==1)[0])}')
    print(f'X_train, X_test have sizes: {X_train.shape, X_test.shape}')
    print(f'y_train, y_test have sizes: {y_train.shape, y_test.shape}')

    # rearrange the order and number of samples for simplification of implementation
    n_samples_list = [len(np.nonzero(y_train==l)[0]) for l in class_list]
    n_samples = np.min(n_samples_list)

    X = []
    y = []
    for i in class_list:
        X_temp = X_train[np.nonzero(y_train==i)[0]]
        X_temp = X_temp[:n_samples]
        y_temp = y_train[np.nonzero(y_train==i)[0]]
        y_temp = y_temp[:n_samples]
        X.append(X_temp)
        y.append(y_temp)
        print(f'number of digit {i} samples is {len(X_temp)}')
    X = np.array(X).reshape(-1, X_train.shape[1])
    y = np.array(y).reshape(-1,)


    np.save(r'../data/CIFAR10/X_train.npy', X)
    np.save(r'../data/CIFAR10/y_train.npy', y)

    # rearrange the order and number of samples for simplification of implementation
    n_samples_list = [len(np.nonzero(y_test==l)[0]) for l in class_list]
    n_samples = np.min(n_samples_list)
    n_split = 1500

    X_cnn = []
    y_cnn = []
    X_eval = []
    y_eval = []
    for i in class_list:
        X_temp = X_test[np.nonzero(y_test==i)[0]]
        y_temp = y_test[np.nonzero(y_test==i)[0]]

        X_temp_cnn = X_temp[:n_split]
        y_temp_cnn = y_temp[:n_split]
        X_temp_eval = X_temp[n_split:n_samples]
        y_temp_eval = y_temp[n_split:n_samples]

        X_cnn.append(X_temp_cnn)
        y_cnn.append(y_temp_cnn)
        X_eval.append(X_temp_eval)
        y_eval.append(y_temp_eval)

        print(f'number of digit {i} samples in cnn set is {len(X_temp_cnn)}')
        print(f'number of digit {i} samples in eval set is {len(X_temp_eval)}')

    X_cnn = np.array(X_cnn).reshape(-1, X_test.shape[1])
    y_cnn = np.array(y_cnn).reshape(-1,)
    X_eval = np.array(X_eval).reshape(-1, X_test.shape[1])
    y_eval = np.array(y_eval).reshape(-1,)

    np.save(r'../data/CIFAR10/X_cnn.npy', X_cnn)
    np.save(r'../data/CIFAR10/y_cnn.npy', y_cnn)
    np.save(r'../data/CIFAR10/X_eval.npy', X_eval)
    np.save(r'../data/CIFAR10/y_eval.npy', y_eval)