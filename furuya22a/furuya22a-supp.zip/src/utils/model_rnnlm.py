from typing import Tuple

import torch
import torch.nn as nn
from torch import Tensor


class RNNLM(nn.Module):
    """RNN language model."""

    def __init__(
        self,
        ntoken: int,
        d_model: int,
        d_hid: int,
        nlayers: int = 1,
        dropout: float = 0.2,
        irnn: bool = False,
        tie_weights: bool = False,
    ):
        super(RNNLM, self).__init__()
        nonlinearity = "relu" if irnn else "tanh"
        self.encoder = nn.Embedding(ntoken, d_model)
        self.drop = nn.Dropout(dropout)
        self.rnn = nn.RNN(
            input_size=d_model,
            hidden_size=d_hid,
            num_layers=nlayers,
            nonlinearity=nonlinearity,
            bias=True,
            batch_first=False,
        )
        self.decoder = nn.Linear(d_hid, ntoken)
        self.d_embed = d_model
        self.d_hid = d_hid
        self.ntoken = ntoken
        self.irnn = irnn
        self.tie_weights = tie_weights
        self.init_weights()
        if tie_weights:
            if d_hid != d_model:
                raise ValueError("When using the tied flag, d_hid must be equal to d_model")
            self.decoder.weight = self.encoder.weight

    def init_weights(self) -> None:
        # initrange = 0.1  # worse than 0.05
        initrange = 0.05
        self.encoder.weight.data.uniform_(-initrange, initrange)
        self.decoder.bias.data.zero_()
        self.decoder.weight.data.uniform_(-initrange, initrange)
        # Initialize h2h weights to identity function
        # [A Simple Way to Initialize Recurrent Networks of Rectified Linear Units](https://arxiv.org/abs/1504.00941)
        if self.irnn:
            for p in self.rnn.named_parameters():
                if "weight_hh_l" in p[0]:
                    nn.init.eye_(p[1])
                elif "bias_hh_l" in p[0]:
                    nn.init.zeros_(p[1])
                else:
                    pass

    def forward(self, inputs: Tensor, hidden: Tensor) -> Tuple[Tensor, Tensor]:
        # Initialize hidden state only for initial step of epoch
        if hidden is None:
            batch_size = inputs.size(1)
            hidden = self.init_hidden(batch_size).to(next(self.parameters()).device)
        emb = self.drop(self.encoder(inputs))
        output, hidden = self.rnn(emb, hidden.detach())
        output = self.drop(output)
        output = self.decoder(output)
        return output, hidden

    def forward_to_hidden(self, inputs: Tensor, hidden: Tensor) -> Tensor:
        self.eval()
        # Initialize hidden state only for initial step of epoch
        if hidden is None:
            batch_size = inputs.size(1)
            hidden = self.init_hidden(batch_size).to(next(self.parameters()).device)
        emb = self.drop(self.encoder(inputs))
        output, hidden = self.rnn(emb, hidden.detach())
        return output, hidden

    def init_hidden(self, batch_size: int) -> Tensor:
        return torch.zeros(1, batch_size, self.d_hid)


class RNNLM_CS(RNNLM):
    """CS means Column Sparsification.

    [Acceleration of LSTM With Structured Pruning Method on FPGA](https://ieeexplore.ieee.org/document/8716654)
    """

    def __init__(
        self,
        ntoken: int,
        d_model: int,
        d_hid: int,
        m_sharp: int,
        nlayers: int = 1,
        dropout: float = 0.2,
        irnn: bool = False,
        tie_weights: bool = False,
    ):
        super().__init__(ntoken, d_model, d_hid, nlayers, dropout, irnn, tie_weights)
        setattr(self, "m_sharp", m_sharp)
        setattr(self, "removed", False)

    def forward(self, inputs: Tensor, hidden: Tensor) -> Tuple[Tensor, Tensor]:
        if self.removed:
            output, hidden = super().forward(inputs, hidden)
        else:
            # Computational graph does not record this mask
            h2h_tmp = self.rnn.weight_hh_l0.data.clone()
            mask = self.get_structured_mask(h2h_tmp, self.m_sharp)
            self.rnn.weight_hh_l0.data.mul_(mask)

            output, hidden = super().forward(inputs, hidden)

            # Reset the mask
            self.rnn.weight_hh_l0.data = h2h_tmp
        return output, hidden

    def get_structured_mask(self, tensor, m_sharp):
        with torch.no_grad():
            norm = torch.norm(tensor, dim=0, p=1)
            c = torch.topk(norm, m_sharp + 1, largest=True).values[-1]
            k = (norm - c) / norm  # epsilon
            k[k < 0] = 0.0
            mask = torch.ones_like(tensor) * k
        return mask

    def remove_mask_(self):
        if self.removed:
            raise Exception("Mask has already removed.")
        else:
            mask = self.get_structured_mask(self.rnn.weight_hh_l0, self.m_sharp)
            self.rnn.weight_hh_l0.data.mul_(mask)
            self.removed = True


class RNNLM4FT(RNNLM):
    """Non-structured-pruned RNN for fine-tuning."""

    def __init__(
        self,
        ntoken: int,
        d_model: int,
        d_hid: int,
        nlayers: int = 1,
        dropout: float = 0.2,
        irnn: bool = False,
        tie_weights: bool = False,
    ):
        super().__init__(ntoken, d_model, d_hid, nlayers, dropout, irnn, tie_weights)
        setattr(self, "mask", {})
        setattr(self, "mask_keys", [])

    def forward(self, inputs: Tensor, hidden: Tensor) -> Tuple[Tensor, Tensor]:
        self.update_weight()
        output, hidden = super().forward(inputs, hidden)
        return output, hidden

    def set_mask(self, mask: Tensor, keys: str) -> None:
        self.mask = mask
        self.mask_keys = keys

    def update_weight(self) -> None:
        for key in self.mask_keys:
            self.state_dict()[key] *= self.mask[key]


def prepare_trained_rnnlm(
    weight,
    dropout: float = 0.2,
    tie_weights: bool = False,
    requires_grad: bool = False,
    m_sharp: int = None,
    ft: bool = False,
):
    """Return trained RNN model whose parameters have `requires_grad` option."""
    d_model = weight["rnn.weight_ih_l0"].shape[1]
    d_hid = weight["rnn.weight_ih_l0"].shape[0]
    ntoken = weight["decoder.weight"].shape[0]
    if ft:
        model = RNNLM4FT(
            ntoken=ntoken, d_model=d_model, d_hid=d_hid, nlayers=1, dropout=dropout, tie_weights=tie_weights
        )
    elif m_sharp is None:
        model = RNNLM(ntoken=ntoken, d_model=d_model, d_hid=d_hid, nlayers=1, dropout=dropout, tie_weights=tie_weights)
    else:
        model = RNNLM_CS(
            ntoken=ntoken,
            d_model=d_model,
            d_hid=d_hid,
            m_sharp=m_sharp,
            nlayers=1,
            dropout=dropout,
            tie_weights=tie_weights,
        )
    model.load_state_dict(weight)

    for param in model.parameters():
        param.requires_grad = requires_grad
    return model
