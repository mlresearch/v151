
import gym
from gym.envs.classic_control.cartpole import CartPoleEnv

class InfiniteCartPole(CartPoleEnv):

  def step(self, action):
    obs, reward, done, info = super(InfiniteCartPole, self).step(action)
    if done:
      reward = -1.
    else:
      reward = 1.
    return obs, reward, False, info
