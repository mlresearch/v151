import numpy as np
from .base_builder import BaseBuilder
from cbp.node import FactorNode

# * d(G) grows O(m)


class HMMBuilder(BaseBuilder):
    def __init__(self, length, node_dim, policy, rand_seed=1):
        self.hmm_length = length
        self.__step = 0
        super().__init__(node_dim, policy, rand_seed)

    def step(self, time_stamp=None):
        """hmm go forward a step, time + 1

        :param time_stamp: timer for the current add node
        :type time_stamp: int
        """
        if time_stamp is None:
            time_stamp = self.__step
        assert time_stamp > 0
        self.add_branch(head_node=f"VarNode_{2*time_stamp-2:03d}")
        self.add_branch(is_constrained=True, is_conv=True)
        self.__step += 1

    def init_graph(self):
        self.add_trivial_node()
        self.add_branch(is_constrained=True, is_conv=True)
        self.__step = 1

        for i in range(1, self.hmm_length):
            self.step(time_stamp=i)

    def add_branch(self, head_node=None, is_constrained=False,
                   prob=None, is_conv=False):
        if head_node is None:
            head_node = f"VarNode_{self.graph.cnt_varnode-1:03d}"
        if is_constrained:
            node = self.add_constrained_node(prob)
        else:
            node = self.add_trivial_node()

        name_list = [head_node, node.name]
        inv_eta = 2 * (self.hmm_length * 2) * \
            np.log(self.node_dim) / self.graph.cfg.itsbp_outer_tolerance
        # * add inverse_eta and exp to potential
        self.graph.inv_eta = inv_eta
        self.add_factor(name_list, is_conv, inv_eta)

    def deterministic_cost(self, d_1: int, d_2: int) -> np.ndarray:
        array1 = np.repeat(np.linspace(0, 1, d_1).reshape(-1, 1), d_2, axis=1)
        array2 = np.linspace(0, 1, d_2)
        cost = (array1 - array2)**2
        return cost

    def add_factor(self, name_list, is_conv=False, inverse_eta=5000):
        factor_potential = self.deterministic_cost(
            self.node_dim, self.node_dim)
        factornode = FactorNode(
            name_list, np.exp(-inverse_eta * factor_potential))
        self.graph.add_factornode(factornode)
        return factornode
