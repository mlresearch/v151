import numpy as np
from sklearn.cluster import KMeans
from sklearn.metrics import accuracy_score


def run_km(x_train_a, x_train_b, y_train, x_test, y_test):
    x_train = np.vstack([x_train_a, x_train_b])
    clf = KMeans(n_clusters=2).fit(x_train)
    y_pred = clf.predict(x_test) * 2 - 1
    accuracy = accuracy_score(y_test, y_pred)

    return accuracy
