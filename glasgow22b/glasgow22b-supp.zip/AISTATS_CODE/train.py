import numpy as np
import os
import pandas as pd
import sys

def file_suffix(name, alg, m, n_block, d, block):
    return "%s_%s_%s_machines_%s_%s_block_%s" % (name, alg, m, n_block, d, block)

def min_eta(m, block):
    width = m*block
    min_eta = 0.0001/np.sqrt(width)
    return min_eta

def train(name, n_block, d, m, alg, block, step_index, reps, epsilon, epochs, num_partitions, datafiles_suffix, eta=None):
    if num_partitions % m != 0:
        print("Skipping run because num_partitions %s not divisible by %s machines." % (num_partitions, m))
        return
    if n_block % (m*block) != 0:
        print("Skipping run becasue data of length %s not divisible by %s machines and block size %s." % (n_block, m, block))
        return
    if alg == 'asaga' or m == 1:
        memory = 16
    else:
        memory = 4
    if alg[:3] == 'syn':
        sync = True
        #print(alg, "Sync")
    else:
        sync = False
    n = int(n_block/block)
    if eta:
        first_eta = eta
    else:
        first_eta = min_eta(m, block)
    filename = file_suffix(name, alg, m, n_block, d, block)
    if sync:
        alg = alg[5:]
    command = "sbatch --nodes=%s --mem-per-cpu=%sG --output=%s.log optimize.sbatch %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s" % (m + 1, memory, filename, filename, alg, n, d, block, m + 1, epsilon, num_partitions, first_eta, epochs, step_index, sync, datafiles_suffix, reps, name)
    print(command)
    os.system(command)

def train_simulated(name, n_block, d, m, alg, block, step_index, reps, epsilon, epochs, num_partitions, datafiles_suffix):
    import machines
    if num_partitions % m != 0:
        print("Skipping run because num_partitions %s not divisible by %s machines." % (num_partitions, m))
        return
    if n_block % (m*block) != 0:
        print("Skipping run becasue data of length %s not divisible by %s machines and block size %s." % (n_block, m, block))
        return
    filename = file_suffix(name, alg, m, n_block, d, block)
    os.system("mkdir %s" % filename)
    os.system("mkdir %s/workers" % filename)
    os.system("mkdir %s/MSE" % filename)
    os.system("mkdir %s/queue" % filename)

    n = int(n_block/block)
    size = m + 1
    first_eta = min_eta(m, block)
    sizes = [first_eta*(1.3**i) for i in range(40)]
    suffix = datafiles_suffix
    num_chunks = num_partitions
    chunks_per_worker = int(num_chunks/(size - 1))
    samples_per_worker = int(n/(size - 1))
    max_its = n*epochs
    if alg[:3] == 'syn':
        sync = True
        alg = alg[5:]
    else:
        sync = False
    j = 0
    f = open("%s/statistics.txt" % filename, 'w', buffering=1)
    fnice = open("%s/statistics_nice.txt" % filename, 'w', buffering=1)
    best_err = np.inf
    best_wallclock = np.inf
    met_eps = False
    for eta in sizes:
        j+=1
        if j != step_index and step_index != -1:
            continue
        # Master
        workers = []
        for i in range(m):
            worker = machines.Worker(i + 1, d, filename, samples_per_worker, block, alg)
            worker.load_data(num_chunks=num_chunks, chunks_per_worker=chunks_per_worker, data_file="data_%s" % suffix, label_file="labels_%s" % suffix)
            worker.reset(tag=10*j)
            workers.append(worker)
        queue = np.random.randint(size - 1, size=(max_its + 3))
        master = machines.Master(d, size, filename, n, block, None, max_its, alg, xhat_file = "xhat_%s" % suffix, epsilon=epsilon, simulated=True, workers=workers, queue=queue)
        master.reset(eta, tag=10*j)
        master.master_init()
        if sync:
            errors_per_epoch, wallclock, its = master.master_routine_sync()
        else:
            errors_per_epoch, wallclock, its = master.master_routine()
        err = errors_per_epoch[-1]
        f.write("Error after %s iterations with eta = %s %s in %s seconds.\n" % (its, eta, err, wallclock))
        to_write = [its, eta, wallclock] + errors_per_epoch + ['\n']
        fnice.write(" ".join(str(x) for x in to_write))
        if err < best_err:
            best_err = err
        if wallclock < best_wallclock:
            best_wallclock = wallclock
        if met_eps and wallclock/best_wallclock > 1.2:
            print("Aborting from Master because degrading wallclock, while at epsilon.")
            break
        elif (err/best_err) > 5:
            print("Aborting from Master because degrading error.")
            break
    os.system("mv %s %s" % (filename, name))

def run_best_hps(hp_file, name, n_block, d, reps, epsilon, epochs, num_partitions, datafiles_suffix):
    os.system("mkdir %s" % name)
    df = pd.read_csv(hp_file, sep=' ')
    for index, row in df.iterrows():
        alg = row['alg']
        m = row['machines']
        block = row['blocks']
        step_index = row['stepindex']
        eta = row['eta']
        train(name, n_block, d, m, alg, block, 0, reps, epsilon, epochs, num_partitions, datafiles_suffix, eta=eta)

def run_hp_search(name, n_block, d, algs, ms, blocks, epsilon, epochs, num_partitions, datafiles_suffix):
    os.system("mkdir %s" % name)
    for m in ms:
        for alg in algs:
            for block in blocks:
                train(name, n_block, d, m, alg, block, -1, 1, epsilon, epochs, num_partitions, datafiles_suffix)

def simulated_hp_search(name, n_block, d, algs, ms, blocks, epsilon, epochs, num_partitions, datafiles_suffix):
    os.system("mkdir %s" % name)
    for m in ms:
        for alg in algs:
            for block in blocks:
                train_simulated(name, n_block, d, m, alg, block, -1, 1, epsilon, epochs, num_partitions, datafiles_suffix)



# Usage: 
# python3 train.py search <n_block> <d> <name> <epochs> <num_partitions> <datafiles_suffix> <num_workers...>
# python3 train.py best <n_block> <d> <name> <epochs> <num_partitions> <datafiles_suffix> <hp_file> <reps> <epsilon>
# python3 train.py sim_search <n_block> <d> <name> <epochs> <num_partitions> <datafiles_suffix> <epsilon> <num_workers...>
task = sys.argv[1]
n_block = int(sys.argv[2])
d = int(sys.argv[3])
name = sys.argv[4]
epochs = int(sys.argv[5])
num_partitions = int(sys.argv[6])
datafiles_suffix= sys.argv[7]
algs = ['sync_adsaga', 'asgd']#['adsaga_hetero', 'iag', 'asgd', 'sync_adsaga', 'adsaga', 'sync_asgd']#['adsaga_hetero', 'adsaga_hetero2', 'adsaga_hetero3', 'adsaga_hetero4']#['asaga'] #['adsaga_hetero', 'iag', 'asgd', 'asaga', 'sync_adsaga']
blocks = [200]
if task == 'best':
    run_best_hps(sys.argv[8], name, n_block, d, int(sys.argv[9]), float(sys.argv[10]), epochs, num_partitions, datafiles_suffix)
elif task == 'search':
    num_ms = len(sys.argv) - 8
    ms = [int(sys.argv[8 + i]) for i in range(num_ms)]
    run_hp_search(name, n_block, d, algs, ms, blocks, 0, epochs, num_partitions, datafiles_suffix)
elif task == 'sim_search':
    blocks = [1]
    num_ms = len(sys.argv) - 9
    ms = [int(sys.argv[9 + i]) for i in range(num_ms)]
    simulated_hp_search(name, n_block, d, algs, ms, blocks, float(sys.argv[8]), epochs, num_partitions, datafiles_suffix)
