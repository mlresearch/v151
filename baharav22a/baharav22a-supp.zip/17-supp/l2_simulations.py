import itertools
import multiprocessing as mp
import numpy as np
import os, pickle
from tqdm import tqdm, trange
import math
import numpy.linalg as npl
import scipy.special,time, scipy.stats
from collections import Counter
from scipy.special import comb as choose


f = lambda x :  np.linalg.norm(x)**2

def ceil(arr):
    return np.ceil(arr).astype(int)


def adaBatch(A,x,epsTarget,delta,iterCount,baseE=2):
    n,d= A.shape
    b0=1
    t=0
    
    perm = np.random.permutation(d)
    A = A[:,perm]
    x = x[perm]
    armMeans = A.dot(x)
    
    numPullsArr = np.zeros(n,dtype='int')
    estMeans = np.zeros(n)
    errArr = []
    budgetArr = []
    while True: 
        
        roundBudget = n*b0*baseE**t ### change base of exp
        numUnifPulls = ceil(roundBudget/n)
        
        ##phase 1: uniform sampling
        for i in range(n):
            pulli = numPullsArr[i]
            if pulli>=d:
                continue
            if pulli + numUnifPulls>=d:
                estMeans[i] = A[i].dot(x)
                numPullsArr[i]+=d
            else:
                samples = d/numUnifPulls * A[i,pulli:pulli+numUnifPulls].dot(x[pulli:pulli+numUnifPulls])
                estMeans[i] = (estMeans[i] * pulli + numUnifPulls*samples)/(pulli+numUnifPulls)
                numPullsArr[i] += numUnifPulls

        ## phase 2: adaptive sampling
        confT = np.sqrt(np.log(1.0/delta)/numPullsArr)
        alphaVec = np.maximum(np.abs(estMeans)-confT,0)
        alphaVec[numPullsArr>=d]=0 ## due to computational problem
        if alphaVec.max()==0: ## if all 0, more uniform sampling
            alphaVec = np.ones(n)
        alphaVec/=alphaVec.sum()
        
        ## factor inserted to downweight uniform sampling
        ft = min(t+1,10) 
        tTilde = ceil(alphaVec*roundBudget*ft)
        
        tempestMeans = np.copy(estMeans)
        tempnumPullsArr = np.copy(numPullsArr)
        for i in range(n):
            tti = tTilde[i]
            pulli = numPullsArr[i]
            if tti ==0 or pulli>=d:
                continue
                
            if pulli + tti>=d:
                tempestMeans[i] = A[i].dot(x)
                tempnumPullsArr[i]+=d
            else:
                samples = d/tti * A[i,pulli:pulli+tti].dot(x[pulli:pulli+tti])
                tempestMeans[i] = (estMeans[i] * pulli + tti*samples)/(pulli+tti)
                tempnumPullsArr[i] += tti

        fEst = np.linalg.norm(tempestMeans,2)**2 - np.sum((tempnumPullsArr<d)/tempnumPullsArr)
        errArr.append(np.abs(fEst - f(armMeans)))
        budgetArr.append(tempnumPullsArr.sum())
        
        confT = np.sqrt(np.log(1.0/delta)/numPullsArr)
        if 16*np.log(1.0/delta)*np.sum(((np.abs(estMeans)+confT)**2/(tempnumPullsArr))*(tempnumPullsArr<d)) <= epsTarget**2:
            estMeans= tempestMeans
            numPullsArr = tempnumPullsArr
            break
        
        t+=1
        if t==iterCount:
            break
    return estMeans,errArr,budgetArr,numPullsArr


def unifBatch(A,x,epsTarget,delta,iterCount,baseE=2):
    f = lambda x :  np.linalg.norm(x)**2
    n,d = A.shape
    t=0
    b0=1
    numPullsArr = np.zeros(n)
    muStar = A.dot(x)
    
    estMeans = np.zeros(n)
    errArr = []
    budgetArr = []
    
    perm = np.random.permutation(d)
    A = A[:,perm]
    x = x[perm]
    while True:
        
        roundBudget = n*b0*baseE**t ### change base of exp
        numUnifPulls = ceil(roundBudget/n)
        
        if numUnifPulls>=d:
            estMeans = A.dot(x)
            errArr.append(0)
            budgetArr.append(numPullsArr.sum()+n*d)
            break
            
        Js=np.random.choice(d,size=numUnifPulls,replace=False)
        samples = d/numUnifPulls*A[:,Js].dot(x[Js])
        estMeans = (estMeans * numPullsArr + numUnifPulls*samples)/(numPullsArr+numUnifPulls) 
        numPullsArr += numUnifPulls
        
        errArr.append(np.abs(f(estMeans) - np.sum(1.0/numPullsArr) - f(muStar)))
        budgetArr.append(numPullsArr.sum())
        
        confT = np.sqrt(np.log(1.0/delta)/numPullsArr)
        if 16*np.log(1.0/delta)*np.sum((2*np.abs(estMeans)+confT)**2/(numPullsArr)) <= epsTarget**2:
            break
        
        t+=1
        if t==iterCount:
            break
       
    return errArr,budgetArr


## Optimism based algorithm
def adaAllocOptimism(A,x,budgetArr,delta,sigmaSq=1):
    n,d=A.shape
    muBase = A.dot(x)
    
    J=np.random.choice(d)
    muEst = d*A[:,J]*x[J] ## Initialize
    numPullsArr = np.ones(n)
    errArr = np.zeros(len(budgetArr))
    outputPullsArr = np.zeros((len(budgetArr),n))
    budgetArrCtr = 0
    
    cDelta = np.sqrt(sigmaSq*np.log(1.0/delta)) ## modified confidence intervals
    for t in range(n,budgetArr[-1]+1):
        if numPullsArr.sum() >= budgetArr[budgetArrCtr] or np.all(numPullsArr>d):
            errArr[budgetArrCtr] = np.abs(f(muEst) - np.sum((numPullsArr<=d)/numPullsArr) - f(muBase))
            outputPullsArr[budgetArrCtr] = np.copy(numPullsArr)
            budgetArrCtr+=1
            if np.all(numPullsArr>d):
                break
        optimisticG= np.abs(muEst)+cDelta*numPullsArr**(-1/2)
        V = (numPullsArr<=d)*optimisticG / numPullsArr
        toPull = np.argmax(V)
        
        if numPullsArr[toPull]==d: ## exact computation
            numPullsArr[toPull]+=d
            muEst[toPull] = A[toPull].dot(x)
            continue
            
        J=np.random.choice(d)
        sample = d*A[toPull,J]*x[J]
        muEst[toPull] = (muEst[toPull] * numPullsArr[toPull] + sample)/(numPullsArr[toPull]+1)
        numPullsArr[toPull]+=1
    return errArr,outputPullsArr
        
def runSimAdaOptimism(args):
    os.environ["MKL_NUM_THREADS"] = "1" 
    os.environ["NUMEXPR_NUM_THREADS"] = "1" 
    os.environ["OMP_NUM_THREADS"] = "1"
    
    (i,A,x,budgetArr,delta) = args
    
    if os.path.isfile("{}/adaOpt_sim{}.pkl".format(baseDir,i)):
        print("already ran file {}/adaOpt_sim{}.pkl".format(baseDir,i))
        return
    
    np.random.seed(i)
    start=time.time()
    errorArr,numPullsArr = adaAllocOptimism(A,x,budgetArr,delta)
    end=time.time()
    
    with open(r"{}/adaOpt_sim{}.pkl".format(baseDir,i), "wb" ) as writeFile:
        pickle.dump({"errorArr":errorArr,"numPullsArr":numPullsArr,"time":end-start}, writeFile )
    



delta = .01
numTrials = 100
num_jobs = 50

baseDir = "pkls/Ax_n100_d100k_pareto"
if not os.path.isdir(baseDir):
    os.mkdir(baseDir)
n=100
d=100000
budgetArr = np.round(np.logspace(np.log2(n),np.log2(2*n*d),num=20,base=2)).astype(int)
print("runing {}, {}, for {}".format(n,d,baseDir))
np.random.seed(2) 

muBase = np.random.pareto(.5,size=n)
muBase/=np.max(muBase)/20
x = np.random.uniform(low=.5,size=d)
A = np.outer(muBase, x/np.linalg.norm(x,2)**2)
A += np.random.normal(size=(n,d))/d
A = A -np.outer(A.dot(x)-muBase,np.ones(d))/x.sum()

# print(np.std(d*A*x,axis=1).mean(),np.std(d*A*x,axis=1).max())

with open(r"{}/info.pkl".format(baseDir), "wb" ) as writeFile:
        pickle.dump({"A":A,"x":x,"budgets":budgetArr,"numTrials":numTrials}, writeFile )


pool      = mp.Pool(processes=num_jobs)
arg_tuple = itertools.product(list(range(numTrials)),[A],[x],[budgetArr],[delta])
for _ in tqdm(pool.imap_unordered(runSimAdaOptimism, arg_tuple), total=numTrials):
	pass


## Batch simulations for Ax
os.environ["MKL_NUM_THREADS"] = "1" 
os.environ["NUMEXPR_NUM_THREADS"] = "1" 
os.environ["OMP_NUM_THREADS"] = "1"


numTrialsBatch = 1000
numRounds = 17
numRoundsUnif = 18
epsilon=.00001
adaErrorBatch = np.zeros((numTrialsBatch,numRounds))
adaBudgetBatch = np.zeros(adaErrorBatch.shape)
unifErrorBatch = np.zeros((numTrialsBatch,numRoundsUnif))
unifBudgetBatch = np.zeros(unifErrorBatch.shape)

unifTimingArr = np.zeros(numTrialsBatch)
adaTimingArr = np.zeros(numTrialsBatch)

for i in tqdm(range(numTrialsBatch), desc='adaBatch'):
    np.random.seed(i)
    start=time.time()
    estMeans,errArrAda,budgetArrAda,numPullsArrAda = adaBatch(A,x, epsilon,.01,numRounds) #eps,delta,...
    adaErrorBatch[i] = errArrAda
    adaBudgetBatch[i] = budgetArrAda
    adaTimingArr[i] = time.time() - start
    
    
for i in tqdm(range(numTrialsBatch), desc='unifBatch'):
    np.random.seed(i)
    start = time.time()
    errArrUnif,budgetArrUnif = unifBatch(A,x,epsilon,.01,numRoundsUnif) #eps,delta,...
    unifErrorBatch[i] = errArrUnif
    unifBudgetBatch[i] = budgetArrUnif
    unifTimingArr[i] = time.time() - start


with open(r"{}/batchedAlgs.pkl".format(baseDir), "wb" ) as writeFile:
        pickle.dump({"ada":(adaErrorBatch, adaBudgetBatch, adaTimingArr) , "unif":(unifErrorBatch, unifBudgetBatch, unifTimingArr)}, writeFile )