use List::Util qw(max);
           sub uniq { my %seen; grep !$seen{$_}++, @_; }
           #parses input like L1*L2^4 L3  
           my @rows = (); 
           my $input = "\n";
           sub process { 
             my @identified = (); 
             my @firstIdentified = @identified;
             my $changed = true;
             my $first = true;
             my $maxid = 0;
             while ($changed) {
               $changed = 0;
               my @newIdentified = ();
               foreach(@rows) {
                 my @vars = uniq(/L[0-9]+/g);
                 if (@vars == 1) {
                   /L([0-9]+)/g;
                   my $id = $1;
                   #my @matches = uniq( /(?<=L[0-9]\^)([0-9]+)/g);
                   my @matches = uniq( /L[0-9]+\^([0-9]+)/g);
                   @matches = map { s/L[0-9]+//r } @matches;
                   my $exp;
                   if (@matches) { $exp = max(@matches); } else { $exp = 1; }
                   if (!$identified[$id] || $exp < $identified[$id]) {
                     $identified[$id] = $exp;
                     push(@newIdentified, $id);
                     $maxid = $id if $id > $maxid;
                     $changed = 1;
                   }
                 }                 
               }
               if ($changed) {
                 @firstIdentified = @identified if ($first);
                 @newIdentified = uniq(@newIdentified);
                 foreach my $id (@newIdentified) {
                   #print join(" ",@rows);
                    foreach (@rows) { s/L$id(\^[0-9]+)?//g; };
                    #print $id."==>";
                   #print join(" ",@rows);
                 }
                 $first = 0;
               }
             };
             
             print "\\makegraph{";
             while ($input =~ /\[([0-9])+ *, *([0-9])+\]/g ) { print "\\edge{$1}{$2}"; }
             #print $input . "=>" ;
             #for (my $i=1;$i<=$maxid;$i++) { if (@firstIdentified[$i] ) { print ",".$i."(@identified[$i])"; } }
             for (my $i=1;$i<=$maxid;$i++) { 
               if (@firstIdentified[$i]) {
                 print "\\mark"; 
                 if (@firstIdentified[$i] == 1) { print "I"; } else { print "F"; }
                 print "{$i}";
               }
             }
             #for (my $i=1;$i<=$maxid;$i++) { if (@identified[$i] && !@firstIdentified[$i]) { print ",".$i."(@identified[$i])"; } }
             for (my $i=1;$i<=$maxid;$i++) { 
               if (@identified[$i] && !@firstIdentified[$i]) {
                 print "\\markZ{$i}";
               }
              }
             print "} %$input";
           };
           while (<>) { 
           #print $_;
             if ($_ =~ "input") { process(); @rows = (); $input = $_ } 
             else { push @rows, $_ }
           }; process()

