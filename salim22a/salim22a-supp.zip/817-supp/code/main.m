% Matlab code for the paper 
% "An Optimal Algorithm for Strongly Convex Minimization under 
% Affine Constraints".
% All rights reserved, 2021.

% Use: launch main.m.
% Tested in Matlab R2021a.
% Runs in about 75s on a recent Macbook Pro.

function main()
	rng('default');
	d = 1000;
	K = randn(d/4,d);
	[U,S,V]=svd(K);
	s = rand(d/4,1);
	s = s-min(s);
	chi = 100000;
	s = s*((1-1/sqrt(chi))/max(s))+1/sqrt(chi); 
	S(S~=0)= s;
	K = U*S*V';
	W = K'*K;
	l = eig(W);
	l = l(find(l>0.1/chi));
	lambda1 = max(l);
	lambda2 = min(l);
	chi2 = lambda1/lambda2; 
	sel = randperm(d);
	S = 50;
	xsharp = zeros(d,1); xsharp(sel(1:S))=1;
	figure(1)
	stem(xsharp,'filled');
	b = K*xsharp;
	opL = @(x) K*x;
	opLadj = @(y) K'*y;
	x0 = zeros(d,1);
	kappa = 10000;
	e = sqrt(1/(kappa-1));
	%F=sqrt(x^2+e^2)+(e/2)x^2
	gradF = @(x) x./sqrt(x.^2+e^2)+e*x;
	L = 1/e+e;
	mu = e;
	kappa2 = L/mu;
	fprintf('chi: %f, kappa: %f\n',chi2,kappa2);
	load('xstar1.mat');
	x = algo(x0,lambda1,lambda2,opL,opLadj,b,gradF,L,mu,4000,xstar);
	chi = lambda1/lambda2;
	N = ceil(sqrt(chi));
	x = PAPC(x0,lambda1,lambda2,opL,opLadj,b,gradF,L,mu,4000*N,xstar);
	% to compute xstar, uncomment the 2 following lines and 
	% use chi = 100000, kappa = 10000, nbiter = 10000
	%xstar = x;
	%save('xstar1.mat','xstar');
	figure(2)
	stem(x,'filled');
end


function x = algo(x0,lambda1,lambda2,opL,opLadj,b,gradF,L,mu,nbiter,xstar)
	chi = lambda1/lambda2;
	c1 = (sqrt(chi)-1)/(sqrt(chi)+1);
	N = ceil(sqrt(chi));
	fprintf('N: %d\n',N);
	kappa = L/mu;
	tau = min(1,(1+c1^N)/(2*sqrt(kappa)*(1-c1^N)));
	eta = 1/(4*tau*L);
	theta = (1+c1^(2*N))/eta/(1+c1^N)^2;
	c = 1/(1+eta*mu);
	x = x0;
	xf = x;
	u = x0*0;
	errortab = zeros(nbiter+1,1);
	errortab(1)=norm(x-xstar)^2;
	for k=1:nbiter
		xg = tau*x + (1-tau)*xf;
		x2 = c*(x-eta*(gradF(xg)-mu*xg+u));
		xc = Chebyshev(x2,lambda1,lambda2,opL,opLadj,b,N);
		r = theta*(x2-xc);
		u = u+r;
		xnew = x2 - (eta*c)*r;
		xf = xg + (2*tau/(2-tau))*(xnew-x);
		x = xnew;
		errortab(k+1)=norm(x-xstar)^2;
	end
	figure(5)
	hold off
	semilogy(0:N:(length(errortab)-1)*N,errortab,'LineWidth',2);
	%xlim([0,nbiter]);
	grid on;
	%ylim([1e-14,100])
	figure(6)
	hold off
	semilogy(0:nbiter,errortab,'LineWidth',2);
	xlim([0,nbiter]);
	grid on;
end



%N>=1, lambda1>0, lambda2>0, lambda2<=lambda1, b\in range(opL)
function z = Chebyshev(z0,lambda1,lambda2,opL,opLadj,b,N)
	c = (lambda1-lambda2)/2; alpha=(lambda1+lambda2)/2;
	p = -opLadj(opL(z0)-b)/alpha;
	z = z0 + p;
	if N==1, return; end
	beta = -c^2/(2*alpha);
	gamma = -(alpha+beta);
	p = (opLadj(opL(z)-b)+beta*p)/gamma;
	z = z + p;
	for i=2:(N-1)
		beta = (c/2)^2/gamma;
		gamma = -(alpha+beta);
		p = (opLadj(opL(z)-b)+beta*p)/gamma;
		z = z + p;
	end
end



function x = PAPC(x0,lambda1,lambda2,opL,opLadj,b,gradF,L,mu,nbiter,xstar)
	chi = lambda1/lambda2;
	N = ceil(sqrt(chi)); %just used for the plot
	v = x0*0;
	x = x0;
	gamma = 2/(L+mu);
	sigma = 1/gamma/lambda1;
	errortab = zeros(nbiter+1,1);
	errortab(1)=norm(x-xstar)^2;
	for k=1:nbiter
		x = x - gamma*(gradF(x) + v);
		r = sigma*opLadj(opL(x)-b);
		v = v + r;
		x = x - gamma*r;
		errortab(k+1)=norm(x-xstar)^2;
	end	
	figure(5)
	hold on
	semilogy(0:nbiter,errortab,'r','LineWidth',2);
	legend('proposed Algorithm 1','PAPC algorithm');
	xlim([0, nbiter])
	ylim([1e-25,100]);
	yticks([1e-25 1e-20 1e-15 1e-10 1e-5 1]);
	figure(6)
	hold on
	errortab2 = errortab(1:N:end);
	semilogy(0:nbiter,errortab,'r','LineWidth',2);
	legend('proposed Algorithm 1','PAPC algorithm')
	ylim([1e-25,100]);
	yticks([1e-25 1e-20 1e-15 1e-10 1e-5 1]);
end


