import torch.nn as nn
import torch.nn.functional as F


class FullyConnectedLayer(nn.Module):

    def __init__(self, input_dims, hidden_dims, num_layers):
        super(FullyConnectedLayer, self).__init__()

        self.fc_in = nn.Linear(input_dims, hidden_dims)
        self.fc_layers = nn.ModuleList([nn.Linear(hidden_dims, hidden_dims) for _ in range(num_layers-1)])
        self.fc_out = nn.Linear(hidden_dims, input_dims*2)

    def forward(self, x):
        x = self.fc_in(x)
        x = F.leaky_relu(x)

        for fc in self.fc_layers:
            x = fc(x)
            x = F.leaky_relu(x)

        x = self.fc_out(x)

        return x