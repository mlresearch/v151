import os
import sys
father_dir = os.path.join('/',  *os.path.realpath(__file__).split(os.path.sep)[:-2])
#print(father_dir)
if not father_dir in sys.path:
    sys.path.append(father_dir)
from utils.misc import torch_accuracy, AvgMeter
from collections import OrderedDict
import torch
from tqdm import tqdm
import torch.nn.functional as F

def train_one_epoch(net, batch_generator, optimizer,
                    criterion, DEVICE=torch.device('cuda:0'),
                    descrip_str='Training', AttackMethod = None, adv_coef = 1.0):
    '''

    :param attack_freq:  Frequencies of training with adversarial examples. -1 indicates natural training
    :param AttackMethod: the attack method, None represents natural training
    :return:  None    #(clean_acc, adv_acc)
    '''
    net.train()
    pbar = tqdm(batch_generator)
    advacc = -1
    advloss = -1
    cleanacc = -1
    cleanloss = -1
    pbar.set_description(descrip_str)
    for i, (data, label) in enumerate(pbar):
        data = data.to(DEVICE)
        label = label.to(DEVICE)

        optimizer.zero_grad()

        pbar_dic = OrderedDict()
        TotalLoss = 0

        if AttackMethod is not None:
            adv_inp = AttackMethod.attack(net, data, label)
            optimizer.zero_grad()
            net.train()
            pred = net(adv_inp)
            loss = criterion(pred, label)

            acc = torch_accuracy(pred, label, (1,))
            advacc = acc[0].item()
            advloss = loss.item()
            #TotalLoss = TotalLoss + loss * adv_coef
            (loss * adv_coef).backward()


        pred = net(data)

        loss = criterion(pred, label)
        #TotalLoss = TotalLoss + loss
        loss.backward()
        #TotalLoss.backward()
        #param = next(net.parameters())
        #grad_mean = torch.mean(param.grad)

        optimizer.step()
        acc = torch_accuracy(pred, label, (1,))
        cleanacc = acc[0].item()
        cleanloss = loss.item()
        #pbar_dic['grad'] = '{}'.format(grad_mean)
        pbar_dic['Acc'] = '{:.4f}'.format(cleanacc)
        pbar_dic['loss'] = '{:.4f}'.format(cleanloss)
        pbar_dic['AdvAcc'] = '{:.4f}'.format(advacc)
        pbar_dic['Advloss'] = '{:.4f}'.format(advloss)
        pbar.set_postfix(pbar_dic)


def eval_one_epoch(net, batch_generator,  DEVICE=torch.device('cuda:0'), AttackMethod=None, return_fgsm=False, eps=None, is_last_iteration=False):
    net.eval()
    pbar = tqdm(batch_generator)
    clean_accuracy = AvgMeter()
    pgd_20_test_accuracy = AvgMeter()
    pgd_50_10_test_accuracy = AvgMeter()
    adv_fgsm_accuracy = AvgMeter()

    pbar.set_description('Evaluating')

    for (data, label) in pbar:
        data = data.to(DEVICE)
        label = label.to(DEVICE)

        with torch.no_grad():
            pred = net(data)
            acc = torch_accuracy(pred, label, (1,))
            clean_accuracy.update(acc[0].item())

        if AttackMethod is not None:
            adv_inp = AttackMethod.attack(net, data, label, nb_iter=20)

            with torch.no_grad():
                pred = net(adv_inp)
                acc = torch_accuracy(pred, label, (1,))
                pgd_20_test_accuracy.update(acc[0].item())

            if is_last_iteration:
                adv_inp = AttackMethod.attack(net, data, label, n_restarts=10, nb_iter=50)

                with torch.no_grad():
                    pred = net(adv_inp)
                    acc = torch_accuracy(pred, label, (1,))
                    pgd_50_10_test_accuracy.update(acc[0].item())

        pbar_dic = OrderedDict()
        pbar_dic['CleanAcc'] = '{:.4f}'.format(clean_accuracy.mean)
        pbar_dic['AdvAcc'] = '{:.4f}'.format(pgd_20_test_accuracy.mean)

        if return_fgsm is True:
            fgsm_output = net(data + fgsm(net, data, label, eps))
            acc = torch_accuracy(fgsm_output, label, (1,))
            adv_fgsm_accuracy.update(acc[0].item())
        pbar_dic['AdvFGSMAcc'] = '{:.4f}'.format(adv_fgsm_accuracy.mean)

        pbar.set_postfix(pbar_dic)

        pgd_20_test_acc = pgd_20_test_accuracy.mean if AttackMethod is not None else 0
        pgd_50_10_test_acc = pgd_50_10_test_accuracy.mean if is_last_iteration is True else None
    if not return_fgsm:
        return clean_accuracy.mean, pgd_20_test_acc
    else:
        return clean_accuracy.mean, pgd_20_test_acc, pgd_50_10_test_acc, adv_fgsm_accuracy.mean


def fgsm(model, X, y, epsilon, random_start=True):
    
    if random_start:
        delta = torch.zeros_like(X).uniform_(-epsilon, epsilon).cuda().requires_grad_(True)
    else:
        delta = torch.zeros_like(X).cuda().requires_grad_(True)
    
    output = model(X + delta)
    loss = F.cross_entropy(output, y)
    loss.backward()
    delta.data = torch.clamp(X + epsilon * torch.sign(delta.grad), 0, 1) - X
    
    return delta.detach().requires_grad_(True)
    