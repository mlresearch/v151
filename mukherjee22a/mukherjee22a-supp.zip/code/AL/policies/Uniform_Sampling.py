

import sys
sys.path.append("..")

import numpy as np
import cvxpy as cp

from environment.LinBandit_env import LinBandit_env

class Uniform_Sampling(object):
    
    
    
    
    def __init__(self, env):
        '''
        Constructor
        '''
        self.T = env.T
        self.num_trials = env.num_trials
        self.num_dims = env.num_dims
        self.num_arms = env.num_arms
        self.rec = 1 # record err every rec samples
        self.unif_sample_complexity = []
        self.sigma = env.sigma
        self.theta_star = env.theta_star
        self.best_arm = env.best_arm
        self.X = env.X
        self.delta = env.delta
        
        self.u_esterr = np.zeros((self.num_trials, self.T//self.rec))
        self.u_armerr = np.zeros((self.num_trials, self.T//self.rec))
        self.u_T = self.T * np.ones(self.num_trials)
        
        self.env = env
        
        
    def init_Uniform_Sampling(self, env):
        
        self.theta_star = env.theta_star
        self.best_arm = env.best_arm
        self.X = env.X
        
        
        
        #print(delta)
    def stop_or_not(self, design_mat, sum_scaled_arms, rows_of_arms, theta_hat, thresh):
        arms, dims = rows_of_arms.shape
        bestarm = np.argmax(rows_of_arms @ theta_hat)
        onehot_competing = cp.Parameter(arms)
        phi = cp.Variable(dims)
        #print(phi, arms, dims, design_mat, sum_scaled_arms, rows_of_arms, theta_hat, thresh)
        sq_err_obj = cp.quad_form(phi, design_mat) - 2 * sum_scaled_arms @ phi
        phi_has_diff_bestarm = [(onehot_competing@self.X - self.X[bestarm]) @ phi >= 0]
        closest_phi = cp.Problem(
            cp.Minimize(sq_err_obj), constraints=phi_has_diff_bestarm
        )
    
        obj_vals = np.zeros(arms)
        for idx in range(arms):
            onehot_competing.value = np.zeros(arms)
            onehot_competing.value[idx] = 1
            obj_vals[idx] = closest_phi.solve()
    
        # sq_loss_closest_phis = sum_sq_R + obj_vals
        min_loss_1, min_loss_2 = np.sort(obj_vals)[:2]
    
        if min_loss_2 - min_loss_1 > thresh:
            return True, obj_vals
        else:
            return False, obj_vals
    
    
    
    def run_Uniform_Sampling(self):
        
        for tr in range(self.num_trials):
            print(tr, end=' ')
            
            '''
            env = self.env.LinBandit_env1(tr, self.num_dims, self.num_arms)
            self.init_Uniform_Sampling(env)
            '''
            unif_A = np.eye(self.num_dims)
            unif_b = np.zeros(self.num_dims)
        
            np.random.seed(tr)
        
            unif_samples = np.random.choice(self.num_arms, size=self.T)
            unif_R = self.X[unif_samples] @ self.theta_star + self.sigma * np.random.randn(len(unif_samples))
        
            unif_rewards = np.zeros((2, self.num_arms))
            unif_err = np.zeros((2, self.T//self.rec))
            for s in range(len(unif_samples)):
                unif_rewards[0, unif_samples[s]] += unif_R[s]
                unif_rewards[1, unif_samples[s]] += 1
                unif_A += np.outer(self.X[unif_samples[s]], self.X[unif_samples[s]])
                unif_b += unif_R[s] * self.X[unif_samples[s]]
        
                if s % self.rec == 0 and s > 0:
                    # theta_hat = least_sq_theta(unif_rewards, X)[0]
                    theta_hat = np.linalg.solve(unif_A, unif_b)
                    unif_err[0, s//self.rec] = np.linalg.norm(theta_hat - self.theta_star, ord=1)
                    unif_err[1, s//self.rec] = not (self.best_arm == np.argmax(self.X @ theta_hat))
                    
                    if s%20 == 0:
                        #if self.stop_or_not(unif_A, unif_b, self.X, theta_hat, np.log(4 * s**2/self.delta)+ self.num_dims * np.log(3*self.num_dims))[0]:
                        if self.stop_or_not(unif_A, unif_b, self.X, theta_hat, np.log(4 * s**2/self.delta)+ self.num_dims * np.log(12.0/self.env.min_seperation))[0]:
                        #if self.stop_or_not(unif_A, unif_b, self.X, theta_hat, np.log(4 * s**2/self.delta)+ self.num_dims * np.log((12.0*self.num_dims)/self.env.min_seperation))[0]:
                        
                        
                            #print(s)
                            self.u_T[tr] = s
                            break
                
                if s%1000 == 0:
                    print(s)
            
    
            self.u_esterr[tr] = unif_err[0]
            self.u_armerr[tr] = unif_err[1]
            self.unif_sample_complexity.append(unif_samples)
        


