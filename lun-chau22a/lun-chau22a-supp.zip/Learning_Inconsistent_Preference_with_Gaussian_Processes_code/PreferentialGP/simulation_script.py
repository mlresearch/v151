"""
Simulation on Clusters of clusterable items

"""
import numpy as np
import pandas as pd
from sklearn.metrics.pairwise import pairwise_kernels, pairwise_distances


def cycle_simulation(n, p, n_states, noise=0., shift=1, type="linear"):
    """

    Args:
        n: number of items
        p: number of features
        n_states: number of latent states
        noise: an effect to mask away the feature usefulness.
            since r = Xbeta + noise
        shift: the difference in mean for each
        type: linear interaction

    Returns:
        C, X, beta_dict, z
    """
    # Generate features
    mean_vec = np.zeros(p)
    # Generate states and features
    z = np.random.choice(n_states, n)

    num_per_clus = [(z==i).sum() for i in range(n_states)]
    X_per_c = [np.random.multivariate_normal(mean_vec + i*shift, np.eye(p), num_per_clus[i]) for i in range(n_states)]

    X = pd.DataFrame(np.zeros((n, p)))
    for i in range(n_states):
        X.iloc[z==i, :] = X_per_c[i]
    X = np.array(X)

    # Generate Kernel
    gamma_RBF = 1 / np.median(pairwise_distances(X, metric='euclidean') ** 2)
    K = pairwise_kernels(X, metric='rbf', gamma=gamma_RBF)

    # Different ranking type

    if type == "linear":
    # Generate different consideration factors
        ranking_dict = dict()
        for i in range(n_states):
            for j in range(i, n_states):
                beta = np.random.normal(size=p)
                r_ij = X @ beta + noise*np.random.normal(p)
                ranking_dict[(i, j)] = r_ij
                ranking_dict[(j, i)] = r_ij

        C = np.zeros((n, n))
        for i in range(n):
            for j in range(i + 1, n):
                skill_i, skill_j = ranking_dict[(z[i], z[j])][i], ranking_dict[(z[i], z[j])][j]
                if skill_i >= skill_j:
                    C[i, j] = 1
                    C[j, i] = -1
                else:
                    C[i, j] = -1
                    C[j, i] = 1

        return C, X, ranking_dict, z

    elif type == "kernel":
        ranking_dict = dict()
        for i in range(n_states):
            for j in range(i, n_states):
                beta = np.random.normal(size=n)
                r_ij = K @ beta + noise*np.random.normal(size=n)
                ranking_dict[(i, j)] = r_ij
                ranking_dict[(j, i)] = r_ij

        C = np.zeros((n, n))
        for i in range(n):
            for j in range(i + 1, n):
                skill_i, skill_j = ranking_dict[(z[i], z[j])][i], ranking_dict[(z[i], z[j])][j]
                if skill_i >= skill_j:
                    C[i, j] = 1
                    C[j, i] = -1
                else:
                    C[i, j] = -1
                    C[j, i] = 1

        return C, X, ranking_dict, z


def cluster_simulation(n, p, n_clusters, noise=0, shift=1, type="linear", state="random"):
    """

    Args:
        n: number of items
        p: number of parameters
        n_clusters: number of clusters
        noise: dictates how useful the features are
        shift: differences in the mean for the features at each cluster
        type: 'linear' or 'kernel'
        state: random

    Returns:

    """

    # Generate features
    mean_vec = np.zeros(p)
    # Generate states and features
    if state == "random":
        z = np.random.choice(n_clusters, n)
    elif state == "equal":
        remainder = n % n_clusters
        dividen = n // n_clusters
        z = np.array(list(np.repeat([i for i in range(n_clusters)], dividen)) + [n_clusters - 1] * remainder)

    num_per_clus = [(z==i).sum() for i in range(n_clusters)]
    X_per_c = [np.random.multivariate_normal(mean_vec + i*shift, np.eye(p), num_per_clus[i]) for i in range(n_clusters)]

    X = pd.DataFrame(np.zeros((n, p)))
    for i in range(n_clusters):
        X.iloc[z==i, :] = X_per_c[i]
    X = np.array(X)

    # Generate Kernel
    gamma_RBF = 1 / np.median(pairwise_distances(X, metric='euclidean') ** 2)
    K = pairwise_kernels(X, metric='rbf', gamma=gamma_RBF)

    # Generate different consideration factors
    if type == "linear":
        ranking_dict = dict()
        for i in range(n_clusters):
            for j in range(i, n_clusters):
                beta = np.random.normal(size=p)
                r_ij = X @ beta + noise*np.random.normal(p)
                ranking_dict[(i, j)] = r_ij
                ranking_dict[(j, i)] = r_ij

        C = np.zeros((n, n))
        for i in range(n):
            for j in range(i+1, n):
                if z[i] == z[j]:
                    skill_i, skill_j = ranking_dict[(z[i], z[j])][i], ranking_dict[(z[i], z[j])][j]
                    if skill_i >= skill_j:
                        C[i, j] = 1
                        C[j, i] = -1
                    else:
                        C[i, j] = -1
                        C[j, i] = 1
                else:
                    # Random outcome if not in the same clusters
                    C[i, j] = np.random.choice([-1, 1])
                    C[j, i] = -C[i, j]

        return C, X, ranking_dict, z

    elif type == "kernel":
        ranking_dict = dict()
        for i in range(n_clusters):
            for j in range(i, n_clusters):
                beta = np.random.normal(size=n)
                r_ij = K @ beta + noise*np.random.normal(size=n)
                ranking_dict[(i, j)] = r_ij
                ranking_dict[(j, i)] = r_ij

        C = np.zeros((n, n))
        for i in range(n):
            for j in range(i + 1, n):
                if z[i] == z[j]:
                    skill_i, skill_j = ranking_dict[(z[i], z[j])][i], ranking_dict[(z[i], z[j])][j]
                    if skill_i >= skill_j:
                        C[i, j] = 1
                        C[j, i] = -1
                    else:
                        C[i, j] = -1
                        C[j, i] = 1
                else:
                    # Random outcome if not in the same clusters
                    C[i, j] = np.random.choice([-1, 1])
                    C[j, i] = -C[i, j]

        return C, X, ranking_dict, z


def cluster_simulationII_any_cluster(n, n_clusters=2, noise=0, type="linear"):
    """

    The main idea is to generate features that are contains structural information that are agnostic to
    clustering algorithm.

    Args:
        n: Number of items
        n_clusters: Number of clusters
        noise: Noise to the ranking vector
        type: linear or kernelised prediction of the ranking vector

    Returns:

    """

    # Generate cluster bounds
    chg_pt = [i * 2 * np.pi / n_clusters for i in range(n_clusters + 1)]
    range_ls = [np.array([chg_pt[i], chg_pt[i + 1]]) for i in range(n_clusters)]

    # Simulate a circle
    thetas = np.random.uniform(low=0, high=2 * np.pi, size=n)
    r = np.random.uniform(low=0, high=1, size=n)

    x1 = r * np.cos(thetas)
    x2 = r * np.sin(thetas)

    X = np.vstack([x1, x2]).T

    z = []
    for theta in thetas:
        for rng_idx in range(len(range_ls)):
            if theta > range_ls[rng_idx][0] and theta <= range_ls[rng_idx][1]:
                z.append(rng_idx)
                break

    gamma_RBF = 1 / np.median(pairwise_distances(X, metric='euclidean') ** 2)
    K = pairwise_kernels(X, metric='rbf', gamma=gamma_RBF)

    if type == "linear":
        ranking_dict = dict()
        for i in range(n_clusters):
            for j in range(i, n_clusters):
                beta = np.random.normal(size=p)
                r_ij = X @ beta + noise * np.random.normal(p)
                ranking_dict[(i, j)] = r_ij
                ranking_dict[(j, i)] = r_ij

        C = np.zeros((n, n))
        for i in range(n):
            for j in range(i + 1, n):
                if z[i] == z[j]:
                    skill_i, skill_j = ranking_dict[(z[i], z[j])][i], ranking_dict[(z[i], z[j])][j]
                    if skill_i >= skill_j:
                        C[i, j] = 1
                        C[j, i] = -1
                    else:
                        C[i, j] = -1
                        C[j, i] = 1
                else:
                    # Random outcome if not in the same clusters
                    C[i, j] = np.random.choice([-1, 1])
                    C[j, i] = -C[i, j]

        return C, X, ranking_dict, z

    elif type == "kernel":
        ranking_dict = dict()
        for i in range(n_clusters):
            for j in range(i, n_clusters):
                beta = np.random.normal(size=n)
                r_ij = K @ beta + noise * np.random.normal(size=n)
                ranking_dict[(i, j)] = r_ij
                ranking_dict[(j, i)] = r_ij

        C = np.zeros((n, n))
        for i in range(n):
            for j in range(i + 1, n):
                if z[i] == z[j]:
                    skill_i, skill_j = ranking_dict[(z[i], z[j])][i], ranking_dict[(z[i], z[j])][j]
                    if skill_i >= skill_j:
                        C[i, j] = 1
                        C[j, i] = -1
                    else:
                        C[i, j] = -1
                        C[j, i] = 1
                else:
                    # Random outcome if not in the same clusters
                    C[i, j] = np.random.choice([-1, 1])
                    C[j, i] = -C[i, j]

        return C, X, ranking_dict, z


def cluster_simulation_circle_feature(n, n_clusters=2, noise=0, type="linear"):
    """

    Args:
        n: Number of items
        n_clusters: Number of clusters
        noise: Noise to the ranking vector
        type: linear or kernelised prediction of the ranking vector

    Returns:

    """
    # Number of features
    p = 2

    x1 = np.random.uniform(size=n)
    x2 = np.random.uniform(size=n)

    X = np.vstack([x1, x2]).T
    #z = [1 if X[i, 0] > X[i, 1] else 0 for i in range(X.shape[0])]
    z = [1 if X[i, 0] > 0.5 else 0 for i in range(X.shape[0])] # Still in development, only works for 2 clusters now.

    gamma_RBF = 1 / np.median(pairwise_distances(X, metric='euclidean') ** 2)
    K = pairwise_kernels(X, metric='rbf', gamma=gamma_RBF)

    if type == "linear":
        ranking_dict = dict()
        for i in range(n_clusters):
            for j in range(i, n_clusters):
                beta = np.random.normal(size=p)
                r_ij = X @ beta + noise * np.random.normal(p)
                ranking_dict[(i, j)] = r_ij
                ranking_dict[(j, i)] = r_ij

        C = np.zeros((n, n))
        for i in range(n):
            for j in range(i + 1, n):
                if z[i] == z[j]:
                    skill_i, skill_j = ranking_dict[(z[i], z[j])][i], ranking_dict[(z[i], z[j])][j]
                    if skill_i >= skill_j:
                        C[i, j] = 1
                        C[j, i] = -1
                    else:
                        C[i, j] = -1
                        C[j, i] = 1
                else:
                    # Random outcome if not in the same clusters
                    C[i, j] = np.random.choice([-1, 1])
                    C[j, i] = -C[i, j]

        return C, X, ranking_dict, z

    elif type == "kernel":
        ranking_dict = dict()
        for i in range(n_clusters):
            for j in range(i, n_clusters):
                beta = np.random.normal(size=n)
                r_ij = K @ beta + noise * np.random.normal(size=n)
                ranking_dict[(i, j)] = r_ij
                ranking_dict[(j, i)] = r_ij

        C = np.zeros((n, n))
        for i in range(n):
            for j in range(i + 1, n):
                if z[i] == z[j]:
                    skill_i, skill_j = ranking_dict[(z[i], z[j])][i], ranking_dict[(z[i], z[j])][j]
                    if skill_i >= skill_j:
                        C[i, j] = 1
                        C[j, i] = -1
                    else:
                        C[i, j] = -1
                        C[j, i] = 1
                else:
                    # Random outcome if not in the same clusters
                    C[i, j] = np.random.choice([-1, 1])
                    C[j, i] = -C[i, j]

        return C, X, ranking_dict, z



"""
def cycle_simulation(n, p, n_states, shift=1, type="linear"):

    # Generate features
    mean_vec = np.zeros(p)
    # Generate states and features
    z = np.random.choice(n_states, n)

    num_per_clus = [(z==i).sum() for i in range(n_states)]
    X_per_c = [np.random.multivariate_normal(mean_vec + i*shift, np.eye(p), num_per_clus[i]) for i in range(n_states)]

    X = pd.DataFrame(np.zeros((n, p)))
    for i in range(n_states):
        X.iloc[z==i, :] = X_per_c[i]
    X = np.array(X)

    # Generate Kernel
    gamma_RBF = 1 / np.median(pairwise_distances(X, metric='euclidean') ** 2)
    K = pairwise_kernels(X, metric='rbf', gamma=gamma_RBF)

    # Different ranking type

    if type == "linear":
    # Generate different consideration factors
        beta_dict = dict()
        for i in range(n_states):
            for j in range(i, n_states):
                beta = np.random.normal(size=p)
                beta_dict[(i, j)] = beta
                beta_dict[(j, i)] = beta

        C = np.zeros((n, n))
        for i in range(n):
            for j in range(i + 1, n):
                skill_i, skill_j = X[[i, j], :] @ beta_dict[(z[i], z[j])]
                if skill_i >= skill_j:
                    C[i, j] = 1
                    C[j, i] = -1
                else:
                    C[i, j] = -1
                    C[j, i] = 1

        return C, X, beta_dict, z

    elif type == "kernel":
        beta_dict = dict()
        for i in range(n_states):
            for j in range(i, n_states):
                beta = np.random.normal(size=n)
                beta_dict[(i, j)] = beta
                beta_dict[(j, i)] = beta

        C = np.zeros((n, n))
        for i in range(n):
            for j in range(i + 1, n):
                skill_i, skill_j = K[[i, j], :] @ beta_dict[(z[i], z[j])]
                if skill_i >= skill_j:
                    C[i, j] = 1
                    C[j, i] = -1
                else:
                    C[i, j] = -1
                    C[j, i] = 1

        return C, X, beta_dict, z


def cluster_simulation(n, p, n_clusters, shift=1, type="linear", state="random"):


    # Generate features
    mean_vec = np.zeros(p)
    # Generate states and features
    if state == "random":
        z = np.random.choice(n_clusters, n)
    elif state == "equal":
        remainder = n % n_clusters
        dividen = n // n_clusters
        z = np.array(list(np.repeat([i for i in range(n_clusters)], dividen)) + [n_clusters - 1] * remainder)

    num_per_clus = [(z==i).sum() for i in range(n_clusters)]
    X_per_c = [np.random.multivariate_normal(mean_vec + i*shift, np.eye(p), num_per_clus[i]) for i in range(n_clusters)]

    X = pd.DataFrame(np.zeros((n, p)))
    for i in range(n_clusters):
        X.iloc[z==i, :] = X_per_c[i]
    X = np.array(X)

    # Generate Kernel
    gamma_RBF = 1 / np.median(pairwise_distances(X, metric='euclidean') ** 2)
    K = pairwise_kernels(X, metric='rbf', gamma=gamma_RBF)

    # Generate different consideration factors
    if type == "linear":
        beta_dict = dict()
        for i in range(n_clusters):
            for j in range(i, n_clusters):
                beta = np.random.normal(size=p)
                beta_dict[(i, j)] = beta
                beta_dict[(j, i)] = beta

        C = np.zeros((n, n))
        for i in range(n):
            for j in range(i+1, n):
                if z[i] == z[j]:
                    skill_i, skill_j = X[[i, j], :] @ beta_dict[(z[i], z[j])]
                    if skill_i >= skill_j:
                        C[i, j] = 1
                        C[j, i] = -1
                    else:
                        C[i, j] = -1
                        C[j, i] = 1
                else:
                    # Random outcome if not in the same clusters
                    C[i, j] = np.random.choice([-1, 1])
                    C[j, i] = -C[i, j]

        return C, X, beta_dict, z

    elif type == "kernel":
        beta_dict = dict()
        for i in range(n_clusters):
            for j in range(i, n_clusters):
                beta = np.random.normal(size=n) # kernelised
                beta_dict[(i, j)] = beta
                beta_dict[(j, i)] = beta

        C = np.zeros((n, n))
        for i in range(n):
            for j in range(i + 1, n):
                if z[i] == z[j]:
                    skill_i, skill_j = K[[i, j], :] @ beta_dict[(z[i], z[j])]
                    if skill_i >= skill_j:
                        C[i, j] = 1
                        C[j, i] = -1
                    else:
                        C[i, j] = -1
                        C[j, i] = 1
                else:
                    # Random outcome if not in the same clusters
                    C[i, j] = np.random.choice([-1, 1])
                    C[j, i] = -C[i, j]

        return C, X, beta_dict, z
        
"""