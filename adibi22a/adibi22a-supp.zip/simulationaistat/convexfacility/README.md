
> ?A  README.md for code accompanying a Minimax Optimization:The Case of Convex-Submodular paper

# Minimax Optimization:The Case of Convex-Submodular
synthetic data application


## Requirements
The main code file synteticdata.py can be run in python.


## Results
we include all the results in paper.
