import gc
import os
import json
import torch
import pickle
import random
import logging
import argparse
import statistics
import numpy as np
import torch.multiprocessing as mp

from task.task_wrapper import TaskWrapper
from utils.tensorboard import Tensorboard
from learner.nce_training import NCEKLossArticle
from setup_validator.core_validator import validate
from utils.multiprocess_logger import MultiprocessingLoggerManager


def main():

    parser = argparse.ArgumentParser()
    parser.add_argument("--task", default='wiki-3029', help="name of the task e.g., agnews, dbpedia, wiki-3029")
    parser.add_argument("--name", default="nce-training", help="Name of the experiment")
    parser.add_argument("--num_classes", default=-1, type=int, help="Number of classes to select (if set to -1 then "
                                                                    "use all classes in the dataset)")
    parser.add_argument("--k", default=-1, type=int, help="Number of negative samples")
    parser.add_argument("--lr", default=-1, type=float, help="Learning rate")
    parser.add_argument("--hidden_dim", default=-1, type=int, help="Hidden dimension")
    parser.add_argument("--output_dim", default=-1, type=int, help="Output GRU dimension")
    parser.add_argument("--dropout", default=-1, type=float, help="Dropout probability")
    parser.add_argument("--batch_size", default=-1, type=int,
                        help="Batch size (also controls negative examples for log_loss_batch case)")
    parser.add_argument("--seed", default=-1, type=int, help="Experiment seed")
    parser.add_argument("--model", default=None, type=str, help="Model name")
    parser.add_argument("--loss", default="margin", type=str, help="Type of loss (log_loss, log_loss_batch, margin)")
    parser.add_argument("--sample_size", default=-1, type=int, help="Samples for training")
    parser.add_argument("--no_collision", default=-1, type=int, help="Remove collision if set to 1")
    parser.add_argument("--forced_diversity", default=-1, type=int, help="Forced diversity if set to 1")
    parser.add_argument("--add_collision", default=0, type=int, help="A number between 0 and k, "
                                                                     "which will necessarily consist of members "
                                                                     "from anchor class")
    parser.add_argument("--temperature", default=-1, type=float, help="Temperature for softmax")
    parser.add_argument("--eval_sample_size", default=-1, type=int, help="Samples for evaluating")
    parser.add_argument("--save_path", default="./results/", type=str, help="Folder where to save results")
    parser.add_argument("--data_path", default="./cache", type=str, help="Folder where cached data is saved")
    parser.add_argument("--debug", default="False", help="Debug the run")
    parser.add_argument("--pushover", default="False", help="Use pushover to send results on phone")
    args = parser.parse_args()

    task_name = args.task

    exp_name = args.name
    experiment_name = "nce-%s-%s-classes-%d-k-%d-add_coll-%d-no_coll-%d-for_div-%d-%s-seed-%d" % \
                      (exp_name, task_name, args.num_classes, args.k, args.add_collision,
                       args.no_collision, args.forced_diversity, args.loss, args.seed)
    experiment = "%s/%s" % (args.save_path, experiment_name)

    # Create the experiment folder
    if not os.path.exists(experiment):
        os.makedirs(experiment)

    # Define log settings
    log_path = experiment + '/train_nce.log'
    multiprocess_logging_manager = MultiprocessingLoggerManager(
        file_path=log_path, logging_level=logging.INFO)
    master_logger = multiprocess_logging_manager.get_logger("Master")
    master_logger.log("----------------------------------------------------------------")
    master_logger.log("                    STARING NEW EXPERIMENT                      ")
    master_logger.log("----------------------------------------------------------------")
    master_logger.log("Environment Name %r. Experiment Name %r" % (task_name, exp_name))

    # Read configuration and constant files. Configuration contain environment information and
    # constant file contains hyperparameters for the model and learning algorithm.
    # Add command line arguments. Command line arguments supersede file settings.
    with open("data/%s/config.json" % task_name) as f:
        config = json.load(f)

        config["num_classes"] = args.num_classes
        config["data_path"] = args.data_path
        config["no_collision"] = (args.no_collision > 0)
        config["forced_diversity"] = (args.forced_diversity > 0)
        master_logger.log("Disable collision %r" % config["no_collision"])

        assert 0 <= args.add_collision <= args.k, "add_collision value should be between 0 and k=%d, found=%d" % \
                                                  (args.k, args.add_collision)

        config["add_collision"] = args.add_collision
        if args.add_collision > 0 and config["no_collision"]:
            master_logger.log("As no_collision is set and add_collision is > 0, we force add_collision samples out of k"
                              "to be from the same class and ensure 0 collision for the remaining negative samples.")

        if args.add_collision > 0 and config["forced_diversity"]:
            master_logger.log("As no_collision is set and forced_diversity is > 0, we force add_collision samples "
                              "out of k, and ensure remaining samples are balanced from other classes")

        config["save_path"] = experiment
        config["exp_name"] = experiment_name

    with open("data/%s/constants.json" % task_name) as f:
        constants = json.load(f)

        constants["loss"] = args.loss

        if args.sample_size != -1:
            constants["sample_size"] = args.sample_size

        if args.lr != -1:
            constants["lr"] = args.lr

        if args.output_dim != -1:
            constants["output_dim"] = args.output_dim

        if args.dropout != -1:
            constants["dropout"] = args.dropout

        if args.model is not None:
            constants["nce_model"] = args.model

        if args.temperature != -1:
            constants["temperature"] = args.temperature

        if args.batch_size != -1:
            constants["batch_size"] = args.batch_size

        if args.eval_sample_size != -1:
            constants["eval_sample_size"] = args.eval_sample_size

        if args.hidden_dim != -1:
            constants["n_hidden"] = args.hidden_dim

        if args.loss == "log_loss_batch":
            if args.k > 2 * (constants["batch_size"] - 1):
                master_logger.log("Cannot support larger value of k=%d larger than=%d (2 * batch size - 2) "
                                  "in for log_loss_batch" % (args.k, 2 * (constants["batch_size"] - 1)))
                exit(0)

    print(json.dumps(config, indent=2))

    # Validate the keys
    validate(config, constants)

    # log core experiment details
    master_logger.log("CONFIG DETAILS")
    for k, v in sorted(config.items()):
        master_logger.log("    %s --- %r" % (k, v))
    master_logger.log("CONSTANTS DETAILS")
    for k, v in sorted(constants.items()):
        master_logger.log("    %s --- %r" % (k, v))
    master_logger.log("START SCRIPT CONTENTS")
    with open(__file__) as f:
        for line in f.readlines():
            master_logger.log(">>> " + line.strip())
    master_logger.log("END SCRIPT CONTENTS")

    if args.seed == -1:
        seeds = [1234, 1235, 1236, 1237, 1238, 1239, 1240, 1241, 1242, 1243]
    else:
        seeds = [args.seed]
    num_runs = len(seeds)
    performance = []

    for trial in range(1, num_runs + 1):

        # Set the random seed
        seed = seeds[trial - 1]
        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)

        config["seed"] = seed

        master_logger.log("========= STARTING EXPERIMENT %d with seed %d ======== " % (trial, seed))

        # Create a new environment with the new seed
        task = TaskWrapper.make_task(config, task_name, master_logger)
        master_logger.log("Task Named %s Created. Number of classes %d" % (task_name, task.get_num_class()))

        tensorboard = Tensorboard(experiment)
        learning_alg = NCEKLossArticle(config, constants)
        # learning_alg = NCEKLossArticleSeqData(config, constants)

        result = learning_alg.train_fixed_epoch(task=task,
                                                k=args.k,
                                                logger=master_logger,
                                                tensorboard=tensorboard)

        for k, v in config.items():
            result["config/%s" % k] = v

        for k, v in constants.items():
            result["constants/%s" % k] = v

        for k, v in args.__dict__.items():
            result["args/%s" % k] = v

        performance.append(result)
        gc.collect()

    # Save performance
    with open("%s/results.pickle" % experiment, "wb") as f:
        pickle.dump(performance, f)

    for key in sorted(performance[0]):  # Assumes the keys are same across all runs

        if key.startswith("config/") or key.startswith("constants/") or key.startswith("args/"):
            continue

        if not isinstance(performance[0][key], int) and not isinstance(performance[0][key], float):
            continue

        results = [result[key] for result in performance]

        stdev = 0.0 if len(results) <= 1 else statistics.stdev(results)
        master_logger.log("%r: Mean %.2f, Median %.2f, Std %.2f, Num runs %d, All performance %r" %
                          (key, statistics.mean(results), statistics.median(results), stdev,
                           num_runs, results))
        print("%r: Mean %.2f, Median %.2f, Std %.2f, Num runs %d, All performance %r" %
              (key, statistics.mean(results), statistics.median(results), stdev, num_runs, results))

    # Cleanup
    multiprocess_logging_manager.cleanup()


if __name__ == "__main__":

    print("SETTING THE START METHOD ")
    mp.freeze_support()
    mp.set_start_method('spawn')
    main()
