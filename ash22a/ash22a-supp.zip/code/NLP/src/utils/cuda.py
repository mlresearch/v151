import torch
from torch.autograd import Variable


def cuda_tensor(t, device):
    if torch.cuda.is_available():
        return t.cuda(device=device)
    else:
        return t


def cuda_var(t, volatile=False, requires_grad=False, device=None):
    """ Create PyTorch variable that will be located on GPU at the given device.
        Volatile and requires_grad parameter will be set as given. """

    return Variable(cuda_tensor(t, device), volatile=volatile, requires_grad=requires_grad)


def make_var(t, cuda, volatile=False, requires_grad=False, device=None):
    """ Create PyTorch variable with right parameters """

    if cuda:
        # Use CUDA
        return cuda_var(t, volatile, requires_grad, device)

    else:
        # Do not use CUDA
        return Variable(t, volatile=volatile, requires_grad=requires_grad)
