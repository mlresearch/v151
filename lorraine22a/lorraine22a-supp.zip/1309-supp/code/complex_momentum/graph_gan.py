import pickle
import matplotlib.pyplot as plt
import numpy as np
import os

loc = './saves/'
arg_loc = '2020-03-05-spirals-zdim:4-loss:standard-c:0/'
save_im_loc = 'eig_images'
save_gif_loc = 'eig_gifs'


def save_ims(load_indices, num_bins=100, num_bins_1d=50, num_eigvec_plot=2):
    # save_data = {'iter': [], 'eigs': [], 'eig_vecs': [], 'grad': [], 'hess':[], 'num_G': [], 'num_D': []}
    try:
        os.makedirs(loc + arg_loc + save_im_loc)
    except FileExistsError:  # directory already exists
        pass

    # Do an initial pass to get the scales
    min_mag, max_mag = 1e16, -1e16
    min_phase, max_phase = 1e16, -1e16
    min_mag_phase_density, max_mag_phase_density = 1e16, -1e16
    min_mag_phase_density_grad_decomp, max_mag_phase_density_grad_decomp = 1e16, -1e16
    min_re, max_re = 1e16, -1e16
    min_im, max_im = 1e16, -1e16
    min_re_im_density, max_re_im_density = 1e16, -1e16
    min_re_im_density_grad_decomp, max_re_im_density_grad_decomp = 1e16, -1e16
    min_hessian_scale, max_hessian_scale = 1e16, -1e16
    min_mag_density, max_mag_density = 1e16, -1e16
    min_phase_energy_density, max_phase_energy_density = 1e16, -1e16
    min_player_proportion_density, max_player_proportion_density = 1e16, -1e16
    min_eigvec_comp_density, max_eigvec_comp_density = 1e16, -1e16
    for ind in load_indices:

        with open(loc + arg_loc + f'eig_info_{ind}.pickle', 'rb') as handle:
            save_data = pickle.load(handle)
        temp_ind = 0
        iter = save_data['iter'][temp_ind]
        print(f"Prepping iteration {iter}")
        eigs = save_data['eigs'][temp_ind]
        eig_vecs = save_data['eig_vecs'][temp_ind]
        grad = save_data['grad'][temp_ind]
        hess = save_data['hess'][temp_ind]
        num_D = save_data['num_D'][temp_ind]
        num_G = save_data['num_G'][temp_ind]
        grad_G = np.copy(grad)
        grad_G[:num_D] = 0
        grad_D = np.copy(grad)
        grad_D[-num_G:] = 0

        log_shift_eigs = np.log10(np.abs(eigs) + 1e-14)

        complex_eigs = np.array([eig[0] + eig[1] * 1j for eig in eigs])
        polar_eigs = np.copy(eigs)
        polar_eigs[:, 0] = np.sqrt(eigs[:, 0] ** 2 + eigs[:, 1] ** 2)
        polar_eigs[:, 1] = np.angle(complex_eigs)

        hess = np.abs(hess)
        hess = hess + 1e-12
        hess = np.log10(hess)

        mixing_coefficients = np.abs(np.linalg.solve(eig_vecs, grad))

        prop_Ds = np.zeros(len(eigs))
        for i in range(len(eigs)):
            eig_vec = np.abs(eig_vecs[i])
            normalizer = np.sum(eig_vec)
            prop_Ds[i] = np.sum(eig_vec[:num_D]) / normalizer

        # TODO: only take log10 of polar eigs once?

        fig = plt.figure()
        mag_phase_h, _, _, out_im_mag = plt.hist2d(np.log10(polar_eigs[:, 0]), polar_eigs[:, 1], bins=num_bins)
        plt.close(fig)

        fig = plt.figure()
        mag_phase_grad_decomp_h, _, _, out_im_mag_mix = plt.hist2d(np.log10(polar_eigs[:, 0]), polar_eigs[:, 1], weights=mixing_coefficients,
                                             bins=num_bins)
        plt.close(fig)

        fig = plt.figure()
        im_re_h, _, _, out_im_re = plt.hist2d(log_shift_eigs[:, 0], log_shift_eigs[:, 1], bins=num_bins)
        plt.close(fig)

        fig = plt.figure()
        im_re_grad_decomp_h, _, _, out_im_re_mix = plt.hist2d(log_shift_eigs[:, 0], log_shift_eigs[:, 1], weights=mixing_coefficients,
                                            bins=num_bins)
        plt.close(fig)

        fig = plt.figure()
        n_mag_distribution, _, _ = plt.hist(np.log10(polar_eigs[:, 0]), bins=num_bins_1d)
        plt.close(fig)

        fig = plt.figure()
        n_phase_energy_distribution_1, _, _ = plt.hist(polar_eigs[:, 1], weights=polar_eigs[:, 0], bins=num_bins_1d, alpha=.5, density=True)
        n_phase_energy_distribution_2, _, _ = plt.hist(polar_eigs[:, 1], bins=num_bins_1d, alpha=.5, density=True)
        plt.close(fig)

        fig = plt.figure()
        n_prop_density, _, _ = plt.hist(prop_Ds, bins=num_bins_1d, alpha=.5, density=True)
        plt.close(fig)

        fig = plt.figure()
        np.random.seed(0)
        randints = np.random.randint(0, len(eigs), size=5)
        for i in randints[:num_eigvec_plot]:
            eig_vec = eig_vecs[i]
            graphable_vec = np.array([[key, np.abs(val)] for key, val in enumerate(eig_vec)])
            n_comp_density, _, _ = plt.hist(graphable_vec[:, 0], weights=graphable_vec[:, 1], bins=num_bins_1d)
            min_eigvec_comp_density, max_eigvec_comp_density = np.minimum(min_eigvec_comp_density, np.min(n_comp_density)), np.maximum(max_eigvec_comp_density, np.max(n_comp_density))
        plt.close(fig)

        min_mag, max_mag = np.minimum(min_mag, np.min(polar_eigs[:, 0])), np.maximum(max_mag, np.max(polar_eigs[:, 0]))
        min_phase, max_phase = np.minimum(min_phase, np.min(polar_eigs[:, 1])), np.maximum(max_phase,
                                                                                           np.max(polar_eigs[:, 1]))
        min_mag_phase_density, max_mag_phase_density = np.minimum(min_mag_phase_density,
                                                                  np.min(mag_phase_h)), np.maximum(
            max_mag_phase_density, np.max(mag_phase_h))
        min_re, max_re = np.minimum(min_re, np.min(log_shift_eigs[:, 0])), np.maximum(max_re,
                                                                                      np.max(log_shift_eigs[:, 0]))
        min_im, max_im = np.minimum(min_im, np.min(log_shift_eigs[:, 1])), np.maximum(max_im,
                                                                                      np.max(log_shift_eigs[:, 1]))
        min_re_im_density, max_re_im_density = np.minimum(min_re_im_density, np.min(im_re_h)), np.maximum(
            max_re_im_density, np.max(im_re_h))
        min_hessian_scale, max_hessian_scale = np.minimum(min_hessian_scale, np.min(hess)), np.maximum(
            max_hessian_scale, np.max(hess))

        min_mag_density, max_mag_density = np.minimum(min_mag_density, np.min(n_mag_distribution)), np.maximum(max_mag_density, np.max(n_mag_distribution))

        min_phase_energy_density, max_phase_energy_density = np.minimum(min_phase_energy_density, np.min(n_phase_energy_distribution_1)), np.maximum(max_phase_energy_density, np.max(n_phase_energy_distribution_1))

        min_mag_phase_density_grad_decomp, max_mag_phase_density_grad_decomp = np.minimum(min_mag_phase_density_grad_decomp, np.min(mag_phase_grad_decomp_h)), np.maximum(max_mag_phase_density_grad_decomp, np.max(mag_phase_grad_decomp_h))

        min_re_im_density_grad_decomp, max_re_im_density_grad_decomp = np.minimum(min_re_im_density_grad_decomp, np.min(im_re_grad_decomp_h)), np.maximum(max_re_im_density_grad_decomp, np.max(im_re_grad_decomp_h))

        min_player_proportion_density, max_player_proportion_density = np.minimum(min_player_proportion_density, np.min(n_prop_density)), np.maximum(max_player_proportion_density, np.max(n_prop_density))



        # TODO: Add density for histograms?
    range_re_im = [[min_re, max_re], [min_im, max_im]]
    range_mag_phase = [[np.log10(min_mag), np.log10(max_mag)], [min_phase, max_phase]]

    iters = []
    total_energies, complex_energies, real_energies = [], [], []
    joint_norms, D_norms, G_norms, newton_norms = [], [], [], []
    for ind in load_indices:
        with open(loc + arg_loc + f'eig_info_{ind}.pickle', 'rb') as handle:
            save_data = pickle.load(handle)

        temp_ind = 0
        iter = save_data['iter'][temp_ind]
        iters += [iter]
        eigs = save_data['eigs'][temp_ind]
        eig_vecs = save_data['eig_vecs'][temp_ind]
        grad = save_data['grad'][temp_ind]
        hess = save_data['hess'][temp_ind]
        num_D = save_data['num_D'][temp_ind]
        num_G = save_data['num_G'][temp_ind]
        grad_G = np.copy(grad)
        grad_G[:num_D] = 0
        grad_D = np.copy(grad)
        grad_D[-num_G:] = 0

        print(f"Doing graphs for iteration {iter}")

        cmap = plt.cm.jet

        # GRAPH THE EIGENVALUE DISTRIBUTION
        log_shift_eigs = np.log10(np.abs(eigs) + 1e-14)

        complex_eigs = np.array([eig[0] + eig[1] * 1j for eig in eigs])
        polar_eigs = np.copy(eigs)
        polar_eigs[:, 0] = np.sqrt(eigs[:, 0] ** 2 + eigs[:, 1] ** 2)
        polar_eigs[:, 1] = np.angle(complex_eigs)

        hess = np.abs(hess)
        hess = hess + 1e-12
        hess = np.log10(hess)

        fig = plt.figure()

        _, _, _, out_im_re = plt.hist2d(log_shift_eigs[:, 0], log_shift_eigs[:, 1], bins=num_bins,
                                        range=range_re_im, cmap=cmap, vmin=min_re_im_density, vmax=max_re_im_density)
        cbar = fig.colorbar(out_im_re)
        cbar.ax.set_ylabel('# of Eigs', rotation=270)
        plt.title(f"Iter {iter}: Eig $\lambda$ (log) Re / (log) Im Dist")
        plt.xlabel("$\log(|\Re(\lambda)| + c)$"), plt.ylabel("$\log(|\Im(\lambda)| + c)$")
        plt.tight_layout()
        plt.savefig(loc + arg_loc + save_im_loc + f'/eig_re_im_distribution_{iter}', bbox_inches='tight', pad_inches=0)
        plt.close(fig)

        fig = plt.figure()
        _, _, _, out_im_mag = plt.hist2d(np.log10(polar_eigs[:, 0]), polar_eigs[:, 1], bins=num_bins, cmap=cmap,
                                         range=range_mag_phase, vmin=min_mag_phase_density, vmax=max_mag_phase_density)
        cbar = fig.colorbar(out_im_mag)
        cbar.ax.set_ylabel('# of Eigs', rotation=270)
        plt.title(f"Iter {iter}: Eig Phase / (log) Mag Dist")
        plt.xlabel("$\log(\|\lambda\|)$"), plt.ylabel("$Phase(\lambda)$")
        plt.tight_layout()
        plt.savefig(loc + arg_loc + save_im_loc + f'/eig_mag_phase_distribution_{iter}', bbox_inches='tight',
                    pad_inches=0)
        plt.close(fig)

        # GRAPH THE HESSIAN
        fig = plt.figure()
        hess_im = plt.imshow(hess, cmap=cmap, vmin=min_hessian_scale, vmax=max_hessian_scale)
        cbar = fig.colorbar(hess_im)
        cbar.ax.set_ylabel('$\log(|x| + c)$', rotation=270)
        plt.title(f"Iter {iter}: Jacobian of Dynamics")
        plt.xlabel("Discriminator / Generator"), plt.ylabel("Generator / Discriminator")
        plt.tight_layout()
        plt.savefig(loc + arg_loc + save_im_loc + f'/hessian_joint_{iter}', bbox_inches='tight', pad_inches=0)
        plt.close(fig)

        fig = plt.figure()
        hess_im = plt.imshow(hess[-num_G:, -num_G:], cmap=cmap, vmin=min_hessian_scale, vmax=max_hessian_scale)
        cbar = fig.colorbar(hess_im)
        cbar.ax.set_ylabel('$\log(|x| + c)$', rotation=270)
        plt.title(f"Iter {iter}: Generator Hessian")
        plt.tight_layout()
        plt.savefig(loc + arg_loc + save_im_loc + f'/hessian_G_{iter}', bbox_inches='tight', pad_inches=0)
        plt.close(fig)

        fig = plt.figure()
        hess_im = plt.imshow(hess[:num_D, :num_D], cmap=cmap, vmin=min_hessian_scale, vmax=max_hessian_scale)
        cbar = fig.colorbar(hess_im)
        cbar.ax.set_ylabel('$\log(|x| + c)$', rotation=270)
        plt.title(f"Iter {iter}: Discriminator Hessian")
        plt.tight_layout()
        plt.savefig(loc + arg_loc + save_im_loc + f'/hessian_D_{iter}', bbox_inches='tight', pad_inches=0)
        plt.close(fig)

        fig = plt.figure()
        plt.hist(polar_eigs[:, 1], weights=polar_eigs[:, 0], bins=num_bins_1d, alpha=.5, density=True, label='Energy')
        plt.hist(polar_eigs[:, 1], bins=num_bins_1d, alpha=.5, density=True, label='Probability')
        plt.ylim(min_phase_energy_density, max_phase_energy_density)
        plt.xlim(min_phase, max_phase)
        plt.xlabel("$Phase(\lambda)$")
        plt.ylabel("Eig $\lambda$ Density")
        plt.title(f"Iter {iter}")
        plt.legend(loc=1)
        plt.tight_layout()
        plt.savefig(loc + arg_loc + save_im_loc + f'/eig_phase_energy_distribution_{iter}', bbox_inches='tight',
                    pad_inches=0)
        plt.close(fig)

        fig = plt.figure()
        plt.hist(np.log10(polar_eigs[:, 0]), bins=num_bins_1d, label='Combined', alpha=.5)
        plt.hist(np.log10(polar_eigs[:, 0]), weights=np.abs(eigs[:, 1]) / polar_eigs[:, 0], bins=num_bins_1d, label='Complex',
                 alpha=.5)
        plt.hist(np.log10(polar_eigs[:, 0]), weights=np.abs(eigs[:, 0]) / polar_eigs[:, 0], bins=num_bins_1d, label='Real',
                 alpha=.25)
        plt.ylim(min_mag_density, max_mag_density)
        plt.xlim(np.log10(min_mag), np.log10(max_mag))
        plt.xlabel("$log(\| \lambda \|)$")
        plt.ylabel("# Eigs $\lambda$")
        plt.title(f"Iter {iter}: Eig (log) Mag $\| \lambda \|$  Density")
        plt.legend()
        plt.tight_layout()
        plt.savefig(loc + arg_loc + save_im_loc + f'/eig_magnitude_distribution_{iter}', bbox_inches='tight',
                    pad_inches=0)
        plt.close(fig)

        fig = plt.figure()
        np.random.seed(0)
        randints = np.random.randint(0, len(eigs), size=5)
        for i in randints[:num_eigvec_plot]:
            eig_vec = eig_vecs[i]
            graphable_vec = np.array([[key, np.abs(val)] for key, val in enumerate(eig_vec)])
            plt.hist(graphable_vec[:, 0], weights=graphable_vec[:, 1], bins=num_bins_1d,
                     label=f'$\lambda {i} = ({eigs[i, 0]:.3f}, {eigs[i, 1]:.3f})$', alpha=.25)
            normalizer = np.sum(graphable_vec[:, 1])
            prop_D = np.sum(graphable_vec[:num_D, 1]) / normalizer
            prop_G = np.sum(graphable_vec[-num_G:, 1]) / normalizer
            # print(f"Eig {i} has prop_D = {prop_D} and prop_G = {prop_G}")
        plt.axvline(num_D, c='k', label='Discriminator / Generator Border')
        plt.ylim(min_eigvec_comp_density, max_eigvec_comp_density)
        plt.xlabel("Parameters")
        plt.ylabel("Eigenvector value in parameter")
        plt.title(f"Iter {iter}: Decomp Eigenvectors into D/G")
        plt.legend(loc=1)
        plt.tight_layout()
        plt.savefig(loc + arg_loc + save_im_loc + f'/eig_vec_components_distribution_{iter}', bbox_inches='tight',
                    pad_inches=0)
        plt.close(fig)

        prop_Ds = np.zeros(len(eigs))
        for i in range(len(eigs)):
            eig_vec = np.abs(eig_vecs[i])
            normalizer = np.sum(eig_vec)
            prop_Ds[i] = np.sum(eig_vec[:num_D]) / normalizer

        fig = plt.figure()
        plt.hist(prop_Ds, bins=num_bins_1d, alpha=.5, density=True)
        plt.ylim(min_player_proportion_density, max_player_proportion_density)
        plt.xlim(0, 1)
        plt.xlabel("Proportion eigenvector for Discriminator")
        plt.ylabel("Eig $\lambda$ Density")
        plt.title(f"Iter {iter}")
        # plt.legend()
        plt.tight_layout()
        plt.savefig(loc + arg_loc + save_im_loc + f'/player_proportion_distribution_{iter}', bbox_inches='tight',
                    pad_inches=0)
        plt.close(fig)

        # TODO: Color the Eigs based on if its from generator or discriminator
        fig = plt.figure()
        paths_decomp_im = plt.scatter(log_shift_eigs[:, 0], log_shift_eigs[:, 1], c=prop_Ds, cmap=plt.cm.RdYlGn,
                                      alpha=.25, edgecolors='none', vmin=0, vmax=1)
        plt.xlim(range_re_im[0]), plt.ylim(range_re_im[1])
        cbar = fig.colorbar(paths_decomp_im)
        cbar.ax.set_ylabel('Proportion discriminator', rotation=270)
        plt.title(f"Iter {iter}: Eig $\lambda$ (log) Re / (log) Im Dist G/D Decomp")
        plt.xlabel("$\log(|\Re(\lambda)| + c)$"), plt.ylabel("$\log(|\Im(\lambda)| + c)$")
        plt.tight_layout()
        plt.savefig(loc + arg_loc + save_im_loc + f'/eig_re_im_distribution_decomposition_{iter}', bbox_inches='tight',
                    pad_inches=0)
        plt.close(fig)

        fig = plt.figure()
        paths_decomp_phase = plt.scatter(np.log10(polar_eigs[:, 0]), polar_eigs[:, 1], c=prop_Ds, cmap=plt.cm.RdYlGn,
                                         alpha=.25, edgecolors='none', vmin=0, vmax=1)
        cbar = fig.colorbar(paths_decomp_phase)
        cbar.ax.set_ylabel('Proportion Discriminator', rotation=270)
        plt.title(f"Iter {iter}: Eig Phase / (log) Mag Dist G/D Decomp")
        plt.xlabel("$\log(\|\lambda\|)$"), plt.ylabel("$Phase(\lambda)$")
        plt.tight_layout()
        plt.xlim(range_mag_phase[0]), plt.ylim(range_mag_phase[1])
        plt.savefig(loc + arg_loc + save_im_loc + f'/eig_mag_phase_distribution_decomposition_{iter}',
                    bbox_inches='tight', pad_inches=0)
        plt.close(fig)

        mixing_coefficients = np.abs(np.linalg.solve(eig_vecs, grad))

        fig = plt.figure()
        _, _, _, out_im_re_mix = plt.hist2d(log_shift_eigs[:, 0], log_shift_eigs[:, 1], weights=mixing_coefficients,
                                            bins=num_bins, range=range_re_im, cmap=cmap,
                                            vmin=min_re_im_density_grad_decomp, vmax=max_re_im_density_grad_decomp)
        cbar = fig.colorbar(out_im_re_mix)
        cbar.ax.set_ylabel('Density', rotation=270)
        plt.title(
            f"Iter {iter}: Eig $\lambda$ (log) Re / (log) Im Dist Grad Decomp")
        plt.xlabel("$\log(|\Re(\lambda)| + c)$"), plt.ylabel("$\log(|\Im(\lambda)| + c)$")
        plt.tight_layout()
        plt.savefig(loc + arg_loc + save_im_loc + f'/eig_re_im_distribution_grad_decomp_{iter}', bbox_inches='tight',
                    pad_inches=0)
        plt.close(fig)

        fig = plt.figure()
        _, _, _, out_im_mag_mix = plt.hist2d(np.log10(polar_eigs[:, 0]), polar_eigs[:, 1], weights=mixing_coefficients,
                                             bins=num_bins, cmap=cmap, range=range_mag_phase,
                                             vmin=min_mag_phase_density_grad_decomp, vmax=max_mag_phase_density_grad_decomp)
        cbar = fig.colorbar(out_im_mag_mix)
        cbar.ax.set_ylabel('Density', rotation=270)
        plt.title(f"Iter {iter}: Eig Phase / (log) Mag Dist Grad Decomp")
        plt.xlabel("$\log(\|\lambda\|)$"), plt.ylabel("$Phase(\lambda)$")
        plt.tight_layout()
        plt.savefig(loc + arg_loc + save_im_loc + f'/eig_mag_phase_distribution_grad_decomp_{iter}',
                    bbox_inches='tight', pad_inches=0)
        plt.close(fig)

        mixing_coefficients_G = np.abs(np.linalg.solve(eig_vecs, grad_G))

        fig = plt.figure()
        _, _, _, out_im_re_mix_G = plt.hist2d(log_shift_eigs[:, 0], log_shift_eigs[:, 1], weights=mixing_coefficients_G,
                                              bins=num_bins, range=range_re_im, cmap=cmap,
                                              vmin=min_re_im_density_grad_decomp, vmax=max_re_im_density_grad_decomp)
        cbar = fig.colorbar(out_im_re_mix_G)
        cbar.ax.set_ylabel('# Eigs', rotation=270)
        plt.title(
            f"Iter {iter}: Eig $\lambda$ (log) Re / (log) Im Dist G Grad Decomp")
        plt.xlabel("$\log(|\Re(\lambda)| + c)$"), plt.ylabel("$\log(|\Im(\lambda)| + c)$")
        plt.tight_layout()
        plt.savefig(loc + arg_loc + save_im_loc + f'/eig_re_im_distribution_grad_decomp_G_{iter}', bbox_inches='tight',
                    pad_inches=0)
        plt.close(fig)

        fig = plt.figure()
        _, _, _, out_im_mag_mix = plt.hist2d(np.log10(polar_eigs[:, 0]), polar_eigs[:, 1],
                                             weights=mixing_coefficients_G, bins=num_bins, cmap=cmap, range=range_mag_phase,
                                             vmin=min_mag_phase_density_grad_decomp, vmax=max_mag_phase_density_grad_decomp)
        cbar = fig.colorbar(out_im_mag_mix)
        cbar.ax.set_ylabel('Density', rotation=270)
        plt.title(f"Iter {iter}: Eig Phase / (log) Mag Dist G Grad Decomp")
        plt.xlabel("$\log(\|\lambda\|)$"), plt.ylabel("$Phase(\lambda)$")
        plt.tight_layout()
        plt.savefig(loc + arg_loc + save_im_loc + f'/eig_mag_phase_distribution_grad_decomp_G_{iter}',
                    bbox_inches='tight', pad_inches=0)
        plt.close(fig)

        mixing_coefficients_D = np.abs(np.linalg.solve(eig_vecs, grad_D))

        fig = plt.figure()
        _, _, _, out_im_re_mix_D = plt.hist2d(log_shift_eigs[:, 0], log_shift_eigs[:, 1], weights=mixing_coefficients_D,
                                              bins=num_bins, range=range_re_im, cmap=cmap,
                                              vmin=min_re_im_density_grad_decomp, vmax=max_re_im_density_grad_decomp)
        cbar = fig.colorbar(out_im_re_mix_D)
        cbar.ax.set_ylabel('# Eigs', rotation=270)
        plt.title(
            f"Iter {iter}: Eig $\lambda$ (log) Re / (log) Im Dist D Grad Decomp")
        plt.xlabel("$\log(|\Re(\lambda)| + c)$"), plt.ylabel("$\log(|\Im(\lambda)| + c)$")
        plt.tight_layout()
        plt.savefig(loc + arg_loc + save_im_loc + f'/eig_re_im_distribution_grad_decomp_D_{iter}', bbox_inches='tight',
                    pad_inches=0)
        plt.close(fig)

        fig = plt.figure()
        _, _, _, out_im_mag_mix_G = plt.hist2d(np.log10(polar_eigs[:, 0]), polar_eigs[:, 1],
                                               weights=mixing_coefficients_D, bins=num_bins, cmap=cmap,
                                               range=range_mag_phase,
                                               vmin=min_mag_phase_density_grad_decomp, vmax=max_mag_phase_density_grad_decomp)
        cbar = fig.colorbar(out_im_mag_mix_G)
        cbar.ax.set_ylabel('Density', rotation=270)
        plt.title(f"Iter {iter}: Eig Phase / (log) Mag Dist D Grad Decomp")
        plt.xlabel("$\log(\|\lambda\|)$"), plt.ylabel("$Phase(\lambda)$")
        plt.tight_layout()
        plt.savefig(loc + arg_loc + save_im_loc + f'/eig_mag_phase_distribution_grad_decomp_D_{iter}',
                    bbox_inches='tight', pad_inches=0)
        plt.close(fig)

        joint_norms += [np.sum(grad ** 2)]
        D_norms += [np.sum(grad_D ** 2)]
        G_norms += [np.sum(grad_G ** 2)]
        newton_step = np.linalg.inv(hess) @ grad
        newton_norms += [np.sum(newton_step ** 2)]

        total_energies += [np.sum(polar_eigs[:, 0])]
        complex_energies += [np.sum(polar_eigs[:, 0] * (np.abs(eigs[:, 1]) / polar_eigs[:, 0]))]
        real_energies += [np.sum(polar_eigs[:, 0] * (np.abs(eigs[:, 0]) / polar_eigs[:, 0]))]
        # TODO: Better way to allocate energy as "complex" or "real"?
        # print(f"Total Energy: {total_energies[-1]}, Proportion complex energy: {complex_energies[-1] / total_energies[-1]}, Proportion real energy: {real_energies[-1] / total_energies[-1]}")
        # print(f"Proportion Energy missing: {np.abs(total_energies[-1] - complex_energies[-1] - real_energies[-1]) / total_energies[-1]}")

    iters = np.array(iters)
    total_energies, complex_energies, real_energies = np.array(total_energies), np.array(complex_energies), np.array(
        real_energies)
    joint_norms, D_norms, G_norms, newton_norms = np.array(joint_norms), np.array(D_norms), np.array(G_norms), np.array(
        newton_norms)

    fig = plt.figure()
    plt.semilogy(iters, joint_norms, label='Joint')
    plt.semilogy(iters, D_norms, label='D')
    plt.semilogy(iters, G_norms, label='G')
    plt.semilogy(iters, newton_norms, label='Newton')
    plt.title("Update Norms vs. Training Iter")
    plt.xlabel("Iter"), plt.ylabel("Update norm")
    plt.legend()
    plt.tight_layout()
    plt.savefig(loc + arg_loc + save_im_loc + f'/training_norms', bbox_inches='tight', pad_inches=0)
    plt.close(fig)

    fig = plt.figure()
    plt.plot(iters, total_energies, label='Total')
    plt.plot(iters, complex_energies, label='Complex')
    plt.plot(iters, real_energies, label='Real')
    plt.title("Hessian Energy during Training")
    plt.xlabel("Iter"), plt.ylabel("Hessian Energy")
    plt.legend()
    plt.tight_layout()
    plt.savefig(loc + arg_loc + save_im_loc + f'/training_hess_energy', bbox_inches='tight', pad_inches=0)
    plt.close(fig)
    # TODO: Make it graph these on each data load?

    # TODO: Could make a gif over the pictures for iterations
    # TODO: Set scale adaptively?


def save_gifs(names, load_indices):
    # save_data = {'iter': [], 'eigs': [], 'eig_vecs': [], 'grad': [], 'hess':[], 'num_G': [], 'num_D': []}

    try:
        os.makedirs(loc + arg_loc + save_gif_loc)
    except FileExistsError:
        # directory already exists
        pass

    iters = []
    for ind in load_indices:  # range(num_saves):  #[-2, -1]:
        with open(loc + arg_loc + f'eig_info_{ind}.pickle', 'rb') as handle:
            save_data = pickle.load(handle)
            iters += [save_data['iter'][-1]]
    iters = np.array(iters)

    import imageio
    for name in names:
        print(f"Making .gif for {name}")
        with imageio.get_writer(loc + arg_loc + save_gif_loc + '/' + name + '.gif', mode='I') as writer:
            filenames = [loc + arg_loc + save_im_loc + '/' + name + str(iter) + '.png' for iter in iters]
            for filename in filenames:
                image = imageio.imread(filename)
                writer.append_data(image)
    print(f"Making .gif for samples")
    with imageio.get_writer(loc + arg_loc + save_gif_loc + '/samples.gif', mode='I') as writer:
        filenames = [loc + arg_loc + 'samples/' + str(iter) + '.png' for iter in iters]
        for filename in filenames:
            image = imageio.imread(filename)
            writer.append_data(image)


names = ['hessian_joint_', 'hessian_G_', 'hessian_D_',
         'eig_vec_components_distribution_', 'player_proportion_distribution_',
         'eig_phase_energy_distribution_', 'eig_magnitude_distribution_',
         'eig_re_im_distribution_', 'eig_mag_phase_distribution_',
         'eig_re_im_distribution_decomposition_', 'eig_mag_phase_distribution_decomposition_',
         'eig_re_im_distribution_grad_decomp_', 'eig_mag_phase_distribution_grad_decomp_',
         'eig_re_im_distribution_grad_decomp_G_', 'eig_mag_phase_distribution_grad_decomp_G_',
         'eig_re_im_distribution_grad_decomp_D_', 'eig_mag_phase_distribution_grad_decomp_D_']

if __name__ == '__main__':
    load_indices = [0, 1, 2, 4, 8, 16, 32, 64, 128, 256, 500]
    save_ims(load_indices)
    # TODO: Fix the scale for the images by finding min/max x and y for all, and max color_scale and min color_scale
    # TODO: add iteration to title?
    print("Making gifs ...")
    save_gifs(names, load_indices)
