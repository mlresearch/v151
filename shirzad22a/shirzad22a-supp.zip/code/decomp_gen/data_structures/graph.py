import numpy as np
import networkx as nx
from networkx.algorithms import approximation as apxa
import matplotlib.pyplot as plt
import copy

class superNode:
    def __init__(self, nodes, label, adjacents, parent, children):
        self.initial_nodes = nodes
        self.nodes = nodes
        self.label = label
        self.adjacents = adjacents
        self.parent = parent
        self.children = children
        self.canonicalName = "10"
        self.canonicalNameSet = False

    def printInformation(self):
        print("****************************************")
        print("Label of the supernode:", self.label)
        if self.parent is not None:
            print('Label of the parent:', self.parent.label)
        else:
            print('root of the tree')
        # print("Nodes inside supernode:", sorted(self.nodes))
        print("Shared and New Nodes: ", self.getNewAndSharedNodes())

        # adjLabels = []
        # for x in self.adjacents:
        #     adjLabels.append(x.getLabel())
        # print("Adjacents:", adjLabels)
        #
        # if self.parent == None:
        #     print("This node is root of the tree")
        # else:
        #     print("Parent:", self.parent.getLabel())
        #
        # childrenLabels = []
        # for x in self.children:
        #     childrenLabels.append(x.getLabel())
        # print("Children list:", childrenLabels)
        #
        # print("Canonical Name:", self.getCanonicalName())
        # print("Canonical Name Sorted By Label:", self.getCanonicalNameSortedByLabel())
        # print("****************************************")

    def setNodes(self, nodes):
        self.nodes = nodes

    def setParent(self, parent):
        self.canonicalNameSet = False
        self.parent = parent

    def addChild(self, u):
        self.canonicalNameSet = False
        self.children.add(u)

    def addAdjacent(self, u):
        self.canonicalNameSet = False
        self.adjacents.add(u)

    def removeChild(self, u):
        self.canonicalNameSet = False
        self.children.remove(u)

    def removeAdjacent(self, u):
        self.canonicalNameSet = False
        self.adjacents.remove(u)

    def setChildren(self, children):
        self.canonicalNameSet = False
        self.children = children

    def getAdjacents(self):
        return self.adjacents

    def getLabel(self):
        return self.label

    def getChildren(self):
        return self.children

    def getParent(self):
        return self.parent

    def getNodes(self):
        return self.nodes

    def getCanonicalName(self):
        if (self.canonicalNameSet):
            return self.canonicalName
        else:
            childrenNames = []
            for child in self.children:
                childrenNames.append(child.getCanonicalName())
            childrenNames.sort(reverse=True)
            self.canonicalName = '1' + ''.join(childrenNames) + '0'
            self.canonicalNameSet = True
            return self.canonicalName

    def getCanonicalNameSortedByLabel(self):
        childrenNames = {}
        labels = []
        for child in self.children:
            childrenNames[child.getLabel()] = child.getCanonicalNameSortedByLabel()
            labels.append(child.getLabel())
        labels.sort()
        names = [childrenNames[x] for x in labels]
        s = '1' + ''.join(names) + '0'
        return s

    def bagSize(self):
        return len(self.nodes)

    def sortedChildrenList(self):
        names = {}
        for child in self.children:
            names[child] = child.getCanonicalName()

        tmp = sorted(names.items(), key=lambda kv: (kv[1]))
        tmp = [x for (x, y) in tmp]
        tmp.reverse()
        return tmp

    def __DFSPathRepresentation(self, currentPath, paths):
        currentPath.append(self.label)

        # this node is a leaf
        if len(self.children) == 0:
            newPath = copy.deepcopy(currentPath)
            paths.append(newPath)
            currentPath = []
            return currentPath, paths
        # non leaf nodes:
        else:
            sortedChildren = self.sortedChildrenList()
            for child in sortedChildren:
                currentPath, paths = child.__DFSPathRepresentation(currentPath, paths)
                currentPath.append(self.label)
            paths.append([self.label])
            currentPath.pop()
            return currentPath, paths

    def subTreePathRepresentatoin(self):
        currentPath = []
        paths = []
        self.__DFSPathRepresentation(currentPath, paths)
        return paths

    def makeNXTree(self, T):
        '''
        input:
            T: A networkx graph
            outputs: Subtree of this node in rooted tree
        '''
        T.add_node(self.label)
        for child in self.children:
            T = child.makeNXTree(T)
            T.add_edge(self.label, child.getLabel())
        return T

    def __orderedBFS(self, Q, P):
        for child in self.sortedChildrenList():
            Q.append(child)
            P.append(child.getLabel())
        if len(Q) > 0:
            u = Q.pop(0)
            u.__orderedBFS(Q, P)

    def getBFSOrdering(self):
        '''
        BFS ordering of the nodes below this node with canonicalName ordering
        '''
        Q = []
        P = [self.label]
        self.__orderedBFS(Q, P)
        return P

    def getNewAndSharedNodes(self):
        if self.parent != None:
            shared = self.nodes & self.parent.nodes
        else:
            shared = set()
        newNodes = self.nodes - shared

        return {'shared': shared, 'newNodes': newNodes}

    def get_new_nodes_with_initial_labels(self):
        if self.parent != None:
            shared = self.initial_nodes & self.parent.initial_nodes
        else:
            shared = set()
        new_nodes = self.initial_nodes - shared

        return new_nodes

    def canonicalNameforNodeonTree(self, node):
        if node not in self.nodes:
            return ''
        names = []
        for child in self.sortedChildrenList():
            names.append(child.canonicalNameforNodeonTree(node))
        name = '1' + ''.join(names) + '0'
        return name


class DecompositionTree:

    def __init__(self, T, tw):
        '''
        T: tree decomposition of a graph, including tree structure and cluster nodes
        tw: approximated treewidth or the maximum size of a supernode
        '''
        if len(T.nodes) == 0:
            raise Exception('Tree with zero nodes is invalid')
        if not nx.is_tree(T):
            raise Exception('Given graph is not a tree')

        self.initialT = T
        self.nodes = []
        self.n = len(T.nodes)
        self.tw = tw

        Tnodes = sorted(T)
        mapping = {}
        for i, v in enumerate(Tnodes):
            mapping[v] = i
            if isinstance(v, int):
                v = [v]
            newSuperNode = superNode(nodes=set(v), label=i, adjacents=set(), parent=None,
                                     children=set())
            # self.nodes.append(nodes = newSuperNode, i) ?
            self.nodes.append(newSuperNode)

        self.T = nx.relabel_nodes(T, mapping)

        self.setAdjLists()
        self.setCenterAsRoot()

    def setCenterAsRoot(self):
        center = nx.center(self.T)
        if len(center) == 1:
            self.root = self.nodes[center[0]]
            self.makeRooted(self.nodes[center[0]])
        else:
            if (len(center) > 2):
                raise Exception('Tree has more than two centers!')
            self.makeRooted(self.nodes[center[0]])
            str0 = self.nodes[center[0]].getCanonicalName()
            self.makeRooted(self.nodes[center[1]])
            str1 = self.nodes[center[1]].getCanonicalName()
            self.root = self.nodes[center[1]]
            if (str0 > str1):
                self.makeRooted(self.nodes[center[0]])
                self.root = self.nodes[center[0]]

    def addSuperNode(self, parentID, nodes=None):
        parentNode = self.nodes[parentID]
        newNode = superNode(nodes=nodes, label=self.n, adjacents=set(parentNode), parent=parentNode,
                            children=set())
        self.nodes.append(newNode)
        self.T.add_edge(parentID, newNode.getLabel())
        self.n = self.n + 1
        if len(nodes) > self.tw:
            self.tw = len(nodes)
        return newNode

    def showTree(self, printNodes=False, showInitialTree=False):
        '''
        Draws tree
        optionals: 1.Print the details of the superNodes inside the DecompositionTree
                   2.Print initial given tree
        '''
        if showInitialTree:
            nx.draw(self.initialT, with_labels=True)
            plt.show()

        show_tree = copy.deepcopy(self.T)
        show_mapping = {}
        for v in show_tree.nodes:
            show_mapping[v] = frozenset(self.nodes[v].nodes)

        show_tree = nx.relabel_nodes(show_tree, show_mapping)

        nx.draw(show_tree, with_labels=True)
        plt.show()

        if printNodes:
            for node in self.nodes:
                node.printInformation()

    def getSimpleTree(self):
        return self.T

    def getNodes(self):
        return self.nodes

    def getRoot(self):
        return self.root

    def getDiameter(self):
        return nx.diameter(self.T)

    def getCanonicalName(self, sortBy='cname'):
        '''
        sortBy options:
            cname: sort by canonicalNames of the children
            label: sort by the label of the nodes
        '''
        if sortBy == 'cname':
            return self.root.getCanonicalName()
        else:
            return self.root.getCanonicalNameSortedByLabel()

    def setAdjLists(self):
        '''
        Setting adjacency lists from given networkx graph
        '''
        for line in nx.generate_adjlist(self.T):
            tmpnodes = line.split()
            tmpnodes = [int(x) for x in tmpnodes]
            v = tmpnodes[0]
            for u in tmpnodes[1:]:
                self.nodes[v].addAdjacent(self.nodes[u])
                self.nodes[u].addAdjacent(self.nodes[v])

    def makeRooted(self, root):
        '''
        Input:
            root: a supernode from nodes of decomposition tree
            Makes tree rooted from given root
        '''
        self.root = root
        mark = [False] * self.n
        root.setParent(None)
        self.__DFSMakeRooted(root, mark)

    def __DFSMakeRooted(self, v, mark):
        '''
        Input:
            v: a superNode of the current DecompositionTree
            mark: A boolean Array for knowing which nodes we have seen and which we have not
        '''
        v.setChildren(set())
        mark[v.getLabel()] = True
        for u in v.getAdjacents():
            if not mark[u.getLabel()]:
                u.setParent(v)
                v.addChild(u)
                self.__DFSMakeRooted(u, mark)

    def BFSOrder(self):
        '''
        BFS ordering of the nodes in tree from root of the tree with considering canonicalName ordering
        '''
        Q = [self.root]
        P = [self.root.getLabel()]
        while len(Q) > 0:
            v = Q.pop(0)
            for u in v.sortedChildrenList():
                Q.append(copy.copy(u))
                P.append(u.getLabel())

        mapping = {}
        for i, sn in enumerate(Q):
            mapping[sn.label] = i
            sn.label = i
        self.T = nx.relabel_nodes(self.T, mapping)
        self.nodes = Q

        return Q

        # Alternative Simple BFS Ordering without considering children's canonicalName Ordering:
        #         edges = nx.bfs_edges(self.T, self.root.getLabel())
        #         p = [self.root.getLabel()] + [v for u, v in edges]

    def pathRepresentation(self):
        return self.root.subTreePathRepresentatoin()

    def pathLenRepresentation(self):
        pr = self.pathRepresentation()
        plr = [len(x) - 1 for x in pr]
        return plr

    def DFS(self, v, Q):
        Q.append(v)
        for u in v.sortedChildrenList():
            self.DFS(u, Q)
        return Q

    def DFSOrder(self):
        Q = []
        self.DFS(self.root, Q)
        mapping = {}
        for i, sn in enumerate(Q):
            mapping[sn.label] = i
            sn.label = i
        self.nodes = Q
        self.T = nx.relabel_nodes(self.T, mapping)
        return Q

    def mapNodes(self, mapping):
        for v in self.nodes:
            newNodes = set()
            for u in v.nodes:
                newNodes.add(mapping[u])
            v.nodes = copy.copy(newNodes)


class Graph:

    def __init__(self, AdjMatrix=None, nxGraph=None, node_order='BFS'):

        self.FIRST_TIME = True

        if nxGraph != None:
            self.G = nxGraph
            self.n = len(self.G)
        else:
            self.n = AdjMatrix.shape[0]
            self.G = nx.from_numpy_array(AdjMatrix)

        self.node_order = node_order
        self.reOrder(randomPermute=False)

        self.T = None
        self.tw = -1
        self.superNodesOrdering = None
        self.clusterEndings = None
        self.treeDecomposition()

        self.randomSeed = 123

    def getGraph(self):
        return self.G

    def getTW(self):
        return self.tw

    def isConnected(self, i, j):
        return self.G.has_edge(i, j)

    def getDecompositionTree(self):
        return self.T

    def getDTdiameter(self):
        return self.T.getDiameter()

    def __mergeAnEdge(self, T):
        for e in T.edges:
            u = e[0]
            v = e[1]
            uset = set(u)
            vset = set(v)
            if vset.issubset(uset):
                ee = (u, v)
                T = nx.contracted_edge(T, ee, self_loops=False)
                return T, True
            if uset.issubset(vset):
                ee = (v, u)
                T = nx.contracted_edge(T, ee, self_loops=False)
                return T, True

        return T, False

    def __makeMinimal(self, T):
        changed = True
        while changed:
            T, changed = self.__mergeAnEdge(T)
        return T

    def treeDecomposition(self, in_test=True):
        '''
        Generates DecompositionTree and estimated tree width (tw) for tree decomposition of this Graph
        '''
        tw, D = apxa.treewidth_min_fill_in(self.G)
        D = self.__makeMinimal(D)


        # Putting whole graph in a cluster:
        # tw = len(self.G) - 1
        # id = frozenset(self.G.nodes)
        # D = nx.Graph()
        # D.add_node(id)



        # if in_test and self.FIRST_TIME:
        #     nx.draw(self.G, with_labels=True)
        #     plt.show()
        #     print('first tree:')
        #     nx.draw(D, with_labels=True)
        #     for i, n in enumerate(D):
        #         print(n)
        #     plt.show()
        #     self.FIRST_TIME = False
        self.tw = tw
        self.T = DecompositionTree(D, tw)
        self.superNodesOrdering = self.T.DFSOrder()
        self.reOrderNodesWithTree()

    # Code from GRAN paper github:
    def reOrder(self, randomPermute=True):
        if randomPermute:
            self.randomReorderNodes()

        CGs = [self.G.subgraph(c) for c in nx.connected_components(self.G)]

        # rank connected componets from large to small size
        CGs = sorted(CGs, key=lambda x: x.number_of_nodes(), reverse=True)

        node_list_bfs = []
        for ii in range(len(CGs)):
            node_degree_list = [(n, d) for n, d in CGs[ii].degree()]
            degree_sequence = sorted(
                node_degree_list, key=lambda tt: tt[1], reverse=True)
            bfs_tree = nx.bfs_tree(CGs[ii], source=degree_sequence[0][0])
            node_list_bfs += list(bfs_tree.nodes())

        adj_bfs = np.array(nx.to_numpy_matrix(self.G, nodelist=node_list_bfs))
        self.G = nx.from_numpy_array(adj_bfs)
        self.treeDecomposition()

    def randomReorderNodes(self):
        '''
        Makes complete random permutation of the nodes of the graph
        '''
        np.random.seed(self.randomSeed)
        self.randomSeed += 1
        p = np.random.permutation(self.G.number_of_nodes())
        self.G = nx.from_numpy_array(nx.to_numpy_matrix(self.G, nodelist=p))

        return p

    def reOrderNodesWithTree(self):
        self.clusterEndings = [0]
        mapping = {}
        P = [0] * self.n
        counter = 0
        for sn in self.superNodesOrdering:
            tmp = sn.getNewAndSharedNodes()
            newNodes = tmp['newNodes']
            canonNames = {}
            for v in newNodes:
                canonNames[v] = sn.canonicalNameforNodeonTree(v)

            canonNames = sorted(canonNames.items(), key=lambda x: x[1], reverse=True)
            newNodes = [ii[0] for ii in canonNames]

            for v in newNodes:
                mapping[v] = counter
                P[counter] = v
                counter += 1

            self.clusterEndings.append(counter)

        self.G = nx.from_numpy_array(nx.to_numpy_matrix(self.G, nodelist=P))
        self.T.mapNodes(mapping)

    def getNumberofClusters(self):
        return len(self.T.nodes)

    def my_subgraph(self, subset_nodes):
        SG = self.G.__class__()
        SG.add_nodes_from((v, self.G.nodes[v]) for v in subset_nodes)
        SG.add_edges_from((v, nbr, d)
                          for v, nbrs in self.G.adj.items() if v in subset_nodes
                          for nbr, d in nbrs.items() if nbr in subset_nodes)
        return SG

    def getClusterData(self, id):
        sn = self.superNodesOrdering[id]

        lastPrevNode = self.clusterEndings[id]
        prevNodes = range(lastPrevNode)

        # Gi = copy.deepcopy(self.G.subgraph(prevNodes))
        Gi = self.my_subgraph(prevNodes)

        CiNodes = sn.getNewAndSharedNodes()
        CiNodes = sorted(list(CiNodes['shared'] | CiNodes['newNodes']))

        # Ci = self.G.__class__()
        # Ci.add_nodes_from((v, self.G.nodes[v]) for v in CiNodes)
        # Ci.add_edges_from((n, nbr, d)
        #                   for n, nbrs in self.G.adj.items() if n in CiNodes
        #                   for nbr, d in nbrs.items() if nbr in CiNodes)
        Ci = self.my_subgraph(CiNodes)
        # print('CiNodes: ', CiNodes)

        # Ci = copy.deepcopy(self.G.subgraph(CiNodes))
        # breakpoint()

        return {'sn': sn, 'Gi': Gi, 'Ci': Ci}

    def partial_graph_before_node(self, max_node_id):
        node_idx = range(max_node_id)
        # Gi = nx.Graph(self.G.subgraph(node_idx))
        Gi = self.my_subgraph(node_idx)
        return Gi

    def super_node_initial_nodes(self):
        sn_num = self.getNumberofClusters()

        bags = []
        for i in range(sn_num):
            sn = self.superNodesOrdering[i]
            # sn_new_nodes_initial_label = sn.get_new_nodes_with_initial_labels()
            bags.append(sn.initial_nodes)

        return bags

    def get_cluster_subgraphs(self):
        sn_num = self.getNumberofClusters()

        sub_graphs = []
        for i in range(sn_num):
            final_node_id = self.clusterEndings[i]
            sub_graphs.append(self.partial_graph_before_node(final_node_id))

        return sub_graphs