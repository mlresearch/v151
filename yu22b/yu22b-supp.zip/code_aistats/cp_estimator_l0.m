function [theta_hat ] = cp_estimator_l0(I,lamb,c_grid, I_ind, J_ind)

     n = size(I,1);
     m = size(I,2);
     theta_path =  zeros(length(c_grid),n*m);
     mean_I =  mean(mean(I));
     Energy =  zeros(1,length(c_grid));
     
     for ind_c =  1:length(c_grid)
         c = c_grid(ind_c);
         labels = [ mean_I  c];
         %num_labels = size(labels,2);
          
         [theta_path(ind_c,:), Energy(ind_c)] = l0_denoising(I,lamb,labels, I_ind, J_ind);
         
     end
     
     best_ind =  find(Energy == min(Energy),1);

     theta_hat = theta_path(best_ind,:);
     %ind_c = 15;
     %theta_hat = reshape(theta_path(ind_c,:), n, m);
     %heatmap(theta_hat)
end