import numpy as np
from matplotlib import pyplot as plt
import sys
from mpi4py import MPI
import time

class Master:
    def __init__(self, d, size, filename, n, block, x_true, max_its, alg, xhat_file = None, epsilon = 0, xhat = None, comm=None, simulated=False, queue=None, workers=None):
        self.d = d
        self.size = size
        self.filename = filename
        self.n = n
        self.block = block
        self.x_true = x_true
        self.max_its = max_its
        self.alg = alg
        self.comm = comm
        if xhat_file:
            self.xhat = np.load(xhat_file)
        self.epsilon = epsilon
        self.m = size - 1
        assert (self.n % (self.m)) == 0
        self.f = open("%s/master.txt" % self.filename, 'w', buffering=1)
        self.f.write("Parameters: \n n: %s \n d: %s \n block: %s \n" % (self.n, self.d, self.block))
        self.f.write("Size is %s \n" % self.size)
        self.f.write("Master Starting up at time %s \n" % time.time())

        # For simulated instances
        self.simulated = simulated
        self.queue = queue   
        self.workers = workers

        # Variables that change each run
        self.eta = None
        self.order_stats = []
        self.tag= None
        self.iterate = np.zeros(d)
        self.Abar = np.zeros(d, dtype=np.float64)
        self.alphas = np.zeros(shape=(self.n, self.d))
        self.errors = []
        self.err_per_epoch = []
        self.times = []

        # FOR ADSAGA_HETERO
        self.m = size - 1
        self.U = np.zeros(shape=(self.size, self.d)) #U[rank] yields correct value
        self.num_updates = np.ones(shape=self.m) # Indexed by rank - 1
        self.eta_mult = np.ones(shape=self.m)

    def reset(self, eta, tag=0):
        self.eta = eta
        self.order_stats = []
        self.tag = tag
        self.iterate = np.zeros(self.d)
        self.Abar = np.zeros(self.d, dtype=np.float64)
        self.alphas = np.zeros(shape=(self.n, self.d))
        self.errors = []
        self.err_per_epoch = []
        self.times = []
        
        # FOR ADSAGA_HETERO
        self.U = np.zeros(shape=(self.size, self.d)) #U[rank] yields correct value
        self.num_updates = np.ones(shape=self.m) # Indexed by rank - 1
        self.eta_mult = np.ones(shape=self.m)

    def master_init(self):
        #print("Master got here", file=sys.stderr, flush=True)
        if not self.simulated:
            for i in range(1, self.size):
                ready = self.comm.recv(source=i, tag=(7 + self.tag))
            for i in range(1, self.size):
                self.comm.Send(self.iterate.astype(np.float64), dest=i, tag=(1 + self.tag))
            print("Sent initial iterates\n", file=sys.stderr, flush=True)

    def adsaga_hetero2(self, hj, j):
        self.iterate = self.iterate - self.eta_mult[j - 1]*self.eta*(hj + self.Abar)
        self.Abar = self.Abar + (hj)/self.n
        self.num_updates[j - 1] += 1
        self.eta_mult[j - 1] = np.min(self.num_updates)/self.num_updates[j - 1]

    def adsaga_hetero3(self, hj, j):
        w = max(np.max(self.w) - self.w[j-1], 1)
        self.w[j-1]+= w
        self.iterate = self.iterate - w*self.eta*(hj + self.Abar)
        self.Abar = self.Abar + (hj)/self.n
        # self.num_updates[j - 1] += 1
        # self.eta_mult[j - 1] = np.min(self.num_updates)/self.num_updates[j - 1]

    def adsaga_hetero4(self, hj, j):
        w = max(np.max(self.w) - self.w[j-1], 1)
        self.w[j-1]+= w
        self.U[j] = self.U[j]*(1 - w)+hj
        self.iterate = self.iterate - w*self.eta*(self.U[j] + self.Abar)
        self.Abar = self.Abar + (hj)/self.n
        self.U[j] -= hj*self.m/self.n
        # self.num_updates[j - 1] += 1
        # self.eta_mult[j - 1] = np.min(self.num_updates)/self.num_updates[j - 1]

    def adsaga_hetero(self, hj, j):
        self.U[j] = self.U[j]*(1 - self.eta_mult[j - 1])+hj
        self.iterate = self.iterate - self.eta_mult[j - 1]*self.eta*(self.U[j] + self.Abar)
        self.Abar = self.Abar + (hj)/self.n
        self.U[j] -= hj*self.m/self.n
        self.num_updates[j - 1] += 1
        self.eta_mult[j - 1] = np.min(self.num_updates)/self.num_updates[j - 1]

    def adsaga_step(self, hj):
        self.iterate = self.iterate - self.eta*(hj + self.Abar)
        self.Abar = self.Abar + (hj)/self.n

    def sgd_step(self, hj):
        self.iterate = self.iterate - self.eta*hj

    def asaga_step(self, grad, i):
        hj = grad - self.alphas[i]
        self.iterate = self.iterate - self.eta*(hj + self.Abar)
        self.alphas[i] = grad
        self.Abar = self.Abar + hj/self.n

    def iag_step(self, hj):
        self.Abar = self.Abar + hj/self.n
        self.iterate = self.iterate - self.eta*self.Abar

    def get_err(self):
        return np.mean(np.square(self.iterate - self.xhat))

    def make_plots(self):
        np.savetxt("%s/MSE/%s_%s.txt" % (self.filename, self.alg, self.eta), np.array(self.errors), delimiter=',')
        plt.scatter(range(len(self.errors)), self.errors)
        plt.yscale('log')
        plt.savefig("%s/MSE/%s_%s.png" % (self.filename, self.alg, self.eta))
        plt.clf()
        plt.cla()
        np.save("%s/MSE/xhat_%s" % (self.filename, self.eta), self.iterate)

    def analyze_order_stats(self):
        if self.simulated:
            seq = np.array(self.queue)
        else:
            seq = np.array(self.order_stats)
        np.savetxt('%s/queue/queue_%s.txt' % (self.filename, self.eta), seq)
        stats = []
        updates_per_machine = []
        for i in range(1, self.size):
            updates = sorted(np.where(seq == i)[0])
            for i in range(1, len(updates)):
                stats.append(updates[i] - updates[i - 1])
            updates_per_machine.append(len(updates))
        plt.bar(range(len(updates_per_machine)), updates_per_machine)
        plt.savefig('%s/queue/update_frequency_%s_%s.png' % (self.filename, self.eta, self.size))
        plt.clf()
        plt.cla()
        plt.hist(stats, bins=range(self.size*2))
        plt.savefig('%s/queue/hist%s_%s.png' % (self.filename, self.eta, self.size))
        plt.clf()
        plt.cla()

    def real_step(self):
        i = None
        status = MPI.Status()
        grad = np.empty(self.d, dtype=np.float64)
        self.comm.Recv(grad, source=MPI.ANY_SOURCE, tag=(2 + self.tag), status=status)
        if self.alg == 'asaga':
            i = self.comm.recv(source=status.Get_source(), tag=(4 + self.tag))
        # self.f.write("Grad Recieved: %s \n" % grad)
        worker = status.Get_source()
        self.order_stats.append(worker)
        # self.f.write("Iteration from %s at time %s \n" % (worker, time.time()))
        self.comm.Send(self.iterate.astype(np.float64), dest=worker, tag=(1 + self.tag))
        return grad, i, worker

    def take_step(self, grad, worker, i=None):
        if self.alg == 'adsaga_hetero':
            self.adsaga_hetero(grad, worker)
        elif self.alg == 'adsaga_hetero2':
            self.adsaga_hetero2(grad, worker)
        elif self.alg == 'adsaga_hetero3':
            self.adsaga_hetero3(grad, worker)
        elif self.alg == 'adsaga_hetero4':
            self.adsaga_hetero4(grad, worker)
        elif self.alg == 'adsaga':
            self.adsaga_step(grad)
        elif self.alg == 'asgd' or self.alg == 'dummy':
            self.sgd_step(grad)
        elif self.alg == 'asaga':
            self.asaga_step(grad, i)
        elif self.alg == 'iag':
            self.iag_step(grad)

    def bookkeep(self, its):
        self.times.append(time.time())
        err = self.get_err()
        self.errors.append(err)
        self.err_per_epoch.append(err)
        if err < self.epsilon:
            return True
        return False

    def get_iterate(self):
        return self.iterate

    def master_routine(self):
        its = 0
        while its < self.max_its + 2:
            if (its % self.n) == 0:
                terminate = self.bookkeep(its)
            i = None
            if self.simulated:
                worker = self.queue[its]
                grad, i = self.workers[worker].simulated_iteration(self.iterate)
                #print("Gradient from function %s: %s" % (i + worker*int(self.n/self.m), grad[:6]))
            else: 
                grad, i, worker = self.real_step()
            self.take_step(grad, worker, i=i)
            # if self.simulated:
            #     print("New iterate %s from %s: %s" % (its, i + worker*int(self.n/self.m), self.iterate[:6]))
            #     print("Abar: %s" % self.Abar[:6])
            # print("Grad Recieved at Master: %s \n" % grad, file=sys.stderr, flush=True)
            # print("New iterate: %s" % self.iterate, file=sys.stderr, flush=True) 
            its = its + 1 
            if terminate:
                break
        endtime = time.time()
        self.make_plots()
        #print("Terminating from master at time %s" % endtime, file=sys.stderr)
        if not self.simulated:
            for i in range(1, self.size):
                self.comm.Recv(grad, source=i, tag=(2 + self.tag))
                if self.alg == 'asaga':
                    j = self.comm.recv(source=i, tag=(4 + self.tag))
                self.comm.Send(np.zeros(self.d, dtype=np.float64), dest=i, tag=(3 + self.tag))
        self.analyze_order_stats()
        return self.err_per_epoch, endtime - self.times[0], its

    def master_routine_sync(self):
        rounds = 0
        its = 0
        terminate = False
        self.bookkeep(its)
        while rounds < self.max_its/(self.size - 1) + 2:
            for i in range(self.size - 1):
                if self.simulated:
                    grad, j = self.workers[i].simulated_iteration(self.iterate)
                else:
                    grad = np.empty(self.d, dtype=np.float64)
                    self.comm.Recv(grad, source=(i + 1), tag=(2+self.tag))
                self.take_step(grad, None)
                if (its % self.n) == 0:
                    terminate = self.bookkeep(its)
                its = its + 1
            #self.f.write("Round %s at time %s \n" % (rounds, time.time()))
            for i in range(1, self.size):
                if self.simulated:
                    grad, j = self.workers[i - 1].simulated_iteration(self.iterate)
                else:
                    self.comm.Send(self.iterate.astype(np.float64), dest=i, tag=(1 + self.tag))
            rounds = rounds + 1
            if terminate:
                break
        endtime = time.time()
        print("Terminating from master at time %s" % endtime, file=sys.stderr)
        if not self.simulated:
            for i in range(1, self.size):
                self.comm.Recv(grad, source=i, tag=(2 + self.tag))
                if self.alg == 'asaga':
                    j = self.comm.recv(source=i, tag=(4 + self.tag))
                self.comm.Send(np.zeros(self.d, dtype=np.float64), dest=i, tag=(3 + self.tag))
        self.analyze_order_stats()
        self.make_plots()
        return self.err_per_epoch, endtime - self.times[0], its

class Worker:
    def __init__(self, rank, d, filename, samples_per_worker, block, alg, seed=None, comm=None, data=None, labels=None):
        self.rank = rank
        self.d = d
        self.f = open("%s/workers/worker%s.txt" % (filename , self.rank), 'w', buffering=1)
        self.N = samples_per_worker
        self.block = block
        self.tag = 0
        self.comm = comm
        self.data =data
        self.labels = labels
        self.alphas = np.zeros(shape=(self.N, self.d))
        # self.f.write("Data: %s \n" % self.data)
        # self.f.write("Labels: %s \n" % self.labels)
        # self.f.flush()
        self.iterate = np.zeros(self.d, dtype=np.float64)
        self.alg = alg
        self.seed = seed
        # np.random.seed(seed)
        self.hangtime = 0

    def reset(self, tag=0):
        self.tag = tag
        self.iterate = np.zeros(self.d, dtype=np.float64)
        self.alphas = np.zeros(shape=(self.N, self.d))
        self.hangtime = 0

    def load_data(self, num_chunks=None, chunks_per_worker=None, data_file=None, label_file=None):
        matrix = np.zeros((0, self.d))
        label = np.zeros(0)
        data_prefix = data_file[:-4]
        labels_prefix = label_file[:-4]
        rank = self.rank
        if self.alg == 'asaga':
            rank = 1
        for i in range(chunks_per_worker):
            chunk = (rank-1)*chunks_per_worker + i
            data_file = "%s_chunk_%s_of_%s.txt.npy" % (data_prefix, chunk, num_chunks)
            label_file = "%s_chunk_%s_of_%s.txt.npy" % (labels_prefix, chunk, num_chunks)
            data_i = np.load(data_file)
            rows = int(data_i.size/self.d)
            data_i = data_i.reshape((rows, self.d))
            labels_i = np.load(label_file)
            labels_i = labels_i.reshape((rows))
            matrix = np.concatenate((matrix, data_i))
            label = np.concatenate((label, labels_i))
        self.f.write("Worker loaded data of dimensions %s, %s \n" % matrix.shape)
        self.data = matrix
        self.labels = label
        return

    def worker_init(self):
        print("Worker initiating", file=sys.stderr, flush=True)
        self.comm.send("Ready", dest=0, tag=(7+self.tag))

    def worker_routine(self):
        print("Worker starting routine", file=sys.stderr, flush=True)
        t = time.time()
        status = MPI.Status()
        while True:
            self.comm.Recv(self.iterate, source=0, tag=MPI.ANY_TAG, status=status)
            self.hangtime = self.hangtime + (time.time() - t)
            if status.Get_tag() == (1 + self.tag):
                grad, i = self.compute_grad()
                # print("Doing an Iteration with iterate: %s \n" % self.iterate, file=sys.stderr, flush=True)
                # self.f.write("Computed Update %s: %s \n" % (i, grad))
                # self.f.write("Doing an Iteration with iterate: %s \n" % self.iterate)
                # print("Computed Gradient %s: %s \n" % (i, grad), file=sys.stderr, flush=True)
                self.comm.Send(grad.astype(np.float64), dest=0, tag=(2+self.tag))
                if self.alg == 'asaga':
                    self.comm.send(i, dest=0, tag=(4+self.tag))
                t = time.time()
            elif status.Get_tag() == (3 + self.tag):
                self.f.write("Worker Terminating with total hangtime %s\n" % self.hangtime)
                break

    def simulated_iteration(self, iterate):
        grad, i = self.compute_grad()
        self.iterate = np.copy(iterate)
        # print("Doing an Iteration with iterate: %s \n" % self.iterate, file=sys.stderr, flush=True)
        # print("Computed Gradient %s: %s \n" % (i, grad), file=sys.stderr, flush=True)
        return grad, i

    def compute_grad(self):
        if self.alg == 'dummy':
            grad, i = np.zeros(self.d), 0
        elif self.alg == 'asgd' or self.alg == 'asaga':
            grad, i = self.stochastic_grad()
        else:#self.alg == 'adsaga' or self.alg == 'iag' or self.alg == 'adsaga_hetero':
            grad, i = self.saga_grad()
        return grad, i

    def stochastic_grad(self):
        i = np.random.randint(self.N)
        grad = self.LS_grad(i)
        return grad, i

    def saga_grad(self):
        i = np.random.randint(self.N)
        grad = self.LS_grad(i)
        hj = grad - self.alphas[i]
        # print("Alphas[i] = %s" % self.alphas[i][:6])
        self.alphas[i] = grad
        return hj, i

    def LS_grad(self, i):
        A_i = self.data[self.block*i:self.block*(i + 1)]
        b_i = self.labels[self.block*i:self.block*(i + 1)]
        grad = np.dot(A_i.T, (np.dot(A_i, self.iterate) - b_i))
        return grad

#     def logistic_loss(self, iterate, i):
#         A_i = self.data[self.block*i:self.block*(i + 1)]
#         b_i = self.labels[self.block*i:self.block*(i + 1)]
#         h = 1/(1 + np.exp(-np.dot(A_i,iterate))
#         loss = np.dot(-b_i.T, np.log(h)) - np.dot((1 - b_i).T, np.log(1 - h))
#         loss = (1/len(A_i))*cost
#         return cost

#     def logistic_grad(self, iterate, i):
#         A_i = self.data[self.block*i:self.block*(i + 1)]
#         b_i = self.labels[self.block*i:self.block*(i + 1)]
#         grad = np.dot(A_i.T, (1/(1 + np.exp(-np.dot(A_i, iterate))) - b_i))
#         return grad





# def load_dict_file(fname):
#     f = open(fname, 'r')
#     lines = f.readlines()
#     data = []
#     labels = []
#     for l in lines:
#         line = l.split(' ')
#         label = line[0]
