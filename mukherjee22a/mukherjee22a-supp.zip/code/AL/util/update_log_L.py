
import numpy as np

def update_log_L(log_L, mu, sig, source_idx, source_val):
    log_L += -1 * np.square((source_val - mu[source_idx, :]) / sig)
    return log_L

