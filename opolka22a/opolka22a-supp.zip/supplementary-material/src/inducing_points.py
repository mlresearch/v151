import gpflow
from gpflow import Parameter
from gpflow.inducing_variables.inducing_variables import InducingPointsBase, \
    InducingVariables
from gpflow.utilities import positive

from utils import sample_random_edges, normalize_adj_dense
import numpy as np
import tensorflow as tf
import tensorflow_probability as tfp


class NodeInducingPoints(InducingPointsBase):
    """
    Set of real-valued inducing points. See parent-class for details.
    """
    pass


class BipartiteGraphInducingPoints(InducingVariables):
    """
    Inducing points on the domain of a bipartite graph.
    """

    def __init__(self, Z1, Z2, name=None):
        """
        :param Z1: Initial positions of the inducing points for origin nodes
        of the inducing graph. Shape [M, D], where M is the number of inducing
        edges.
        :param Z2: Initial positions of the inducing points for destination
        nodes of the inducing graph. Shape [M, D], where M is the number of
        inducing edges.
        """
        super().__init__(name=name)
        self.Z1 = Parameter(Z1, dtype=Z1.dtype)
        self.Z2 = Parameter(Z2, dtype=Z2.dtype)

    def __len__(self):
        return self.Z1.shape[0]


class GraphInducingPoints(InducingVariables):
    """
    Inducing points on the domain of an undirected graph.
    """

    def __init__(self, Z, num_edges, seed=None, name=None):
        """
        :param Z: Initial positions of the inducing points for the nodes of
        the inducing graph. Shape [Mn, D], where Mn is the number of inducing
        nodes.
        :param num_edges: Number of edges the inducing graph should have.
        """
        super().__init__(name=name)
        self.Z = Parameter(Z, dtype=Z.dtype)
        # sample random edges between the nodes
        rstate = np.random.RandomState(seed) if seed else None
        self.edge_indices = sample_random_edges(Z.shape[0], num_edges, rstate)
        self.edge_indices = tf.constant(self.edge_indices)

    def __len__(self):
        return self.edge_indices.shape[0]


class ConvolvingGraphInducingPoints(InducingVariables):
    """
    Inducing points on the domain of an undirected graph where graph
    convolutions are performed to compute inducing points.
    """

    def __init__(self, Z, num_edges, name=None):
        """
        :param Z: Initial positions of the inducing points for the nodes of
        the inducing graph. Shape [Mn, D], where Mn is the number of inducing
        nodes.
        :param num_edges: Number of edges the inducing graph should have.
        """
        super().__init__(name=name)
        self.Z = Parameter(Z, dtype=Z.dtype)
        num_nodes = self.Z.shape[0]

        # sample random edges between the nodes
        self.edge_indices = sample_random_edges(Z.shape[0], num_edges)
        self.edge_indices = tf.constant(self.edge_indices)

        adj_matrix = np.zeros((num_nodes, num_nodes))
        pos_edges = self.edge_indices[:len(self.edge_indices)//2]
        adj_matrix[pos_edges[:, 0], pos_edges[:, 1]] = 1.0
        adj_matrix[pos_edges[:, 1], pos_edges[:, 0]] = 1.0
        adj_matrix[np.diag_indices(adj_matrix.shape[0])] = 1.0
        adj_matrix = normalize_adj_dense(adj_matrix)
        self.conv_mat = tf.constant(adj_matrix)

        self.weight_1 = Parameter(np.array([1.0]), transform=gpflow.utilities.positive(), name="inducing_conv_weight_1")
        self.weight_2 = Parameter(np.array([1.0]), transform=gpflow.utilities.positive(), name="inducing_conv_weight_2")

    def __len__(self):
        return self.edge_indices.shape[0]
