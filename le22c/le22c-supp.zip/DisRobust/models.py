import numpy as np
import torch 
import torch.nn as nn 
import torch.nn.functional as F 
from torch.utils.data import Dataset, DataLoader, TensorDataset
import torch.optim as optim
from collections import OrderedDict

from small_cnn import * 
from resnet import * 
from wideresnet import * 
from models_dis import * 
import small_cnn_dis as cnn 
import resnet_dis as res 
from small_cnn_dis import Disc_FC, Disc_FC_with_labels

def swish(x):
    return x * F.sigmoid(x)

def activ(key): 
    if key == 'relu': 
        return nn.ReLU() 
    elif key == 'elu': 
        return nn.ELU()
    elif key == 'swish': 
        return swish

def get_model(ds, model, activation=nn.ReLU()): 
    if ds == 'toy2d': 
        return Toy2D()
    
    elif ds == 'mnist': 
        assert (model=='cnn')
        return Mnist(activation=activation)

    elif ds == 'cifar10': 
        if model == 'cnn': 
            return Cifar10(activation=activation)
        elif model == 'resnet18': 
            return ResNet18()
        elif model == 'wideresnet': 
            return WideResNet()
    

def get_D_model_image(ds, model, activation=nn.ReLU()): 
    if ds == 'toy2d': 
        return cnn.Toy2D_Dis()
    
    elif ds == 'mnist': 
        assert (model=='cnn')
        return cnn.Mnist_Dis(activation=activation)

    elif ds == 'cifar10': 
        if model == 'cnn': 
            return cnn.Cifar10_Dis(activation=activation)
        elif model == 'resnet18': 
            return res.ResNet18_Dis()
        elif model == 'wideresnet': 
            raise ValueError


def get_D_model(ds, model, activation=nn.ReLU(), num_manifold=10, dis_input='latent', use_lables=True, num_hidden=256):     
    num_classes = 100 if ds == 'cifar100' else 10 
    
    if dis_input == 'latent': 
        if model == 'cnn': 
            in_features = 1024 if ds == 'mnist' else 1152 

        elif model == 'resnet18': 
            in_features = 512 

        elif model == 'wideresnet': 
            in_features = 640 
    elif dis_input == 'prediction': 
        in_features = num_classes
    else: 
        raise ValueError
    
    if not use_lables:
        return Disc_FC(activation=activation, num_manifold=num_manifold, 
                        num_classes=num_classes, in_features=in_features, num_hidden=num_hidden)
    else: 
        # WILL NOT USE num_manifold 
        return Disc_FC_with_labels(activation=activation, num_manifold=num_manifold, 
                        num_classes=num_classes, in_features=in_features, num_hidden=num_hidden)

def get_D_model_final(ds, model, activation=nn.ReLU(), num_manifold=10, dis_input='image', use_lables=True, num_hidden=256): 
    if dis_input == 'image': 
        return get_D_model_image(ds, model, activation=activation)
    else: 
        assert(dis_input in ['latent', 'prediction'])
        assert(use_lables in [True, False])
        assert(num_manifold in [1, 10, 100])
        return get_D_model(ds, model, activation=activation, 
                        num_manifold=num_manifold, 
                        dis_input=dis_input, 
                        use_lables=use_lables, 
                        num_hidden=num_hidden)

def adjust_learning_rate_mnist(optimizer, epoch, lr):
    """decrease the learning rate"""
    _lr = lr 
    if epoch >= 55:
        _lr = lr * 0.1
    if epoch >= 75:
        _lr = lr * 0.01
    if epoch >= 90:
        _lr = lr * 0.001
    for param_group in optimizer.param_groups:
        param_group['lr'] = _lr
    return optimizer

def adjust_learning_rate_cifar10(optimizer, epoch, lr):
    """decrease the learning rate"""
    _lr = lr
    if epoch >= 75:
        _lr = lr * 0.1
    if epoch >= 90:
        _lr = lr * 0.01
    if epoch >= 100:
        _lr = lr * 0.001
    for param_group in optimizer.param_groups:
        param_group['lr'] = _lr
    return optimizer

def adjust_learning_rate(optimizer, epoch, lr, ds): 
    if ds == 'mnist': 
        return adjust_learning_rate_mnist(optimizer, epoch, lr)
    elif ds in ['cifar10', 'cifar100']: 
        return adjust_learning_rate_cifar10(optimizer, epoch, lr)


def get_optimizer(ds, model, architecture):
    if ds == 'mnist': 
        assert(architecture == 'cnn')
        lr = 0.01
        momentum = 0.9
        opt = optim.SGD(model.parameters(), lr=lr, momentum=momentum)             

    elif ds == 'cifar10': 
        if architecture == 'cnn':
            lr = 0.001
            opt = optim.Adam(model.parameters(), lr=lr)
        
        elif architecture == 'resnet18': 
            lr = 0.01
            momentum = 0.9
            weight_decay = 3.5e-3 # MART SETTING
            opt = optim.SGD(model.parameters(), lr=lr, momentum=momentum, weight_decay=weight_decay)    

        elif architecture == 'wideresnet': 
            lr = 0.1
            momentum = 0.9
            weight_decay = 2e-4
            opt = optim.SGD(model.parameters(), lr=lr, momentum=momentum, weight_decay=weight_decay)            
    
    else: 
        raise ValueError

    return opt, lr


def get_D_optimizer(model):

    lr = 1e-3
    momentum = 0.9
    weight_decay = 2e-4 
    opt = optim.SGD(model.parameters(), lr=lr, momentum=momentum, weight_decay=weight_decay)             

    return opt

def switch_status(model, status): 
    if status == 'train': 
        model.train()
    elif status == 'eval': 
        model.eval()
    else: 
        raise ValueError
#------------------------------------------------------
class DataWithIndex(Dataset):
    def __init__(self, train_data):
        self.data = train_data
        
    def __getitem__(self, index):
        data, target = self.data[index]
        
        return data, target, index

    def __len__(self):
        return len(self.data)