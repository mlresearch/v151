from argparse import ArgumentParser

import pandas as pd
from train import run, run_supervised

if __name__ == "__main__":
    parser = ArgumentParser()
    parser.add_argument(
        "--batch_size",
        type=int,
        default=64,
        help="input batch size for training (default: 64)",
    )
    parser.add_argument(
        "--val_batch_size",
        type=int,
        default=10000,
        help="input batch size for validation (default: 1000)",
    )
    parser.add_argument(
        "--epochs",
        type=int,
        default=500,
        help="number of epochs to train (default: 500)",
    )
    parser.add_argument(
        "--lr", type=float, default=0.01, help="learning rate (default: 0.01)"
    )
    parser.add_argument(
        "--momentum",
        type=float,
        default=0.0,
        help="SGD momentum (default: 0.0)",
    )
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument(
        "--nsd",
        type=int,
        nargs="+",
        default=[1000, 2000, 4000, 8000, 12000, 16000, 20000],
    )
    parser.add_argument("--ntest", type=int, default=10000)
    parser.add_argument("--n_trials", type=int, default=20)
    parser.add_argument("--model", type=str, default="LinearClassifier")
    parser.add_argument(
        "--loss", type=str, default="logistic", help="Loss function "
    )
    parser.add_argument(
        "--algorithms",
        type=str,
        nargs="+",
        default=["sl", "sv"],
        help="list of algorithms",
    )
    parser.add_argument(
        "--datasets",
        type=str,
        nargs="+",
        default=["mnist", "fashion", "kmnist"],
        help="list of datasets",
    )
    parser.add_argument(
        "--display_gpu_info",
        action="store_true",
        help="Display gpu usage info. This needs python 3.X and pynvml package",
    )
    parser.add_argument(
        "--out",
        type=str,
        default="./results/complexity.csv",
        help="path to output results",
    )

    args = parser.parse_args()

    results = []

    for dataset in args.datasets:
        for nsd in args.nsd:
            for algorithm in args.algorithms:
                for seed in range(args.n_trials):
                    print("# Dataset: {}".format(dataset))
                    print("# NSD: {}".format(nsd))
                    print("# Algorithm: {}".format(algorithm))
                    print("# Seed: {}".format(seed))
                    print("")

                    if algorithm in ["sl"]:
                        acc = run(
                            train_batch_size=args.batch_size,
                            val_batch_size=args.val_batch_size,
                            epochs=args.epochs,
                            lr=args.lr,
                            momentum=args.momentum,
                            weight_decay=args.weight_decay,
                            display_gpu_info=args.display_gpu_info,
                            loss=args.loss,
                            model=args.model,
                            dataset=dataset,
                            nsd=nsd,
                            ntest=args.ntest,
                            seed=seed,
                            algorithm=algorithm,
                        )

                    elif algorithm in ["sv"]:
                        acc = run_supervised(
                            train_batch_size=args.batch_size,
                            val_batch_size=args.val_batch_size,
                            epochs=args.epochs,
                            lr=args.lr,
                            momentum=args.momentum,
                            weight_decay=args.weight_decay,
                            display_gpu_info=args.display_gpu_info,
                            loss=args.loss,
                            model=args.model,
                            dataset=dataset,
                            nsd=nsd,
                            ntest=args.ntest,
                            seed=seed,
                        )
                    else:
                        raise NotImplementedError

                    res = {
                        "seed": seed,
                        "algorithm": algorithm,
                        "acc": acc,
                        "dataset": dataset,
                        "nsd": nsd,
                    }
                    results.append(res)

    pd.DataFrame(results).to_csv(args.out, index=False)
