import torch
import os
from PIL import Image
import numpy as np


def load_CIFAR10(data_dir):
    
    print(os.path.join(data_dir, 'X_cnn.npy'))
    X_cnn = np.load(os.path.join(data_dir, 'X_cnn.npy'))
    X_eval = np.load(os.path.join(data_dir, 'X_eval.npy'))
    X_train = np.load(os.path.join(data_dir, 'X_train.npy'))

    y_cnn = np.load(os.path.join(data_dir, 'y_cnn.npy'))
    y_eval = np.load(os.path.join(data_dir, 'y_eval.npy'))
    y_train = np.load(os.path.join(data_dir, 'y_train.npy'))

    print(X_cnn.shape)
    print(X_eval.shape)
    print(X_train.shape)
    print(y_cnn.shape)
    print(y_eval.shape)
    print(y_train.shape)

    # # print(sum(y_train==0))

    # for name in ['train', 'cnn', 'eval']:
    #     parent_dir = os.path.join(data_dir, name)
    #     os.makedirs(parent_dir, exist_ok=True)
    #     for class_idx in ['0', '1']:
    #         curr_dir = os.path.join(parent_dir, class_idx)
    #         os.makedirs(curr_dir, exist_ok=True)

    # # demo = cifar_10.data[2].reshape(32,32,3,order='F').transpose(1,0,2)

    # for idx in range(X_train.shape[0]):
    #     img = Image.fromarray((X_train[idx].reshape(32,32,3,order='F').transpose(1,0,2))).convert('RGB')
    #     if y_train[idx]==0:
    #         img.save(os.path.join(data_dir, 'train' ,'0', f'{idx}.jpg'))
    #     else:
    #         img.save(os.path.join(data_dir, 'train' ,'1', f'{idx}.jpg'))

    # for idx in range(X_cnn.shape[0]):
    #     img = Image.fromarray((X_cnn[idx].reshape(32,32,3,order='F').transpose(1,0,2))).convert('RGB')
    #     if y_cnn[idx]==0:
    #         img.save(os.path.join(data_dir, 'cnn' ,'0', f'{idx}.jpg'))
    #     else:
    #         img.save(os.path.join(data_dir, 'cnn' ,'1', f'{idx}.jpg'))
    
    # for idx in range(X_eval.shape[0]):
    #     img = Image.fromarray((X_eval[idx].reshape(32,32,3,order='F').transpose(1,0,2))).convert('RGB')
    #     if y_eval[idx]==0:
    #         img.save(os.path.join(data_dir, 'eval' ,'0', f'{idx}.jpg'))
    #     else:
    #         img.save(os.path.join(data_dir, 'eval' ,'1', f'{idx}.jpg'))

    # for name in ['demo']:
    #     parent_dir = os.path.join(data_dir, name)
    #     os.makedirs(parent_dir, exist_ok=True)
    #     for class_idx in ['0', '1']:
    #         curr_dir = os.path.join(parent_dir, class_idx)
    #         os.makedirs(curr_dir, exist_ok=True)

    # num_samples = 1500
    # X_test = np.concatenate((X_cnn, X_eval), axis=0)
    # X_demo = np.concatenate((X_test[0:5], X_test[num_samples:num_samples+5]), axis=0)
    # y_demo = np.array([0]*(X_demo.shape[0]//2)+[1]*(X_demo.shape[0]//2))

    # for idx in range(X_demo.shape[0]):
    #     img = Image.fromarray((X_demo[idx].reshape(32,32,3,order='F').transpose(1,0,2))).convert('RGB')
    #     if y_demo[idx]==0:
    #         img.save(os.path.join(data_dir, 'demo' ,'0', f'{idx}.png'))
    #     else:
    #         img.save(os.path.join(data_dir, 'demo' ,'1', f'{idx}.png'))



if __name__ == '__main__':
    load_CIFAR10(r'../data/CIFAR10')