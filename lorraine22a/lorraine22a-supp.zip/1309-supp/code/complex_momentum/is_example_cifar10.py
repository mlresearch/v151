"""Check that the Inception Score (IS) is high for the "true" data distribution (the CIFAR-10 training set).

Example
-------
python is_example_cifar10.py
"""
import os
import sys
sys.path.insert(0, 'wgan_stuff/wgan-gp')
import ipdb

from torchvision import datasets

# Local imports
from tflib import inception_score

cifar10_trainset = datasets.CIFAR10(root='data', train=True, download=True, transform=None)
train_images = cifar10_trainset.data  # This is a numpy array of type uint8, with min value 0, max value 255

cifar10_testset = datasets.CIFAR10(root='data', train=False, download=True, transform=None)
test_images = cifar10_testset.data  # This is a numpy array of type uint8, with min value 0, max value 255

print('Running Inception on the CIFAR-10 training set...')
train_is = inception_score.get_inception_score(list(train_images))
print('\nInception Score (CIFAR-10 Trainset): {}'.format(train_is))

print('\nRunning Inception on the CIFAR-10 training set...')
test_is = inception_score.get_inception_score(list(test_images))
print('\nInception Score (CIFAR-10 Testset): {}'.format(test_is))
