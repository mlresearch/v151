include("clustering_synthetic.jl")

main_clustering_synthetic(10,10)
