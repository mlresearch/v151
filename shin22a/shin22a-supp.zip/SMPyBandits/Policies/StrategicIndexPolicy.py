# -*- coding: utf-8 -*-
""" Generic index policy.

- If rewards are not in [0, 1], be sure to give the lower value and the amplitude. Eg, if rewards are in [-3, 3], lower = -3, amplitude = 6.
"""
from __future__ import division, print_function  # Python 2 compatibility

import numpy as np

try:
    from .StrategicBasePolicy import StrategicBasePolicy
except (ImportError, SystemError):
    from StrategicBasePolicy import StrategicBasePolicy


class StrategicIndexPolicy(StrategicBasePolicy):
    """ Class that implements a generic index policy."""

    def __init__(self, nbArms, nbAgents, nbArmsPerAgents,
                 lower=0., amplitude=1.):
        """ New index policy for strategic bandit.

        - nbArms: the number of arms,
        - nbAgents: the number of agents,
        - nbArmsPerAgents: a list of the number of arms for each agent
        - lower, amplitude: lower value and known amplitude of the rewards.
        """
        super(StrategicIndexPolicy, self).__init__(nbArms, nbAgents, nbArmsPerAgents,
                                                   lower=lower, amplitude=amplitude)
        self.agentIndex = np.zeros(nbAgents)  #: Numerical index for each agents
        self.armIndex = np.zeros(nbArms)  #: Numerical index for each arms

    # --- Start game, and receive rewards

    def startGame(self):
        """ Initialize the policy for a new game."""
        super(StrategicIndexPolicy, self).startGame()
        self.agentIndex.fill(0)
        self.armIndex.fill(0)

    
    def computeAgentIndex(self, agent):
        """ Compute the current index of agent 'argent'."""
        raise NotImplementedError("This method computeAgentIndex(agent) has to be implemented in the child class inheriting from StrategicIndexPolicy.")


    def computeArmIndex(self, arm):
        """ Compute the current index of arm 'arm'."""
        raise NotImplementedError("This method computeArmIndex(arm) has to be implemented in the child class inheriting from StrategicIndexPolicy.")


    def computeAllIndex(self):
        """ Compute the current indexes for all arms. Possibly vectorized, by default it can *not* be vectorized automatically."""
        for agent in range(self.nbAgents):
            self.agentIndex[agent] = self.computeAgentIndex(agent)
        
        for arm in range(self.nbArms):
            self.armIndex[arm] = self.computeArmIndex(arm)


    def choice(self):
        r""" In an strategic index policy,
        choose an arm with maximal index of the maximal index agent (uniformly at random):

        .. warning:: In almost all cases, there is a unique arm with maximal index, so we loose a lot of time with this generic code, but I couldn't find a way to be more efficient without loosing generality.
        """
        # I prefer to let this be another method, so child of IndexPolicy only needs to implement it (if they want, or just computeIndex)
        self.computeAllIndex()

        # Uniform choice among the best agents
        try:
            agent = np.random.choice(np.nonzero(self.agentIndex == np.max(self.agentIndex))[0])
        except ValueError:
            print("Warning: unknown error in StrategicIndexPolicy.choice(): the agent indexes were {} but couldn't be used to select an agent.".format(self.agentIndex))
            agent = np.random.randint(self.nbAgents)

        # Get arm indices with chosen agent
        tempArmIndexArr = np.full((self.nbArms), float('-inf'))
        armPossession = np.cumsum(self.nbArmsPerAgents) - 1

        if agent == 0:
            tempArmIndexArr[0:armPossession[agent]+1] = self.armIndex[0:armPossession[agent]+1]
        else:
            tempArmIndexArr[armPossession[agent-1]+1:armPossession[agent]+1] = self.armIndex[armPossession[agent-1]+1:armPossession[agent]+1]

        # Uniform choice among the best arms of the best agent.
        # np.nonzero gives an index
        try:
            return np.random.choice(np.nonzero(tempArmIndexArr == np.max(tempArmIndexArr))[0])
        except ValueError:
            print("Warning: unknown error in StrategicIndexPolicy.choice(): the arm indexes were {} but couldn't be used to select an arm.".format(self.armIndex))
            return np.random.choice(np.where(tempArmIndexArr >= 0)[0])


