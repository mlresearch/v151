from torch.utils.data import DataLoader
from torchvision import datasets, transforms


def calc_input_sizes(dataset: str, task: str):
    """Calculate sequential and feature sizes for input data with respect to the dataset and task.

    Args:
        dataset (str): "MNIST", "FashionMNIST" or "CIFAR10".
        task (str): "pix", "seq" or "whole".

    Returns:
        int: Sequential size (temporal size).
        int: Feature size.
    """
    if dataset in ["MNIST", "FashionMNIST"]:
        width = 28
        height = 28
        channel = 1
    elif dataset in ["CIFAR10"]:
        width = 32
        height = 32
        channel = 3
    else:
        raise Exception("Unrecognized dataset: %s" % dataset)

    if task == "pix":
        seq_size = width * height
        feature_size = channel
    elif task == "seq":
        seq_size = height
        feature_size = width * channel
    elif task == "whole":
        seq_size = 1
        feature_size = width * height * channel
    else:
        raise Exception("Unrecognized task: %s" % task)
    return seq_size, feature_size


def mydataloader(dataset: str, task: str, data_dir: str, batch_size: int, num_workers: int = 2):
    """Return dataloader for RNN.

    Args:
        dataset (str): "MNIST", "FashionMNIST" or "CIFAR10".
        task (str): "pix", "seq" or "whole".
        data_dir (str): Path to dataset.
        batch_size (int): Batch size for batch sampling.
    """

    def serialize(x, seq_size, feature_size):
        return x.view(feature_size, seq_size).transpose(0, 1)

    def list_transform(dataset, task):
        seq_size, feature_size = calc_input_sizes(dataset, task)
        list_trans = [transforms.ToTensor(), transforms.Lambda(lambda x: serialize(x, seq_size, feature_size))]
        return list_trans

    list_trans = list_transform(dataset, task)
    if dataset == "MNIST":
        ds = datasets.MNIST
        transform = transforms.Compose(list_trans)
    elif dataset == "FashionMNIST":
        ds = datasets.FashionMNIST
        transform = transforms.Compose(list_trans)
    elif dataset == "CIFAR10":
        ds = datasets.CIFAR10
        list_trans.insert(
            1,
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5)),
        )
        transform = transforms.Compose(list_trans)
    else:
        raise Exception("Unrecognized dataset: %s" % dataset)

    train_ds = ds(root=data_dir, train=True, transform=transform, download=True)
    test_ds = ds(root=data_dir, train=False, transform=transform, download=True)
    train_dl = DataLoader(train_ds, batch_size=batch_size, shuffle=True, num_workers=num_workers, pin_memory=True)
    test_dl = DataLoader(test_ds, batch_size=batch_size, shuffle=False, num_workers=num_workers, pin_memory=True)
    return train_dl, test_dl
