from .base import Loss
from .regularized import SinkhornLoss
