from src.datasets import get_dataset, get_dim
import src.noises
import torchvision
import torch
inds = [1000, 2000, 3000,4000,5000,6000]
image = torch.stack([get_dataset('imagenet','test')[x][0] for x in inds])
dssn_noise = src.noises.SplitMethodDerandomized(sigma=3.5,dim=get_dim('imagenet'),seed=0)
uniform_noise = src.noises.Uniform(sigma=3.5,dim=get_dim('imagenet'))

torchvision.utils.save_image(dssn_noise.sample(image.reshape(len(inds),-1)).reshape(image.shape),'dssn_example_2.png',nrow =6)
torchvision.utils.save_image(uniform_noise.sample(image.reshape(len(inds),-1)).reshape(image.shape),'uniform_example_2.png',normalize=True,scale_each=True,nrow=6 )
torchvision.utils.save_image(image,'clean_example_2.png',nrow =6)
