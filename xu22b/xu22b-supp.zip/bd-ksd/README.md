# bounded-domain ksd test
