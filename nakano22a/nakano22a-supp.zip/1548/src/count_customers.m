function [NumRowCustomers, NumColumnCustomers] = count_customers(RowTable, ColumnTable, K)

NumRowCustomers=zeros(K,1);
for kk=1:K
    NumRowCustomers(kk) = sum(RowTable==kk);
end
NumColumnCustomers=zeros(K,1);
for kk=1:K
    NumColumnCustomers(kk) = sum(ColumnTable==kk);
end