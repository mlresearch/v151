from scipy.special import comb, perm
import numpy as np
from pdf2cdf import pdf2cdf
def m_by_n(m ,n):
    """Define a function m_sum_n, where
     m, n are integers, return a matrix(numpy array)
     such that each row of this matrix is exactly
     a discrete pdf of an m-by-n diagram."""
    Nd = int(comb(m+n, m))
    answer = np.zeros((Nd, m+1))
    if m == 1:
        for i_n in range(m+n):
            answer[i_n] = [i_n, n-i_n]
        return answer
    if n == 1:
        for i_m in range(m+n):
            answer[i_m, i_m] = 1
        return answer
    index_start = 0
    index_finish = 0
    for v_begin in range(n+1):
        """for each time, consider the first value is v_begin, then 
        it reduce to the combinations of (m-1)-by-(n-v_begin)"""
        Nd_last = int(comb(m-1+n-v_begin, m-1))
        index_start = index_finish
        index_finish = index_start + Nd_last
        for j_first in range(index_start, index_finish):
            answer[j_first, 0] = v_begin
        answer[index_start:index_finish, 1:] = m_by_n(m-1, n-v_begin)
    return answer
