import logging


def get_module_logger(modname):
    logger = logging.getLogger(modname)
    logger.setLevel(logging.DEBUG)
    sh = logging.StreamHandler()
    sh.setLevel(logging.ERROR)
    logger.addHandler(sh)
    fh = logging.FileHandler(filename="log.txt", mode="a", encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(logging.Formatter("%(asctime)s:%(levelname)s:%(name)s:%(message)s"))
    logger.addHandler(fh)
    return logger
