import math

import numpy as np
from sklearn.metrics import mean_absolute_error, mean_absolute_percentage_error
import matplotlib.pyplot as plt
import networkx as nx
from pygsp import graphs
import tensorflow as tf
import gpflow
from gpflow.utilities import print_summary

from kernels.wavelet_kernel import Wavelet, TaylorApproximateWavelet
from multiscale_stochastic_block_model import sample_multiscale_graph
from wavelet_utils import compute_full_filter, plot_spectral_filters


def low(x, alpha=1.):
    return 1. / (1. + alpha * x)


def taylor_low_scalar(x, alpha=1., max_degree=5, around=1.0):
    """Taylor approximation of the low pass filter 1/(1 + alpha * x) around 1.0"""
    result = 0.0
    for degree in range(max_degree+1):
        result += (-1.0)**degree * alpha**degree * (x - around)**degree / (1.0 + alpha * around)**(degree+1)
    return result


def band(x, scale=0.3):
    if isinstance(x, np.ndarray):
        return x * scale * np.exp(-scale * x)
    return x * scale * tf.exp(-scale * x)


def taylor_band_scalar(x, beta=1., max_degree=5, around=1.0):
    """Taylor approximation of the low pass filter bx * exp(-bx)"""
    result = 0.0
    for degree in range(max_degree+1):
        result += (-1.0)**degree * 1 / math.factorial(degree) * beta**degree * (beta * around - degree) * np.exp(-beta * around) * (x - around)**degree
    return result


def sample_spectral_graph_signal(graph):
    N = graph.N
    w, v = np.linalg.eig(graph.L.todense())
    w, v = np.real(w), np.real(v)
    idx = w.argsort()  # [::-1]
    w = w[idx]
    v = v[:, idx]
    x = np.linspace(0, w.max(), N)

    plot_spectral_filters(low_scale=10., band_scales=[0.8, 0.1], low_filter=low, band_filter=band,
                          eigvals=w)

    wave_signal = np.sum([v[:, i] * e for i, e in enumerate(low(x, 10.) + band(x, 0.8) + band(x, 0.1))], axis=0)
    return wave_signal


def sample_signal_from_prior(prior_kernel):
    prior_mean = np.zeros(prior_kernel.num_nodes)
    prior_cov = prior_kernel.K(tf.range(prior_kernel.num_nodes))
    sample = np.random.multivariate_normal(mean=prior_mean, cov=prior_cov)
    return sample


def compute_spectrum_deviation(eigvals, low_scale, band_scales, pred_low_scale, pred_band_scales, low_filter, band_filter, approx_low_filter,
                               approx_band_filter):
    pred_filtered_eigvals = compute_full_filter(eigvals, pred_low_scale, pred_band_scales, approx_low_filter,
                                                approx_band_filter)
    filtered_eigvals = compute_full_filter(eigvals, low_scale, band_scales, low_filter, band_filter)
    return mean_absolute_percentage_error(filtered_eigvals, pred_filtered_eigvals)


def optimize_scipy(model, step_callback):
    opt = gpflow.optimizers.Scipy()
    opt.minimize(model.training_loss, variables=model.trainable_variables,
                 step_callback=step_callback, method="Newton-CG")


def optimize_tf(model, step_callback, lr=0.1):
    opt = tf.optimizers.Adam(lr=lr)
    for epoch_idx in range(100):
        with tf.GradientTape(watch_accessed_variables=False) as tape:
            tape.watch(model.trainable_variables)
            loss = -model.log_marginal_likelihood()
            gradients = tape.gradient(loss, model.trainable_variables)
        opt.apply_gradients(zip(gradients, model.trainable_variables))
        step_callback(epoch_idx)
        print(f"{epoch_idx}:\tLoss={loss}")


def run_training():
    # Sample a multiscale graph
    graph = sample_multiscale_graph(nodes_per_scale=(8, 8, 8))
    graph = graphs.Graph(nx.adj_matrix(graph, nodelist=sorted(list(graph))).todense())
    graph.compute_laplacian("normalized")
    L_normalized = graph.L.todense()
    eigvals, eigvecs = np.linalg.eig(L_normalized)
    eigvals = np.real(eigvals)
    graph.set_coordinates()
    num_nodes = graph.N
    print(num_nodes)

    low_scale = 15.0
    band_scales = [1.5, 3.2]
    init_low_scale = 5.0
    init_band_scales = [1.0, 2.0]
    low_around = 0.6
    band_around = 1.0
    low_degree = 5
    band_degree = 5

    # Sample a graph signal from the GP prior
    prior_kernel = Wavelet(L_normalized, low_pass=low_scale, scales=band_scales)
    wave_signal = sample_signal_from_prior(prior_kernel)
    axes = plt.gca()
    graph.plot_signal(wave_signal, ax=axes)
    axes.set_title("ground truth sampled signal")
    plt.show()

    # Prepare GP model
    # train_idcs = tf.range(int(0.5 * num_nodes))
    train_idcs = tf.constant(np.random.choice(num_nodes, int(0.75*num_nodes), replace=False))
    X_full = tf.cast(tf.reshape(tf.range(num_nodes), (-1, 1)), tf.float64)
    Y_full = tf.cast(tf.reshape(wave_signal, (-1, 1)), dtype=tf.float64)
    X_train = tf.gather(X_full, train_idcs) # tf.cast(tf.reshape(train_idcs, (-1, 1)), tf.float64)
    Y_train = tf.gather(Y_full, train_idcs) #tf.cast(tf.reshape(tf.gather(wave_signal, train_idcs), (-1, 1)), dtype=tf.float64)
    kernel = TaylorApproximateWavelet(L_normalized, low_pass=init_low_scale, scales=init_band_scales)
    data = (X_train, Y_train)
    m = gpflow.models.GPR(data, kernel=kernel)
    print_summary(m)

    def step_callback(step, variables=None, values=None):
        if step % 10 == 0:
            pred, pred_var = m.predict_y(X_full)
            pred = pred.numpy().reshape(-1)
            mae = mean_absolute_error(pred, wave_signal.reshape(-1))
            print(f"Epoch {step}:\tMAE={mae:.5f}")
            axes = plt.gca()
            graph.plot_signal(pred, ax=axes)
            axes.set_title(f"prediction after {step} epochs (MAE={mae:.5f})")
            plt.show()
            print_summary(m)
    optimize_scipy(m, step_callback)
    # optimize_tf(m, step_callback)
    print_summary(m)

    approx_low_filter = lambda x, scale: taylor_low_scalar(x, alpha=scale, max_degree=low_degree, around=low_around)
    approx_band_filter = lambda x, scale: taylor_band_scalar(x, beta=scale, max_degree=band_degree, around=band_around)

    pred_low = m.kernel.alpha.numpy()
    pred_band_scales = [m.kernel.scale1.numpy(), m.kernel.scale2.numpy()]
    plot_spectral_filters(low_scale, band_scales, low, band, eigvals=eigvals, pred_low_scale=pred_low,
                          pred_band_scales=pred_band_scales, approx=True, approx_band_filter=approx_band_filter,
                          approx_low_filter=approx_low_filter)
    spectrum_deviation = compute_spectrum_deviation(
        eigvals, low_scale=low_scale, band_scales=band_scales, pred_low_scale=pred_low,
        pred_band_scales=pred_band_scales, low_filter=low, band_filter=band, approx_low_filter=approx_low_filter,
        approx_band_filter=approx_band_filter)
    print(f"Spectrum deviation: {spectrum_deviation}")


if __name__ == '__main__':
    # x = np.linspace(0, 2.0, 1000)
    # plt.plot(x, taylor_low_scalar(x, 0.4, max_degree=3, around=1.0))
    # plt.plot(x, low(x, 0.4))
    # plt.show()
    run_training()