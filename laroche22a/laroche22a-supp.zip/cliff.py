# authors: anonymous

import numpy as np
from utils import choice

class Cliff:
    def __init__(self, nb_states, gamma=0.99, noise=0, ratio=10):
        self.reward_0 = 0
        self.reward_2 = gamma**(nb_states-3)
        self.reward_1 = ratio*self.reward_2
        self.nb_states = nb_states
        self.nb_actions = 3
        self.gamma = gamma
        self.transition_function = np.zeros((self.nb_states, self.nb_actions, self.nb_states))
        self.is_done = False
        self.initial_state = 0
        self.current_state = self.initial_state
        self.final_state = nb_states - 1
        self._generate_transition_function()
        self._generate_reward_function()
        self.noise = noise # uniform reward noise amplitude

    def _generate_transition_function(self):
        for id_state in range(self.nb_states-2):
            self.transition_function[id_state, 0, self.final_state-1] = 1
            self.transition_function[id_state, 1, self.final_state] = 1
            self.transition_function[id_state, 2, id_state + 1] = 1

    def reset(self):
        self.current_state = self.initial_state
        return int(self.current_state)

    def sample_action(self):
        return np.random.randint(self.nb_actions)

    def _get_reward(self, state, action, next_state):
        r = self.reward_function[state, next_state] + (2*np.random.rand()-1)*self.noise 
        return r

    def step(self, state, action):
        next_state = choice(self.nb_states, self.transition_function[int(state), action, :].squeeze())
        reward = self._get_reward(state, action, next_state)
        is_done = (next_state >= self.final_state-1) # 2 terminal states
        return reward, next_state, is_done

    # Reward matrix
    def _generate_reward_function(self):
        self.reward_function = np.zeros((self.nb_states, self.nb_states))
        for s in range(self.nb_states):
            self.reward_function[s, self.final_state-1] = self.reward_0
            self.reward_function[s, self.final_state] = self.reward_1
        self.reward_function[self.final_state - 2, self.final_state - 1] = self.reward_2
        return self.reward_function

    def start_state(self):
        return self.initial_state

    def generate_random_policy(self):
        # We use log to have a policy that is further from uniform.
        x = np.log(np.random.rand(self.nb_states,self.nb_actions))
        pi = x/x.sum(axis=1).reshape(self.nb_states,1)
        return pi
