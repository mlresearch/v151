import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from torch.autograd.gradcheck import zero_gradients
from torch.autograd import Variable

import pickle

device = 'cuda' if torch.cuda.is_available() else 'cpu'

loss_ce = nn.CrossEntropyLoss(size_average=False) 
adversarial_criterion = nn.BCELoss(reduction='sum')

loss_ce_mean = nn.CrossEntropyLoss(size_average=True) 
adversarial_criterion_mean = nn.BCELoss(reduction='mean')

class Gv_PGD(nn.Module):
    def __init__(self, basic_net, config, discriminator, D_optimizer):
        super(Gv_PGD, self).__init__()
        self.basic_net = basic_net
        self.discriminator = discriminator
        self.D_optimizer = D_optimizer
        self.rand = config['random_init']
        self.step_size = config['step_size']
        self.epsilon = config['epsilon']
        self.num_steps = config['num_steps']

        self.dis_input = config['dis_input']
        self.x_min = config['x_min']
        self.x_max = config['x_max']
        self.lamda1 = config['lamda1']
        self.lamda2 = config['lamda2']

        self.batch_size = config['batch_size']
        self.num_classes = config['num_classes']

        print(config)

    def get_D_input(self, image, latent, prediction): 
        if self.dis_input == 'image': 
            return image
        elif self.dis_input == 'latent': 
            return latent 
        elif self.dis_input == 'prediction': 
            return prediction
        else: 
            raise ValueError

    def genadv(self, inputs, targets):

        aux_net = pickle.loads(pickle.dumps(self.basic_net))

        aux_net.eval()

        assert(aux_net.training is False)

        batch_size = inputs.size(0)

        x_adv = inputs.detach()
        
        assert(self.rand)
        
        x_adv = x_adv + torch.zeros_like(x_adv).uniform_(-self.epsilon, self.epsilon)

        # Clasification for Nat images 
        logits_pred_nat, fea_nat = aux_net(inputs, return_z=True)
        inD_nat = self.get_D_input(inputs, fea_nat, logits_pred_nat)

        for _ in range(self.num_steps):
            x_adv.requires_grad_()

            # Clear all previous gradients
            zero_gradients(x_adv)
            if x_adv.grad is not None:
                x_adv.grad.data.fill_(0)

            aux_net.zero_grad()
            self.discriminator.zero_grad()

            # Classification - forward path  
            logits_pred, fea_adv = aux_net(x_adv, return_z=True)
            inD_adv = self.get_D_input(x_adv, fea_adv, logits_pred)

            # Discriminator forward path 
            logits_fea_nat, D_cla_nat = self.discriminator(inD_nat, targets=targets)
            logits_fea_adv, D_cla_adv = self.discriminator(inD_adv, targets=targets)

            # Label for Discriminator 
            valid = Variable(torch.Tensor(np.ones((batch_size, 1))), requires_grad=False).cuda()
            fake = Variable(torch.Tensor(np.zeros((batch_size, 1))), requires_grad=False).cuda()

            # Losses 
            with torch.enable_grad():
                C_cla_adv = loss_ce(logits_pred, targets) # Average over batch 
                D_cla_fake = loss_ce(D_cla_adv, targets) # Average over batch
                loss_real = adversarial_criterion(logits_fea_nat, valid)
                loss_fake = adversarial_criterion(logits_fea_adv, fake)
                loss = C_cla_adv - self.lamda1 * loss_fake - self.lamda2 * D_cla_fake
            
            # Backpropagation 
            grad = torch.autograd.grad(loss, [x_adv])[0] # []

            # Update using PGD 
            x_adv = x_adv.detach() + self.step_size * torch.sign(grad.detach())
            x_adv = torch.min(torch.max(x_adv, inputs - self.epsilon), inputs + self.epsilon)
            x_adv = torch.clamp(x_adv, self.x_min, self.x_max) 

        log_dict = dict()
        log_dict['genadv_d_real'] = loss_real
        log_dict['genadv_d_fake'] = loss_fake
        log_dict['genadv_c_adv'] = C_cla_adv
        log_dict['genadv_score_real'] = torch.mean(logits_fea_nat)
        log_dict['genadv_score_fake'] = torch.mean(logits_fea_adv)

        X_adv_out = Variable(x_adv, requires_grad=False)

        return X_adv_out, log_dict


    def get_discriminator_loss(self, nat_inputs, adv_inputs, targets): 
        
        batch_size = nat_inputs.size(0)

        logits_pred_nat, fea_nat = self.basic_net(nat_inputs, return_z=True)
        logits_pred, fea_adv = self.basic_net(adv_inputs, return_z=True)

        inD_nat = self.get_D_input(nat_inputs, fea_nat, logits_pred_nat)
        inD_adv = self.get_D_input(adv_inputs, fea_adv, logits_pred)   

        valid = Variable(torch.Tensor(np.ones((batch_size, 1))), requires_grad=False).cuda()
        fake = Variable(torch.Tensor(np.zeros((batch_size, 1))), requires_grad=False).cuda()        

        # Discriminator forward path 
        logits_fea_nat, D_cla_nat = self.discriminator(inD_nat.detach(), targets=targets) # CHANGE HERE 
        logits_fea_adv, D_cla_adv = self.discriminator(inD_adv.detach(), targets=targets) # CHANGE HERE 

        # losses 
        with torch.enable_grad():
            loss_real = adversarial_criterion_mean(logits_fea_nat, valid)
            loss_fake = adversarial_criterion_mean(logits_fea_adv, fake)
            D_cla_real = loss_ce_mean(D_cla_nat, targets)
            D_cla_fake = loss_ce_mean(D_cla_adv, targets)
            discriminator_loss = loss_real + loss_fake + D_cla_real + D_cla_fake

        log_dict = dict()
        log_dict['dis_d_real'] = loss_real
        log_dict['dis_d_fake'] = loss_fake
        log_dict['dis_c_nat'] = D_cla_real
        log_dict['dis_c_adv'] = D_cla_fake
        log_dict['dis_score_real'] = torch.mean(logits_fea_nat)
        log_dict['dis_score_fake'] = torch.mean(logits_fea_adv)

        return discriminator_loss, log_dict
    
    def get_generator_loss(self, nat_inputs, adv_inputs, targets): 
        batch_size = nat_inputs.size(0)
               
        valid = Variable(torch.Tensor(np.ones((batch_size, 1))), requires_grad=False).cuda()
        fake = Variable(torch.Tensor(np.zeros((batch_size, 1))), requires_grad=False).cuda()        

        # Classifier forward path 
        logits_pred_nat, fea_nat = self.basic_net(nat_inputs, return_z=True)
        logits_pred, fea_adv = self.basic_net(adv_inputs, return_z=True)

        inD_nat = self.get_D_input(nat_inputs, fea_nat, logits_pred_nat)
        inD_adv = self.get_D_input(adv_inputs, fea_adv, logits_pred)   

        # Discriminator forward path 
        logits_fea_nat, D_cla_nat = self.discriminator(inD_nat, targets=targets) # DO NOT STOP GRADIENT 
        logits_fea_adv, D_cla_adv = self.discriminator(inD_adv, targets=targets) # DO NOT STOP GRADIENT 

        with torch.enable_grad():
            loss_real = adversarial_criterion_mean(logits_fea_nat, fake) # CHANGE HERE 
            loss_fake = adversarial_criterion_mean(logits_fea_adv, valid) # CHANGE HERE
            D_cla_real = loss_ce_mean(D_cla_nat, targets)
            D_cla_fake = loss_ce_mean(D_cla_adv, targets)

            generator_loss = D_cla_real + D_cla_fake + loss_fake

        log_dict = dict()
        log_dict['gen_d_real'] = loss_real
        log_dict['gen_d_fake'] = loss_fake
        log_dict['gen_score_real'] = torch.mean(logits_fea_nat)
        log_dict['gen_score_fake'] = torch.mean(logits_fea_adv)

        return generator_loss, log_dict

    def get_classifier_loss(self, nat_inputs, adv_inputs, targets, beta=1.0): 
        # Classifier forward path 
        logits_pred_nat, fea_nat = self.basic_net(nat_inputs, return_z=True)
        logits_pred, fea_adv = self.basic_net(adv_inputs, return_z=True)

        with torch.enable_grad():
            gen_c_nat = loss_ce_mean(logits_pred_nat, targets)
            gen_c_adv = loss_ce_mean(logits_pred, targets)
            class_loss = gen_c_nat + beta * gen_c_adv

        log_dict = dict()
        log_dict['gen_c_nat'] = gen_c_nat
        log_dict['gen_c_adv'] = gen_c_adv

        return class_loss, log_dict