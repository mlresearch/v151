# Copyright (c) 2017-present, Facebook, Inc.
# All rights reserved.
#
# This source code is licensed under the license found in the LICENSE file in
# the root directory of this source tree. An additional grant of patent rights
# can be found in the PATENTS file in the same directory.

from collections import defaultdict

import torch
import torch.nn.functional as F
from torch import nn
from torch.autograd.variable import Variable
from torch.nn import Parameter
import math

from partitioned_linear import PartitionedLinear


class FillPadding(torch.autograd.Function):
    @staticmethod
    def forward(ctx, inputs, mask, num_heads):
        assert len(inputs.size()) == 3, "Tensor is not 3 dims"
        bsz = int(inputs.size(0) / num_heads)
        tgt_len = inputs.size(1)
        src_len = inputs.size(2)
        inputs = inputs.view(bsz, num_heads, tgt_len, src_len)
        inputs = inputs + mask.unsqueeze(1).unsqueeze(2)
        inputs = inputs.view(bsz * num_heads, tgt_len, src_len)
        return inputs.detach()

    def backward(ctx, grad_output):
        grad_input = grad_output
        return grad_input, None, None


fill_padding_func = FillPadding.apply


class MultiheadAttention(nn.Module):
    """Multi-headed attention.

    See "Attention Is All You Need" for more details.
    """

    def __init__(
        self, args, embed_dim, num_heads, dropout=0.0, softmax_type="default", bias=True,
    ):
        super().__init__()
        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.dropout = dropout
        self.softmax_type = softmax_type
        self.head_dim = embed_dim // num_heads
        assert (
            self.head_dim * num_heads == self.embed_dim
        ), "embed_dim must be divisible by num_heads"
        self.scaling = self.head_dim ** -0.5
        self._mask = None

        partition_embed_dim = not args.partition_heads

        if args.partition_both:
            ratios = in_ratios = args.ratios
        elif args.partition_input:
            ratios = None
            in_ratios = args.ratios
        else:
            ratios = args.ratios
            in_ratios = None

        self.w_qs = args.partitioned_linear_module(embed_dim, embed_dim, ratios=ratios, in_ratios=in_ratios, bias=bias,
                                      pad_if_not_fully_active=False)
        self.w_ks = args.partitioned_linear_module(embed_dim, embed_dim, ratios=ratios, in_ratios=in_ratios, bias=bias,
                                      pad_if_not_fully_active=False)

        self.partition_v = args.partition_v
        self.partition_out_proj = args.partition_out_proj

        if args.partition_v:
            self.w_vs = args.partitioned_linear_module(embed_dim, embed_dim, ratios=ratios, in_ratios=in_ratios, bias=bias)
        else:
            self.w_vs = nn.Linear(embed_dim, embed_dim, bias=bias)

        self.partition_embed_dim = partition_embed_dim

        if args.partition_out_proj:
            self.out_proj = args.partitioned_linear_module(embed_dim, embed_dim, in_ratios=ratios, bias=bias)
        else:
            self.out_proj = nn.Linear(embed_dim, embed_dim, bias=bias)

        self.reset_parameters()

    def reset_parameters(self):
        def reset_fn(module):
            for m in module.children():
                if isinstance(m, nn.Linear):
                    nn.init.xavier_uniform_(m.weight, gain=1 / math.sqrt(2))
                    if m.bias is not None:
                        nn.init.constant_(m.bias, 0.0)
        self.apply(reset_fn)


    def forward(
        self,
        query,
        key,
        value,
        mask_future_timesteps=False,
        key_padding_mask=None,
        incremental_state=None,
        need_weights=True,
        static_kv=False,
        attn_mask=None,
        need_head_weights=False
    ):
        """Input shape: Time x Batch x Channel

        Self-attention can be implemented by passing in the same arguments for
        query, key and value. Future timesteps can be masked with the
        `mask_future_timesteps` argument. Padding elements can be excluded from
        the key by passing a binary ByteTensor (`key_padding_mask`) with shape:
        batch x src_len, where padding elements are indicated by 1s.
        """
        if need_head_weights:
            need_weights = True
        qkv_same = query.data_ptr() == key.data_ptr() == value.data_ptr()
        kv_same = key.data_ptr() == value.data_ptr()

        tgt_len, bsz, embed_dim = query.size()
        assert embed_dim == self.embed_dim
        assert list(query.size()) == [tgt_len, bsz, embed_dim]
        assert key.size() == value.size()

        if incremental_state is not None:
            saved_state = self._get_input_buffer(incremental_state)
            if "prev_key" in saved_state:
                # previous time steps are cached - no need to recompute
                # key and value if they are static
                if static_kv:
                    assert kv_same and not qkv_same
                    key = value = None
        else:
            saved_state = None

        q = self.scaling * self.w_qs(query)
        if key is None:
            assert value is None
            # this will allow us to concat it with previous value and get
            # just get the previous value
            k = v = q.new(0)
        else:
            k = self.w_ks(key)
            v = self.w_vs(value)

        if saved_state is not None:
            if "prev_key" in saved_state:
                k = torch.cat((saved_state["prev_key"], k), dim=0)
            if "prev_value" in saved_state:
                v = torch.cat((saved_state["prev_value"], v), dim=0)
            saved_state["prev_key"] = k
            saved_state["prev_value"] = v
            self._set_input_buffer(incremental_state, saved_state)

        src_len = k.size(0)

        if key_padding_mask is not None:
            assert key_padding_mask.size(0) == bsz
            assert key_padding_mask.size(1) == src_len

        if self.partition_embed_dim:
            current_head_dim = q.size(2) // self.num_heads
            q = (
                q[:, :, :current_head_dim * self.num_heads].contiguous()
                .view(tgt_len, bsz, current_head_dim, self.num_heads)
                .transpose(2, 3)
            )
            k = (
                k[:, :, :current_head_dim * self.num_heads].contiguous()
                .view(src_len, bsz, current_head_dim, self.num_heads)
                .transpose(2, 3)
            )
            if self.partition_v:
                v = (
                    v[:, :, :current_head_dim * self.num_heads].contiguous()
                    .view(src_len, bsz, current_head_dim, self.num_heads)
                    .transpose(2, 3)
                )
                current_head_dim_v = current_head_dim
            else:
                current_head_dim_v = self.head_dim
        else:
            current_head_dim = self.head_dim
            current_head_dim_v = self.head_dim

        q = (
            q.contiguous()
            .view(tgt_len, bsz * self.num_heads, -1)
            .transpose(0, 1)
        )
        k = (
            k.contiguous()
            .view(src_len, bsz * self.num_heads, -1)
            .transpose(0, 1)
        )
        v = (
            v.contiguous()
            .view(src_len, bsz * self.num_heads, -1)
            .transpose(0, 1)
        )

        attn_weights = torch.bmm(q, k.transpose(1, 2))
        assert list(attn_weights.size()) == [bsz * self.num_heads, tgt_len, src_len]

        # only apply masking at training time (when incremental state is None)
        if mask_future_timesteps and incremental_state is None:
            assert (
                query.size() == key.size()
            ), "mask_future_timesteps only applies to self-attention"
            attn_weights += self.buffered_mask(attn_weights).unsqueeze(0)

        if attn_mask is not None:
            attn_mask = attn_mask.unsqueeze(0)
            attn_weights += attn_mask

        if self.softmax_type == "fast_fill":
            if key_padding_mask is not None:
                attn_weights = fill_padding_func(
                    attn_weights, key_padding_mask, self.num_heads
                )
            attn_weights = F.softmax(attn_weights, dim=-1)
        elif self.softmax_type == "default":
            if key_padding_mask is not None:
                attn_weights = attn_weights.view(bsz, self.num_heads, tgt_len, src_len)
                attn_weights = attn_weights.masked_fill(
                    key_padding_mask.unsqueeze(1).unsqueeze(2), float("-inf")
                )
                attn_weights = attn_weights.view(bsz * self.num_heads, tgt_len, src_len)
            attn_weights = F.softmax(attn_weights, dim=-1, dtype=torch.float32).type_as(attn_weights)
        else:
            assert False, "Unknown Softmax Type: {}".format(self.softmax_type)
        attn_weights = F.dropout(attn_weights, p=self.dropout, training=self.training)
        attn = torch.bmm(attn_weights, v)
        assert list(attn.size()) == [bsz * self.num_heads, tgt_len, current_head_dim_v]
        attn = attn.transpose(0, 1).contiguous().view(tgt_len, bsz, current_head_dim_v * self.num_heads)
        attn = self.out_proj(attn)

        if need_weights:
            # average attention weights over heads
            attn_weights = attn_weights.view(bsz, self.num_heads, tgt_len, src_len)
            if not need_head_weights:
                attn_weights = attn_weights.mean(dim=1)
        else:
            attn_weights = None

        return attn, attn_weights

    def in_proj_qkv(self, query):
        return self._in_proj(query).chunk(3, dim=-1)

    def in_proj_kv(self, key):
        return self._in_proj(key, start=self.embed_dim).chunk(2, dim=-1)

    def in_proj_q(self, query):
        return self._in_proj(query, end=self.embed_dim)

    def in_proj_k(self, key):
        return self._in_proj(key, start=self.embed_dim, end=2 * self.embed_dim)

    def in_proj_v(self, value):
        return self._in_proj(value, start=2 * self.embed_dim)

    def _in_proj(self, input, start=None, end=None):
        weight = self.in_proj_weight
        bias = self.in_proj_bias
        if end is not None:
            weight = weight[:end, :]
            if bias is not None:
                bias = bias[:end]
        if start is not None:
            weight = weight[start:, :]
            if bias is not None:
                bias = bias[start:]
        return F.linear(input, weight, bias)

    def buffered_mask(self, tensor):
        dim = tensor.size(-1)
        if self._mask is None:
            self._mask = torch.triu(fill_with_neg_inf(tensor.new(dim, dim)), 1)
        if self._mask.size(0) < dim:
            self._mask = torch.triu(fill_with_neg_inf(self._mask.resize_(dim, dim)), 1)
        return self._mask[:dim, :dim]

    def reorder_incremental_state(self, incremental_state, new_order):
        """Reorder buffered internal state (for incremental generation)."""
        input_buffer = self._get_input_buffer(incremental_state)
        if input_buffer is not None:
            for k in input_buffer.keys():
                input_buffer[k] = input_buffer[k].index_select(1, new_order)
            self._set_input_buffer(incremental_state, input_buffer)

    def _get_input_buffer(self, incremental_state):
        return get_incremental_state(self, incremental_state, "attn_state",) or {}

    def _set_input_buffer(self, incremental_state, buffer):
        set_incremental_state(
            self, incremental_state, "attn_state", buffer,
        )


def fill_with_neg_inf(t):
    """FP16-compatible function that fills a tensor with -inf."""
    return t.float().fill_(float("-inf")).type_as(t)


INCREMENTAL_STATE_INSTANCE_ID = defaultdict(lambda: 0)


def _get_full_incremental_state_key(module_instance, key):
    module_name = module_instance.__class__.__name__

    # assign a unique ID to each module instance, so that incremental state is
    # not shared across module instances
    if not hasattr(module_instance, "_mlbench_instance_id"):
        INCREMENTAL_STATE_INSTANCE_ID[module_name] += 1
        module_instance._mlbench_instance_id = INCREMENTAL_STATE_INSTANCE_ID[
            module_name
        ]

    return "{}.{}.{}".format(module_name, module_instance._mlbench_instance_id, key)


def get_incremental_state(module, incremental_state, key):
    """Helper for getting incremental state for an nn.Module."""
    full_key = _get_full_incremental_state_key(module, key)
    if incremental_state is None or full_key not in incremental_state:
        return None
    return incremental_state[full_key]


def set_incremental_state(module, incremental_state, key, value):
    """Helper for setting incremental state for an nn.Module."""
    if incremental_state is not None:
        full_key = _get_full_incremental_state_key(module, key)
        incremental_state[full_key] = value
