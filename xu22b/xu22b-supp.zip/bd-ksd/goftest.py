#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Dec 15 18:45:23 2020

@author: wenkaix
"""

import torch.autograd as autograd
import torch
import torch.distributions as dists
import torch.optim as optim
import typing
from scipy.integrate import quad
import numpy as np

import time

def bootstrapper_rademacher(n):
    """
    Produce a sequence of i.i.d {-1, 1} random variables.
    Suitable for boostrapping on an i.i.d. sample.
    """
    return 2.0*np.random.randint(0, 1+1, n)-1.0

def bootstrapper_multinomial(n):
    """
    Produce a sequence of i.i.d Multinomial(n; 1/n,... 1/n) random variables.
    This is described on page 5 of Liu et al., 2016 (ICML 2016).
    """
    import warnings
    warnings.warn('Somehow bootstrapper_multinomial() does not give the right null distribution.')
    M = np.random.multinomial(n, np.ones(n)/float(n), size=1) 
    return M.reshape(-1) - (1.0/float(n))

def bootstrapper_gaussian(n):
    """
    Produce a sequence of i.i.d standard gaussian random variables.
    """
    return np.random.randn(n)

    
class GKernelSteinTest(object):
    """
    kernelized KSD test
    p: probability density
    k: kernel choice
    alpah: test level
    """
    def __init__(self, k, p, g=None,bootstrapper=bootstrapper_rademacher, alpha=0.05,
                        n_simulate=500, seed=13, ustats=False, u_sim=1000):
        self.k = k
        self.p = p
        self.g = g
        self.alpha = alpha
        self.bootstrapper = bootstrapper
        self.n_simulate = n_simulate
        self.seed = seed
        self.ustats = ustats
        self.u_sim = u_sim
        
    def perform_test(self, X, return_simulated_stats=False, return_ustat_gram=False):
        """
        perform the test, with wildbootstrap
        """
        #start track time
        start = time.time()
        test_stat, H = self.compute_stat(X, return_gram_mat=True)
        
        # bootrapping
        alpha = self.alpha
        n_simulate = self.n_simulate
        n = X.shape[0]
        sim_stats = torch.zeros(n_simulate).to(H.device)
        torch.random.manual_seed(self.seed)
        
        if self.ustats is True:
            D, _ = torch.eig(H)
    #         D /= float(n)
            D = D[:,0]
            Z1 = torch.randn(len(D)*self.u_sim).to(D.device)
            Z = Z1.reshape([-1, len(D)]).to(D.dtype)
#            import pdb; pdb.set_trace()
            sim_stats = (Z**2 - 2.)@(D) #/2.
     
            
        else:
            for i in range(n_simulate):
                W = torch.from_numpy(self.bootstrapper(n)).view(1,n).to(H.dtype)
                H_ = H.clone().to("cpu")
    #            import pdb; pdb.set_trace()
                boot_stat = W@H_@W.T/float(n)
                sim_stats[i] = boot_stat.to(H.device)          
        pvalue = torch.mean((sim_stats > test_stat)*1.0)
        
        #time used for the process
        end=time.time()
        
        pvalue = pvalue.cpu().numpy()
        test_stat = test_stat.detach().cpu().numpy()
        results = {'alpha': self.alpha, 'pvalue': pvalue, 'test_stat': test_stat,
                 'h0_rejected': pvalue < alpha, 'n_simulate': n_simulate,
                 'time_secs': end-start}        
        if return_simulated_stats:
            results['sim_stats'] = sim_stats
        if return_ustat_gram:
            results['H'] = H
            
        return results
        
    def compute_stat(self, X, return_gram_mat = True):
        k = self.k
        p = self.p
            
        n, d = X.shape
        K = k.eval(X, X)


        
        Kx = torch.zeros(n, n, d).to(X.device)
        for i in range(d):
            Kx[:,:,i] = k.gradX_Y(X, X, i) # n x n
        Kxy_sum = k.gradXY_sum(X, X) #n x n
        gradp = p.grad_log(X) # n x d
#        X = X.detach()
#        X.requires_grad = False

        if self.g is None:
            gradg = 0
        else:
            gradg = self.g.grad_log(X)
            
        H = Kxy_sum
        for i in range(d):
            temp_x = Kx[:,:, i].to(K.device)
            
            if self.g is None:
                temp_g = gradp[:,i].to(K.device) 
            else:
                temp_g = (gradp[:,i]+gradg[:,i]).to(K.device) 

            Temp = torch.einsum('j,ij->ij',temp_g, temp_x)
            H += Temp + Temp.T
            H += torch.einsum('i,j,ij->ij',temp_g, temp_g, K)

#            Kgradg = torch.einsum('i, ij, j->ij', gradg, K, gradg)
        if self.g is not None:
            g_val = self.g.eval(X)            
            H = torch.einsum('i,ij, j->ij', g_val, H, g_val)   
#            H += Kgradg

        Tstat = torch.mean(H) * n
        if return_gram_mat:
            return Tstat, H
        else:
            return Tstat

    def power_criterion0(self, X, lamb=0.01):
        test_stat, H = self.compute_stat(X, return_gram_mat=True)
        std_reg = torch.std(H) + lamb
        return test_stat/std_reg
    
    def power_criterion(self, X, lamb=0.01):
        test_stat, H = self.compute_stat(X, return_gram_mat=True)
        std_reg = torch.std(torch.mean(H,1)) + lamb
        return test_stat/std_reg
    

    def grid_search_kernel(self, X, grid, lamb=0.01, return_val=True, power_0=False):
        d = len(grid)
        pw_crit = torch.zeros(d)
        for i in range(d):
            self.k.rescale(grid[i])
            if power_0 is True:
                pw_crit[i] = self.power_criterion0(X,lamb=lamb)
            else:
                pw_crit[i] = self.power_criterion(X,lamb=lamb)
        idx = torch.argmax(pw_crit)
        self.k.rescale(grid[idx])
        if return_val:
            return idx, grid[idx]
        
        
        

class MirroredKernelSteinTest(object):
    """
    KSD test with Mirrored Stein operator Shi et al. 2021
    p: probability density
    k: kernel choice
    alpah: test level
    """
    def __init__(self, k, p, g=None,bootstrapper=bootstrapper_rademacher, alpha=0.05,
                        n_simulate=500, seed=13, ustats=False, u_sim=1000):
        self.k = k
        self.p = p
        self.g = g
        self.alpha = alpha
        self.bootstrapper = bootstrapper
        self.n_simulate = n_simulate
        self.seed = seed
        self.ustats = ustats
        self.u_sim = u_sim
        
    def perform_test(self, X, return_simulated_stats=False, return_ustat_gram=False):
        """
        perform the test, with wildbootstrap
        """
        #start track time
        start = time.time()
        test_stat, H = self.compute_stat(X, return_gram_mat=True)
        
        # bootrapping
        alpha = self.alpha
        n_simulate = self.n_simulate
        n = X.shape[0]
        sim_stats = torch.zeros(n_simulate).to(H.device)
        torch.random.manual_seed(self.seed)
        
        if self.ustats is True:
            D, _ = torch.eig(H)
    #         D /= float(n)
            D = D[:,0]
            Z1 = torch.randn(len(D)*self.u_sim).to(D.device)
            Z = Z1.reshape([-1, len(D)]).to(D.dtype)
#            import pdb; pdb.set_trace()
            sim_stats = (Z**2 - 2.)@(D) #/2.
     
            
        else:
            for i in range(n_simulate):
                W = torch.from_numpy(self.bootstrapper(n)).view(1,n).to(H.dtype)
                H_ = H.clone().to("cpu")
    #            import pdb; pdb.set_trace()
                boot_stat = W@H_@W.T/float(n)
                sim_stats[i] = boot_stat.to(H.device)          
        pvalue = torch.mean((sim_stats > test_stat)*1.0)
        
        #time used for the process
        end=time.time()
        
        pvalue = pvalue.cpu().numpy()
        test_stat = test_stat.detach().cpu().numpy()
        results = {'alpha': self.alpha, 'pvalue': pvalue, 'test_stat': test_stat,
                 'h0_rejected': pvalue < alpha, 'n_simulate': n_simulate,
                 'time_secs': end-start}        
        if return_simulated_stats:
            results['sim_stats'] = sim_stats
        if return_ustat_gram:
            results['H'] = H
            
        return results
        
    def compute_stat(self, X, return_gram_mat = True):
        """
        Mirrored Stein operator statistics
        
        Parameters
        ----------
        X : TYPE
            DESCRIPTION.
        return_gram_mat : TYPE, optional
            DESCRIPTION. The default is True.

        Returns
        -------
        None.

        """
        k = self.k
        p = self.p
            
        n, d = X.shape
        K = k.eval(X, X)


        
        Kx = torch.zeros(n, n, d).to(X.device)
        for i in range(d):
            Kx[:,:,i] = k.gradX_Y(X, X, i) # n x n
        Kxy_sum = k.gradXY_sum(X, X) #n x n
        gradp = p.grad_log(X) # n x d
#        X = X.detach()
#        X.requires_grad = False

        if self.g is None:
            # gradg = 0
            gradg_diag = torch.diag_embed(X)
            gradg_mat = torch.einsum('ij,il->ijl',X, X)
            gradg = gradg_diag - gradg_mat
        else:
            gradg = self.g.grad_log(X)

        gradp = torch.einsum('ni,nij->nj',gradp, gradg)
            
        H = Kxy_sum
        for i in range(d):
            temp_x = Kx[:,:, i].to(K.device)
            
            if self.g is None:
                temp_g = gradp[:,i].to(K.device)
            else:
                temp_g = (gradp[:,i]+gradg[:,i]).to(K.device) 

            Temp = torch.einsum('j,ij->ij',temp_g, temp_x)
            H += Temp + Temp.T
            H += torch.einsum('i,j,ij->ij',temp_g, temp_g, K)

#            Kgradg = torch.einsum('i, ij, j->ij', gradg, K, gradg)
#         if self.g is not None:
#             g_val = self.g.eval(X)            
#             H = torch.einsum('i,ij, j->ij', g_val, H, g_val)   
# #            H += Kgradg

        Tstat = torch.mean(H) * n
        if return_gram_mat:
            return Tstat, H
        else:
            return Tstat

    def power_criterion0(self, X, lamb=0.01):
        test_stat, H = self.compute_stat(X, return_gram_mat=True)
        std_reg = torch.std(H) + lamb
        return test_stat/std_reg
    
    def power_criterion(self, X, lamb=0.01):
        test_stat, H = self.compute_stat(X, return_gram_mat=True)
        std_reg = torch.std(torch.mean(H,1)) + lamb
        return test_stat/std_reg
    

    def grid_search_kernel(self, X, grid, lamb=0.01, return_val=True, power_0=False):
        d = len(grid)
        pw_crit = torch.zeros(d)
        for i in range(d):
            self.k.rescale(grid[i])
            if power_0 is True:
                pw_crit[i] = self.power_criterion0(X,lamb=lamb)
            else:
                pw_crit[i] = self.power_criterion(X,lamb=lamb)
        idx = torch.argmax(pw_crit)
        self.k.rescale(grid[idx])
        if return_val:
            return idx, grid[idx]
        
class KSDPowerCriterion(object):
    """
    Implement the power criterion of the KSD to learn parameters.
    """
    def __init__(self, p, k, X):
        """
        p: an instance of UnnormalizedDensity
        k: a kernel object representing a kernel on X
        X: torch tensors representing the observed data
        """
        self.p = p
        self.k = k
        self.X = X
        self.ksdtest = KernelSteinTest(k, p)
    
    def optimize_params(self, params, lr, reg=1e-4, constraint_f=None, 
        max_iter=500, verbose=False):
        """
        Optimize parameters in the list params by maximizing the power
        criterion of the KSD test. This method modifies the state of this
        object (specifically, parameters in kernel k).
        - params:  a list of torch.Tensor.
        Specifies what Tensors should be optimized. Will be fed to an
        optimizer in torch.optim. All parameters in params must be part of
        (p, k). 
        - constraint_f: callable object (params) |-> None that modifies
        all the parameters to be optimized in-place to satisfy the
        constraints (if any).
        - reg: regularizer of the power criterion
        - lr: overall learning rate. Lr of each parameter can be specified
        separately as well. https://pytorch.org/docs/stable/optim.html
        - max_iter: maximum number of gradient updates
        Return a torch array of recorded function values
        """
        if params is None:
            params = []
        if constraint_f is None:
            constraint_f = lambda *args, **kwargs: None
        # optimizer
        all_params = params
        for pa in all_params:
            pa.requires_grad = True
        optimizer = optim.Adam(all_params, lr=lr)
#        optimizer = optim.SGD(all_params, lr=lr)

        # record
        objs = torch.zeros(max_iter)
        for t in range(max_iter):
            optimizer.zero_grad()
            # minimize the *negative* of power criterion
            obj = -self._point_power_criterion(reg=reg)
            obj.backward(retain_graph=True)
            optimizer.step()
            # constraint satisfaction
            constraint_f(params)
            # Flip the sign back
            objs[t] = -obj.detach()
            
            if verbose is True:
                print(params)
        return objs

    def _point_power_criterion(self, reg=1e-5):
        """
        Evaluate the regularized power criterion of KSD statistics using the
        specified kernels and data.
        The objective is mean_under_H1 / (reg + standard deviation under H1)
        reg: a non-negative scalar specifying the regularization parameter
        """
        ksdtest = self.ksdtest

        stat, H = ksdtest.compute_stat(self.X)
        sigma_h1 = torch.std(torch.mean(H, 1))

        power_cri = stat/(sigma_h1 + reg)
        return power_cri
    



class G_Radius():
    """
    Auxilary function with 1 - radius
    """
    def __init__(self, p=1., eps = 1e-7):
        self.eps = eps
        self.p = p
    def eval(self, X):
        """g(x) = 1 - ||x||
        X: n x d torch tensor
        """
        gval = 1. -torch.sqrt((X**2).sum(axis=1)) # size [n] torch tensor 
        return gval

    def gradX(self, X):
        """
        Compute the gradient with respect to X in g(X).
        X: n x d
        Return a numpy array of size n x d.
        """
        norm = 1./(torch.sqrt((X**2).sum(axis=1)) + self.eps)
        
        Grad =  -torch.einsum('i,ij->ij', norm, X)   
        
        return Grad
    
    def grad_log(self, X):
        """
        Compute the gradient with respect to X in g(X).
        X: n x d
        Return a numpy array of size n x d.
        """
        Grad =  self.gradX(X)
        Xinv = 1./(self.eval(X) + self.eps)
        grad_log =  torch.einsum('i,ij->ij', Xinv, Grad)   
        return grad_log



class G_Radius_sq():
    """
    Auxilary function with 1 - radius^2
    """
    def __init__(self,eps=1e-7):
        self.eps = eps
        
        
    def eval(self, X):
        """g(x) = 1 - ||x||^2
        X: n x d torch tensor
        """
        gval = 1. - ((X**2).sum(axis=1)) # size [n] torch tensor 
        return gval

    def gradX(self, X):
        """
        Compute the gradient with respect to X in g(X).
        X: n x d
        Return a numpy array of size n x d.
        """
        Grad =  - torch.einsum('i,ij->ij', ((X**2).sum(axis=1)) , X)   
        return Grad

    def grad_log(self, X):
        """
        Compute the gradient with respect to X in g(X).
        X: n x d
        Return a numpy array of size n x d.
        """
#        Grad =  - torch.einsum('i,ij->ij', ((X**2).sum(axis=1)) , X)
        Grad =  self.gradX(X)
        Xinv = 1./(self.eval(X) + self.eps)
        grad_log =  torch.einsum('i,ij->ij', Xinv, Grad)   
        return grad_log


class G_Prod():
    """
    Auxilary function with 1 - radius
    """
    def __init__(self,eps=1e-7):
        self.eps = eps

    def eval(self, X):
        """g(x) = 1 - ||x||
        X: n x d torch tensor
        """
        gval = X.prod(axis=1) # size [n] torch tensor 
        return gval

    def gradX(self, X):
        """
        Compute the gradient with respect to X in g(X).
        X: n x d
        Return a numpy array of size n x d.
        """
        g_inv = 1./(X.prod(axis=1) + self.eps) 
        Grad = torch.einsum('i,ij->ij', g_inv, X)   
        return Grad
    
    
    def grad_log(self, X):
        """
        Compute the gradient with respect to X in g(X).
        X: n x d
        Return a numpy array of size n x d.
        """
#        Grad =  - torch.einsum('i,ij->ij', ((X**2).sum(axis=1)) , X)
        Grad =  self.gradX(X)
        Xinv = 1./(self.eval(X) + self.eps)
        grad_log =  torch.einsum('i,ij->ij', Xinv, Grad)   
        return grad_log




class G_Mirror_negent():
    """
    Auxilary function based on mirror Stein operator Shi et al. 2021
    In mirrored Stein discrepancy 
    g(x) = \nabla^2 \psi^{-1}
    
    """
    def __init__(self,eps=1e-7):
        self.eps = eps

    def eval(self, X):
        """
        X: n x d torch tensor
        return 1/\sum(1/x_i)
        """
        gval = 1./(1./X).sum(axis=1) # size [n] torch tensor 
        return gval

    def gradX(self, X):
        """
        Compute the gradient with respect to X in g(X).
        X: n x d
        Return a numpy array of size n x d.
        """
        g_inv = 1./(X.prod(axis=1) + self.eps) 
        Grad = torch.einsum('i,ij->ij', g_inv, X)   
        return Grad
    
    
    def grad_log(self, X):
        """
        Compute the gradient with respect to X in g(X).
        X: n x d
        Return a numpy array of size n x d.
        """
#        Grad =  - torch.einsum('i,ij->ij', ((X**2).sum(axis=1)) , X)
        Grad =  self.gradX(X)
        Xinv = 1./(self.eval(X) + self.eps)
        grad_log =  torch.einsum('i,ij->ij', Xinv, Grad)   
        return grad_log
