#!/bin/sh

#$ -l h_rt=10:00:00
#$ -S /bin/bash

. /etc/profile
module add R/4.1.0 
R CMD BATCH --no-save --vanilla test_2_3.R
