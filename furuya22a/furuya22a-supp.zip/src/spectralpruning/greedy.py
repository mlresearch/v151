import numpy as np


def step_greedy(obj, sub_F, sub_J):
    r"""One-step procedure of the greedy algorithm.

    Args:
        obj : Some set function to minimize.
        sub_F ([int]): Full index set :math:`F`.
        sub_J ([int]): Temporary selected sub index set :math:`J`.

    Returns:
        [int]: Selected sub index set for next step.
    """
    # Calculate the objective function for all candidates as next index set
    sub_J_ = np.array([np.union1d(sub_J, i) for i in np.setdiff1d(sub_F, sub_J)], dtype="int")
    obj_next = np.array([obj(sub) for sub in sub_J_])
    # Choose the next index set which minimize the objective function
    idx_next = np.array(obj_next).argmin()
    return sub_J_[idx_next]


def layer_greedy(obj, m_sharp, sub_F, stop_greedy=False):
    r"""The greedy algorithm for 1-dim index set.

    Args:
        obj : Some set function to minimize.
        m_sharp (int): Desired size of index set :math:`m^\#`.
        sub_F ([int]): Full index set :math:`F`.
        stop_greedy (Bool): Stop the greedy iteration when the size of index set reaches `m_sharp` if True.
    """
    # Begin with empty index set
    sub = []
    sub_all = []
    if stop_greedy:
        stop = m_sharp
    else:
        stop = len(sub_F)
    # Iterate step greedy procedure
    for _ in range(stop):
        sub = step_greedy(obj, sub_F, sub)
        sub_all.append(sub)

    return sub_all[m_sharp - 1], sub_all
