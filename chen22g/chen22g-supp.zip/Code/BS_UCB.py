# -*- coding: utf-8 -*-
import numpy as np
import time

##############################################################################
#UCB Normal rewards
# start = time.time()
sample = 1000
T = 100
# mu = np.array([1,1.5]) #normal mean
# sigma = np.array([1,1])
mu = np.array([2,2.5,3,3.5]) #normal mean
sigma = np.array([2,1,1,2])
K = mu.size
muhat21 = np.zeros([K,sample])
error21 = np.zeros([K,sample])
R = np.zeros([sample,T])
I = np.zeros([sample,T])

for i in range(K):
    I[:,i] = i

for s in range(sample):  
    UCB = np.zeros([K,T])

    for t in range(K):
        R[s,t] = np.random.normal(mu[np.int(I[s,t])],sigma[i])
    for i in range(K):
        UCB[i,t]= np.sum(R[s,:t+1][I[s,:t+1]==i])/np.where(I[s,:t+1]==i)[0].size+np.sqrt(np.log(t)/np.where(I[s,:t+1]==i)[0].size)
    for t in range(K,T):    
        I[s,t] = np.argmax(UCB[:,t-1])   
        R[s,t] = np.random.normal(mu[np.int(I[s,t])],sigma[np.int(I[s,t])])       
        for i in range(K):
            UCB[i,t]= np.sum(R[s,:t+1][I[s,:t+1]==i])/np.where(I[s,:t+1]==i)[0].size+np.sqrt(np.log(t)/np.where(I[s,:t+1]==i)[0].size)
    for i in range(K):
        muhat21[i, s] = np.sum(R[s][I[s]==i])/np.where(I[s]==i)[0].size
    error21[:,s] = muhat21[:, s] - mu
bias21 = np.mean(error21, axis=1)  

print('bias is', np.round(bias21,4)) 
print('muhat is', np.round(np.mean(muhat21, axis=1),4))
# np.save('bias21.npy', bias21)
# np.save('muhat21.npy', muhat21)
# np.save('R21.npy', R)
# np.save('I21.npy', I)
# np.savetxt('bias21.dat',np.transpose(bias21.reshape(2,1)),header='arm1,arm2',delimiter=',',newline='\n')
# np.savetxt('muhat21.dat',np.transpose(muhat21),header='arm1,arm2',delimiter=',',newline='\n')
np.save('mulbias21.npy', bias21)
np.save('mulmuhat21.npy', muhat21)
np.save('mulR21.npy', R)
np.save('mulI21.npy', I)
np.savetxt('mulbias21.dat',np.transpose(bias21.reshape(4,1)),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')
np.savetxt('mulmuhat21.dat',np.transpose(muhat21),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')
 
############################################################################### 
#MB
muhatmb21 = np.zeros([K,sample])
errormb21 = np.zeros([K,sample])
B = 1000

for s in range(sample):
    print('MB nomral sample is', s+1)
    mub = np.zeros(K)
    varb = np.zeros(K)
    for i in range(K):
        mub[i] =  np.mean(R[s][I[s]==i])
        varb[i] = np.var(R[s][I[s]==i])
        
    muboots = np.zeros([K,B])
    Rmb = np.zeros([B,T])
    Imb = np.zeros([B,T])
    for i in range(K):       
        Imb[:,i] = i
    for b in range(B):
        UCB = np.zeros([K,T])   
        for t in range(K):
            # W = np.random.normal(0,1,size=(np.where(I[s]==np.int(Imb[b,t]))[0].size))
            # Rmb[b,t] = np.dot(W, R[s][I[s]==np.int(Imb[b,t])]-np.mean(R[s][I[s]==np.int(Imb[b,t])]))/np.sqrt(np.where(I[s]==np.int(Imb[b,t]))[0].size)+np.mean(R[s][I[s]==np.int(Imb[b,t])])
            Rmb[b,t] = np.random.normal(mub[np.int(Imb[b,t])],np.sqrt(varb[np.int(Imb[b,t])]))                 
        for i in range(K):
            UCB[i,t]= np.sum(Rmb[b,:t+1][Imb[b,:t+1]==i])/np.where(Imb[b,:t+1]==i)[0].size+np.sqrt(np.log(t)/np.where(Imb[b,:t+1]==i)[0].size)
        for t in range(K,T):    
            Imb[b,t] = np.argmax(UCB[:,t-1])
            # W = np.random.normal(0,1,size=(np.where(I[s]==np.int(Imb[b,t]))[0].size))
            # Rmb[b,t] = np.dot(W, R[s][I[s]==np.int(Imb[b,t])]-np.mean(R[s][I[s]==np.int(Imb[b,t])]))/np.sqrt(np.where(I[s]==np.int(Imb[b,t]))[0].size)+np.mean(R[s][I[s]==np.int(Imb[b,t])])    
            Rmb[b,t] = np.random.normal(mub[np.int(Imb[b,t])],np.sqrt(varb[np.int(Imb[b,t])]))                 
            for i in range(K):
                UCB[i,t]= np.sum(Rmb[b,:t+1][Imb[b,:t+1]==i])/np.where(Imb[b,:t+1]==i)[0].size+np.sqrt(np.log(t)/np.where(Imb[b,:t+1]==i)[0].size)
        for i in range(K):
            muboots[i, b] = np.sum(Rmb[b][Imb[b]==i])/np.where(Imb[b]==i)[0].size
    muhatmb21[:,s] = np.mean(muboots,axis = 1)   
errormb21 = muhatmb21 - muhat21
biasmb21 = np.mean(errormb21, axis=1)  
muhatmb21 = muhat21 - errormb21 

print('biasmb is', np.round(biasmb21,4))
print('muhatmb is', np.round(np.mean(muhatmb21, axis=1),5))
# np.save('biasmb21.npy', biasmb21)
# np.save('muhatmb21.npy', muhatmb21)
# np.savetxt('biasmb21.dat',np.transpose(biasmb21.reshape(2,1)),header='arm1,arm2',delimiter=',',newline='\n')
# np.savetxt('muhatmb21.dat',np.transpose(muhatmb21),header='arm1,arm2',delimiter=',',newline='\n')
np.save('mulbiasmb21.npy', biasmb21)
np.save('mulmuhatmb21.npy', muhatmb21)
np.savetxt('mulbiasmb21.dat',np.transpose(biasmb21.reshape(4,1)),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')
np.savetxt('mulmuhatmb21.dat',np.transpose(muhatmb21),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')

##############################################################################
#EB
muhateb21 = np.zeros([K,sample])
erroreb21 = np.zeros([K,sample])
B = 1000

for s in range(sample):  
    print('EB normal sample is', s+1)
    muboots = np.zeros([K,B])
    Reb = np.zeros([B,T])
    Ieb = np.zeros([B,T])
    for i in range(K):       
        Ieb[:,i] = i
        
    mutemp = np.zeros([B,K])
    
    for i in range(K):
        locals()['Runiq'+str(i)]  = np.unique(R[s][I[s]==i])
        locals()['P'+str(i)] = np.zeros(locals()['Runiq'+str(i)].size)
        for j in range(locals()['Runiq'+str(i)].size):
            locals()['P'+str(i)][j] = np.where(R[s][I[s]==i]==locals()['Runiq'+str(i)][j])[0].size/np.where(I[s]==i)[0].size
    
    Rset = np.zeros([K,B,T])
    for i in range(K):
        Rset[i] = np.random.choice(locals()['Runiq'+str(i)], size=(B,T), p=locals()['P'+str(i)])
        
    for b in range(B):
        UCB = np.zeros([K,T])
        for t in range(K):
            Reb[b,t] = Rset[np.int(Ieb[b,t]),b,t]
        for i in range(K):
            UCB[i,t]= Reb[b,i]+np.sqrt(np.log(t))
        for t in range(K,T):    
            Ieb[b,t] = np.argmax(UCB[:,t-1])   
            Reb[b,t] = Rset[np.int(Ieb[b,t]),b,t]       
            for i in range(K):
                UCB[i,t]= np.sum(Reb[b,:t+1][Ieb[b,:t+1]==i])/np.where(Ieb[b,:t+1]==i)[0].size+np.sqrt(np.log(t)/np.where(Ieb[b,:t+1]==i)[0].size)
        for i in range(K):
            muboots[i, b] = np.sum(Reb[b][Ieb[b]==i])/np.where(Ieb[b]==i)[0].size
    muhateb21[:,s] = np.mean(muboots,axis = 1)        
erroreb21 = muhateb21 - muhat21
biaseb21 = np.mean(erroreb21, axis=1)  
muhateb21 = muhat21 - erroreb21 

print('biaseb is', np.round(biaseb21,4))
print('muhateb is', np.round(np.mean(muhateb21, axis=1),4))
# np.savetxt('biaseb21.dat',np.transpose(biaseb21.reshape(2,1)),header='arm1,arm2',delimiter=',',newline='\n')
# np.savetxt('muhateb21.dat',np.transpose(muhateb21),header='arm1,arm2',delimiter=',',newline='\n')
# np.savetxt('biaseb21.dat',np.transpose(biaseb21.reshape(2,1)),header='arm1,arm2',delimiter=',',newline='\n')
# np.savetxt('muhateb21.dat',np.transpose(muhateb21),header='arm1,arm2',delimiter=',',newline='\n')
# np.savetxt('mulbiaseb21.dat',np.transpose(biaseb21.reshape(4,1)),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')
# np.savetxt('mulmuhateb21.dat',np.transpose(muhateb21),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')
# np.savetxt('mulbiaseb21.dat',np.transpose(biaseb21.reshape(4,1)),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')
# np.savetxt('mulmuhateb21.dat',np.transpose(muhateb21),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')

# np.save('biaseb21.npy', biaseb21)
# np.save('muhateb21.npy', muhateb21)
# np.savetxt('biaseb21.dat',np.transpose(biaseb21.reshape(2,1)),header='arm1,arm2',delimiter=',',newline='\n')
# np.savetxt('muhateb21.dat',np.transpose(muhateb21),header='arm1,arm2',delimiter=',',newline='\n')
np.save('mulbiaseb21.npy', biaseb21)
np.save('mulmuhateb21.npy', muhateb21)
np.savetxt('mulbiaseb21.dat',np.transpose(biaseb21.reshape(4,1)),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')
np.savetxt('mulmuhateb21.dat',np.transpose(muhateb21),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')


##############################################################################
#UCB Bernoulli Rewards
sample = 1000
T = 100
# mu = np.array([0.3, 0.6]) #bernoulli mean
mu = np.array([0.4, 0.5, 0.7, 0.8]) #bernoulli mean
K = mu.size
muhat22 = np.zeros([K,sample])
error22 = np.zeros([K,sample])
R = np.zeros([sample,T])
I = np.zeros([sample,T])

for i in range(K):
    I[:,i] = i

for s in range(sample):  
    UCB = np.zeros([K,T])

    for t in range(K):
        R[s,t] = np.random.binomial(1, mu[np.int(I[s,t])])
    for i in range(K):
        UCB[i,t]= np.sum(R[s,:t+1][I[s,:t+1]==i])/np.where(I[s,:t+1]==i)[0].size+np.sqrt(np.log(t)/np.where(I[s,:t+1]==i)[0].size)
    for t in range(K,T):    
        I[s,t] = np.argmax(UCB[:,t-1])   
        R[s,t] = np.random.binomial(1, mu[np.int(I[s,t])])
        for i in range(K):
            UCB[i,t]= np.sum(R[s,:t+1][I[s,:t+1]==i])/np.where(I[s,:t+1]==i)[0].size+np.sqrt(np.log(t)/np.where(I[s,:t+1]==i)[0].size)
    for i in range(K):
        muhat22[i, s] = np.sum(R[s][I[s]==i])/np.where(I[s]==i)[0].size
    error22[:,s] = muhat22[:, s] - mu
bias22 = np.mean(error22, axis=1)  

print('bias is', np.round(bias22,4)) 
print('muhat is', np.round(np.mean(muhat22, axis=1),4))
# np.save('bias22.npy', bias22)
# np.save('muhat22.npy', muhat22)
# np.save('R22.npy', R)
# np.save('I22.npy', I)
# np.savetxt('bias22.dat',np.transpose(bias22.reshape(2,1)),header='arm1,arm2',delimiter=',',newline='\n')
# np.savetxt('muhat22.dat',np.transpose(muhat22),header='arm1,arm2',delimiter=',',newline='\n')
np.save('mulbias22.npy', bias22)
np.save('mulmuhat22.npy', muhat22)
np.save('mulR22.npy', R)
np.save('mulI22.npy', I)
np.savetxt('mulbias22.dat',np.transpose(bias22.reshape(4,1)),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')
np.savetxt('mulmuhat22.dat',np.transpose(muhat22),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')


############################################################################### 
#MB
muhatmb22 = np.zeros([K,sample])
errormb22 = np.zeros([K,sample])
B = 1000

for s in range(sample):
    print('MB bernoulli sample is', s+1)
    muboots = np.zeros([K,B])
    Rmb = np.zeros([B,T])
    Imb = np.zeros([B,T])
    for i in range(K):       
        Imb[:,i] = i
    for b in range(B):
        UCB = np.zeros([K,T])   
        for t in range(K):
            W = np.random.normal(0,1,size=(np.where(I[s]==np.int(Imb[b,t]))[0].size))
            Rmb[b,t] = np.dot(W, R[s][I[s]==np.int(Imb[b,t])]-np.mean(R[s][I[s]==np.int(Imb[b,t])]))/np.sqrt(np.where(I[s]==np.int(Imb[b,t]))[0].size)+np.mean(R[s][I[s]==np.int(Imb[b,t])])
        for i in range(K):
            UCB[i,t]= np.sum(Rmb[b,:t+1][Imb[b,:t+1]==i])/np.where(Imb[b,:t+1]==i)[0].size+np.sqrt(np.log(t)/np.where(Imb[b,:t+1]==i)[0].size)
        for t in range(K,T):    
            Imb[b,t] = np.argmax(UCB[:,t-1])
            W = np.random.normal(0,1,size=(np.where(I[s]==np.int(Imb[b,t]))[0].size))
            Rmb[b,t] = np.dot(W, R[s][I[s]==np.int(Imb[b,t])]-np.mean(R[s][I[s]==np.int(Imb[b,t])]))/np.sqrt(np.where(I[s]==np.int(Imb[b,t]))[0].size)+np.mean(R[s][I[s]==np.int(Imb[b,t])])    
            for i in range(K):
                UCB[i,t]= np.sum(Rmb[b,:t+1][Imb[b,:t+1]==i])/np.where(Imb[b,:t+1]==i)[0].size+np.sqrt(np.log(t)/np.where(Imb[b,:t+1]==i)[0].size)
        for i in range(K):
            muboots[i, b] = np.sum(Rmb[b][Imb[b]==i])/np.where(Imb[b]==i)[0].size
    muhatmb22[:,s] = np.mean(muboots,axis = 1)   
errormb22 = muhatmb22 - muhat22
biasmb22 = np.mean(errormb22, axis=1)  
muhatmb22 = muhat22 - errormb22

print('biasmb is', np.round(biasmb22,4))
print('muhatmb is', np.round(np.mean(muhatmb22, axis=1),4))
# np.save('biasmb22.npy', biasmb22)
# np.save('muhatmb22.npy', muhatmb22)
# np.savetxt('biasmb22.dat',np.transpose(biasmb22.reshape(2,1)),header='arm1,arm2',delimiter=',',newline='\n')
# np.savetxt('muhatmb22.dat',np.transpose(muhatmb22),header='arm1,arm2',delimiter=',',newline='\n')
np.save('mulbiasmb22.npy', biasmb22)
np.save('mulmuhatmb22.npy', muhatmb22)
np.savetxt('mulbiasmb22.dat',np.transpose(biasmb22.reshape(4,1)),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')
np.savetxt('mulmuhatmb22.dat',np.transpose(muhatmb22),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')


##############################################################################
#EB
muhateb22 = np.zeros([K,sample])
erroreb22 = np.zeros([K,sample])
B = 1000

for s in range(sample):  
    print('EB bernoulli sample is', s+1)
    muboots = np.zeros([K,B])
    Reb = np.zeros([B,T])
    Ieb = np.zeros([B,T])
    for i in range(K):       
        Ieb[:,i] = i
        
    mutemp = np.zeros([B,K])
    
    for i in range(K):
        locals()['Runiq'+str(i)]  = np.unique(R[s][I[s]==i])
        locals()['P'+str(i)] = np.zeros(locals()['Runiq'+str(i)].size)
        for j in range(locals()['Runiq'+str(i)].size):
            locals()['P'+str(i)][j] = np.where(R[s][I[s]==i]==locals()['Runiq'+str(i)][j])[0].size/np.where(I[s]==i)[0].size
    
    Rset = np.zeros([K,B,T])
    for i in range(K):
        Rset[i] = np.random.choice(locals()['Runiq'+str(i)], size=(B,T), p=locals()['P'+str(i)])
        
    for b in range(B):
        UCB = np.zeros([K,T])
        for t in range(K):
            Reb[b,t] = Rset[np.int(Ieb[b,t]),b,t]
        for i in range(K):
            UCB[i,t]= Reb[b,i]+np.sqrt(np.log(t))
        for t in range(K,T):    
            Ieb[b,t] = np.argmax(UCB[:,t-1])   
            Reb[b,t] = Rset[np.int(Ieb[b,t]),b,t]       
            for i in range(K):
                UCB[i,t]= np.sum(Reb[b,:t+1][Ieb[b,:t+1]==i])/np.where(Ieb[b,:t+1]==i)[0].size+np.sqrt(np.log(t)/np.where(Ieb[b,:t+1]==i)[0].size)
        for i in range(K):
            muboots[i, b] = np.sum(Reb[b][Ieb[b]==i])/np.where(Ieb[b]==i)[0].size
    muhateb22[:,s] = np.mean(muboots,axis = 1)        
erroreb22 = muhateb22 - muhat22
biaseb22 = np.mean(erroreb22, axis=1)
muhateb22 = muhat22 - erroreb22 

print('biaseb is', np.round(biaseb22,4))
print('muhateb is', np.round(np.mean(muhateb22, axis=1),4))
# np.save('biaseb22.npy', biaseb22)
# np.save('muhateb22.npy', muhateb22)
# np.savetxt('biaseb22.dat',np.transpose(biaseb22.reshape(2,1)),header='arm1,arm2',delimiter=',',newline='\n')
# np.savetxt('muhateb22.dat',np.transpose(muhateb22),header='arm1,arm2',delimiter=',',newline='\n')
np.save('mulbiaseb22.npy', biaseb22)
np.save('mulmuhateb22.npy', muhateb22)
np.savetxt('mulbiaseb22.dat',np.transpose(biaseb22.reshape(4,1)),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')
np.savetxt('mulmuhateb22.dat',np.transpose(muhateb22),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')


# # end = time.time()
# # print(end-start)

