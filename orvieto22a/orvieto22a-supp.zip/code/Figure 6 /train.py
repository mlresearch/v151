#######################################
## Run experiments for Fig 6 (right) ##
#######################################

# This script needs four inputs
# 1. optim in [Adam,RMSprop, SGD]             <- optimizer
# 2. learning rate in R                       <- Skip connections
# 3. batch size in N                          <- If True: width=sqrt(depth), else width=depth

### Tensorboard needed for visualization

######################################
######################################
######################################



import numpy as np
import IPython
import torch
import torch.optim as optim
from tensorboardX import SummaryWriter
import datetime
import sys

import math
import random

import torchvision
import torchvision.transforms as transforms


class MyDataset(torch.utils.data.Dataset):
    def __init__(self, X,Y):
        super().__init__()

        self.X, self.Y = X,Y 
        self.N= self.X.shape[0]
        
    def get_item(self, idx):        
        return self.X[idx].to(device), self.Y[idx].to(device)

    def get_all(self):
        return self.X,self.Y



def get_params_grad(model):
    """
    get model parameters and corresponding gradients
    """
    params = []
    grads = []
    for param in model.parameters():
        if not param.requires_grad:
            continue
        params.append(param)
        grads.append(0. if param.grad is None else param.grad + 0.)
    return params, grads


def flat_params(model):
    flat_data = []
    for p in model.parameters():
        flat_data.append(p.data.view(-1))
    return torch.cat(flat_data)

def flat_gradient(net):
    grad_dict  = {k:v.grad for k, v in zip(net.state_dict(), net.parameters())}
    grad_vec = torch.cat([g.contiguous().view(-1) for k,g in grad_dict.items()])
    return grad_vec

class non_linear_MLP(torch.nn.Module):
    def __init__(self, d_in,d_hidden,d_out,num_hidden_layers,xavier_init,act=torch.nn.ReLU(),seed=None):
        super(non_linear_MLP, self).__init__()
        
        self.act=act
        self.W_in = torch.nn.Linear(d_in, d_hidden,bias=False)
        hidden_layers=[]

        for i in range(num_hidden_layers):
            hidden_layers+=[torch.nn.Linear(d_hidden,d_hidden,bias=False),torch.nn.BatchNorm1d(d_hidden),act]
        self.hidden_layers=torch.nn.Sequential(*hidden_layers)

        self.W_out = torch.nn.Linear(d_hidden, d_out,bias=False)

        if xavier_init:
            for p in self.parameters():
                torch.nn.init.kaiming_uniform_(p, nonlinearity='relu')
               
    def forward(self, x):
        return self.W_out(self.hidden_layers(self.act(self.W_in(x))))

def train_net(trainloader,testloader,my_model,optimizer,optim_method,lr,n_epochs = 100, batch_size=32):
    
    ########################################
    ########### Tensorboard log ############
    ########################################
    
    writer = SummaryWriter(f'FMNIST_logs/train/MLP/{optim_method}/lr: {lr}')

    iteration=0

    ########################################
    ###########   train model   ############
    ########################################

    loss_fn=torch.nn.CrossEntropyLoss() 
    my_model.train()
    for epoch in range(n_epochs):    
        print("\r{} {}".format(" Epoch :", epoch), end=" "*10, flush=True)   


        with torch.no_grad():
            my_model.eval()
            test_acc=0
            for i,batch in enumerate(testloader):
                x,y=batch[0].to(device),batch[1].to(device)
                y_pred=my_model.forward(x.view(x.shape[0], -1)) 
                test_acc+=1.0*torch.sum(torch.max(y_pred, 1)[1]==y)/len(y)
                if i==5:
                    test_acc=test_acc/6
                    break
            writer.add_scalar('stats/test_accuracy',test_acc,iteration)
        
        for i,batch in enumerate(trainloader):
            my_model.train()
            optimizer.zero_grad()
            x,y=batch[0].to(device),batch[1].to(device)
            y_pred=my_model.forward(x.view(x.shape[0], -1)) 
            loss = loss_fn(y_pred,y.long())
            loss.backward()
            grad=flat_gradient(my_model)
            acc=1.0*torch.sum(torch.max(y_pred, 1)[1]==y)/len(y)
            
            if iteration==0:
                writer.add_scalar('stats/grad_norm',torch.norm(grad).item(),iteration)  
                writer.add_scalar('stats/training_loss', loss.item(), iteration)
                writer.add_scalar('stats/accuracy',acc,iteration)
            
  
            optimizer.step()

            iteration=iteration+1
      

        

        writer.add_scalar('stats/grad_norm',torch.mean(torch.abs(grad)).item(),iteration)  
        writer.add_scalar('stats/training_loss', loss.item(), iteration)
        writer.add_scalar('stats/accuracy',acc,iteration)

    writer.close()
    return  

time = None

def main(optim_method,lr,bs):


    global device
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    ########################################################################
    ########################### 1. Setup Model  ############################
    ########################################################################
    depth=128
    width=32#int(np.sqrt(depth))
    my_model=non_linear_MLP(28**2,width,width,depth,True).to(device)
    
    ########################################################################
    ########################### 2. load data  ##############################
    ########################################################################
    transform = transforms.Compose([transforms.ToTensor(),transforms.Normalize((0.5), (0.5))])#m,m,m,std,std,std

    trainset = torchvision.datasets.FashionMNIST(root='./data', train=True,download=True, transform=transform)
    testset = torchvision.datasets.FashionMNIST(root='./data', train=False,download=True, transform=transform)

    #train_ds = MyDataset(torch.Tensor(trainset.data),torch.Tensor(trainset.targets))
    trainloader = torch.utils.data.DataLoader(trainset, batch_size=bs,shuffle=True,pin_memory=True)
    testloader = torch.utils.data.DataLoader(testset, batch_size=bs,shuffle=True,pin_memory=True)


    ########################################
    ########### Setup  Optimizer ###########   
    ########################################
    
    #optimizer = optim.Adam(my_model.parameters(), lr=lr) if optim_method=="Adam" else optim.SGD(my_model.parameters(), lr=lr) 
    if optim_method=="Adam":
        optimizer = optim.Adam(my_model.parameters(), lr=lr)
    elif optim_method=="RMSprop" or optim_method=="RMSProp":
        optimizer = optim.RMSprop(my_model.parameters() lr=lr)
    elif optim_method=="Momentum":
        optimizer = optim.SGD(my_model.parameters(),momentum=0.9,lr=lr) 

    else:  
        optimizer = optim.SGD(my_model.parameters(),lr=lr) 

    ########################################################################
    ############################## 3. train network ########################
    ########################################################################

    train_net(trainloader,testloader,my_model,optimizer,optim_method,lr,batch_size=bs)
        
   
    print("done!")

if __name__ == "__main__":
    a=str(sys.argv[2])
    b=float(sys.argv[3])
    c=int(sys.argv[4])
    main(a,b,c)


    