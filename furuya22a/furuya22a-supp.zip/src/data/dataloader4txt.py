import torch
from torchtext.data.utils import get_tokenizer
from torchtext.datasets import PennTreebank
from torchtext.vocab import build_vocab_from_iterator


def build_vocab(path: str):
    train_iter = PennTreebank(root=path, split="train")
    tokenizer = get_tokenizer("basic_english")
    vocab = build_vocab_from_iterator(map(tokenizer, train_iter), specials=["<unk>"])
    # vocab = build_vocab_from_iterator(map(my_tokenizer, train_iter), specials=["<unk>"])  # worse than without eos
    vocab.set_default_index(vocab["<unk>"])
    return vocab


def my_tokenizer(line: str):
    tokenizer = get_tokenizer("basic_english")
    return tokenizer(line) + ["<eos>"]


class BatchfiedPTB(torch.utils.data.Dataset):
    """Create batchfied PTB dataset of certain split."""

    def __init__(self, path, split, vocab, batch_size, bptt):
        raw_text_iter = PennTreebank(root=path, split=split)
        tokenizer = get_tokenizer("basic_english")
        data = [torch.tensor(vocab(tokenizer(item)), dtype=torch.long) for item in raw_text_iter]
        data = torch.cat(tuple(filter(lambda t: t.numel() > 0, data)))
        n_total = data.nelement()

        # sequence size
        seq_size = (n_total // batch_size) + (n_total % batch_size != 0)
        # additional sequence size for bptt division
        add_seq = 0 if (seq_size % bptt == 0) else bptt - seq_size % bptt
        # additional data for completion
        add_end = 0 if (seq_size + add_seq - n_total % seq_size == 0) else seq_size + add_seq - n_total % seq_size
        data = torch.cat([data, data[:add_end]])
        # make datasest arranged to [seq_size + add_seq, batch_size]
        offsets = [i * seq_size for i in range(batch_size)]
        data = torch.cat([data[offset : offset + seq_size + add_seq] for offset in offsets])
        data = data.view(batch_size, -1).t().contiguous()

        self.dataset = data
        self.datanum = data.size(0) - 1
        self.n_total = n_total

    def __len__(self):
        return self.datanum

    def __getitem__(self, idx):
        out_data = self.dataset[idx]
        out_label = self.dataset[idx + 1]
        return out_data, out_label
