Illustration1 directory contains two sub-directories: IID and Correlated
Similar directories are present in Illustration2 also.

Dependencies: Download and setup cvxr package using http://cvxr.com/cvx/download/


In the IID directory, run the matlab script 'Run_File_IID.m'.
Similarly, run 'Run_File_corr.m'
Both script does the following:
(i) Consider a 2D grid of nodes (size Nnodes)
(ii) For a value of Nnodes, load the generative model (h, scaling factors)
(iii) Choose N based on C, delta as suggested in the article.
(iv) For simplicity, 'n' value is fixed to n_min. Otherwise n value should be incremented until we get 
exact reconstruction for all 45 trials.
(v) For every trial, solve Regularized Wiener Filter Estimate and reconstruct the graph.
(vi) Compute the relative error
(vii) At the end the program will display the number of successful reconstructions out of 45 trials.

dataFit.m:
a linear fit is estimated between n_min and log(p)

