clear all


f = 0.5*pi; %Frequency at which the toplogy is recnstructed
d= 8; %% maximum number of one-hop and two-hop neighbors of a node in the graph. For a 2D grid, d=8
epsilon = 0.05; %% accuracy of reconstruction
num_trial = 45; %% number of trials 
Success = zeros(1,num_trial);

for Nnodes = [4,16,36]   %Nondes is the size of the 2D grid. Change this if you want to run for specific graph size
    
%% Deciding the value of n: The value of n is incremented in steps of 50000 in the range [2e5, 30e5]. 
%%The minimum value of n such that the graph is reconstructed exactly for
%%all the trials. For ease of running, the minimum value of n is provided
%%for various sizes of the network. 

if Nnodes == 4
    n = 12e5; % for 4 node network;
elseif  Nnodes ==16
    n = 22e5; % for 4 node network;
elseif Nnodes == 36
        n = 32e5; % for 4 node network;
else 
        continue
end


%% Load the Model
load(strcat('p',num2str(Nnodes),'.mat'));

%%%
h = h*0.9;
%%%
%% Model based quantities from Generative Model Equations
[IPSD_analytical,PSDX_analytical,WF,H] = Model_at_f(Adj,h,f,E_factor);
%% System constants defined in the paper 
[L,U,m_i,n_bound,m] = Constants_at_f(IPSD_analytical,WF, epsilon,d);
[C,delta] = C_delta(E_factor,h);

%% Choice of N defined in the paper
N = floor(4*C*real(U)*delta/(1-delta)^2);
%% Choice of the regularization parameter

Lambda = real(4*sqrt( ( ( 3+24*sqrt(3)*U*C/(1/delta-1) )*log(8*(Nnodes-1)^2/epsilon)  )/(n*L)    )   )/33;

%% Graph reconstruction for every trial
for trial = 1:num_trial

%% IID samples and Phi_Hat calculations
Big_Matrix = Covaraiance_corr(n,E_factor,N,h,f);

%% Regularized Wiener Filter
RWFE = zeros(Nnodes,Nnodes);
for i= 1:Nnodes
i_bar = setdiff(1:Nnodes,i);
R=Big_Matrix(i_bar,i_bar);
P1 = Big_Matrix(i_bar,i);
P2 = Big_Matrix(i,i_bar);
cvx_begin 
variable param(Nnodes-1,1) complex 
minimize 1*(real(param'*R*param) -real(param'*P1) -real(P2*param)) +real(Lambda*sum(abs(param)))       
cvx_end
RWFE(i,i_bar)= param;
end
%% Reconstructing the Topology from the Winer filter estimate
Recon_Top = zeros(Nnodes,Nnodes);
for i = 1:Nnodes
   for j = i+1:Nnodes 
       if abs(imag(RWFE(i,j)))+abs(imag(RWFE(j,i)))>m
            Recon_Top(i,j)=1;Recon_Top(j,i)=1;
       end 
   end
end
error = sum(sum(abs(Recon_Top-Adj)))/sum(sum(Adj));
if error==0
   Success(trial) = 1; 
else
    disp('error');                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              
end
end

Probability = sum(Success==1)/length(Success);
Confidence = std(Success)/sqrt(length(Success));
disp(strcat("Graph Reconstruction is successful with ",num2str(sum(Success==1)), "out of ", num2str(length(Success))));
Success
save(strcat('Data',num2str(Nnodes)),'Big_Matrix', 'RWFE','WF','IPSD_analytical','L','U','C','delta','Success','epsilon','n','Lambda','N','Adj','Recon_Top');
    
end

%% Run Plot1.m for generating the plot



