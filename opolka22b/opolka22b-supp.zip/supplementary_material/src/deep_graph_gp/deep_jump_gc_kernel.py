import numpy as np
import gpflow
from gpflow import Parameter
from gpflow import covariances as covs
import tensorflow as tf
import tensorflow_probability as tfp

from inducing_points import NodeInducingPoints


class DeepGraphJumpConvolutional(gpflow.kernels.base.Kernel):

    def __init__(self, base_kernel, sparse, num_convs):
        super().__init__([1])
        self.base_kernel = base_kernel
        self.sparse = sparse
        self.num_convs = num_convs
        self.weights = [Parameter(np.array([(1.0/(i+2.0))]),
                                  transform=tfp.bijectors.Sigmoid(),
                                  name=f"weight_{i+1}")
                        for i in range(num_convs)]

        # Setup for sparse vs dense operations
        if sparse:
            self.matmul_f = tf.sparse.sparse_dense_matmul
            self.eye_f = tf.sparse.eye
            self.add_f = tf.sparse.add
        else:
            self.matmul_f = tf.matmul
            self.eye_f = tf.eye
            self.add_f = tf.add

        self.conv_mat = None

    def set_subgraph(self, conv_matrix):
        self.conv_mat = conv_matrix
        if self.sparse is False and isinstance(conv_matrix, tf.sparse.SparseTensor):
            self.conv_mat = tf.sparse.to_dense(tf.sparse.reorder(conv_matrix))

    def K(self, X, Y=None, presliced=False):
        """
        X are node features of the current subgraph of shape (N, D).
        :return: Covariance matrix of shape (N, N).
        """
        assert Y is None, "Unexpected argument Y"
        num_nodes = self.conv_mat.shape[0]
        num_samples = X.shape[0] // num_nodes

        cov_list = []   # Collects cov matrices with different number of convs
        cov = self.base_kernel.K(X)                                                 # Shape (S*N, S*N)
        cov_list.append(cov)

        cov = tf.reshape(cov, [num_samples, num_nodes, num_samples, num_nodes])     # Shape (S, N, S, N)
        cov = tf.transpose(cov, [0, 2, 1, 3])                                       # Shape (S, S, N, N)
        for i in range(self.num_convs):
            conv_mat = self.add_f(self.weights[i] * self.conv_mat,
                                  (1.0 - self.weights[i]) * self.eye_f(self.conv_mat.shape[0]))
            cov = self.matmul_f(conv_mat, cov)
            cov = self.matmul_f(conv_mat, cov, adjoint_b=True)

            reshaped_cov = tf.transpose(cov, [0, 2, 1, 3])                          # Shape (S, N, S, N)
            reshaped_cov = tf.reshape(reshaped_cov,
                                      [num_samples * num_nodes,
                                       num_samples * num_nodes])                    # Shape (S*N, S*N)
            cov_list.append(reshaped_cov)
        return cov_list

    def K_diag(self, X, presliced=False):
        cov_list = self.K(X)
        return [tf.linalg.diag_part(cov) for cov in cov_list]

    def Kzx(self, Z, X):
        """
        Z are the inducing points of shape (M, D) and X are the node features
        of the current subgraph of shape (N, D).
        :return: Covariance matrix of shape (M, N).
        """
        cov_list = []
        cov = self.base_kernel.K(X, Z)
        cov_list.append(tf.transpose(cov))

        cov = tf.reshape(cov, [-1, self.conv_mat.shape[0], Z.shape[0]])     # Shape (S, N, M)
        for i in range(self.num_convs):
            conv_mat = self.add_f(self.weights[i] * self.conv_mat,
                                  (1.0 - self.weights[i]) * self.eye_f(self.conv_mat.shape[0]))
            cov = self.matmul_f(conv_mat, cov)

            reshaped_cov = tf.reshape(cov, [-1, Z.shape[0]])
            reshaped_cov = tf.transpose(reshaped_cov)
            cov_list.append(reshaped_cov)
        return cov_list

    def Kzz(self, Z, jitter=None):
        cov = self.base_kernel.K(Z)
        if jitter is not None:
            cov = cov + jitter * tf.eye(cov.shape[0], dtype=cov.dtype)
        return cov


@covs.Kuu.register(NodeInducingPoints, DeepGraphJumpConvolutional)
def Kuu_graph_polynomial(inducing_variable, kernel, jitter=None):
    """
    Computes the covariance matrix between the inducing points (which are not
    associated with any node).
    :param inducing_variable: Set of inducing points of type
    NodeInducingPoints.
    :param kernel: Kernel of type GraphPolynomial.
    :return: Covariance matrix between the inducing variables.
    """
    return kernel.Kzz(inducing_variable.Z, jitter)


@covs.Kuf.register(NodeInducingPoints, DeepGraphJumpConvolutional, tf.Tensor)
def Kuf_graph_polynomial(inducing_variable, kernel, X):
    """
    Computes the covariance matrix between inducing points (which are not
    associated with any node) and normal inputs.
    :param inducing_variable: Set of inducing points of type
    NodeInducingPoints.
    :param kernel: Kernel of type GraphPolynomial.
    :param X: Normal inputs. Note, however, that to simplify the
    implementation, we pass in the indices of the nodes rather than their
    features directly.
    :return: Covariance matrix between inducing variables and inputs.
    """
    return kernel.Kzx(inducing_variable.Z, X)