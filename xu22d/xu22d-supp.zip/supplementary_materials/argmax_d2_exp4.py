import numpy as np
def pricing_d2exp4(x, theta, vec_f, Md, gamma, noise_bound = 1):
    i_u = int(np.dot(x, theta)/gamma)*gamma
    largest_i = 0
    r_max = 0
    for i in range(Md + 1):
        r_i = (i_u+i)*gamma*(1-vec_f[i])
        if r_i > r_max:
            largest_i = i
            r_max = r_i
    return int(max(i_u + largest_i - (1+noise_bound), 1))
