from loaders.featureloader import *
import tensorflow.keras as K

class PairDataLoader(K.utils.Sequence):
    def __init__(self, pair_items, pair_labels, featurizer, interaction_counts, n_consecutive_pair, shuffle = True, batch_size = 1000):
        self.pair_items, self.pair_labels = pair_items, pair_labels
        self.featurizer = featurizer
        self.shuffle, self.batch_size = shuffle, batch_size
        self.indexes = np.arange(len(self.pair_items))
        self.coocurrence_count = interaction_counts
        self.n_occurrence = n_consecutive_pair

    def __len__(self):
        return int(np.floor(len(self.pair_items) / self.batch_size))

    def __getitem__(self, index):
        indexes = self.indexes[index * self.batch_size:(index + 1) * self.batch_size]
        X, Y = self.data_generator(indexes)
        return X, Y

    def on_epoch_end(self):
        self.indexes = np.arange(len(self.pair_items))
        if self.shuffle:
            np.random.shuffle(self.indexes)

    def data_generator(self, indexes):
        item_list_A = [self.pair_items[indexes[i]][0] for i in range(len(indexes))]
        item_list_B = [self.pair_items[indexes[i]][1] for i in range(len(indexes))]

        features_A, id_A = self.featurizer.featurize(item_list_A)
        features_B, id_B = self.featurizer.featurize(item_list_B)

        Y = 1.0 * np.asarray([1.0 * self.pair_labels[indexes[i]] for i in range(len(indexes))]).astype(np.float32)

        pair_index = [(min(self.pair_items[indexes[i]][0], self.pair_items[indexes[i]][1]),
                       max(self.pair_items[indexes[i]][0], self.pair_items[indexes[i]][1])) for i in range(len(indexes))]

        # statistics that might be useful -- but not for now

        counts = []
        eps = 1.0
        for pos in range(len(pair_index)):
            if pair_index[pos] not in self.coocurrence_count:
                counts.append(eps)
            else:
                counts.append(self.coocurrence_count[pair_index[pos]] + eps)

        C = 1.0 * np.asarray(counts).astype(np.float32)
        P = C / (self.n_occurrence * (1 + eps))

        # end

        output = np.hstack([Y.reshape(-1, 1), C.reshape(-1, 1), P.reshape(-1, 1)])
        return [id_A, features_A, id_B, features_B], output