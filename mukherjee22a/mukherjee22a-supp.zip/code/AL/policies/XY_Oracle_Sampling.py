

import numpy as np
from math import pi
import itertools
import click
import multiprocessing as mp
import sys
#from cvxpy import *
import cvxpy as cp
import pickle


from environment.LinBandit_env import LinBandit_env


class XY_Oracle_Sampling(object):
    
    
    
    
    def __init__(self, env):
        '''
        Constructor
        '''
        self.T = env.T
        self.num_trials = env.num_trials
        self.num_dims = env.num_dims
        self.num_arms = env.num_arms
        self.rec = 1 # record err every rec samples
        #self.unif_sample_complexity = []
        self.sigma = env.sigma
        self.theta_star = env.theta_star
        self.best_arm = env.best_arm
        self.X = env.X
        self.delta = env.delta
        
        self.alpha = 0.1
        
        self.env = env
        
        
    def init_XY_Static_Sampling(self, env):
        
        self.theta_star = env.theta_star
        self.best_arm = env.best_arm
        self.X = env.X
        

    #get optimal ratio
    def optimal_ratio(self,X,theta):
        Y = self.const_Y(X,theta)
        Y = np.array([y/y.dot(theta) for y in Y])
        print(Y)
        K,d = X.shape
        C = cp.Variable((K,1))
        #C = np.ones(K)
        #A = np.eye(d)
        A = np.zeros((d,d))
        for i in range(K):
            A = A + C[i]* np.expand_dims(X[i,:],-1).dot(np.expand_dims(X[i,:],axis=0))
        tmp = cp.bmat([[cp.matrix_frac(y, A) for y in Y]])
        obj = cp.Minimize(cp.max(tmp))
        constraints = [C>=0, cp.sum(C) == 1.0e3]
        prob = cp.Problem(obj, constraints)
        #prob.solve(solver='SCS', max_iters = 10000, verbose=True)
        prob.solve()
        return np.array(C.value)[:,0]

    #Add observation
    def add_observe(self,A,b,x,theta,sigma):
        A += np.expand_dims(x,-1).dot(np.expand_dims(x,axis=0))
        b += self.observe(x,theta,sigma)*x
        return A,b

    def observe(self,x,theta,sigma):
        return x.dot(theta) + np.random.randn()*sigma


    def next_arm_score(self,A,x,Y,theta,varbose=False):
        A_tmp = A + np.expand_dims(x,-1).dot(np.expand_dims(x,axis=0))
        A_inv_tmp = np.linalg.inv(A_tmp)
        res = []
        for y in Y:
            tmp1 = y.T.dot(A_inv_tmp.dot(y))
            tmp2 = y.dot(theta)
            res.append(np.sqrt(tmp1)/tmp2)
        if(varbose):
            print(res)
        return np.max(res)

    def max_randomly(self,a):
        a = np.array(a)
        
    #search for next arm in greedy manner
    #returns arm id
    
    def search_next_arm(self,A,X,Y,theta,verbose=False):
        score = []
        for x in X:
            score.append(self.next_arm_score(A,x,Y,theta))
        score= np.array(score)
        idx = np.random.choice(np.arange(len(X))[score <= np.min(score)*(1.0+1.0e-10)])
        if(verbose):
            print("scores=")
            print(score)
            print("candidate=")
            print(np.arange(len(X))[score <= np.min(score)])
        return idx
    
    def search_next_arm_from_opt_ratio(self,arm_count,opt_ratio):
        return np.argmin((arm_count+1)/opt_ratio)

    #calculate confidence bound
    def confidence_bound(self,y,n,A_inv,K,sigma,delta):
        tmp = y.T.dot(A_inv.dot(y))
        return 2*np.sqrt(2)*sigma*np.sqrt(tmp)*(np.sqrt(np.log(6/pi/pi*n*n*K/delta)))
    
    def cal_err_width(self,x,A,K,sigma,delta,A_inv=None):
        if(A_inv is None):
            A_inv = np.linalg.inv(A)
        tmp = x.T.dot(A_inv.dot(x))
        det = np.linalg.det(A)
        return np.sqrt(tmp)*(sigma*np.sqrt(2*np.log(K*K*np.sqrt(det)/delta) )+ 2)


    def check_stop_condition(self, Y, K, theta, n, A, sigma, delta, verbose=False):
        
        
        A_inv = np.linalg.inv(A)
        for y in Y:
            score_dif = y.dot(theta)
            conf_bound = self.confidence_bound(y,n,A_inv,K,sigma,delta)
            
            if(score_dif < conf_bound):
                '''
                if(verbose):
                    print("--------at %d step-------"%n)
                    print(y)
                    print("estimated rewards difference:%f"%score_dif)
                    print("confidence bound:%f"%conf_bound)
                    print("lingape confidence bound:%f"%cal_err_width(y,A,K,sigma,delta,A_inv))
                '''
                return -1
        return 1
        
        
        '''
        theta_hat = np.linalg.solve(A, b)
        A_inv = np.linalg.inv(A)
        est_reward = X.dot(theta_hat)
        best_arm = np.argmax(est_reward)
        
        if best_arm not in self.env.best_arm_set:
            if n < self.T:
                error_XY_static[n] = 1
    
        for i in range(len(X)):
            if(i == best_arm):
                continue
            #print(i)
            est_dif = est_reward[best_arm] - est_reward[i]
            arm_dif = X[best_arm] - X[i]
            conf_bound = self.confidence_bound(arm_dif, n, A_inv, len(X), sigma, delta)
            #print(est_dif,arm_dif,conf_bound)
            if(est_dif < conf_bound) :
            #if(est_dif < conf_bound) and (conf_bound > 0.0015) :
                
                if(verbose):
                    print("--------at %d step-------" % n)
                    print("arm %d violates stop condition" % i)
                    print("best estimated arm: %d" % best_arm)
                    print("best estimated reward: %f" % est_reward[best_arm])
                    print("estimated rewards difference:%f" % est_dif)
                    print("confidence bound:%f" % conf_bound)
                return -1
            
        return best_arm
        '''
    # constrct Y which contations all directions to be distinguished


    def const_Y(self,X,theta):
        rewards = X.dot(theta)
        best_arm_id = np.argmax(rewards)
        Y = []
        for i,x in enumerate(X):
            if(i != best_arm_id):
                Y.append(X[best_arm_id]-x)
        return np.array(Y)
    

    # do one simulation
    def simulation(self, X, theta, d, sigma, delta, arm_selections, error_XY_oracle, error_est_XY_oracle, verbose=True):
        # initilization
        
        A = np.eye(d)
        b = np.zeros(d)
        n = 0
        K = len(X)
        #arm_count = np.zeros(K,dtype=int)
        Y = self.const_Y(X,theta)
        #select arms one times for each
        opt_ratio = self.optimal_ratio(X,theta)
        print(opt_ratio)
        for i,x in enumerate(X):
            self.add_observe(A,b,x,theta,sigma)
            n+=1
            arm_selections[i] += 1
        
        
        '''
        A = np.eye(d) * 0.01
        b = np.zeros(d)
        n = 0
        K = len(X)
        '''
        
        #arm_count = np.zeros(K, dtype=int)
        #Y = self.const_Y(X, range(K))
    
      
        # select arms one times for each
        for i, x in enumerate(X):
            self.add_observe(A, b, x, theta, sigma)
            
            if n < self.T:
                error_XY_oracle[n] = 0
                #error_est_XY_static[n] = np.linalg.norm(theta_hat - self.theta_star, ord=1)
                error_est_XY_oracle[n] = 0
            
            n += 1
            
    
        # select arm in a greedy manner until stop condition is satisified
        while(self.check_stop_condition(Y,K,theta,n,A,sigma,delta) < 0):
            if(verbose):
                if(n % 1000 == 0):
                    self.check_stop_condition(Y,K,theta,n,A,sigma,delta,True)
                    print("XYO " + str(n))
                    #print(arm_selections)
                    #print(self.next_arm_score(A,np.zeros(d),Y,theta,True))
                    #print(np.linalg.inv(A))
            #arm = search_next_arm(A,X,Y,theta)
            arm = self.search_next_arm_from_opt_ratio(arm_selections,opt_ratio)
            A,b = self.add_observe(A,b,X[arm],theta,sigma)
            n += 1
            arm_selections[arm] += 1
            
        best_arm = self.check_stop_condition(Y,K,theta,n,A,sigma,delta)
        error_XY_oracle[0] = 1
        return error_XY_oracle, arm_selections, error_est_XY_oracle
        
        '''
        final_score = []
        while(self.check_stop_condition(X, n, A, b, sigma, delta, error_XY_static) < 0):
            
    
            if (verbose):
                if (n % 100 == 0):
                    ch = self.check_stop_condition(X, n, A, b, sigma, delta, error_XY_static)
                    #print(ch)
            arm, final_score = self.search_next_arm(A,X,b,Y,n,final_score,verbose)
            A, b, r_t = self.add_observe(A, b, X[arm], theta, sigma)
            n += 1
            
            if n%1000 == 0:
                print(n, best_arm, self.check_stop_condition(X, n, A, b, sigma, delta, error_XY_static))
            
            arm_selections[arm] += 1
            if n >= self.T-1:
                break
        best_arm = self.check_stop_condition(X, n, A, b, sigma, delta, error_XY_static)
        error_XY_static[0] = 1
        return error_XY_static, arm_selections, error_est_XY_static
        '''
    
    
    def run_XY_Oracle_Sampling(self):
        
        tr = 0
        self.total_error_XY_Oracle = []
        self.total_arm_selection = []
        self.total_error_est_XY_Oracle = []
    
        
        trial_error, arm_selection_trial, est_trial = self.simulation(self.X, self.theta_star, self.num_dims, self.sigma, self.delta, np.zeros(self.num_arms),np.zeros(self.T), np.zeros(self.T), True)
        self.total_error_XY_Oracle.append(trial_error)
        self.total_arm_selection.append(arm_selection_trial)
        self.total_error_est_XY_Oracle.append(est_trial)
        
        print(' XYO:'+ str(tr), end=', ')
        
        file = open('../main/linbandit_xy_oracle_dim'+str(self.num_dims), 'wb')
    
        pickle.dump([[self.total_error_XY_Oracle],[np.sum(self.total_arm_selection,axis = 1)]],file)
    
        file.close()
        
        '''
        #res_list = []
        trial_rec = self.num_trials//self.rec
        #print(trial_rec)
        
        
        for j in range(0,self.rec):
        
            pool = mp.Pool(trial_rec)
            res_list = pool.starmap(self.simulation, [(self.X, self.theta_star, self.num_dims, self.sigma, self.delta, np.zeros(self.num_arms),np.zeros(self.T), np.zeros(self.T), True) for i in range(trial_rec)])
            #res_list.append(res_list1)
            
            for tr in range(0,trial_rec):
                trial_error = res_list[tr][0]
                arm_selection_trial = res_list[tr][1]
                est_trial = res_list[tr][2]
                
                self.total_error_XY_Oracle.append(trial_error)
                self.total_arm_selection.append(arm_selection_trial)
                self.total_error_est_XY_Oracle.append(est_trial)
            
                print(' XYO:'+ str(tr), end=', ')
                if tr % 25 == 0:
                    print()
            
            pool.terminate()
            
        '''
        
        
if __name__ == "__main__":
    
    #trials = 4
    
    seed = 16
    dim = 8
    arms =12
    
    env = LinBandit_env()
    env.LinBandit_env1(seed, dim, arms)
    
    obj = XY_Oracle_Sampling(env)
    obj.run_XY_Oracle_Sampling()
    '''
    file = open('../main/linbandit_xy_oracle_dim'+str(dim), 'wb')
    
    pickle.dump([[obj.total_error_XY_Oracle],[np.sum(obj.total_arm_selection,axis = 1)]],file)
    
    file.close()
    '''
    print(obj.total_arm_selection)
    print(len(obj.total_arm_selection))
    print(obj.total_arm_selection[0])
    print(sum(obj.total_arm_selection[0]))



