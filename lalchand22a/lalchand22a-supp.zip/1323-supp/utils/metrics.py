#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Computing metrics for GPLVM models

- Test Reconstruction error for Y_train with and without missing data 

"""

import torch
import numpy as np

def float_tensor(X): return torch.tensor(X).float()

def rmse(Y_test, Y_recon):
    
    return torch.mean((Y_test - float_tensor(Y_recon))**2).sqrt()

def rmse_missing(Y_test, Y_recon):
    
    return torch.sqrt(torch.Tensor([np.nanmean(np.square(Y_test - Y_recon))]))

