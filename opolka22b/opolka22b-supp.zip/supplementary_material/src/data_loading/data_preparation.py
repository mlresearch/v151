import pathlib

import numpy as np
import scipy.sparse as sp
import torch_geometric.datasets as datasets
from scipy.io import loadmat
from sklearn.feature_extraction.text import TfidfTransformer


def _standardize_features(node_features, edge_features=None):
    # node features
    std = np.std(node_features, axis=0)
    node_features = node_features[:, std > 0.0]
    mean = np.mean(node_features, axis=0)
    std = np.std(node_features, axis=0)
    node_features = (node_features - mean) / std

    # edge features
    if edge_features is not None:
        std = np.std(edge_features, axis=0)
        if np.sum(std > 0.0) == 0:
            edge_features = None
        else:
            edge_features = edge_features[:, std > 0.0]
            mean = np.mean(edge_features, axis=0)
            std = np.std(edge_features, axis=0)
            edge_features = (edge_features - mean) / std
    return node_features, edge_features


def prepare_pytorch_geometric_dataset(dataset_name, dataset_folder,
                                      tfidf_transform=True):
    # Load raw data set
    if dataset_name in ["Cora", "Citeseer", "PubMed"]:
        dataset = datasets.Planetoid(dataset_folder, dataset_name)
    elif dataset_name in ["Computers", "Photo"]:
        dataset = datasets.Amazon(dataset_folder, dataset_name)
    elif dataset_name in ["Physics", "CS"]:
        dataset = datasets.Coauthor(dataset_folder, dataset_name)
    else:
        raise ValueError(f"No data set found for name {dataset_name}.")

    dataset_folder = pathlib.Path(dataset_folder)

    data = dataset.data
    features = data.x.numpy()
    labels = data.y.numpy()
    edge_indices = data.edge_index.numpy().T

    # Transform features if necessary
    if dataset_name.lower() != 'pubmed' and tfidf_transform: # tf-idf transform features, unless it's pubmed, which already comes with tf-idf
        transformer = TfidfTransformer(smooth_idf=True)
        features = transformer.fit_transform(features).todense()
        features = np.array(features)

    np.save(dataset_folder / "adj_indices.npy", edge_indices)
    np.save(dataset_folder / "node_features.npy", features)
    np.save(dataset_folder / "node_labels.npy", labels)


def prepare_network_dataset(txt_filepath, standardize):
    txt_filepath = pathlib.Path(txt_filepath)
    with txt_filepath.open("r") as fd:
        dataset_string = fd.read()
    lines = dataset_string.split("\n")
    nodes = []
    adj = []
    edges = []
    currently_vertices = False
    currently_edges = False
    for line in lines:
        if "*Vertices" in line:
            currently_vertices = True
            currently_edges = False
        elif "*Edges" in line:
            currently_vertices = False
            currently_edges = True
        elif line.startswith("*"):
            continue
        elif currently_vertices:
            attributes = line.split("    ")
            nodes.append([float(val) for val in attributes[-3:]])
        elif currently_edges:
            attributes = line.split("    ")
            if len(attributes) > 2:
                adj.append([int(val) for val in attributes[-3:-1]])
                edges.append(float(attributes[-1]))
    nodes = np.array(nodes)
    edges = np.array(edges)
    adj = np.array(adj)-1
    num_nodes = len(nodes)

    if standardize:
        nodes, edges = _standardize_features(nodes, edges)

    adj_matrix = np.zeros((num_nodes, num_nodes))
    adj_matrix[adj[:, 0], adj[:, 1]] = 1.0
    adj_matrix[adj[:, 1], adj[:, 0]] = 1.0
    print(nodes)
    print(adj)
    print(edges)
    print(adj_matrix)

    np.save(txt_filepath.parent / "adj_indices.npy", adj)
    np.save(txt_filepath.parent / "adj_matrix.npy", adj_matrix)
    np.save(txt_filepath.parent / "node_features.npy", nodes)
    np.save(txt_filepath.parent / "edge_features.npy", edges)


def prepare_mat_dataset(mat_filepath):
    mat_dict = loadmat(mat_filepath)

    mat_filepath = pathlib.Path(mat_filepath)

    adj_matrix = mat_dict["net"].tocoo()
    adj_indices = np.stack((adj_matrix.row, adj_matrix.col), axis=-1)
    adj_indices = adj_indices[adj_indices[:, 0] < adj_indices[:, 1]]
    np.save(mat_filepath.parent / "adj_indices.npy", adj_indices)


if __name__ == '__main__':
    # prepare_pytorch_geometric_dataset("Cora", "../data/cora/")
    prepare_pytorch_geometric_dataset("Physics", "../data/physics/")
    # prepare_network_dataset("../data/us_air_lines/USAir97.net.txt",
    #                         standardize=True)
    # prepare_mat_dataset("../data/ecoli/Ecoli.mat")
