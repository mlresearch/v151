import numpy as np
import gpytorch
from gpytorch.kernels import RBFKernel
import torch
from PreferentialGP.skew_symmetric_kernel import SkewKernel
from numpy.linalg import inv
from PreferentialGP.utility import Conjugate_GD
import os
os.environ['KMP_DUPLICATE_LIB_OK']='True'



##################
# Latest Version #
##################
"""
The latest version of SSGP (SkewSymGP) allows one to use conjugate gradient descent
to speed up the computation. (Could potentially uses the Batch CG suggested in the GPytorch
paper later) 
"""


class SSGPCuda(torch.nn.Module):
    """
    Rewriting SkewSymGP in pytorch format for easier optimisation
    """

    def __init__(self, comp_ls, y_ls, phi):
        super().__init__()

        self.comp_ls = comp_ls
        self.y_ls = y_ls
        self.phi = phi
        self.kernel = RBFKernel(ard_num_dims=phi.shape[1]).cuda()
        self.kernel.lengthscale = torch.tensor([2. for i in range(phi.shape[1])])
        self.f = torch.nn.Parameter(torch.randn(len(comp_ls), 1, requires_grad=True, device="cuda:0"))
        self.T = None
        self.T_inv = None
        self.K = None

    def forward(self):

        K = self.kernel(torch.tensor(self.phi).cuda()).evaluate().cuda()
        self.K = K

        m = len(self.comp_ls)
        T = torch.zeros((m, m), requires_grad=False).cuda()

        for i in range(m):
            for j in range(i, m):
                x1, x2 = self.comp_ls[i]
                l1, l2 = self.comp_ls[j]

                T[i, j] = K[x1, l1] * K[x2, l2] - K[x1, l2] * K[x2, l1]
                T[j, i] = T[i, j]

        self.T = T
        self.T_free = T.detach()


class SSGPCudaII(torch.nn.Module):
    """
    It stores the original kernel matrix so it can be reuse quicker everytime
    """

    def __init__(self, phi):
        super().__init__()

        self.phi = phi
        self.kernel = RBFKernel(ard_num_dims=phi.shape[1]).cuda()
        self.kernel.lengthscale = torch.tensor([1. for i in range(phi.shape[1])])
        self.T = None
        K = self.kernel(torch.tensor(self.phi).cuda()).evaluate().cuda()
        self.K = K

    def forward(self, comp_ls, y_ls):

        self.f = torch.nn.Parameter(torch.randn(len(comp_ls), 1, requires_grad=True, device="cuda:0"))
        m = len(comp_ls)

        T = torch.zeros((m, m), requires_grad=False).cuda()

        for i in range(m):
            for j in range(i, m):
                x1, x2 = comp_ls[i]
                l1, l2 = comp_ls[j]

                T[i, j] = self.K[x1, l1] * self.K[x2, l2] - self.K[x1, l2] * self.K[x2, l1]
                T[j, i] = T[i, j]

        self.T = T
        self.T_free = T.detach()

        self.comp_ls = comp_ls


def fit_sskernelCuda(K, comp_ls):
    m = len(comp_ls)
    T = torch.zeros((m, m), requires_grad=False).cuda()

    for i in range(m):
        for j in range(i, m):
            x1, x2 = comp_ls[i]
            l1, l2 = comp_ls[j]

            T[i, j] = K[x1, l1] * K[x2, l2] - K[x1, l2] * K[x2, l1]
            T[j, i] = T[i, j]

    return T


def ssgp_predict(ssgp, new_comp_ls):
    """
    Args:
        ssgp: The trained SSGP object with f_map computed previously
        new_comp_ls: new competition list to do prediction

    Returns:
        the predicted f_map
    """
    complete_ls = ssgp.comp_ls + new_comp_ls
    Tn = fit_sskernelCuda(ssgp.K, complete_ls)
    Tno = Tn[len(ssgp.comp_ls):, 0:len(ssgp.comp_ls)]
    # Tnn = Tn[len(ssgp.comp_ls):, len(ssgp.comp_ls):]
    # Too = Tn[:len(ssgp.comp_ls), :len(ssgp.comp_ls)]

    Too_invf = Conjugate_GD(ssgp.T_free, ssgp.f, num_rounds=10, cuda=True)

    return Tno @ Too_invf

# Loss function to minimise


def CG_GaussianLoglikelihoodCuda(f, T, y_tensor, num_rounds):
    """
    Loss function to optimise for f, uses CG. Everything in Cuda.
    """
    sigma = torch.nn.Sigmoid()
    K_invf = Conjugate_GD(T, f, num_rounds=num_rounds, cuda=True)

    L = 0.5 * f.t() @ K_invf - torch.sum(torch.log(sigma(y_tensor * f)))

    return L


def CG_approx_Marginal_log_likelihoodCuda(f, T, y_tensor):

    sigma = torch.nn.Sigmoid()
    w_elements = (sigma(f) * sigma(-f)).reshape(1, -1)[0]
    W_half = torch.diag(w_elements ** (1 / 2))
    B = torch.eye(T.shape[0]).cuda() + W_half @ T @ W_half
    eig_vals, e_vecs = torch.symeig(B, eigenvectors=True)

    mll = 0.5 * f.t() @ Conjugate_GD(T, f, num_rounds=10, cuda=True) - torch.sum(torch.log(sigma(y_tensor * f))) + 0.5 * torch.log(
        torch.prod(eig_vals))

    return mll