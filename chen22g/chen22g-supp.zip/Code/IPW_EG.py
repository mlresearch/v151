import numpy as np
import time

start = time.time()
##############################################################################
#Epsilon Greedy Normal Rewards
sample = 1000
T = 100
epsilon = 0.05

mu = np.array([1,1.5]) #normal mean
sigma = np.array([1,1])
K = mu.size
muhat41 = np.zeros([sample,K])
error41 = np.zeros([sample,K])
R = np.zeros([sample,T])
I = np.zeros([sample,T])
EG = np.zeros([sample,K,T])

for i in range(K):
    I[:,i] = i

for s in range(sample):
    for t in range(K):
        R[s,t] = np.random.normal(mu[np.int(I[s,t])],sigma[np.int(I[s,t])])
    for i in range(K):
        EG[s,i,t]= np.sum(R[s,:t+1][I[s,:t+1]==i])/np.where(I[s,:t+1]==i)[0].size
    for t in range(K,T):
        flag = np.random.rand()
        itemp = np.random.rand()
        if flag<=epsilon:
            if itemp<=1/2:
                I[s,t] = 0
            else:
                I[s,t] = 1  
        else:
            I[s,t]=np.argmax(EG[s,:,t-1])   
        R[s,t] = np.random.normal(mu[np.int(I[s,t])],sigma[np.int(I[s,t])])       
        for i in range(K):
            EG[s,i,t]= np.sum(R[s,:t+1][I[s,:t+1]==i])/np.where(I[s,:t+1]==i)[0].size
    for i in range(K):
        muhat41[s,i] = np.sum(R[s][I[s]==i])/np.where(I[s]==i)[0].size
    error41[s] = muhat41[s] - mu
bias41 = np.mean(error41, axis=0)  

print('bias is', bias41) 
print('muhat is', np.mean(muhat41, axis=0))

np.save('bias41.npy', bias41)
np.save('muhat41.npy', muhat41)    
np.save('R41.npy', R)
np.save('I41.npy', I)

##############################################################################
#IPW
muipw41 = np.zeros([sample, K, T])
muaipw41 = np.zeros([sample, K, T])
MSEipw41 = np.zeros([K, T])
MSEaipw41 = np.zeros([K, T])
for s in range(sample):
    E = np.zeros([K,T])
    M = np.zeros([K,T])
    Ripw = np.zeros([K,T])
    Raipw = np.zeros([K,T])
    for t in range(K,T):
        for i in range(K):
            E[i,t] = epsilon/2+(1-epsilon)*(EG[s,i,t-1]>=EG[s,1-i,t-1])
            M[i,t] = np.sum(R[s,:t][I[s,:t]==i])/np.where(I[s,:t]==i)[0].size
            Ripw[i,t] = (I[s,t]==i)*R[s,t]/E[i,t]
            Raipw[i,t] = (I[s,t]==i)*R[s,t]/E[i,t]+(1-(I[s,t]==i)/E[i,t])*M[i,t]
        for i in range(K):
            muipw41[s,i,t] =  np.mean(Ripw[i,K:t+1])
            muaipw41[s,i,t] =  np.mean(Raipw[i,K:t+1])   

for t in range(K,T):
    for i in range(K):
        MSEipw41[i,t] = np.var(muipw41[:,i,t])+(np.mean(muipw41[:,i,t])-mu[i])**2
        MSEaipw41[i,t] = np.var(muaipw41[:,i,t])+(np.mean(muaipw41[:,i,t])-mu[i])**2     
        
muhatipw41 = np.mean(muipw41, axis=0)          
muhataipw41 = np.mean(muaipw41, axis=0)
print('muhatipw is', muhatipw41[:,-1])
print('muhataipw is', muhataipw41[:,-1])
np.save('muhatipw41.npy', muhatipw41)
np.save('muhataipw41.npy', muhataipw41)
np.save('MSEipw41.npy', MSEipw41)
np.save('MSEaipw41.npy', MSEaipw41)

############################################################################## 
#MB
B = 1000

mumb41 = np.zeros([sample, K, T]) #bootstrap muhat
errormb41 = np.zeros([sample, K])
muhatmb41 = np.zeros([sample, K, T]) #corrected muhat
MSEmb41 = np.zeros([K, T])


for s in range(sample): 
    print('MB normal sample is', s+1)   
    mub = np.zeros(K)
    varb = np.zeros(K)
    for i in range(K):
        mub[i] =  np.mean(R[s][I[s]==i])
        varb[i] = np.var(R[s][I[s]==i])  
        
    muboots = np.zeros([K,B])
    Rmb = np.zeros([B,T])
    Imb = np.zeros([B,T])
    EG = np.zeros([B,K,T])
    
    for i in range(K):       
        Imb[:,i] = i
    for b in range(B):       
        for t in range(K):
           Rmb[b,t] = np.random.normal(mub[np.int(Imb[b,t])],np.sqrt(varb[np.int(Imb[b,t])]))  
        for i in range(K):
            EG[b,i,t]= np.sum(Rmb[b,:t+1][Imb[b,:t+1]==i])/np.where(Imb[b,:t+1]==i)[0].size
        for t in range(K,T):    
            flag = np.random.rand()
            itemp = np.random.rand()
            if flag<=epsilon:
                if itemp<=1/2:
                    Imb[b,t] = 0
                else:
                    Imb[b,t] = 1
            else:
                Imb[b,t]=np.argmax(EG[b,:,t-1])   
            Rmb[b,t] = np.random.normal(mub[np.int(Imb[b,t])],np.sqrt(varb[np.int(Imb[b,t])]))  
            for i in range(K):
                EG[b,i,t]= np.sum(Rmb[b,:t+1][Imb[b,:t+1]==i])/np.where(Imb[b,:t+1]==i)[0].size
    #     for i in range(K):
    #         muboots[i, b] = np.sum(Rmb[b][Imb[b]==i])/np.where(Imb[b]==i)[0].size        
    # muhatmb41[:,s] = np.mean(muboots,axis = 1)   
    mumb41[s] = np.mean(EG,axis = 0)
    muhatmb41[s] = 2*muhat41[s].reshape(K,1) - mumb41[s]
    
  
for t in range(K,T):
    for i in range(K):
        MSEmb41[i,t] = np.var(muhatmb41[:,i,t])+(np.mean(muhatmb41[:,i,t])-mu[i])**2
   
print('muhatmb is', np.mean(muhatmb41[:,:,-1], axis=0))
np.save('muhatmb41.npy', muhatmb41)
np.save('MSEmb41.npy', MSEmb41)

#############################################################################
# Epsilon Greedy Bernoulli Rewards
mu = np.array([0.3, 0.6]) #bernoulli mean
K = mu.size
muhat42 = np.zeros([sample,K])
error42 = np.zeros([sample,K])
R = np.zeros([sample,T])
I = np.zeros([sample,T])
EG = np.zeros([sample,K,T])

for i in range(K):
    I[:,i] = i

for s in range(sample):
    for t in range(K):
        R[s,t] = np.random.binomial(1, mu[np.int(I[s,t])])
    for i in range(K):
        EG[s,i,t]= np.sum(R[s,:t+1][I[s,:t+1]==i])/np.where(I[s,:t+1]==i)[0].size
    for t in range(K,T):
        flag = np.random.rand()
        itemp = np.random.rand()
        if flag<=epsilon:
            if itemp<=1/2:
                I[s,t] = 0
            else:
                I[s,t] = 1  
        else:
            I[s,t]=np.argmax(EG[s,:,t-1])   
        R[s,t] = np.random.binomial(1, mu[np.int(I[s,t])])
        for i in range(K):
            EG[s,i,t]= np.sum(R[s,:t+1][I[s,:t+1]==i])/np.where(I[s,:t+1]==i)[0].size
    for i in range(K):
        muhat42[s,i] = np.sum(R[s][I[s]==i])/np.where(I[s]==i)[0].size
    error42[s] = muhat42[s] - mu
bias42 = np.mean(error42, axis=0)  

print('bias is', bias42) 
print('muhat is', np.mean(muhat42, axis=0))
np.save('bias42.npy', bias42)
np.save('muhat42.npy', muhat42)    
np.save('R42.npy', R)
np.save('I42.npy', I)

##############################################################################
#IPW
muipw42 = np.zeros([sample, K, T])
muaipw42 = np.zeros([sample, K, T])
MSEipw42 = np.zeros([K, T])
MSEaipw42 = np.zeros([K, T])
for s in range(sample):
    E = np.zeros([K,T])
    M = np.zeros([K,T])
    Ripw = np.zeros([K,T])
    Raipw = np.zeros([K,T])
    for t in range(K,T):
        for i in range(K):
            E[i,t] = epsilon/2+(1-epsilon)*(EG[s,i,t-1]>=EG[s,1-i,t-1])
            M[i,t] = np.sum(R[s,:t][I[s,:t]==i])/np.where(I[s,:t]==i)[0].size
            Ripw[i,t] = (I[s,t]==i)*R[s,t]/E[i,t]
            Raipw[i,t] = (I[s,t]==i)*R[s,t]/E[i,t]+(1-(I[s,t]==i)/E[i,t])*M[i,t]
        for i in range(K):
            muipw42[s,i,t] =  np.mean(Ripw[i,K:t+1])
            muaipw42[s,i,t] =  np.mean(Raipw[i,K:t+1])   

for t in range(K,T):
    for i in range(K):
        MSEipw42[i,t] = np.var(muipw42[:,i,t])+(np.mean(muipw42[:,i,t])-mu[i])**2
        MSEaipw42[i,t] = np.var(muaipw42[:,i,t])+(np.mean(muaipw42[:,i,t])-mu[i])**2     
        
muhatipw42 = np.mean(muipw42, axis=0)          
muhataipw42 = np.mean(muaipw42, axis=0)
print('muhatipw is', muhatipw42[:,-1])
print('muhataipw is', muhataipw42[:,-1])
np.save('muhatipw42.npy', muhatipw42)
np.save('muhataipw42.npy', muhataipw42)
np.save('MSEipw42.npy', MSEipw42)
np.save('MSEaipw42.npy', MSEaipw42)

############################################################################## 
# #MB
B = 1000

mumb42 = np.zeros([sample, K, T]) #bootstrap muhat
errormb42 = np.zeros([sample, K])
muhatmb42 = np.zeros([sample, K, T]) #corrected muhat
MSEmb42 = np.zeros([K, T])

for s in range(sample): 
    print('MB bernoulli sample is', s+1)   
    mub = np.zeros(K)
    varb = np.zeros(K)
    for i in range(K):
        mub[i] =  np.mean(R[s][I[s]==i])
        varb[i] = np.var(R[s][I[s]==i])  
        
    muboots = np.zeros([K,B])
    Rmb = np.zeros([B,T])
    Imb = np.zeros([B,T])
    EG = np.zeros([B,K,T])
    
    for i in range(K):       
        Imb[:,i] = i
    for b in range(B):
        
        for t in range(K):
            Rmb[b,t] = np.random.normal(mub[np.int(Imb[b,t])],np.sqrt(varb[np.int(Imb[b,t])])) 
        for i in range(K):
            EG[b,i,t]= np.sum(Rmb[b,:t+1][Imb[b,:t+1]==i])/np.where(Imb[b,:t+1]==i)[0].size
        for t in range(K,T):    
            flag = np.random.rand()
            itemp = np.random.rand()
            if flag<=epsilon:
                if itemp<=1/2:
                    Imb[b,t] = 0
                else:
                    Imb[b,t] = 1
            else:
                Imb[b,t]=np.argmax(EG[b,:,t-1])   
            Rmb[b,t] = np.random.normal(mub[np.int(Imb[b,t])],np.sqrt(varb[np.int(Imb[b,t])])) 
            for i in range(K):
                EG[b,i,t]= np.sum(Rmb[b,:t+1][Imb[b,:t+1]==i])/np.where(Imb[b,:t+1]==i)[0].size
    #     for i in range(K):
    #         muboots[i, b] = np.sum(Rmb[b][Imb[b]==i])/np.where(Imb[b]==i)[0].size        
    # muhatmb41[:,s] = np.mean(muboots,axis = 1)   
    mumb42[s] = np.mean(EG,axis = 0)
    muhatmb42[s] = 2*muhat42[s].reshape(K,1) - mumb42[s]   
     
for t in range(K,T):
    for i in range(K):
        MSEmb42[i,t] = np.var(muhatmb42[:,i,t])+(np.mean(muhatmb42[:,i,t])-mu[i])**2
    
print('muhatmb is', np.mean(muhatmb42[:,:,-1], axis=0))

np.save('muhatmb42.npy', muhatmb42)
np.save('MSEmb42.npy', MSEmb42)

end = time.time()
