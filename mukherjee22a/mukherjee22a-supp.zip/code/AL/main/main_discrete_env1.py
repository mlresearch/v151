

import sys
sys.path.append("..")

from environment.Discrete_env import Discrete_env
from policies.Chernoff_sampling import Chernoff_Sampling
from policies.Chernoff_sampling_expl import Chernoff_Sampling_expl
from policies.Batched_Chernoff_Sampling import Batched_Chernoff_Sampling
from policies.Random_sampling import Random_Sampling
from policies.Top2_sampling import Top2_Sampling
from policies.Njav_sampling import Njav_Sampling
from plots.plot_sample_complexity import plot_sample_complexity
from plots.plot_error_rate import plot_error_rate
from util.file_IO import file_IO

import pickle

if __name__ == "__main__":
    env = Discrete_env()
    env.discrete_env1()
    
    chern = Chernoff_Sampling(env)
    chern.run_Chernoff_Sampling()
    
    
    bchern = Batched_Chernoff_Sampling(env, 5)
    bchern.run_Batched_Chernoff_Sampling()
    
    bchern1 = Batched_Chernoff_Sampling(env, 10)
    bchern1.run_Batched_Chernoff_Sampling()
    
    bchern2 = Batched_Chernoff_Sampling(env, 15)
    bchern2.run_Batched_Chernoff_Sampling()
    
    rand = Random_Sampling(env)
    rand.run_Random_Sampling()
    
    top2 = Top2_Sampling(env)
    top2.run_Top2_Sampling()
    
    njav = Njav_Sampling(env)
    njav.run_Njav_Sampling()
    
    chern_e = Chernoff_Sampling_expl(env)
    chern_e.run_Chernoff_Sampling_expl()
    
    #top2_err, rand_err, chern_err, njav_err, top2_sample_complexity, rand_sample_complexity, chern_sample_complexity, njav_sample_complexity = file_IO()
    
    file = open('discrete_env1_1', 'wb')
    # dump information to that file
    pickle.dump([[top2.top2_err, rand.rand_err, chern.chern_err, bchern.batched_chern_err, bchern1.batched_chern_err, bchern2.batched_chern_err, njav.njav_err, chern_e.chern_err],[top2.top2_sample_complexity, rand.rand_sample_complexity, chern.chern_sample_complexity, bchern.batched_chern_sample_complexity, bchern1.batched_chern_sample_complexity, 
                                                                                                                                                                                    bchern2.batched_chern_sample_complexity, njav.njav_sample_complexity, chern_e.chern_sample_complexity]],file)
    # close the file
    file.close()
    
    top2_err, rand_err, chern_err, bchern_err, bchern1_err, bchern2_err, njav_err, chern_e_err, top2_sample_complexity, rand_sample_complexity, chern_sample_complexity, bchern_sample_complexity, bchern1_sample_complexity, bchern2_sample_complexity, njav_sample_complexity, chern_e_sample_complexity = file_IO('discrete_env1_1')
    
    
    plot_sample_complexity(chern_sample_complexity, bchern_sample_complexity, bchern1_sample_complexity, bchern2_sample_complexity, rand_sample_complexity, top2_sample_complexity, njav_sample_complexity, chern_e_sample_complexity, env.num_sources, env.num_hypo, "env1_1")
    #plot_error_rate(chern_err, bchern_err, rand_err, top2_err, njav_err, env.num_sources, env.num_hypo, env.T, "env1")
    
    
    
    