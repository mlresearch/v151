function [x, history, time] = proj_newton(y, D, k, lambda)
%%
n   = length(y);
m   = size(D,1);

if size(D,2) == 2
    
    edges1  = D(:,1);
    edges2  = D(:,2);

    %Make sparse D matrix
    D       = sparse((1:m)', edges1, 1, m, n, 10*m);
    D       = D + sparse((1:m)', edges2, -1, m, n);

else
    edges1  = zeros(m,1);
    edges2  = zeros(m,1);
    
    for i = 1:m
        Iy          = find(D(i,:) ~= 0);
        edges1(i)   = Iy(1);
        edges2(i)   = Iy(2);
    end
    
    D   = sparse(D);

end

L = D'*D;
D = sparse(D);
O = D;

for i = 1:k
    if mod(i, 2)
        O = D' * O;
    else
        O = D * O;
    end
end

H = O*O';

%line-search parameter
alpha   = 0.1; %intepolation parameter
beta    = 0.8; %backtracking parameter

%tolerance and maxiter
tol_pcg = 1e-5;
maxiter = 50;
history = [];
time    = [];

% initialization
u       = zeros(size(O,1), 1);
fx      = 0;
t0      = cputime;

for iter = 1:1:maxiter   
    %
    grad    = compute_grad(D, L, k, y, u);
    IX      = free_set(u, grad, lambda);
    delta   = zeros(size(u));
    [delta(IX), ~, ~] = pcg(H(IX,IX), grad(IX), tol_pcg, 200);

    %Projected Newton step with backtracking line search
    gamma   = 1;
    
    u_new   = proj_lambda(u - gamma*delta, lambda);
    fx_new  = dobj_eval(D, L, k, y, u_new); 
    
    while fx_new > fx - alpha * gamma * grad' * (delta)
        gamma   = beta*gamma;
        u_new   = proj_lambda(u - gamma*delta, lambda);
        fx_new  = dobj_eval(D, L, k, y, u_new);
    end
     
    %update parameters
    fx      = fx_new;
    u       = u_new;
     
    STu     = Times_ST(D, L, k, u);
    x       = -STu + y;
    % dgap    = lambda*norm(Times_S(D, L, k, x), 1) - STu'*x;
    fobj    = obj_eval(D, L, k, y, x, lambda); 
    ftime   = cputime - t0; 
    
    fprintf('iter = %d. fobj = %f\n', iter, fobj);    
    history = [history, fobj];
    time    = [time, ftime]; 

end

end

