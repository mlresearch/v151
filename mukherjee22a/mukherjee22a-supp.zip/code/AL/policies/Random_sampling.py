

import sys
sys.path.append("..")
from util.check_stop_time import check_stop_time
from util.update_log_L import update_log_L
from util.sample_source import sample_source

from environment.Discrete_env import Discrete_env

import numpy as np

class Random_Sampling(object):
    
    '''
    classdocs
    '''
    
    num_sources = 0
    num_hypo = 0
    mu = None
    
    def __init__(self, env):
        '''
        Constructor
        '''
        self.num_hypo = env.num_hypo
        self.num_sources = env.num_sources
        self.mu = env.mu
        self.sig = env.sig
        self.env = env
        self.trials = env.trials
        self.T = env.T
        self.jstar = env.jstar
        self.best_arm = env.best_arm
        
        
        self.rand_err = []
        self.rand_num = []
        #pre calculate chernoff sampling proportions
        

        self.rand_sample_complexity = np.zeros((self.trials, self.num_sources))

    def run_Random_Sampling(self):
        
        print("\n Random")
        for tr in range(self.trials): 
    
            self.rand_L = np.zeros(self.num_hypo)
            self.tr_rand_err = np.zeros(self.T)
    
            np.random.seed(tr)
    
            self.tr_rand_num = np.zeros(self.num_sources)
    
            for t in range(self.T):

        
        
                if check_stop_time(self.rand_L, self.num_hypo) == False:
                    idx = np.random.choice(self.num_sources)
                    self.tr_rand_num[idx] += 1  # recording number of pulls
                
                    val = sample_source(idx, self.mu, self.sig, self.jstar)
                    update_log_L(self.rand_L, self.mu, self.sig, idx, val)
                    rand_hypo_hat = np.random.choice([h for h in range(self.num_hypo) if self.rand_L[h] == max(self.rand_L)])
                    #tr_rand_err[t] += int(rand_hypo_hat != jstar)
                    rand_best_arm_hat = np.argmax(np.array(self.mu[:,rand_hypo_hat]))
                    self.tr_rand_err[t] += int(rand_best_arm_hat != self.best_arm)
                
                    self.rand_sample_complexity[tr][idx] += 1
            
            self.rand_err.append(self.tr_rand_err)
    
            self.rand_num.append(self.tr_rand_num)
            
            print(tr, end=', ')
            if tr % 100 == 0:
                print()