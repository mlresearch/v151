

import numpy as np

class Discrete_env(object):
    '''
    classdocs
    '''

    num_sources = 0
    num_hypo = 0
    mu = None
    
    def __init__(self):
        '''
        Constructor
        '''
    
    def set_param(self, num_sources, num_hypo):
        self.num_sources = num_sources
        self.num_hypo = num_hypo
    
    def discrete_env1(self):
        
        
        self.jstar = 0  # 1st column

        self.trials = 150
        self.T = 10000 # number of rounds in each trial
        self.sig = 1.5 # noise std dev #0.5 in original paper
        
        '''
        mu = np.array([[1.0, 0.0, 0], [1.0, 1.05, 0.95]])
        mu1 = [[1.0, 1.01 + np.random.uniform(0,0.001), 0.99 - np.random.uniform(0,0.001)] for i in range(198)]
        mu = np.vstack((mu,mu1))
        '''
        
        mu = np.array([[3.0, 0.0, 0.0, 0.0, 0.0, 0.0], [2.0, 3.0, 2.0, 2.0, 2.0, 2.0], [2.0, 2.0, 2.0, 3.0, 2.0, 2.0], 
               [2.0, 2.0, 2.0, 2.0, 3.0, 2.0], [2.0, 2.0, 2.0, 2.0, 2.0, 3.0]])
        
        mu1 = [[1.0, 1.0, 1.0, 1.0, 1.0 + np.random.uniform(0,0.00001), 1.0] for i in range(45)]
        
        
        '''
        #Best one
        mu = np.array([[3.0, 0.0, 0.0, 0.0, 0.0, 0.0], [2.0, 3.0, 2.0, 2.0, 2.0, 2.0], [2.0, 2.0, 3.0, 2.0, 2.0, 2.0], [2.0, 2.0, 2.0, 3.0, 2.0, 2.0], 
               [2.0, 2.0, 2.0, 2.0, 3.0, 2.0], [2.0, 2.0, 2.0, 2.0, 2.0, 3.0]])
        
        mu1 = [[1.0, 1.0, 1.0, 1.0, 1.0 + np.random.uniform(0,0.00001), 1.0] for i in range(44)]
        
        mu = np.vstack((mu,mu1))
        '''
        '''
        mu = np.array([[3.0, 0.0, 0.0, 0.0, 0.0, 0.0], [2.0, 3.0, 2.0, 2.0, 2.0, 2.0], [2.0, 2.0, 3.0, 2.0, 2.0, 2.0], [2.0, 2.0, 2.0, 3.0, 2.0, 2.0], 
               [2.0, 2.0, 2.0, 2.0, 3.0, 2.0], [2.0, 2.0, 2.0, 2.0, 2.0, 3.0], [0, 0, 0, 0, 0, 2.0],  [0, 0, 0, 0, 0, 2.0]])
        
        mu1 = [[1.0, 1.0, 1.0, 1.0, 1.0 + np.random.uniform(0,0.00001), 1.0] for i in range(44)]
        '''
        mu = np.vstack((mu,mu1))
        
        
        self.mu = mu
        
        #print(self.mu)
        
        self.num_sources, self.num_hypo = mu.shape
        jstar = 0  # 1st column
        self.best_arm = np.argmax(np.array(mu[:,jstar]))
        #print(self.best_arm)
        return self.mu
    
    def discrete_env2(self):
        
        self.jstar = 0  # 1st column

        self.trials = 100
        self.T = 10000 # number of rounds in each trial
        self.sig = 1 # noise std dev
        
        mu = np.array([[1.0, 0.001, 0.0], [1.0, 1.05, 0.95]])
        self.mu = mu
        #mu1 = [[1.0, 1.01 + np.random.uniform(0,0.001), 0.99 - np.random.uniform(0,0.001)] for i in range(198)]
        #mu = np.vstack((mu,mu1))
        #print(self.mu)
        
        self.num_sources, self.num_hypo = mu.shape
        jstar = 0  # 1st column
        self.best_arm = np.argmax(np.array(mu[:,jstar]))
        #print(best_arm)
        return self.mu
    
    def discrete_env2_1(self):
        
        self.jstar = 0  # 1st column

        self.trials = 100
        self.T = 10000 # number of rounds in each trial
        self.sig = 1 # noise std dev
        
        mu = np.array([[1.0, 0.001, 0.0], [1.0, 1.002, 0.998]])
        self.mu = mu
        #mu1 = [[1.0, 1.01 + np.random.uniform(0,0.001), 0.99 - np.random.uniform(0,0.001)] for i in range(198)]
        #mu = np.vstack((mu,mu1))
        #print(self.mu)
        
        self.num_sources, self.num_hypo = mu.shape
        jstar = 0  # 1st column
        self.best_arm = np.argmax(np.array(mu[:,jstar]))
        #print(best_arm)
        return self.mu
    
    def discrete_env3(self):
        
        self.jstar = 0  # 1st column

        self.trials = 100
        self.T = 10000 # number of rounds in each trial
        self.sig = 1 # noise std dev
        
        mu = np.random.randn(50,6)*1.0
        self.mu = mu
        #mu1 = [[1.0, 1.01 + np.random.uniform(0,0.001), 0.99 - np.random.uniform(0,0.001)] for i in range(198)]
        #mu = np.vstack((mu,mu1))
        #print(self.mu)
        
        self.num_sources, self.num_hypo = mu.shape
        jstar = 0  # 1st column
        self.best_arm = np.argmax(np.array(mu[:,jstar]))
        #print(best_arm)
        return self.mu
    
    def discrete_env4(self):
        
        self.jstar = 0  # 1st column

        self.trials = 100
        self.T = 10000 # number of rounds in each trial
        self.sig = 1 # noise std dev
        
        mu = [[.1,1],[1,.1],[.6,.6]]
        mu1 = np.random.randn(50,2)*1.0
        
        mu = np.vstack((mu,mu1))
        
        
        self.mu = mu
        #mu1 = [[1.0, 1.01 + np.random.uniform(0,0.001), 0.99 - np.random.uniform(0,0.001)] for i in range(198)]
        #mu = np.vstack((mu,mu1))
        #print(self.mu)
        
        self.num_sources, self.num_hypo = mu.shape
        jstar = 0  # 1st column
        self.best_arm = np.argmax(np.array(mu[:,jstar]))
        #print(best_arm)
        return self.mu
    

if __name__ == "__main__":
    obj = Discrete_env()
    print(obj.discrete_env1())
    print(obj.discrete_env2())
    print(obj.discrete_env3())
    print(obj.discrete_env4())
    
  
    
    