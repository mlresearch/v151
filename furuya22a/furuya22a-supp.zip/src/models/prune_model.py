import copy

import torch


def random_weight_prune(weight, n_prune: int):
    """Return pruned weight parameters by random pruning algorithm.

    `n_prune` positions to prune are selected randomly.
    """
    wts_pruned = copy.deepcopy(weight)
    w = wts_pruned["rnn.weight_hh_l0"]
    mask = torch.randn_like(w)
    mask_idx = torch.topk(mask.flatten(), n_prune, largest=False)[1]
    w.flatten()[mask_idx] = 0
    return wts_pruned


def magnitude_weight_prune(weight, n_prune: int, key: str = "rnn.weight_hh_l0"):
    """Return pruned weight parameters by magnitude-based pruning algorithm.

    `n_prune` positions to prune are selected in descending order of magnitude.
    """
    wts_pruned = copy.deepcopy(weight)
    w = wts_pruned[key]
    mask_idx = torch.topk(w.flatten().abs(), n_prune, largest=False)[1]
    w.flatten()[mask_idx] = 0
    return wts_pruned


def lrd(w, m):
    """Low rank decomposition for weight matrix."""
    u, s, vh = torch.linalg.svd(w)
    return u[:, :m] @ torch.diag(s[:m]) @ vh[:m]
