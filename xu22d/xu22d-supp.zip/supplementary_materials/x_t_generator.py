import numpy as np
from x_t_agent import random_agent, super_strategic_agent
# import pandas as pd
# import matplotlib.pyplot as plt
import pickle as pk
"""generating a series of x"""
T = 70000
d = 2
rounds = 20
normbound_x = 1
full_xt = np.zeros((T, d, rounds))
for iround in range(0,rounds):
    for t in range(T):
        x_t = super_strategic_agent(d, int(np.log2(t+1)))
        # x_t = random_agent(d, normbound_x)
        full_xt[t, :, iround] = x_t

# with open("xtrandom.pkl", 'wb') as f:
#     pk.dump(full_xt, f)
with open("xtadversarial.pkl", 'wb') as f:
    pk.dump(full_xt, f)

