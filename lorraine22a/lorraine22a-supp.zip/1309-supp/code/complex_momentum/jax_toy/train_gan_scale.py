# import os
# os.environ['XLA_PYTHON_CLIENT_PREALLOCATE'] = 'false'

import matplotlib as mpl
import time
import itertools
import numpy.random as npr
import jax.numpy as np
from jax import jit, value_and_grad, random
from jax.experimental import optimizers
from jax.experimental import stax
from jax.experimental.stax import Dense
from jax.nn import log_sigmoid, sigmoid
from toy_data import sample_spirals, sample_gaussians
import matplotlib.pyplot as plt
import os
import tqdm
import argparams
from jax.nn.initializers import kaiming_uniform, normal
from jax.experimental.optimizers import optimizer as optimizer_maker
import pandas as pd
import gc
import cmath
import seaborn as sns
import GPUtil as GPU
import pickle

mpl.use('Agg')


def create_nets(rng, z_dim=4, hidden_dim=25, output_dim=2):
    rng, G_rng = random.split(rng)
    rng, D_rng = random.split(rng)

    LeakyRelu_01 = stax.elementwise(lambda x: stax.leaky_relu(x, negative_slope=0.1))

    init_random_params_G, G_fwd = stax.serial(
        Dense(hidden_dim, W_init=kaiming_uniform(), b_init=normal(stddev=1e-6)), LeakyRelu_01,
        Dense(hidden_dim, W_init=kaiming_uniform(), b_init=normal(stddev=1e-6)), LeakyRelu_01,
        Dense(output_dim, W_init=kaiming_uniform(), b_init=normal(stddev=1e-6)))

    _, init_params_G = init_random_params_G(G_rng, (-1, z_dim))

    init_random_params_D, D_fwd = stax.serial(
        Dense(hidden_dim, W_init=kaiming_uniform(), b_init=normal(stddev=1e-6)), LeakyRelu_01,
        Dense(hidden_dim, W_init=kaiming_uniform(), b_init=normal(stddev=1e-6)), LeakyRelu_01,
        Dense(1, W_init=kaiming_uniform(), b_init=normal(stddev=1e-12)))

    _, init_params_D = init_random_params_D(D_rng, (-1, output_dim))

    return (init_params_G, G_fwd), (init_params_D, D_fwd)


# This is the network used in https://arxiv.org/pdf/1807.04740.pdf
#
def create_nets_from_neg_momentum_paper(rng, z_dim=4, hidden_dim=256, output_dim=2):
    rng, G_rng = random.split(rng)
    rng, D_rng = random.split(rng)

    # They dont say initializition assuming kaiming that is default in pytorch.
    init_random_params_G, G_fwd = stax.serial(
        Dense(hidden_dim, W_init=kaiming_uniform(), b_init=normal(stddev=1e-6)), stax.Relu,
        Dense(hidden_dim, W_init=kaiming_uniform(), b_init=normal(stddev=1e-6)), stax.Relu,
        Dense(hidden_dim, W_init=kaiming_uniform(), b_init=normal(stddev=1e-6)), stax.Relu,
        Dense(output_dim, W_init=kaiming_uniform(), b_init=normal(stddev=1e-6)))

    _, init_params_G = init_random_params_G(G_rng, (-1, z_dim))

    init_random_params_D, D_fwd = stax.serial(
        Dense(hidden_dim, W_init=kaiming_uniform(), b_init=normal(stddev=1e-6)), stax.Relu,
        Dense(hidden_dim, W_init=kaiming_uniform(), b_init=normal(stddev=1e-6)), stax.Relu,
        Dense(hidden_dim, W_init=kaiming_uniform(), b_init=normal(stddev=1e-6)), stax.Relu,
        Dense(1, W_init=kaiming_uniform(), b_init=normal(stddev=1e-12)))

    _, init_params_D = init_random_params_D(D_rng, (-1, output_dim))

    return (init_params_G, G_fwd), (init_params_D, D_fwd)


# This is the original formulation of GANs eq (1) Goodfellow et al 2014.
def V(G_, D_, batch):
    # x~p(x), z~p(z)
    X_, Z_ = batch

    Dx = D_(X_)
    Gz = G_(Z_)

    # v1= int_x p(x) log D(x) dx
    v1 = np.mean(log_sigmoid(Dx))

    # v1= int_z p(z) log (1-D(G(z))) dz
    DGz = D_(Gz)
    v2 = np.mean(np.log(1 - sigmoid(DGz)))
    return v1 + v2


# Non-Saturating Generator Loss
def loss_G(G_fn, D_fn, G_params_, D_params_, batch):
    G = lambda X_: G_fn(G_params_, X_)
    D = lambda X_: D_fn(D_params_, X_)

    _, Z_ = batch
    # min_G -E[logD(G(z))]
    Gz = G(Z_)
    DGz = D(Gz)

    v_ = -np.mean(log_sigmoid(DGz))

    return v_


def loss_D(G_fn, D_fn, G_params_, D_params_, batch):
    G = lambda X_: G_fn(G_params_, X_)
    D = lambda X_: D_fn(D_params_, X_)
    return -V(G, D, batch)


@optimizer_maker
def complex_momentum(step_size, mass):
    """Construct optimizer triple for SGD with complex momentum.

    Returns:
      An (init_fun, update_fun, get_params) triple.
    """
    # keep our notation with the paper.
    alpha = step_size
    B = mass

    def init(x0):
        v0 = np.zeros_like(x0, dtype=np.complex64)
        return x0, v0

    def update(i, g, state):
        w, u = state
        u = B * u + g

        alphau = (alpha * u) + np.conjugate(alpha * u)

        w = w - 0.5 * np.real(alphau)

        # keep jax api consistent
        x, velocity = w, u
        return x, velocity

    def get_params(state):
        x, _ = state
        return x

    return init, update, get_params


def main(args, Z_test=None):
    out_dir = args.out_dir
    rng = random.PRNGKey(0)

    z_dim = args.z_dim
    batch_size = args.batch_size
    ad_hoc_gen_obj = not args.zero_game

    if ad_hoc_gen_obj is False:
        print('using zero game formulation')
        # loss_G = lambda G_fn, D_fn, G_params_, D_params_, batch: -loss_D(G_fn, D_fn, G_params_, D_params_, batch)
        assert False

    data_sampler = sample_spirals if args.toy_version == 'spirals' else sample_gaussians
    dataset = args.toy_version
    batch_neg_log_lk_compute = None
    if args.compute_batch_nll:
        print('\nComputing Batch NLL requires Gaussians... overwritting')
        dataset = 'sample_gaussians_lk'
        from toy_data_2 import mixture_of_gaussian_pack

        gaussians, data_sampler, batch_neg_log_lk_compute = mixture_of_gaussian_pack(num_gaussians=8)

    # ----
    lr_g = args.G_lr
    lr_d = args.D_lr
    epochs = args.n_epochs
    in_d = z_dim
    no_improvement_after = args.no_improvement_after

    # Ignore flag
    if no_improvement_after == -1:
        no_improvement_after = np.inf

    if args.net_version == 'very_toy':
        (G_params, G_fwd), (D_params, D_fwd) = create_nets(rng, z_dim=in_d)
    elif args.net_version == 'neg_momentum_paper':
        (G_params, G_fwd), (D_params, D_fwd) = create_nets_from_neg_momentum_paper(rng, z_dim=in_d)
        # epochs = 100000  # forcing it to be this as per they paper? they dont mention batchsize...so
    else:
        raise ValueError()

    if args.opt == 'sgd':
        assert np.imag(lr_g) == 0, 'needs to be real for sgd'
        assert np.imag(lr_d) == 0, 'needs to be real for sgd'
        # ---
        lr_g = np.real(lr_g)
        lr_d = np.real(lr_d)
        # ---
        opt_init_G, opt_update_G, get_params_G = optimizers.sgd(lr_g)
        opt_init_D, opt_update_D, get_params_D = optimizers.sgd(lr_d)
    elif args.opt == 'momentum':
        assert np.imag(lr_g) == 0, 'needs to be real for momentum'
        assert np.imag(lr_d) == 0, 'needs to be real for momentum'
        # ---
        lr_g = np.real(lr_g)
        lr_d = np.real(lr_d)
        # ---

        opt_init_G, opt_update_G, get_params_G = optimizers.momentum(lr_g, mass=args.momentum_mass)
        opt_init_D, opt_update_D, get_params_D = optimizers.momentum(lr_d, mass=args.momentum_mass)
        args.momentum_mass_complex = 0

    elif args.opt == 'complex_momentum':
        complex_mass = args.momentum_mass + args.momentum_mass_complex  # .25j

        lr_g = lr_g + 0.j if np.imag(lr_g) == 0 else lr_g  # or np.imag(lr_)
        lr_d = lr_d + 0.j if np.imag(lr_d) == 0 else lr_d

        opt_init_G, opt_update_G, get_params_G = complex_momentum(lr_g, mass=complex_mass)
        opt_init_D, opt_update_D, get_params_D = complex_momentum(lr_d, mass=complex_mass)
    else:
        raise ValueError()

    # stats....
    def create_pandas_log_table():
        stats_table = pd.DataFrame(
            columns=['dataset', 'network', 'epoch', 'optimizer', 'lr_re', 'lr_complex', 'momentum_mass',
                     'momentum_mass_complex',
                     'loss_G',
                     'loss_D', 'neg_log_like',
                     'lr_mag', 'lr_arg', 'momentum_mag', 'momentum_arg',
                     ]
        )
        return stats_table

    stats_table = create_pandas_log_table()
    stats_table.to_csv(out_dir + '/stats.csv', index=False, header=True)

    @jit
    def update_G(i, opt_state_G_, opt_state_D_, batch):
        G_params_ = get_params_G(opt_state_G_)
        D_params_ = get_params_D(opt_state_D_)

        value, grad_Gw = value_and_grad(loss_G, argnums=2)(G_fwd, D_fwd, G_params_, D_params_, batch)

        return value, opt_update_G(i, grad_Gw, opt_state_G_)

    @jit
    def update_D(i, opt_state_G_, opt_state_D_, batch):
        G_params_ = get_params_G(opt_state_G_)
        D_params_ = get_params_D(opt_state_D_)

        value, grad_Dw = value_and_grad(loss_D, argnums=3)(G_fwd, D_fwd, G_params_, D_params_, batch)
        return value, opt_update_D(i, grad_Dw, opt_state_D_)

    opt_state_G = opt_init_G(G_params)
    opt_state_D = opt_init_D(D_params)

    itercount = itertools.count()
    rng_np = npr.RandomState(0)

    print("\nStarting training...")
    # for logging....
    GPUs = GPU.getGPUs()
    if len(GPUs) > 0:
        GPU_mem_free = GPUs[0].memoryFree
        GPU_mem_used = GPUs[0].memoryUsed
    else:
        GPU_mem_free = -1
        GPU_mem_used = -1
    # ---
    assert lr_d == lr_g, 'stats assume lr_d and lr_g are the same, stats only save lr_d'
    lr_mag, lr_arg = cmath.polar(lr_d)
    cm = args.momentum_mass + args.momentum_mass_complex
    momentum_mag, momentum_arg = cmath.polar(cm)
    # Stats...
    print(
        f'LR: {lr_d} Momentum: {cm}\nLR :mag:{lr_mag:.4} arg: {lr_arg} Momentum :mag:{momentum_mag:.4} arg: {momentum_arg}, GPU: {GPU_mem_free}/{GPU_mem_used}')

    force_log_every = 10000
    force_stats_log_every = force_log_every / 2
    fname = out_dir + '/stats.csv'

    pbar = tqdm.tqdm(range(epochs))

    if Z_test is None:
        # Use the same Z each time to get rid of stochasticity
        # create if not predifined from the outer scope
        Z_test = np.array(rng_np.normal(size=(100000, z_dim)))
    else:
        Z_test = np.array(Z_test)

    Gz = G_fwd(get_params_G(opt_state_G), Z_test)
    batch_neg_log_like_prev = batch_neg_log_lk_compute(Gz)

    # log the initial eval
    stats_table.loc[len(stats_table)] = [dataset, args.net_version, 0, args.opt, np.real(lr_d),
                                         np.imag(lr_d),
                                         args.momentum_mass,
                                         args.momentum_mass_complex, np.nan, np.nan,
                                         batch_neg_log_like_prev,
                                         lr_mag, lr_arg, momentum_mag, momentum_arg]

    no_improvement_counter = 0
    for epoch in pbar:
        start_time = time.time()

        X, _ = data_sampler(batch_size)

        # to jax numpy
        X = np.array(X)

        i_ = next(itercount)

        Z = np.array(rng_np.normal(size=(X.shape[0], z_dim)))
        curr_loss_D_val, opt_state_D = update_D(i_, opt_state_G, opt_state_D, (X, Z))

        Z = np.array(rng_np.normal(size=(X.shape[0], z_dim)))
        curr_loss_G_val, opt_state_G = update_G(i_, opt_state_G, opt_state_D, (X, Z))

        epoch_time = time.time() - start_time

        pbar.set_description(
            f"GPU Free:{GPU_mem_free} GPU_Used:{GPU_mem_used} Epoch {epoch}  Loss D:{curr_loss_D_val},  Loss G:{curr_loss_G_val} Best NLL:{batch_neg_log_like_prev}")

        batch_neg_log_like = np.inf

        if (epoch % force_log_every) == 0:
            # Z = np.array(rng_np.normal(size=(100000, z_dim)))
            Gz = G_fwd(get_params_G(opt_state_G), Z_test)

            range_lim = 6
            plt.clf()  # clear the plot every time to avoid stacking the cache
            plt.hist2d(Gz[:, 0], Gz[:, 1], range=[[-range_lim, range_lim], [-range_lim, range_lim]],
                       bins=100, cmap=plt.cm.jet)
            plt.tight_layout()
            plt.savefig(os.path.join(out_dir, 'test_%.8i.png' % epoch))

            pickle.dump(Gz, open(os.path.join(out_dir, 'test_%.8i.pckl' % epoch), 'wb'))

            # plt.clf()  # clear the plot
            # sns.kdeplot(Gz[:, 0], Gz[:, 1], shade=True)
            # plt.savefig(os.path.join(out_dir, 'test_%.8i_kde.png' % epoch))

            batch_neg_log_like = batch_neg_log_lk_compute(Gz)
            batch_neg_log_like_prev = min(batch_neg_log_like_prev, batch_neg_log_like)

            # gpu memory...
            # for logging....
            GPUs = GPU.getGPUs()
            if len(GPUs) > 0:
                GPU_mem_free = GPUs[0].memoryFree
                GPU_mem_used = GPUs[0].memoryUsed
            else:
                GPU_mem_free = -1
                GPU_mem_used = -1

        elif (epoch % (force_log_every / 10)) == 0:
            if batch_neg_log_lk_compute is not None:
                Gz = G_fwd(get_params_G(opt_state_G), Z_test)
                batch_neg_log_like = batch_neg_log_lk_compute(Gz)

                if batch_neg_log_like >= batch_neg_log_like_prev:
                    no_improvement_counter = no_improvement_counter + 1
                else:
                    no_improvement_counter = 0

                batch_neg_log_like_prev = min(batch_neg_log_like_prev, batch_neg_log_like)

        # updating stats
        assert lr_d == lr_g, 'logs assume lr_d=lr_g, but they are different'

        # columns = ['dataset', 'network', 'epoch', 'optimizer', 'lr_re', 'lr_complex', 'momentum_mass',
        #            'momentum_mass_complex',
        #            'loss_G',
        #            'loss_D', 'neg_log_like',
        #            'lr_mag', 'lr_arg', 'momentum_mag', 'momentum_arg',
        #            ]

        stats_table.loc[len(stats_table)] = [dataset, args.net_version, epoch + 1, args.opt, np.real(lr_d),
                                             np.imag(lr_d),
                                             args.momentum_mass,
                                             args.momentum_mass_complex, curr_loss_G_val, curr_loss_D_val,
                                             batch_neg_log_like,
                                             lr_mag, lr_arg, momentum_mag, momentum_arg]
        # In case something crashes.
        if (epoch % force_stats_log_every) == 0:
            print('\nPartially Saving stats....')
            fname = out_dir + '/stats.csv'

            # if file does not exist write header
            if not os.path.isfile(fname):
                stats_table.to_csv(fname, header=True, index=False)
            else:  # else it exists so append without writing the header
                stats_table.to_csv(fname, mode='a', header=False, index=False)

            # clear the memory if this grows then it becomes slow
            print('\nClearing Stats from memory')
            del stats_table
            gc.collect()
            # stats_table = None
            stats_table = create_pandas_log_table()

        if np.isnan(curr_loss_D_val).any().item() is True:
            print('\nNan detected stopping....')
            break

        if no_improvement_counter >= no_improvement_after:
            print(f'\nStopping no improvement after {no_improvement_counter}')
            break

    print('\nSaving stats....')
    stats_table.to_csv(fname, mode='a', header=False, index=False)


if __name__ == "__main__":
    args = argparams.collect_params()
    main(args)
