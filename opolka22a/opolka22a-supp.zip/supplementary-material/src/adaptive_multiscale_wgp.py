import numpy as np
import networkx as nx
import tensorflow as tf
import gpflow
from gpflow.utilities import print_summary
from pygsp import graphs
try:
    import matplotlib.pyplot as plt
except:
    pass
from sklearn.metrics import mean_absolute_error
import scipy.stats as st

from kernels.wavelet_kernel import AdaptiveApproximateWavelet
from multiscale_stochastic_block_model import sample_multiscale_graph
from multiscale_wgp import Wavelet, sample_signal_from_prior
from wavelet_utils import mexican_hat, low, scalar_polynomial, plot_spectral_filters, \
    mexican_hat_normalized, morlet

from kernels.chebyshev_kernel import Chebyshev
from kernels.ggp_kernel import GraphGP

def optimize_scipy(model, step_callback, regularize=False):
    opt = gpflow.optimizers.Scipy()
    if regularize:
        loss = lambda: model.training_loss() + 0.05 * (model.kernel.scale1**2 + model.kernel.scale2**2) + (0.001 * model.kernel.alpha**2)#- 0.1 * tf.abs(model.kernel.scale1 - model.kernel.scale2)
    else:
        loss = model.training_loss
    opt.minimize(loss, variables=model.trainable_variables, step_callback=step_callback)

def optimize_tf(model, step_callback, lr=0.1):
    opt = tf.optimizers.Adam(lr=lr)
    for epoch_idx in range(100):
        with tf.GradientTape(watch_accessed_variables=False) as tape:
            tape.watch(model.trainable_variables)
            loss = -model.log_marginal_likelihood()
            gradients = tape.gradient(loss, model.trainable_variables)
        opt.apply_gradients(zip(gradients, model.trainable_variables))
        step_callback(epoch_idx)
        print(f"{epoch_idx}:\tLoss={loss}")

def get_filter_approximation(x, approx_points, proj_mat, exact_filter_f):
    y_approx_points = exact_filter_f(approx_points).numpy()
    coeffs = proj_mat.numpy() @ y_approx_points
    y_poly = scalar_polynomial(x, coeffs)
    return y_poly

def get_subset_cluster_entropy(subset_idcs, nx_graph, cluster_level=0):
    """
    Computes the entropy of a subset of nodes with respect to their belonging to a certain
    cluster in the graph.
    :param subset_idcs: NumPy array with node indices.
    :param nx_graph: NetworkX graph with node labels of format "3-2-4", where first integer
    denotes top-level cluster, second integer denotes second-level cluster etc.
    """
    cluster_labels = np.array(["-".join(label.split("-")[:cluster_level+1]) for label in nx_graph.nodes])
    unique_cluster_labels = np.sort(np.unique(cluster_labels))
    cluster_idcs = np.array([np.where(unique_cluster_labels == label)[0][0] for label in cluster_labels])
    train_cluster_idcs = cluster_idcs[subset_idcs.numpy()]
    rel_freqs = st.relfreq(train_cluster_idcs, numbins=np.max(cluster_idcs)+1).frequency
    entropy = st.entropy(rel_freqs)
    return entropy

# Sample a multiscale graph
graph = sample_multiscale_graph(nodes_per_scale=(8, 8, 8))
graph_nx = graph.copy()
graph = graphs.Graph(nx.adj_matrix(graph, nodelist=sorted(list(graph))).todense())
num_nodes = graph.N
graph.compute_laplacian("normalized")
L_unshifted = graph.L.todense()
L = L_unshifted - np.eye(num_nodes)
eigvals, eigvecs = np.linalg.eig(L)
eigvals = np.real(eigvals)
graph.set_coordinates(seed = 1)
print(f"Number of nodes: {num_nodes}")

def run_training(init_per = 0.5):
    global low_scale, band_scales, init_low_scale, init_band_scales, low_f, band_f, graph, kernel

    # Define some parameters
    low_scale = 12.0
    band_scales = [1.2, 2.2]
    init_low_scale = 10.
    init_band_scales = [1., 5.0]
    polynomial_degree = 6
    low_f = low
    band_f = mexican_hat_normalized
    plot_signal = False

    # Sample a graph signal from the GP prior
    prior_kernel = Wavelet(L_unshifted, low_pass=low_scale, scales=band_scales, low_filter=low_f,
                        band_filter=band_f)
    wave_signal = sample_signal_from_prior(prior_kernel)
    # Prepare GP model
    train_idcs = tf.constant(np.random.choice(num_nodes, int(init_per*num_nodes), replace=False))
    X_full = tf.cast(tf.reshape(tf.range(num_nodes), (-1, 1)), tf.float64)
    Y_full = tf.cast(tf.reshape(wave_signal, (-1, 1)), dtype=tf.float64)
    X_train = tf.gather(X_full, train_idcs)
    Y_train = tf.gather(Y_full, train_idcs)

    global entropy
    entropy = get_subset_cluster_entropy(train_idcs, graph_nx)

    losses, models = [], []
    for _ in range(20):
        # random initialization
        init_low_scale = 10. + np.random.rand()*5.
        init_band_scales = [1. + np.random.rand()*4., 5. + np.random.rand()*5.]
        print(init_low_scale, init_band_scales)
        kernel = AdaptiveApproximateWavelet(L_unshifted, low_pass=init_low_scale, scales=init_band_scales,
                                            poly_degree=polynomial_degree, low_filter=low_f,
                                            band_filter=band_f)
        # change kernel to run baseline gp models
        #kernel = Chebyshev(L_unshifted, poly_degree=polynomial_degree, base_kernel=None, node_feats=None)
        #kernel = GraphGP(graph.W.todense(), base_kernel=None, node_feats=None)

        data = (X_train, Y_train)
        m = gpflow.models.GPR(data, kernel=kernel)

        # Compare approximation vs exact filters
        N = len(eigvals)
        x = np.linspace(np.min(eigvals), np.max(eigvals), N)
        if plot_signal:
            y = low_f(x, kernel.alpha).numpy()
            y_eigvals = low(eigvals, kernel.alpha).numpy()
            y_poly = get_filter_approximation(x, kernel.approx_points, kernel.proj_mat,
                                            lambda x: low_f(x, kernel.alpha))
            plt.figure()
            plt.plot(x, y, label="exact filter")
            plt.plot(x, y_poly, label="approximated filter")
            plt.plot(eigvals, y_eigvals, 'x', color="blue", label="eigenvalues")
            plt.legend()
            plt.show()

        # Compare approximation vs exact filters for band pass
        N = len(eigvals)
        x = np.linspace(np.min(eigvals), np.max(eigvals), N)
        if plot_signal:
            y = mexican_hat(x, kernel.scale1).numpy()
            y_eigvals = mexican_hat(eigvals, kernel.scale1).numpy()
            y_poly = get_filter_approximation(x, kernel.approx_points, kernel.proj_mat,
                                            lambda x: mexican_hat(x, kernel.scale1))
            plt.figure()
            plt.plot(x, y, label="exact filter")
            plt.plot(x, y_poly, label="approximated filter")
            plt.plot(eigvals, y_eigvals, 'x', color="blue", label="eigenvalues")
            plt.legend()
            plt.show()

        def step_callback(step, variables=None, values=None):
            if step % 20 == 0:
                pred, pred_var = m.predict_y(X_full)
                pred = pred.numpy().reshape(-1)
                mae = mean_absolute_error(pred, wave_signal.reshape(-1))
                print(f"Epoch {step}:\tMAE={mae:.5f}")
                if plot_signal:
                    axes = plt.gca()
                    graph.plot_signal(pred, ax=axes)
                    axes.set_title(f"prediction after {step} epochs (MAE={mae:.5f})")
                    plt.show()
                    print_summary(m)
        optimize_scipy(m, step_callback, regularize=True)
        # optimize_tf(m, step_callback)
        losses.append(m.training_loss().numpy())
        models.append(m)
    idmin = np.argmin(losses)
    m = models[idmin]
    print_summary(m)

    global pred_low, mae, e_mae
    pred_low = m.kernel.alpha.numpy()
    pred_band_scales = [m.kernel.scale1.numpy(), m.kernel.scale2.numpy()]
    '''
    plot_spectral_filters(low_scale, band_scales, low_f, band_f, eigvals=eigvals, pred_low_scale=pred_low,
                          pred_band_scales=pred_band_scales, approx=True,
                          approx_band_filter=lambda x, param: get_filter_approximation(x, kernel.approx_points, kernel.proj_mat, lambda x: band_f(x, param)),
                          approx_low_filter=lambda x, param: get_filter_approximation(x, kernel.approx_points, kernel.proj_mat, lambda x: low_f(x, param)), )
    '''
    # compute mae of best model's prediction
    pred, pred_var = m.predict_y(X_full)
    pred = pred.numpy().reshape(-1)
    mae = mean_absolute_error(pred, wave_signal.reshape(-1))

    # compute mae of filter at eigenvalues
    ground = low(graph.e, alpha = low_scale, shift = 0.) + mexican_hat_normalized(graph.e, band_scales[0], shift = 0.) + mexican_hat_normalized(graph.e, band_scales[1], shift = 0.)
    e_recovered = low(graph.e, alpha = m.kernel.alpha, shift = 0.) + mexican_hat_normalized(graph.e, m.kernel.scale1, shift = 0.) + mexican_hat_normalized(graph.e, m.kernel.scale2, shift = 0.)
    e_mae = mean_absolute_error(ground, e_recovered)
    
    return np.array(sorted(pred_band_scales))

if __name__ == '__main__':
    import os
    if not os.path.isdir('npy'):
        os.mkdir('npy')
    # 10 %
    all_scales = []
    low_scales = []
    maes, e_maes = [], []
    entropies = []
    for _ in range(100):
        band_scales = run_training(init_per = 0.1)
        all_scales.append(band_scales)
        low_scales.append(pred_low)
        maes.append(mae)
        e_maes.append(e_mae)
        entropies.append(entropy)
    all_scales = np.stack(all_scales, axis=0)

    np.save("npy/all_scales10.npy", all_scales)
    np.save("npy/low_scales10.npy", low_scales)
    np.save("npy/maes10.npy", maes)
    np.save("npy/e_maes10.npy", e_maes)
    np.save("npy/entropies10.npy", entropies)

    # 20 %
    all_scales = []
    low_scales = []
    maes, e_maes = [], []
    entropies = []
    for _ in range(100):
        band_scales = run_training(init_per = 0.2)
        all_scales.append(band_scales)
        low_scales.append(pred_low)
        maes.append(mae)
        e_maes.append(e_mae)
        entropies.append(entropy)
    all_scales = np.stack(all_scales, axis=0)

    np.save("npy/all_scales20.npy", all_scales)
    np.save("npy/low_scales20.npy", low_scales)
    np.save("npy/maes20.npy", maes)
    np.save("npy/e_maes20.npy", e_maes)
    np.save("npy/entropies20.npy", entropies)

    # 30 %
    all_scales = []
    low_scales = []
    maes, e_maes = [], []
    entropies = []
    for _ in range(100):
        band_scales = run_training(init_per = 0.3)
        all_scales.append(band_scales)
        low_scales.append(pred_low)
        maes.append(mae)
        e_maes.append(e_mae)
        entropies.append(entropy)
    all_scales = np.stack(all_scales, axis=0)

    np.save("npy/all_scales30.npy", all_scales)
    np.save("npy/low_scales30.npy", low_scales)
    np.save("npy/maes30.npy", maes)
    np.save("npy/e_maes30.npy", e_maes)
    np.save("npy/entropies30.npy", entropies)

    # 40 %
    all_scales = []
    low_scales = []
    maes, e_maes = [], []
    entropies = []
    for _ in range(100):
        band_scales = run_training(init_per = 0.4)
        all_scales.append(band_scales)
        low_scales.append(pred_low)
        maes.append(mae)
        e_maes.append(e_mae)
        entropies.append(entropy)
    all_scales = np.stack(all_scales, axis=0)

    np.save("npy/all_scales40.npy", all_scales)
    np.save("npy/low_scales40.npy", low_scales)
    np.save("npy/maes40.npy", maes)
    np.save("npy/e_maes40.npy", e_maes)
    np.save("npy/entropies40.npy", entropies)

    # 50 %
    all_scales = []
    low_scales = []
    maes, e_maes = [], []
    entropies = []
    for _ in range(100):
        band_scales = run_training(init_per = 0.5)
        all_scales.append(band_scales)
        low_scales.append(pred_low)
        maes.append(mae)
        e_maes.append(e_mae)
        entropies.append(entropy)
    all_scales = np.stack(all_scales, axis=0)

    np.save("npy/all_scales50.npy", all_scales)
    np.save("npy/low_scales50.npy", low_scales)
    np.save("npy/maes50.npy", maes)
    np.save("npy/e_maes50.npy", e_maes)
    np.save("npy/entropies50.npy", entropies)

    # 60 %
    all_scales = []
    low_scales = []
    maes, e_maes = [], []
    entropies = []
    for _ in range(100):
        band_scales = run_training(init_per = 0.6)
        all_scales.append(band_scales)
        low_scales.append(pred_low)
        maes.append(mae)
        e_maes.append(e_mae)
        entropies.append(entropy)
    all_scales = np.stack(all_scales, axis=0)

    np.save("npy/all_scales60.npy", all_scales)
    np.save("npy/low_scales60.npy", low_scales)
    np.save("npy/maes60.npy", maes)
    np.save("npy/e_maes60.npy", e_maes)
    np.save("npy/entropies60.npy", entropies)

    # 70 %
    all_scales = []
    low_scales = []
    maes, e_maes = [], []
    entropies = []
    for _ in range(100):
        band_scales = run_training(init_per = 0.7)
        all_scales.append(band_scales)
        low_scales.append(pred_low)
        maes.append(mae)
        e_maes.append(e_mae)
        entropies.append(entropy)
    all_scales = np.stack(all_scales, axis=0)

    np.save("npy/all_scales70.npy", all_scales)
    np.save("npy/low_scales70.npy", low_scales)
    np.save("npy/maes70.npy", maes)
    np.save("npy/e_maes70.npy", e_maes)
    np.save("npy/entropies70.npy", entropies)

    #all_scales = np.load("all_scales.npy")
    '''
    plt.title("Recovery of scale parameters of the Wavelet kernel")
    plt.xlabel("scale 1")
    plt.ylabel("scale 2")
    plt.scatter(all_scales[:, 0], all_scales[:, 1], marker="x", label="learned scales")
    plt.scatter([1.20], [2.2], c="green", marker="o", label="ground truth scales")
    plt.legend()
    plt.show()
    '''