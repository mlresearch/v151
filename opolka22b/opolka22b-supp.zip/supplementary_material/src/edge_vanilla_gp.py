import pathlib
import random
import sys
from collections import OrderedDict

import numpy as np
import gpflow
import tensorflow as tf
from gpflow.kernels import Polynomial, RBF
from gpflow.likelihoods import Bernoulli
from scipy.cluster.vq import kmeans2

from data_loading.link_prediction_dataset import LinkPredictionDataset
from metrics import compute_mean, compute_max, compute_binary_accuracy, compute_auc, compute_ap
from training_environment import PerformanceLogger, OutputLogger, \
    checkpoint_filepath
from training_environment import TrainingSettings as ts
from utils import save_tf_module_weights, load_tf_module_weights


def training_step(train_loader, gprocess, optimizer, ds, logger):
    for edge_idcs, labels, conv_mat, subgraph_nodes, node_feats in train_loader:
        node1_feats = tf.gather(node_feats, tf.cast(edge_idcs[:, 0], tf.int32))
        node2_feats = tf.gather(node_feats, tf.cast(edge_idcs[:, 1], tf.int32))
        batch_node_feats = tf.concat((node1_feats, node2_feats), axis=-1)
        # Gradient update
        with tf.GradientTape(watch_accessed_variables=False) as tape:
            tape.watch(gprocess.trainable_variables)
            objective = -gprocess.elbo((batch_node_feats, labels))
            gradients = tape.gradient(objective, gprocess.trainable_variables)
        optimizer.apply_gradients(zip(gradients, gprocess.trainable_variables))
        logger.add_values({
            "nELBO": objective.numpy(),
            "nELBOc": objective.numpy(),
            "grad_norm": tf.linalg.global_norm(gradients).numpy(),
        })


def evaluate(data_loader, gprocess, logger, num_samples, ds, prefix):
    for edge_idcs, labels, conv_mat, subgraph_nodes, node_feats in data_loader:
        node1_feats = tf.gather(node_feats, tf.cast(edge_idcs[:, 0], tf.int32))
        node2_feats = tf.gather(node_feats, tf.cast(edge_idcs[:, 1], tf.int32))
        batch_node_feats = tf.concat((node1_feats, node2_feats), axis=-1)
        # get prediction and likelihood
        pred_y, pred_y_var = gprocess.predict_y(batch_node_feats)
        likelihood = gprocess.predict_log_density((batch_node_feats, labels))
        logger.add_values({
            f"{prefix}_labels": labels,
            f"{prefix}_predictions": pred_y.numpy(),
            f"{prefix}_variances": pred_y_var.numpy(),
            f"{prefix}_likelihood": likelihood.numpy(),
        })


def setup_training_env():
    cp_folder = pathlib.Path(ts.cp_folder)
    if not cp_folder.exists():
        cp_folder.mkdir(parents=True, exist_ok=True)
    # Set up performance logger
    log_filepath = checkpoint_filepath(cp_folder, "log", __file__,
                                       file_ending=".pk")
    metric_funcs = OrderedDict({
        "nELBOc": (lambda m: np.mean(m["nELBOc"])),
        "nELBO": (lambda m: np.mean(m["nELBO"])),
        "train_likelihood": (lambda m: np.mean(m["train_likelihood"])),
        "kl": (lambda m: np.mean(m["kl"])),
        "mean_glob_grad_norm": (lambda m: compute_mean(m["grad_norm"])),
        "max_glob_grad_norm": (lambda m: compute_max(m["grad_norm"])),
        "mean_orig_grad_norm": (lambda m: compute_mean(m["orig_grad_norm"])),
        "max_orig_grad_norm": (lambda m: compute_max(m["orig_grad_norm"])),
        "test_acc": (lambda m: compute_binary_accuracy(m["test_predictions"], m["test_labels"])),
        "test_auc": (lambda m: compute_auc(m["test_predictions"], m["test_labels"])),
        "test_ap": (lambda m: compute_ap(m["test_predictions"], m["test_labels"])),
        "test_likelihood": (lambda m: compute_mean(m["test_likelihood"])),
    })
    logger = PerformanceLogger(
        metric_funcs, "nELBO", log_filepath, write_every=ts.write_log_every,
        final_test_metrics=["test_acc", "test_auc", "test_ap",
                            "test_likelihood"])
    # Set up model checkpointing
    weights_filepath = checkpoint_filepath(cp_folder, "weights", __file__,
                                           file_ending=".pk")
    # Set up writing stdout to file
    output_filepath = checkpoint_filepath(cp_folder, "output", __file__,
                                          file_ending=".txt")
    output_logger = OutputLogger(output_filepath)
    sys.stdout = output_logger
    summary_filepath = checkpoint_filepath(cp_folder, "summary", __file__,
                                           file_ending=".txt")
    results_filepath = checkpoint_filepath(cp_folder, "results", __file__,
                                                file_ending=".pk")
    # Write hyperparameters to file
    ts.write_summary_file(checkpoint_filepath(cp_folder, "hyperparams",
                                              __file__, file_ending=".txt"))
    print(ts.settings_description())
    return (log_filepath, logger, weights_filepath, output_logger,
            summary_filepath, results_filepath)


def run_training():
    (log_filepath, logger, weights_filepath, output_logger,
     summary_filepath, results_filepath) = setup_training_env()

    # Set up training environment
    # Set random seed
    random.seed(ts.seed)
    np.random.seed(ts.seed)
    tf.random.set_seed(ts.seed)
    # Set float type
    gpflow.config.set_default_float(ts.float_type)
    gpflow.config.set_default_jitter(ts.jitter)

    # Load data set
    ds = LinkPredictionDataset(ts.dataset_path, ts.dataset_name,
                               ts.dataset_folder, split_seed=ts.seed,
                               train_batch_size=ts.batch_size,
                               test_batch_size=ts.test_batch_size,
                               subsample_sizes=ts.num_node_samples,
                               float_type=ts.float_type, extract_subgraphs=True,
                               node2vec_embeddings=ts.node2vec_embeddings,
                               test_fraction=ts.test_fraction,
                               train_set_frac=ts.train_set_frac)
    train_loader, test_loader = ds.train_loader, ds.test_loader

    # Init inducing points
    num_inducing_nodes = (ds.num_nodes // 8 if ts.num_inducing_nodes is None
                          else ts.num_inducing_nodes)
    # We initialise the inducing points by concatenating node features of
    # training nodes and computing their kmeans.
    edge_features = np.concatenate((
        ds.node_features[ds.pos_train_edges[:, 0]],
        ds.node_features[ds.pos_train_edges[:, 1]]
    ), axis=-1)
    inducing_points = kmeans2(edge_features, num_inducing_nodes,
                              minit='points')[0]    # use as many inducing points as training samples

    # Init GP model
    num_node_feats = ds.node_features.shape[-1]
    kernel = RBF(
        lengthscales=ts.initial_lengthscale * np.ones(2*num_node_feats))
    gprocess = gpflow.models.SVGP(kernel, Bernoulli(), inducing_points)

    # Init optimizer
    optimizer = tf.optimizers.Adam(learning_rate=ts.lr)

    for epoch in range(ts.num_epochs):
        training_step(train_loader, gprocess, optimizer, ds, logger)
        logger.complete_epoch(lambda: save_tf_module_weights(gprocess,
                                                             weights_filepath))
        print(logger.epoch_summary())
        if (logger.has_converged(convergence_diff=ts.convergence_stop)):
            break

    # Evaluate on test set with the best model
    load_tf_module_weights(gprocess, weights_filepath)
    evaluate(test_loader, gprocess, logger, ts.test_num_samples, ds,
             prefix="test")
    logger.write_epoch_metrics(results_filepath)
    logger.complete_epoch()
    print(logger.epoch_summary())

    # Cleanup after training
    output_logger.close()
    sys.stdout = sys.__stdout__
    logger.write(log_filepath)
    logger.write_summary(summary_filepath, ts.settings_description())
    return logger


if __name__ == '__main__':
    run_training()