# A Global Defense Approach via Adversarial Attack and Defense Risk Guaranteed Bounds

## Introduction 
Pytorch implementation for the paper "A Global Defense Approach via Adversarial Attack and Defense Risk Guaranteed Bounds" 

## Note 
- The input range should be [0, 1]. It is worth noting that, the standard `epsilon` threshold is for the input range [0, 1] (e.g., `epsilon`=8/255 for the CIFAR10 dataset), therefore, we should not normalized the input as in other implementations (e.g., normalizing CIFAR10 images with mean=0.5 and std=0.5 as in this [tutorial](https://pytorch.org/tutorials/beginner/blitz/cifar10_tutorial.html)). In case using normalization, the `epsilon` should also be scaled to get a similar attack performance (e.g., `new_epsilon`=`epsilon`/std). 

## Requirements 
- Python 3.7
- Auto-Attack 0.1
- Foolbox 3.2.1
- Numba 0.52.0

## Robustness Evaluation 
We use several attackers to challenge the baselines and our method. 

(1) PGD Attack. We use the pytorch version of the Cifar10 Challenge with norm Linf, from the [implementation](https://github.com/yaodongyu/TRADES/blob/master/pgd_attack_cifar10.py). Attack setting for the Cifar10 dataset: `epsilon`=8/255, `step_size`=2/255, `num_steps`=200, `random_init`=True 

(2) Auto-Attack. The official implementation in the [link](https://github.com/fra31/auto-attack). We test with the standard version with both Linf and L2 norm. 

(3) Brendel & Bethge Attack. The B&B attack is adapted from [the implementation](https://github.com/wielandbrendel/adaptive_attacks_paper/tree/master/07_ensemble_diversity) of the paper ["On Adaptive Attacks to Adversarial Example Defenses"](https://arxiv.org/abs/2002.08347). It has been initialized with PGD attack (20 steps, `eta`=`epsilon`/2) to increase the success rate.  

We use the full test-set (10k images) for the attack (1) and 1000 first test images for the attacks (2-3).

## Training and Evaluation 

We provide the default setting for each corresponding dataset (MNIST, CIFAR10) which is used in our paper.

To reproduce the baselines, run the following script. 
```shell
python run_baseline.py
```

To reproduce our results, run the following script. 
```shell
python run_main.py
```

## References
- The B&B attack is adapted from [the implementation](https://github.com/wielandbrendel/adaptive_attacks_paper/tree/master/07_ensemble_diversity) of the paper ["On Adaptive Attacks to Adversarial Example Defenses"](https://arxiv.org/abs/2002.08347). 
- The Auto-attack is adapted from [the implementation](https://github.com/fra31/auto-attack) of the paper ["Reliable evaluation of adversarial robustness with an ensemble of diverse parameter-free attacks", Francesco Croce, Matthias Hein, ICML 2020](https://arxiv.org/abs/2003.01690).