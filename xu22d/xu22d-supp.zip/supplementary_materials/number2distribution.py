import numpy as np

def number_2_dist(idist, d, Md, gamma_discrete):
    vec_dist = np.zeros(2*Md + 1)
    j_bit = 0
    while j_bit < 2*Md + 1:
        current_bit = idist % (Md + 1)
        vec_dist[j_bit] = current_bit
        idist = idist // (Md + 1)
        j_bit += 1
    vec_dist = vec_dist * gamma_discrete
    return vec_dist