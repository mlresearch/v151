import pickle
import random
from tqdm import tqdm

import dgl
import networkx as nx
import copy
import torch
import numpy as np

from pathlib import Path

from decomp_gen.data_structures.generating_tree import GeneratingTree

SEED = 1234
TRAIN_RATIO = 0.7
VAL_RATIO = 0.1
TEST_RATIO = 1.0 - TRAIN_RATIO - VAL_RATIO

def generateSeveralSamplesFromAGraph(G,times,includeInitialGraph=True):
    res = []
    mlen = -1

    if includeInitialGraph:
        times-=1

    print("Generating requested number of reordering for each graph:")
    for g in tqdm(G):
        if includeInitialGraph:
            res.append(g)
            mlen = max(mlen,g.getDTdiameter())
        for i in range(times):
            try:
                g.randomBFSReorderNodes()
                newg = copy.deepcopy(g)
                res.append(newg)
                mlen = max(mlen,newg.getDTdiameter())
            except:
                print("Error in generating new BFS reorder")

    random.shuffle(res)
    mlen = int((mlen+1)/2)
    return res, mlen

def generateDatasetFromGraphs(graphs, graphsMaxLen=100):
    # making indices for train/test
    train_last_idx = int(float(len(graphs)) * TRAIN_RATIO)
    eval_last_idx = int(float(len(graphs)) * VAL_RATIO) + train_last_idx

    indices = list(range(len(graphs)))

    train_last_idx = int(float(len(graphs)) * TRAIN_RATIO)
    test_last_idx = int(float(len(graphs)) * TEST_RATIO) + train_last_idx

    indices = list(range(len(graphs)))

    train_idxs = indices[0:train_last_idx]
    test_idxs = indices[train_last_idx:test_last_idx]
    eval_idxs = indices[test_last_idx:]

    test_initial_graphs = [graphs[idx] for idx in test_idxs]
    validation_initial_graphs = [graphs[idx] for idx in eval_idxs]
    train_initial_graphs = [graphs[idx] for idx in train_idxs]

    train = train_initial_graphs
    test = test_initial_graphs
    validation = validation_initial_graphs
    MaxLen = graphsMaxLen

    return train, test, validation, MaxLen

def getGeneratingTrees(g,MaskLen, makeFromTree=False):
    # print("MaskLen",MaskLen)
    res = []
    if makeFromTree:
        t = g
    else:
        t = g.getDecompositionTree()
    TPLR = t.pathLenRepresentation()
    GT = GeneratingTree()
    for ii, l in enumerate(TPLR):
        T = GT.getSimpleTree()
        DGLT = dgl.DGLGraph(T)

        # p=nx.shortest_path_length(T, source=0)
        #
        # for ii,v in enumerate(DGLT.nodes()):
        #     vv = int(v.item())
        #     d = torch.zeros((1,4)).type(torch.FloatTensor)
        #     # height = TPLR[0]-p[vv]
        #     if vv==0:
        #         d[0,0]=1.0
        #     else:
        #         d[0,1]=1.0
        #     d[0,2]=float(T.degree[vv])
        #     d[0,3]=float(p[vv])
        #     # d[0][p[vv]]=1.0
        #     # d[0,MaskLen:MaskLen+randomFeatures]=torch.empty(1,randomFeatures).normal_(mean=0.0,std=1.0)
        #     # if ii>0:
        #     #     d[0][MaskLen+height]=1.0
        #     DGLT.nodes[[v]].data['d']=d

        limits = GT.nextStepLimit()

        mask = [0.0]*MaskLen
        if limits[1] == -1:
            limits[1] = MaskLen
        for i in range(limits[0], limits[1]):
            mask[i] = 1.0

        #Making dataset just for times we want to make choice:
        if limits[1]-limits[0]>1:
            res.append({'T': DGLT, "Mask": mask, "CurrentNode": GT.currentNode().getLabel(),"l":l})
        GT.makeStep(l)

    return res


def getTreeDataSet(graphs, samplePerGraph, MaxLen=100, name=None, makeFromTree=False):
    if name!=None:
        namePath=(Path("__file__").resolve().parent)
        relative_path="data/Datasets/treeGeneratorData/"+name+".dat"
        namePath = (namePath / relative_path).resolve()
        try:
            print('looking for data: ', namePath)
            with open(namePath, "rb") as f:
                data = pickle.load(f)
            return data[0], data[1], data[2], data[3]
        except:
            print("Dataset not found in saved tree generator data, generating dataset:")

    if name==None:
        name = "tmp"

    namePath=(Path("__file__").resolve().parent)
    relative_path = "data/Datasets/treeGeneratorData/"+name+".dat"
    namePath = (namePath / relative_path).resolve()

    trainG, testG, validationG, MaxLen = generateDatasetFromGraphs(graphs, graphsMaxLen=MaxLen)
    print("MaxLen in data generation: ", MaxLen)

    print("Size of train/validation/test: ", len(trainG), len(validationG), len(testG))
    train = []
    validation = []
    test = []

    Extend = 1
    MaskLen = MaxLen+Extend

    print("Generating extending tree dataset for train dataset:")
    for g in tqdm(trainG):
        if makeFromTree:
            train.extend(getGeneratingTrees(g, MaskLen, makeFromTree=True))
        else:
            train.extend(getGeneratingTrees(g, MaskLen))

    print("Generating extending tree dataset for validation dataset:")
    for g in tqdm(validationG):
        if makeFromTree:
            validation.extend(getGeneratingTrees(g, MaskLen, makeFromTree=True))
        else:
            validation.extend(getGeneratingTrees(g, MaskLen))

    print("Generating extending tree dataset for test dataset:")
    for g in tqdm(testG):
        if makeFromTree:
            test.extend(getGeneratingTrees(g, MaskLen, makeFromTree=True))
        else:
            test.extend(getGeneratingTrees(g, MaskLen))

    data = [train, validation, test, MaskLen]
    with open(namePath, "wb") as f:
        pickle.dump(data, f)

    return train, validation, test, MaskLen
