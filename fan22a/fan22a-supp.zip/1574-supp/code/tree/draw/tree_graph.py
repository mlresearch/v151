import numpy as np
import matplotlib.pyplot as plt


def draw_stats(dims, _means, _ints, ax, color, label=None, legend_position='best'):
    ax.plot(dims, _means, color=color, label=label)
    ax.fill_between(
        dims,
        (_means - _ints),
        (_means + _ints), color=color, alpha=.1)
    if label != None:
        ax.legend(loc=legend_position)


def plot_bound_stats(x_axis, bound_bf, bound_bp, bp_mean_log, bp_std_log, bf_mean_log, bf_std_log):
    plt.plot(x_axis, bound_bf, '--', color='blue')
    plt.plot(x_axis, bound_bp, '--', color='magenta')
    draw_stats(x_axis, (bp_mean_log), (bp_std_log), ax, 'magenta')
    draw_stats(x_axis, (bf_mean_log), (bf_std_log), ax, 'blue')
    plt.grid(which='major')
    plt.minorticks_on()
    plt.tight_layout()


def load_stats(file_name, folder='draw/baryc_'):
    file = np.log(np.load(folder + 'bp' + file_name))
    bp_mean_log = file.mean(axis=1)
    bp_std_log = file.std(axis=1)

    file = np.log(np.load(folder + 'Sinkhorn' + file_name))
    bf_mean_log = file.mean(axis=1)
    bf_std_log = file.std(axis=1)
    return bp_mean_log, bp_std_log, bf_mean_log, bf_std_log


#!barycenter m change
file_name = '_n_10_m_3_1_change.npy'
bp_mean_log, bp_std_log, bf_mean_log, bf_std_log = load_stats(
    file_name, folder='draw/baryc_')
bary_m_axis = np.array([3, 4, 5, 6, 7])
fig, ax = plt.subplots(figsize=(4, 3), dpi=80)
ax.set_xlabel(r'$m$', fontsize=12)
bound_bf = np.log(bary_m_axis**3 * 10**bary_m_axis)
bound_bp = np.log(bary_m_axis * 10**2 / 1e4)
bound_bf -= (bound_bf[0] - bf_mean_log[0]) - 0.3
bound_bp -= (bound_bp[0] - bp_mean_log[0]) - 2
plot_bound_stats(bary_m_axis, bound_bf, bound_bp, bp_mean_log,
                 bp_std_log, bf_mean_log, bf_std_log)
fig.savefig(f"./draw/barycenter_fix_n_eps2e1.png",
            bbox_inches='tight', dpi=200)


#!barycenter n change
file_name = '_total_m_4_n_20_10_change.npy'
bp_mean_log, bp_std_log, bf_mean_log, bf_std_log = load_stats(
    file_name, folder='draw/baryc_')

bary_n_axis = np.array([20, 30, 40, 50, 60])
fig, ax = plt.subplots(figsize=(4, 3), dpi=80)
ax.set_xlabel(r'$n$', fontsize=12)
ax.set_ylabel('logarithm of run time', fontsize=12)
plt.plot(bary_n_axis, 1 + np.log(bary_n_axis**4 / 3e5), '--',
         color='blue', label=r'reference $\tilde O (m^3 n^m)$')
plt.plot(bary_n_axis, np.log(
    bary_n_axis**2 / 1e4) + 1, '--', color='magenta', label=r'reference $\tilde O (d(G)m n^2)$')
draw_stats(bary_n_axis, (bf_mean_log), (bf_std_log),
           ax, 'blue', 'Brutal force Sinkhorn')
draw_stats(bary_n_axis, (bp_mean_log), (bp_std_log),
           ax, 'magenta', 'Ours Sinkhorn BP')
plt.grid(which='major')
plt.minorticks_on()
plt.tight_layout()
fig.savefig(f"./draw/barycenter_fix_m_eps2e1.png",
            bbox_inches='tight', dpi=200)

#!hmm m change
file_name = '_n_10_m_2_1_change.npy'
bp_mean_log, bp_std_log, bf_mean_log, bf_std_log = load_stats(
    file_name, folder='draw/HMM_')

bary_m_axis = np.array([4, 6, 8, 10, 12])
bary_m_axis_short = np.array([4, 6, 8])
fig, ax = plt.subplots(figsize=(4, 3), dpi=80)
ax.set_xlabel(r'$m$', fontsize=12)
plt.plot(bary_m_axis_short, 0.5 + np.log(bary_m_axis_short**3 * 10**bary_m_axis_short / 5e7), '--',
         color='blue')
plt.plot(bary_m_axis, 1.5 + np.log(
    (bary_m_axis / 2 + 1) * bary_m_axis / 6e2), '--', color='magenta')
draw_stats(bary_m_axis, (bp_mean_log), (bp_std_log),
           ax, 'magenta')

draw_stats(bary_m_axis_short, (bf_mean_log), (bf_std_log),
           ax, 'blue')
plt.grid(which='major')
plt.minorticks_on()
plt.tight_layout()
fig.savefig(f"./draw/hmm_fix_n_eps2e1.png",
            bbox_inches='tight', dpi=200)

#!hmm n change

file_name = '_total_m_2_n_20_10_change.npy'
bp_mean_log, bp_std_log, bf_mean_log, bf_std_log = load_stats(
    file_name, folder='draw/HMM_')
bary_n_axis = np.array([20, 30, 40, 50, 60])
fig, ax = plt.subplots(figsize=(4, 3), dpi=80)
ax.set_xlabel(r'$n$', fontsize=12)
ax.set_ylabel('logarithm of run time', fontsize=12)
plt.plot(bary_n_axis, 0.5 + np.log(bary_n_axis**4 / 8e5), '--',
         color='blue')
plt.plot(bary_n_axis, 1 + np.log(
    bary_n_axis**2 / 2e4), '--', color='magenta')
draw_stats(bary_n_axis, (bp_mean_log), (bp_std_log),
           ax, 'magenta')
draw_stats(bary_n_axis, (bf_mean_log), (bf_std_log),
           ax, 'blue')
plt.grid(which='major')
plt.minorticks_on()
plt.tight_layout()
fig.savefig(f"./draw/hmm_fix_m_eps2e1.png",
            bbox_inches='tight', dpi=200)
