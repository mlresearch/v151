# How to run? (we give an example of DCGAN on CIFAR-10)

### Precalculated statistics for computing FID score
You can also download the precalculated_statistics from `http://bioinf.jku.at/research/ttur/`
```
# Simultaneous SGD
$ python -W ignore main.py --arch dcgan --resample False --dataset cifar10 --adv_loss wgan-gp --g_lr 2e-3 --d_lr 2e-3 --optim sgd --alternating False --total_step 200000

# Alternating SGD
$ python -W ignore main.py --arch dcgan --resample False --dataset cifar10 --adv_loss wgan-gp --g_lr 5e-3 --d_lr 5e-3 --optim sgd --alternating True --total_step 200000

```
