from ray.rllib.agents.impala.impala import ImpalaAgent, DEFAULT_CONFIG

__all__ = ["ImpalaAgent", "DEFAULT_CONFIG"]
