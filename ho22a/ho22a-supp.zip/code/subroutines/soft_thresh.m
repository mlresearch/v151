function Y = soft_thresh(X, thresh)
    Y = max(X - thresh, 0);
    Y = Y + min(X+thresh, 0);
end

