from models.personalizer.kernel import *


class SIMSGP:
    def __init__(self, cov, mean, noise = np.log(0.5)):
        self.cov = cov
        self.mean = mean
        self.noise = noise

    def NLL(self, X, Y):
        Yr = tf.reshape(tf.convert_to_tensor(Y), [-1, 1])
        Yc = Yr - self.mean.m(X)
        Kxx = self.cov.cov(X) + tf.cast(KB.exp(2.0 * self.noise), tf.float32) * KB.eye(Yc.shape[0])
        L = tf.linalg.cholesky(Kxx)
        Linv = tf.matmul(tf.linalg.inv(L), Yc)
        res = KB.sum(KB.log(tf.linalg.tensor_diag_part(L))) + 0.5 * tf.matmul(tf.transpose(Linv), Linv)
        return res

    def predict(self, Xt, X, Y, var = False):
        Yr = tf.reshape(tf.convert_to_tensor(Y), [-1, 1])
        Yc = Yr - self.mean.m(X)
        Ktx = self.cov.cov(Xt, X)
        Kxx = self.cov.cov(X)
        Q_inv = tf.linalg.inv(Kxx + tf.cast(KB.exp(2.0 * self.noise), tf.float32) * KB.eye(Yc.shape[0]))
        Yt = tf.matmul(Ktx, tf.matmul(Q_inv, Yc)) + self.mean.m(Xt)
        if var is False:
            return Yt
        Ktt = self.cov.cov(Xt)
        Vt = Ktt - tf.matmul(Ktx, tf.matmul(Q_inv, tf.transpose(Ktx)))
        return Yt, Vt