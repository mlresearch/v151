%% This code computes the covraiabnce of [X_i^r, X_{\bar{i}}^r]

function [T] = Covaraiance_corr(n,E_factor,N,h,f,lag)
Nnodes = size(h,1);
T = zeros(Nnodes);
initial = zeros(Nnodes,lag);
for cnt = 1:n
E = E_factor*randn(Nnodes,N);
[temp] = DataGenerator(N,h,E, initial,lag);

initial = temp(:,N-lag+1:N);
temp = 1/sqrt(N)*temp*transpose(exp(-1j*f*(0:(N-1))));
T = T +conj(temp)*transpose(temp);
end
T = T/2/n;

end

