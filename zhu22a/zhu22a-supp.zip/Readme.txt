Dear reader,

This supplementary material is structured as follows:

OptimalDesigns.ipynb
* Experiments on the illustrative and synthetic problems (Sections 5.1 and 5.2)

OptimalDesigns (MNIST).ipynb
* Experiments on the MNIST dataset (Appendix)

Sincerely yours,

The authors
