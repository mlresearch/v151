import torch.nn.functional as F
import torch

def fgsm(model, X, y, epsilon, random_start=True):
    
    if random_start:
        delta = torch.zeros_like(X).uniform_(-epsilon, epsilon).cuda().requires_grad_(True)
    else:
        delta = torch.zeros_like(X).cuda().requires_grad_(True)
    
    output = model(X + delta)
    loss = F.cross_entropy(output, y)
    loss.backward()
    delta.data = torch.clamp(X + epsilon * torch.sign(delta.grad), 0, 1) - X
    
    return delta.detach()


def pgd(model, X, y, epsilon, alpha, attack_iters, n_restarts=0):
    
    fail_inds = torch.tensor([True] * X.shape[0])
    delta = torch.zeros_like(X).uniform_(-epsilon, epsilon).cuda().requires_grad_(True)
    
    for _ in range(n_restarts + 1):
        for i in range(attack_iters):
            output = model(X + delta)
            loss = F.cross_entropy(output, y)
            loss.backward()
            d = torch.clamp(delta + alpha * torch.sign(delta.grad), -epsilon, epsilon)
            d = torch.clamp(X + d, 0, 1) - X
            delta.data[fail_inds] = d[fail_inds]
            delta.grad.zero_()
        
        if n_restarts > 0:
            output = model(X + delta)
            fail_inds = (output.max(1)[1] == y)
            delta.data[fail_inds] = torch.zeros_like(delta).uniform_(-epsilon, epsilon)[fail_inds]
    
    return delta.detach()


"""
Wang, Yisen, et al. "On the Convergence and Robustness of Adversarial Training." ICML. Vol. 1. 2019.
"""
def dat_pgd(model, X, y, epsilon, alpha, attack_iters, crit):

    delta = torch.zeros_like(X).uniform_(-epsilon, epsilon).cuda().requires_grad_(True)

    for i in range(attack_iters):
        loss = F.cross_entropy(model(X + delta), y)
        loss.backward()
        grad = delta.grad.detach().clone()
        delta.grad.zero_()
        
        d = torch.clamp(delta + alpha * torch.sign(grad), -epsilon, epsilon)
        d = torch.clamp(X + d, 0, 1) - X

        grad_flatten = grad.view(delta.size(0),-1)
        grad_norm = torch.norm(grad_flatten, p=1, dim=1)
        diff = delta.view(delta.size(0),-1)
        fosc = -(grad_flatten * diff).sum(dim=1) + epsilon * grad_norm
        delta.data[fosc > crit] = d[fosc > crit]

    return delta.detach()


def pgd_train(model, X, y, epsilon, alpha, attack_iters):
    delta = torch.zeros_like(X).uniform_(-epsilon, epsilon).cuda().requires_grad_(True)
    
    for i in range(attack_iters):
        loss = F.cross_entropy(model(X + delta), y)
        loss.backward()
        d = torch.clamp(delta + alpha * torch.sign(delta.grad), -epsilon, epsilon)
        d = torch.clamp(X + d, 0, 1) - X
        delta.data = d
        delta.grad.zero_()

    return delta.detach()
