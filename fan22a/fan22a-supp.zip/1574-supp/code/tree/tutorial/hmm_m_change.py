import time
import numpy as np
from cbp import builder
from cbp.graph.coef_policy import bp_policy


for name_type in ['bp', 'Sinkhorn']:
    time_iter = 'total'
    if time_iter == 'per_iteration':
        num_inner_iter = 5
    else:
        num_inner_iter = 3 if name_type == 'Sinkhorn' else 5
        # num_inner_iter = 5
    num_outer_iter = 5
    max_ite = 1 if time_iter == 'per_iteration' else 500000
    run_time_list = np.zeros([num_inner_iter, num_outer_iter])

    m_start = 2
    m_step = 1
    n_value = 10

    for repeat in range(num_outer_iter + 1):
        for idx in range(num_inner_iter):
            graph = builder.HMMBuilder(
                length=m_start + m_step * idx, node_dim=n_value, policy=bp_policy, rand_seed=repeat)()
            # graph.plot(f"draw/hmm.png")
            graph.bake()
            start = time.time()
            if name_type == 'Sinkhorn':
                eps, steps, timers = graph.sinkhorn(
                    max_iter=max_ite,
                    tolerance=graph.cfg.itsbp_outer_tolerance / (8))
            else:
                eps, steps, timers = graph.itsbp(max_iter=max_ite)
            total_cost = 0
            for _, f_node in graph.factornode_recorder.items():
                factor_marginal = f_node.marginal(
                )
                C_B = factor_marginal * (-
                                         np.log(f_node.potential) / graph.inv_eta)
                total_cost += C_B.sum()

            end = time.time()
            if time_iter == 'per_iteration':
                run_time = timers / (m_start + m_step * idx)
            else:
                run_time = end - start

            if repeat > 0:
                run_time_list[idx, repeat - 1] = run_time
            print("steps:", steps, "time:", run_time)
            print("steps:", steps, "cost:", total_cost)
            # print(eps)

    np.save(
        f'draw/HMM_{name_type}_n_{n_value}_m_{m_start}_{m_step}_change.npy', run_time_list)
    result = np.load(
        f'draw/HMM_{name_type}_n_{n_value}_m_{m_start}_{m_step}_change.npy')
    print(result.mean(axis=1), result.std(axis=1))
