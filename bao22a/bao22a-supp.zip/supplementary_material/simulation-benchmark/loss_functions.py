import torch
import torch.nn.functional as F


def logistic(z, t):
    return torch.mean(-F.logsigmoid(z * t))


def zero_one(z, t):
    return torch.mean((t != 2 * (z > 0).int() - 1).float())
