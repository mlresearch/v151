import numpy as np
import gpflow
from gpflow import Parameter
from gpflow import covariances as cov
import tensorflow as tf
import tensorflow_probability as tfp

from inducing_points import GraphInducingPoints


class DeepEdgeGraphConvolutional(gpflow.kernels.base.Kernel):

    def __init__(self, base_kernel, sparse, num_convs):
        super().__init__([1])
        self.base_kernel = base_kernel
        self.sparse = sparse
        self.num_convs = num_convs
        self.weights = [Parameter(np.array([(1.0/(i+2.0))]),
                                  transform=tfp.bijectors.Sigmoid(),
                                  name=f"weight_{i+1}")
                        for i in range(num_convs)]

        # Setup for sparse vs dense operations
        if sparse:
            self.matmul_f = tf.sparse.sparse_dense_matmul
            self.eye_f = tf.sparse.eye
            self.add_f = tf.sparse.add
        else:
            self.matmul_f = tf.matmul
            self.eye_f = tf.eye
            self.add_f = tf.add

        self.conv_mat = None
        self.target_edges = None

    def set_subgraph(self, conv_matrix, target_edges):
        self.conv_mat = conv_matrix
        self.target_edges = target_edges
        if self.sparse is False and isinstance(conv_matrix, tf.sparse.SparseTensor):
            self.conv_mat = tf.sparse.to_dense(tf.sparse.reorder(conv_matrix))

    def K(self, X, Y=None, presliced=False):
        """
        X are node features of the current subgraph of shape (N, D).
        :return: Covariance matrix of shape (N, N).
        """
        assert Y is None, "Unexpected argument Y"
        num_nodes = self.conv_mat.shape[0]
        num_edges = self.target_edges.shape[0]
        num_samples = X.shape[0] // num_nodes
        edges = tf.cast(self.target_edges, tf.dtypes.int32)

        cov = self.base_kernel.K(X)                                                 # Shape (S*N, S*N)
        cov = tf.reshape(cov, [num_samples, num_nodes, num_samples, num_nodes])     # Shape (S, N, S, N)
        cov = tf.transpose(cov, [0, 2, 1, 3])                                       # Shape (S, S, N, N)
        for i in range(self.num_convs):
            conv_mat = self.add_f(self.weights[i] * self.conv_mat,
                                  (1.0 - self.weights[i]) * self.eye_f(self.conv_mat.shape[0], dtype=cov.dtype))
            cov = self.matmul_f(conv_mat, cov)
            cov = self.matmul_f(conv_mat, cov, adjoint_b=True)
        cov = tf.transpose(cov, [0, 2, 1, 3])                                       # Shape (S, N, S, N)

        cov_iip = tf.gather(tf.gather(cov, edges[:, 0], axis=1), edges[:, 0], axis=3)
        cov_jjp = tf.gather(tf.gather(cov, edges[:, 1], axis=1), edges[:, 1], axis=3)
        cov_ijp = tf.gather(tf.gather(cov, edges[:, 0], axis=1), edges[:, 1], axis=3)
        cov_jip = tf.gather(tf.gather(cov, edges[:, 1], axis=1), edges[:, 0], axis=3)
        cov_edges = cov_iip * cov_jjp + cov_ijp * cov_jip                           # Shape (S, E, S, E)

        cov_edges = tf.reshape(cov_edges, [num_samples*num_edges, num_samples*num_edges])       # Shape (S*E, S*E)
        return cov_edges

    def K_diag(self, X, presliced=False):
        return tf.linalg.diag_part(self.K(X))


@cov.Kuu.register(GraphInducingPoints, DeepEdgeGraphConvolutional)
def Kuu_graph_polynomial(inducing_variable, kernel, jitter=None):
    """
    Computes the covariance matrix between the inducing points (which are not
    associated with any node).
    :param inducing_variable: Set of inducing points of type
    NodeInducingPoints.
    :param kernel: Kernel of type GraphPolynomial.
    :return: Covariance matrix between the inducing variables.
    """
    Z = inducing_variable.Z
    ind_edges = tf.cast(inducing_variable.edge_indices, tf.dtypes.int32)

    cov = kernel.base_kernel.K(Z)                                                   # Shape (M, M)
    cov_iip = tf.gather(tf.gather(cov, ind_edges[:, 0], axis=0), ind_edges[:, 0], axis=1)
    cov_jjp = tf.gather(tf.gather(cov, ind_edges[:, 1], axis=0), ind_edges[:, 1], axis=1)
    cov_ijp = tf.gather(tf.gather(cov, ind_edges[:, 0], axis=0), ind_edges[:, 1], axis=1)
    cov_jip = tf.gather(tf.gather(cov, ind_edges[:, 1], axis=0), ind_edges[:, 0], axis=1)
    cov_edges = cov_iip * cov_jjp + cov_ijp * cov_jip                               # Shape (F, F)

    if jitter is not None:
        cov_edges = cov_edges + jitter * tf.eye(cov_edges.shape[0], dtype=cov_edges.dtype)
    return cov_edges


@cov.Kuf.register(GraphInducingPoints, DeepEdgeGraphConvolutional, tf.Tensor)
def Kuf_graph_polynomial(inducing_variable, kernel, X):
    """
    Computes the covariance matrix between inducing points (which are not
    associated with any node) and normal inputs.
    :param inducing_variable: Set of inducing points of type
    NodeInducingPoints.
    :param kernel: Kernel of type GraphPolynomial.
    :param X: Normal inputs. Note, however, that to simplify the
    implementation, we pass in the indices of the nodes rather than their
    features directly.
    :return: Covariance matrix between inducing variables and inputs.
    """
    edges = tf.cast(kernel.target_edges, tf.dtypes.int32)                           # Shape (E, 2)
    conv_mat = kernel.conv_mat                                                      # Shape (N, N)
    Z = inducing_variable.Z                                                         # Shape (M, D)
    ind_edges = tf.cast(inducing_variable.edge_indices, tf.dtypes.int32)            # Shape (F, 2)

    cov = kernel.base_kernel.K(X, Z)
    cov = tf.reshape(cov, [-1, conv_mat.shape[0],
                           Z.shape[0]])                                             # Shape (S, N, M)
    for i in range(kernel.num_convs):
        conv_mat = kernel.add_f(
            kernel.weights[i] * conv_mat,
            (1.0 - kernel.weights[i]) * kernel.eye_f(conv_mat.shape[0], dtype=cov.dtype))
        cov = kernel.matmul_f(conv_mat, cov)                                        # Shape (S, N, M)

    cov_iip = tf.gather(tf.gather(cov, edges[:, 0], axis=1), ind_edges[:, 0], axis=2)
    cov_jjp = tf.gather(tf.gather(cov, edges[:, 1], axis=1), ind_edges[:, 1], axis=2)
    cov_ijp = tf.gather(tf.gather(cov, edges[:, 0], axis=1), ind_edges[:, 1], axis=2)
    cov_jip = tf.gather(tf.gather(cov, edges[:, 1], axis=1), ind_edges[:, 0], axis=2)
    cov_edges = cov_iip * cov_jjp + cov_ijp * cov_jip                               # Shape (S, E, F)

    cov_edges = tf.reshape(cov_edges, [-1, ind_edges.shape[0]])                             # Shape (S*E, F)
    return tf.transpose(cov_edges)                                                  # Shape (F, S*E)