"""Compute the Inception Score (IS) for CIFAR-10 given a numpy file of GAN samples.

Example
-------
CUDA_VISIBLE_DEVICES=0 python compute_is_from_samples.py \
    --load=/scratch/gobi2/pvicol/complex_momentum/samples_np/BigGAN_C10_seed0_Gch64_Dch64_bs50_nDs4_Glr2.0e-04_Dlr2.0e-04_GB10.000_GB1p16.000_GB20.999_GB2p16.000_DB10.000_DB1p16.000_DB20.999_DB2p16.000_Gnlrelu_Dnlrelu_GinitN02_DinitN02_ema_cg_cd/12000/samples.np
"""
import os
import sys
sys.path.insert(0, 'wgan_stuff/wgan-gp')
import csv
import ipdb
import argparse
import numpy as np

from tflib import inception_score

parser = argparse.ArgumentParser()
parser.add_argument('--load', type=str,
                    help='Path to numpy file containing samples to load')
args = parser.parse_args()

# samples = np.load(args.load)
array = np.load(args.load)
samples = array['x'].transpose(0,2,3,1)

print('Running Inception score...')
score = inception_score.get_inception_score(list(samples))
print('\nInception Score: {}'.format(score))

base_dir = os.path.dirname(args.load)

# Save the Inception Score in a CSV file
with open(os.path.join(base_dir, 'inception_score.csv'), 'w') as result_file:
    result_writer = csv.DictWriter(result_file, fieldnames=['inception_score'])
    result_writer.writeheader()
    result_writer.writerow({ 'inception_score': score[0] })
    result_file.flush()
