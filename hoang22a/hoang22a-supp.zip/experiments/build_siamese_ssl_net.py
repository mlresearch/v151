import sys
import os
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"
from os.path import dirname
sys.path.append(dirname("/home/user/neurips21/"))  # this is to add the project's path to PYTHONPATH so python can tell where to load the relevant parts of the code

import matplotlib.pyplot as plt
import seaborn as sns
#sns.set_theme()

import logging
logging.getLogger('tensorflow').disabled = True

# importing our utils function
from utils.utilities import *
# importing bits for our metric implementations
from utils.metric import *

# importing keras
from tensorflow.keras import backend as KB
import tensorflow as tf

# importing bits for our recommenders
from models.nets.simsnet import *
from models.nets.spenet import *
from models.recommenders.sims import *
from models.recommenders.spe import *
from models.recommenders.simsssl import *

# importing bits for our personalizers
from models.personalizer.kernel import *
from models.personalizer.simsgp import *
from models.personalizer.simspersonalizer import *
from models.personalizer.simssparsegp import *

# importing bits for our data loaders
from loaders.dataloader import *
from loaders.pairloader import *
from loaders.featureloader import *
from loaders.factory import *

# set random seed
seed = 1234
fix_seed(seed)

# set the GPU -- which one to be used for training -- later: figure out how to do multi-GPU training
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

INPUT_PATH = "/home/user/data/movielens/20M"  # base path for data
OUTPUT_PATH = "/home/user/neurips21_cache"  # base path for model + data saves

if not os.path.exists(OUTPUT_PATH):
    os.mkdir(OUTPUT_PATH)

PLOT_PATH = "/home/user/neurips21/plots"

DATA_VERSION = "movielens-data"  # specific name for data loader cache
DATA_CACHE = os.path.sep.join([OUTPUT_PATH, DATA_VERSION])  # path to DATA CACHE -- where to save our data objects

if not os.path.exists(DATA_CACHE):  # check if the folder exists already
    os.makedirs(DATA_CACHE)  # if not, create it

MODEL_VERSION_BASE = "siamese-base-model"
MODEL_VERSION_SSL = "siamese-SSL-model"

MODEL_SSL = os.path.sep.join([OUTPUT_PATH, MODEL_VERSION_SSL])  # path to MODEL CACHE -- where to save our model artifacts
MODEL_BASE = os.path.sep.join([OUTPUT_PATH, MODEL_VERSION_BASE])  # path to MODEL CACHE -- where to save our model artifacts

if not os.path.exists(MODEL_SSL):  # check if the folder exists already
    os.makedirs(MODEL_SSL)  # if not, create it

META_CHANNELS = ['Plot', 'AveRating']
channels = {}
for CHANNEL in META_CHANNELS:
    channels[CHANNEL] = os.path.sep.join([INPUT_PATH, "{}.npz".format(CHANNEL)])

n_pair_per_user, window, timecut, version = 10, 10, 1365957431, 4

print("Loading Data")
DataBuilder : DataFactory = load_object(DATA_CACHE + "/data-pair-per-user-{}-window-{}-timecut-{}.dat".format(n_pair_per_user, window, timecut))
DataBuilder.reset_feature_channel(channels)

print("Loading User Ratings ...")
ratings = np.load(channels['AveRating'])['arr_0']

X, Y, p = [], [], []
total = 0.
for i in range(ratings.shape[0]):
    X.append(ratings[i, 0])
    Y.append(ratings[i, 1])
    p.append(len(DataBuilder.interaction_data_loader.items[X[-1]]) * 1.0)
    total += p[-1]

for i in range(len(p)):
    p[i] /= total

Y_mean = 0.0
for i in range(len(Y)):
    Y_mean += Y[-1]
Y_mean = Y_mean * 1.0 / len(Y)

save_object([X, Y, p], DATA_CACHE + "/SSL-data.dat")

print("Loading Parameters ...")  # this is the user-provided parameters needed to build our metric net
hyper_params = {'max_no_item' : 26801, 'feature_channels_dim' : DataBuilder.featurizer.feature_dims,  # {"Title" : 50, "Poster" : 512}
                'loss' : Losses.ContrastiveLossV1, 'hidden_dim' : 50, 'id_embedding_dim' : 30, 'learning_rate' : 5 * 1e-4}

[X, Y, p] = load_object(DATA_CACHE + "/SSL-data.dat")
n_support = 100
Xs = np.random.choice(X, n_support, p = p, replace = False)

featurizer = DataBuilder.featurizer
epoch, L = 30, 10

md_base = "siamese-version-{}-pair-per-user-{}-window-{}-timecut-{}-epoch-{}-seed-{}".format(version, n_pair_per_user, window, timecut, 50, seed)
md_name = "SSL-siamese-version-{}-pair-per-user-{}-window-{}-timecut-{}-epoch-{}-support-{}".\
    format(version, n_pair_per_user, window, timecut, epoch, n_support)
PLOT_CACHE = os.path.sep.join([PLOT_PATH, md_name])
md_name = md_name + "-seed-{}".format(seed)

if not os.path.exists(PLOT_CACHE):  # check if the folder exists already
    os.makedirs(PLOT_CACHE)  # if not, create it

metrics = {'mrr': mean_reciprocal_rank, 'precision_at_{}'.format(L): precision_at_k, 'ndcg_at_{}'.format(L): ndcg_at_k}

SIMSEngine = SIMSV4(hyper_params, md_base)  # load these parameters and create a metric net
SIMSEngine.load(MODEL_BASE)  # load the model
SIMSEngine.md_name = md_name  # from now on, save it under a different name reflecting the SSL prefix

personalizer = SIMSSparseGP(SIMSCovV2(SIMSEngine, featurizer), SIMSMean(c = 2.5), noise = np.log(1.0))
optimizer = SIMSEngine.network.optimizer

SIMSAdapter = SIMSSSL(personalizer, optimizer)

print("Evaluating Base Model ...")
tests = DataBuilder.unseen_items
message, base = DataBuilder.metric_eval_streamline_unpersonalized(SIMSEngine, metrics, tests,
                                                                  K = L, verbal = False, forward = False)
print(message)

print("Tuning Model with SSL Data [GPU = {} - seed = {}] ...".format(os.environ["CUDA_VISIBLE_DEVICES"], seed))
Ls, Rs = [], []
metric_evals = []
for i in range(epoch):
    print("Epoch {} ...".format(i + 1))
    losses, rmses = SIMSAdapter.fit(X, Y, Xs, max_num_epoch = 100, checkpoint = 50)  # train the metric model via SSL
    Ls, Rs = Ls + losses, Rs + rmses

    message, results = DataBuilder.metric_eval_streamline_unpersonalized(SIMSAdapter.personalizer.cov.simsengine,
                                                                         metrics, tests, K = L, verbal = False, forward = False)
    metric_evals.append(results)
    print(Ls)
    print(Rs)
    print(message)
    md_name_prev = SIMSAdapter.personalizer.cov.simsengine.md_name

    SIMSAdapter.personalizer.cov.simsengine.md_name += "-iter-{}".format(i + 1)  # separately save for each iteration
    SIMSAdapter.personalizer.cov.simsengine.save(MODEL_SSL)
    SIMSAdapter.personalizer.cov.simsengine.md_name = md_name_prev
    SIMSAdapter.personalizer.cov.simsengine.save(MODEL_SSL)

    save_object([Ls, Rs, metric_evals, base], PLOT_CACHE + "/saved-eval-results-seed-{}.dat".format(seed))  # save results so far

print("Check out the saved results at {}.".format(PLOT_CACHE + "/saved-eval-results-seed-{}.dat".format(seed)))
