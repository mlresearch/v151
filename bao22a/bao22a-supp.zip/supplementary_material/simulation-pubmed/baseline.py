import numpy as np
import torch
import torch.nn.functional as F


class SDLoss(torch.nn.BCEWithLogitsLoss):
    def __init__(self, similarity_prior):
        super(SDLoss, self).__init__()
        self.prior_s = similarity_prior
        self.prior_p = (1 + np.sqrt(2 * self.prior_s - 1)) / 2
        self.lossfn = F.binary_cross_entropy_with_logits

    def forward(self, input: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        p_p, p_n = self.prior_p, 1 - self.prior_p
        p_s, p_d = self.prior_s, 1 - self.prior_s
        n_s = len(target[target == 1])
        n_d = len(target[target == 0])
        l_s = p_p * self.lossfn(input, target) \
                - p_n * self.lossfn(input, 1 - target)
        l_s = target * p_s * l_s
        l_d = p_p * self.lossfn(input, target) \
                - p_n * self.lossfn(input, 1 - target)
        l_d = (1 - target) * p_d * l_d
        loss = (l_s.sum() / n_s + l_d.sum() / n_d) / (p_p - p_n)
        return loss


class MetricLearningLoss(torch.nn.Module):
    def forward(self, input: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        loss_g = target * input ** 2
        loss_i = (1 - target) * torch.exp(-2.77 * input)
        return (loss_g + loss_i).mean()
