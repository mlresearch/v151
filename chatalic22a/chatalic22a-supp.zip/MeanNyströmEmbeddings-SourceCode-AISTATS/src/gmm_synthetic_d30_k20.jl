include("gmm_synthetic.jl")

main_gmm_synthetic(30, 20) # d, k
