

library(genlasso)
library(doParallel)
library(foreach)
library(ITALE)
library(mvtnorm)
library(glmnet)
library(glmnetUtils )
library(ensr)


cv.fusedlasso <- function(object, D, k=5) {
  
  y = object$y
  X = object$X
  n = length(y)
  
  if(k<2 || round(k)!=k || k>n-2) {
    stop("The number of folds must an integer between 2 and n-2.")
  }
  
  foldid = c(0,rep(Seq(1,k),n-2)[Seq(1,n-2)],0)
  
  lambda = object$lambda
  cvall = matrix(0,k,length(lambda))
  
  for (i in Seq(1,k)) {
    cat(sprintf("Fold %i ... ",i))
    
    otr = which(foldid!=i)
    ntr = length(otr)
    ytr = y[otr]
    Xtr = X[otr, ]  
    
    out = fusedlasso(ytr, Xtr, D, maxsteps = 400, minlam = 0.01)
    b = coef.genlasso(out, lambda = lambda)$beta  
    
    
    ote = which(foldid==i)
    yte = matrix(y[ote],length(ote),length(lambda))
    Xte = X[ote, ]
    pred = Xte %*% b
    
    cvall[i, ] = colMeans((yte-pred)^2) 
  }
  
  cverr = colMeans(cvall)
  i0 = which.min(cverr)
  lam.min = lambda[i0]
  out.list = list(lambda.min = lam.min, i.min = i0)
  return(out.list)
}

Seq <- function(a, b, ...) {
  if (a<=b) return(seq(a,b,...))
  else return(numeric(0))
}

enumerate.jumps <- function(fit, tol = 1e-4){
  dif = abs(diff(fit))
  idx = which(dif > tol)
  
  idx
}

library(fdm2id)



y_train_or = cookies.y.train[-23, 2]

y_test_or = cookies.y.test[-21, 2]

X_train_or = cookies.desc.train[-23, ]

X_test_or = cookies.desc.test[-21, ]

X = rbind (X_train_or, X_test_or)

y = c(y_train_or, y_test_or)



mse_fl_test =c()
mse_lasso_test = c()
mse_el_test = c()
mse_ITALE_test = c()

mse_fl_train =c()
mse_lasso_train = c()
mse_el_train = c()
mse_ITALE_train = c()

no_change_fl = c()
no_change_lasso = c()
no_change_el = c()
no_change_ITALE = c()

no_nonzero_fl = c()
no_nonzero_lasso = c()
no_nonzero_el = c()
no_nonzero_ITALE = c()



trials = 100

for (x in (1:trials)) {
  
  print(x)  
  
  set.seed(x *101)
  
  index = sort( sample(c(1:70), 39) )
  
  X_train = X[index, ] 
  
  X_test = X[-index, ] 
  
  y_train = y [index ]
  
  y_test =  y [-index]
  
  y_train = scale(y_train)
  
  y_test = scale(y_test)
  
  X_test = scale(X_test)
  
  X_train = scale(X_train)
  
  p = dim(X_train)[2]
  
  n = dim(X_train)[1]
  
  n_test = dim(X_test)[1]
  
  D_1 = getD1d(p)
  
  res_fl = fusedlasso (y_train, X_train, D_1,  maxsteps = 200, minlam = 0.01)
  
  cv_fl = cv.fusedlasso(res_fl, D_1)
  
  fit_fl = coef(res_fl, lambda = cv_fl$lambda.min)$beta
  
  no_nonzero_fl_new =  length(which(abs(fit_fl)  > 1e-4))
  
  no_nonzero_fl = c(no_nonzero_fl, no_nonzero_fl_new)
  
  no_change_fl_new = length(enumerate.jumps(fit_fl))
  
  no_change_fl = c(no_change_fl, no_change_fl_new)
  
  mse_fl_test_new = sum((y_test - X_test %*% fit_fl)^2)/n_test
  
  mse_fl_test = c(mse_fl_test, mse_fl_test_new)
  
  
  mse_fl_train_new = sum((y_train - X_train %*% fit_fl)^2)/n
  
  mse_fl_train = c(mse_fl_train, mse_fl_train_new)
  
  
  
  
  res_lasso = cv.glmnet(X_train, y_train, type.measure="mse", alpha=1,  family="gaussian", nfolds = 5, intercept = F)
  
  fit_lasso = coef(res_lasso, s = "lambda.min")[-1]
  
  predict_lasso = predict(res_lasso, newx = X_test, s = "lambda.min")
  
  no_nonzero_lasso_new =  length(which(abs(fit_lasso)  > 1e-4))
  
  no_nonzero_lasso = c(no_nonzero_lasso, no_nonzero_lasso_new)
  
  no_change_lasso_new = length(enumerate.jumps(fit_lasso))
  
  no_change_lasso = c(no_change_lasso, no_change_lasso_new)
  
  mse_lasso_test_new = sum((y_test -predict_lasso )^2)/n_test
  
  mse_lasso_test = c(mse_lasso_test, mse_lasso_test_new )
  
  
  mse_lasso_train_new = sum((y_train - X_train %*% fit_lasso)^2)/n
  
  mse_lasso_train = c(mse_lasso_train, mse_lasso_train_new)
  
  
  
  res_el_1 = ensr( X_train, y_train, alpha = seq(0, 1, len = 11),  nfolds = 5, standardize = F,  intercept = F)
  
  res_el_summary = summary(object = res_el_1)
  
  tunning_parameter = res_el_summary[cvm == min(cvm)]
  
  res_el = glmnet( X_train, y_train, lambda = tunning_parameter$lambda[1], intercept = F, alpha=tunning_parameter$alpha[1]) 
  
  fit_el  = coef(res_el)[-1]
  
  predict_el = predict(res_el, newx = X_test)
  
  no_nonzero_el_new =  length(which(abs(fit_el)  > 1e-4))
  
  no_nonzero_el = c(no_nonzero_el, no_nonzero_el_new)
  
  no_change_el_new = length(enumerate.jumps(fit_el))
  
  no_change_el = c(no_change_el, no_change_el_new)
  
  mse_el_test_new = sum((y_test -predict_el )^2)/n_test
  
  mse_el_test = c(mse_el_test, mse_el_test_new )
  
  mse_el_train_new = sum((y_train - X_train %*% fit_el)^2)/n
  
  mse_el_train = c(mse_el_train, mse_el_train_new)
  

  
  
}


mean(mse_fl_test)

mean(mse_lasso_test)
 
mean(mse_el_test)



sd(mse_fl_test)

sd(mse_lasso_test)

sd(mse_el_test)



mean(mse_fl_train)

mean(mse_lasso_train)

mean(mse_el_train)



sd(mse_fl_train)

sd(mse_lasso_train)

sd(mse_el_train)


mean(no_change_fl)

mean(no_change_lasso)

mean(no_change_el)



sd(no_change_fl)

sd(no_change_lasso)

sd(no_change_el)



mean(no_nonzero_fl)

mean(no_nonzero_lasso)

mean(no_nonzero_el)



sd(no_nonzero_fl)

sd(no_nonzero_lasso)

sd(no_nonzero_el)



