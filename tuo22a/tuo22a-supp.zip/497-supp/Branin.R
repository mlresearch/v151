library(RandomFields)
#library(deldir) 
library(randtoolbox)
library(GPfit)
library(geoR)
library(lhs)
library(flexclust)
library(mlegp)
library(mvtnorm)

set.seed(20)
mynu = 4

n1 = 101
myPreX <- seq(0, 1, length.out = n1)
myPreY <- seq(0, 1, length.out = n1) # prediction points
myd <- expand.grid(x = myPreX, y = myPreY) # gridpoints
d1 <- myd
d1[,1] <- myd[,2]
d1[,2] <- myd[,1]

sigma2 = 1

pointeval = function(x,X){
  for(i in 1:dim(X)[1]){
    if(x[1] == X[i,1] & x[2] == X[i,2]){
      return(i)
    }
  }
}

findY = function(y,Y){
  for(i in 1:length(Y)){
    if(Y[i] == y){
      return(i)
    }
  }
}

# mytest <- function(xx)
#   {
#     x1 <- xx[1]
#     x2 <- xx[2]
# 
#     x1bar <- 15*x1 - 5
#     x2bar <- 15 * x2
# 
#     term1 <- x2bar - 5.1*x1bar^2/(4*pi^2) + 5*x1bar/pi - 6
#     term2 <- (10 - 10/(8*pi)) * cos(x1bar)
# 
#     y <- (term1^2 + term2 - 44.81)/20
#     return(y)
# }
mytest <- function(xx){
  a=1
  b=5.1/(4*pi^2)
  c=5/pi
  r=6
  s=10
  t=1/(8*pi)
  x1 <- 15*xx[1]-5
  x2 <- 15*xx[2]

  term1 <- -a * (x2 - b*x1^2 + c*x1 - r)^2
  term2 <- -s*(1-t)*cos(x1)

  y <- (term1 + term2)/40
  return(y)
}

desnum = 30
itmax = 30
itnum = seq(5, itmax, by = 5)
itnumlen = length(itnum)

myX = optimumLHS(n=desnum, k=2) # ini design
myXX = round(myX/(1/(n1-1)))*(1/(n1-1)) # LHS on grids

n2 <- n1^2
# 
# GPdraw <- 1:n2
# 
# for(k in 1:n2){
#   GPdraw[k] = mytest(d1[k,])
# }
# 
# GPdraw=as.numeric(GPdraw)

# gpva <- matrix(data = 1,nrow = 100, ncol = n1^2)
nipos <- matrix(data = 1,nrow = 100, ncol = desnum + itmax)
mycover <- seq(0.2,1.5,by = 0.1)
myclen <- length(mycover)
mycoverrate95 <- matrix(data = 0,nrow = myclen, ncol = itnumlen)
mycoverrate50 <- matrix(data = 0,nrow = myclen, ncol = itnumlen)
trocoverrate95 <- matrix(data = 0,nrow = itnumlen, ncol = 1)
trocoverrate50 <- matrix(data = 0,nrow = itnumlen, ncol = 1)

Ciwidth5 <- matrix(data = 0,nrow = myclen, ncol = 100)
Ciupper5 <- matrix(data = 0,nrow = myclen, ncol = 100)

Ciwidth10 <- matrix(data = 0,nrow = myclen, ncol = 100)
Ciupper10 <- matrix(data = 0,nrow = myclen, ncol = 100)

Ciwidth15 <- matrix(data = 0,nrow = myclen, ncol = 100)
Ciupper15 <- matrix(data = 0,nrow = myclen, ncol = 100)

Ciwidth20 <- matrix(data = 0,nrow = myclen, ncol = 100)
Ciupper20 <- matrix(data = 0,nrow = myclen, ncol = 100)

Ciwidth25 <- matrix(data = 0,nrow = myclen, ncol = 100)
Ciupper25 <- matrix(data = 0,nrow = myclen, ncol = 100)

Ciwidth30 <- matrix(data = 0,nrow = myclen, ncol = 100)
Ciupper30 <- matrix(data = 0,nrow = myclen, ncol = 100)

Ciwidthtr <- matrix(data = 0,nrow = itnumlen, ncol = 100)
Ciuppertr <- matrix(data = 0,nrow = itnumlen, ncol = 100)

Ciwidthtr50 <- matrix(data = 0,nrow = itnumlen, ncol = 100)

Ci50width5 <- matrix(data = 0,nrow = myclen, ncol = 100)
Ci50upper5 <- matrix(data = 0,nrow = myclen, ncol = 100)

Ci50width10 <- matrix(data = 0,nrow = myclen, ncol = 100)
Ci50upper10 <- matrix(data = 0,nrow = myclen, ncol = 100)

Ci50width15 <- matrix(data = 0,nrow = myclen, ncol = 100)
Ci50upper15 <- matrix(data = 0,nrow = myclen, ncol = 100)

Ci50width20 <- matrix(data = 0,nrow = myclen, ncol = 100)
Ci50upper20 <- matrix(data = 0,nrow = myclen, ncol = 100)

Ci50width25 <- matrix(data = 0,nrow = myclen, ncol = 100)
Ci50upper25 <- matrix(data = 0,nrow = myclen, ncol = 100)

Ci50width30 <- matrix(data = 0,nrow = myclen, ncol = 100)
Ci50upper30 <- matrix(data = 0,nrow = myclen, ncol = 100)

numtemp <- 0
n1 = n1^2

EIdata <- matrix(data = 1,nrow = 100,ncol = 1) 


# myphi = 1/(2*sqrt(mynu))
# mynu <- c(1.5,2.5,3.5)
A0D <- 25

A0Dcan <- seq(0.001, 5, length.out = 50)
myDistXX=as.matrix(dist(myXX,diag=TRUE,upper=TRUE))

mymle = function(y){
  y1 = -100000000
  tt = 1
  for(i in 1:100){
    A0 = A0Dcan[i]
    D = sqrt(2)
    scnu = ((2*4*sqrt(mynu)*gamma(mynu + 1/2)*D/(sqrt(pi) * (2*mynu - 1)*gamma(mynu)))/A0)
    myphi1 = scnu/(sqrt(mynu))
    K <- matern(u = myDistXX, phi = myphi1, kappa = mynu)
    myt = solve(K + 1e-11* diag(desnum),as.matrix(GPdraw[inipos]),tol = 0)
    myt2 = GPdraw[inipos]
    sigma22 = 0
    for(j in 1:desnum){
      sigma22 = sigma22 + myt2[[j]] * myt[j]/desnum
    }
    for(j in 1:desnum){
      for(k in 1:desnum){
        K[j,k] <- sigma22^2 *K[j,k]
      }
    }
    y2 <- dmvnorm(y, mean = 0*y, sigma = K, log =TRUE)
    # print(y2)
    if(y2>y1){
      tt = i
      y1 = y2
    }
  }
  return(tt)
}

myscalenu = function(nu,p){
  D = sqrt(p)
  return((p*4*sqrt(nu)*gamma(nu + 1/2)*D/(sqrt(pi) * (2*nu - 1)*gamma(nu)))/A0D)
}

gpdrawsimu = function(n,A){
  bdr = as.matrix(rnorm(n))
  return(A %*% bdr)
}

inipos <- 1:desnum
for(k in 1:desnum){
  inipos[k] <- pointeval(myXX[k,],d1)
}

myY<-1:desnum

for(k in 1:desnum){
  myY[k] <- mytest(d1[k,])
}

myY=as.numeric(myY)

A0D=A0Dcan[mymle(myY)]
Mtheta <- myscalenu(mynu,2)
myphi = Mtheta/(2*sqrt(mynu))

myDist=as.matrix(dist(myPreX,diag=TRUE,upper=TRUE))
PhiEval1 <- matern(u = myDist, phi = myphi, kappa = mynu)
A1 <- t(cholx(PhiEval1))
PhiEval <- kronecker(PhiEval1,PhiEval1)

myt = solve(PhiEval[inipos,inipos] + 1e-11* diag(desnum),as.matrix(GPdraw[inipos]),tol = 0)
myt2 = GPdraw[inipos]
sigma2 = 0
for(j in 1:desnum){
  sigma2 = sigma2 + myt2[j] * myt[j]/desnum
}

sigma2 = sqrt(sigma2)

# sigma2 = 1
# myDistx=as.matrix(dist(matrix(as.matrix(d1[,1]),ncol = 1),diag=TRUE,upper=TRUE))
# myDisty=as.matrix(dist(matrix(as.matrix(d1[,2]),ncol = 1),diag=TRUE,upper=TRUE))
# PhiEval22 <- matern(u = myDistx, phi = myphi, kappa = mynu) *
#   matern(u = myDisty, phi = myphi, kappa = mynu)


# GPdraw = sigma2 * gpdrawsimu(n1,kronecker(A1,A1))
# GPdraw = rmvnorm(n=1,sigma = PhiEval)
# gpva[i,] <- GPdraw
# GPdraw <- gpva[i,]
mypoints <- myXX
myY <- 1:desnum

for(k in 1:desnum){
  myY[k] <- GPdraw[inipos[k]]
}
posnow <- inipos
## start EI

i=1

for(j in 1:itmax){
  print(c(i,j))
  # calculate kernel matrix
  # myDistx1=as.matrix(dist(matrix(as.matrix(mypoints[,1]),ncol = 1),diag=TRUE,upper=TRUE))
  # myDisty1=as.matrix(dist(matrix(as.matrix(mypoints[,2]),ncol = 1),diag=TRUE,upper=TRUE))
  # PhiEval1 <- matern(u = myDistx1, phi = 1/(2*sqrt(mynu)), kappa = mynu) *
  #   matern(u = myDisty1, phi = 1/(2*sqrt(mynu)), kappa = mynu)
  ## start prediction
  fHat <- as.matrix(PhiEval[,posnow])%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum-1+j),myY,tol = 0)
  curmaxf <- max(fHat)
  sigmax <- matrix(1:n1,ncol = 1)
  for(xnum in 1:n1){
    sigmax[xnum] <- sigma2 * sqrt(1 - PhiEval[xnum,posnow]%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum-1+j),PhiEval[posnow,xnum],tol = 0))
  }
  ## calculate GPUCB
  fei <- 1:n1
  for(p in 1:n1){
    myttt <- sqrt(log(16/0.05))
    temp <- sqrt(2 * log(j^2*2*pi^2/(3*0.05)) + 4*log(j^2*2*myttt))
    fei[p] <- fHat[p] + sigmax[p]*temp
  }
  curmpos <- which.max(fei)
  mypoints <- rbind(mypoints,as.matrix(d1[curmpos,],nrow =1))
  myY <- c(myY,GPdraw[curmpos])
  posnow <- c(posnow,curmpos)
  ## save data j=5
  if(j == 5){
    ## last calculation
    fHat <- as.matrix(PhiEval[,posnow])%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),myY,tol = 0)
    curmaxf <- max(fHat)
    sigmax <- matrix(1:n1,ncol = 1)
    for(xnum in 1:n1){
      sigmax[xnum] <- sigma2 * sqrt(1 - PhiEval[xnum,posnow]%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),PhiEval[posnow,xnum],tol = 0))
    }
    
    ## cover?
    gpmaxpos <- which.max(GPdraw)
    temp4 <- max(fHat + sigmax* 1.64)
    Ciwidthtr[1,i] <- temp4 - max(myY)
    Ciuppertr[1,i] <- temp4
    Ciwidthtr50[1,i] <- max(fHat) - max(myY)
    if(GPdraw[gpmaxpos] < temp4){
      trocoverrate95[1] <- trocoverrate95[1] + 1
    }
    temp5 <- max(fHat)
    if(GPdraw[gpmaxpos] < temp5){
      trocoverrate50[1] <- trocoverrate50[1] + 1
    }
    for(k in 1:myclen){
      temp1 <- max(fHat + sigmax * sqrt(log(exp(1)/(min(1,sigmax)))) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.5)*2)))
      temp2 <- max(fHat + sigmax * sqrt(log(exp(1)/(min(1,sigmax)))) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.05)*2)))
      Ciwidth5[k,i] <- temp2 - max(myY)
      Ciupper5[k,i] <- temp2
      Ci50width5[k,i] <- temp1 - max(myY)
      Ci50upper5[k,i] <- temp1
      if(GPdraw[gpmaxpos] < temp1){
        mycoverrate50[k,1] <- mycoverrate50[k,1] + 1
      }
      if(GPdraw[gpmaxpos] < temp2){
        mycoverrate95[k,1] <- mycoverrate95[k,1] + 1
      }
      # print(temp1 - max(fHat))
      # print(temp4 - max(fHat))
      # print(temp1-temp4)
    }
    
  }
  ## save data j=10
  if(j == 10){
    ## last calculation
    fHat <- as.matrix(PhiEval[,posnow])%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),myY,tol = 0)
    curmaxf <- max(fHat)
    sigmax <- matrix(1:n1,ncol = 1)
    for(xnum in 1:n1){
      sigmax[xnum] <- sigma2 * sqrt(1 - PhiEval[xnum,posnow]%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),PhiEval[posnow,xnum],tol = 0))
    }
    
    ## cover?
    gpmaxpos <- which.max(GPdraw)
    temp4 <- max(fHat + sigmax* 1.64)
    Ciwidthtr[2,i] <- temp4 - max(myY)
    Ciuppertr[2,i] <- temp4
    Ciwidthtr50[2,i] <- max(fHat) - max(myY)
    if(GPdraw[gpmaxpos] < temp4){
      trocoverrate95[2] <- trocoverrate95[2] + 1
    }
    temp5 <- max(fHat)
    if(GPdraw[gpmaxpos] < temp5){
      trocoverrate50[2] <- trocoverrate50[2] + 1
    }
    for(k in 1:myclen){
      temp1 <- max(fHat + sigmax * sqrt(log(exp(1)/(min(1,sigmax)))) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.5)*2)))
      temp2 <- max(fHat + sigmax * sqrt(log(exp(1)/(min(1,sigmax)))) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.05)*2)))
      Ciwidth10[k,i] <- temp2 - max(myY)
      Ciupper10[k,i] <- temp2
      Ci50width10[k,i] <- temp1 - max(myY)
      Ci50upper10[k,i] <- temp1
      if(GPdraw[gpmaxpos] < temp1){
        mycoverrate50[k,2] <- mycoverrate50[k,2] + 1
      }
      if(GPdraw[gpmaxpos] < temp2){
        mycoverrate95[k,2] <- mycoverrate95[k,2] + 1
      }
      # print(temp1 - max(fHat))
      # print(temp4 - max(fHat))
      # print(temp1-temp4)
    }
    
  }
  ## save data j=15
  if(j == 15){
    ## last calculation
    fHat <- as.matrix(PhiEval[,posnow])%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),myY,tol = 0)
    curmaxf <- max(fHat)
    sigmax <- matrix(1:n1,ncol = 1)
    for(xnum in 1:n1){
      sigmax[xnum] <- sigma2 * sqrt(1 - PhiEval[xnum,posnow]%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),PhiEval[posnow,xnum],tol = 0))
    }
    
    ## cover?
    gpmaxpos <- which.max(GPdraw)
    temp4 <- max(fHat + sigmax* 1.64)
    Ciwidthtr[3,i] <- temp4 - max(myY)
    Ciuppertr[3,i] <- temp4
    Ciwidthtr50[3,i] <- max(fHat) - max(myY)
    if(GPdraw[gpmaxpos] < temp4){
      trocoverrate95[3] <- trocoverrate95[3] + 1
    }
    temp5 <- max(fHat)
    if(GPdraw[gpmaxpos] < temp5){
      trocoverrate50[3] <- trocoverrate50[3] + 1
    }
    for(k in 1:myclen){
      temp1 <- max(fHat + sigmax * sqrt(log(exp(1)/(min(1,sigmax)))) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.5)*2)))
      temp2 <- max(fHat + sigmax * sqrt(log(exp(1)/(min(1,sigmax)))) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.05)*2)))
      Ciwidth15[k,i] <- temp2 - max(myY)
      Ciupper15[k,i] <- temp2
      Ci50width15[k,i] <- temp1 - max(myY)
      Ci50upper15[k,i] <- temp1
      if(GPdraw[gpmaxpos] < temp1){
        mycoverrate50[k,3] <- mycoverrate50[k,3] + 1
      }
      if(GPdraw[gpmaxpos] < temp2){
        mycoverrate95[k,3] <- mycoverrate95[k,3] + 1
      }
      # print(temp1 - max(fHat))
      # print(temp4 - max(fHat))
      # print(temp1-temp4)
    }
    
  }
  ## save data j=20
  if(j == 20){
    ## last calculation
    fHat <- as.matrix(PhiEval[,posnow])%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),myY,tol = 0)
    curmaxf <- max(fHat)
    sigmax <- matrix(1:n1,ncol = 1)
    for(xnum in 1:n1){
      sigmax[xnum] <- sigma2 * sqrt(1 - PhiEval[xnum,posnow]%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),PhiEval[posnow,xnum],tol = 0))
    }
    
    ## cover?
    gpmaxpos <- which.max(GPdraw)
    temp4 <- max(fHat + sigmax* 1.64)
    Ciwidthtr[4,i] <- temp4 - max(myY)
    Ciuppertr[4,i] <- temp4
    Ciwidthtr50[4,i] <- max(fHat) - max(myY)
    if(GPdraw[gpmaxpos] < temp4){
      trocoverrate95[4] <- trocoverrate95[4] + 1
    }
    temp5 <- max(fHat)
    if(GPdraw[gpmaxpos] < temp5){
      trocoverrate50[4] <- trocoverrate50[4] + 1
    }
    for(k in 1:myclen){
      temp1 <- max(fHat + sigmax * sqrt(log(exp(1)/(min(1,sigmax)))) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.5)*2)))
      temp2 <- max(fHat + sigmax * sqrt(log(exp(1)/(min(1,sigmax)))) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.05)*2)))
      Ciwidth20[k,i] <- temp2 - max(myY)
      Ciupper20[k,i] <- temp2
      Ci50width20[k,i] <- temp1 - max(myY)
      Ci50upper20[k,i] <- temp1
      if(GPdraw[gpmaxpos] < temp1){
        mycoverrate50[k,4] <- mycoverrate50[k,4] + 1
      }
      if(GPdraw[gpmaxpos] < temp2){
        mycoverrate95[k,4] <- mycoverrate95[k,4] + 1
      }
      # print(temp1 - max(fHat))
      # print(temp4 - max(fHat))
      # print(temp1-temp4)
    }
    
  }
  ## save data j=25
  if(j == 25){
    ## last calculation
    fHat <- as.matrix(PhiEval[,posnow])%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),myY,tol = 0)
    curmaxf <- max(fHat)
    sigmax <- matrix(1:n1,ncol = 1)
    for(xnum in 1:n1){
      sigmax[xnum] <- sigma2 * sqrt(1 - PhiEval[xnum,posnow]%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),PhiEval[posnow,xnum],tol = 0))
    }
    
    ## cover?
    gpmaxpos <- which.max(GPdraw)
    temp4 <- max(fHat + sigmax* 1.64)
    Ciwidthtr[5,i] <- temp4 - max(myY)
    Ciuppertr[5,i] <- temp4
    Ciwidthtr50[5,i] <- max(fHat) - max(myY)
    if(GPdraw[gpmaxpos] < temp4){
      trocoverrate95[5] <- trocoverrate95[5] + 1
    }
    temp5 <- max(fHat)
    if(GPdraw[gpmaxpos] < temp5){
      trocoverrate50[5] <- trocoverrate50[5] + 1
    }
    for(k in 1:myclen){
      temp1 <- max(fHat + sigmax * sqrt(log(exp(1)/(min(1,sigmax)))) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.5)*2)))
      temp2 <- max(fHat + sigmax * sqrt(log(exp(1)/(min(1,sigmax)))) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.05)*2)))
      Ciwidth25[k,i] <- temp2 - max(myY)
      Ciupper25[k,i] <- temp2
      Ci50width25[k,i] <- temp1 - max(myY)
      Ci50upper25[k,i] <- temp1
      if(GPdraw[gpmaxpos] < temp1){
        mycoverrate50[k,5] <- mycoverrate50[k,5] + 1
      }
      if(GPdraw[gpmaxpos] < temp2){
        mycoverrate95[k,5] <- mycoverrate95[k,5] + 1
      }
      # print(temp1 - max(fHat))
      # print(temp4 - max(fHat))
      # print(temp1-temp4)
    }
    
  }
  ## save data j=30
  if(j == 30){
    ## last calculation
    fHat <- as.matrix(PhiEval[,posnow])%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),myY,tol = 0)
    curmaxf <- max(fHat)
    sigmax <- matrix(1:n1,ncol = 1)
    for(xnum in 1:n1){
      sigmax[xnum] <- sigma2 * sqrt(1 - PhiEval[xnum,posnow]%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),PhiEval[posnow,xnum],tol = 0))
    }
    
    ## cover?
    gpmaxpos <- which.max(GPdraw)
    temp4 <- max(fHat + sigmax* 1.64)
    Ciwidthtr[6,i] <- temp4 - max(myY)
    Ciuppertr[6,i] <- temp4
    Ciwidthtr50[6,i] <- max(fHat) - max(myY)
    if(GPdraw[gpmaxpos] < temp4){
      trocoverrate95[6] <- trocoverrate95[6] + 1
    }
    temp5 <- max(fHat)
    if(GPdraw[gpmaxpos] < temp5){
      trocoverrate50[6] <- trocoverrate50[6] + 1
    }
    for(k in 1:myclen){
      temp1 <- max(fHat + sigmax * sqrt(log(exp(1)/(min(1,sigmax)))) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.5)*2)))
      temp2 <- max(fHat + sigmax * sqrt(log(exp(1)/(min(1,sigmax)))) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.05)*2)))
      Ciwidth30[k,i] <- temp2 - max(myY)
      Ciupper30[k,i] <- temp2
      Ci50width30[k,i] <- temp1 - max(myY)
      Ci50upper30[k,i] <- temp1
      if(GPdraw[gpmaxpos] < temp1){
        mycoverrate50[k,6] <- mycoverrate50[k,6] + 1
      }
      if(GPdraw[gpmaxpos] < temp2){
        mycoverrate95[k,6] <- mycoverrate95[k,6] + 1
      }
      # print(temp1 - max(fHat))
      # print(temp4 - max(fHat))
      # print(temp1-temp4)
    }
    
  }
  
  
}

print(mycoverrate95)
print(trocoverrate95)
print(GPdraw[posnow])
print(max(GPdraw[posnow]))
print(GPdraw[gpmaxpos])

