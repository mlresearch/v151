import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler

'''
Actually no train/test needed here
'''
def load_credit(path="taiwan_credit.csv", standardize=True):
    credit = pd.read_csv(path)
    
    mutable_feats = ['EducationLevel', 'MaxBillAmountOverLast6Months', 'MaxPaymentAmountOverLast6Months',
       'MonthsWithZeroBalanceOverLast6Months',
       'MonthsWithLowSpendingOverLast6Months',
       'MonthsWithHighSpendingOverLast6Months', 'MostRecentBillAmount',
       'MostRecentPaymentAmount', 'TotalOverdueCounts', 'TotalMonthsOverdue',
       'HistoryOfOverduePayments']
    
    X = credit[mutable_feats].to_numpy()
    X_std = X
    if standardize:
        scaler = StandardScaler()
        X_std = scaler.fit_transform(X)
    
    y = credit["NoDefaultNextMonth"].to_numpy().astype("int")
    return X_std, y