import re
import sys
from functools import reduce

import numpy as np
import scipy.io
import sklearn.datasets
import sklearn.preprocessing
from sklearn.model_selection import train_test_split
from torchvision.datasets import KMNIST, MNIST, FashionMNIST


def log(*s):
    print(*s, file=sys.stderr)


def adult(nsd, ntest, seed, supervised=False):
    # https://www.csie.ntu.edu.tw/~cjlin/libsvmtools/datasets/binary.html#a9a
    # n=32561, d=123, np=7841
    return _load_svmlight(
        1,
        -1,
        nsd,
        ntest,
        filename="datasets/a9a",
        seed=seed,
        supervised=supervised,
    )


def banana(nsd, ntest, seed, supervised=False):
    # Not currently available.
    # Alternative csv-format data can be found at
    # https://github.com/mikeizbicki/datasets/tree/master/csv/ida

    # n=5300, d=2, np=2376
    return _load_svmlight(
        1,
        -1,
        nsd,
        ntest,
        filename="datasets/banana_data.libsvm",
        seed=seed,
        supervised=supervised,
    )


def codrna(nsd, ntest, seed, supervised=False):
    # https://www.csie.ntu.edu.tw/~cjlin/libsvmtools/datasets/binary.html#cod-rna
    # n=59535, d=8, np=19845
    return _load_svmlight(
        1,
        -1,
        nsd,
        ntest,
        filename="datasets/cod-rna",
        seed=seed,
        supervised=supervised,
    )


def ijcnn1(nsd, ntest, seed, supervised=False):
    # https://www.csie.ntu.edu.tw/~cjlin/libsvmtools/datasets/binary.html#ijcnn1
    # n=49990, d=22, np=4853
    return _load_svmlight(
        1,
        -1,
        nsd,
        ntest,
        filename="datasets/ijcnn1",
        seed=seed,
        supervised=supervised,
    )


def magic(nsd, ntest, seed, supervised=False):
    # https://archive.ics.uci.edu/ml/datasets/MAGIC+Gamma+Telescope
    # n=19020, d=10, np=6688
    def conv(x):
        return 1.0 if x == b"g" else 0.0

    data = np.genfromtxt(
        "datasets/magic04.data", delimiter=",", converters={10: conv}
    )
    p_cls = 0
    n_cls = 1
    return _load_uci_data(
        p_cls,
        n_cls,
        nsd,
        ntest,
        filename=None,
        data=data,
        seed=seed,
        supervised=supervised,
    )


def phishing(nsd, ntest, seed, supervised=False):
    # https://www.csie.ntu.edu.tw/~cjlin/libsvmtools/datasets/binary.html#phishing
    # n=11055, d=68, np=4898
    return _load_svmlight(
        0,
        1,
        nsd,
        ntest,
        filename="datasets/phishing",
        seed=seed,
        supervised=supervised,
    )


def phoneme(nsd, ntest, seed, supervised=False):
    # https://www.elen.ucl.ac.be/neural-nets/Research/Projects/ELENA/databases/REAL/phoneme/ # NOQA
    # n=5404, d=5, np=3818
    data = np.genfromtxt("datasets/phoneme.dat")
    return _load_uci_data(
        0,
        1,
        nsd,
        ntest,
        filename=None,
        data=data,
        seed=seed,
        supervised=supervised,
    )


def spambase(nsd, ntest, seed, supervised=False):
    # https://archive.ics.uci.edu/ml/datasets/Spambase
    # n=4601, d=57, np=1813
    p_cls = 1
    n_cls = 0
    return _load_uci_data(
        p_cls,
        n_cls,
        nsd,
        ntest,
        "datasets/spambase.data",
        seed=seed,
        supervised=supervised,
    )


def waveform(nsd, ntest, seed, supervised=False):
    # https://archive.ics.uci.edu/ml/datasets/Waveform+Database+Generator+%28Version+1%29 # NOQA
    # n=5000, d=21, np=1657
    p_cls = 0
    n_cls = None
    return _load_uci_data(
        p_cls,
        n_cls,
        nsd,
        ntest,
        "datasets/waveform.data",
        seed=seed,
        supervised=supervised,
    )


def w8a(nsd, ntest, seed, supervised=False):
    # https://www.csie.ntu.edu.tw/~cjlin/libsvmtools/datasets/binary.html#w8a
    # n=49749, d=300, np=1479
    return _load_svmlight(
        1,
        -1,
        nsd,
        ntest,
        filename="datasets/w8a",
        seed=seed,
        supervised=supervised,
    )


def _load_svmlight(
    p_cls,
    n_cls,
    nsd,
    ntest,
    filename,
    preprocessor=sklearn.preprocessing.scale,
    seed=0,
    supervised=False,
):
    data = sklearn.datasets.load_svmlight_file(filename)
    X = data[0].todense()
    Y = data[1]

    DP_src = X[Y == p_cls]
    if n_cls is None:
        cls = np.unique(Y)
        n_cls = [i for i in cls if i != p_cls]
        mask = reduce(lambda x, y: x + y, [Y == i for i in n_cls])
        DN_src = X[mask]
    else:
        DN_src = X[Y == n_cls]

    X = np.vstack([DP_src, DN_src])
    y = np.hstack([np.ones(len(DP_src)), -np.ones(len(DN_src))]).astype("i")

    return _prepare_dataset(
        X,
        y,
        nsd,
        ntest,
        preprocessor=preprocessor,
        seed=seed,
        supervised=supervised,
    )


def usps(p_cls, n_cls, nsd, ntest, seed=0, supervised=False):
    data = scipy.io.loadmat("datasets/usps_all.mat")["data"].astype(np.float64)
    DP_src = data[:, :, p_cls].T
    if n_cls is None:
        mask = np.ones(data.shape[2], dtype=bool)
        mask[p_cls] = False
        DN_src = data[:, :, mask].reshape(data.shape[0], -1).T
    else:
        DN_src = data[:, :, n_cls].T

    X = np.vstack([DP_src, DN_src])
    y = np.hstack([np.ones(len(DP_src)), -np.ones(len(DN_src))]).astype("i")

    return _prepare_dataset(
        X,
        y,
        nsd,
        ntest,
        preprocessor=sklearn.preprocessing.normalize,
        seed=seed,
        supervised=supervised,
    )


def _load_uci_data(
    p_cls, n_cls, nsd, ntest, filename=None, data=None, seed=0, supervised=False
):
    if filename is not None:
        data = np.genfromtxt(filename, delimiter=",")

    assert data is not None

    K = len(np.unique(data[:, -1]))
    X = data[:, :-1]
    Y = data[:, -1]
    data = np.array([X[Y == y] for y in range(K)])
    DP_src = data[p_cls]
    if n_cls is None:
        mask = np.ones(K, dtype=bool)
        mask[p_cls] = False
        DN_src = np.vstack(data[mask])
    else:
        DN_src = data[n_cls]

    X = np.vstack([DP_src, DN_src])
    y = np.hstack([np.ones(len(DP_src)), -np.ones(len(DN_src))]).astype("i")

    return _prepare_dataset(X, y, nsd, ntest, seed=seed, supervised=supervised)


def _prepare_dataset(
    X,
    y,
    nsd,
    ntest,
    preprocessor=sklearn.preprocessing.scale,
    seed=0,
    supervised=False,
):
    assert len(X) >= nsd * 2 + ntest

    # preprocessing
    if preprocessor is not None:
        X = preprocessor(X)

    X_train, X_val, y_train, y_val = train_test_split(
        X,
        y,
        train_size=nsd * 2,
        test_size=ntest,
        shuffle=True,
        random_state=seed,
    )

    if supervised:
        return X_train, y_train, X_val, y_val
    else:
        X_train_a, X_train_b = X_train[:nsd], X_train[nsd:]
        t_train = y_train[:nsd] * y_train[nsd:]
        return X_train_a, X_train_b, t_train, X_val, y_val


def load_torch(dataset_name, nsd, ntest, seed, supervised=False, prior=None):
    if dataset_name == "mnist":
        # data_transform = Compose([ToTensor(), Normalize((0.1307,), (0.3081,))])
        train = MNIST(download=True, root="./datasets", train=True)
        test = MNIST(download=True, root="./datasets", train=False)
    elif dataset_name == "fashion":
        train = FashionMNIST(download=True, root="./datasets", train=True)
        test = FashionMNIST(download=True, root="./datasets", train=False)
    elif dataset_name == "kmnist":
        train = KMNIST(download=True, root="./datasets", train=True)
        test = KMNIST(download=True, root="./datasets", train=False)
    else:
        raise ValueError(
            "specified dataset `{}` does not exist.".format(dataset_name)
        )

    x_train, y_train, x_test, y_test = (
        train.data.numpy(),
        train.targets.numpy(),
        test.data.numpy(),
        test.targets.numpy(),
    )
    X = np.vstack([x_train, x_test])
    y = np.hstack([y_train, y_test])

    X = X.reshape(len(X), -1)
    y = np.where(y % 2 == 0, +1, -1)

    X = X / 255

    if prior:
        assert 0 < prior < 1
        X_pos = X[y == 1]
        X_neg = X[y == -1]
        n_pos = len(X_pos)
        n_neg = len(X_neg)
        if n_pos / prior > n_neg / (1 - prior):
            n_pos = int(n_neg * prior / (1 - prior))
            X_pos = X_pos[np.random.choice(len(X_pos), n_pos, replace=False)]

        else:
            n_neg = int(n_pos * (1 - prior) / prior)
            X_neg = X_neg[np.random.choice(len(X_neg), n_neg, replace=False)]
        X = np.vstack([X_pos, X_neg])
        y = np.hstack([np.ones(n_pos), -np.ones(n_neg)])

    return _prepare_dataset(
        X, y, nsd, ntest, preprocessor=None, seed=seed, supervised=supervised
    )


def load_dataset(dataset_name, NSD, Ntest, seed, supervised=False, prior=None):
    if dataset_name.startswith("usps"):
        p_cls, n_cls = re.match(r"usps:(\d):(\d)", dataset_name).groups()
        p_cls = int(p_cls)
        n_cls = int(n_cls)
        out = usps(p_cls, n_cls, NSD, Ntest, seed=seed, supervised=supervised)
    elif dataset_name in ["mnist", "fashion", "kmnist"]:
        out = load_torch(
            dataset_name,
            NSD,
            Ntest,
            seed=seed,
            supervised=supervised,
            prior=prior,
        )
    else:
        try:
            dataset_generator = globals()[dataset_name]
        except KeyError:
            raise ValueError(
                "specified dataset `{}` does not exist.".format(dataset_name)
            )
        out = dataset_generator(NSD, Ntest, seed, supervised=supervised)
    return out
