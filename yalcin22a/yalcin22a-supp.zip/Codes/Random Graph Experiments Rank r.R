rm(list = ls())


install.packages("igraph")
library(igraph)

calculate_obj <-function(X, M_big, mask){
  X_big = X %*% t(X)
  diff = (X_big - M_big) * mask
  obj = sum(diff*diff)
  return(obj)
}

calculate_gradient <-function(X, M_big, mask){
  X_big = X %*% t(X)
  grad = ((X_big - M_big) * mask) %*% X
  return(grad)
}

gradient_algorithm_constant <- function(X, M_big, mask, stepsize){
  i = 0
  while (TRUE) {
    X_big = X %*% t(X)
    
    error = sum(abs(calculate_gradient(X, M_big, mask)))
    
    if (error == Inf) {
      flag = matrix(0, nrow = nrow(X), ncol = ncol(X))
      flag[1,1] = -100
      return(flag)
    }
    if (error < 1e-10){break} 
    
    gradient = calculate_gradient(X, M_big, mask)
    
    a = stepsize
    X_n = X - a * gradient
    i = i+1
    obj = calculate_obj(X_n, M_big, mask)
    #print(c(error, obj))
    X = X_n
  }
  return(X)
}


vertex_size = 10
rank = 2
block = vertex_size
probability_edge = 0.90
graph <- erdos.renyi.game(vertex_size, probability_edge, type='gnp',
                          directed = FALSE, loops = FALSE)

adj_matrix = as_adjacency_matrix(graph)
is.connected(graph) # Check if true
largest_ivs(graph)[1]
ivs_vertices = c(1,6) #Check the vertices 

mask = matrix(0, ncol = vertex_size*rank, nrow = vertex_size*rank)
for (i in 1:vertex_size) {
  for (j in 1:vertex_size) {
    if(adj_matrix[i,j]==1){
      mask[(rank*(i-1)+1):(rank*(i-1)+rank),(rank*(j-1)+1):(rank*(j-1)+rank)] =1
    }
    if(i == j){
      mask[(rank*(i-1)+1):(rank*(i-1)+rank),(rank*(j-1)+1):(rank*(j-1)+rank)] =1
      
    }
  }
}

for (i in 1:(length(ivs_vertices)-1)) {
  j = ivs_vertices[i]
  k = ivs_vertices[i+1]
  mask[(rank*(j-1)+1):(rank*(j-1)+rank),(rank*(k-1)+1):(rank*(k-1)+rank)] = 1
  mask[(rank*(k-1)+1):(rank*(k-1)+rank),(rank*(j-1)+1):(rank*(j-1)+rank)] = 1
  for (m in 1:rank) {
    mask[(rank*(j-1)+m),(rank*(k-1)+m)] = 0
    mask[(rank*(k-1)+m),(rank*(j-1)+m)] = 0
  }
}

identity = diag(rank)
zero = matrix(0, ncol= rank, nrow= rank)

M = matrix(0, nrow = vertex_size*rank, ncol = rank)
for (i in 1:length(ivs_vertices)) {
  j = ivs_vertices[i]
  M[(rank*(j-1)+1):(rank*(j-1)+rank),1:rank] = identity
}

c = rank
r = block * rank

epsilon = matrix(rnorm(c*r), ncol = c, nrow= r)
norm_epsilon = sqrt(sum(epsilon*epsilon))
n_epsilon = epsilon/norm_epsilon 
n_epsilon

success_percent = c()
epsilon_length = c()
for (i in 1:100){
  spur = 0 
  counter = 0
  M_new = M + n_epsilon*(i)/200
  M_big = M_new %*% t(M_new)
  while (counter < 100) {
    X = matrix(runif(c*r,-10,10), ncol=c, nrow=r)
    stepsize = 0.001
    while(TRUE){
      sp_X = gradient_algorithm_constant(X, M_big, mask, stepsize)
      if(sp_X[1,1] == -100){
        stepsize = stepsize/10
      }else{
        break
      }
    }
    value = calculate_obj(sp_X, M_big, mask)
    if (value > 1e-10){
      #break
      spur = spur +1
    }
    counter = counter +1
    print(c(spur/counter, counter))
  }
  print(i)  
  success_percent[i] = spur/counter
  epsilon_length[i] = (i)/200
}

n_epsilon1 = n_epsilon
data1 = data.frame(epsilon_length, success_percent)
write.csv(n_epsilon1, file = 'perturbation_random_graph_rank2_S2_cs.csv')
write.csv(data1, file= 'convergence_random_graph_rank2_S2_cs.csv')
write.csv(mask, file = 'observation_pattern_random_graph_rank2_S2_cs.csv')
write.csv(ivs_vertices, file = "independent_set_random_graph_rank2_S2_cs.csv")

vertex_size = 10
rank = 2
block = vertex_size
probability_edge = 0.80
graph <- erdos.renyi.game(vertex_size, probability_edge, type='gnp',
                          directed = FALSE, loops = FALSE)

adj_matrix = as_adjacency_matrix(graph)
is.connected(graph) # Check if true
largest_ivs(graph)[1]
ivs_vertices = c(3,6,10) #Check the vertices 

mask = matrix(0, ncol = vertex_size*rank, nrow = vertex_size*rank)
for (i in 1:vertex_size) {
  for (j in 1:vertex_size) {
    if(adj_matrix[i,j]==1){
      mask[(rank*(i-1)+1):(rank*(i-1)+rank),(rank*(j-1)+1):(rank*(j-1)+rank)] =1
    }
    if(i == j){
      mask[(rank*(i-1)+1):(rank*(i-1)+rank),(rank*(j-1)+1):(rank*(j-1)+rank)] =1
      
    }
  }
}

for (i in 1:(length(ivs_vertices)-1)) {
  j = ivs_vertices[i]
  k = ivs_vertices[i+1]
  mask[(rank*(j-1)+1):(rank*(j-1)+rank),(rank*(k-1)+1):(rank*(k-1)+rank)] = 1
  mask[(rank*(k-1)+1):(rank*(k-1)+rank),(rank*(j-1)+1):(rank*(j-1)+rank)] = 1
  for (m in 1:rank) {
    mask[(rank*(j-1)+m),(rank*(k-1)+m)] = 0
    mask[(rank*(k-1)+m),(rank*(j-1)+m)] = 0
  }
}

identity = diag(rank)
zero = matrix(0, ncol= rank, nrow= rank)

M = matrix(0, nrow = vertex_size*rank, ncol = rank)
for (i in 1:length(ivs_vertices)) {
  j = ivs_vertices[i]
  M[(rank*(j-1)+1):(rank*(j-1)+rank),1:rank] = identity
}

c = rank
r = block * rank

epsilon = matrix(rnorm(c*r), ncol = c, nrow= r)
norm_epsilon = sqrt(sum(epsilon*epsilon))
n_epsilon = epsilon/norm_epsilon 
n_epsilon

success_percent_2 = c()
epsilon_length_2 = c()
for (i in 1:100){
  spur = 0 
  counter = 0
  M_new = M + n_epsilon*(i)/200
  M_big = M_new %*% t(M_new)
  while (counter < 100) {
    X = matrix(runif(c*r,-10,10), ncol=c, nrow=r)
    stepsize = 0.001
    while(TRUE){
      sp_X = gradient_algorithm_constant(X, M_big, mask, stepsize)
      if(sp_X[1,1] == -100){
        stepsize = stepsize/10
      }else{
        break
      }
    }
    value = calculate_obj(sp_X, M_big, mask)
    if (value > 1e-10){
      #break
      spur = spur +1
    }
    counter = counter +1
    print(c(spur/counter, counter))
  }
  print(i)  
  success_percent_2[i] = spur/counter
  epsilon_length_2[i] = (i)/200
}

n_epsilon2 = n_epsilon
data2 = data.frame(epsilon_length_2, success_percent_2)
write.csv(n_epsilon2, file = 'perturbation_random_graph_rank2_S3_cs.csv')
write.csv(data2, file= 'convergence_random_graph_rank2_S3_cs.csv')
write.csv(mask, file = 'observation_pattern_random_graph_rank2_S3_cs.csv')
write.csv(ivs_vertices, file = "independent_set_random_graph_rank2_S3_cs.csv")


vertex_size = 10
rank = 2
block = vertex_size
probability_edge = 0.60
graph <- erdos.renyi.game(vertex_size, probability_edge, type='gnp',
                          directed = FALSE, loops = FALSE)

adj_matrix = as_adjacency_matrix(graph)
is.connected(graph) # Check if true
largest_ivs(graph)[1]
ivs_vertices = c(2,4,7,10) #Check the vertices 

mask = matrix(0, ncol = vertex_size*rank, nrow = vertex_size*rank)
for (i in 1:vertex_size) {
  for (j in 1:vertex_size) {
    if(adj_matrix[i,j]==1){
      mask[(rank*(i-1)+1):(rank*(i-1)+rank),(rank*(j-1)+1):(rank*(j-1)+rank)] =1
    }
    if(i == j){
      mask[(rank*(i-1)+1):(rank*(i-1)+rank),(rank*(j-1)+1):(rank*(j-1)+rank)] =1
      
    }
  }
}

for (i in 1:(length(ivs_vertices)-1)) {
  j = ivs_vertices[i]
  k = ivs_vertices[i+1]
  mask[(rank*(j-1)+1):(rank*(j-1)+rank),(rank*(k-1)+1):(rank*(k-1)+rank)] = 1
  mask[(rank*(k-1)+1):(rank*(k-1)+rank),(rank*(j-1)+1):(rank*(j-1)+rank)] = 1
  for (m in 1:rank) {
    mask[(rank*(j-1)+m),(rank*(k-1)+m)] = 0
    mask[(rank*(k-1)+m),(rank*(j-1)+m)] = 0
  }
}

identity = diag(rank)
zero = matrix(0, ncol= rank, nrow= rank)

M = matrix(0, nrow = vertex_size*rank, ncol = rank)
for (i in 1:length(ivs_vertices)) {
  j = ivs_vertices[i]
  M[(rank*(j-1)+1):(rank*(j-1)+rank),1:rank] = identity
}

c = rank
r = block * rank

epsilon = matrix(rnorm(c*r), ncol = c, nrow= r)
norm_epsilon = sqrt(sum(epsilon*epsilon))
n_epsilon = epsilon/norm_epsilon 
n_epsilon

success_percent_3 = c()
epsilon_length_3 = c()
for (i in 1:100){
  spur = 0 
  counter = 0
  M_new = M + n_epsilon*(i)/200
  M_big = M_new %*% t(M_new)
  while (counter < 100) {
    X = matrix(runif(c*r,-10,10), ncol=c, nrow=r)
    stepsize = 0.001
    while(TRUE){
      sp_X = gradient_algorithm_constant(X, M_big, mask, stepsize)
      if(sp_X[1,1] == -100){
        stepsize = stepsize/10
      }else{
        break
      }
    }
    value = calculate_obj(sp_X, M_big, mask)
    if (value > 1e-10){
      #break
      spur = spur +1
    }
    counter = counter +1
    print(c(spur/counter, counter))
  }
  print(i)  
  success_percent_3[i] = spur/counter
  epsilon_length_3[i] = (i)/200
}

n_epsilon3 = n_epsilon
data3 = data.frame(epsilon_length_3, success_percent_3)
write.csv(n_epsilon3, file = 'perturbation_random_graph_rank2_S4_cs.csv')
write.csv(data3, file= 'convergence_random_graph_rank2_S4_cs.csv')
write.csv(mask, file = 'observation_pattern_random_graph_rank2_S4_cs.csv')
write.csv(ivs_vertices, file = "independent_set_random_graph_rank2_S4_cs.csv")


vertex_size = 10
rank = 3
block = vertex_size
probability_edge = 0.90
graph <- erdos.renyi.game(vertex_size, probability_edge, type='gnp',
                          directed = FALSE, loops = FALSE)

adj_matrix = as_adjacency_matrix(graph)
is.connected(graph) # Check if true
largest_ivs(graph)[1]
ivs_vertices = c(2,5) #Check the vertices 

mask = matrix(0, ncol = vertex_size*rank, nrow = vertex_size*rank)
for (i in 1:vertex_size) {
  for (j in 1:vertex_size) {
    if(adj_matrix[i,j]==1){
      mask[(rank*(i-1)+1):(rank*(i-1)+rank),(rank*(j-1)+1):(rank*(j-1)+rank)] =1
    }
    if(i == j){
      mask[(rank*(i-1)+1):(rank*(i-1)+rank),(rank*(j-1)+1):(rank*(j-1)+rank)] =1
      
    }
  }
}

for (i in 1:(length(ivs_vertices)-1)) {
  j = ivs_vertices[i]
  k = ivs_vertices[i+1]
  mask[(rank*(j-1)+1):(rank*(j-1)+rank),(rank*(k-1)+1):(rank*(k-1)+rank)] = 1
  mask[(rank*(k-1)+1):(rank*(k-1)+rank),(rank*(j-1)+1):(rank*(j-1)+rank)] = 1
  for (m in 1:rank) {
    mask[(rank*(j-1)+m),(rank*(k-1)+m)] = 0
    mask[(rank*(k-1)+m),(rank*(j-1)+m)] = 0
  }
}

identity = diag(rank)
zero = matrix(0, ncol= rank, nrow= rank)

M = matrix(0, nrow = vertex_size*rank, ncol = rank)
for (i in 1:length(ivs_vertices)) {
  j = ivs_vertices[i]
  M[(rank*(j-1)+1):(rank*(j-1)+rank),1:rank] = identity
}

c = rank
r = block * rank

epsilon = matrix(rnorm(c*r), ncol = c, nrow= r)
norm_epsilon = sqrt(sum(epsilon*epsilon))
n_epsilon = epsilon/norm_epsilon 
n_epsilon

success_percent_4 = c()
epsilon_length_4 = c()
for (i in 55:100){
  spur = 0 
  counter = 0
  M_new = M + n_epsilon*(i)/200
  M_big = M_new %*% t(M_new)
  while (counter < 100) {
    X = matrix(runif(c*r,-10,10), ncol=c, nrow=r)
    stepsize = 0.001
    while(TRUE){
      sp_X = gradient_algorithm_constant(X, M_big, mask, stepsize)
      if(sp_X[1,1] == -100){
        stepsize = stepsize/10
      }else{
        break
      }
    }
    value = calculate_obj(sp_X, M_big, mask)
    if (value > 1e-10){
      #break
      spur = spur +1
    }
    counter = counter +1
    print(c(spur/counter, counter))
  }
  print(i)  
  success_percent_4[i] = spur/counter
  epsilon_length_4[i] = (i)/200
}

n_epsilon4 = n_epsilon
data4 = data.frame(epsilon_length_4, success_percent_4)
write.csv(n_epsilon4, file = 'perturbation_random_graph_rank3_S2_cs.csv')
write.csv(data4, file= 'convergence_random_graph_rank3_S2_cs.csv')
write.csv(mask, file = 'observation_pattern_random_graph_rank3_S2_cs.csv')
write.csv(ivs_vertices, file = "independent_set_random_graph_rank3_S2_cs.csv")


vertex_size = 10
rank = 3
block = vertex_size
probability_edge = 0.80
graph <- erdos.renyi.game(vertex_size, probability_edge, type='gnp',
                          directed = FALSE, loops = FALSE)

adj_matrix = as_adjacency_matrix(graph)
is.connected(graph) # Check if true
largest_ivs(graph)[1]
ivs_vertices = c(4,9,10) #Check the vertices 

mask = matrix(0, ncol = vertex_size*rank, nrow = vertex_size*rank)
for (i in 1:vertex_size) {
  for (j in 1:vertex_size) {
    if(adj_matrix[i,j]==1){
      mask[(rank*(i-1)+1):(rank*(i-1)+rank),(rank*(j-1)+1):(rank*(j-1)+rank)] =1
    }
    if(i == j){
      mask[(rank*(i-1)+1):(rank*(i-1)+rank),(rank*(j-1)+1):(rank*(j-1)+rank)] =1
      
    }
  }
}

for (i in 1:(length(ivs_vertices)-1)) {
  j = ivs_vertices[i]
  k = ivs_vertices[i+1]
  mask[(rank*(j-1)+1):(rank*(j-1)+rank),(rank*(k-1)+1):(rank*(k-1)+rank)] = 1
  mask[(rank*(k-1)+1):(rank*(k-1)+rank),(rank*(j-1)+1):(rank*(j-1)+rank)] = 1
  for (m in 1:rank) {
    mask[(rank*(j-1)+m),(rank*(k-1)+m)] = 0
    mask[(rank*(k-1)+m),(rank*(j-1)+m)] = 0
  }
}

identity = diag(rank)
zero = matrix(0, ncol= rank, nrow= rank)

M = matrix(0, nrow = vertex_size*rank, ncol = rank)
for (i in 1:length(ivs_vertices)) {
  j = ivs_vertices[i]
  M[(rank*(j-1)+1):(rank*(j-1)+rank),1:rank] = identity
}

c = rank
r = block * rank

epsilon = matrix(rnorm(c*r), ncol = c, nrow= r)
norm_epsilon = sqrt(sum(epsilon*epsilon))
n_epsilon = epsilon/norm_epsilon 
n_epsilon

success_percent_5 = c()
epsilon_length_5 = c()
for (i in 1:100){
  spur = 0 
  counter = 0
  M_new = M + n_epsilon*(i)/200
  M_big = M_new %*% t(M_new)
  while (counter < 100) {
    X = matrix(runif(c*r,-10,10), ncol=c, nrow=r)
    stepsize = 0.001
    while(TRUE){
      sp_X = gradient_algorithm_constant(X, M_big, mask, stepsize)
      if(sp_X[1,1] == -100){
        stepsize = stepsize/10
      }else{
        break
      }
    }
    value = calculate_obj(sp_X, M_big, mask)
    if (value > 1e-10){
      #break
      spur = spur +1
    }
    counter = counter +1
    print(c(spur/counter, counter))
  }
  print(i)  
  success_percent_5[i] = spur/counter
  epsilon_length_5[i] = (i)/200
}

n_epsilon5 = n_epsilon
data5 = data.frame(epsilon_length_5, success_percent_5)
write.csv(n_epsilon5, file = 'perturbation_random_graph_rank3_S3_cs.csv')
write.csv(data5, file= 'convergence_random_graph_rank3_S3_cs.csv')
write.csv(mask, file = 'observation_pattern_random_graph_rank3_S3_cs.csv')
write.csv(ivs_vertices, file = "independent_set_random_graph_rank3_S3_cs.csv")
