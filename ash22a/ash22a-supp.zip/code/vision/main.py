import argparse
import sys
import os
import pdb
import numpy as np
import torch
import torch.optim as optim
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from tqdm import tqdm
from sklearn.linear_model import LogisticRegression
import utils
from model import Model

## code based on https://github.com/chingyaoc/DCL

def get_negative_mask(batch_size):
    negative_mask = torch.ones((batch_size, 2 * batch_size), dtype=bool)
    for i in range(batch_size):
        negative_mask[i, i] = 0
        negative_mask[i, i + batch_size] = 0

    negative_mask = torch.cat((negative_mask, negative_mask), 0)
    return negative_mask


def train(net, data_loader, train_optimizer, temperature, tau_plus):
    net = net.train()
    total_loss, total_num, train_bar = 0.0, 0, data_loader
    count = 0
    avLoss = 0
    for pos_1, pos_2, target, negs in train_bar:

        pos_1, pos_2 = pos_1.cuda(non_blocking=True), pos_2.cuda(non_blocking=True)
        feature_1, out_1 = net(pos_1)
        feature_2, out_2 = net(pos_2)
        concat = torch.cat((out_1, out_2), 0)
        bs = len(out_2)
        inds = np.arange(bs)
           
            
        negEmbs = []
        samp = min(args.k, 2 * args.batch_size - 2)
        for i in range(args.batch_size): 
            inds = [j for j in range(args.batch_size * 2) if j != i and j != (i + args.batch_size)]
            np.random.shuffle(inds)
            inds = inds[:samp]
            use = concat[inds]
            negEmbs.append(concat[inds])


        diffs = out_2.unsqueeze(1) - torch.stack(negEmbs).cuda()

        # take dot with current example 
        dots = torch.sum(out_1.unsqueeze(1) * diffs, 2) / temperature

        # get the loss
        zeros = torch.zeros(bs, 1).cuda()
        loss = torch.logsumexp(torch.cat((-1 * dots, zeros), 1), 1).mean()

        train_optimizer.zero_grad()
        loss.backward()
        train_optimizer.step()

        total_num += batch_size
        total_loss += loss.item() * batch_size
        avLoss += loss.item()
        count += 1
        if count % 10 == 0: 
            print('Train Epoch: [{}/{}] Loss: {:.4f}, progress: {}'.format(epoch, epochs, avLoss / 100, count), flush=True)
            avLoss = 0
        #if count == 40: break
    return total_loss / total_num, net


# test function
def test(net, memory_data_loader, test_data_loader, downstream):
    net.eval()


    with torch.no_grad():

        # embed data
        Xemb = []
        Ytrain = []
        for pos_1, pos_2, target, negs in memory_data_loader:
            feature, out = net(pos_1.cuda())
            Xemb.append(feature.cpu())
            Ytrain.append(target.cpu())

        XembTest = []
        Ytest = []
        for data, _, target, _ in test_data_loader:
            feature, out = net(data.cuda())
            XembTest.append(feature.cpu())
            Ytest.append(target.cpu())

        Xemb = torch.cat(Xemb)
        XembTest = torch.cat(XembTest)
        Ytrain = torch.cat(Ytrain)
        Ytest = torch.cat(Ytest)

    # mean classifier
    ce = nn.CrossEntropyLoss()
    means = torch.stack([torch.mean(Xemb[Ytrain == i], 0) for i in range(nClasses)])
    scores = XembTest @ means.t()
    mca = torch.sum(torch.argmax(scores, 1) == Ytest).item() / len(Ytest)
    mcl = ce(scores, Ytest.long()).item()


    # train logistic regression
    correctTrain = correctTest = lossTrain = lossTest = 0.
    printEvery = 100
    linear = downstream
    opt = optim.Adam(linear.parameters(), lr=1e-3)
    i = 0
    bestLoss = np.inf
    attempts = 0
    batchSize = 512

    maxAttempts = 100
    while True:
        i += 1
        inds = np.random.randint(0, len(Xemb), batchSize)
        Xbatch = Xemb[inds].cuda()
        Ybatch = Ytrain[inds].cuda()
        output = linear(Xbatch)
        loss = ce(output, Ybatch)
        loss.backward()
        opt.step()
        opt.zero_grad()
        lossTrain += loss.item()
        correctTrain += torch.sum(torch.argmax(output, 1) == Ybatch).item()

        output = linear(XembTest.cuda())
        loss = ce(output, Ytest.cuda())
        lossTest = loss.item()
        correctTest = torch.sum(torch.argmax(output, 1) == Ytest.cuda()).item()

        if i % printEvery == 0:
            correctTrain /= (batchSize * printEvery)
            lossTrain /= (batchSize * printEvery)
            correctTest /= len(XembTest) 
            if lossTrain < bestLoss:
                bestLoss = lossTrain
                attempts = 0
            else:
                attempts += 1
                if attempts == maxAttempts or i == 1000000:
                    break
            if correctTrain > 0.99: break

            print(i, attempts, lossTrain, correctTrain, lossTest, correctTest, flush=True)
            correctTrain = correctTest = lossTrain = lossTest = 0.


    return correctTest, lossTest, mca, mcl


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Train SimCLR')
    parser.add_argument('--feature_dim', default=128, type=int, help='Feature dim for latent vector')
    parser.add_argument('--temperature', default=0.5, type=float, help='Temperature used in softmax')
    parser.add_argument('--tau_plus', default=0.1, type=float, help='Positive class priorx')
    parser.add_argument('--lr', default=1e-3, type=float, help='learning rate')
    parser.add_argument('--k', default=32, type=int, help='Top k most similar images used to predict the label')
    parser.add_argument('--dummy', default=0, type=int, help='Top k most similar images used to predict the label')
    parser.add_argument('--batch_size', default=256, type=int, help='Number of images in each mini-batch')
    parser.add_argument('--epochs', default=400, type=int, help='Number of sweeps over the dataset to train')
    parser.add_argument('--useReal', default=0, type=int, help='use a real, same-class sample for the positive or do augmentation?')
    parser.add_argument('--gLayers', default=0, type=int, help='depth of g')
    parser.add_argument('--data', default='cifar10', type=str, help='cifar10 or svhn')

    # args parse
    args = parser.parse_args()



    feature_dim, temperature, tau_plus, k = args.feature_dim, args.temperature, args.tau_plus, args.k
    batch_size, epochs = args.batch_size, args.epochs

    
    data = args.data
    nClasses = 10
    if args.useReal: 
        if data == 'cifar10': train_data = utils.CIFAR10Pair("data/", train=True, download = True, transform=utils.test_transform)
        if data == 'svhn': train_data = utils.SVHNPair("data/", split='train', download = True, transform=utils.test_transform)
    else: 
        if data == 'cifar10': train_data = utils.CIFAR10Pair("data/", train=True, download = True, transform=utils.train_transform)
        if data == 'svhn': train_data = utils.SVHNPair("data/", split='train', download = True, transform=utils.train_transform)

    if data == 'svhn': 
        train_data.classMap = [np.where(np.asarray(train_data.labels) == i)[0] for i in range(nClasses)]
    else:
        train_data.classMap = [np.where(np.asarray(train_data.targets) == i)[0] for i in range(nClasses)]
    train_data.useReal = args.useReal
    toAdd = int(np.ceil((args.k - 2 * args.batch_size + 2) / batch_size))
    train_data.k = max(1, toAdd)

    if data == 'cifar10': memory_data= utils.CIFAR10Pair("data/", train=True, download = True, transform=utils.test_transform)
    if data == 'svhn': 
        memory_data = utils.SVHNPair("data/", split='train', download = True, transform=utils.test_transform)
        memory_data.classMap = [np.where(np.asarray(memory_data.labels) == i)[0] for i in range(nClasses)]
    else: memory_data.classMap = [np.where(np.asarray(memory_data.targets) == i)[0] for i in range(nClasses)]
    memory_data.useReal = args.useReal
    memory_data.k = max(1, toAdd)
    if memory_data.k > 1: sys.exit(0)

    if data == 'cifar10': test_data  = utils.CIFAR10Pair("data/", train=False, download= True, transform=utils.test_transform)
    if data == 'svhn': 
        test_data = utils.SVHNPair("data/", split='test', download = True, transform=utils.test_transform)
        test_data.classMap = [np.where(np.asarray(test_data.labels) == i)[0] for i in range(nClasses)]
    else:
        test_data.classMap = [np.where(np.asarray(test_data.targets) == i)[0] for i in range(nClasses)]
    test_data.useReal = args.useReal
    test_data.k = max(1, toAdd)

    train_loader = DataLoader(train_data, batch_size=batch_size, shuffle=True, num_workers=4, pin_memory=True, drop_last=True)
    memory_loader = DataLoader(memory_data, batch_size=128, shuffle=False, num_workers=1, pin_memory=True)
    test_loader = DataLoader(test_data, batch_size=128, shuffle=False, num_workers=1, pin_memory=True)

    # model setup and optimizer config
    model = Model(feature_dim, args.gLayers).cuda()

    optimizer = optim.Adam(model.parameters(), lr=args.lr, weight_decay=1e-6)
    c = len(memory_data.classMap)
    print('# Classes: {}'.format(c))




    pa = os.getenv('AMLT_OUTPUT_DIR', '/tmp')
    print(pa, flush=True) 
    # training loop
    if not os.path.exists('results'):
        os.mkdir('results')
    for epoch in range(1, epochs + 1):
        train_loss, model = train(model, train_loader, optimizer, temperature, tau_plus)
        if epoch % 50 == 0:
            torch.save({'model': model.cpu(), 'epochs': epoch}, pa + '/features.pt')
            model.cuda()
            correctTest, lossTest, mca, mcl = test(model, memory_loader, test_loader, 
                nn.Sequential(nn.Linear(feature_dim, 10)).cuda()
            )
            print('Test Linear: ', epoch, correctTest, lossTest, mca, mcl, flush=True)
            correctTest, lossTest, mca, mcl = test(model, memory_loader, test_loader, 
                nn.Sequential(nn.Linear(512, 512, bias=False), nn.BatchNorm1d(512), nn.ReLU(inplace=True), nn.Linear(512, feature_dim, bias=True)).cuda()
            )
            print('Test MLP: ', epoch, correctTest, lossTest, mca, mcl, flush=True)






