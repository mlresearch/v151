from distutils.core import setup

setup(name='hitandrun',
      version='0.1',
      py_modules=['hitandrun'],
      )
