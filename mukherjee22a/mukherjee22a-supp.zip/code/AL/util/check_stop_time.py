
import numpy as np

def check_stop_time(log_L, num_hypo):
    
    delta = 0.05
    beta_func = np.log((num_hypo)/delta)
    
    for j in range(num_hypo):
        #num_cross = 0
        diff = log_L[j] - log_L
        if (diff > beta_func).sum() >= num_hypo - 1:
            return True

    return False