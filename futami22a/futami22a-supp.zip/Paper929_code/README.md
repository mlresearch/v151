Code for *Predictive variational Bayesian inference as risk-seeking optimization*

This code is built on the code for *Learning under Model Misspecification: Applications to Variational and Ensemble methods*, NeurIPS 2020 (https://github.com/PGM-Lab/PAC2BAYES).
When you use our code, please cite the their paper too.


## Dependencies
- tensorflow 1.15.0
- tensorflow-probability 0.8.0

## Usage
The code reproduce the experiments in Section 5 in our paper. Please use this, for example, as follows:
```
%run -i Code_ent_vb.py --temp 1.0 --tempKL --1.0 --epoch 100 --data "mnist"
```
- --temp means the temperature parameter in Entropic risk.
- --tempKL means the temperature of KL divergence of the objective function.
