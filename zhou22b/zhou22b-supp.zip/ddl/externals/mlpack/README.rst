Making the necessary mlpack functions transparent in Python.

Copied some source files from
~/mlpack/build/src/mlpack/bindings/python/mlpack
