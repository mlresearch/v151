import itertools
import multiprocessing as mp
import numpy as np
import os, pickle
from tqdm import tqdm, trange
import math
import numpy.linalg as npl
import scipy.special,time, scipy.stats
from collections import Counter
from scipy.special import comb as choose
import heapq

def ceil(arr):
    return np.ceil(arr).astype(int)

def gain(mu,w):
    vec = w*np.sqrt(mu*(1-mu))
    return len(mu)*np.linalg.norm(vec,2)**2/np.linalg.norm(vec,1)**2

def adaBatch(w,muBase,epsTarget,delta,iterCount,baseE=2):
    n = len(w)
    b0=2
    t=0

    start=time.time()
    numPullsArr = np.zeros(n,dtype='int')
    estMeans = np.zeros(n)
    
    errArr = []
    budgetArr = []
    timingArr = []
    while True: 
        
        roundBudget = n*b0*baseE**t ### change base of exp
        numUnifPulls = ceil(roundBudget/n)
        
        samples = np.zeros(n)
        for i in range(n):
            samples[i] = np.random.binomial(n=numUnifPulls,p=muBase[i]) / numUnifPulls
        estMeans = (estMeans * numPullsArr + numUnifPulls*samples)/(numPullsArr+numUnifPulls) 
        numPullsArr += numUnifPulls
        
        ### phase 2
        numOnes = estMeans*numPullsArr
        M2Arr = numOnes*(1-estMeans)**2 + (numPullsArr-numOnes)*estMeans**2
        stdEst = np.sqrt(M2Arr/(numPullsArr-1))
        confSigma = np.sqrt(np.log(1.0/delta)/(numPullsArr-1))
        
        alphaVec = w*np.maximum(stdEst-confSigma,0)
        if alphaVec.max()==0: ## if all 0, more uniform sampling
            alphaVec = np.ones(n)
        alphaVec/=alphaVec.sum()
        
        # factor inserted to downweight uniform sampling
        ft = min(t+1,10)
        tTilde = ceil(alphaVec*roundBudget*ft)
        
        tempestMeans = np.copy(estMeans)
        tempnumPullsArr = np.copy(numPullsArr)
        for i in range(n):
            tti = tTilde[i]
            pulli = numPullsArr[i]
            if tti ==0:
                continue

            samples = np.random.binomial(n=tti,p=muBase[i]) / tti
            tempestMeans[i] = (estMeans[i] * pulli + tti*samples)/(pulli+tti)
            tempnumPullsArr[i] += tti

        errArr.append(np.abs(np.dot(w,muBase-tempestMeans)))
        budgetArr.append(tempnumPullsArr.sum())
        timingArr.append(time.time()-start)

        numOnes = estMeans*numPullsArr
        M2Arr = numOnes*(1-estMeans)**2 + (numPullsArr-numOnes)*estMeans**2
        stdEst = np.sqrt(M2Arr/(numPullsArr-1))
        confSigma = np.sqrt(np.log(1.0/delta)/(numPullsArr-1))
        
        if 16*np.log(1.0/delta)*np.sum(w*(stdEst+confSigma)**2/tempnumPullsArr) <= epsTarget**2:
            estMeans= tempestMeans
            numPullsArr = tempnumPullsArr
            break
            
        t+=1
        if t==iterCount:
            break
    return estMeans,errArr,budgetArr,timingArr


def unifBatch(w,muBase,epsTarget,delta,iterCount,baseE=2):
    n = len(muBase)
    t=0
    b0=2
    numPullsArr = np.zeros(n)
   
    estMeans = np.zeros(n)
    errArr = []
    budgetArr = []
    timingArr = []
    
    start = time.time()
    while True: 
        
        roundBudget = n*b0*baseE**t ## change base of exp
        numUnifPulls = ceil(roundBudget/n)
            
        samples = np.zeros(n)
        for i in range(n):
            samples[i] = np.random.binomial(n=numUnifPulls,p=muBase[i]) / numUnifPulls
        estMeans = (estMeans * numPullsArr + numUnifPulls*samples)/(numPullsArr+numUnifPulls) 
        numPullsArr += numUnifPulls
        
        errArr.append(np.abs(np.dot(w,estMeans-muBase)))
        budgetArr.append(numPullsArr.sum())
        timingArr.append(time.time()-start)
        
                                       
        ## check if terminate
        numOnes = estMeans*numPullsArr
        M2Arr = numOnes*(1-estMeans)**2 + (numPullsArr-numOnes)*estMeans**2
        stdEst = np.sqrt(M2Arr/(numPullsArr-1))
        confSigma = np.sqrt(np.log(1.0/delta)/(numPullsArr-1))
        
        if 16*np.log(1.0/delta)*np.sum(w*(stdEst+confSigma)**2/numPullsArr) <= epsTarget**2:
            break
        
        t+=1
        if t==iterCount:
            break
       
    return errArr,budgetArr,timingArr


## Optimism-based algorithm
def adaAllocOptimism(w,muBase,budgetArr,delta,sigmaSq=1):
    n = len(muBase)
    soln = w.dot(muBase)

    numPullsArr = np.ones(n)
    M2Arr = np.zeros(n)
    muEst = np.zeros(n)
    
    errArr = np.zeros(len(budgetArr))
    outputPullsArr = np.zeros((len(budgetArr),n))
    outputTimeArr = np.zeros(len(budgetArr))
    budgetArrCtr = 0
    
    
    ## generating samples beforehand speeds up the algorithm by 10x
    sampleArr = np.zeros((budgetArr[-1],n))
    for i in range(n):
        sampleArr[:,i] = scipy.stats.bernoulli.rvs(muBase[i],size=budgetArr[-1])
    
    start=time.time()
    beta = np.sqrt(sigmaSq*np.log(1.0/delta))
    for t in range(budgetArr[-1]+1):
        if numPullsArr.sum() >= budgetArr[budgetArrCtr]:
            errArr[budgetArrCtr] = np.abs(w.dot(muEst-muBase))
            outputPullsArr[budgetArrCtr] = np.copy(numPullsArr)
            outputTimeArr[budgetArrCtr] = time.time()-start
            budgetArrCtr+=1
            if numPullsArr.sum() == budgetArr[-1]:
                break
        
        if t<2*n:
            toPull = t%n
        else:
            if t==2*n:
                stdArr = np.sqrt(M2Arr/(numPullsArr-1))
                B= w/numPullsArr * (stdArr + 2*beta/np.sqrt(numPullsArr))
                pq = []
                for i in range(n):
                    heapq.heappush(pq,(-B[i],i))
            toPull = heapq.heappop(pq)[1]
        
        numPullsArr[toPull]+=1
        sample = sampleArr[t,toPull]
        delta1 = sample - muEst[toPull]
        muEst[toPull] += delta1/numPullsArr[toPull]
        delta2 = sample - muEst[toPull]
        M2Arr[toPull]+= delta1*delta2
        
        if t>= 2*n:
            i=toPull
            bScore = -w[i]/numPullsArr[i]* (np.sqrt(M2Arr[i]/(numPullsArr[i]-1)) + 2*beta/np.sqrt(numPullsArr[i]))
            heapq.heappush(pq,(bScore,i))
        
    return errArr,outputPullsArr,outputTimeArr

        
def runSimAdaOptimism(args):
    os.environ["MKL_NUM_THREADS"] = "1" 
    os.environ["NUMEXPR_NUM_THREADS"] = "1" 
    os.environ["OMP_NUM_THREADS"] = "1"
    
    (i,w,mu,budgetArr,delta) = args
    
    if os.path.isfile("{}/adaOpt_sim{}.pkl".format(baseDir,i)):
        print("already ran file {}/adaOpt_sim{}.pkl".format(baseDir,i))
        return
    
    np.random.seed(i)
    start=time.time()
    errorArr,numPullsArr,timeArr = adaAllocOptimism(w,mu,budgetArr,delta,.0001)
    end=time.time()
    
    with open(r"{}/adaOptBer_sim{}.pkl".format(baseDir,i), "wb" ) as writeFile:
        pickle.dump({"errorArr":errorArr,"numPullsArr":numPullsArr,"time":timeArr}, writeFile )
    

def runSimStopping(args):
    os.environ["MKL_NUM_THREADS"] = "1" 
    os.environ["NUMEXPR_NUM_THREADS"] = "1" 
    os.environ["OMP_NUM_THREADS"] = "1"
    
    (i,n,numSubTrials,epsilon,delta) = args
    
    # if os.path.isfile("{}/adaOpt_sim{}.pkl".format(baseDir,i)):
    #     print("already ran file {}/adaOpt_sim{}.pkl".format(baseDir,i))
    #     return
    
    np.random.seed(i)
    mu = np.random.pareto(.5,size=n)**2
    muMax = np.random.uniform()
    mu/=np.max(mu)/muMax

    w = np.random.uniform(size=n)
    numRounds=200

    gainVal= gain(mu,w)
    
    adaBudgetBatch = np.zeros(numSubTrials)
    adaFinalError = np.zeros(adaBudgetBatch.shape)
    unifBudgetBatch = np.zeros(numSubTrials)
    unifFinalError = np.zeros(unifBudgetBatch.shape)
    
    
    for j in range(numSubTrials):
        eBase = 2-j/numSubTrials/2

        estMeans,errArrAda,budgetArrAda,timingArr = adaBatch(w,mu, epsilon,delta,numRounds,eBase) #eps,delta,...
        assert(errArrAda[-1]<eps)
        adaBudgetBatch[j] = budgetArrAda[-1]
        adaFinalError[j] = errArrAda[-1]


        errArrUnif,budgetArrUnif,timingArr = unifBatch(w,mu,epsilon,delta,numRounds,eBase)
        assert(errArrUnif[-1]<eps)
        unifBudgetBatch[j] = budgetArrUnif[-1]
        unifFinalError[j] = errArrUnif[-1]
    
    with open(r"{}/adaBerStopping_sim{}.pkl".format(newDir,i), "wb" ) as writeFile:
        pickle.dump({"ada":(adaBudgetBatch,adaFinalError),"unif":(unifBudgetBatch,unifFinalError),"gain":gainVal}, writeFile )

    
####### command center start
runOpt = True
runBatch = False
runGain = False

delta = .01
numTrials = 100
num_jobs = 2

baseDir = "pkls/bern_n100_pareto_sq00001"
print('running for', baseDir)
if not os.path.isdir(baseDir):
    print('creating directory')
    os.mkdir(baseDir)
n=100
budgetArr = np.round(np.logspace(np.log2(n),np.log2(1000000),num=20,base=2)).astype(int)

a = list(budgetArr)
a.extend([10**x for x in [3,4,5]]) ### adding extra elements for comparison
a = np.array(a)
a.sort()
budgetArr = a

np.random.seed(0)
muBase = np.random.pareto(.5,size=n)**2
muBase/=np.max(muBase)*2 ## max is .5
w = np.random.uniform(size=n)
w/= w.sum()
with open(r"{}/info.pkl".format(baseDir), "wb" ) as writeFile:
        pickle.dump({"mu":muBase,"w":w,"budgets":budgetArr,"numTrials":numTrials}, writeFile )

f = lambda x :  x.dot(w)
        
pool      = mp.Pool(processes=num_jobs)
arg_tuple = itertools.product(list(range(numTrials)),[w],[muBase],[budgetArr],[delta])
if runOpt:
    for _ in tqdm(pool.imap_unordered(runSimAdaOptimism, arg_tuple), total=numTrials, desc='Optimism'):
        pass
    

numTrialsBatch = 1000
numRounds = 14
numRoundsUnif = 15
epsilon=.000001
adaErrorBatch = np.zeros((numTrialsBatch,numRounds))
adaBudgetBatch = np.zeros(adaErrorBatch.shape)
unifErrorBatch = np.zeros((numTrialsBatch,numRoundsUnif))
unifBudgetBatch = np.zeros(unifErrorBatch.shape)

adaTimingArr = np.zeros(adaErrorBatch.shape)
unifTimingArr = np.zeros(unifErrorBatch.shape)
if runBatch:
    for i in tqdm(range(numTrialsBatch), desc='adaBatch'):
        np.random.seed(i)
        estMeans,errArrAda,budgetArrAda,timingArr = adaBatch(w,muBase, epsilon,.01,numRounds) #eps,delta,...
        adaErrorBatch[i] = errArrAda
        adaBudgetBatch[i] = budgetArrAda
        adaTimingArr[i] = timingArr


    for i in tqdm(range(numTrialsBatch), desc='unifBatch'):
        np.random.seed(i)
        errArrUnif,budgetArrUnif,timingArr = unifBatch(w,muBase,epsilon,.01,numRoundsUnif) #eps,delta,...
        unifErrorBatch[i] = errArrUnif
        unifBudgetBatch[i] = budgetArrUnif
        unifTimingArr[i] = timingArr


    with open(r"{}/batched.pkl".format(baseDir), "wb" ) as writeFile:
            pickle.dump({"ada":(adaErrorBatch, adaBudgetBatch, adaTimingArr) , "unif":(unifErrorBatch, unifBudgetBatch, unifTimingArr)}, writeFile )

            
##### running stopping time simulations
numBaseTrials = 100
numSubTrials = 200

numRounds = 80000
eps = .0001
delta=.01
n=100

adaBudgetBatch = np.zeros((numBaseTrials,numSubTrials))
adaFinalError = np.zeros(adaBudgetBatch.shape)
unifBudgetBatch = np.zeros((numBaseTrials,numSubTrials))
unifFinalError = np.zeros(unifBudgetBatch.shape)
gainArr = np.zeros(numBaseTrials)

if runGain:
    
    newDir = baseDir + "/stopping"
    if not os.path.isdir(newDir):
        print('creating directory')
        os.mkdir(newDir)
    
    
    pool      = mp.Pool(processes=num_jobs)
    arg_tuple = itertools.product(list(range(numBaseTrials)),[n],[numSubTrials],[epsilon],[delta]) #(i,n,numSubTrials,epsilon,delta)
    for _ in tqdm(pool.imap_unordered(runSimStopping, arg_tuple), total=numBaseTrials, desc='Stopping simulations'):
        pass
    
    for i in range(numBaseTrials):
        myData = pickle.load( open( "{}/adaBerStopping_sim{}.pkl".format(newDir,i), "rb" ) )
        budgetArrAda,errArrAda = myData['ada']
        budgetArrUnif,errArrUnif = myData['unif']
        gainArr[i] = myData['gain']

        adaBudgetBatch[i] = budgetArrAda
        adaFinalError[i] = errArrAda

        unifBudgetBatch[i] = budgetArrUnif
        unifFinalError[i] = errArrUnif
    with open(r"{}/batched_stopping.pkl".format(baseDir), "wb" ) as writeFile:
        pickle.dump({"ada":(adaBudgetBatch, adaFinalError) , "unif":(unifBudgetBatch, unifFinalError), "gainArr":gainArr}, writeFile )