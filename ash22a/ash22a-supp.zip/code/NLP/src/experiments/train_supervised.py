import gc
import os
import json
import torch
import pickle
import random
import logging
import argparse
import numpy as np
import torch.multiprocessing as mp

from task.task_wrapper import TaskWrapper
from utils.tensorboard import Tensorboard
from setup_validator.core_validator import validate
from model.discriminator_wrapper import DiscriminatorWrapper
from learner.downstream_training import DownstreamClassificationTask
from utils.multiprocess_logger import MultiprocessingLoggerManager


def main():

    parser = argparse.ArgumentParser()
    parser.add_argument("--task", default='wiki-3029', help="name of the task e.g., wiki-3029")
    parser.add_argument("--name", default="supervised-learning", help="Name of the experiment")
    parser.add_argument("--num_classes", default=-1, type=int, help="Number of classes to select (if set to -1 then "
                                                                    "use all classes in the dataset)")
    parser.add_argument("--lr", default=-1, type=float, help="Learning rate")
    parser.add_argument("--hidden_dim", default=-1, type=int, help="Hidden dimension")
    parser.add_argument("--batch_size", default=-1, type=int,
                        help="Batch size (also controls negative examples for log_loss_batch case)")
    parser.add_argument("--seed", default=-1, type=int, help="Experiment seed")
    parser.add_argument("--loss", default="margin", type=str, help="Type of loss (log_loss, log_loss_batch, margin)")
    parser.add_argument("--save_path", default="./results/", type=str, help="Folder where to save results")
    parser.add_argument("--data_path", default="./cache", type=str, help="Folder where cached data is saved")
    parser.add_argument("--debug", default="False", help="Debug the run")
    parser.add_argument("--pushover", default="False", help="Use pushover to send results on phone")
    args = parser.parse_args()

    task_name = args.task

    exp_name = args.name
    experiment_name = "supervised-%s-%s-classes-%d-seed-hd-%d-%d" % \
                      (exp_name, task_name, args.num_classes, args.hidden_dim, args.seed)
    experiment = "%s/%s" % (args.save_path, experiment_name)

    # Create the experiment folder
    if not os.path.exists(experiment):
        os.makedirs(experiment)

    # Define log settings
    log_path = experiment + '/train_supervised.log'
    multiprocess_logging_manager = MultiprocessingLoggerManager(
        file_path=log_path, logging_level=logging.INFO)
    master_logger = multiprocess_logging_manager.get_logger("Master")
    master_logger.log("----------------------------------------------------------------")
    master_logger.log("                    STARING NEW EXPERIMENT                      ")
    master_logger.log("----------------------------------------------------------------")
    master_logger.log("Environment Name %r. Experiment Name %r" % (task_name, exp_name))

    # Read configuration and constant files. Configuration contain environment information and
    # constant file contains hyperparameters for the model and learning algorithm.
    # Add command line arguments. Command line arguments supersede file settings.
    with open("data/%s/config.json" % task_name) as f:
        config = json.load(f)

        config["num_classes"] = args.num_classes
        config["data_path"] = args.data_path
        config["save_path"] = experiment
        config["exp_name"] = experiment_name

    with open("data/%s/constants.json" % task_name) as f:
        constants = json.load(f)

        constants["loss"] = args.loss

        if args.lr != -1:
            constants["lr"] = args.lr

        if args.hidden_dim != -1:
            constants["n_hidden"] = args.hidden_dim

        if args.batch_size != -1:
            constants["batch_size"] = args.batch_size

    print(json.dumps(config, indent=2))

    # Validate the keys
    validate(config, constants)

    # log core experiment details
    master_logger.log("CONFIG DETAILS")
    for k, v in sorted(config.items()):
        master_logger.log("    %s --- %r" % (k, v))
    master_logger.log("CONSTANTS DETAILS")
    for k, v in sorted(constants.items()):
        master_logger.log("    %s --- %r" % (k, v))
    master_logger.log("START SCRIPT CONTENTS")
    with open(__file__) as f:
        for line in f.readlines():
            master_logger.log(">>> " + line.strip())
    master_logger.log("END SCRIPT CONTENTS")

    if args.seed == -1:
        seeds = [1234, 1235, 1236, 1237, 1238, 1239, 1240, 1241, 1242, 1243]
    else:
        seeds = [args.seed]
    num_runs = len(seeds)
    performance = []

    for trial in range(1, num_runs + 1):

        # Set the random seed
        seed = seeds[trial - 1]
        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)

        config["seed"] = seed

        master_logger.log("========= STARTING EXPERIMENT %d with seed %d ======== " % (trial, seed))

        # Create a new environment with the new seed
        task = TaskWrapper.make_task(config, task_name, master_logger)
        master_logger.log("Task Named %s Created. Number of classes %d" % (task_name, task.get_num_class()))

        tensorboard = Tensorboard(experiment)
        learning_alg = DownstreamClassificationTask(config, constants, fine_tune_encoding=True)
        encoder_model = DiscriminatorWrapper.get_wrapper(config, constants)

        result = learning_alg.train(task=task,
                                    encoder_model=encoder_model,
                                    logger=master_logger,
                                    tensorboard=tensorboard)

        for k, v in config.items():
            result["config/%s" % k] = v

        for k, v in constants.items():
            result["constants/%s" % k] = v

        for k, v in args.__dict__.items():
            result["args/%s" % k] = v

        performance.append(result)
        gc.collect()

    # Save performance
    with open("%s/results.pickle" % experiment, "wb") as f:
        pickle.dump(performance, f)

    for key in sorted(performance[0]):  # Assumes the keys are same across all runs

        if key.startswith("config/") or key.startswith("constants/") or key.startswith("args/"):
            continue

        if not isinstance(performance[0][key], int) and not isinstance(performance[0][key], float):
            continue

        results = np.array([float(result[key]) for result in performance])
        master_logger.log("%r: Mean %r, Median %r, Std %r, Num runs %d, All performance %r" %
                          (key, np.mean(results), np.median(results), np.std(results), num_runs, results))

    # Cleanup
    multiprocess_logging_manager.cleanup()


if __name__ == "__main__":

    print("SETTING THE START METHOD ")
    mp.freeze_support()
    mp.set_start_method('spawn')
    main()
