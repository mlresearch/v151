import argparse
import math
import os

import numpy as np
import torch
import torch.nn as nn
import yaml

from src import get_module_logger
from src import spectralpruning as spec
from src.data.dataloader4txt import BatchfiedPTB, build_vocab
from src.models.predict_model4txt import evaluate
from src.models.prune_model import magnitude_weight_prune, random_weight_prune
from src.utils.model_rnnlm import prepare_trained_rnnlm


def main():
    logger = get_module_logger("prune")
    logger.debug("Begin...")
    parser = argparse.ArgumentParser()
    parser.add_argument("--wts_path", type=str, required=True, help="Path for weight parameter.")
    parser.add_argument("--m", type=int, default=None, help="Compressed hidden_size.")
    args = parser.parse_args()

    # Pruning preparations
    wts_path = args.wts_path
    m_sharp = args.m
    # Load configure yaml
    cfg = os.path.join(*wts_path.split("/")[:-2], "config.yaml")
    with open(cfg, "r") as f:
        data = yaml.load(f, Loader=yaml.SafeLoader)
    for key in data:
        args.__setattr__(key, data[key])
    logger.debug(args)

    # Model parameters
    hidden_size = args.hidden_size
    dropout = args.dropout
    # tie_weights = args.tie_weights
    tie_weights = False  # Can turn on True ??

    # Learning parameters
    batch_size = args.batch_size
    eval_batch_size = args.eval_batch_size
    bptt = args.bptt

    # Dataset parameters
    # dataset = args.dataset
    data_dir = args.data_dir

    # Prepare dataloader
    vocab = build_vocab(data_dir)
    train_ds = BatchfiedPTB(data_dir, "train", vocab, batch_size, bptt)
    train_dl = torch.utils.data.DataLoader(train_ds, batch_size=bptt, shuffle=False)
    test_ds = BatchfiedPTB(data_dir, "test", vocab, eval_batch_size, bptt)
    test_dl = torch.utils.data.DataLoader(test_ds, batch_size=bptt, shuffle=False)
    logger.debug("Datasets are loaded.")

    # Check device
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    if torch.cuda.is_available():
        torch.backends.cudnn.benchmark = True
    logger.debug("GPU or CPU: %s" % device)

    # Calculate covariance matrix
    cov_path = os.path.join(os.path.dirname(wts_path), "cov.pkl")
    if not os.path.exists(cov_path):
        logger.debug("Calculating covariance matrix...")
        spec.save_cov4rnnlm(wts_path, dropout, tie_weights, train_dl, device, save_name="cov.pkl")
    else:
        logger.debug("Skip calculation of covariance matrix.")
    cov = spec.load_cov(cov_path)

    # Greedy algorithm and Spectral Pruning
    logger.debug("Spectral Pruning...")
    sub = None
    sub_F = spec.calc_non_zero_rows_idx(cov)
    NZR = spec.calc_non_zero_rows_n(cov)
    if m_sharp is None:
        m_sharp = NZR
        # sub = sub_F
        logger.info("  for m_sharp = %d (NZR)" % NZR)
    else:
        logger.info("  for m_sharp = %d (NZR)" % NZR)
        logger.info("  for m_sharp = %d (user)" % m_sharp)
    n_prune = hidden_size ** 2 - m_sharp ** 2
    logger.info("  for n_prune = %d" % n_prune)

    # Compare models before/after Spectral Pruning
    logger.info("Compare some Pruning Methods:")
    criterion = nn.CrossEntropyLoss()
    n_sample = 5  # sampling for n-times
    logger.info("Original:")
    model = prepare_trained_rnnlm(torch.load(wts_path, map_location=device), dropout=dropout, tie_weights=tie_weights)
    loss = evaluate(model, criterion, test_dl, device=device)
    logger.info("Test Loss: {:5.2f} ppl: {:8.2f}".format(loss, math.exp(loss)))

    logger.info("Spectral Pruning:")
    wts_pruned, _ = spec.prune_rnn_by_cov(
        torch.load(wts_path, map_location="cpu"), cov, m_sharp, sub=sub, sub_F=sub_F, quiet=True, pinv=False
    )
    model = prepare_trained_rnnlm(wts_pruned, dropout=dropout, tie_weights=tie_weights)
    loss = evaluate(model, criterion, test_dl, device=device)
    logger.info("Test Loss: {:5.2f} ppl: {:8.2f}".format(loss, math.exp(loss)))

    logger.info("Spectral Pruning w/o reconstruction matrix:")
    wts_pruned, _ = spec.prune_rnn_by_cov_wo_reconstruction(
        torch.load(wts_path, map_location="cpu"), cov, m_sharp, sub=sub, sub_F=sub_F, pinv=False
    )
    model = prepare_trained_rnnlm(wts_pruned, dropout=dropout, tie_weights=tie_weights)
    loss = evaluate(model, criterion, test_dl, device=device)
    logger.info("Test Loss: {:5.2f} ppl: {:8.2f}".format(loss, math.exp(loss)))
    torch.save(wts_pruned, os.path.join(os.path.dirname(wts_path), "wts_pruned_wo.pth"))
    logger.info("Saved pruned weight w/o reconstruction.")

    logger.info("Random Pruning w/  reconstruction matrix:")
    losses = []
    for i in range(n_sample):
        sub_random = np.sort(np.random.permutation(sub_F)[:m_sharp])
        wts_pruned, _ = spec.prune_rnn_by_cov(
            torch.load(wts_path, map_location="cpu"), cov, m_sharp, sub=sub_random, sub_F=sub_F, pinv=False
        )
        model = prepare_trained_rnnlm(wts_pruned, dropout=dropout, tie_weights=tie_weights)
        loss = evaluate(model, criterion, test_dl, device=device)
        losses.append(loss)
        torch.save(wts_pruned, os.path.join(os.path.dirname(wts_path), "wts_random_pruned%d.pth" % i))
        logger.info("Saved random pruned weight w/  reconstruction.")
    loss = np.mean(losses)
    logger.info("Test Loss: {:5.2f} ppl: {:8.2f}".format(loss, math.exp(loss)))

    logger.info("Random Pruning w/o reconstruction matrix:")
    losses = []
    for i in range(n_sample):
        sub_random = np.sort(np.random.permutation(sub_F)[:m_sharp])
        wts_pruned, _ = spec.prune_rnn_by_cov_wo_reconstruction(
            torch.load(wts_path, map_location="cpu"), cov, m_sharp, sub=sub_random, sub_F=sub_F, pinv=False
        )
        model = prepare_trained_rnnlm(wts_pruned, dropout=dropout, tie_weights=tie_weights)
        loss = evaluate(model, criterion, test_dl, device=device)
        losses.append(loss)
        torch.save(wts_pruned, os.path.join(os.path.dirname(wts_path), "wts_random_pruned_wo%d.pth" % i))
        logger.info("Saved random pruned weight w/o reconstruction.")
    loss = np.mean(losses)
    logger.info("Test Loss: {:5.2f} ppl: {:8.2f}".format(loss, math.exp(loss)))

    logger.info("Random Weight Pruning:")
    losses = []
    for i in range(n_sample):
        wts_pruned = random_weight_prune(torch.load(wts_path, map_location=device), n_prune)
        model = prepare_trained_rnnlm(wts_pruned, dropout=dropout, tie_weights=tie_weights)
        loss = evaluate(model, criterion, test_dl, device=device)
        losses.append(loss)
        torch.save(wts_pruned, os.path.join(os.path.dirname(wts_path), "wts_random_weight_pruned%d.pth" % i))
        logger.info("Saved random non-structured pruned weight.")
    loss = np.mean(losses)
    logger.info("Test Loss: {:5.2f} ppl: {:8.2f}".format(loss, math.exp(loss)))

    logger.info("Magnitude-based Weight Pruning:")
    wts_pruned = magnitude_weight_prune(torch.load(wts_path, map_location=device), n_prune)
    model = prepare_trained_rnnlm(wts_pruned, dropout=dropout, tie_weights=tie_weights)
    loss = evaluate(model, criterion, test_dl, device=device)
    logger.info("Test Loss: {:5.2f} ppl: {:8.2f}".format(loss, math.exp(loss)))
    torch.save(wts_pruned, os.path.join(os.path.dirname(wts_path), "wts_magnitude_weight_pruned.pth"))
    logger.info("Saved magnitude non-structured pruned weight.")

    logger.info("Magnitude-based Weight Over Pruning:")
    wts_pruned = torch.load(wts_path, map_location=device)
    wts_pruned["encoder.weight"] = wts_pruned["encoder.weight"] @ wts_pruned["rnn.weight_ih_l0"].t()
    nn.init.eye_(wts_pruned["rnn.weight_ih_l0"])
    for key, n_prune in [
        ("rnn.weight_hh_l0", hidden_size ** 2 - m_sharp ** 2),
        ("decoder.weight", wts_pruned["decoder.weight"].size(0) * (hidden_size - m_sharp)),
        ("encoder.weight", wts_pruned["decoder.weight"].size(0) * (hidden_size - m_sharp)),
    ]:
        wts_pruned[key] = magnitude_weight_prune(wts_pruned, n_prune, key=key)[key]
    # wts_pruned["encoder.weight"] = wts_pruned["decoder.weight"]
    model = prepare_trained_rnnlm(wts_pruned, dropout=dropout, tie_weights=tie_weights)
    loss = evaluate(model, criterion, test_dl, device=device)
    logger.info("Test Loss: {:5.2f} ppl: {:8.2f}".format(loss, math.exp(loss)))
    torch.save(wts_pruned, os.path.join(os.path.dirname(wts_path), "wts_magnitude_weight_pruned_over.pth"))
    logger.info("Saved magnitude non-structured OVER pruned weight.")

    logger.debug("Done!!")


if __name__ == "__main__":
    main()
