"""
    Implementation of Distributional Robustness Training 
"""
import numpy as np
import torch 
import torch.nn as nn 
from torchvision import datasets, transforms
from torch.utils.tensorboard import SummaryWriter
from torchsummary import summary

from mysetting import * 
from models import get_model, get_D_model_final
from models import activ, adjust_learning_rate, get_optimizer, get_D_optimizer

from gv_pgd import Gv_PGD

from mytrain import test, adv_test
from mytrain import test_Dis, adv_test_Dis

from utils_cm import mkdir_p, writelog, backup, merge_dict
from utils import get_acc

import re 
#------------------------------------------------------
# Dataset preprocessing 
if args.ds == 'mnist':
    nb_classes = 10
    x_max = 1.
    x_min = 0.
    transform=transforms.Compose([
            transforms.ToTensor(),
            ])
    train_data = datasets.MNIST('../data', train=True, download=True,
                        transform=transform)
    test_data = datasets.MNIST('../data', train=False,
                        transform=transform)
    epsilon = 0.3 
    step_size = 0.01
    num_steps= 40
    log_period = 10
    epsilon_range = [0.1, 0.2, 0.25, 0.3, 0.325, 0.35, 0.375, 0.4, 0.41, 0.42, 0.43, 0.44, 0.45, 0.46, 0.47, 0.48, 0.49, 0.5, 0.6, 0.7]
    input_size = (1, 28, 28)
    num_classes = 10
    
elif args.ds == 'cifar10': 
    nb_classes = 10
    x_max = 1.
    x_min = 0.
    transform_train = transforms.Compose([
        transforms.RandomCrop(32, padding=4),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
    ])
    transform_test = transforms.Compose([
        transforms.ToTensor(),
    ])
    train_data = datasets.CIFAR10('../data', train=True, download=True,
                        transform=transform_train)
    test_data = datasets.CIFAR10('../data', train=False,
                        transform=transform_test)    

    epsilon = 0.031
    step_size = 0.007
    num_steps= 10
    log_period = 50 if args.model == 'wideresnet' else 20 
    epsilon_range = [2., 4., 6., 8., 10., 12., 14., 16., 20., 24., 32.]
    epsilon_range = [x/255 for x in epsilon_range]
    input_size = (3, 32, 32)
    num_classes = 10

#------------------------------------------------------
# Params setting 
log_interval = 10

attack_params = dict()

attack_params['attack_type'] = args.attack_type
attack_params['epsilon'] = args.epsilon
attack_params['step_size'] = step_size if args.step_size < 0 else args.step_size
attack_params['num_steps'] = num_steps
attack_params['x_min'] = x_min
attack_params['x_max'] = x_max
attack_params['random_start'] = True 
attack_params['dis_input'] = args.dis_input 
attack_params['use_labels'] = args.use_labels
attack_params['lamda1'] = args.lamda1
attack_params['lamda2'] = args.lamda2

attack_params['defense'] = args.defense
attack_params['order'] = int(args.order) if args.order != 'inf' else np.inf
attack_params['loss_type'] = args.loss_type
attack_params['random_init'] = args.random_init
attack_params['projecting'] = args.projecting
attack_params['distype'] = args.distype
attack_params['trades_beta'] = args.trades_beta
attack_params['batch_size'] = args.bs
attack_params['num_classes'] = num_classes

eval_params = attack_params.copy()
eval_params['num_steps'] = 20
eval_params['epsilon'] = epsilon
# ------------------------------------------------------
import os 
os.chdir('./')
WP = os.path.dirname(os.path.realpath('__file__')) +'/log/'
print(WP)

save_dir = WP + basedir + '/' + modeldir + '/'
mkdir_p(basedir)
mkdir_p(save_dir)
mkdir_p(save_dir+'/codes/')
backup('./', save_dir+'/codes/')
model_dir = save_dir + 'model.pt'
D_model_dir = save_dir + 'discriminator.pt'
model_best_dir = save_dir + 'model_best.pt'

logfile = save_dir + 'log.txt'
log_params = save_dir + 'model_params.txt'

writer = SummaryWriter(save_dir+'log/')

for key in attack_params.keys(): 
    writelog('attack_params, {}:{}'.format(key, attack_params[key]), logfile)

use_cuda = not args.no_cuda and torch.cuda.is_available()

torch.manual_seed(20212022)

device = torch.device("cuda" if use_cuda else "cpu")

train_kwargs = {'batch_size': args.bs, 'shuffle': True} #'drop_last': True
test_kwargs = {'batch_size': args.bs}
if use_cuda:
    cuda_kwargs = {'num_workers': 1,
                    'pin_memory': True,
                    }
    train_kwargs.update(cuda_kwargs)
    test_kwargs.update(cuda_kwargs)

#------------------------------------------------------
# Load dataset 
train_loader = torch.utils.data.DataLoader(train_data, **train_kwargs)
test_loader = torch.utils.data.DataLoader(test_data, **test_kwargs)    

#------------------------------------------------------
# Model 
model = get_model(args.ds, args.model, activation=activ(args.activ))

assert(attack_params['use_labels'] is False)

D_model = get_D_model_final(args.ds, args.model, activation=activ(args.activ), 
                        num_manifold=1, 
                        dis_input=attack_params['dis_input'], 
                        use_lables=attack_params['use_labels'], 
                        num_hidden=args.num_hidden)

#------------------------------------------------------
if torch.cuda.device_count() > 1:
  print("Let's use", torch.cuda.device_count(), "GPUs!")
  model = nn.DataParallel(model)
  D_model = nn.DataParallel(D_model)

model.to(device)
D_model.to(device)

opt, lr = get_optimizer(ds=args.ds, model=model, architecture=args.model)
D_opt = get_D_optimizer(model=D_model)

#------------------------------------------------------
# Defense method 

Defense = Gv_PGD(basic_net=model, 
            config=attack_params, 
            discriminator=D_model, 
            D_optimizer=D_opt)


if torch.cuda.device_count() > 1:
  print("Let's use", torch.cuda.device_count(), "GPUs!")
  Defense = nn.DataParallel(Defense)

Defense.to(device)

#------------------------------------------------------
# Train model 
pre_acc = -1. 

assert (args.defense in ['pie'])

print('--- Start training method = {} ---'.format(args.defense))
model.train()
D_model.train()
Defense.train()

summary(model, input_size)
# summary(D_model)
writelog('----------------------------------',log_params)
for name, _ in model.named_parameters(): 
    writelog(name,log_params)
writelog('----------------------------------',log_params)
for name, _ in D_model.named_parameters(): 
    writelog(name,log_params)

num_batches = len(train_loader.dataset) // args.bs

for epoch in range(args.epochs): 
    opt = adjust_learning_rate(opt, epoch, lr=lr, ds=args.ds)
    D_opt = adjust_learning_rate(D_opt, epoch, lr=lr, ds=args.ds)
        
    for batch_idx, (data, target) in enumerate(train_loader):
        assert(model.training)
        assert(D_model.training)
        assert(Defense.basic_net.training)
        assert(Defense.discriminator.training)

        
        data, target = data.to(device), target.to(device)

        log_dict = dict()

        opt.zero_grad()
        D_opt.zero_grad()

        # Generate Adversarial Examples with Discriminator 
        X_adv, _temp_log = Defense.genadv(inputs=data, targets=target)
        log_dict = merge_dict(log_dict, _temp_log)

        # Train Discriminator 
        loss_d, _temp_log = Defense.get_discriminator_loss(nat_inputs=data, adv_inputs=X_adv, targets=target)
        log_dict = merge_dict(log_dict, _temp_log)

        D_opt.zero_grad()
        opt.zero_grad()
        loss_d.backward(retain_graph=False) 
        D_opt.step()
        
        # Train Generator (=Encoder)
        loss_g, _temp_log = Defense.get_generator_loss(nat_inputs=data, adv_inputs=X_adv, targets=target)
        log_dict = merge_dict(log_dict, _temp_log)

        D_opt.zero_grad()
        opt.zero_grad()
        loss_g.backward(retain_graph=False)
        opt.step()

        # Train Classifier (=Encoder + Linear Classifier)
        loss_ce, _temp_log = Defense.get_classifier_loss(nat_inputs=data, adv_inputs=X_adv, targets=target, beta=args.trades_beta)
        log_dict = merge_dict(log_dict, _temp_log)

        D_opt.zero_grad()
        opt.zero_grad()
        loss_ce.backward(retain_graph=False) 
        opt.step()

        output = model(data)
        output_adv = model(X_adv)
        nat_acc = get_acc(output, target)
        adv_acc = get_acc(output_adv, target)
        
        log_dict['nat_acc'] = nat_acc
        log_dict['adv_acc'] = adv_acc
        log_dict['loss_ce'] = loss_ce

        if batch_idx % log_interval == 0:    
            writestr = [
                ('epoch={}', epoch),
                ('Train_iter={}', epoch*num_batches + batch_idx),
            ]
            
            writestr = '  ,'.join([t.format(v) for (t, v) in writestr]) 
            writestr += '  ,'.join([', {}={:.4f}'.format(k, log_dict[k].item()) for k in log_dict.keys()]) 

            print(writestr)
            for k in log_dict.keys():
                writer.add_scalar(k, log_dict[k].item(), epoch*num_batches + batch_idx)

    nat_acc = test(model, test_loader, device, return_count=False, num_classes=num_classes)
    if epoch % log_period == 0 and epoch > 0:
        adv_acc = adv_test(model, test_loader, device, eval_params, return_count=False, num_classes=num_classes)
        writelog('epoch:{}, nat_acc:{}, adv_acc:{}'.format(epoch, nat_acc, adv_acc), logfile)

        if (nat_acc + adv_acc) >= pre_acc: 
            pre_acc = nat_acc + adv_acc 
            torch.save(model.state_dict(), model_best_dir)
    else: 
        writelog('epoch:{}, nat_acc:{}'.format(epoch, nat_acc), logfile)

    # switch to training mode after evaluation 
    model.train()
    
    writer.add_images('input_img', data[:24], global_step=epoch, dataformats='NCHW')
    writer.add_images('adv_img', X_adv[:24], global_step=epoch, dataformats='NCHW')

    torch.save(model.state_dict(), model_dir)
    torch.save(D_model.state_dict(), D_model_dir)
    
    writer.flush()
writer.close()
print('--- Finish training! ---')


nat_acc = test(model, test_loader, device, return_count=False, num_classes=num_classes)
adv_acc = adv_test(model, test_loader, device, eval_params, return_count=False, num_classes=num_classes)
writelog('epoch:{}, nat_acc:{}, adv_acc:{}'.format(epoch, nat_acc, adv_acc), logfile)

#------------------------------------------------------
model_dir = model_best_dir
model.load_state_dict(torch.load(model_dir))
model.eval()
eval_params = attack_params.copy()
eval_params['num_steps'] = 200
eval_params['epsilon'] = epsilon

#------------------------------------------------------
writelog('----------EVAL STANDARD PGD-200 ----------------', logfile)
writelog('model_dir:{}'.format(model_dir), logfile)
nat_acc = test(model, test_loader, device, return_count=False, num_classes=num_classes)
adv_acc = adv_test(model, test_loader, device, eval_params, return_count=False, num_classes=num_classes)
writelog('epoch:{}, nat_acc:{}, adv_acc:{}'.format(epoch, nat_acc, adv_acc), logfile)

for key in eval_params.keys(): 
    writelog('eval_params, {}:{}'.format(key, eval_params[key]), logfile)
writelog('nat_acc={:.4f}, adv_acc={:.4f}'.format(nat_acc, adv_acc), logfile)
writelog('--------------------------', logfile)

#------------------------------------------------------
D_model.load_state_dict(torch.load(D_model_dir))
D_model.eval()

#------------------------------------------------------
writelog('----------DISCRIMINATOR EVAL STANDARD PGD-200 ----------------', logfile)
writelog('D_model_dir:{}'.format(D_model_dir), logfile)
nat_acc, nat_s_acc, nat_pred_as_count, nat_correct_count, class_count = test_Dis(D_model, test_loader, device, return_count=True, num_classes=num_classes)
adv_acc, adv_s_acc, adv_pred_as_count, adv_correct_count, class_count = adv_test_Dis(D_model, test_loader, device, eval_params, return_count=True, num_classes=num_classes)
writelog('epoch:{}, nat_acc:{}, adv_acc:{}'.format(epoch, nat_acc, adv_acc), logfile)
writelog('epoch:{}, nat_s_acc:{}, adv_s_acc:{}'.format(epoch, nat_s_acc, adv_s_acc), logfile)
writelog('nat_pred_as_count: {}'.format(nat_pred_as_count), logfile)
writelog('nat_correct_count: {}'.format(nat_correct_count), logfile)
writelog('adv_pred_as_count: {}'.format(adv_pred_as_count), logfile)
writelog('adv_correct_count: {}'.format(adv_correct_count), logfile)
writelog('class_count: {}'.format(class_count), logfile)
writelog('--------------------------', logfile)
for key in eval_params.keys(): 
    writelog('eval_params, {}:{}'.format(key, eval_params[key]), logfile)
writelog('nat_acc={:.4f}, adv_acc={:.4f}'.format(nat_acc, adv_acc), logfile)
writelog('nat_s_acc={:.4f}, adv_s_acc={:.4f}'.format(nat_s_acc, adv_s_acc), logfile)