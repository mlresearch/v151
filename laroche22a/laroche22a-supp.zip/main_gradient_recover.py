# authors: anonymous

import numpy as np
import garnets 
import chain
import cliff
import gradient_ascent
import yaml
import pickle
from utils import prt
import proj_simplex

prt('Start of experiment')

def perform_update(theta, learning_rate, parametrization, q, p=2):
    if parametrization == 'softmax':
        # Update the main policy
        exp = np.exp(theta)
        pi = exp / np.sum(exp)
        # True advantage
        adv = q-(pi*q).sum()
        # print(adv)
        # Gradient
        grad = adv*pi
        # Update of parameters
        theta += learning_rate*grad
        # For numerical stability, rescale the thetas.
        theta -= np.max(theta)
    if parametrization == 'ce-softmax':
        # Update the main policy
        exp = np.exp(theta)
        pi = exp / np.sum(exp)
        # target mask
        y = np.zeros(theta.shape)
        y[np.where((q.T==q.max()).T)] = 1
        y /= y.sum()
        # print(adv)
        # Gradient
        grad = y-pi
        # Update of parameters
        theta += learning_rate*grad
        # For numerical stability, rescale the thetas.
        theta -= np.max(theta)
    elif parametrization == 'escort':
        esc = np.abs(theta)**p
        summ = np.sum(esc)
        if np.isnan(summ.sum()):
            fdsjkjl
        pi = esc / summ
        # print(pi)
        # True advantage
        adv = q-(pi*q).sum()
        # print(adv)
        # Gradient (we should normalise by L_p norm, but the learning rate is scaled with its square)
        grad = adv*pi**(1-1/p)
        # print(grad)
        # Update of parameters
        theta += learning_rate*np.linalg.norm(theta,p)*grad
        # print(theta)
        theta = np.abs(theta)
        # print(theta)
    elif parametrization == 'direct':
        # Gradient (instead of dividing d_0(s,a) by pi(s,a) which may cause numerical instability, we use d_0(s) = sum_a d_0(s,a))
        grad = q
        theta += learning_rate*grad
        theta_bis = np.zeros((1, 2))
        theta_bis[0] = theta
        theta = proj_simplex.projection_simplex_sort(theta_bis)[0]
    return theta


def do_n_grad_steps(n, learning_rate, parametrization, p=2):
    theta = 0.5*np.ones(2)
    q = np.ones(2)
    q[1] = 0
    for _ in range(n):
        theta = perform_update(theta, learning_rate, parametrization, q, p)
    return theta

def recover_steps(theta, learning_rate, parametrization, p=2):
    q = np.ones(2)
    q[0] = 0
    count = 0
    while theta[0]>theta[1]:
        theta = perform_update(theta, learning_rate, parametrization, q, p)
        count += 1
    print(theta)
    print(count)
    return count

gamma = 0.99
# r = -1
# alpha = 1.1
# for n in range(1,1000001):
#     r = r*(1+n**(-alpha))
#     print(str(n) + '\t\t' + str(r))

# fdhsjkhk
parametrization = "escort"
p=2
# parametrization = "direct"
# parametrization = "softmax"
# parametrization = "ce-softmax"
learning_rate = 0.01
for n in 2**np.arange(10):
    print(parametrization)
    print('n=' + str(n))
    theta = do_n_grad_steps(n, learning_rate, parametrization, p)
    print(theta)
    print('WAY BACK')
    time = recover_steps(theta, learning_rate, parametrization, p)
