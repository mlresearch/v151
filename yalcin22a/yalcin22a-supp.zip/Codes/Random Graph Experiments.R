rm(list = ls())


install.packages("igraph")
library(igraph)

calculate_obj <-function(X, M_big, mask){
  X_big = X %*% t(X)
  diff = (X_big - M_big) * mask
  obj = sum(diff*diff)
  return(obj)
}

calculate_gradient <-function(X, M_big, mask){
  X_big = X %*% t(X)
  grad = ((X_big - M_big) * mask) %*% X
  return(grad)
}

gradient_algorithm_constant <- function(X, M_big, mask, stepsize){
  i = 0
  while (TRUE) {
    X_big = X %*% t(X)
    
    error = sum(abs(calculate_gradient(X, M_big, mask)))
    
    if (error == Inf) {
      flag = matrix(0, nrow = nrow(X), ncol = ncol(X))
      flag[1,1] = -100
      return(flag)
    }
    if (error < 1e-10){break} 
    
    gradient = calculate_gradient(X, M_big, mask)
    
    a = stepsize
    X_n = X - a * gradient
    i = i+1
    obj = calculate_obj(X_n, M_big, mask)
    #print(c(error, obj))
    X = X_n
  }
  return(X)
}


vertex_size = 20
probability_edge = 0.3
graph <- erdos.renyi.game(vertex_size, probability_edge, type='gnp',
                          directed = FALSE, loops = FALSE)

adj_matrix = as_adjacency_matrix(graph)

omega = matrix(0, ncol = vertex_size, nrow = vertex_size)
for (i in 1:vertex_size) {
  for (j in 1:vertex_size) {
    omega[i,j] = adj_matrix[i,j]
    if(i == j){
      omega[i,j] = 1
    }
  }
}

#Rank-1

is.connected(graph) # Check if true
largest_ivs(graph)[1]

rank = 1
block = vertex_size
mask = omega

ivs_vertices = c(1,3,9,11,12,15,20) #Check the vertices 
M = matrix(0, nrow = vertex_size, ncol = rank)
for (i in 1:length(ivs_vertices)) {
  j = ivs_vertices[i]
  M[j,] = 1
}

c = rank
r = block * rank

M
epsilon = matrix(rnorm(c*r), ncol = c, nrow= r)
norm_epsilon = sqrt(sum(epsilon*epsilon))
n_epsilon = epsilon/norm_epsilon 
n_epsilon

success_percent = c()
epsilon_length= c()
for (i in 1:100){
  spur = 0 
  counter = 0
  while (counter < 100) {
    M_new = M + n_epsilon*(i)/200
    M_big = M_new %*% t(M_new)
    X = matrix(runif(c*r,-10,10), ncol=c, nrow=r)
    stepsize = 0.001
    while(TRUE){
      sp_X = gradient_algorithm_constant(X, M_big, mask, stepsize)
      if(sp_X[1,1] == -100){
        stepsize = stepsize/10
      }else{
        break
      }
    }
    value = calculate_obj(sp_X, M_big, mask)
    if (value > 1e-10){
      #break
      spur = spur +1
    }
    counter = counter +1
    print(c(spur/counter, counter))
  }
  print(i)  
  success_percent[i] = spur/counter
  epsilon_length[i] = (i)/200
}

n_epsilon8 = n_epsilon
data8 = data.frame(epsilon_length, success_percent)
write.csv(n_epsilon8, file = 'perturbation_random_graph_rank1_S7_cs.csv')
write.csv(data8, file= 'convergence_random_graph_rank1_S7_cs.csv')
write.csv(mask, file = 'observation_pattern_random_graph_rank1_S7_cs.csv')
write.csv(ivs_vertices, file = "independent_set_random_graph_rank1_S7_cs.csv")


vertex_size = 20
probability_edge = 0.4
graph <- erdos.renyi.game(vertex_size, probability_edge, type='gnp',
                          directed = FALSE, loops = FALSE)

adj_matrix = as_adjacency_matrix(graph)

omega = matrix(0, ncol = vertex_size, nrow = vertex_size)
for (i in 1:vertex_size) {
  for (j in 1:vertex_size) {
    omega[i,j] = adj_matrix[i,j]
    if(i == j){
      omega[i,j] = 1
    }
  }
}

#Rank-1

is.connected(graph) # Check if true
largest_ivs(graph)[1]

rank = 1
block = vertex_size
mask = omega

ivs_vertices = c(1,8,13,15,19,20) #Check the vertices 
M = matrix(0, nrow = vertex_size, ncol = rank)
for (i in 1:length(ivs_vertices)) {
  j = ivs_vertices[i]
  M[j,] = 1
}

c = rank
r = block * rank

M
epsilon = matrix(rnorm(c*r), ncol = c, nrow= r)
norm_epsilon = sqrt(sum(epsilon*epsilon))
n_epsilon = epsilon/norm_epsilon 
n_epsilon

success_percent_2 = c()
epsilon_length_2 = c()
for (i in 1:100){
  spur = 0 
  counter = 0
  M_new = M + n_epsilon*(i)/200
  M_big = M_new %*% t(M_new)
  while (counter < 100) {
    X = matrix(runif(c*r,-10,10), ncol=c, nrow=r)
    stepsize = 0.001
    while(TRUE){
      sp_X = gradient_algorithm_constant(X, M_big, mask, stepsize)
      if(sp_X[1,1] == -100){
        stepsize = stepsize/10
      }else{
        break
      }
    }
    value = calculate_obj(sp_X, M_big, mask)
    if (value > 1e-10){
      #break
      spur = spur +1
    }
    counter = counter +1
    print(c(spur/counter, counter))
  }
  print(i)  
  success_percent_2[i] = spur/counter
  epsilon_length_2[i] = (i)/200
}

n_epsilon9 = n_epsilon
data9 = data.frame(epsilon_length_2, success_percent_2)
write.csv(n_epsilon9, file = 'perturbation_random_graph_rank1_S6_cs.csv')
write.csv(data9, file= 'convergence_random_graph_rank1_S6_cs.csv')
write.csv(mask, file = 'observation_pattern_random_graph_rank1_S6_cs.csv')
write.csv(ivs_vertices, file = "independent_set_random_graph_rank1_S6_cs.csv")


vertex_size = 20
probability_edge = 0.5
graph <- erdos.renyi.game(vertex_size, probability_edge, type='gnp',
                          directed = FALSE, loops = FALSE)

adj_matrix = as_adjacency_matrix(graph)

omega = matrix(0, ncol = vertex_size, nrow = vertex_size)
for (i in 1:vertex_size) {
  for (j in 1:vertex_size) {
    omega[i,j] = adj_matrix[i,j]
    if(i == j){
      omega[i,j] = 1
    }
  }
}

#Rank-1

is.connected(graph) # Check if true
largest_ivs(graph)[1]

rank = 1
block = vertex_size
mask = omega

ivs_vertices = c(1,2,5,9,19) #Check the vertices 
M = matrix(0, nrow = vertex_size, ncol = rank)
for (i in 1:length(ivs_vertices)) {
  j = ivs_vertices[i]
  M[j,] = 1
}

c = rank
r = block * rank

M
epsilon = matrix(rnorm(c*r), ncol = c, nrow= r)
norm_epsilon = sqrt(sum(epsilon*epsilon))
n_epsilon = epsilon/norm_epsilon 
n_epsilon

success_percent_3 = c()
epsilon_length_3 = c()
for (i in 1:100){
  spur = 0 
  counter = 0
  M_new = M + n_epsilon*(i)/200
  M_big = M_new %*% t(M_new)
  while (counter < 100) {
    X = matrix(runif(c*r,-10,10), ncol=c, nrow=r)
    stepsize = 0.001
    while(TRUE){
      sp_X = gradient_algorithm_constant(X, M_big, mask, stepsize)
      if(sp_X[1,1] == -100){
        stepsize = stepsize/10
      }else{
        break
      }
    }
    value = calculate_obj(sp_X, M_big, mask)
    if (value > 1e-10){
      #break
      spur = spur +1
    }
    counter = counter +1
    print(c(spur/counter, counter))
  }
  print(i)  
  success_percent_3[i] = spur/counter
  epsilon_length_3[i] = (i)/200
}

n_epsilon10 = n_epsilon
data10 = data.frame(epsilon_length_3, success_percent_3)
write.csv(n_epsilon10, file = 'perturbation_random_graph_rank1_S5_cs.csv')
write.csv(data10, file= 'convergence_random_graph_rank1_S5_cs.csv')
write.csv(mask, file = 'observation_pattern_random_graph_rank1_S5_cs.csv')
write.csv(ivs_vertices, file = "independent_set_random_graph_rank1_S5_cs.csv")



vertex_size = 20
probability_edge = 0.7
graph <- erdos.renyi.game(vertex_size, probability_edge, type='gnp',
                          directed = FALSE, loops = FALSE)


adj_matrix = as_adjacency_matrix(graph)

omega = matrix(0, ncol = vertex_size, nrow = vertex_size)
for (i in 1:vertex_size) {
  for (j in 1:vertex_size) {
    omega[i,j] = adj_matrix[i,j]
    if(i == j){
      omega[i,j] = 1
    }
  }
}

#Rank-1

is.connected(graph) # Check if true
largest_ivs(graph)[1]

rank = 1
block = vertex_size
mask = omega

ivs_vertices = c(1,4,13,19) #Check the vertices 
M = matrix(0, nrow = vertex_size, ncol = rank)
for (i in 1:length(ivs_vertices)) {
  j = ivs_vertices[i]
  M[j,] = 1
}

c = rank
r = block * rank

M
epsilon = matrix(rnorm(c*r), ncol = c, nrow= r)
norm_epsilon = sqrt(sum(epsilon*epsilon))
n_epsilon = epsilon/norm_epsilon 
n_epsilon

success_percent_4 = c()
epsilon_length_4 = c()
for (i in 1:100){
  spur = 0 
  counter = 0
  M_new = M + n_epsilon*(i)/200
  M_big = M_new %*% t(M_new)
  while (counter < 100) {
    X = matrix(runif(c*r,-10,10), ncol=c, nrow=r)
    stepsize = 0.001
    while(TRUE){
      sp_X = gradient_algorithm_constant(X, M_big, mask, stepsize)
      if(sp_X[1,1] == -100){
        stepsize = stepsize/10
      }else{
        break
      }
    }
    value = calculate_obj(sp_X, M_big, mask)
    if (value > 1e-10){
      #break
      spur = spur +1
    }
    counter = counter +1
    print(c(spur/counter, counter))
  }
  print(i)  
  success_percent_4[i] = spur/counter
  epsilon_length_4[i] = (i)/200
}

n_epsilon11 = n_epsilon
data11 = data.frame(epsilon_length_4, success_percent_4)
write.csv(n_epsilon11, file = 'perturbation_random_graph_rank1_S4_cs.csv')
write.csv(data11, file= 'convergence_random_graph_rank1_S4_cs.csv')
write.csv(mask, file = 'observation_pattern_random_graph_rank1_S4_cs.csv')
write.csv(ivs_vertices, file = "independent_set_random_graph_rank1_S4_cs.csv")

vertex_size = 20
probability_edge = 0.8
graph <- erdos.renyi.game(vertex_size, probability_edge, type='gnp',
                          directed = FALSE, loops = FALSE)


adj_matrix = as_adjacency_matrix(graph)

omega = matrix(0, ncol = vertex_size, nrow = vertex_size)
for (i in 1:vertex_size) {
  for (j in 1:vertex_size) {
    omega[i,j] = adj_matrix[i,j]
    if(i == j){
      omega[i,j] = 1
    }
  }
}

#Rank-1

is.connected(graph) # Check if true
largest_ivs(graph)[1]

rank = 1
block = vertex_size
mask = omega

ivs_vertices = c(1,8,11) #Check the vertices 
M = matrix(0, nrow = vertex_size, ncol = rank)
for (i in 1:length(ivs_vertices)) {
  j = ivs_vertices[i]
  M[j,] = 1
}

c = rank
r = block * rank

M
epsilon = matrix(rnorm(c*r), ncol = c, nrow= r)
norm_epsilon = sqrt(sum(epsilon*epsilon))
n_epsilon = epsilon/norm_epsilon 
n_epsilon

success_percent_5 = c()
epsilon_length_5 = c()
for (i in 1:100){
  spur = 0 
  counter = 0
  M_new = M + n_epsilon*(i)/200
  M_big = M_new %*% t(M_new)
  while (counter < 100) {
    X = matrix(runif(c*r,-10,10), ncol=c, nrow=r)
    stepsize = 0.001
    while(TRUE){
      sp_X = gradient_algorithm_constant(X, M_big, mask, stepsize)
      if(sp_X[1,1] == -100){
        stepsize = stepsize/10
      }else{
        break
      }
    }
    value = calculate_obj(sp_X, M_big, mask)
    if (value > 1e-10){
      #break
      spur = spur +1
    }
    counter = counter +1
    print(c(spur/counter, counter))
  }
  print(i)  
  success_percent_5[i] = spur/counter
  epsilon_length_5[i] = (i)/200
}

n_epsilon12 = n_epsilon
data12 = data.frame(epsilon_length_5, success_percent_5)
write.csv(n_epsilon12, file = 'perturbation_random_graph_rank1_S3_cs.csv')
write.csv(data12, file= 'convergence_random_graph_rank1_S3_cs.csv')
write.csv(mask, file = 'observation_pattern_random_graph_rank1_S3_cs.csv')
write.csv(ivs_vertices, file = "independent_set_random_graph_rank1_S3_cs.csv")

vertex_size = 20
probability_edge = 0.95
graph <- erdos.renyi.game(vertex_size, probability_edge, type='gnp',
                          directed = FALSE, loops = FALSE)


adj_matrix = as_adjacency_matrix(graph)

omega = matrix(0, ncol = vertex_size, nrow = vertex_size)
for (i in 1:vertex_size) {
  for (j in 1:vertex_size) {
    omega[i,j] = adj_matrix[i,j]
    if(i == j){
      omega[i,j] = 1
    }
  }
}

#Rank-1

is.connected(graph) # Check if true
largest_ivs(graph)[1]

rank = 1
block = vertex_size
mask = omega

ivs_vertices = c(2,10) #Check the vertices 
M = matrix(0, nrow = vertex_size, ncol = rank)
for (i in 1:length(ivs_vertices)) {
  j = ivs_vertices[i]
  M[j,] = 1
}

c = rank
r = block * rank

M
epsilon = matrix(rnorm(c*r), ncol = c, nrow= r)
norm_epsilon = sqrt(sum(epsilon*epsilon))
n_epsilon = epsilon/norm_epsilon 
n_epsilon

success_percent_6 = c()
epsilon_length_6 = c()
for (i in 1:100){
  spur = 0 
  counter = 0
  M_new = M + n_epsilon*(i)/200
  M_big = M_new %*% t(M_new)
  while (counter < 100) {
    X = matrix(runif(c*r,-10,10), ncol=c, nrow=r)
    stepsize = 0.001
    while(TRUE){
      sp_X = gradient_algorithm_constant(X, M_big, mask, stepsize)
      if(sp_X[1,1] == -100){
        stepsize = stepsize/10
      }else{
        break
      }
    }
    value = calculate_obj(sp_X, M_big, mask)
    if (value > 1e-10){
      #break
      spur = spur +1
    }
    counter = counter +1
    print(c(spur/counter, counter))
  }
  print(i)  
  success_percent_6[i] = spur/counter
  epsilon_length_6[i] = (i)/200
}

n_epsilon13 = n_epsilon
data13 = data.frame(epsilon_length_6, success_percent_6)
write.csv(n_epsilon13, file = 'perturbation_random_graph_rank1_S2_cs.csv')
write.csv(data13, file= 'convergence_random_graph_rank1_S2_cs.csv')
write.csv(mask, file = 'observation_pattern_random_graph_rank1_S2_cs.csv')
write.csv(ivs_vertices, file = "independent_set_random_graph_rank1_S2_cs.csv")

