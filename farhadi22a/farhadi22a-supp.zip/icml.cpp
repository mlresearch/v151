#include <iostream>
#include <vector>
#include <set>
#include <queue>
#include <random>

#include <thread>


using namespace std;

const int MN=1000*1000,MM=1000*1000*100;

const int tno=8;

const int repeat=100;

double _eps=1e-6;

vector<double> ec={0.1,0.2,0.5,1,2,3.5,5};

int n,m;
vector<int> list[MN];

random_device seedgen[tno]; 
mt19937 gen[tno];
uniform_real_distribution<> dis[tno];
double random(int no)
{
	return dis[no](gen[no]);
}

double exp_sample(double scale,int no)
{
	return -scale*log(random(no));
}

double random(double scale,int no)
{
	double e1=exp_sample(scale,no),e2=exp_sample(scale,no);
	return e1-e2;
}

class prefix_sum
{
	public:
		prefix_sum(double _eps,int _no)
		{
			no=_no;
			eps=_eps;
		}
		int no;
		double eps=0;
		double sum=0,sumerr=0;
		vector<pair<int,double> > errs;
		void add(double v)
		{
			sum+=v;
			errs.push_back({1,random(log(n)/eps,no)});
			while (errs.size()>1 && errs[errs.size()-1].first==errs[errs.size()-2].first)
			{
				int t=errs[errs.size()-1].first;
				errs.pop_back();
				errs.pop_back();
				errs.push_back({2*t,random(log(n)/eps,no)});
			}
			sumerr=0;
			for (auto & x:errs) sumerr+=x.second;
		}
		double get()
		{
			return sum+sumerr;
		}
};
double deg[tno][MN];
vector<prefix_sum> ps[tno];
bool mark[tno][MN];
int cnt[tno][MN];
double noise[tno][MN];
double dsp_dp(double eps,int no)
{
	double te=m;
	double delta=1;
	for (int i=0;i<6;i++)
		delta/=10;
	for (int i=0;i<n;i++) deg[no][i]=list[i].size(),mark[no][i]=0;
	double ep=eps/(4*log(exp(1)/delta));
	vector<double> rho;
	for (int i=0;i<n;i++)
	{
		double sum=0;
		for (int j=0;j<n;j++) if (!mark[no][j])
			sum+=exp(-ep*deg[no][j]);
		double r=random(no)*sum;
		int v=-1;
		for (int j=0;j<n;j++) if (!mark[no][j])
		{
			r-=exp(-ep*deg[no][j]);
			if (r<=1e-6)
			{
				v=j;
				break;
			}
		}
		rho.push_back(double(te)/(n-i));

		mark[no][v]=true;
		for (auto & x:list[v]) if (!mark[no][x])
		{
			te--;
			deg[no][x]--;
		}
	}
	double sum=0;
	for (auto & x:rho)
		sum+=exp(eps*x/2);
	double r=random(no)*sum;
	for (auto & x:rho)
	{
		r-=exp(eps*x/2);
		if (r<=1e-6)
			return x;
	}
	return 0;
}


double thread_answer[tno+10];

void dsp_dp_thread(double eps, int no)
{
	double res=0;
	for (int i=no;i<repeat;i+=tno) res+=dsp_dp(eps,no);
	thread_answer[no]=res;
}

double _tme;
double dsp_dp_multiple(double eps)
{
	_tme=time(0);	
	vector<thread> trds;
	for (int i=0;i<tno;i++)
		trds.push_back(thread(dsp_dp_thread,eps,i));
	for (auto & x:trds) x.join();
	double res=0;
	for (int i=0;i<tno;i++) res+=thread_answer[i];
	_tme=time(0)-_tme;
	
	return res/repeat;
}

int c_deg[MN];
bool c_mark[MN];


double dsp_charikar()
{
	for (int i=0;i<n;i++) c_deg[i]=list[i].size(),c_mark[i]=0;
	int te=m;
	double dmax=0, sol=0;
	for (int i=0;i<n;i++)
	{
		double mn=1e20; int v=-1;
		for (int j=0;j<n;j++) if (!c_mark[j] && c_deg[j]<mn)
			mn=c_deg[j],v=j;
		c_mark[v]=true;
		sol=max(sol,min(double(n-i-1)/2,double(te)/(n-i)));
		for (auto & x:list[v]) if (!c_mark[x])
		{
			te--;
			c_deg[x]--;
		}
	}
	return sol;

}

set<pair<int,int>> emark;
int main() 
{

	for (int i=0;i<tno;i++)
	{
		gen[i]=mt19937(seedgen[i]());
		dis[i]=uniform_real_distribution<> (0,1);
	}
	cin>>n>>m;
	for (int i=0;i<m;i++)
	{
		int a,b;
		cin>>a>>b; a--; b--;
		if (emark.find({a,b})!=emark.end() || a==b)
			cout<<"Bad input!"<<endl;
		emark.insert({a,b});
		emark.insert({b,a});
		list[a].push_back(b);
		list[b].push_back(a);
	}
	double _=dsp_charikar();
	cout<<"Exact: "<<_<<endl;
	for (double eps:ec)
	{
		cout<<"Epsilon: "<<eps<<", res: "<<dsp_dp_multiple(eps)<<endl;
		cout<<"Time: "<<_tme<<endl;
		
	}

	return 0;
}
