from typing import List
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from decomp_gen.models.decomp_tree_encoder import TreeEncoder
from decomp_gen.models.gat import GAT
from decomp_gen.models.mlp import Mlp
from decomp_gen.models.nnutils import graphs_batch_offsets

from dgl import batch
from dgl import DGLGraph

NUM_HEADS = 1
MLP_HIDDEN_SIZES = [200, 100, 50, 20]

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

class NodeSharing_Simple(nn.Module):
    def __init__(self,
                 max_cluster_size,
                 max_graph_size,
                 tree_hidden_dim,
                 gat_hidden_dim,
                 gat_num_layers,
                 node_feat_dim,
                 mlp_hidden_dim
                 ):
        super(NodeSharing_Simple, self).__init__()

        self.C = max_cluster_size
        self.N = max_graph_size  # max number of nodes
        self.tree_hidden_dim = tree_hidden_dim
        self.gat_hidden_dim = gat_hidden_dim
        self.gat_num_layers = gat_num_layers
        self.node_feat_dim = node_feat_dim

        self.tree_encoder = TreeEncoder(self.tree_hidden_dim, self.N)


        # This only applies to a single node at a time (not the entire A)
        self.dimension_reductor = nn.Linear(self.N, self.node_feat_dim)

        self.gat = GAT(
            num_layers=self.gat_num_layers,
            in_dim=self.node_feat_dim,
            num_hidden=self.gat_hidden_dim,
            num_output=self.gat_hidden_dim,
            heads=[NUM_HEADS] * self.gat_num_layers,
            activation=F.elu,
            feat_drop=0,
            attn_drop=0,
            negative_slope=0.2,
            residual=False
        )

        self.mlp_input_size = self.gat_hidden_dim + 2 * self.tree_hidden_dim + self.C
        # self.mlp = Mlp(input_size=self.mlp_input_size, output_size=1, hidden_sizes=MLP_HIDDEN_SIZES)
        self.mlp = nn.Sequential(
                nn.Linear(self.mlp_input_size, mlp_hidden_dim),
                nn.ReLU(),
                nn.Linear(mlp_hidden_dim, 1),
                nn.Sigmoid())

    def forward(self, graphs: List[DGLGraph], trees: List[DGLGraph],
                cluster_nodes_idx: List[np.array],
                super_node_idx: List[np.array], samples_per_tree: np.array,
                masked_shared: torch.Tensor):
        """
        Args:
            graphs: batch of DGL graphs (tensorized graph] of dimension:
              [B x (features of nodes, adjacency matrix=n, etc.)]
            trees: decomposition trees
              []
            cluster_nodes_idx: list of np arrays, each np arrays contains the
              indices of the nodes in parent cluster
            super_node_idx: A list of np arrays, each np array shows for the corresponding tree
              what is the supernode index we want to make node sharing with
            samples_per_tree: np array containing number of decisions for each tree

            masked_shareds: list of tensors. Each tensor is masked sharing for causal
              sharing results related to one of main graphs
        """
        for i, g in enumerate(graphs):
            graphs[i] = g.to(device)

        for i, tree in enumerate(trees):
            trees[i] = tree.to(device)

        # masked_shared = masked_shared.to(device)

        # g.ndata['a']: adjacency matrix of the graph --> MxN, where N is the max size, and
        # M is the actual number of nodes. We will interpret M as the size of batch
        # If so, M can now be variable.

        # dgl library concatenates all the ndata['a'] of each graph into a single big tensor

        graphs_batch = batch(graphs)

        input_features = self.dimension_reductor(graphs_batch.ndata['a'])
        # output size: sum(M_i) x self.node_feat_dim, where i=0..len(graphs)

        graph_encoded = self.gat(graphs_batch, input_features)
        # output size: sum(M_i) x GAT.num_outputs, where i=0..len(graphs)
        graphs_node_offset = graphs_batch_offsets(graphs_batch)

        for i, c in enumerate(cluster_nodes_idx):
            cluster_nodes_idx[i] = c + graphs_node_offset[i]
        cluster_nodes_idx = np.concatenate(cluster_nodes_idx)
        node_encodings = graph_encoded[cluster_nodes_idx]

        # DecompTreeEncoder batches the given list of trees in its forward method
        roots_encode, tree_batch = self.tree_encoder(trees)

        tree_encodings = []
        for i in range(roots_encode.shape[0]):
            tree_encodings.append(roots_encode[i].repeat(samples_per_tree[i]))
        tree_encodings = torch.cat(tree_encodings, dim=0)
        tree_encodings = tree_encodings.view(-1, self.tree_hidden_dim)

        trees_node_offset = graphs_batch_offsets(tree_batch)
        for i, sid in enumerate(super_node_idx):
            super_node_idx[i] = sid + trees_node_offset[i]
        super_node_idx = np.concatenate(super_node_idx)
        super_node_encodings = tree_batch.ndata['h'][super_node_idx]

        # last_cluster_idx: size = sum(M_i) x self.C (max cluster size)
        last_cluster_idx = graphs_batch.ndata['last_cluster_idx'][cluster_nodes_idx]

        concatenated_feat = torch.cat(
            [node_encodings, tree_encodings, super_node_encodings, last_cluster_idx]
            , dim=1
        )

        probs = self.mlp(concatenated_feat)
        return probs

class NodeSharing(nn.Module):
    def __init__(self,
                 max_cluster_size,
                 max_graph_size,
                 tree_hidden_dim,
                 gat_hidden_dim,
                 gat_num_layers,
                 node_feat_dim,
                 mlp_hidden_dim
                 ):
        super(NodeSharing, self).__init__()

        self.C = max_cluster_size
        self.N = max_graph_size  # max number of nodes
        self.tree_hidden_dim = tree_hidden_dim
        self.gat_hidden_dim = gat_hidden_dim
        self.gat_num_layers = gat_num_layers
        self.node_feat_dim = node_feat_dim

        self.tree_encoder = TreeEncoder(self.tree_hidden_dim, self.N)

        # This only applies to a single node at a time (not the entire A)
        self.dimension_reductor = nn.Linear(self.N, self.node_feat_dim)

        self.gat = GAT(
            num_layers=self.gat_num_layers,
            in_dim=self.node_feat_dim,
            num_hidden=self.gat_hidden_dim,
            num_output=self.gat_hidden_dim,
            heads=[NUM_HEADS] * self.gat_num_layers,
            activation=F.elu,
            feat_drop=0,
            attn_drop=0,
            negative_slope=0.2,
            residual=False
        )

        self.mlp_input_size = self.gat_hidden_dim + 2 * self.tree_hidden_dim + 2 * self.C
        self.mlp = nn.Sequential(
                nn.Linear(self.mlp_input_size, mlp_hidden_dim),
                nn.ReLU(),
                nn.Linear(mlp_hidden_dim, mlp_hidden_dim//2),
                nn.ReLU(),
                nn.Linear(mlp_hidden_dim//2,1),
                nn.Sigmoid())

    def forward(self, graphs: List[DGLGraph], trees: List[DGLGraph],
                cluster_nodes_idx: List[np.array],
                super_node_idx: List[np.array], samples_per_tree: np.array,
                masked_shared: torch.Tensor):
        """
        Args:
            graphs: batch of DGL graphs (tensorized graph] of dimension:
              [B x (features of nodes, adjacency matrix=n, etc.)]
            trees: decomposition trees
              []
            cluster_nodes_idx: list of np arrays, each np arrays contains the
              indices of the nodes in parent cluster
            super_node_idx: A list of np arrays, each np array shows for the corresponding tree
              what is the supernode index we want to make node sharing with
            samples_per_tree: np array containing number of decisions for each tree

            masked_shareds: list of tensors. Each tensor is masked sharing for causal
              sharing results related to one of main graphs
        """
        for i, g in enumerate(graphs):
            graphs[i] = g.to(device)

        for i, tree in enumerate(trees):
            trees[i] = tree.to(device)

        masked_shared = masked_shared.to(device)
        graphs_batch = batch(graphs)

        input_features = self.dimension_reductor(graphs_batch.ndata['a'])
        graph_encoded = self.gat(graphs_batch, input_features)
        graphs_node_offset = graphs_batch_offsets(graphs_batch)

        for i, c in enumerate(cluster_nodes_idx):
            cluster_nodes_idx[i] = c + graphs_node_offset[i]
        cluster_nodes_idx = np.concatenate(cluster_nodes_idx)
        node_encodings = graph_encoded[cluster_nodes_idx]

        # DecompTreeEncoder batches the given list of trees in its forward method
        roots_encode, tree_batch = self.tree_encoder(trees)

        tree_encodings = []
        for i in range(roots_encode.shape[0]):
            tree_encodings.append(roots_encode[i].repeat(samples_per_tree[i]))
        tree_encodings = torch.cat(tree_encodings, dim=0)
        tree_encodings = tree_encodings.view(-1, self.tree_hidden_dim)

        trees_node_offset = graphs_batch_offsets(tree_batch)
        for i, sid in enumerate(super_node_idx):
            super_node_idx[i] = sid + trees_node_offset[i]
        super_node_idx = np.concatenate(super_node_idx)
        super_node_encodings = tree_batch.ndata['h'][super_node_idx]

        # last_cluster_idx: size = sum(M_i) x self.C (max cluster size)
        last_cluster_idx = graphs_batch.ndata['last_cluster_idx'][cluster_nodes_idx]

        concatenated_feat = torch.cat(
            [node_encodings, tree_encodings, super_node_encodings, last_cluster_idx, masked_shared]
            , dim=1
        )

        probs = self.mlp(concatenated_feat)
        return probs


class NodeSharing_v2(nn.Module):
    def __init__(self,
                 max_cluster_size,
                 max_graph_size,
                 tree_hidden_dim,
                 gat_hidden_dim,
                 gat_num_layers,
                 node_feat_dim,
                 mlp_hidden_dim
                 ):
        super(NodeSharing, self).__init__()

        self.C = max_cluster_size
        self.N = max_graph_size  # max number of nodes
        self.tree_hidden_dim = tree_hidden_dim
        self.gat_hidden_dim = gat_hidden_dim
        self.gat_num_layers = gat_num_layers
        self.node_feat_dim = node_feat_dim

        self.tree_encoder = TreeEncoder(self.tree_hidden_dim, self.N)


        # This only applies to a single node at a time (not the entire A)
        self.dimension_reductor = nn.Linear(self.N, self.node_feat_dim)

        self.gat = GAT(
            num_layers=self.gat_num_layers,
            in_dim=self.node_feat_dim + self.C,
            num_hidden=self.gat_hidden_dim + self.C,
            num_output=self.gat_hidden_dim + self.C,
            heads=[NUM_HEADS] * self.gat_num_layers,
            activation=F.elu,
            feat_drop=0,
            attn_drop=0,
            negative_slope=0.2,
            residual=False
        )

        self.mlp_input_size = self.gat_hidden_dim + 2 * self.tree_hidden_dim + 2 * self.C
        # self.mlp = Mlp(input_size=self.mlp_input_size, output_size=1, hidden_sizes=MLP_HIDDEN_SIZES)
        self.mlp = nn.Sequential(
                nn.Linear(self.mlp_input_size, mlp_hidden_dim),
                nn.ReLU(),
                nn.Linear(mlp_hidden_dim, mlp_hidden_dim//2),
                nn.ReLU(),
                nn.Linear(mlp_hidden_dim//2,1),
                nn.Sigmoid())

    def forward(self, graphs: List[DGLGraph], trees: List[DGLGraph],
                cluster_nodes_idx: List[np.array],
                super_node_idx: List[np.array], samples_per_tree: np.array,
                masked_shared: torch.Tensor):
        """
        Args:
            graphs: batch of DGL graphs (tensorized graph] of dimension:
              [B x (features of nodes, adjacency matrix=n, etc.)]
            trees: decomposition trees
              []
            cluster_nodes_idx: list of np arrays, each np arrays contains the
              indices of the nodes in parent cluster
            super_node_idx: A list of np arrays, each np array shows for the corresponding tree
              what is the supernode index we want to make node sharing with
            samples_per_tree: np array containing number of decisions for each tree

            masked_shareds: list of tensors. Each tensor is masked sharing for causal
              sharing results related to one of main graphs
        """
        for i, g in enumerate(graphs):
            graphs[i] = g.to(device)

        for i, tree in enumerate(trees):
            trees[i] = tree.to(device)

        masked_shared = masked_shared.to(device)

        # g.ndata['a']: adjacency matrix of the graph --> MxN, where N is the max size, and
        # M is the actual number of nodes. We will interpret M as the size of batch
        # If so, M can now be variable.

        # dgl library concatenates all the ndata['a'] of each graph into a single big tensor

        graphs_batch = batch(graphs)

        input_features = torch.cat([self.dimension_reductor(graphs_batch.ndata['a']),
                                   graphs_batch.ndata['last_cluster_idx']], dim=1)
        # output size: sum(M_i) x self.node_feat_dim, where i=0..len(graphs)

        graph_encoded = self.gat(graphs_batch, input_features)
        # output size: sum(M_i) x GAT.num_outputs, where i=0..len(graphs)
        graphs_node_offset = graphs_batch_offsets(graphs_batch)

        for i, c in enumerate(cluster_nodes_idx):
            cluster_nodes_idx[i] = c + graphs_node_offset[i]
        cluster_nodes_idx = np.concatenate(cluster_nodes_idx)

        node_encodings = graph_encoded[cluster_nodes_idx]

        # DecompTreeEncoder batches the given list of trees in its forward method
        roots_encode, tree_batch = self.tree_encoder(trees)

        tree_encodings = []
        for i in range(roots_encode.shape[0]):
            tree_encodings.append(roots_encode[i].repeat(samples_per_tree[i]))
        tree_encodings = torch.cat(tree_encodings, dim=0)
        tree_encodings = tree_encodings.view(-1, self.tree_hidden_dim)

        trees_node_offset = graphs_batch_offsets(tree_batch)
        for i, sid in enumerate(super_node_idx):
            super_node_idx[i] = sid + trees_node_offset[i]
        super_node_idx = np.concatenate(super_node_idx)
        super_node_encodings = tree_batch.ndata['h'][super_node_idx]

        # last_cluster_idx: size = sum(M_i) x self.C (max cluster size)
        last_cluster_idx = graphs_batch.ndata['last_cluster_idx'][cluster_nodes_idx]

        # multi hot encoding of which nodes are shared. A tensor of dimension
        # masked_shared = torch.cat(masked_shareds, dim=0)

        concatenated_feat = torch.cat(
            [node_encodings, tree_encodings, super_node_encodings, last_cluster_idx, masked_shared]
            , dim=1
        )

        probs = self.mlp(concatenated_feat)

        return probs

class NodeSharing_old(nn.Module):
    def __init__(self,
                 max_cluster_size,
                 max_graph_size,
                 tree_hidden_dim,
                 gat_hidden_dim,
                 gat_num_layers,
                 node_feat_dim,
                 mlp_hidden_dim
                 ):
        super(NodeSharing_old, self).__init__()

        self.C = max_cluster_size
        self.N = max_graph_size  # max number of nodes
        self.tree_hidden_dim = tree_hidden_dim
        self.gat_hidden_dim = gat_hidden_dim
        self.gat_num_layers = gat_num_layers
        self.node_feat_dim = node_feat_dim

        self.tree_encoder = TreeEncoder(self.tree_hidden_dim, self.N)


        # This only applies to a single node at a time (not the entire A)
        self.dimension_reductor = nn.Linear(self.N, self.node_feat_dim)

        self.gat = GAT(
            num_layers=self.gat_num_layers,
            in_dim=self.node_feat_dim,
            num_hidden=self.gat_hidden_dim,
            num_output=self.gat_hidden_dim,
            heads=[NUM_HEADS] * self.gat_num_layers,
            activation=F.elu,
            feat_drop=0,
            attn_drop=0,
            negative_slope=0.2,
            residual=False
        )

        self.mlp_input_size = self.gat_hidden_dim + 2 * self.tree_hidden_dim + 2 * self.C
        # self.mlp = Mlp(input_size=self.mlp_input_size, output_size=1, hidden_sizes=MLP_HIDDEN_SIZES)
        self.mlp = nn.Sequential(
                nn.Linear(self.mlp_input_size, mlp_hidden_dim),
                nn.ReLU(),
                nn.Linear(mlp_hidden_dim, mlp_hidden_dim//2),
                nn.ReLU(),
                nn.Linear(mlp_hidden_dim//2,1),
                nn.Sigmoid())

    def forward(self, graphs: List[DGLGraph], trees: List[DGLGraph],
                cluster_nodes_idx: List[np.array],
                super_node_idx: List[np.array], samples_per_tree: np.array,
                masked_shared: torch.Tensor):
        """
        Args:
            graphs: batch of DGL graphs (tensorized graph] of dimension:
              [B x (features of nodes, adjacency matrix=n, etc.)]
            trees: decomposition trees
              []
            cluster_nodes_idx: list of np arrays, each np arrays contains the
              indices of the nodes in parent cluster
            super_node_idx: A list of np arrays, each np array shows for the corresponding tree
              what is the supernode index we want to make node sharing with
            samples_per_tree: np array containing number of decisions for each tree

            masked_shareds: list of tensors. Each tensor is masked sharing for causal
              sharing results related to one of main graphs
        """
        for i, g in enumerate(graphs):
            graphs[i] = g.to(device)

        for i, tree in enumerate(trees):
            trees[i] = tree.to(device)

        masked_shared = masked_shared.to(device)

        # g.ndata['a']: adjacency matrix of the graph --> MxN, where N is the max size, and
        # M is the actual number of nodes. We will interpret M as the size of batch
        # If so, M can now be variable.

        # dgl library concatenates all the ndata['a'] of each graph into a single big tensor

        graphs_batch = batch(graphs)

        input_features = self.dimension_reductor(graphs_batch.ndata['a'])
        # output size: sum(M_i) x self.node_feat_dim, where i=0..len(graphs)

        graph_encoded = self.gat(graphs_batch, input_features)
        # output size: sum(M_i) x GAT.num_outputs, where i=0..len(graphs)
        graphs_node_offset = graphs_batch_offsets(graphs_batch)

        for i, c in enumerate(cluster_nodes_idx):
            cluster_nodes_idx[i] = c + graphs_node_offset[i]
        cluster_nodes_idx = np.concatenate(cluster_nodes_idx)

        node_encodings = graph_encoded[cluster_nodes_idx]

        # DecompTreeEncoder batches the given list of trees in its forward method
        roots_encode, tree_batch = self.tree_encoder(trees)

        tree_encodings = []
        for i in range(roots_encode.shape[0]):
            tree_encodings.append(roots_encode[i].repeat(samples_per_tree[i]))
        tree_encodings = torch.cat(tree_encodings, dim=0)
        tree_encodings = tree_encodings.view(-1, self.tree_hidden_dim)

        trees_node_offset = graphs_batch_offsets(tree_batch)
        for i, sid in enumerate(super_node_idx):
            super_node_idx[i] = sid + trees_node_offset[i]
        super_node_idx = np.concatenate(super_node_idx)
        super_node_encodings = tree_batch.ndata['h'][super_node_idx]

        # last_cluster_idx: size = sum(M_i) x self.C (max cluster size)
        last_cluster_idx = graphs_batch.ndata['last_cluster_idx'][cluster_nodes_idx]

        # multi hot encoding of which nodes are shared. A tensor of dimension
        # masked_shared = torch.cat(masked_shareds, dim=0)

        concatenated_feat = torch.cat(
            [node_encodings, tree_encodings, super_node_encodings, last_cluster_idx, masked_shared]
            , dim=1
        )

        probs = self.mlp(concatenated_feat)

        return probs


class NodeSharing_Without_Tree_Encoding(nn.Module):
    def __init__(self,
                 max_cluster_size,
                 max_graph_size,
                 tree_hidden_dim,
                 gat_hidden_dim,
                 gat_num_layers,
                 node_feat_dim,
                 mlp_hidden_dim
                 ):
        super(NodeSharing_Without_Tree_Encoding, self).__init__()

        self.C = max_cluster_size
        self.N = max_graph_size  # max number of nodes
        # self.tree_hidden_dim = tree_hidden_dim
        self.gat_hidden_dim = gat_hidden_dim
        self.gat_num_layers = gat_num_layers
        self.node_feat_dim = node_feat_dim

        # self.tree_encoder = TreeEncoder(self.tree_hidden_dim, self.N)

        # This only applies to a single node at a time (not the entire A)
        self.dimension_reductor = nn.Linear(self.N, self.node_feat_dim)

        self.gat = GAT(
            num_layers=self.gat_num_layers,
            in_dim=self.node_feat_dim,
            num_hidden=self.gat_hidden_dim,
            num_output=self.gat_hidden_dim,
            heads=[NUM_HEADS] * self.gat_num_layers,
            activation=F.elu,
            feat_drop=0,
            attn_drop=0,
            negative_slope=0.2,
            residual=False
        )

        self.mlp_input_size = self.gat_hidden_dim + 2 * self.C
        self.mlp = nn.Sequential(
                nn.Linear(self.mlp_input_size, mlp_hidden_dim),
                nn.ReLU(),
                nn.Linear(mlp_hidden_dim, mlp_hidden_dim//2),
                nn.ReLU(),
                nn.Linear(mlp_hidden_dim//2,1),
                nn.Sigmoid())

    def forward(self, graphs: List[DGLGraph], trees: List[DGLGraph],
                cluster_nodes_idx: List[np.array],
                super_node_idx: List[np.array], samples_per_tree: np.array,
                masked_shared: torch.Tensor):
        """
        Args:
            graphs: batch of DGL graphs (tensorized graph] of dimension:
              [B x (features of nodes, adjacency matrix=n, etc.)]
            trees: decomposition trees
              []
            cluster_nodes_idx: list of np arrays, each np arrays contains the
              indices of the nodes in parent cluster
            super_node_idx: A list of np arrays, each np array shows for the corresponding tree
              what is the supernode index we want to make node sharing with
            samples_per_tree: np array containing number of decisions for each tree

            masked_shareds: list of tensors. Each tensor is masked sharing for causal
              sharing results related to one of main graphs
        """
        for i, g in enumerate(graphs):
            graphs[i] = g.to(device)

        masked_shared = masked_shared.to(device)
        graphs_batch = batch(graphs)

        input_features = self.dimension_reductor(graphs_batch.ndata['a'])
        graph_encoded = self.gat(graphs_batch, input_features)
        graphs_node_offset = graphs_batch_offsets(graphs_batch)

        for i, c in enumerate(cluster_nodes_idx):
            cluster_nodes_idx[i] = c + graphs_node_offset[i]
        cluster_nodes_idx = np.concatenate(cluster_nodes_idx)
        node_encodings = graph_encoded[cluster_nodes_idx]

       # last_cluster_idx: size = sum(M_i) x self.C (max cluster size)
        last_cluster_idx = graphs_batch.ndata['last_cluster_idx'][cluster_nodes_idx]

        concatenated_feat = torch.cat(
            [node_encodings, last_cluster_idx, masked_shared]
            , dim=1
        )

        probs = self.mlp(concatenated_feat)
        return probs
