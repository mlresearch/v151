import torch
from torch.autograd import Variable
import numpy as np
import torch.nn.functional as F
import torchvision
from torchvision import transforms
from torchvision.utils import make_grid, save_image
# from torch.utils.tensorboard import SummaryWriter

from tensorboardX import SummaryWriter
from math import log

import torch.optim as optim
from torch import nn
from torch.utils.data import TensorDataset, DataLoader, Dataset

import torch.distributions as tdists

from tqdm import tqdm

from pathlib import Path
import argparse
import os
import math

from scipy import linalg
import matplotlib.pyplot as plt
import matplotlib as mpl
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.colors import LogNorm



import zipfile

from torch.utils.data import Dataset


import os.path
from torch.utils.data import DataLoader
import torchvision
from torchvision import transforms
import requests
import zipfile
import cv2
import glob

# plt.ioff()
from argparse import Namespace 
import pickle
from tqdm.notebook import tqdm
from scipy.io import savemat


def create_dir_with_index(path):
    made = False
    counter = 1
    while made == False:
        if not os.path.exists(path):
            os.makedirs(path)
            made = True
            return path
        else:
            new_path = path + '_' + str(counter)
            if not os.path.exists(new_path):
                os.makedirs(new_path)
                made = True
                return new_path
            else:
                counter += 1


class VAE(torch.nn.Module):
    def __init__(self,
                 input_dim=1,
                 latent_dim=1,
                 post_sig=0,
                 data_sig=np.sqrt(0.1),
                 dataset_size=1000,
                 beta=1,
                 hidden_dim=256,
                 tcvae=True):
        super(VAE, self).__init__()
        self.beta=beta
        self.tcvae = tcvae
        self.latent_dim = latent_dim
        self.input_dim = input_dim
        self.post_sig = post_sig
        self._enc_mu = torch.nn.Sequential(
            torch.nn.Linear(input_dim, hidden_dim, bias=True),
            torch.nn.Sigmoid(),
            torch.nn.Linear(hidden_dim, hidden_dim, bias=True),
            torch.nn.Sigmoid(),
            torch.nn.Linear(hidden_dim, latent_dim, bias=True))
        self._dec = torch.nn.Sequential(
            torch.nn.Linear(latent_dim, hidden_dim, bias=True),
            torch.nn.Sigmoid(),
            torch.nn.Linear(hidden_dim, hidden_dim, bias=True),
            torch.nn.Sigmoid(),
            torch.nn.Linear(hidden_dim, input_dim, bias=True))
            
        if post_sig == 0:
            self._enc_log_sigma = torch.nn.Sequential(
                torch.nn.Linear(input_dim, hidden_dim, bias=True),
                torch.nn.Sigmoid(),
                torch.nn.Linear(hidden_dim, hidden_dim, bias=True),
                torch.nn.Sigmoid(),
                torch.nn.Linear(hidden_dim, latent_dim, bias=True))

        self.dim_s = latent_dim
        self.data_sig = data_sig
        self.dataset_size = dataset_size
        self.prior = tdists.Normal(torch.zeros(self.dim_s, ),torch.ones(self.dim_s,))

    def _sample_latent(self, x_in):
        """
        Return the latent normal sample z ~ N(mu, sigma^2)
        """

        self.z_loc = self._enc_mu(x_in)

        if self.post_sig == 0:
            z_log_scale = self._enc_log_sigma(x_in)
            self.z_scale = torch.exp(z_log_scale)
        else:
            self.z_scale = self.post_sig

        self.posterior = tdists.Normal(loc=self.z_loc, scale=self.z_scale)

        return self.posterior.rsample()

    def kl(self, z):
        return self.posterior.log_prob(z).sum(-1) - self.prior.log_prob(z)

    def log_prob(self, x_in):
        return self.forward(x_in)

    def forward(self, x_in):
        z = self._sample_latent(x_in)
        if self.mix_method == 'unconstrained' or self.mix_method == 'deconv':
            x_out = self._dec(z)
        likelihood_dist = torch.distributions.Normal(loc=x_out, scale=self.data_sig)
        return likelihood_dist, z
    
    def recon(self,x):
        # log p(x|z) + log p(z) - log q(z|x)
        batch_size = x.size(0)
        x = x.view(batch_size, -1)
        zs = self._enc_mu(x)
        x_out = self._dec(zs)
        return x_out
        
    
    def elbo(self, x):
        # log p(x|z) + log p(z) - log q(z|x)
        batch_size = x.size(0)
        x = x.view(batch_size, -1)
        zs = self._sample_latent(x)
        
        x_out = self._dec(zs)
        likelihood_dist = torch.distributions.Normal(loc=x_out, scale=self.data_sig)
        logpx = likelihood_dist.log_prob(x).view(batch_size, -1).sum(1)
            
        logpz = self.prior.log_prob(zs).view(batch_size, -1).sum(1)
        logqz_condx = self.posterior.log_prob(zs).view(batch_size, -1).sum(1)

        elbo = logpx + logpz - logqz_condx

        return elbo, elbo.detach()
        

def nats_to_bits_per_dim(nats, x_size):
    return nats / (log(2) * x_size)


def plot_reconstructed(vae, r0=(-1.2, 1.2), r1=(-1.2, 1.2), n=12, gap=3, w=32):
    img = list()
    for i, y in enumerate(np.linspace(*r1, n)):
        for j, x in enumerate(np.linspace(*r0, n)):
            z = torch.Tensor([[x, y]]).to(device)
            x_hat = vae._dec(z)
            x_hat = x_hat.reshape(3, w, w).to('cpu').detach().numpy()
            x_hat = np.transpose(x_hat,(1,2,0))
            img.append(x_hat[np.newaxis,:])

    img = np.concatenate(img)
    min_ = img.min()
    max_ = img.max()

    img = (img - min_)/(max_ - min_)

    return img




def get_confirm_token(response):
    for key, value in response.cookies.items():
        if key.startswith('download_warning'):
            return value

    return None


def save_response_content(response, destination):
    CHUNK_SIZE = 32768

    with open(destination, "wb") as f:
        for chunk in response.iter_content(CHUNK_SIZE):
            if chunk:  # Filter out keep-alive new chunks.
                f.write(chunk)
    
def download_file_from_google_drive(id, dest):
    URL = "https://docs.google.com/uc?export=download"

    session = requests.Session()

    response = session.get(URL, params={'id': id}, stream=True)
    token = get_confirm_token(response)

    if token:
        params = {'id': id, 'confirm': token}
        response = session.get(URL, params=params, stream=True)

    save_response_content(response, dest)
    

class CelebAHQ64Fast(Dataset):
    GOOGLE_DRIVE_FILE_ID = {
        'train': '1psLniAvAvyDgJV8DBk7cvTZ9EasB_2tZ',
        'valid': '1WfE64z9FNgOnLliGshUDuCrGBfJSwf-t'
    }

    NPY_NAME = {'train': 'train.npy', 'valid': 'valid.npy'}

    def __init__(self, root, train=True, download=False, transform=None):
        self.transform = transform
        self.root = root

        if download:
            self._download()


    def _download(self):
        os.makedirs(self.root, exist_ok=True)

        for tag in ['train', 'valid']:
            npy = os.path.join(self.root, self.NPY_NAME[tag])
            if not os.path.isfile(npy):
                print('Downloading {}...'.format(self.NPY_NAME[tag]))
                download_file_from_google_drive(self.GOOGLE_DRIVE_FILE_ID[tag],
                                                npy)

CelebAHQ64Fast('./data', download=True, train=True)


if not os.path.exists('data/celeba-hq-256/train-png'): 
    with zipfile.ZipFile('data/train.npy', 'r') as zip_ref:
        zip_ref.extractall('data')


X_data = []

files = glob.glob ("data/celeba-hq-256/train-png/*.png")
for i, myFile in enumerate(files):
    image = cv2.imread(myFile)
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    X_data.append(image)
    if i == 128: 
        break

X_data = np.array(X_data)
print('X_data shape:', X_data.shape)


# "we can apply convs that do strides in encoder and decoder networks before or after ResNet blocks."
# False means strided convs are done before ResNet blocks
# True means, for some stride values, partially done before and partially after
args = dict()
args['batch_size'] = 128
args['post_sig'] = 1.35
args['lr'] = 0.001
args['data_sig'] = 0.1
args['latent_dim'] = 128
args['val_steps'] = 50
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
deg = 2
# make toy data


batch_size = args['batch_size']
latent_dim = args['latent_dim']
torch.manual_seed(0)
np.random.seed(0)

tensor_x = torch.Tensor(X_data[:batch_size].reshape(batch_size,-1)).clone().float()/256
print(tensor_x.shape)
x_size = 1
im_width = 1

random_batch = tensor_x.to(device)

for args['data_sig'] in [0.0, 0.1,0.5]:
    for args['post_sig'] in [0.1,0.5,1.0]:
        name = 'D%.2fS%2.f'%(args['data_sig'], args['post_sig'])

        vae = VAE(latent_dim=latent_dim,
                  input_dim=tensor_x.shape[1],
                  dataset_size=batch_size,
                  post_sig=args['post_sig'],
                  hidden_dim=1024,
                  beta=1)

        vae.to(device)
        tensor_x = tensor_x.to(device)

        token = 'it'+'_'.join([str(v) for v in args.values()])
        optimizer = optim.Adam(vae.parameters(), lr=args['lr'])
        l = None

        run_dir = Path('runs') / Path(token)
        run_dir = Path(create_dir_with_index(str(run_dir)))

        summary_writer = SummaryWriter(run_dir, max_queue=100)

        frames = []
        num_steps = 10000
        vae.train()
        for i in tqdm(range(num_steps)):
            step = i
            # inputs = Variable(inputs.resize_(batch_size, input_dim))
            optimizer.zero_grad()
            elbo = vae.elbo(tensor_x + args['data_sig']*torch.randn_like(tensor_x))
            loss = -elbo[0].sum(-1).mean()
            loss.backward(retain_graph=True)
            optimizer.step()
            l = loss.data
            if i % args['val_steps'] == 0:
                # plot q(z|x) means and samples in z
                with torch.no_grad():
                    summary_writer.add_scalar('loss/loss', loss.item(), step)
                frames.append(Namespace(iter_num = step, recon=vae.recon(tensor_x).detach().numpy()))
              
        os.makedirs('saved_weights/' + name, exist_ok=True)

        fname = os.path.join(os.getcwd(), 'saved_weights/'+name+'/dec_weights.mat')
        weights = [vae._dec[0].weight.data.numpy().astype(np.float64), 
                       vae._dec[2].weight.data.numpy().astype(np.float64), 
                       vae._dec[4].weight.data.numpy().astype(np.float64)]
        data = {'weights': np.array(weights, dtype=np.object)}
        savemat(fname, data)

        fname = os.path.join(os.getcwd(), 'saved_weights/'+name+'/enc_mu_weights.mat')
        weights = [vae._enc_mu[0].weight.data.numpy().astype(np.float64), 
                       vae._enc_mu[2].weight.data.numpy().astype(np.float64), 
                       vae._enc_mu[4].weight.data.numpy().astype(np.float64)]
        data = {'weights': np.array(weights, dtype=np.object)}
        savemat(fname, data)
        
        recon = vae.recon(tensor_x).detach().numpy()
        fname = os.path.join(os.getcwd(), 'saved_weights/'+name+'recon.pkl')
        with open(fname,'wb') as f:
             pickle.dump(recon, f)



