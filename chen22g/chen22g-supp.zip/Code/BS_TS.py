import numpy as np
import time

##############################################################################
#TS Normal Rewards
start = time.time()
sample = 1000
T = 100
# mu = np.array([1,1.5]) #normal mean
# sigma = np.array([1,1])
mu = np.array([2,2.5,3,3.5]) #normal mean
sigma = np.array([2,1,1,2])
K = mu.size
muhat31 = np.zeros([K,sample])
error31 = np.zeros([K,sample])
R = np.zeros([sample,T])
I = np.zeros([sample,T])

for i in range(K):
      I[:,i] = i
  
for s in range(sample): 
    theta = np.zeros([K, T])
    mutemp = np.zeros([K, T+1])    
  
    for t in range(K):
        R[s,t] = np.random.normal(mu[np.int(I[s,t])],sigma[np.int(I[s,t])])
    for i in range(K):
        mutemp[i,t+1] = np.sum(R[s,:t+1][I[s,:t+1]==i])/(np.where(I[s,:t+1]==i)[0].size+1)
    for t in range(K,T):
        for i in range(K):
            theta[i,t] = np.random.normal(mutemp[i,t],np.sqrt(1/(np.where(I[s,:t+1]==i)[0].size+1)))
        I[s,t] = np.argmax(theta[:,t])
        R[s,t] = np.random.normal(mu[np.int(I[s,t])],sigma[np.int(I[s,t])])
        for i in range(K):
            mutemp[i,t+1] = np.sum(R[s,:t+1][I[s,:t+1]==i])/(np.where(I[s,:t+1]==i)[0].size+1)
    muhat31[:,s]= mutemp[:,-1]
    error31[:,s] = mutemp[:,-1] - mu 
bias31 = np.mean(error31, axis=1)   
print('bias is', np.round(bias31,4)) 
print('muhat is', np.round(np.mean(muhat31, axis=1),4))
# np.save('bias31.npy', bias31)
# np.save('muhat31.npy', muhat31)
# np.save('R31.npy', R)
# np.save('I31.npy', I)
# np.savetxt('bias31.dat',np.transpose(bias31.reshape(2,1)),header='arm1,arm2',delimiter=',',newline='\n')
# np.savetxt('muhat31.dat',np.transpose(muhat31),header='arm1,arm2',delimiter=',',newline='\n')
np.save('mulbias31.npy', bias31)
np.save('mulmuhat31.npy', muhat31)
np.save('mulR31.npy', R)
np.save('mulI31.npy', I)
np.savetxt('mulbias31.dat',np.transpose(bias31.reshape(4,1)),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')
np.savetxt('mulmuhat31.dat',np.transpose(muhat31),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')
 
###############################################################################
#MB
muhatmb31 = np.zeros([K,sample])
errormb31 = np.zeros([K,sample])
B = 1000

for s in range(sample):
    print('MB normal sample is', s+1) 
    mub = np.zeros(K)
    varb = np.zeros(K)
    for i in range(K):
        mub[i] =  np.mean(R[s][I[s]==i])
        varb[i] = np.var(R[s][I[s]==i])
    muboots = np.zeros([K,B])
    Rmb = np.zeros([B,T])
    Imb = np.zeros([B,T])
    for i in range(K):       
        Imb[:,i] = i
    for b in range(B): 
        theta = np.zeros([K, T])
        mutemp = np.zeros([K, T+1])       
        for t in range(K):
            # W = np.random.normal(0,1,size=(np.where(I[s]==np.int(Imb[b,t]))[0].size))
            # Rmb[b,t] = np.dot(W, R[s][I[s]==np.int(Imb[b,t])]-np.mean(R[s][I[s]==np.int(Imb[b,t])]))/np.sqrt(np.where(I[s]==np.int(Imb[b,t]))[0].size)+np.mean(R[s][I[s]==np.int(Imb[b,t])])            
            Rmb[b,t] = np.random.normal(mub[np.int(Imb[b,t])],np.sqrt(varb[np.int(Imb[b,t])]))                 
        for i in range(K):
            mutemp[i,t+1] = np.sum(Rmb[b,:t+1][Imb[b,:t+1]==i])/(np.where(Imb[b,:t+1]==i)[0].size+1)        
        for t in range(K,T):
            for i in range(K):
                theta[i,t] = np.random.normal(mutemp[i,t],np.sqrt(1/(np.where(Imb[b,:t+1]==i)[0].size+1)))
            Imb[b,t] = np.argmax(theta[:,t])
            # W = np.random.normal(0,1,size=(np.where(I[s]==np.int(Imb[b,t]))[0].size))
            # Rmb[b,t] = np.dot(W, R[s][I[s]==np.int(Imb[b,t])]-np.mean(R[s][I[s]==np.int(Imb[b,t])]))/np.sqrt(np.where(I[s]==np.int(Imb[b,t]))[0].size)+np.mean(R[s][I[s]==np.int(Imb[b,t])])
            Rmb[b,t] = np.random.normal(mub[np.int(Imb[b,t])],np.sqrt(varb[np.int(Imb[b,t])]))                         
            for i in range(K):
                mutemp[i,t+1] = np.sum(Rmb[b,:t+1][Imb[b,:t+1]==i])/(np.where(Imb[b,:t+1]==i)[0].size+1)
        muboots[:,b]= mutemp[:,-1]
    muhatmb31[:,s] = np.mean(muboots,axis = 1)        
errormb31 = muhatmb31 - muhat31
biasmb31 = np.mean(errormb31, axis=1)  
muhatmb31 = muhat31 - errormb31
print('biasmb is', np.round(biasmb31,4))
print('muhatmb is', np.round(np.mean(muhatmb31, axis=1),4))
# np.save('biasmb31.npy', biasmb31)
# np.save('muhatmb31.npy', muhatmb31)
# np.savetxt('biasmb31.dat',np.transpose(biasmb31.reshape(2,1)),header='arm1,arm2',delimiter=',',newline='\n')
# np.savetxt('muhatmb31.dat',np.transpose(muhatmb31),header='arm1,arm2',delimiter=',',newline='\n')
np.save('mulbiasmb31.npy', biasmb31)
np.save('mulmuhatmb31.npy', muhatmb31)
np.savetxt('mulbiasmb31.dat',np.transpose(biasmb31.reshape(4,1)),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')
np.savetxt('mulmuhatmb31.dat',np.transpose(muhatmb31),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')


##############################################################################
#EB
muhateb31 = np.zeros([K,sample])
erroreb31 = np.zeros([K,sample])
B = 1000

for s in range(sample):  
    print('EB normal sample is', s+1)
    muboots = np.zeros([K,B])
    Reb = np.zeros([B,T])
    Ieb = np.zeros([B,T])

    for i in range(K):
        locals()['Runiq'+str(i)]  = np.unique(R[s][I[s]==i])
        locals()['P'+str(i)] = np.zeros(locals()['Runiq'+str(i)].size)
        for j in range(locals()['Runiq'+str(i)].size):
            locals()['P'+str(i)][j] = np.where(R[s][I[s]==i]==locals()['Runiq'+str(i)][j])[0].size/np.where(I[s]==i)[0].size
    
    Rset = np.zeros([K,B,T])
    for i in range(K):
        Rset[i] = np.random.choice(locals()['Runiq'+str(i)], size=(B,T), p=locals()['P'+str(i)])
    
    for i in range(K):       
        Ieb[:,i] = i    
    for b in range(B):
        theta = np.zeros([K, T])
        mutemp = np.zeros([K, T+1])        
        for t in range(K):
            Reb[b,t] = Rset[np.int(Ieb[b,t]),b,t]
        for i in range(K):
            mutemp[i,t+1] = np.sum(Reb[b,:t+1][Ieb[b,:t+1]==i])/(np.where(Ieb[b,:t+1]==i)[0].size+1)                
        for t in range(K,T):
            for i in range(K):
                theta[i,t] = np.random.normal(mutemp[i,t],np.sqrt(1/(np.where(Ieb[b,:t+1]==i)[0].size+1)))
            Ieb[b,t] = np.argmax(theta[:,t])
            Reb[b,t] = Rset[np.int(Ieb[b,t]),b,t]
            for i in range(K):
                mutemp[i,t+1] = np.sum(Reb[b,:t+1][Ieb[b,:t+1]==i])/(np.where(Ieb[b,:t+1]==i)[0].size+1)
        muboots[:,b]= mutemp[:,-1]
    muhateb31[:,s] = np.mean(muboots,axis = 1)        
erroreb31 = muhateb31 - muhat31
biaseb31 = np.mean(erroreb31, axis=1)  
muhateb31 = muhat31 - erroreb31 
print('biaseb is', np.round(biaseb31,4))
print('muhateb is', np.round(np.mean(muhateb31, axis=1),4))
# np.save('biaseb31.npy', biaseb31)
# np.save('muhateb31.npy', muhateb31)
# np.savetxt('biaseb31.dat',np.transpose(biaseb31.reshape(2,1)),header='arm1,arm2',delimiter=',',newline='\n')
# np.savetxt('muhateb31.dat',np.transpose(muhateb31),header='arm1,arm2',delimiter=',',newline='\n')
np.save('mulbiaseb31.npy', biaseb31)
np.save('mulmuhateb31.npy', muhateb31)
np.savetxt('mulbiaseb31.dat',np.transpose(biaseb31.reshape(4,1)),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')
np.savetxt('mulmuhateb31.dat',np.transpose(muhateb31),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')


##############################################################################
#TS Bernoulli Rewards
sample = 1000
T = 100
# mu = np.array([0.3, 0.6]) #bernoulli mean
mu = np.array([0.4, 0.5, 0.7, 0.8]) #bernoulli mean
K = mu.size

muhat32 = np.zeros([K,sample])
error32 = np.zeros([K,sample])
R = np.zeros([sample,T])
I = np.zeros([sample,T])

for i in range(K):
    I[:,i] = i

for s in range(sample): 
    theta = np.zeros([K, T])
    mutemp = np.zeros([K, T+1])    

    for t in range(K):
        R[s,t] = np.random.binomial(1, mu[np.int(I[s,t])])
    for i in range(K):
        mutemp[i,t+1] = np.sum(R[s,:t+1][I[s,:t+1]==i])/(np.where(I[s,:t+1]==i)[0].size+1)
    for t in range(K,T):
        for i in range(K):
            theta[i,t] = np.random.normal(mutemp[i,t],np.sqrt(1/(np.where(I[s,:t+1]==i)[0].size+1)))
        I[s,t] = np.argmax(theta[:,t])
        R[s,t] = np.random.binomial(1, mu[np.int(I[s,t])])
        for i in range(K):
            mutemp[i,t+1] = np.sum(R[s,:t+1][I[s,:t+1]==i])/(np.where(I[s,:t+1]==i)[0].size+1)
    muhat32[:,s]= mutemp[:,-1]
    error32[:,s] = mutemp[:,-1] - mu 
bias32 = np.mean(error32, axis=1)   
print('bias is', np.round(bias32,4)) 
print('muhat is', np.round(np.mean(muhat32, axis=1),4))
# np.save('bias32.npy', bias32)
# np.save('muhat32.npy', muhat32)
# np.save('R32.npy', R)
# np.save('I32.npy', I)
# np.savetxt('bias32.dat',np.transpose(bias32.reshape(2,1)),header='arm1,arm2',delimiter=',',newline='\n')
# np.savetxt('muhat32.dat',np.transpose(muhat32),header='arm1,arm2',delimiter=',',newline='\n')
np.save('mulbias32.npy', bias32)
np.save('mulmuhat32.npy', muhat32)
np.save('mulR32.npy', R)
np.save('mulI32.npy', I)
np.savetxt('mulbias32.dat',np.transpose(bias32.reshape(4,1)),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')
np.savetxt('mulmuhat32.dat',np.transpose(muhat32),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')

###############################################################################
#MB 
muhatmb32 = np.zeros([K,sample])
errormb32 = np.zeros([K,sample])
B = 1000

for s in range(sample):
    print('MB bernoulli sample is', s+1) 
    muboots = np.zeros([K,B])
    Rmb = np.zeros([B,T])
    Imb = np.zeros([B,T])
    for i in range(K):       
        Imb[:,i] = i
    for b in range(B): 
        theta = np.zeros([K, T])
        mutemp = np.zeros([K, T+1])       
        for t in range(K):
            W = np.random.normal(0,1,size=(np.where(I[s]==np.int(Imb[b,t]))[0].size))
            Rmb[b,t] = np.dot(W, R[s][I[s]==np.int(Imb[b,t])]-np.mean(R[s][I[s]==np.int(Imb[b,t])]))/np.sqrt(np.where(I[s]==np.int(Imb[b,t]))[0].size)+np.mean(R[s][I[s]==np.int(Imb[b,t])])            
        for i in range(K):
            mutemp[i,t+1] = np.sum(Rmb[b,:t+1][Imb[b,:t+1]==i])/(np.where(Imb[b,:t+1]==i)[0].size+1)        
        for t in range(K,T):
            for i in range(K):
                theta[i,t] = np.random.normal(mutemp[i,t],np.sqrt(1/(np.where(Imb[b,:t+1]==i)[0].size+1)))
            Imb[b,t] = np.argmax(theta[:,t])
            W = np.random.normal(0,1,size=(np.where(I[s]==np.int(Imb[b,t]))[0].size))
            Rmb[b,t] = np.dot(W, R[s][I[s]==np.int(Imb[b,t])]-np.mean(R[s][I[s]==np.int(Imb[b,t])]))/np.sqrt(np.where(I[s]==np.int(Imb[b,t]))[0].size)+np.mean(R[s][I[s]==np.int(Imb[b,t])])
            for i in range(K):
                mutemp[i,t+1] = np.sum(Rmb[b,:t+1][Imb[b,:t+1]==i])/(np.where(Imb[b,:t+1]==i)[0].size+1)
        muboots[:,b]= mutemp[:,-1]
    muhatmb32[:,s] = np.mean(muboots,axis = 1)        
errormb32 = muhatmb32 - muhat32
biasmb32 = np.mean(errormb32, axis=1)  
muhatmb32 = muhat32 - errormb32
print('biasmb is', np.round(biasmb32,4))
print('muhatmb is', np.round(np.mean(muhatmb32, axis=1),4))
# np.save('biasmb32.npy', biasmb32)
# np.save('muhatmb32.npy', muhatmb32)
# np.savetxt('biasmb32.dat',np.transpose(biasmb32.reshape(2,1)),header='arm1,arm2',delimiter=',',newline='\n')
# np.savetxt('muhatmb32.dat',np.transpose(muhatmb32),header='arm1,arm2',delimiter=',',newline='\n')
np.save('mulbiasmb32.npy', biasmb32)
np.save('mulmuhatmb32.npy', muhatmb32)
np.savetxt('mulbiasmb32.dat',np.transpose(biasmb32.reshape(4,1)),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')
np.savetxt('mulmuhatmb32.dat',np.transpose(muhatmb32),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')

##############################################################################
#EB
muhateb32 = np.zeros([K,sample])
erroreb32 = np.zeros([K,sample])
B = 1000

for s in range(sample):  
    print('EB bernoulli sample is', s+1)
    muboots = np.zeros([K,B])
    Reb = np.zeros([B,T])
    Ieb = np.zeros([B,T])

    for i in range(K):
        locals()['Runiq'+str(i)]  = np.unique(R[s][I[s]==i])
        locals()['P'+str(i)] = np.zeros(locals()['Runiq'+str(i)].size)
        for j in range(locals()['Runiq'+str(i)].size):
            locals()['P'+str(i)][j] = np.where(R[s][I[s]==i]==locals()['Runiq'+str(i)][j])[0].size/np.where(I[s]==i)[0].size
    
    Rset = np.zeros([K,B,T])
    for i in range(K):
        Rset[i] = np.random.choice(locals()['Runiq'+str(i)], size=(B,T), p=locals()['P'+str(i)])
    
    for i in range(K):       
        Ieb[:,i] = i    
    for b in range(B):
        theta = np.zeros([K, T])
        mutemp = np.zeros([K, T+1])        
        for t in range(K):
            Reb[b,t] = Rset[np.int(Ieb[b,t]),b,t]
        for i in range(K):
            mutemp[i,t+1] = np.sum(Reb[b,:t+1][Ieb[b,:t+1]==i])/(np.where(Ieb[b,:t+1]==i)[0].size+1)                
        for t in range(K,T):
            for i in range(K):
                theta[i,t] = np.random.normal(mutemp[i,t],np.sqrt(1/(np.where(Ieb[b,:t+1]==i)[0].size+1)))
            Ieb[b,t] = np.argmax(theta[:,t])
            Reb[b,t] = Rset[np.int(Ieb[b,t]),b,t]
            for i in range(K):
                mutemp[i,t+1] = np.sum(Reb[b,:t+1][Ieb[b,:t+1]==i])/(np.where(Ieb[b,:t+1]==i)[0].size+1)
        muboots[:,b]= mutemp[:,-1]
    muhateb32[:,s] = np.mean(muboots,axis = 1)        
erroreb32 = muhateb32 - muhat32
biaseb32 = np.mean(erroreb32, axis=1)  
muhateb32 = muhat32 - erroreb32 
print('biaseb is', np.round(biaseb32,4))
print('muhateb is', np.round(np.mean(muhateb32, axis=1),4))
# np.save('biaseb32.npy', biaseb32)
# np.save('muhateb32.npy', muhateb32)
# np.savetxt('biaseb32.dat',np.transpose(biaseb32.reshape(2,1)),header='arm1,arm2',delimiter=',',newline='\n')
# np.savetxt('muhateb32.dat',np.transpose(muhateb32),header='arm1,arm2',delimiter=',',newline='\n')
np.save('mulbiaseb32.npy', biaseb32)
np.save('mulmuhateb32.npy', muhateb32)
np.savetxt('mulbiaseb32.dat',np.transpose(biaseb32.reshape(4,1)),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')
np.savetxt('mulmuhateb32.dat',np.transpose(muhateb32),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')

# # # end = time.time()
# # # print(end-start)
