
 function [regrets_track, arm_track] = sw_gp_ucb(SW, B,f_test,kernel,T,lambda,epsilon,R,time_change,max_value,max_arm)
        
        %SW = 2* SW;
        [~, arms] = size(f_test(1,:));
        %[max_value,max_arm] = max(f_test);
        %kernel_t = kernel;
        mu_t = zeros(arms,1); sigma2_t = zeros(arms,1);
        
        regrets_cumula = 0;
        regrets_track = zeros(T,1);

        rewards_cumula = 0;
        rewards_track = zeros(T,1);
        
        arm_track = zeros(T,1);
        y_track = zeros(T,1);
        
        num_func = size(B,1);
        iter_func = 0;
        
        for t = 1 : T   
            for i = 1 : num_func
                if t == time_change(i)+1
                    iter_func = iter_func + 1;
                end
            end
                
                if t <= SW
                    t2 = 1; 
                else
                    t2 = t- SW + 1;
                end
                    
                
                gamma_t =  log(t -t2 + 1);  % x_t only 1 dimension
                
                beta_t = B(iter_func)+   R/sqrt(lambda) *sqrt(2*gamma_t + 2);   %%%?
                if t == 1
                    arm_t = randi(arms);
                    mu_t = zeros(arms,1); sigma2_t = zeros(arms,1);
                else
                    [~,arm_t] = max( mu_t +  beta_t*sqrt(sigma2_t) );
                end
                arm_track(t) = arm_t;
                
                rewards_cumula = rewards_cumula + f_test(iter_func,arm_t);
                rewards_track(t) = rewards_cumula;
                               
                
                regrets_cumula = regrets_cumula + max_value(iter_func) - f_test(iter_func,arm_t);
                regrets_track(t) = regrets_cumula;

                noise = randn;  %sub-gaussian  normal 
                y_t = f_test(iter_func,arm_t) + epsilon*noise;
                y_track(t) = y_t;

                
                y1t = y_track(t2 : t);
                
                ktx = zeros(t-t2 + 1, arms);
                Kt = zeros(t-t2 + 1, t -t2 + 1);
                for i = t2 : t
                    ktx(i - t2 + 1, :) = kernel(arm_track(i),:);
                    for j = t2 : t
                        Kt(i - t2 + 1 ,j - t2 + 1) = kernel(arm_track(i), arm_track(j));
                    end
                end
                
                for k = 1 : arms
                    mu_t (k) = transpose( ktx(:, k) ) * inv(Kt + lambda*eye(t -t2 + 1))* y1t;
                    sigma2_t(k) = kernel(k,k) - transpose( ktx(:, k) )* inv(Kt + lambda*eye(t -t2 + 1)) * ktx(:, k);
                end
                

                
            
        end
    
        end