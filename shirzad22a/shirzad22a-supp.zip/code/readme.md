# TD-GEN

Before running install requirements. Install dgl and torch according to your device cuda version (or cpu version)

---

Model has three parts:
1. Tree generator
2. Node sharing
3. Node adding

The code used for training each of these submodels are:
1. train_tree_generator.py
2. train_node_sharing.py
3. train_node_adding.py

---

Each of the codes have its own args. You can easily change the name of the 
dataset, and other args and see the results of the training.

NLL of the whole model, is the sum of the nll/graph for the mentioned three models.

For generating graphs and using statistical metric, please train the first two models properly at first,
then for training node adding give the names of the trained models in args. Alse uncomment
the code for evaluate_stats, at the end of the code.

---
Statistical metrics have came in utils/dist_helper.py

For changing the distance metrics from total variation to earth moving distance or vide versa,
change the metrics from utils/eval_helper.py

For comparison with the previous work, we have used EMD for graph generation in table 1,
and TV for comparison of the tree generator in table 2.

---
Expected running time:

1. Ego-small: ~2 hours
2. Community-small: ~3 hours
3. Ego: ~6 hours
4. Community: ~12 hours