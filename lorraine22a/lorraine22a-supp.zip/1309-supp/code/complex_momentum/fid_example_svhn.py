"""Check that Frechet Inception Distance (FID) is approximately 0 when the two distributions are the same (both == SVHN training set).

Example
-------
python fid_example_svhn.py
"""
import os
import ipdb
import glob
import numpy as np
from imageio import imread

import tensorflow as tf
from torchvision import datasets

import fid

# Paths
stats_path = 'fid-stats/fid_stats_svhn_train.npz' # training set statistics
inception_path = fid.check_or_download_inception(None) # download inception network

svhn_trainset = datasets.SVHN(root='data', split='train', download=True, transform=None)
images = svhn_trainset.data.transpose(0,2,3,1)  # Switches from (73257, 3, 32, 32) to (73256, 32, 32, 3)

# load precalculated training set statistics
f = np.load(stats_path)
mu_real, sigma_real = f['mu'][:], f['sigma'][:]
f.close()

fid.create_inception_graph(inception_path)  # load the graph into the current TF graph
with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())
    mu_gen, sigma_gen = fid.calculate_activation_statistics(images, sess, batch_size=100)

fid_value = fid.calculate_frechet_distance(mu_gen, sigma_gen, mu_real, sigma_real)
print("FID: %s" % fid_value)  # Gives 0.000426237069234503
