from dataclasses import dataclass
from random import randint


@dataclass
class BaseConfig:
    verbose_send_msg_name: bool = False
    verbose_send_msg_data: bool = False
    verbose_engine_cnp: bool = False
    verbose_itsbp_outer: bool = True
    verbose_itsbp_link: bool = False

    cnp_engine_tolerance: float = 1e-5
    cnp_engine_iteration: float = 5000000

    itsbp_outer_tolerance: float = 2e-1
    itsbp_outer_iteration: float = 5000000

    random_update: bool = True
    @staticmethod
    def itsbp_schedule(cnt, leaf_nodes):
        cnt += 1
        return cnt % len(leaf_nodes)

    @staticmethod
    def itsbp_stochastic_schedule(cnt, leaf_nodes):
        old_cnt = cnt
        while cnt == old_cnt:
            cnt = randint(0, len(leaf_nodes) - 1)
        return cnt


baseconfig = BaseConfig()
