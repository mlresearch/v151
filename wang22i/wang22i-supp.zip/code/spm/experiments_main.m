function experiments_main

% Calls scripts corresponding to different numerical evaluations of our
% paper

SBM_case_NegativeInformative           % Figure 3a
SBM_case_PositiveInformative           % Figure 3b
