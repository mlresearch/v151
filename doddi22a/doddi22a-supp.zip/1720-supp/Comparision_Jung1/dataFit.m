%% Fitting the n_min with log(p)
format long
y = @(b,x) b(1)*log(x)+b(2) ;
opts = statset('Display','iter','TolFun',1e-8);
mdl = fitnlm([4,16,64,121], [5e5, 9e5, 16e5, 19e5], y,[70000,1270]);
semilogx([4,16,64,121], mdl.feval([4,16,64,121]));
