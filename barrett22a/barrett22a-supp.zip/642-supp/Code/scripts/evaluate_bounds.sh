pythonw ./other_experiments/evaluate_bounds.py --quantile_upper_bound=30
pythonw ./other_experiments/evaluate_bounds.py --gaussian_type="scaled_center" --gaussian_scaling=0.1 --quantile_upper_bound=5
pythonw ./other_experiments/evaluate_bounds.py --gaussian_type="off_center" --quantile_upper_bound=40
pythonw ./other_experiments/evaluate_bounds.py --gaussian_type="random" --quantile_upper_bound=40