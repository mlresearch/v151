
The code can be used to replicate the results in the paper "Optimal partition recovery in general graphs."


Requirements: 
The gco-v3.0 Matlab package that can be found in: 
https://github.com/nsubtil/gco-v3.0/tree/master/matlab

Simulations_l0.m: This can be used to generate the data and evaluate the performance of the proposed method.

l0_comparisons_tv.R: This can be used to compare agains TV denosing based detection in grid graphs

l0_comparisons.R: This can be used to compare against DCART.