clear all
n =5000 ;
num_trial = 50; %% number of trials 
d= 8; %% maximum number of one-hop and two-hop neighbors of a node in the graph. For a 2D grid, d=8
epsilon = 0.7; %% accuracy of reconstruction
Nnodes =16;
load(strcat('p',num2str(Nnodes),'.mat'));
lag = 3;


f = 0.25*pi; 
name1 = strcat('Batch1_f1_',int2str(n) ,'.mat');
name2 = strcat('Batch2_f1_',int2str(n) ,'.mat');


N = 285; %floor(4*C*real(U)*delta/(1-delta)^2);
%% 
Shat=zeros(16,16,num_trial);

for trial = 1:num_trial
Big_Matrix = Covaraiance_corr(n,E_factor,N,h,f,lag);
Shat(:,:,trial) = Big_Matrix;
end
save(name1, 'Shat')


%%
Shat=zeros(16,16,num_trial);
for trial = 1:num_trial
Big_Matrix = Covaraiance_corr(n,E_factor,N,h,f,lag);
Shat(:,:,trial) = Big_Matrix;
end
save(name2, 'Shat')
