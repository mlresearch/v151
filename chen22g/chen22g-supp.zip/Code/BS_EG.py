import numpy as np
import time

##############################################################################
#Epsilon Greedy Normal Rewards
#start = time.time()
sample = 1000
T = 100
epsilon = 0.05
# mu = np.array([1,1.5]) #normal mean
# sigma = np.array([1,1])
mu = np.array([2,2.5,3,3.5]) #normal mean
sigma = np.array([2,1,1,2])
K = mu.size
muhat41 = np.zeros([K,sample])
error41 = np.zeros([K,sample])
R = np.zeros([sample,T])
I = np.zeros([sample,T])

for i in range(K):
    I[:,i] = i

for s in range(sample):  
    EG = np.zeros([K,T])

    for t in range(K):
        R[s,t] = np.random.normal(mu[np.int(I[s,t])],sigma[np.int(I[s,t])])
    for i in range(K):
        EG[i,t]= np.sum(R[s,:t+1][I[s,:t+1]==i])/np.where(I[s,:t+1]==i)[0].size
    for t in range(K,T):
        flag = np.random.rand()
        itemp = np.random.rand()
        if flag<=epsilon:
            # if itemp<=1/2:
            #     I[s,t] = 0
            # else:
            #     I[s,t] = 1
            if itemp<=1/4:
                I[s,t] = 0
            elif itemp>1/4 and itemp<=1/2:
                I[s,t] = 1
            elif itemp>1/2 and itemp<=3/4:
                I[s,t] = 2
            else:
                I[s,t] = 3
        else:
            I[s,t]=np.argmax(EG[:,t-1])   
        R[s,t] = np.random.normal(mu[np.int(I[s,t])],sigma[np.int(I[s,t])])       
        for i in range(K):
            EG[i,t]= np.sum(R[s,:t+1][I[s,:t+1]==i])/np.where(I[s,:t+1]==i)[0].size
    for i in range(K):
        muhat41[i, s] = np.sum(R[s][I[s]==i])/np.where(I[s]==i)[0].size
    error41[:,s] = muhat41[:, s] - mu
bias41 = np.mean(error41, axis=1)  

print('bias is', np.round(bias41,4)) 
print('muhat is', np.round(np.mean(muhat41, axis=1),4))
# np.save('bias41.npy', bias41)
# np.save('muhat41.npy', muhat41)
# np.save('R41.npy', R)
# np.save('I41.npy', I)
# np.savetxt('bias41.dat',np.transpose(bias41.reshape(2,1)),header='arm1,arm2',delimiter=',',newline='\n')
# np.savetxt('muhat41.dat',np.transpose(muhat41),header='arm1,arm2',delimiter=',',newline='\n')
np.save('mulbias41.npy', bias41)
np.save('mulmuhat41.npy', muhat41)
np.save('mulR41.npy', R)
np.save('mulI41.npy', I)
np.savetxt('mulbias41.dat',np.transpose(bias41.reshape(4,1)),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')
np.savetxt('mulmuhat41.dat',np.transpose(muhat41),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')
 

############################################################################## 
#MB
muhatmb41 = np.zeros([K,sample])
errormb41 = np.zeros([K,sample])
B = 1000

for s in range(sample): 
    print('MB normal sample is', s+1) 
    mub = np.zeros(K)
    varb = np.zeros(K)
    for i in range(K):
        mub[i] =  np.mean(R[s][I[s]==i])
        varb[i] = np.var(R[s][I[s]==i])
    muboots = np.zeros([K,B])
    Rmb = np.zeros([B,T])
    Imb = np.zeros([B,T])
    for i in range(K):       
        Imb[:,i] = i
    for b in range(B):
        EG = np.zeros([K,T])
    
        for t in range(K):
            # W = np.random.normal(0,1,size=(np.where(I[s]==np.int(Imb[b,t]))[0].size))
            # Rmb[b,t] = np.dot(W, R[s][I[s]==np.int(Imb[b,t])]-np.mean(R[s][I[s]==np.int(Imb[b,t])]))/np.sqrt(np.where(I[s]==np.int(Imb[b,t]))[0].size)+np.mean(R[s][I[s]==np.int(Imb[b,t])])
            Rmb[b,t] = np.random.normal(mub[np.int(Imb[b,t])],np.sqrt(varb[np.int(Imb[b,t])]))                 
        for i in range(K):
            EG[i,t]= np.sum(Rmb[b,:t+1][Imb[b,:t+1]==i])/np.where(Imb[b,:t+1]==i)[0].size
        for t in range(K,T):    
            flag = np.random.rand()
            itemp = np.random.rand()
            if flag<=epsilon:
                # if itemp<=1/2:
                #     Imb[b,t] = 0
                # else:
                #     Imb[b,t] = 1
                if itemp<=1/4:
                    Imb[b,t] = 0
                elif itemp>1/4 and itemp<=1/2:
                    Imb[b,t] = 1
                elif itemp>1/2 and itemp<=3/4:
                    Imb[b,t] = 2
                else:
                    Imb[b,t] = 3
            else:
                Imb[b,t]=np.argmax(EG[:,t-1])   
            # W = np.random.normal(0,1,size=(np.where(I[s]==np.int(Imb[b,t]))[0].size))
            # Rmb[b,t] = np.dot(W, R[s][I[s]==np.int(Imb[b,t])]-np.mean(R[s][I[s]==np.int(Imb[b,t])]))/np.sqrt(np.where(I[s]==np.int(Imb[b,t]))[0].size)+np.mean(R[s][I[s]==np.int(Imb[b,t])])    
            Rmb[b,t] = np.random.normal(mub[np.int(Imb[b,t])],np.sqrt(varb[np.int(Imb[b,t])]))                         
            for i in range(K):
                EG[i,t]= np.sum(Rmb[b,:t+1][Imb[b,:t+1]==i])/np.where(Imb[b,:t+1]==i)[0].size
        for i in range(K):
            muboots[i, b] = np.sum(Rmb[b][Imb[b]==i])/np.where(Imb[b]==i)[0].size
    muhatmb41[:,s] = np.mean(muboots,axis = 1)   
errormb41 = muhatmb41 - muhat41
biasmb41 = np.mean(errormb41, axis=1)  
muhatmb41 = muhat41 - errormb41

print('biasmb is', np.round(biasmb41,4))
print('muhatmb is', np.round(np.mean(muhatmb41, axis=1),4))
# np.save('biasmb41.npy', biasmb41)
# np.save('muhatmb41.npy', muhatmb41)
# np.savetxt('biasmb41.dat',np.transpose(biasmb41.reshape(2,1)),header='arm1,arm2',delimiter=',',newline='\n')
# np.savetxt('muhatmb41.dat',np.transpose(muhatmb41),header='arm1,arm2',delimiter=',',newline='\n')
np.save('mulbiasmb41.npy', biasmb41)
np.save('mulmuhatmb41.npy', muhatmb41)
np.savetxt('mulbiasmb41.dat',np.transpose(biasmb41.reshape(4,1)),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')
np.savetxt('mulmuhatmb41.dat',np.transpose(muhatmb41),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')

 
##############################################################################
#EB
muhateb41 = np.zeros([K,sample])
erroreb41 = np.zeros([K,sample])
B = 1000

for s in range(sample):  
    print('EB normal sample is', s+1)
    muboots = np.zeros([K,B])
    Reb = np.zeros([B,T])
    Ieb = np.zeros([B,T])

    for i in range(K):
        locals()['Runiq'+str(i)]  = np.unique(R[s][I[s]==i])
        locals()['P'+str(i)] = np.zeros(locals()['Runiq'+str(i)].size)
        for j in range(locals()['Runiq'+str(i)].size):
            locals()['P'+str(i)][j] = np.where(R[s][I[s]==i]==locals()['Runiq'+str(i)][j])[0].size/np.where(I[s]==i)[0].size
    
    Rset = np.zeros([K,B,T])
    for i in range(K):
        Rset[i] = np.random.choice(locals()['Runiq'+str(i)], size=(B,T), p=locals()['P'+str(i)])
    
    for i in range(K):       
        Ieb[:,i] = i    
    for b in range(B):
        EG = np.zeros([K,T])        
        for t in range(K):
            Reb[b,t] = Rset[np.int(Ieb[b,t]),b,t]
        for i in range(K):
            EG[i,t]= np.sum(Reb[b,:t+1][Ieb[b,:t+1]==i])/np.where(Ieb[b,:t+1]==i)[0].size                
        for t in range(K,T):    
            flag = np.random.rand()
            itemp = np.random.rand()
            if flag<=epsilon:
                # if itemp<=1/2:
                #     Ieb[b,t] = 0
                # else:
                #     Ieb[b,t] = 1
                if itemp<=1/4:
                    Ieb[b,t] = 0
                elif itemp>1/4 and itemp<=1/2:
                    Ieb[b,t] = 1
                elif itemp>1/2 and itemp<=3/4:
                    Ieb[b,t] = 2
                else:
                    Ieb[b,t] = 3
            else:
                Ieb[b,t]=np.argmax(EG[:,t-1])   
            Reb[b,t] = Rset[np.int(Ieb[b,t]),b,t]
            for i in range(K):
                EG[i,t]= np.sum(Reb[b,:t+1][Ieb[b,:t+1]==i])/np.where(Ieb[b,:t+1]==i)[0].size    
        for i in range(K):
            muboots[i, b] = np.sum(Reb[b][Ieb[b]==i])/np.where(Ieb[b]==i)[0].size
    muhateb41[:,s] = np.mean(muboots,axis = 1)        
erroreb41 = muhateb41 - muhat41
biaseb41 = np.mean(erroreb41, axis=1)  
muhateb41 = muhat41 - erroreb41 
print('biaseb is', np.round(biaseb41,4))
print('muhateb is', np.round(np.mean(muhateb41, axis=1),4))
# np.save('biaseb41.npy', biaseb41)
# np.save('muhateb41.npy', muhateb41)
# np.savetxt('biaseb41.dat',np.transpose(biaseb41.reshape(2,1)),header='arm1,arm2',delimiter=',',newline='\n')
# np.savetxt('muhateb41.dat',np.transpose(muhateb41),header='arm1,arm2',delimiter=',',newline='\n')
np.save('mulbiaseb41.npy', biaseb41)
np.save('mulmuhateb41.npy', muhateb41)
np.savetxt('mulbiaseb41.dat',np.transpose(biaseb41.reshape(4,1)),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')
np.savetxt('mulmuhateb41.dat',np.transpose(muhateb41),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')

##############################################################################
#Epsilon Greedy Bernoulli Rewards
sample = 1000
T = 100
epsilon = 0.05
# mu = np.array([0.3, 0.6]) #bernoulli mean
mu = np.array([0.4, 0.5, 0.7, 0.8]) #bernoulli mean
K = mu.size

muhat42 = np.zeros([K,sample])
error42 = np.zeros([K,sample])
R = np.zeros([sample,T])
I = np.zeros([sample,T])

for i in range(K):
    I[:,i] = i

for s in range(sample):  
    EG = np.zeros([K,T])

    for t in range(K):
        R[s,t] = np.random.binomial(1, mu[np.int(I[s,t])])
    for i in range(K):
        EG[i,t]= np.sum(R[s,:t+1][I[s,:t+1]==i])/np.where(I[s,:t+1]==i)[0].size
    for t in range(K,T):
        flag = np.random.rand()
        itemp = np.random.rand()
        if flag<=epsilon:
            # if itemp<=1/2:
            #     I[s,t] = 0
            # else:
            #     I[s,t] = 1
            if itemp<=1/4:
                I[s,t] = 0
            elif itemp>1/4 and itemp<=1/2:
                I[s,t] = 1
            elif itemp>1/2 and itemp<=3/4:
                I[s,t] = 2
            else:
                I[s,t] = 3
        else:
            I[s,t]=np.argmax(EG[:,t-1])   
        R[s,t] = np.random.binomial(1, mu[np.int(I[s,t])])
        for i in range(K):
            EG[i,t]= np.sum(R[s,:t+1][I[s,:t+1]==i])/np.where(I[s,:t+1]==i)[0].size
    for i in range(K):
        muhat42[i, s] = np.sum(R[s][I[s]==i])/np.where(I[s]==i)[0].size
    error42[:,s] = muhat42[:, s] - mu
bias42 = np.mean(error42, axis=1)  

print('bias is', np.round(bias42,4)) 
print('muhat is', np.round(np.mean(muhat42, axis=1),4))
# np.save('bias42.npy', bias42)
# np.save('muhat42.npy', muhat42)
# np.save('R42.npy', R)
# np.save('I42.npy', I)
# np.savetxt('bias42.dat',np.transpose(bias42.reshape(2,1)),header='arm1,arm2',delimiter=',',newline='\n')
# np.savetxt('muhat42.dat',np.transpose(muhat42),header='arm1,arm2',delimiter=',',newline='\n')
np.save('mulbias42.npy', bias42)
np.save('mulmuhat42.npy', muhat42)
np.save('mulR42.npy', R)
np.save('mulI42.npy', I)
np.savetxt('mulbias42.dat',np.transpose(bias42.reshape(4,1)),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')
np.savetxt('mulmuhat42.dat',np.transpose(muhat42),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')


############################################################################## 
#MB
muhatmb42 = np.zeros([K,sample])
errormb42 = np.zeros([K,sample])
B = 1000

for s in range(sample): 
    print('MB bernoulli sample is', s+1)   
    muboots = np.zeros([K,B])
    Rmb = np.zeros([B,T])
    Imb = np.zeros([B,T])
    for i in range(K):       
        Imb[:,i] = i
    for b in range(B):
        EG = np.zeros([K,T])  
        for t in range(K):
            W = np.random.normal(0,1,size=(np.where(I[s]==np.int(Imb[b,t]))[0].size))
            Rmb[b,t] = np.dot(W, R[s][I[s]==np.int(Imb[b,t])]-np.mean(R[s][I[s]==np.int(Imb[b,t])]))/np.sqrt(np.where(I[s]==np.int(Imb[b,t]))[0].size)+np.mean(R[s][I[s]==np.int(Imb[b,t])])
        for i in range(K):
            EG[i,t]= np.sum(Rmb[b,:t+1][Imb[b,:t+1]==i])/np.where(Imb[b,:t+1]==i)[0].size
        for t in range(K,T):    
            flag = np.random.rand()
            itemp = np.random.rand()
            if flag<=epsilon:
                # if itemp<=1/2:
                #     Imb[b,t] = 0
                # else:
                #     Imb[b,t] = 1
                if itemp<=1/4:
                    Imb[b,t] = 0
                elif itemp>1/4 and itemp<=1/2:
                    Imb[b,t] = 1
                elif itemp>1/2 and itemp<=3/4:
                    Imb[b,t] = 2
                else:
                    Imb[b,t] = 3
            else:
                Imb[b,t]=np.argmax(EG[:,t-1])   
            W = np.random.normal(0,1,size=(np.where(I[s]==np.int(Imb[b,t]))[0].size))
            Rmb[b,t] = np.dot(W, R[s][I[s]==np.int(Imb[b,t])]-np.mean(R[s][I[s]==np.int(Imb[b,t])]))/np.sqrt(np.where(I[s]==np.int(Imb[b,t]))[0].size)+np.mean(R[s][I[s]==np.int(Imb[b,t])])    
            for i in range(K):
                EG[i,t]= np.sum(Rmb[b,:t+1][Imb[b,:t+1]==i])/np.where(Imb[b,:t+1]==i)[0].size
        for i in range(K):
            muboots[i, b] = np.sum(Rmb[b][Imb[b]==i])/np.where(Imb[b]==i)[0].size
    muhatmb42[:,s] = np.mean(muboots,axis = 1)   
errormb42 = muhatmb42 - muhat42
biasmb42 = np.mean(errormb42, axis=1)  
muhatmb42 = muhat42 - errormb42
print('biasmb is', np.round(biasmb42,4))
print('muhatmb is', np.round(np.mean(muhatmb42, axis=1),4))
# np.save('biasmb42.npy', biasmb42)
# np.save('muhatmb42.npy', muhatmb42)
# np.savetxt('biasmb42.dat',np.transpose(biasmb42.reshape(2,1)),header='arm1,arm2',delimiter=',',newline='\n')
# np.savetxt('muhatmb42.dat',np.transpose(muhatmb42),header='arm1,arm2',delimiter=',',newline='\n')
np.save('mulbiasmb42.npy', biasmb42)
np.save('mulmuhatmb42.npy', muhatmb42)
np.savetxt('mulbiasmb42.dat',np.transpose(biasmb42.reshape(4,1)),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')
np.savetxt('mulmuhatmb42.dat',np.transpose(muhatmb42),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')

##############################################################################
#EB
muhateb42 = np.zeros([K,sample])
erroreb42 = np.zeros([K,sample])
B = 1000

for s in range(sample):  
    print('EB bernoulli sample is', s+1)
    muboots = np.zeros([K,B])
    Reb = np.zeros([B,T])
    Ieb = np.zeros([B,T])

    for i in range(K):
        locals()['Runiq'+str(i)]  = np.unique(R[s][I[s]==i])
        locals()['P'+str(i)] = np.zeros(locals()['Runiq'+str(i)].size)
        for j in range(locals()['Runiq'+str(i)].size):
            locals()['P'+str(i)][j] = np.where(R[s][I[s]==i]==locals()['Runiq'+str(i)][j])[0].size/np.where(I[s]==i)[0].size
    
    Rset = np.zeros([K,B,T])
    for i in range(K):
        Rset[i] = np.random.choice(locals()['Runiq'+str(i)], size=(B,T), p=locals()['P'+str(i)])
    
    for i in range(K):       
        Ieb[:,i] = i    
    for b in range(B):
        EG = np.zeros([K,T])        
        for t in range(K):
            Reb[b,t] = Rset[np.int(Ieb[b,t]),b,t]
        for i in range(K):
            EG[i,t]= np.sum(Reb[b,:t+1][Ieb[b,:t+1]==i])/np.where(Ieb[b,:t+1]==i)[0].size                
        for t in range(K,T):    
            flag = np.random.rand()
            itemp = np.random.rand()
            if flag<=epsilon:
                # if itemp<=1/2:
                #     Ieb[b,t] = 0
                # else:
                #     Ieb[b,t] = 1
                if itemp<=1/4:
                    Ieb[b,t] = 0
                elif itemp>1/4 and itemp<=1/2:
                    Ieb[b,t] = 1
                elif itemp>1/2 and itemp<=3/4:
                    Ieb[b,t] = 2
                else:
                    Ieb[b,t] = 3
            else:
                Ieb[b,t]=np.argmax(EG[:,t-1])   
            Reb[b,t] = Rset[np.int(Ieb[b,t]),b,t]
            for i in range(K):
                EG[i,t]= np.sum(Reb[b,:t+1][Ieb[b,:t+1]==i])/np.where(Ieb[b,:t+1]==i)[0].size    
        for i in range(K):
            muboots[i, b] = np.sum(Reb[b][Ieb[b]==i])/np.where(Ieb[b]==i)[0].size
    muhateb42[:,s] = np.mean(muboots,axis = 1)        
erroreb42 = muhateb42 - muhat42
biaseb42 = np.mean(erroreb42, axis=1)  
muhateb42 = muhat42 - erroreb42 
print('biaseb is', np.round(biaseb42,4))
print('muhateb is', np.round(np.mean(muhateb42, axis=1),4))
# np.save('biaseb42.npy', biaseb42)
# np.save('muhateb42.npy', muhateb42)
# np.savetxt('biaseb42.dat',np.transpose(biaseb42.reshape(2,1)),header='arm1,arm2',delimiter=',',newline='\n')
# np.savetxt('muhateb42.dat',np.transpose(muhateb42),header='arm1,arm2',delimiter=',',newline='\n')
np.save('mulbiaseb42.npy', biaseb42)
np.save('mulmuhateb42.npy', muhateb42)
np.savetxt('mulbiaseb42.dat',np.transpose(biaseb42.reshape(4,1)),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')
np.savetxt('mulmuhateb42.dat',np.transpose(muhateb42),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')


# # #end = time.time()
# # #print(end-start)