from models.personalizer.simsgp import *
import tqdm
from utils.utilities import *


class SIMSSSL:
    def __init__(self, gp, optimizer):
        self.personalizer = gp
        self.optimizer = optimizer

    def fit(self, X, Y, Xs, max_num_epoch = 100, checkpoint = 10):
        losses, rmses = [], []
        counter = tqdm.trange(max_num_epoch)
        for epoch in counter:
            with tf.GradientTape(watch_accessed_variables = False) as tape:
                tape.watch(self.personalizer.cov.simsengine.network.aggregator.trainable_weights)
                L = self.personalizer.NLL(X, Y, Xs)
                gradient = tape.gradient(L, self.personalizer.cov.simsengine.network.aggregator.trainable_weights)
                self.optimizer.optimizer.apply_gradients(zip(gradient, self.personalizer.cov.simsengine.network.aggregator.trainable_weights))

            self.personalizer.cov.tower = self.personalizer.cov.simsengine.network.tower
            self.personalizer.cov.aggregator = self.personalizer.cov.simsengine.network.aggregator

            if (epoch + 1) % checkpoint == 0:
                loss = tf.identity(L).numpy()[0, 0]
                Y_pred = self.personalizer.predict(X, X, Y, Xs)
                Y_true = tf.reshape(tf.cast(tf.convert_to_tensor(Y), tf.float32), [-1, 1])
                rmse = (KB.sum(KB.abs(Y_pred - Y_true) ** 2) / Y_pred.shape[0]) ** 0.5
                rmses.append(rmse.numpy())
                losses.append(loss)
                counter.set_postfix_str("Epoch {} : Loss = {:.4f} | RMSE = {:.4f}".format(epoch + 1, loss, rmse))
        return losses, rmses

    def get_single_recommendation(self, item, candidates, item_embeddings, candidate_embeddings, K = 25):
        scores = 1.0 - self.personalizer.cov.aggregator([item_embeddings, candidate_embeddings])
        scores = scores.numpy()
        ratings = []
        for i in range(len(candidates)):
            ratings.append(scores[i, 0])
        ratings = np.asarray(ratings)
        indices = (-ratings).argsort()[:(K + 1)]
        res = []
        for pos in indices:
            if candidates[pos] != item and len(res) < K:
                res.append(candidates[pos])
        return res

    def get_recommendation(self, items, candidates, featurizer, interaction_data_loader = None, K = 25, verbal = False):  # generate the top-K items for a given item from a pool of candidates
        candidate_features, candidate_ids = featurizer.featurize(candidates)
        item_features, item_ids = featurizer.featurize(items)
        candidate_embeddings = self.personalizer.cov.tower([candidate_ids, candidate_features])
        item_embeddings = self.personalizer.cov.tower([item_ids, item_features])
        if len(list(item_features.keys())) == 0:
            item_embeddings = [item_embeddings]
            candidate_embeddings = [candidate_embeddings]
        res = {}
        for i in range(len(items)):
            announce("Evaluating Item No {} with ID = {}".format(i + 1, items[i]), verbal = verbal)
            embeddings = []
            for component in item_embeddings:
                embeddings.append(tf.repeat([component[i, :]], repeats = [len(candidates)], axis = 0))
            res[items[i]] = self.get_single_recommendation(items[i], candidates, embeddings, candidate_embeddings, K = K)
        return res

