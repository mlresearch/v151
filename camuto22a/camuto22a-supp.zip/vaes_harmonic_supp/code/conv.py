[
    vae._enc_mu[i].weight.data.cpu().numpy().astype(np.float64)
    for i in [0, 3, 6, 9]
]


class ConvDecoder(nn.Module):
    def __init__(self, input_dim):
        super(ConvDecoder, self).__init__()

        self.net = torch.nn.Sequential(
            torch.nn.ConvTranspose2d(input_dim, 512, 1, 1, 0),  # 1 x 1
            torch.nn.BatchNorm2d(512),
            torch.nn.Sigmoid(),
            torch.nn.ConvTranspose2d(512, 128, 4, 1, 0),  # 4 x 4
            torch.nn.BatchNorm2d(128),
            torch.nn.Sigmoid(),
            torch.nn.ConvTranspose2d(128, 128, 4, 2, 1),  # 8 x 8
            torch.nn.BatchNorm2d(128),
            torch.nn.Sigmoid(),
            torch.nn.ConvTranspose2d(128, 64, 4, 2, 1),  # 16 x 16
            torch.nn.BatchNorm2d(64),
            torch.nn.Sigmoid(),
            torch.nn.ConvTranspose2d(64, 64, 4, 2, 1) , # 32 x 32
            torch.nn.BatchNorm2d(64),
            torch.nn.Sigmoid(),
            torch.nn.ConvTranspose2d(64, 3, 4, 2, 1)  # 16 x 16)


class ConvEncoder(nn.Module):
    def __init__(self, output_dim):
        super(ConvEncoder, self).__init__()
        self.output_dim = output_dim
        torch.nn.Sequential(
            torch.nn.Conv2d(3, 64, 4, 2, 1),  # 32 x 32
            torch.nn.BatchNorm2d(64),
            orch.nn.Sigmoid(),
            torch.nn.Conv2d(64, 64, 4, 2, 1),  # 16 x 16
            torch.nn.BatchNorm2d(64),
            orch.nn.Sigmoid(),
            torch.nn.Conv2d(3, 128, 4, 2, 1),  # 8 x 8
            torch.nn.BatchNorm2d(128),
            torch.nn.Sigmoid(),
            torch.nn.Conv2d(128, 128, 4, 2, 1),  # 4 x 4
            torch.nn.BatchNorm2d(128),
            torch.nn.Sigmoid(),
            torch.nn.Conv2d(128, 512, 4),
            torch.nn.BatchNorm2d(512),
            torch.nn.Sigmoid(),
            torch.nn.Conv2d(512, output_dim, 1),
        )

        # setup the non-linearity
        self.act = nn.ReLU(inplace=True)
