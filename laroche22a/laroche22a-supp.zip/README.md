# Implementation of Cross-Entropy updates as described in the paper entitled "Beyond the Policy Gradient Theorem for Efficient Policy Updates in Actor-Critic Algorithms"

This project can be used to replicate the experiments presented in the paper. Please cite the paper if you use this corpus in your work.

## Prerequisites

The project is implemented in Python 3.5 and requires *numpy* and *scipy*.

## Usage



## License

This project is MIT-licensed.
