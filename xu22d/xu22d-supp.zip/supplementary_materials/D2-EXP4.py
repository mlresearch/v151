import numpy as np
from pricing_function import pricing
# from pricing_inverse_function import pricing_inverse
import scipy.stats as stats
from number2theta import number_2_theta, theta_mat
import pickle as pk
import matplotlib.pyplot as plt
from scipy.special import comb, perm
from m_sum_n import m_by_n
from pdf2cdf import pdf2cdf
from argmax_d2_exp4 import pricing_d2exp4
import random

"""
    This is an implementation of D2-EXP4 algorithm as a function.
"""
def d2_exp4(T=4096, d=2, gamma=0.11, rounds=1, mode_indicator=0, bound_theta=1, bound_x=1, bound_noise=1,
               start_point=16, ifregression=1, ifplot=1, ifsave=1, ifprint=1):
    """ Mode Selection """
    mode_indicator = 1  # 1 for stochastic x_t's, and 0 for adversarial
    """initialize model parameters"""
    # T = 5000  # period number < 70000
    # d = 2  # feature dimension
    # rounds = 5  # repeat, rounds <= 20
    # bound_theta = 1  # Euclidean norm upper bound of theta_star
    # bound_x = 1  # Euclidean norm upper bound of x_t
    # bound_noise = 1  # should be an integer
    sigma = bound_noise / 8  # denominator should be >2
    # start_point = 100
    """Initialize EXP4 parameter"""
    # gamma = 0.11  # balance the exploration-exploitation of EXP-4
    """load x_t"""
    if mode_indicator:
        with open("xtrandom.pkl", 'rb') as pkf:
            xt_file = pk.load(pkf)
    else:
        with open("xtadversarial.pkl", 'rb') as pkg:
            xt_file = pk.load(pkg)
    """regret_list"""
    regret_original = np.zeros((T, rounds))
    """rounds start"""
    for iround in range(rounds):
        print("round  ", iround)
        """load x_t for this round"""
        xt_this_round = xt_file[:, :, iround]
        """(not necessarily happen) initialize theta_star"""
        theta_star = bound_theta * np.random.rand(d)  # for convenience, we assume theta_star is all positive
        theta_star = theta_star / max(1, np.linalg.norm(theta_star, 2))
        if ifprint == 1:
            print("theta_star = ", theta_star)
        """initialize regret as zero"""
        regret = 0
        """set up T and discretize"""
        delta = T ** (-1 / 4) * d ** (-1 / 2)  # discretizator of policy theta
        discrete_factor = T ** (-1 / 4)  # gamma in our paper
        """theta discretization"""
        M = int(np.floor(bound_theta / delta))  # number of grid
        N = (M + 1) ** d  # number of theta
        """action discretization"""
        K_action = int(np.ceil((bound_noise + bound_x * bound_theta) / discrete_factor)) + 1
        list_selected_actions = np.zeros(T)
        """noise distribution discretization factor """
        Md = int(np.floor(bound_noise / discrete_factor))
        Hd = int(np.floor(1 / discrete_factor))
        """We construct the theta vectors"""
        theta_matrix = theta_mat(d, M, N, delta)
        """We construct the pdf vectors"""
        pdf_matrix = m_by_n(Md, Hd)
        cdf_matrix = pdf_matrix
        Nd = len(pdf_matrix)
        for i_N in range(Nd):
            cdf_matrix[i_N] = pdf2cdf(pdf_matrix[i_N]) * discrete_factor
        """Instead of the weight vector of policies in original EXP4, 
        here we adopt a weight matrix, with the first index for theta
        and the second index for distribution."""
        weight_of_experts = np.ones((N, Nd))
        """            period start                  """
        for t in range(T):
            x_t = xt_this_round[t]
            v_t = 0  # initialize a price
            i_v_t = 0
            W_t = weight_of_experts.sum()
            """Stage one: decide exploration or exploitation"""
            divider1 = np.random.rand()
            """with Pr = gamma/K, take action (price) uniformly at random"""
            if divider1 <= gamma:
                i_v_t = np.random.randint(K_action)
                v_t = discrete_factor * i_v_t
            else:
                """stage 2: choose a parameter theta,
                set up cumulative probability of theta"""
                prob_theta_vec = []
                for i_N in range(N):
                    prob_theta_vec.append(weight_of_experts[i_N].sum() / W_t)
                index_list_theta = list(range(N))
                index_theta = random.choices(index_list_theta, weights=prob_theta_vec, k=1)

                """stage 3: choose a distribution vector"""
                # W_t_theta = weight_of_experts[index_theta].sum()
                index_list_f = list(range(Nd))
                index_f = random.choices(index_list_f, weights=list(weight_of_experts[index_theta, :][0]), k=1)
                # till now, our policy should be greedy on (index_theta, index_f)
                theta_t = theta_matrix[index_theta][0]  # number_2_theta(index_theta, d, M, discrete_factor)  # should use a more static method
                vec_f_t = cdf_matrix[index_f][0]
                i_v_t = pricing_d2exp4(x_t, theta_t, vec_f_t, Md, discrete_factor, bound_noise)
                v_t = discrete_factor * i_v_t
            # the price v_t has been proposed
            """ generate customers' valuation """
            N_t = min(max(bound_noise / 2 + np.random.randn() * sigma, 0), bound_noise)  # N(0.5, 0.167) truncated in [0,1]
            y_t = np.dot(x_t, theta_star) + N_t
            u_t = np.dot(x_t, theta_star) + bound_noise / 2
            """compare and make a decision accordingly"""
            ind = 0
            if v_t <= y_t:
                ind = 1
            """calculate cumulative expected regret and record"""
            v_star = pricing(u_t, sigma)
            expected_revenue_t = v_t * (1 - stats.norm.cdf((v_t - u_t) / sigma))
            largest_expected_revenue = v_star * (1 - stats.norm.cdf((v_star - u_t) / sigma))
            regret = regret + largest_expected_revenue - expected_revenue_t
            regret_original[t, iround] = regret
            """update weights"""
            prob_v_i = gamma / K_action
            """construct an index-to-price matrix (table)"""
            price_index_matrix = np.zeros((N, Nd))
            for i_N in range(N):  # index of theta
                theta_i = theta_matrix[i_N]
                for j_Nd in range(Nd):  # index of distribution
                    f_j = cdf_matrix[j_Nd]
                    index_price = pricing_d2exp4(x_t, theta_i, f_j, Md, discrete_factor, bound_noise)
                    price_index_matrix[i_N, j_Nd] = index_price
                    if index_price == i_v_t:
                        prob_v_i += weight_of_experts[i_N, j_Nd] / W_t * (1 - gamma)
            hat_reward_t = v_t * ind / prob_v_i
            for i_N in range(N):
                for j_Nd in range(Nd):
                    index_price_ij = price_index_matrix[i_N, j_Nd]
                    if index_price_ij == i_v_t:
                        weight_of_experts[i_N, j_Nd] = weight_of_experts[i_N, j_Nd] * np.exp(
                            gamma * hat_reward_t / K_action)
            """monitor the process, as it is really time consuming"""
            if t % 100 == 0 and ifprint == 1:
                print("round = ", iround, ", t = ", t)
                """
                    Since it is a price rather than a theta that the agent choose,
                    we do not have such a theta here. Therefore, we do not print
                    a theta corresponding to each printed t.
                """
    """save the regret list"""
    if ifsave:
        with open("d2_exp4_numerical_demo.pkl", "wb") as d2exp4_rec:
            pk.dump(regret_original, d2exp4_rec)
    """plot regret curve"""
    # taking average
    average_d2_exp4 = np.zeros(T)
    for i_round in range(rounds):
        average_d2_exp4 += 1 / rounds * regret_original[:, i_round]
    # a simple linear regression
    if ifregression == 1:
        log_index_list = [np.log2(ix) for ix in range(start_point, T)]
        log_regret_list = [np.log2(iy) for iy in np.ndarray.tolist(average_d2_exp4[start_point:])]
        slope_d2, intercept_d2, r_value_d2, p_value_d2, std_err_d2 = stats.linregress(log_index_list, log_regret_list)
        asymptote_array_d2 = np.array([2 ** (slope_d2 * np.log2(x) + intercept_d2) for x in range(start_point, T)])
        plt.plot(np.arange(start_point, T), asymptote_array_d2, color="gray", linestyle="dotted", linewidth=1)
        print("D2-EXP4 log-linear regression (stochastic): log_2(y) = ", slope_d2, "log_2(x)+", intercept_d2, " .")
        print("D2-EXP4 sto R^2 = ", r_value_d2 ** 2, " .")
    # ploting
    if ifplot == 1:
        regret_average = np.sum(regret_original, axis=1) / rounds
        plt.plot(np.arange(start_point, T), regret_average[start_point:])
        plt.xscale("log", base=2)
        plt.yscale("log", base=2)
        plt.grid(True)
        plt.xlabel('round', fontsize=18)
        plt.ylabel('regret', fontsize=18)
        plt.title('Average cumulative regret for D2-EXP4')
        plt.savefig('./plot_d2_exp4_demo.pdf', bbox_inches='tight')
        plt.show()
    return regret_original[-1, :]
