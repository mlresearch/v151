function STu = Times_ST(D, L, k, u)
    if ~mod(k, 2)
        STu = D' * u;
        for i = 1:(k/2)
            STu = L*STu;
        end
    else
        STu = u;
        for i = 1:(k+1)/2
            STu = L*STu;
        end
    end  
end

