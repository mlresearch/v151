from config import args, TrainingConfing
from dataset import create_train_dataset, create_test_dataset
from network import create_network

from utils.misc import save_args, save_checkpoint, load_checkpoint
from training.train import eval_one_epoch
from loss import  Hamiltonian, CrossEntropyWithWeightPenlty
from training_function import train_one_epoch, FastGradientLayerOneTrainer

import torch
import json
import numpy as np

import torch.nn as nn
import torch.optim as optim
import os
import time

import pickle
import torch

RED = "\033[1;31m"
YELLOW = "\033[1;33m"


def pprint(stat):
    for key_idx, key in enumerate(stat.keys()):
        if key_idx + 1 != len(stat.keys()):
            end = ' ||'
        else:
            end = '\n'

        if type(stat[key]) is not float:
            print(RED, key, YELLOW, stat[key], end=end)
        else:
            print(RED, key, YELLOW, "{:.3f}".format(stat[key]), end=end)


def save(dataset, file):
    with open(file, 'wb') as fo:
        pickle.dump(dataset, fo)


def main(config):
    DEVICE = torch.device('cuda:{}'.format(args.d))
    torch.backends.cudnn.benchmark = True

    net = create_network()
    net.to(DEVICE)
    criterion = CrossEntropyWithWeightPenlty(net.other_layers, DEVICE, config.weight_decay)
    optimizer = config.create_optimizer(net.other_layers.parameters())
    lr_scheduler = config.create_lr_scheduler(optimizer)

    Hamiltonian_func = Hamiltonian(net.layer_one, config.weight_decay)
    layer_one_optimizer = optim.SGD(net.layer_one.parameters(), lr=lr_scheduler.get_lr()[0], momentum=0.9, weight_decay=5e-4)
    layer_one_optimizer_lr_scheduler = optim.lr_scheduler.MultiStepLR(layer_one_optimizer, milestones=[60], gamma=0.1)
    LayerOneTrainer = FastGradientLayerOneTrainer(Hamiltonian_func, layer_one_optimizer, config.inner_iters, config.sigma, config.eps)

    ds_train = create_train_dataset(args.batch_size)
    ds_val = create_test_dataset(10000)

    EvalAttack = config.create_evaluation_attack_method(DEVICE)

    now_epoch = 0

    if args.auto_continue:
        args.resume = os.path.join(config.model_dir, 'last.checkpoint')
    if args.resume is not None and os.path.isfile(args.resume):
        now_epoch = load_checkpoint(args.resume, net, optimizer,lr_scheduler)

    stats = []
    train_time = 0
    iteration = 0
    while True:
        if now_epoch == config.num_epochs:
            break
        now_epoch = now_epoch + 1
        comput_time = train_one_epoch(net, ds_train, optimizer, criterion, LayerOneTrainer, config.K, eps=config.eps, DEVICE=DEVICE)
        train_time += comput_time
        iteration += 400

        if config.val_interval > 0 and now_epoch % config.val_interval == 0:
            acc, pgd_20_test_acc, pgd_50_10_test_acc, advfgsm = eval_one_epoch(net, ds_val, DEVICE, EvalAttack, return_fgsm=True, eps=args.eps, is_last_iteration=now_epoch==config.num_epochs)
            stat = {
                'Method': 'YOPO',
                'Dataset': "MNIST",
                'eps': config.eps,
                'J': config.inner_iters,
                'K': config.K,
                'eta': None,
                'Trial': trial,
                'Iteration': iteration,
                'Time': train_time,
                'Test Acc.': acc,
                'FGSM Test Acc.': advfgsm,
                'PGD-20 Test Acc.': pgd_20_test_acc,
                'PGD-50-10 Test Acc.': pgd_50_10_test_acc,
                'Optimizer': "SGD+PiecewiseConstant",
                'Learning Rate': optimizer.param_groups[0]['lr'],
            }
            stats.append(stat)
            pprint(stat)

        lr_scheduler.step()
        layer_one_optimizer_lr_scheduler.step()

    return stats


if __name__ == '__main__':
    for trial in range(5):
        for eps in (0.4,):
            for K, J in ((10,5),):
                config = TrainingConfing(eps, K, J)
                stats = main(config)
                save(stats, 'results/yopo_{}_{}_{}.pickle'.format(K, J, trial))
