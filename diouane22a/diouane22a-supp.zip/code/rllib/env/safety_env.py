import gym


class DelayedCost(gym.Wrapper):
    def __init__(self, env):
        """Accumlate cost and give it in the end.
        """
        gym.Wrapper.__init__(self, env)
        self.total_cost = 0

    def step(self, action):
        obs, reward, done, info = self.env.step(action)
        cost = info['cost']
        self.total_cost += cost
        if done:
            info['constraint_costs'] = self.total_cost
            self.total_cost = 0
        else:
            info['constraint_costs'] = 0

        return obs, reward, done, info

    def reset(self, **kwargs):
        obs = self.env.reset(**kwargs)
        self.total_cost = 0
        return obs
