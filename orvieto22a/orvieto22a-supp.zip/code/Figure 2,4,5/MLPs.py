#######################################
#### Run experiments for Fig 1,2,3 ####
#######################################

# This script needs four inputs
# 1. model type in ['linear','non_linear']    <- ReLU or linear MLPs
# 2. xavier_init in [True,False]              <- Xavier/He or LeCun init
# 3. residual_connections [True,False]        <- Skip connections
# 4. narrow [True,False]                      <- If True: width=sqrt(depth), else width=depth

### For Figure 3 please change width=1 manually (marked below)

######################################
######################################
######################################

import sys
import torch
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import math


class linear_MLP(torch.nn.Module):
    def __init__(self, d_in,d_hidden,d_out,num_hidden_layers,xavier_init,residual_connections):
        super(linear_MLP, self).__init__()
        self.W_in = torch.nn.Linear(d_in, d_hidden,bias=False)
        self.hidden_layers=[]
        self.num_hidden_layers=num_hidden_layers

        for i in range(num_hidden_layers):
            self.hidden_layers+=[torch.nn.Linear(d_hidden,d_hidden,bias=False)]
        self.hidden_layers=torch.nn.Sequential(*self.hidden_layers)
        self.W_out = torch.nn.Linear(d_hidden, d_out,bias=False)
        
        if xavier_init:
            for p in self.parameters():
                if xavier_init:
                    torch.nn.init.xavier_uniform_(p, gain=1)
                else:
                    torch.nn.init.uniform_(p, a=-1/np.int(np.sqrt(len(p))), b=1/np.int(np.sqrt(len(p))))

    def forward(self, x):
        return self.W_out(self.hidden_layers(self.W_in(x)))


class non_linear_MLP(torch.nn.Module):
    def __init__(self, d_in,d_hidden,d_out,num_hidden_layers,xavier_init,residual_connections,act=torch.nn.ReLU(),,seed=None):
        super(non_linear_MLP, self).__init__()
        
        self.act=act
        self.W_in = torch.nn.Linear(d_in, d_hidden,bias=False)
        hidden_layers=[]
        self.num_hidden_layers=num_hidden_layers
        self.residual_connections=residual_connections

        for i in range(num_hidden_layers):
            hidden_layers+=[torch.nn.Linear(d_hidden,d_hidden,bias=False),torch.nn.BatchNorm1d(d_hidden),act]
        self.hidden_layers=torch.nn.Sequential(*hidden_layers)

        self.W_out = torch.nn.Linear(d_hidden, d_out,bias=False)

        if xavier_init:

            for m in self.modules():
                if isinstance(m, torch.nn.Linear):
                    if xavier_init:
                        torch.nn.init.kaiming_uniform_(m.weight, nonlinearity='relu') 
                    else:
                        torch.nn.init.uniform_(m.weight, a=-1/np.int(np.sqrt(len(m.weight))), b=1/np.int(np.sqrt(len(m.weight))))

           
    def forward(self, x):
        if not self.residual_connections:
            return self.W_out(self.hidden_layers(self.act(self.W_in(x))))
        else:
            x=self.W_in(x)
            for i in range(self.num_hidden_layers):
              if i==0:
                _x=x.clone()
              if i%3==0:
                x=self.hidden_layers[i](x)+_x
                _x=x.clone()
              else:
                x=self.hidden_layers[i](x)

            x=self.W_out(x)
            return x

def H_exact(model, data,target):
    loss_fn = torch.nn.MSELoss()
    loss = loss_fn(model(data), target)
        
    grad_dict = torch.autograd.grad(loss, model.parameters(), create_graph=True,allow_unused=True)
    
    grad_vec = torch.cat([g.contiguous().view(-1) for g in grad_dict])
    H = torch.ones((grad_vec.size(0), grad_vec.size(0))).double()

    for i, grad in enumerate(grad_vec):
        H_i_dict = torch.autograd.grad(grad, model.parameters(), retain_graph=True,allow_unused=True)
        H_i_vec = torch.cat([g.contiguous().view(-1) for g in H_i_dict])
        H[:, i] = H_i_vec
   
    return H,grad_vec

def main(model_type,residual_connections,xavier_init,narrow):
    global device
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    num_runs =10
    n=100
    depths=[2,6,14,30,62,126,256]

    loss_fn=torch.nn.MSELoss() 
    results=[]
    for i in range(num_runs):
      grads, h_diags, h_off_diags= [],[],[]  
      for depth in depths:

        if narrow:
            width=int(np.sqrt(depth))
        else:
            width=depth

        #width=1 #for Figure 3


        X=torch.randn(n,width).double().to(device)
        my_ground_truth_model=linear_MLP(width,width,width,1,xavier_init,residual_connections).double().to(device) if model_type=='linear' else non_linear_MLP(width,width,width,1,xavier_init,residual_connections).double().to(device)
        Y=my_ground_truth_model.forward(X)
        print(f"run: {i}, depth: {depth}")
        my_model=linear_MLP(width,width,width,depth,xavier_init,residual_connections).double().to(device) if model_type=='linear' else non_linear_MLP(width,width,width,depth,xavier_init,residual_connections).double().to(device)
        H,grad=H_exact(my_model,X,Y)

        print(f'grad_norm: {torch.mean(torch.abs(grad)).item()}')
        grads.append(torch.mean(torch.abs(grad)).item()), h_diags.append((torch.sum(torch.abs(torch.diag(H)))/H.shape[0]).item()), h_off_diags.append((torch.sum(torch.abs(H-torch.diag(H))/(H.shape[0]**2-H.shape[0])).item()))

      run_dict={'run_id': np.ones(len(grads),dtype=np.int8)*i,'grad':grads,'h_diag':h_diags,'h_off_diag': h_off_diags}
      results.append(pd.DataFrame(run_dict))

    results=pd.concat(results)
    results.to_pickle(f'{model_type}_width_{width}_xavier_{xavier_init}_residual_{residual_connections}_narrow_{narrow}.pkl')


if __name__ == "__main__":
    model_type=str(sys.argv[1])
    xavier_init=bool(sys.argv[2])
    residual_connections=bool(sys.argv[3])
    narrow=bool(sys.argv[4])
    main(model_type)