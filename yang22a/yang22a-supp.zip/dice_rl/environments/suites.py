
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from absl import app
from absl import flags

from tf_agents.environments.suite_gym import load as load_gym
from tf_agents.environments.suite_mujoco import load as load_mujoco
from tf_agents.environments.suite_dm_control import load as load_dm_control
