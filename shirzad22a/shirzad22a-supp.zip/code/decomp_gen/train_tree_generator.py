import argparse

from decomp_gen.models.incompleteTreeExtender import *
from decomp_gen.treeDataGenerator import *
from decomp_gen import configs

from decomp_gen.data_structures.dataset import GraphDataset, TreeGeneratorDataset

SEED = 1234
TRAIN_RATIO = 0.7
VAL_RATIO = 0.1
TEST_RATIO = 1.0 - TRAIN_RATIO - VAL_RATIO

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

EARLY_STOP_EPOCHS = 50

def parse():
    parser = argparse.ArgumentParser(description='')
    parser.add_argument('-f')
    parser.add_argument('--continue-training', type=bool, default=False)
    parser.add_argument('--model-name', type=str, default='tree_generator_tmp')
    parser.add_argument('--data-name', type=str, default='grid',
                        help='dataset to be built')
    parser.add_argument('--epochs', type=int, default=5000,
                        help='number of epochs for training')
    parser.add_argument('--batch-size', type=int, default=64,
                        help='size of the batches')
    parser.add_argument('--tree-hidden-size', type=int, default=128,
                        help='hidden size of tree nodes representations')
    parser.add_argument('--mlp-hidden-size', type=int, default=64)
    parser.add_argument('--num-mlp-hidden-layers', type=int, default=2)
    parser.add_argument('--num-workers', default=0, type=int)

    args = parser.parse_args()

    return args


args = parse()
data_name = args.data_name
epochs = args.epochs
batch_size = args.batch_size
hidden_size = args.tree_hidden_size
data = GraphDataset(args.data_name, '{}.dat'.format(args.data_name))
mlp_sizes = [args.mlp_hidden_size] * args.num_mlp_hidden_layers


# treeRandomFeatures=32

eps=1e-7

def negative_log_likelihood(output, y):
    y = torch.tensor(y).to(device)
    tmp = -(torch.log(output.gather(1, y.view(-1, 1))))
    if torch.isnan(tmp).any():
        print('in loss: ')
        breakpoint()

    tmp = tmp.sum()

    return tmp


def evaluate(model, validation):
    totalNLL = torch.tensor([0.0])
    for i in range(0, len(validation), batch_size):
        j = min(i + batch_size, len(validation))

        trees = []
        extendingNodes = []
        Masks = []
        y = []
        for x in range(i, j):
            trees.append(validation[x]['T'])
            extendingNodes.append(validation[x]['CurrentNode'])
            Masks.append(validation[x]['Mask'])
            y.append(validation[x]['l'])

            mask = Masks[-1]
            tree = trees[-1]
            l = y[-1]
            if (mask[l] < 1.0):
                print("Problem with limit finder")
                nx.draw(tree.to_networkx(), with_labels=True)
                print("Extending Node: ", extendingNodes[-1])

        Masks = torch.tensor(Masks)
        Masks = cuda(Masks)

        output = model(trees, extendingNodes, Masks)
        nll = negative_log_likelihood(output, y)
        totalNLL += nll.data.detach()
        del trees, extendingNodes, Masks, y

    # print('total nll in evaluation: ', totalNLL, '  len evaluation: ', len(validation))
    return totalNLL, totalNLL / len(validation)


def collate(samples):
    batch = {
        'trees': list(),
        'extending_nodes': list(),
        'masks': list(),
        'target': list()
    }

    for sample in samples:
        batch['trees'].append(sample['T'])
        batch['extending_nodes'].append(sample['CurrentNode'])
        batch['masks'].append(torch.tensor(sample['Mask']).view(1, -1))
        batch['target'].append(sample['l'])

    batch['masks'] = torch.cat(batch['masks'], dim=0)

    return batch


def trainTreeModel(model, train_dataset, eval_dataset, model_name, num_train_graphs, num_eval_graphs, checkpoint=None):
    best_loss = torch.tensor(1000.0).to(device)

    adr = os.path.join(configs.root_dir, 'saved_models', model_name)
    adr_state_dict = os.path.join(configs.root_dir, 'saved_models', model_name + '_state_dict')
    print("Saving model to: ", adr)

    # data_loader = torch.utils.data.DataLoader(train_dataset,
    #                                           batch_size=args.batch_size, shuffle=True,
    #                                           num_workers=args.num_workers, collate_fn=collate,
    #                                           pin_memory=True)

    optimizer = torch.optim.Adam(model.parameters(), lr=0.0005, betas=(0.9, 0.999), eps=1e-08, weight_decay=0,
                                 amsgrad=False)

    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=25,
                                                           threshold=0.01, threshold_mode='rel', cooldown=0,
                                                           min_lr=0.0001, eps=1e-08, verbose=True)

    start_epoch = 0

    if checkpoint is not None:
        optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        scheduler.load_state_dict(checkpoint['scheduler_state_dict'])
        start_epoch = checkpoint['epoch'] + 1
        best_loss = checkpoint['best_loss']

    early_stop_counter = 0

    for epoch in range(start_epoch, epochs):
        model.train()
        print("epoch: ", epoch)
        epoch_nll = torch.tensor([0.0]).to(device)
        cnt = 0
        # for i, batch in enumerate(data_loader):
        for i, ii in enumerate(range(0, len(train_dataset), batch_size)):
            jj = min(ii+batch_size, len(train_dataset))
            batch = collate( train_dataset[ii:jj])

            optimizer.zero_grad()
            output = model(batch['trees'], batch['extending_nodes'], batch['masks'])
            nll = negative_log_likelihood(output, batch['target'])
            nll.backward()
            # print('grad after calculations: ')
            # print(model.treeEncoder.enc_tree_update.W_z.weight.grad)
            optimizer.step()

            epoch_nll += nll.data.detach()
            cnt += len(batch['extending_nodes'])
            if i % 20 == 0 and i > 0:
                print("average nll till batch ", i, "=", epoch_nll.item() / cnt)

        epoch_avg_nll = epoch_nll.data.detach() / len(train_dataset)
        print("epoch average nll: ", epoch_avg_nll)
        print("train average per graph nll: ", epoch_nll / num_train_graphs)
        print("epoch total nll: ", epoch_nll)


        eval_total_nll, eval_avg_nll = evaluate(model, eval_dataset)

        print("eval average nll: ", eval_avg_nll)
        print("eval average per graph nll: ", eval_total_nll / num_eval_graphs)
        print("eval total nll: ", eval_total_nll)

        early_stop_counter += 1

        if eval_avg_nll < best_loss:
            best_loss = eval_avg_nll.data.detach()
            torch.save(model, adr)
            torch.save({
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'scheduler_state_dict': scheduler.state_dict(),
                'best_loss': best_loss
            }, adr_state_dict)

            early_stop_counter = 0

        print('best nll: ', best_loss)

        scheduler.step(epoch_avg_nll)

        if early_stop_counter >= EARLY_STOP_EPOCHS:
            return


def get_tree_nll(TPLR, model):
    MaskLen = model.MaskLen
    MaskLenForData = MaskLen
    GT = GeneratingTree()
    NLL = torch.tensor([0.0])
    count = 0
    for l in TPLR:
        T = GT.getSimpleTree()
        DGLT = [dgl.DGLGraph(T)]

        # p = nx.shortest_path_length(T, source=0)
        # for v in DGLT.nodes():
        #     vv = int(v.item())
        #     d = torch.zeros((1, 2 * MaskLen))
        #     height = TPLR[0] - p[vv]
        #     # d[0][p[vv]]=1.0
        #     # if vv > 0:
        #     #     d[0][MaskLen+height] = 1.0
        #     DGLT.nodes[[v]].data['d'] = d

        limits = GT.nextStepLimit()

        mask = [0.0] * MaskLenForData
        if limits[1] == -1:
            limits[1] = MaskLenForData
        for i in range(limits[0], limits[1]):
            mask[i] = 1.0

        extendingNodes = [GT.currentNode().getLabel()]
        Masks = [mask]

        Masks = torch.tensor(Masks)
        Masks = cuda(Masks)

        y = [l]
        # Making dataset just for times we want to make choice:
        if limits[1] - limits[0] > 1:
            output = model(DGLT, extendingNodes, Masks)
            nll = negative_log_likelihood(output, y, Masks)
            NLL += nll
            count += 1
        GT.makeStep(l)

    return NLL, NLL / count


def main():
    name = "{}_tree_generator".format(data_name)
    if data_name == 'lobster':
        # graphs, MaxLen = create_graphs('lobster',num_graphs=sampleCnt)
        graphs = data.graphs
        MaxLen = data.max_tree_diam

        print("MaxLen: ", MaxLen)
        trainData, validationData, testData, MaskLenForData = getTreeDataSet(graphs=graphs, samplePerGraph=1,
                                                                             MaxLen=MaxLen, name=name,
                                                                             makeFromTree=True)
        print('len train data: ', len(trainData))
        print('len eval data: ', len(validationData))
    else:
        # graphs,graphsMaxLen = getGraphDataset(data_name=data_name, graph_type='simple',numberOfSamples=sampleCnt,start=start,name=name)
        graphs = data.graphs
        graphsMaxLen = data.max_tree_diam

        trainData, validationData, testData, MaskLenForData = getTreeDataSet(graphs=graphs, samplePerGraph=5,
                                                                             MaxLen=graphsMaxLen, name=name)

    model = incompleteTreeExtender(hidden_size, MaskLen=MaskLenForData, mlp_sizes=mlp_sizes, max_node_size=data.N)

    checkpoint = None

    train_dataset = TreeGeneratorDataset(trainData)
    eval_dataset = TreeGeneratorDataset(validationData)
    test_dataset = TreeGeneratorDataset(testData)



    if args.continue_training:
        print('loading model to continue training ....')
        adr = os.path.join(configs.root_dir, 'saved_models', args.model_name + '_state_dict')
        # model = torch.load(adr, map_location=device)
        try:
            checkpoint = torch.load(adr)
            model.load_state_dict(checkpoint['model_state_dict'])
        except:
            print('state dict not found trying to load model . . .')
            adr = os.path.join(configs.root_dir, 'saved_models', args.model_name)
            model = torch.load(adr, map_location=device)


    model = model.to(device)

    print('len train/validation: ', len(trainData), len(validationData))
    # breakpoint()

    try:
        trainTreeModel(model, train_dataset, eval_dataset, args.model_name,
                   len(trainData), len(validationData), checkpoint)
    except:
        print('\ntrain finished')

    adr = os.path.join(configs.root_dir, 'saved_models', args.model_name)
    best_model = torch.load(adr, map_location=device)

    total_nll, avg_nll = evaluate(best_model, test_dataset)
    print('test nll/graph', total_nll / (len(data) * TEST_RATIO))

    total_nll, avg_nll = evaluate(best_model, train_dataset)
    print('train nll/graph', total_nll/(len(data)*TRAIN_RATIO))

    # total_nll, avg_nll = evaluate(best_model, eval_dataset)
    # print('val nll/graph', total_nll / (len(data) * VAL_RATIO))




if __name__ == "__main__":
    main()
