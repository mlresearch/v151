
function [regrets_track, arm_track] = r_gp_ucb(H, B,f_test,kernel,T,lambda,epsilon,R,max_value)
   
        %H = 250;

        %H = 2* H;
        [~, arms] = size(f_test(1,:));
        %[max_value,max_arm] = max(f_test);
        %kernel_t = kernel;
        mu_t = zeros(arms,1); sigma2_t = zeros(arms,1);
        
        regrets_cumula = 0;
        regrets_track = zeros(T,1);

        rewards_cumula = 0;
        rewards_track = zeros(T,1);
        
        arm_track = zeros(T,1);
        y_track = zeros(T,1);
        
        num_func = size(B,1);
        iter_func = 0;
        

        
        for t = 1 : T   
            
                iter_func = iter_func+1;
                
                if mod(t,H) == 0
                    t1 = H;
                else
                    t1 = mod(t,H);
                end
                    
                
                gamma_t =  log(t1);  % x_t only 1 dimension
                
                beta_t = B(iter_func,1)+   R/sqrt(lambda) *sqrt(2* gamma_t + 2);   %%%?
                if t1 == 1
                    arm_t = randi(arms);
                    mu_t = zeros(arms,1); sigma2_t = zeros(arms,1);
                else
                    [~,arm_t] = max( mu_t +  beta_t*sqrt(sigma2_t) );
                end
                arm_track(t) = arm_t;
                
                rewards_cumula = rewards_cumula + f_test(iter_func,arm_t);
                rewards_track(t) = rewards_cumula;
                               
                
                regrets_cumula = regrets_cumula + max_value(iter_func) - f_test(iter_func,arm_t);
                regrets_track(t) = regrets_cumula;

                noise = randn;  %sub-gaussian  normal 
                y_t = f_test(iter_func,arm_t) + epsilon*noise;
                y_track(t) = y_t;

                
                y1t = y_track(t- t1 + 1 : t);
                
                ktx = zeros(t1, arms);
                Kt = zeros(t1, t1);
                for i = 1 : t1
                    ktx(i, :) = kernel(arm_track(t-t1+i),:);
                    for j = 1 : t1
                        Kt(i,j) = kernel(arm_track(t-t1+i), arm_track(t-t1+j));
                    end
                end
                
                for k = 1 : arms
                    mu_t (k) = transpose( ktx(:, k) ) * inv(Kt + lambda*eye(t1))* y1t;
                    sigma2_t(k) = kernel(k,k) - transpose( ktx(:, k) )* inv(Kt + lambda*eye(t1)) * ktx(:, k);
                end
                

                
            
        end
end
