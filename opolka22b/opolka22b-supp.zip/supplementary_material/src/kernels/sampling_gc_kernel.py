import numpy as np
import gpflow
from gpflow import Parameter
from gpflow import covariances as cov
import tensorflow as tf
import tensorflow_probability as tfp

from inducing_points import NodeInducingPoints


class SamplingGraphConvolutional(gpflow.kernels.base.Kernel):

    def __init__(self, base_kernel, sparse, num_convs):
        super().__init__([1])
        self.base_kernel = base_kernel
        self.sparse = sparse
        self.num_convs = num_convs
        self.weights = [Parameter(np.array([(1.0/(i+2.0))]),
                                  transform=tfp.bijectors.Sigmoid(),
                                  name=f"weight_{i+1}")
                        for i in range(num_convs)]

        # Setup for sparse vs dense operations
        if sparse:
            self.matmul_f = tf.sparse.sparse_dense_matmul
            self.eye_f = tf.sparse.eye
            self.add_f = tf.sparse.add
        else:
            self.matmul_f = tf.matmul
            self.eye_f = tf.eye
            self.add_f = tf.add

        self.conv_mat = None

    def set_subgraph(self, conv_matrix):
        self.conv_mat = conv_matrix
        if self.sparse is False:
            self.conv_mat = tf.sparse.to_dense(tf.sparse.reorder(conv_matrix))

    def K(self, X, Y=None, presliced=False):
        """
        X are node features of the current subgraph of shape (N, D).
        :return: Covariance matrix of shape (N, N).
        """
        assert Y is None, "Unexpected argument Y"
        cov = self.base_kernel.K(X)
        for i in range(self.num_convs):
            conv_mat = self.add_f(self.weights[i] * self.conv_mat,
                                  (1.0 - self.weights[i]) * self.eye_f(self.conv_mat.shape[0]))
            cov = self.matmul_f(conv_mat, cov)
            cov = self.matmul_f(conv_mat, cov, adjoint_b=True)
        return cov

    def K_diag(self, X, presliced=False):
        return tf.linalg.diag_part(self.K(X))

    def Kzx(self, Z, X):
        """
        Z are the inducing points of shape (M, D) and X are the node features
        of the current subgraph of shape (N, D).
        :return: Covariance matrix of shape (M, N).
        """
        cov = self.base_kernel.K(X, Z)
        for i in range(self.num_convs):
            conv_mat = self.add_f(self.weights[i] * self.conv_mat,
                                  (1.0 - self.weights[i]) * self.eye_f(self.conv_mat.shape[0]))
            cov = self.matmul_f(conv_mat, cov)
        return tf.transpose(cov)

    def Kzz(self, Z):
        cov = self.base_kernel.K(Z)
        return cov


@cov.Kuu.register(NodeInducingPoints, SamplingGraphConvolutional)
def Kuu_graph_polynomial(inducing_variable, kernel, jitter=None):
    """
    Computes the covariance matrix between the inducing points (which are not
    associated with any node).
    :param inducing_variable: Set of inducing points of type
    NodeInducingPoints.
    :param kernel: Kernel of type GraphPolynomial.
    :return: Covariance matrix between the inducing variables.
    """
    return kernel.Kzz(inducing_variable.Z)


@cov.Kuf.register(NodeInducingPoints, SamplingGraphConvolutional, tf.Tensor)
def Kuf_graph_polynomial(inducing_variable, kernel, X):
    """
    Computes the covariance matrix between inducing points (which are not
    associated with any node) and normal inputs.
    :param inducing_variable: Set of inducing points of type
    NodeInducingPoints.
    :param kernel: Kernel of type GraphPolynomial.
    :param X: Normal inputs. Note, however, that to simplify the
    implementation, we pass in the indices of the nodes rather than their
    features directly.
    :return: Covariance matrix between inducing variables and inputs.
    """
    return kernel.Kzx(inducing_variable.Z, X)
