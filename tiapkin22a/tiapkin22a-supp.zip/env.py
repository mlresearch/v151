import numpy as np
import scipy as sp
from scipy import optimize
from scipy import stats

def generate_pi(n_action, n_state, seed):
    """
    function to generate policy,
    inputs:
        N_a - number of actions;
        N_s - number of states;
    outputs:
        pi(a|s) - np.array of shape N_a x N_s
    """
    np.random.seed(seed)
    Pi_matr = np.random.uniform(0.0,1.0,(n_action, n_state))
    norm_coef = Pi_matr.sum(axis=0)
    Pi_matr = Pi_matr / norm_coef.reshape((1, n_state))
    return Pi_matr


class BaseEnvironment:
    def __init__(self):
        '''
            Base class of RL-environment
            Fields:
                n_state : number of states of MDP
                n_action : number of actions of MDP
                P : tensor of transitions p(s'|s,a) of size (n_state, n_state, n_action)
                R : matrix of deterministic rewards r(a,s) of size (n_state, n_action)
        '''
        self.n_state = None
        self.n_action = None
        self.P = None
        self.R = None
    
    def step(self, state, action, n_samples=1):
        '''
            Make one step corresponds to dynamics of MDP
            Args:
                state - current state
                action - current action
            Returns: next state s'
        '''
        return np.random.choice(self.n_state, p=self.P[:,state,action], size=n_samples)
   

    def state_transitions(self, policy, greedy=False):
        '''
            Return state transition matrix P_s = p_policy(s' | s)
            Args:
                policy: if greedy, vector of size (n_state)
                        else: matrix of size (n_state, n_action)
            returns:
                matrix of size (n_state, n_state)
        '''
        P_s = np.zeros((self.n_state, self.n_state),dtype = float)
        for i in range(self.n_state):
            for j in range(self.n_state):
                if greedy:  
                    P_s[i,j] = self.P[i,j,policy[j]]
                else:
                    P_s[i,j] = np.dot(self.P[i,j,:], policy[:,j])
        return P_s 
    
    def state_reward(self, policy, greedy=False):
        '''
            Return state reward vector r = p_policy(s)
            Args:
                policy: if greedy, vector of size (n_state)
                        else: matrix of size (n_state, n_action)
            returns:  P_true[s, 1][min(nState - 1, s + 1)] = 0.35
            P_true[s, 1][s] = 0.6
            P_true[s, 1][max(0, s-1)] = 0.05

                vector of size (n_state)
        '''
        r = np.zeros(self.n_state, dtype = float)
        for i in range(self.n_state):
            if greedy:
                r[i] = self.R[policy[i], i]
            else:
                r[i] = np.dot(self.R[:,i], policy[:, i])
        return r

    def mixing_time(self, n_samples):
        '''
            Compute approximation of mixing time on random policies
        '''
        def compute_mixing_time(S_trans):
            t_mix = 0
            _, v = np.linalg.eig(S_trans)
            nu_pi = np.real(v[:, np.isclose(_, 1)]).flatten()
            nu_pi /= np.sum(nu_pi)

            for i in range(self.n_state):
                ei = np.zeros(self.n_state)
                ei[i] = 1
                t = 0
                while np.linalg.norm(ei - nu_pi, 1) >= 1/2:
                    ei = S_trans @ ei
                    t += 1
                t_mix = max(t, t_mix)
            return t_mix
     
        t_mix = 0
            
        for k in range(n_samples):
            policy = generate_pi(self.n_action, self.n_state, k)
            S_trans = self.state_transitions(policy)
            t_mix = max(t_mix, compute_mixing_time(S_trans))
        return t_mix
    
    def amdp_value(self, policy, greedy=False):
        '''
            Computes AMDP value of policy 
            Args:
                policy: if greedy, vector of size (n_state)
                        else: matrix of size (n_state, n_action)
            returns:
                v_pi - amdp-value of policy
        '''
        S_trans = self.state_transitions(policy, greedy)
        r = self.state_reward(policy, greedy)
        _, v = np.linalg.eig(S_trans)
        nu_pi = np.real(v[:, np.isclose(_, 1)])[:,0]
        nu_pi /= np.sum(nu_pi)
        return np.dot(nu_pi, r)
    
    def amdp_solve(self):
        '''
            Solves AMDP problem using LP solver
            Returns: v_star
        '''
        A_tot = self.n_action * self.n_state
        c = np.zeros(1 + self.n_state)
        c[0] = 1

        hat_I = np.zeros((self.n_state, self.n_state, self.n_action))
        for i in range(self.n_state):
            for a in range(self.n_action):
                hat_I[i,i,a] = 1
        hat_I = hat_I.reshape(self.n_state, A_tot).T
        hat_P = self.P.reshape(self.n_state, A_tot).T

        b_ub = -self.R.T.reshape(A_tot)
        A_ub = -np.concatenate((np.ones(A_tot)[:, None], hat_I - hat_P), axis=1)

        return optimize.linprog(c, A_ub=A_ub, b_ub=b_ub, bounds=(None,None)).x[0]

    
class EmpiricalMDP(BaseEnvironment):
    def __init__(self, MDP, n_samples):
        '''
            Class of empirical MDP
            Args:
                MDP: instance of derived class of BaseEnvironment
                n_samples: number of samples per state-action pair
        '''
        self.n_state = MDP.n_state
        self.n_action = MDP.n_action
        self.P = np.zeros((self.n_state, self.n_state, self.n_action))
        for s in range(self.n_state):
            for a in range(self.n_action):
                samples = MDP.step(s, a, n_samples)
                for s_prime in samples:
                    self.P[s_prime,s,a] += 1
        self.P /= n_samples
        self.n_samples = np.ones((self.n_state, self.n_action)) * n_samples
        
        self.R = MDP.R.copy()
    
    def update(self, state, action, state_next):
        '''
            Updates empirical MDP according to the observation
        '''
        self.P[:, state, action] *= self.n_samples[state, action]
        self.n_samples[state, action] += 1
        self.P[state_next, state, action] += 1
        self.P[:, state, action] /= self.n_samples[state, action]


class Garnet(BaseEnvironment):
    def __init__(self, n_state, n_action, branching_factor, seed):
        np.random.seed(seed)
        self.n_state = n_state
        self.n_action = n_action
        
        inds_nonzero = np.zeros((n_state, n_action, branching_factor),dtype = int)
        for i in range(n_state):
            for j in range(n_action):
                inds_nonzero[i,j] = np.random.choice(n_state, size=branching_factor, replace=False)
        self.P = np.zeros((n_state, n_state, n_action),dtype=float)
        for i in range(n_state):
            for j in range(n_action):
                self.P[inds_nonzero[i,j],i,j] = np.random.uniform(0.0,1.0,branching_factor)
        norm_coef = self.P.sum(axis=0)
        
        self.P = self.P / norm_coef.reshape((1, n_state, n_action))
        self.R = np.random.uniform(0.0,1.0,(n_action,n_state))
    
    
class AccessControl(BaseEnvironment):
    def __init__(self, n_servers, priorities, free_prob):
        n_prior = priorities.shape[0]
        self.n_state = (n_servers + 1) * n_prior
        self.n_action = 2 
        
        self.R = np.zeros((2, n_servers + 1, n_prior))
        for serv in range(1, n_servers+1):
            self.R[1, serv, :] = priorities

        self.R = self.R.reshape((self.n_action, self.n_state))
        
        self.P = np.zeros((n_servers + 1, n_prior, n_servers + 1, n_prior, 2))
        unif = np.ones((n_prior, n_prior)) / n_prior
        
        for n in range(1, n_servers+1):
            n_busy = n_servers - n
            for k in range(0, n_busy + 1):
                prob = sp.stats.binom.pmf(k, n_busy, free_prob)
                self.P[n+k, :, n, :, 0] = unif.copy() * prob
                self.P[n+k-1, :, n, :, 1] = unif.copy() * prob
        
        n_busy = n_servers
        for k in range(0, n_busy + 1):
            prob = sp.stats.binom.pmf(k, n_busy, free_prob)
            self.P[k, :, 0, :, 0] = unif.copy() * prob
            self.P[k, :, 0, :, 1] = unif.copy() * prob

        self.P = self.P.reshape((self.n_state, self.n_state, self.n_action))
            
    
class RiverSwim(BaseEnvironment):
    def __init__(self, n_state=6, left_reward=0.005, right_reward=1.):
        self.n_state = n_state
        self.n_action = 2
        
        self.R = np.zeros((2, n_state))
        self.R[0,0] = left_reward
        self.R[1, n_state-1] = right_reward
        
        self.P = np.zeros((n_state, n_state, 2))
        for s in range(n_state):
            self.P[max(s-1, 0), s, 0] = 1.
            
        for s in range(1, n_state-1):
            self.P[s + 1, s, 1] = 0.35
            self.P[s, s, 1] = 0.6
            self.P[max(0, s-1), s, 1] = 0.05
        
        self.P[0,0,1] = 0.6
        self.P[1,0,1] = 0.4
        self.P[n_state - 1, n_state-1, 1] = 0.6
        self.P[n_state - 2, n_state-1, 1] = 0.4
            