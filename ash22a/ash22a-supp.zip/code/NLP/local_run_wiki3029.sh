python3.7 src/experiments/train_with_nce.py --num_classes 200 --k 10 --batch_size 100 --hidden_dim 400 --name wik3029_nce --task wiki-3029 --seed 1236 --data_path ./cache --loss log_loss_batch --no_collision -1 --model linear

