import argparse
import os

import torch
import yaml

from src import get_module_logger
from src.data.dataloader4img import mydataloader
from src.models.predict_model4img import evaluate
from src.utils.model_rnn import prepare_trained_rnn


def main():
    logger = get_module_logger("predict")
    logger.debug("Begin...")
    parser = argparse.ArgumentParser()
    parser.add_argument("--wts_path", type=str, default="model/best_wts/state_dict.pth", help="")
    args = parser.parse_args()

    # Evaluation preparations
    wts_path = args.wts_path
    logger.info("Model to be evaluated = %s" % wts_path)
    # Load configure yaml
    cfg = os.path.join(*wts_path.split("/")[:-2], "config.yaml")
    with open(cfg, "r") as f:
        data = yaml.load(f, Loader=yaml.SafeLoader)
    for key in data:
        args.__setattr__(key, data[key])
    logger.debug(args)

    # Model parameters
    # hidden_size = args.hidden_size
    # output_size = args.output_size
    m_CS = args.m_CS if hasattr(args, "m_CS") else None
    irnn = args.irnn

    # Learning parameters
    batch_size = args.batch_size

    # Dataset parameters
    dataset = args.dataset
    task = args.task
    data_dir = args.data_dir
    # _, input_size = calc_input_sizes(dataset, task)

    # Prepare dataloader
    _, test_dl = mydataloader(dataset=dataset, task=task, data_dir=data_dir, batch_size=batch_size)
    logger.debug("Datasets are loaded.")

    # Check device
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    if torch.cuda.is_available():
        torch.backends.cudnn.benchmark = True
    logger.debug("GPU or CPU: %s" % device)

    # Evaluate accuracy of RNN classifier
    model = prepare_trained_rnn(torch.load(wts_path, map_location=device), irnn=irnn, requires_grad=False, m_sharp=m_CS)
    logger.debug("--Begin Evaluation--")
    acc = evaluate(model, test_dl, device=device)
    logger.info("Test Acc: {:.4f}".format(acc))
    logger.debug("--Finished Evaluation--")

    logger.debug("Done!!")


if __name__ == "__main__":
    main()
