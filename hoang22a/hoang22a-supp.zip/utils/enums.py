import enum


class Losses(enum.Enum):
    """
    Defines all the losses we currently support
    """
    ContrastiveLossV1 = 1
    BinaryCrossEntropy = 2


class ContainerType(enum.Enum):
    """
    Defines all batch-loader types we currently support
    """
    PairLoader = 1


class Activations(enum.Enum):
    """
    Lists all the activations we currently support
    """
    relu = 1
    sigmoid = 2
    tanh = 3


class Optimizers(enum.Enum):
    """
    Lists all the optimizers we currently support
    """
    adam = 1
    adagrad = 2


class DataMode(enum.Enum):
    """
    Lists all modes of data we currently support
    """
    train = 1
    validate = 2
    test = 3

class DataType(enum.Enum):
    """
    Lists all types of data we currently support
    """
    Interaction = 1
    ItemFeature = 2
    UserFeature = 3


class TestMode(enum.Enum):
    """
    Lists all test modes we currently support
    """
    COLD = 1
    WARM = 2
    MIXED = 3