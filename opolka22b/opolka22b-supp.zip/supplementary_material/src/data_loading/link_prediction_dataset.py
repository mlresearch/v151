import math
import pathlib
import pickle as pk
import numpy as np
import tensorflow as tf
import scipy.sparse as sp
from torch_geometric import datasets

from data_loading.data_utils import subsample_neighbors, get_adj_list_matrix, \
    get_subgraph_matrix, get_subgraph_matrix_sparse, \
    _generate_node2vec_embeddings
from utils import dense_matrix_to_sparse_matrix, get_conv_matrix, normalize_adj, \
    sparse_matrix_to_parts


class LinkPredictionDataset:

    def __init__(self, dataset_path, dataset_name, dataset_folder, split_seed,
                 train_batch_size, test_batch_size, subsample_sizes=None,
                 extract_subgraphs=True, node2vec_embeddings=False,
                 float_type=np.float64, test_fraction=0.1, pert_frac=None,
                 missing_frac=None, train_set_frac=None):
        """

        :param dataset_path: Path to a dataset in the file system. Only
        either dataset_path or dataset_name must be None.
        :param dataset_name: Name of a dataset that can be loaded via pytorch
        geometric.
        :param dataset_folder: Where to store the raw data of a dataset loaded
        via pytorch geometric.
        :param split_seed: Seed for a random state used to split the data into
        training and validation set.
        :param train_batch_size: Size of a mini-batch for the training set.
        :param test_batch_size: Size of a mini-batch for the test set.
        :param extract_subgraphs: If True, the data loaders will extract
        the relevant subgraphs for each batch of edges and next to the edges
        and labels will also return the corresponding convolution matrix among
        others.
        :param node2vec_embeddings: If True, node2vec embeddings are used as
        node features.
        :param float_type:
        :param test_fraction: Fraction r of existing links that are removed
        from graph to form the testing set. Overall, we use r of the existing
        links as positive test samples and then select the same number of node
        pairs without edges between them as negative test samples.
        :param pert_frac: Flips pert_frac * num_edges many entries in the
        adjacency matrix.
        :param missing_frac: Probability of each feature being replaced by
        a zero vector.
        :param train_set_frac: If not None, only the specified fraction of
        training samples is used.
        """
        rstate = np.random.RandomState(split_seed)

        # Load raw data. Adjacency information for an undirected graph without
        # self-loops.
        raw_data = LinkPredictionDataset._load_raw_data(
            dataset_path, dataset_name, dataset_folder)
        adj_idcs, node_features, edge_features = raw_data

        # Dataset statistics
        num_edges = adj_idcs.shape[0]
        num_nodes = (node_features.shape[0] if node_features is not None
                     else np.max(adj_idcs) + 1)
        num_pos_edges = int(math.ceil(test_fraction * float(num_edges)))
        print(f"#nodes: {num_nodes}")
        print(f"#edges: {num_edges}")

        # Create sparse adjacency matrix
        adj_matrix = sp.csr_matrix((np.ones(num_edges),
                                    (adj_idcs[:, 0], adj_idcs[:, 1])),
                                   shape=(num_nodes, num_nodes))
        adj_matrix += adj_matrix.T

        # Find data set split into training and test set.
        split = LinkPredictionDataset._get_dataset_split(
            adj_matrix, adj_idcs, num_nodes, num_edges, num_pos_edges, rstate,
            train_set_frac)
        pos_test_edges, neg_test_edges, pos_train_edges, neg_train_edges = split
        num_train_samples = len(pos_train_edges) + len(neg_train_edges)
        num_test_samples = len(pos_test_edges) + len(neg_test_edges)

        # Remove positive test samples from the adjacency matrix
        adj_matrix[pos_test_edges[:, 0], pos_test_edges[:, 1]] = 0.0
        adj_matrix[pos_test_edges[:, 1], pos_test_edges[:, 0]] = 0.0
        adj_matrix.eliminate_zeros()

        # Generate node2vec node features if explicitly required or no other
        # node features available
        if node2vec_embeddings or node_features is None:
            embeddings = _generate_node2vec_embeddings(
                adj_matrix, 128, True, neg_train_edges)
            node_features = embeddings

        # If specified, add perturbed edges
        if pert_frac is not None:
            adj_matrix = LinkPredictionDataset._perturb_graph(
                adj_matrix, pert_frac, num_edges)

        # If specified, set some node features to 0.
        if missing_frac is not None:
            zero_idcs = rstate.choice(num_nodes,
                                      int(num_nodes * missing_frac))
            node_features[zero_idcs] = 0.0

        # For data loading, the adjacency matrix requires self-loops.
        adj_matrix[np.diag_indices(adj_matrix.shape[0])] = 1.0

        # Assign attributes
        self.adj_idcs, _ = sparse_matrix_to_parts(adj_matrix)
        self._subsample_sizes = subsample_sizes
        self._extract_subgraphs = extract_subgraphs
        self._float_type = float_type
        self._tf_float_type = tf.float64 if float_type == np.float64 else tf.float32
        self.num_nodes, self.num_edges = num_nodes, num_edges
        self.num_train_samples = num_train_samples
        self.num_test_samples = num_test_samples
        self.pos_test_edges = pos_test_edges
        self.neg_test_edges = neg_test_edges
        self.pos_train_edges = pos_train_edges
        self.neg_train_edges = neg_train_edges
        self.node_features = node_features.astype(float_type)
        self.edge_features = None
        if self.edge_features is not None:
            self.edge_features = edge_features.astype(float_type)
        # Variables filled on a per-need basis
        self.subgraph_mat_idcs = None
        self.conv_mat_idcs = None
        self.conv_mat_vals = None
        self.adj_list_matrix = None

        if pert_frac is None:
            assert np.all(adj_matrix[self.pos_train_edges[:, 0].astype(np.int), self.pos_train_edges[:, 1].astype(np.int)] > 0.0)
            assert np.all(adj_matrix[self.neg_train_edges[:, 0].astype(np.int), self.neg_train_edges[:, 1].astype(np.int)] < 1e-5)
            assert np.all(adj_matrix[self.pos_test_edges[:, 0].astype(np.int), self.pos_test_edges[:, 1].astype(np.int)] < 1e-5)
            assert np.all(adj_matrix[self.neg_test_edges[:, 0].astype(np.int), self.neg_test_edges[:, 1].astype(np.int)] < 1e-5)
        assert np.sum(np.absolute(adj_matrix - adj_matrix.T)) < 1e-4

        self.train_loader, self.test_loader = self._create_data_loaders(
            train_batch_size, test_batch_size, adj_matrix, 2)
        del adj_matrix

    def get_adj_matrix(self):
        """
        Returns the full adjacency matrix of the data set as a sparse SciPy
        csr_matrix.
        """
        adj_matrix = sp.csr_matrix((np.ones(self.adj_idcs.shape[0]),
                                    (self.adj_idcs[:, 0], self.adj_idcs[:, 1])),
                                   shape=(self.num_nodes, self.num_nodes))
        return adj_matrix

    def get_conv_matrix(self):
        """
        Returns the full convolution matrix of the data set as a sparse SciPy
        csr_matrix.
        """
        adj_matrix = self.get_adj_matrix()
        return get_conv_matrix(adj_matrix, self._float_type, scipy_sparse=True)

    @staticmethod
    def _perturb_graph(adj_matrix, pert_frac, num_edges):
        """
        Randomly flips a set of entries in the adjacency matrix. Note that the
        fraction might not be exact as some entries might randomly be sampled
        multiple times and diagonal entries are not flipped.
        """
        adj_matrix = adj_matrix.todense()
        num_perturb = math.ceil(pert_frac * num_edges)
        num_nodes = adj_matrix.shape[0]
        origins = np.random.choice(num_nodes, num_perturb)
        destinations = np.random.choice(num_nodes, num_perturb)
        # Only flip non-diagonal edges
        non_diag = np.where(origins != destinations)
        origins, destinations = origins[non_diag], destinations[non_diag]
        # Flip edges
        adj_matrix[origins, :][:, destinations] = 1.0 - adj_matrix[origins, :][:, destinations]
        adj_matrix[destinations, :][:, origins] = 1.0 - adj_matrix[destinations, :][:, origins]
        return dense_matrix_to_sparse_matrix(adj_matrix)

    def _create_data_loaders(self, train_batch_size, test_batch_size,
                             adj_matrix, num_hops):
        """
        Creates the training and test set as tensorflow Datasets.
        """
        def _create_base_dataset(pos_edges, neg_edges):
            inputs = np.concatenate((pos_edges, neg_edges), axis=0)
            inputs = tf.data.Dataset.from_tensor_slices(inputs)
            labels = np.concatenate(
                [np.ones(len(pos_edges), dtype=np.int64),
                 np.zeros(len(neg_edges), dtype=np.int64)],
                axis=0
            ).reshape(-1, 1)
            labels = tf.data.Dataset.from_tensor_slices(labels)
            dataset = tf.data.Dataset.zip((inputs, labels))
            return dataset

        # Fill in some attributes that are only need if subgraph extraction
        # is used.
        self.subgraph_mat_idcs = get_subgraph_matrix_sparse(adj_matrix, num_hops)
        if self._subsample_sizes is not None:
            self.adj_list_matrix = get_adj_list_matrix(adj_matrix)
            mapping_fn = self._tf_get_subsampled_subgraph_information
        else:
            self.conv_mat_idcs, self.conv_mat_vals = get_conv_matrix(
                adj_matrix, self._float_type)
            mapping_fn = self._tf_get_subgraph_information

        # Create train dataset.
        train_dataset = _create_base_dataset(self.pos_train_edges, self.neg_train_edges)
        train_dataset = train_dataset.shuffle(self.num_train_samples).batch(
            train_batch_size, drop_remainder=True)
        train_dataset = train_dataset.map(mapping_fn)
        # Create test dataset.
        test_dataset = _create_base_dataset(self.pos_test_edges, self.neg_test_edges)
        test_dataset = test_dataset.batch(test_batch_size, drop_remainder=True)
        test_dataset = test_dataset.map(mapping_fn)

        return train_dataset, test_dataset

    @staticmethod
    def _load_raw_data(dataset_path, dataset_name, dataset_folder):
        """
        Loads the node features and adjacency indices for the specified data
        set. A data set can either be specified via the dataset_path in which
        case it is loaded from file. Alternatively, it can be specified by a
        dataset_name in which case it will be loaded via PyTorch Geometric.
        :param dataset_path: Path to the folder containing the dataset. This
        folder must contain files adj_indices.npy, node_features.npy, and
        optionally edge_features.npy.
        :param dataset_name: Identifier of a dataset according to the PyTorch
        Geometric naming convention.
        :param dataset_folder: Path to a folder in which to store the raw data
        loaded using PyTorch Geometric.
        :return:
        - adj_idcs of shape [N, 2]. Guaranteed to be undirected and without
        self-loops.
        - node_features of shape [N, Dn] or None
        - edge_features of shape [E, De] or None
        """
        assert dataset_path is None or dataset_name is None
        if dataset_path is not None:    # Dataset from file system
            dataset_path = pathlib.Path(dataset_path)
            adj_idcs = np.load(dataset_path / "adj_indices.npy")
            node_features = None
            if (dataset_path / "node_features.npy").exists():
                node_features = np.load(dataset_path / "node_features.npy")
            edge_features = None
            if (dataset_path / "edge_features.npy").exists():
                edge_features = np.load(dataset_path / "edge_features.npy")
        else:   # PyTorch Geometric data set
            dataset_folder = pathlib.Path(dataset_folder)
            # PPI is a special case because it consists of multiple graphs
            if dataset_name.startswith("PPI"):
                dataset_path = dataset_folder / f"ptgeo_{dataset_name[:-1]}/"
                graph_id = int(dataset_name[-1])
                dataset = datasets.PPI(dataset_path, "val")
                data = dataset.data
                slices = dataset.slices
                node_features = data.x.numpy()
                node_features = node_features[slices["x"][graph_id]:slices["x"][graph_id+1]]
                edge_features = None
                adj_idcs = data.edge_index.numpy().T
                adj_idcs = adj_idcs[slices["edge_index"][graph_id]:slices["edge_index"][graph_id+1]]
            else:
                dataset_path = dataset_folder / f"ptgeo_{dataset_name}/"
                if dataset_name in ["Cora", "Citeseer", "PubMed"]:
                    dataset = datasets.Planetoid(dataset_path, dataset_name)
                elif dataset_name in ["Computers", "Photo"]:
                    dataset = datasets.Amazon(dataset_path, dataset_name)
                elif dataset_name in ["Physics", "CS"]:
                    dataset = datasets.Coauthor(dataset_path, dataset_name)
                else:
                    raise ValueError(f"No data set found for name {dataset_name}.")
                data = dataset.data
                node_features = data.x.numpy()
                edge_features = None
                adj_idcs = data.edge_index.numpy().T  # Shape [N, 2]

        # Make sure indices are unique
        adj_idcs = np.array(list({(node1, node2) for (node1, node2) in adj_idcs}))
        # Make sure the graph is undirected and contains no self-loops
        adj_idcs = adj_idcs[adj_idcs[:, 0] < adj_idcs[:, 1]]

        pk.dump((adj_idcs, node_features, edge_features), open(f"{dataset_name}.pk", "wb"))
        return adj_idcs, node_features, edge_features

    @staticmethod
    def _get_dataset_split(adj_matrix, adj_indices, num_nodes, num_edges,
                           num_pos_edges, rstate, train_set_frac):
        """
        Computes the split of the dataset into a training and validation
        subset.
        """
        # select positive test samples
        pos_test_edges_idcs = rstate.choice(num_edges, num_pos_edges,
                                            replace=False)
        pos_test_edges = adj_indices[pos_test_edges_idcs]
        # select negative test samples
        neg_test_edges = LinkPredictionDataset._choose_negative_samples(
            adj_matrix, num_pos_edges, num_nodes, set(), rstate)

        # select positive and negative training samples
        pos_train_edges_mask = np.ones(num_edges)
        pos_train_edges_mask[pos_test_edges_idcs] = 0.0
        pos_train_edges = adj_indices[pos_train_edges_mask.astype(bool)]
        num_pos_edges = len(pos_train_edges)
        excluded_edges = {(node1, node2) for (node1, node2) in neg_test_edges}
        neg_train_edges = LinkPredictionDataset._choose_negative_samples(
            adj_matrix, num_pos_edges, num_nodes, excluded_edges, rstate)

        # If specified, choose a subset of the originally selected edges
        if train_set_frac is not None:
            pos_train_edges = pos_train_edges[
                              :int(train_set_frac * len(pos_train_edges))]
            neg_train_edges = neg_train_edges[
                              :int(train_set_frac * len(neg_train_edges))]

        temp1 = {(node1, nodes2) for (node1, nodes2) in pos_train_edges}
        temp2 = {(node1, nodes2) for (node1, nodes2) in neg_train_edges}
        temp3 = {(node1, nodes2) for (node1, nodes2) in pos_test_edges}
        temp4 = {(node1, nodes2) for (node1, nodes2) in neg_test_edges}
        assert len(temp1.intersection(temp2)) == 0
        assert len(temp1.intersection(temp3)) == 0
        assert len(temp1.intersection(temp4)) == 0
        assert len(temp2.intersection(temp3)) == 0
        assert len(temp2.intersection(temp4)) == 0
        assert len(temp3.intersection(temp4)) == 0
        return pos_test_edges, neg_test_edges, pos_train_edges, neg_train_edges

    @staticmethod
    def _choose_negative_samples(adj_matrix, num_samples, num_nodes,
                                 excluded_edges, rstate):
        """
        Selects a set of node pairs with no edges between them as negative
        samples.
        :param adj_matrix: Sparse SciPy csr_matrix version of the adjceancy
        matrix without self-loops.
        :param num_samples: Number of negative samples that are required.
        :param num_nodes: Number of nodes in the graph.
        :param excluded_edges: Edges that must not be part of the resulting
        set (e.g. because they are already part of the test set).
        :param rstate: NumPy random state.
        :return: Array of negative edges of shape [E, 2].
        """
        neg_edges = set()
        while len(neg_edges) < num_samples:
            nodes1 = rstate.choice(num_nodes, 2*num_samples)        # sample from [0; num_nodes)
            nodes2 = rstate.choice(num_nodes, 2*num_samples)        # sample from [0; num_nodes)
            valid_idcs = (nodes1 < nodes2)                          # only keep pairs where origin < dest to get undirected edges
            valid_idcs = np.bitwise_and(                            # only keep pairs without edges
                valid_idcs, np.array(adj_matrix[nodes1, nodes2]).reshape(-1) == 0.0)
            nodes1, nodes2 = nodes1[valid_idcs], nodes2[valid_idcs]
            pairs = list(zip(nodes1, nodes2))
            pairs = set(pairs) - excluded_edges                     # only keep pairs not in excluded edges
            neg_edges |= set(pairs)
        neg_edges = list(neg_edges)[:num_samples]
        return np.array(neg_edges)

    def _tf_get_subgraph_information(self, idcs_batch, y_batch):
        """
        Mapping function for mapping a dataset that contains only edges and
        labels to a dataset that additionally returns information about the
        minimal subgraph of the batch. This includes the convolution matrix,
        the indices of nodes in the subgraph (relative to all nodes), and the
        node features of the subgraph nodes. Does not subsample neighbourhoods.
        :param idcs_batch: Indices of the nodes that the edges in the batch
        connect. Shape [B, 2].
        :param y_batch: Labels of the edges. Shape [B, 1].
        """
        if self._extract_subgraphs:
            [idcs_batch, y_batch, subgraph_conv_idcs, subgraph_conv_vals,
             subgraph_idcs, subgraph_features, num_subgraph_nodes] = tf.py_function(
                LinkPredictionDataset._get_subgraph_information,
                [idcs_batch, y_batch, self.subgraph_mat_idcs,
                 self.node_features, self.conv_mat_idcs, self.conv_mat_vals],
                [self._tf_float_type, tf.int64, tf.int64, self._tf_float_type,
                 tf.int64, self._tf_float_type, tf.int64]
            )
            conv_matrix = tf.SparseTensor(subgraph_conv_idcs, subgraph_conv_vals,
                                          (num_subgraph_nodes,
                                           num_subgraph_nodes))
            return (idcs_batch, y_batch, conv_matrix, subgraph_idcs,
                    subgraph_features)
        return idcs_batch, y_batch

    @staticmethod
    def _get_subgraph_information(idcs_batch, y_batch, subgraph_mat_idcs,
                                  node_feats, conv_mat_idcs, conv_mat_vals):
        num_nodes = node_feats.shape[0]
        # bring inputs into right format
        conv_matrix = sp.csr_matrix((conv_mat_vals.numpy(),
                                     (conv_mat_idcs.numpy()[:, 0],
                                      conv_mat_idcs.numpy()[:, 1])),
                                    shape=(num_nodes, num_nodes))
        num_subgraph_idcs = subgraph_mat_idcs.shape[0]
        subgraph_mat = sp.csr_matrix((np.ones(num_subgraph_idcs, dtype=np.bool),
                                      (subgraph_mat_idcs.numpy()[:, 0],
                                       subgraph_mat_idcs.numpy()[:, 1])),
                                     shape=(num_nodes, num_nodes))

        batch_idcs = idcs_batch.numpy().reshape(-1).astype(np.int32)        # Shape [2B]
        center_idcs = np.unique(batch_idcs)                                 # Shape [U]
        subgraph_idcs = np.unique(subgraph_mat[center_idcs].tocoo().col)    # Shape [M]

        # Extract subgraph convolution matrix.
        subgraph_conv_mat = conv_matrix[subgraph_idcs, :][:, subgraph_idcs]
        temp = subgraph_conv_mat.tocoo()
        subgraph_conv_idcs = tf.constant(
            np.stack((temp.row, temp.col), axis=-1).astype(np.int64))
        subgraph_conv_vals = tf.constant(temp.data)

        # Extract features for nodes in the subgraph.
        subgraph_features = tf.gather(node_feats, subgraph_idcs)

        # Make sure the node indices in idcs_batch are relative to the
        # other M subgraph nodes.
        rel_idcs = LinkPredictionDataset._get_relative_idcs(batch_idcs, subgraph_idcs)
        rel_idcs = rel_idcs.reshape(len(rel_idcs)//2, 2)      # Shape [B, 2]

        return (rel_idcs, y_batch, subgraph_conv_idcs, subgraph_conv_vals,
                subgraph_idcs, subgraph_features, len(subgraph_idcs))

    def _tf_get_subsampled_subgraph_information(self, idcs_batch, y_batch):
        """
        Mapping function for mapping a dataset that contains only edges and
        labels to a dataset that additionally returns information about the
        minimal subgraph of the batch. This includes the convolution matrix,
        the indices of nodes in the subgraph (relative to all nodes), and the
        node features of the subgraph nodes. Does subsample neighbourhoods.
        :param idcs_batch: Indices of the nodes that the edges in the batch
        connect. Shape [B, 2].
        :param y_batch: Labels of the edges. Shape [B, 1].
        """
        [idcs_batch, y_batch, subgraph_conv_idcs, subgraph_conv_vals,
         subgraph_idcs, subgraph_features, num_subgraph_nodes] = tf.py_function(
            LinkPredictionDataset._get_subsampled_subgraph_information,
            [idcs_batch, y_batch, self.adj_list_matrix,
             self.node_features, self.adj_idcs, self._subsample_sizes],
            [self._tf_float_type, tf.int64, tf.int64, self._tf_float_type,
             tf.int64, self._tf_float_type, tf.int64]
        )
        conv_matrix = tf.SparseTensor(subgraph_conv_idcs, subgraph_conv_vals,
                                      (num_subgraph_nodes,
                                       num_subgraph_nodes))
        return (idcs_batch, y_batch, conv_matrix, subgraph_idcs,
                subgraph_features)

    @staticmethod
    def _get_subsampled_subgraph_information(idcs_batch, y_batch, adj_list_mat,
                                             node_feats, adj_mat_idcs,
                                             sample_sizes):
        num_nodes = node_feats.shape[0]
        num_edges = adj_mat_idcs.shape[0]
        sample_sizes = sample_sizes.numpy().tolist()
        adj_matrix = sp.csr_matrix((np.ones(num_edges),
                                    (adj_mat_idcs.numpy()[:, 0],
                                     adj_mat_idcs.numpy()[:, 1])),
                                   shape=(num_nodes, num_nodes),
                                   dtype=node_feats.numpy().dtype)

        # Get nodes in the subgraph of the incident nodes of the batch.
        batch_idcs = idcs_batch.numpy().reshape(-1).astype(np.int64)        # Shape [2B]
        center_idcs = np.unique(batch_idcs)                                 # Shape [U]
        subgraph_idcs = subsample_neighbors(
            center_idcs, sample_sizes, adj_list_mat.numpy())

        # Extract subgraph convolution matrix.
        subgraph_adj_mat = adj_matrix[subgraph_idcs, :][:, subgraph_idcs]
        subgraph_conv_mat = normalize_adj(subgraph_adj_mat)
        temp = subgraph_conv_mat.tocoo()
        subgraph_conv_idcs = tf.constant(
            np.stack((temp.row, temp.col), axis=-1).astype(np.int64))
        subgraph_conv_vals = tf.constant(temp.data)

        # Extract node features of the nodes in the subgraph.
        subgraph_features = tf.gather(node_feats, subgraph_idcs)

        # Make sure the node indices in idcs_batch are relative to the
        # other M subgraph nodes.
        rel_idcs = LinkPredictionDataset._get_relative_idcs(batch_idcs, subgraph_idcs)
        rel_idcs = rel_idcs.reshape(len(rel_idcs)//2, 2)         # Shape [B, 2]

        return (rel_idcs, y_batch, subgraph_conv_idcs, subgraph_conv_vals,
                subgraph_idcs, subgraph_features, len(subgraph_idcs))

    @staticmethod
    def _get_relative_idcs(idcs, superset):
        """
        Takes an array of indices and a set of indices in the form of an array
        (contains unique elements). The former is a subset of the latter.
        It returns a new version of the indices set such that the indices in
        the new set are 'relative' to the indices in the superset.
        Example: idcs = [4, 7, 6, 7], superset = [2, 3, 4, 6, 7, 8]. The result
        is [2, 4, 3, 4]. If we use the result for indexing superset, we obtain
        idcs.
        """
        temp1 = idcs[None, :].repeat(len(superset), axis=0)      # Shape [M, 2B]
        temp2 = superset[:, None].repeat(len(idcs), axis=1)      # Shape [M, 2B]
        comp = temp1 == temp2
        rel_idcs = np.argmax(comp, axis=0)                       # Shape [2B]
        return rel_idcs


def get_subgraph_information_test():
    idcs_batch = np.array([[2, 7],
                           [7, 4],
                           [2, 5],
                           [7, 5]])
    num_nodes = 8
    node_feats = np.arange(num_nodes)
    adj_matrix = np.zeros((num_nodes, num_nodes))
    adj_matrix[0, 6] = 1
    adj_matrix[1, 2] = 1
    adj_matrix[1, 6] = 1
    adj_matrix[2, 7] = 1
    adj_matrix[2, 4] = 1
    adj_matrix[4, 5] = 1
    adj_matrix += adj_matrix.T
    adj_matrix[np.diag_indices(7)] = 1
    adj_indices = np.stack((np.where(adj_matrix > 0)), axis=-1)
    adj_sparse = dense_matrix_to_sparse_matrix(adj_matrix)
    print("adj_matrix")
    print(adj_matrix)
    print()

    conv_mat_idcs, conv_mat_vals = get_conv_matrix(adj_matrix, np.float32)
    conv_mat_idcs = tf.constant(conv_mat_idcs)
    conv_mat_vals = tf.constant(conv_mat_vals)
    conv_matrix = sp.csr_matrix((conv_mat_vals,
                                 (conv_mat_idcs[:, 0],
                                  conv_mat_idcs[:, 1])),
                                shape=(num_nodes, num_nodes))
    print("full conv_matrix")
    print(conv_matrix.todense())

    # subgraph_matrix = np.array([[1, 1, 0, 3, 0, 0, 1, 0],
    #                             [1, 1, 1, 1, 1, 0, 1, 1],
    #                             [0, 1, 1, 0, 1, 1, 1, 1],
    #                             [1, 1, 0, 1, 0, 0, 1, 0],
    #                             [0, 1, 1, 0, 1, 1, 0, 1],
    #                             [0, 0, 1, 0, 1, 1, 0, 0],
    #                             [1, 1, 1, 1, 0, 0, 1, 0],
    #                             [0, 1, 1, 0, 1, 0, 0, 1])
    subgraph_matrix = get_subgraph_matrix(dense_matrix_to_sparse_matrix(adj_matrix), 2)
    subgraph_matrix_idcs = get_subgraph_matrix_sparse(adj_sparse, 2)
    subgraph_matrix_idcs = tf.constant(subgraph_matrix_idcs)
    print("subgraph_matrix:")
    print(subgraph_matrix)
    print()

    idcs_batch = tf.constant(idcs_batch)

    a = LinkPredictionDataset._get_subgraph_information(idcs_batch, None, subgraph_matrix_idcs, node_feats, conv_mat_idcs, conv_mat_vals)
    (idcs_batch, y_batch, subgraph_conv_idcs, subgraph_conv_vals,
     subgraph_idcs, subgraph_features, num_subgraph_nodes) = a
    sub_conv_matrix = tf.SparseTensor(subgraph_conv_idcs, subgraph_conv_vals,
                                  (num_subgraph_nodes, num_subgraph_nodes))
    sub_conv_matrix = tf.sparse.to_dense(sub_conv_matrix).numpy()
    print(subgraph_features)
    print(idcs_batch)
    print(subgraph_idcs)
    print(sub_conv_matrix)

    assert np.array_equal(idcs_batch, np.array([[1, 5], [5, 2], [1, 3], [5, 3]]))
    true_conv = conv_matrix[np.array([1, 2, 4, 5, 6, 7])][:, np.array([1, 2, 4, 5, 6, 7])]
    assert np.allclose(sub_conv_matrix, true_conv.todense())


if __name__ == '__main__':
    # ds = LinkPredictionDataset("../../data/us_air_lines", None, None,
    #                            split_seed=0, train_batch_size=32,
    #                            test_batch_size=1, float_type=np.float32,
    #                            extract_subgraphs=True,
    #                            node2vec_embeddings=False, test_fraction=0.1,
    #                            pert_frac=0.00, train_set_frac=0.5)
    ds = LinkPredictionDataset("../../data/yeast", None, None, 0, None,
                               None, float_type=np.float32,
                               node2vec_embeddings=False, test_fraction=0.1,
                               train_set_frac=1.0)
    # get_subgraph_information_test()
    # ds = LinkPredictionDataset(None, "PPI1", "../../data",
    #                            split_seed=0, train_batch_size=32,
    #                            test_batch_size=1, float_type=np.float32,
    #                            extract_subgraphs=True,
    #                            node2vec_embeddings=False, test_fraction=0.1,
    #                            pert_frac=0.05, train_set_frac=0.2)
