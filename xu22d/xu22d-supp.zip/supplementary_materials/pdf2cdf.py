import numpy as np


def pdf2cdf(vec_pdf):
    n = len(vec_pdf)
    vec_cdf = vec_pdf
    for i in range(1,n):
        vec_cdf[i] = vec_cdf[i-1] + vec_pdf[i]
    return vec_cdf