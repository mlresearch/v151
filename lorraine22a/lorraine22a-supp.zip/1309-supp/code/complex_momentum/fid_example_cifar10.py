"""Check that Frechet Inception Distance (FID) is approximately 0 when the two distributions are the same (both == CIFAR10 training set).

Example
-------
python fid_example_cifar10.py
"""
import os
import ipdb
import glob
import numpy as np
from imageio import imread

import tensorflow as tf
from torchvision import datasets

import fid

# Paths
# image_path = 'cifar10_train_images' # set path to some generated images
stats_path = 'fid-stats/fid_stats_cifar10_train.npz' # training set statistics
inception_path = fid.check_or_download_inception(None) # download inception network

# loads all images into memory (this might require a lot of RAM!)
# image_list = glob.glob(os.path.join(image_path, '*.jpg'))
# images = np.array([imread(str(fn)).astype(np.float32) for fn in image_list])

cifar10_trainset = datasets.CIFAR10(root='data', train=True, download=True, transform=None)
images = cifar10_trainset.data  # This is a numpy array of type uint8, with min value 0, max value 255
ipdb.set_trace()

# load precalculated training set statistics
f = np.load(stats_path)
mu_real, sigma_real = f['mu'][:], f['sigma'][:]
f.close()

# f2 = np.load('fid_cifar10_train_stats.npz')
# mu_real2, sigma_real2 = f2['mu'][:], f2['sigma'][:]
# f2.close()

fid.create_inception_graph(inception_path)  # load the graph into the current TF graph
with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())
    mu_gen, sigma_gen = fid.calculate_activation_statistics(images, sess, batch_size=100)

fid_value = fid.calculate_frechet_distance(mu_gen, sigma_gen, mu_real, sigma_real)
print("FID: %s" % fid_value)
