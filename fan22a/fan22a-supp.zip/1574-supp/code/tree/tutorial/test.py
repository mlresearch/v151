import time
import numpy as np
from cbp import builder
from cbp.graph.coef_policy import bp_policy

np.set_printoptions(precision=2)

max_ite = 100
cnt_node = 3
node_d = 2

graph = builder.StarBuilder(num_node=cnt_node, d=node_d,
                            policy=bp_policy, rand_seed=1)()
graph.plot(f"draw/barycenter.png")
graph.bake()
eps, steps, timers = graph.itsbp(max_iter=max_ite)

print("#######")

graph = builder.StarBuilder(num_node=cnt_node, d=node_d,
                            policy=bp_policy, rand_seed=1)()
graph.plot(f"draw/barycenter.png")
graph.bake()
eps, steps, timers = graph.sinkhorn(
    max_iter=max_ite,
    tolerance=graph.cfg.itsbp_outer_tolerance / (8))
