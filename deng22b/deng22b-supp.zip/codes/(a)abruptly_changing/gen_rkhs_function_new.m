function [f, x_j_vec, a_j_vec] = gen_rkhs_function_new(data,l,num_points,rkhs_index,kernel_index,num_functions)

[d,arms] = size(data);
K = num_functions;
f = zeros(K,arms);
x_j_vec = zeros(K,arms);
temp = rand(1,num_points);
for k =1:K
   x_j_vec(k,:) = temp; 
end

a_j_vec = rand(K,num_points);
for k = 1:K
    
    
    if rkhs_index == 1
            a_j_vec(k,:) =  -1 + 2.*rand(1,num_points);
        else
            a_j_vec(k,:) = rand(1,num_points);
    end
    for i = 1: arms
        x = data(:,i);
        for j = 1:num_points
            y = x_j_vec(k,j);
            f(k,i) = f(k,i) + a_j_vec(k,j)*kernel_function(x,y,l,kernel_index);
        end
    end
end










