# Bayesian Link Prediction with Deep Graph Convolutional Gaussian Processes

* Data sets are provided in the data folder and come without a license. They are widely available, for example through PyTorch Geometric.
* Requirements:
	* GPflow 2.1.4
	* tensorflow 2.4.0
	* torch-geometric 1.6.3 (for data loading)
	* torch 1.8.1 (for data loading)
	* networkx 2.5
	* matplotlib 3.3.3
* Originally based on the DeepGP repository: https://github.com/ICL-SML/Doubly-Stochastic-DGP

* `deep_edge_gcgp.py` is for running the Link-DGP model.
* `edge_gcgp.py` is for running the shallow Link-GP model.
* `training_environment.py` can be used to specify hyperparameters.