# IIT
Simulation code for "Rapid convergence of informed importance tempering"

perm_sim: code for the "weighted permutations" simulation study

variable_selection: code for the "variable selection" simulation study

iit_src: C++ code for IIT sampling for variable selection
