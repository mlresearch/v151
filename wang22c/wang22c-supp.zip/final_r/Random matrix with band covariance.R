
library('ggplot2')
library('gridExtra')
library(latex2exp)
library('egg')





result = read.csv(file = "/Users/apple/Desktop/PHD Project/final_csv/random_Gaussian_matrix_5_1.csv", 
                  header = T, sep = " ") 
result = as.matrix(result)
index = c(3, 6, 9, 12)
result[index, ] = abs(result[index, ] - 9)


two_fl = rbind(result[1, ], result[2, ])
two_fl = apply(two_fl, 2, max)
two_adapt = rbind(result[4, ], result[5, ])
two_adapt = apply(two_adapt, 2, max)
two_adapt_adapt = rbind(result[7, ], result[8, ])
two_adapt_adapt = apply(two_adapt_adapt, 2, max) 
two_ITALE = rbind(result[10, ], result[11, ])
two_ITALE = apply(two_ITALE , 2, max)
result = rbind (result, two_fl, two_adapt, two_adapt_adapt, two_ITALE)

result_mean =  apply(result, 1, mean)
result_sd =  apply(result, 1, sd)/10
result_up =  result_mean + result_sd
result_low =  result_mean - result_sd
result_method = as.factor(c(rep('FL', 3), rep('FLMF', 3), rep('FLMTF', 3), rep('ITALE', 3), 'FL', 'FLMF', 'FLMTF', 'ITALE' ))



results = data.frame(result_mean, result_up, result_low , result_method)
ind = c(1, 4, 7, 10)
p = ggplot(results[ind, ], aes(x = result_method, y = result_mean)) +
  geom_bar(stat = 'identity', position = position_dodge(), fill =  "slategray3") + 
  geom_text(aes(label = round(result_mean, 2)), vjust = -1, color =  "black", size = 2.5)+
  geom_errorbar(aes(ymin = result_low , ymax = result_up ), width = .1, position = position_dodge(.9), color =  "slategray") +
  labs(title =  TeX(" $h = 1$")) +
  theme(plot.title = element_text(size = 12, vjust = - 0.5, hjust = -0.24),
        axis.title=element_text(size = 9),
        plot.margin = margin(l = 5, r = 5) )

p1 = p +xlab("" ) + ylab("Left Hausdorff Distance")

ind = c(2, 5, 8, 11)
p = ggplot(results[ind, ], aes(x = result_method, y = result_mean)) +
  geom_bar(stat = 'identity', position = position_dodge(), fill =  "slategray3") + 
  geom_text(aes(label = round(result_mean, 2)), vjust = -1, color =  "black",  size = 2.5) +
  geom_errorbar(aes(ymin = result_low , ymax = result_up ), width = .1, position = position_dodge(.9), color =  "slategray") +
  labs(title = TeX(" $h = 1$")) +
  theme(plot.title = element_text(size = 12, vjust = - 0.5, hjust = -0.24),
        axis.title=element_text(size = 9),
        plot.margin = margin(l = 5, r = 5) )

p2 = p +xlab("") + ylab("Right Hausdorff Distance")

ind = c(13, 14, 15, 16)
p = ggplot(results[ind, ], aes(x = result_method, y = result_mean)) +
  geom_bar(stat = 'identity', position = position_dodge(), fill =  "slategray3") + 
  geom_text(aes(label = round(result_mean, 2)), vjust = -1, color =  "black",  size = 2.5) +
  geom_errorbar(aes(ymin = result_low , ymax = result_up ), width = .1, position = position_dodge(.9), color =  "slategray") +
  labs(title = TeX(" $h = 1$")) +
  theme(plot.title = element_text(size = 12, vjust = - 0.5, hjust = -0.24),
        axis.title=element_text(size = 9),
        plot.margin = margin(l = 5, r = 5) )

p1_1 = p +xlab("") + ylab("Hausdorff Distance")

ind = c(3, 6, 9, 12)
p = ggplot(results[ind, ], aes(x = result_method, y = result_mean)) +
  geom_bar(stat = 'identity', position = position_dodge(), fill =  "slategray3") + 
  geom_text(aes(label = round(result_mean, 2)), vjust = -1, color =  "black",  size = 2.5) +
  geom_errorbar(aes(ymin = result_low , ymax = result_up ), width = .1, position = position_dodge(.9), color =  "slategray") +
  labs(title = TeX(" $h = 1$")) +
  theme(plot.title = element_text(size = 12, vjust = - 0.5, hjust = -0.24),
        axis.title=element_text(size = 9),
        plot.margin = margin(l = 5, r = 5) )

p3 = p +xlab("") + ylab(TeX(" $|S( \\hat{x} ) - S|$"))


result = read.csv(file = "/Users/apple/Desktop/PHD Project/final_csv/random_Gaussian_matrix_5_2.csv", 
                  header = T, sep = " ") 
result = as.matrix(result)
index = c(3, 6, 9, 12)
result[index, ] = abs(result[index, ] - 9)

two_fl = rbind(result[1, ], result[2, ])
two_fl = apply(two_fl, 2, max)
two_adapt = rbind(result[4, ], result[5, ])
two_adapt = apply(two_adapt, 2, max)
two_adapt_adapt = rbind(result[7, ], result[8, ])
two_adapt_adapt = apply(two_adapt_adapt, 2, max) 
two_ITALE = rbind(result[10, ], result[11, ])
two_ITALE = apply(two_ITALE , 2, max)
result = rbind (result, two_fl, two_adapt, two_adapt_adapt, two_ITALE)

result_mean =  apply(result, 1, mean)
result_sd =  apply(result, 1, sd)/10
result_up =  result_mean + result_sd
result_low =  result_mean - result_sd
result_method = as.factor(c(rep('FL', 3), rep('FLMF', 3), rep('FLMTF', 3), rep('ITALE', 3), 'FL', 'FLMF', 'FLMTF', 'ITALE' ))



results = data.frame(result_mean, result_up, result_low , result_method)
ind = c(1, 4, 7, 10)
p = ggplot(results[ind, ], aes(x = result_method, y = result_mean)) +
  geom_bar(stat = 'identity', position = position_dodge(), fill =  "slategray3") + 
  geom_text(aes(label = round(result_mean, 2)), vjust = -1, color =  "black",  size = 2.5) +
  geom_errorbar(aes(ymin = result_low , ymax = result_up ), width = .1, position = position_dodge(.9), color =  "slategray") +
  labs(title = TeX(" $h = 10$")) +
  theme(plot.title = element_text(size = 12, vjust = - 0.5, hjust = -0.25),
        axis.title=element_text(size = 9),
        plot.margin = margin(l = 5, r = 5) )

p4 = p +xlab("" ) + ylab("Left Hausdorff Distance")

ind = c(2, 5, 8, 11)
p = ggplot(results[ind, ], aes(x = result_method, y = result_mean)) +
  geom_bar(stat = 'identity', position = position_dodge(), fill =  "slategray3") + 
  geom_text(aes(label = round(result_mean, 2)), vjust = -1, color =  "black",  size = 2.5) +
  geom_errorbar(aes(ymin = result_low , ymax = result_up ), width = .1, position = position_dodge(.9), color =  "slategray") +
  labs(title = TeX(" $h = 10$")) +
  theme(plot.title = element_text(size = 12, vjust = - 0.5, hjust = -0.25),
        axis.title=element_text(size = 9),
        plot.margin = margin(l = 5, r = 5) )

p5 = p +xlab("") + ylab("Right Hausdorff Distance")

ind = c(13, 14, 15, 16)
p = ggplot(results[ind, ], aes(x = result_method, y = result_mean)) +
  geom_bar(stat = 'identity', position = position_dodge(), fill =  "slategray3") + 
  geom_text(aes(label = round(result_mean, 2)), vjust = -1, color =  "black",  size = 2.5) +
  geom_errorbar(aes(ymin = result_low , ymax = result_up ), width = .1, position = position_dodge(.9), color =  "slategray") +
  labs(title = TeX(" $h = 10$")) +
  theme(plot.title = element_text(size = 12, vjust = - 0.5, hjust = -0.25),
        axis.title=element_text(size = 9),
        plot.margin = margin(l = 5, r = 5) )

p2_1 = p +xlab("") + ylab("Hausdorff Distance")

ind = c(3, 6, 9, 12)
p = ggplot(results[ind, ], aes(x = result_method, y = result_mean)) +
  geom_bar(stat = 'identity', position = position_dodge(), fill =  "slategray3") + 
  geom_text(aes(label = round(result_mean, 2)), vjust = -1, color =  "black",  size = 2.5) +
  geom_errorbar(aes(ymin = result_low , ymax = result_up ), width = .1, position = position_dodge(.9), color =  "slategray") +
  labs(title = TeX(" $h = 10$")) +
  theme(plot.title = element_text(size = 12, vjust = - 0.5, hjust = -0.25),
        axis.title=element_text(size = 9),
        plot.margin = margin(l = 5, r = 5) )

p6 = p +xlab("") + ylab(TeX(" $|S( \\hat{x} ) - S|$"))



result = read.csv(file = "/Users/apple/Desktop/PHD Project/final_csv/random_Gaussian_matrix_5_3.csv", 
                  header = T, sep = " ") 
result = as.matrix(result)
index = c(3, 6, 9, 12)
result[index, ] = abs(result[index, ] - 9)

two_fl = rbind(result[1, ], result[2, ])
two_fl = apply(two_fl, 2, max)
two_adapt = rbind(result[4, ], result[5, ])
two_adapt = apply(two_adapt, 2, max)
two_adapt_adapt = rbind(result[7, ], result[8, ])
two_adapt_adapt = apply(two_adapt_adapt, 2, max) 
two_ITALE = rbind(result[10, ], result[11, ])
two_ITALE = apply(two_ITALE , 2, max)
result = rbind (result, two_fl, two_adapt, two_adapt_adapt, two_ITALE)

result_mean =  apply(result, 1, mean, na.rm = T)
result_sd =  apply(result, 1, sd, na.rm = T)/10
result_up =  result_mean + result_sd
result_low =  result_mean - result_sd
result_method = as.factor(c(rep('FL', 3), rep('FLMF', 3), rep('FLMTF', 3), rep('ITALE', 3), 'FL', 'FLMF', 'FLMTF', 'ITALE' ))


results = data.frame(result_mean, result_up, result_low , result_method)
ind = c(1, 4, 7, 10)
p = ggplot(results[ind, ], aes(x = result_method, y = result_mean)) +
  geom_bar(stat = 'identity', position = position_dodge(), fill =  "slategray3") + 
  geom_text(aes(label = round(result_mean, 2)), vjust = -1, color =  "black",  size = 2.5) +
  geom_errorbar(aes(ymin = result_low , ymax = result_up ), width = .1, position = position_dodge(.9), color =  "slategray") +
  labs(title = TeX(" $h = 50$")) +
  theme(plot.title = element_text(size = 12, vjust = - 0.5, hjust = -0.26),
        axis.title=element_text(size = 9),
        plot.margin = margin(l = 5, r = 5) )

p7 = p +xlab("" ) + ylab("Left Hausdorff Distance")

ind = c(2, 5, 8, 11)
p = ggplot(results[ind, ], aes(x = result_method, y = result_mean)) +
  geom_bar(stat = 'identity', position = position_dodge(), fill =  "slategray3") + 
  geom_text(aes(label = round(result_mean, 2)), vjust = -1, color =  "black",  size = 2.5) +
  geom_errorbar(aes(ymin = result_low , ymax = result_up ), width = .1, position = position_dodge(.9), color =  "slategray") +
  labs(title = TeX(" $h = 50$")) +
  theme(plot.title = element_text(size = 12, vjust = - 0.5, hjust = -0.26),
        axis.title=element_text(size = 9),
        plot.margin = margin(l = 5, r = 5) )

p8 = p +xlab("") + ylab("Right Hausdorff Distance")

ind = c(13, 14, 15, 16)
p = ggplot(results[ind, ], aes(x = result_method, y = result_mean)) +
  geom_bar(stat = 'identity', position = position_dodge(), fill =  "slategray3") + 
  geom_text(aes(label = round(result_mean, 2)), vjust = -1, color =  "black",  size = 2.5) +
  geom_errorbar(aes(ymin = result_low , ymax = result_up ), width = .1, position = position_dodge(.9), color =  "slategray") +
  labs(title = TeX(" $h = 50$")) +
  theme(plot.title = element_text(size = 12, vjust = - 0.5, hjust = -0.26),
        axis.title=element_text(size = 9),
        plot.margin = margin(l = 5, r = 5) )

p3_1 = p +xlab("") + ylab("Hausdorff Distance")


ind = c(3, 6, 9, 12)
p = ggplot(results[ind, ], aes(x = result_method, y = result_mean)) +
  geom_bar(stat = 'identity', position = position_dodge(), fill =  "slategray3") + 
  geom_text(aes(label = round(result_mean, 2)), vjust = -1, color =  "black",  size = 2.5) +
  geom_errorbar(aes(ymin = result_low , ymax = result_up ), width = .1, position = position_dodge(.9), color =  "slategray") +
  labs(title = TeX(" $h = 50$")) +
  theme(plot.title = element_text(size = 12, vjust = - 0.5, hjust = -0.26),
        axis.title=element_text(size = 9),
        plot.margin = margin(l = 5, r = 5) )

p9 = p +xlab("") + ylab(TeX(" $|S( \\hat{x} ) - S|$"))





result = read.csv(file = "/Users/apple/Desktop/PHD Project/final_csv/random_Gaussian_matrix_5_4.csv", 
                  header = T, sep = " ") 
result = as.matrix(result)
index = c(3, 6, 9, 12)
result[index, ] = abs(result[index, ] - 9)

two_fl = rbind(result[1, ], result[2, ])
two_fl = apply(two_fl, 2, max)
two_adapt = rbind(result[4, ], result[5, ])
two_adapt = apply(two_adapt, 2, max)
two_adapt_adapt = rbind(result[7, ], result[8, ])
two_adapt_adapt = apply(two_adapt_adapt, 2, max) 
two_ITALE = rbind(result[10, ], result[11, ])
two_ITALE = apply(two_ITALE , 2, max)
result = rbind (result, two_fl, two_adapt, two_adapt_adapt, two_ITALE)

result_mean =  apply(result, 1, mean, na.rm = T)
result_sd =  apply(result, 1, sd, na.rm = T)/10
result_up =  result_mean + result_sd
result_low =  result_mean - result_sd
result_method = as.factor(c(rep('FL', 3), rep('FLMF', 3), rep('FLMTF', 3), rep('ITALE', 3), 'FL', 'FLMF', 'FLMTF', 'ITALE' ))



results = data.frame(result_mean, result_up, result_low , result_method)
ind = c(1, 4, 7, 10)
p = ggplot(results[ind, ], aes(x = result_method, y = result_mean)) +
  geom_bar(stat = 'identity', position = position_dodge(), fill =  "slategray3") + 
  geom_text(aes(label = round(result_mean, 2)), vjust = -1, color =  "black",  size = 2.5) +
  geom_errorbar(aes(ymin = result_low , ymax = result_up ), width = .1, position = position_dodge(.9), color =  "slategray") +
  labs(title = TeX(" $h = 999$")) +
  theme(plot.title = element_text(size = 12, vjust = - 0.5, hjust = -0.27),
        axis.title=element_text(size = 9),
        plot.margin = margin(l = 5, r = 5) )

p10 = p +xlab("" ) + ylab("Left Hausdorff Distance")

ind = c(2, 5, 8, 11)
p = ggplot(results[ind, ], aes(x = result_method, y = result_mean)) +
  geom_bar(stat = 'identity', position = position_dodge(), fill =  "slategray3") + 
  geom_text(aes(label = round(result_mean, 2)), vjust = -1, color =  "black",  size = 2.5) +
  geom_errorbar(aes(ymin = result_low , ymax = result_up ), width = .1, position = position_dodge(.9), color =  "slategray") +
  labs(title = TeX(" $h = 999$")) +
  theme(plot.title = element_text(size = 12, vjust = - 0.5, hjust = -0.27),
        axis.title=element_text(size = 9),
        plot.margin = margin(l = 5, r = 5) )

p11 = p +xlab("") + ylab("Right Hausdorff Distance")

ind = c(13, 14, 15, 16)
p = ggplot(results[ind, ], aes(x = result_method, y = result_mean)) +
  geom_bar(stat = 'identity', position = position_dodge(), fill =  "slategray3") + 
  geom_text(aes(label = round(result_mean, 2)), vjust = -1, color =  "black",  size = 2.5) +
  geom_errorbar(aes(ymin = result_low , ymax = result_up ), width = .1, position = position_dodge(.9), color =  "slategray") +
  labs(title = TeX(" $h = 999$")) +
  theme(plot.title = element_text(size = 12, vjust = - 0.5, hjust = -0.27),
        axis.title=element_text(size = 9),
        plot.margin = margin(l = 5, r = 5) )

p4_1 = p +xlab("") + ylab("Hausdorff Distance")

ind = c(3, 6, 9, 12)
p = ggplot(results[ind, ], aes(x = result_method, y = result_mean)) +
  geom_bar(stat = 'identity', position = position_dodge(), fill =  "slategray3") + 
  geom_text(aes(label = round(result_mean, 2)), vjust = -1, color =  "black",  size = 2.5) +
  geom_errorbar(aes(ymin = result_low , ymax = result_up ), width = .1, position = position_dodge(.9), color =  "slategray") +
  labs(title = TeX(" $h = 999$")) +
  theme(plot.title = element_text(size = 12, vjust = - 0.5, hjust = -0.27),
        axis.title=element_text(size = 9),
        plot.margin = margin(l = 5, r = 5) )

p12 = p +xlab("") + ylab(TeX(" $|S( \\hat{x} ) - S|$"))

ggarrange(p1, p4, p7, p10, p2, p5, p8, p11, p3, p6, p9, p12, ncol = 4)

ggarrange(p1_1, p2_1, p3_1, p4_1, p3, p6, p9, p12, ncol = 4)