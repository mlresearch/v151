#######################################
## Run experiments for Fig 6 (right) ##
#######################################

# This script needs four inputs
# 1. network in [resnet16,...,resnet500]      <- network depth
# 2. optim in [Adam,RMSprop, SGD]             <- optimizer
# 3. learning rate in R                       <- Skip connections
# 4. batch size in N                          <- If True: width=sqrt(depth), else width=depth

### Tensorboard needed for visualization

######################################
######################################
######################################


import numpy as np
import IPython
import torch
import torch.optim as optim
from tensorboardX import SummaryWriter
import datetime
import sys
from no_resnet import ResNet18,ResNet34,ResNet50,ResNet101,ResNet152,ResNet200,ResNet270,ResNet336,ResNet500

import math
import random

import torchvision
import torchvision.transforms as transforms


class MyDataset(torch.utils.data.Dataset):
    def __init__(self, X,Y):
        super().__init__()

        self.X, self.Y = X,Y #shipping entire dataset to device to speed things up!
        self.N= self.X.shape[0]
        
    def get_item(self, idx):        
        return self.X[idx].to(device), self.Y[idx].to(device)

    def get_all(self):
        return self.X,self.Y



def get_params_grad(model):
    """
    get model parameters and corresponding gradients
    """
    params = []
    grads = []
    for param in model.parameters():
        if not param.requires_grad:
            continue
        params.append(param)
        grads.append(0. if param.grad is None else param.grad + 0.)
    return params, grads


def flat_params(model):
    flat_data = []
    for p in model.parameters():
        flat_data.append(p.data.view(-1))
    return torch.cat(flat_data)

def flat_gradient(net):
    grad_dict  = {k:v.grad for k, v in zip(net.state_dict(), net.parameters())}
    grad_vec = torch.cat([g.contiguous().view(-1) for k,g in grad_dict.items()])
    return grad_vec
## RMS prop needs ~ 300 epochs
def train_net(trainloader,testloader,my_model,optimizer,optim_method,network,lr,n_epochs = 400, batch_size=32):
    
    ########################################
    ########### Tensorboard log ############
    ########################################
    
    for m in my_model.modules():
        if isinstance(m, torch.nn.Conv2d):
            torch.nn.init.kaiming_uniform_(m.weight, mode='fan_out', nonlinearity='relu')
    writer = SummaryWriter(f'logs/train_new/{network}/{optim_method}/lr: {lr}')


    iteration=0

    ########################################
    ###########   train model   ############
    ########################################

    loss_fn=torch.nn.CrossEntropyLoss() 
    my_model.train() 

    for epoch in range(n_epochs):    
        #rperm = torch.randperm(train_ds.N).to(device)
        #i=0  
        print("\r{} {}".format(" Epoch :", epoch), end=" "*10, flush=True)   

        #while i*batch_size<train_ds.N-1:
        for i,batch in enumerate(trainloader):
            my_model.train()
            optimizer.zero_grad()
            #x,y = train_ds.get_item(rperm[i*(batch_size):min((i+1)*(batch_size),train_ds.N-1)])
            x,y=batch[0].to(device),batch[1].to(device)
            #y_pred=my_model.forward(x.transpose(1,3)) 
            y_pred=my_model(x) 
            loss = loss_fn(y_pred,y.long())
            loss.backward()
            grad=flat_gradient(my_model)
            acc=1.0*torch.sum(torch.max(y_pred, 1)[1]==y)/len(y)
            
            if iteration==0:
                writer.add_scalar('stats/grad_norm',torch.norm(grad).item(),iteration)  
                writer.add_scalar('stats/training_loss', loss.item(), iteration)
                writer.add_scalar('stats/accuracy',acc,iteration)
            
            #torch.nn.utils.clip_grad_norm_(my_model.parameters(),500)
  
            optimizer.step()

            iteration=iteration+1
            #i=i+1

        with torch.no_grad():
            my_model.eval()
            test_acc=0
            for i,batch in enumerate(testloader):
                x,y=batch[0].to(device),batch[1].to(device)
                y_pred=my_model(x) 
                test_acc+=1.0*torch.sum(torch.max(y_pred, 1)[1]==y)/len(y)
                if i==5:
                    test_acc=test_acc/6
                    break
            writer.add_scalar('stats/test_accuracy',test_acc,iteration)

        writer.add_scalar('stats/grad_norm',torch.mean(torch.abs(grad)).item(),iteration)  
        writer.add_scalar('stats/training_loss', loss.item(), iteration)
        writer.add_scalar('stats/accuracy',acc,iteration)

    writer.close()
    return  

time = None

def main(network,optim_method,lr,bs):

    global device
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    ########################################################################
    ########################### 1. Setup Model  ############################
    ########################################################################
    
    if network=="resnet18":
        my_model=ResNet18
    elif network=="resnet50":
        my_model=ResNet50
    elif network=="resnet152":
        my_model=ResNet152
    elif network=="resnet200":
        my_model=ResNet200
    elif network=="resnet270":
        my_model=ResNet270
    elif network=="resnet336":
        my_model=ResNet336
    elif network=="resnet500":
        my_model=ResNet500

    my_model=torch.nn.DataParallel(my_model()).cuda()

    ########################################################################
    ########################### 2. load data  ##############################
    ########################################################################
    transform = transforms.Compose([transforms.ToTensor(),transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])#m,m,m,std,std,std

    trainset = torchvision.datasets.CIFAR10(root='./data', train=True,download=True, transform=transform)
    testset = torchvision.datasets.CIFAR10(root='./data', train=False,download=True, transform=transform)

    trainloader = torch.utils.data.DataLoader(trainset, batch_size=bs,shuffle=True,pin_memory=True,num_workers=4)
    testloader = torch.utils.data.DataLoader(testset, batch_size=bs,shuffle=False,pin_memory=True,num_workers=4)


    ########################################
    ########### Setup  Optimizer ###########   
    ########################################
    
    if optim_method=="Adam":
        optimizer = optim.Adam(my_model.parameters(), lr=lr)
    elif optim_method=="RMSprop" or optim_method=="RMSProp":
        optimizer = optim.RMSprop(my_model.parameters(), lr=lr)
    else:  
        optimizer = optim.SGD(my_model.parameters(), lr=lr) 


    ########################################################################
    ############################## 3. train network ########################
    ########################################################################

    train_net(trainloader,testloader,my_model,optimizer,optim_method,network,lr,batch_size=bs)
        
   
    print("done!")

if __name__ == "__main__":
    a=str(sys.argv[1])
    b=str(sys.argv[2])
    c=float(sys.argv[3])
    d=int(sys.argv[4])
    main(a,b,c,d)


    