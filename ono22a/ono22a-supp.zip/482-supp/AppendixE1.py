import functools
from multiprocessing import Pool
import os

import numpy as np
import scipy.optimize as optimize

import experiment


# load data
data2011 = np.loadtxt("data/emission/gt_2011.csv",skiprows=1,delimiter=',')
data2012 = np.loadtxt("data/emission/gt_2012.csv",skiprows=1,delimiter=',')
data2013 = np.loadtxt("data/emission/gt_2013.csv",skiprows=1,delimiter=',')
data2014 = np.loadtxt("data/emission/gt_2014.csv",skiprows=1,delimiter=',')
data2015 = np.loadtxt("data/emission/gt_2015.csv",skiprows=1,delimiter=',')
data = np.concatenate((data2011,data2012,data2013,data2014,data2015), axis=0)
y = data[:, -1]
x = data[:, :-2]
(n, d) = np.shape(x)

if __name__ ==  '__main__': 
    # get number of cpus
    num_processors = os.cpu_count()
    
    # hyperparameters
    sigma = 1.
    alpha = 0.3

    # set interval
    cuy = 110
    cly = 40
    cux = np.array([10., 1030., 100., 6., 30., 1100., 570., 170., 15.])
    clx = np.array([ 5., 1000.,  70., 4., 20., 1000., 530., 130., 10.])
    
    # experiment setting
    num_trials = 1000
    epsilons = np.array([5., 10., 25.])
    ns = np.array([100, 1000, 10000])

    # initilize hitory
    his = np.zeros((len(epsilons), len(ns), num_trials, d))
    
    for j, epsilon in enumerate(epsilons):
        expe = functools.partial(experiment.experiment_private, x=x, y=y, 
                                sigma=sigma, alpha=alpha, epsilon=epsilon, 
                                cuy=cuy, cly=cly, cux=cux, clx=clx)
        for k, n_dash in enumerate(ns):
            with Pool(processes = num_processors) as p:
                output = np.array(p.map(expe,np.ones(num_trials,dtype=int)*ns[k]))
            his[j, k] = output
    
    # save the histry as a numpy file
    np.save("outputs/appE1_his.npy", his)
