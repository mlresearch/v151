function [SupPerm, invSP] = gen_SupPerm(n)

if n/2==floor(n/2)
    OddSeq = (1:(n/2+1))*2 - 1;
else
    OddSeq = (1:((n+1)/2))*2 - 1;
end

if n/2==floor(n/2)
    EvenSeq = ((n/2):-1:1)*2;
else
    EvenSeq = (((n+1)/2):-1:1)*2;
end

SupPerm = [];
if n/2==floor(n/2)
    for ii=1:n
        if ii/2==floor(ii/2)
            SupPerm = [SupPerm EvenSeq-ii/n];
        else
            SupPerm = [SupPerm OddSeq-ii/n];
        end
    end
else
    for ii=1:n
        if ii/2==floor(ii/2)
            SupPerm = [SupPerm EvenSeq-ii/n];
        else
            SupPerm = [SupPerm OddSeq-ii/n];
        end
    end
end

temp = SupPerm;
[~,temptemp] = sort(temp);
[~,SupPerm] = sort(temptemp);
[~,invSP] = sort(SupPerm);
