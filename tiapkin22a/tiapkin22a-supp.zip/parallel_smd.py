import numpy as np
import scipy as sp
import time
from tqdm import tqdm

def parallel_SMD(eps, N, MDP, empiricalMDP, t_mix, checkpoint_iters=100, updates=False, warmup=False):
    eps_true = eps
    
    
    N_s = MDP.n_state
    N_a = MDP.n_action
    M = 6 * t_mix
    # Algorithm
    bar_v = 0
    h = np.zeros(N_s)
    c = MDP.R.copy().T.reshape(-1) # current constraints
    mu = np.zeros((N_s, N_a)) # dual variables
    mu += 1e-9 # to avoid zero-division
    
    policies = []
    times = []
    start_time = time.time()

    for _ in tqdm(range(N)):
        eps = warmup * max(0, 1000/np.power(_ + 1, 0.5) - 1) * eps_true + eps_true
         # check constraints
        bad_constr = np.argmax(c)
        if c[bad_constr] < eps:
            # productive step
            delta_bar_v = min(eps/64, bar_v)
            bar_v -= delta_bar_v
            # recompute constraints
            c += delta_bar_v
        else:
            # non-productive step
            i, a_i = np.unravel_index(bad_constr, (N_s, N_a))
            s = MDP.step(i, a_i)
            if updates:
                empiricalMDP.update(i, a_i, s)
            
            delta_bar_v = min(1 - bar_v, eps/64)
            bar_v += delta_bar_v
            
            delta_hs = min(M + h[s], eps/64)
            h[s] -= delta_hs
            
            delta_hi = min(M - h[i], eps/64)
            h[i] += delta_hi
                
            mu[i, a_i] +=1
            # recompute constraints
            c -= (delta_bar_v + delta_hs * empiricalMDP.P[s] - delta_hi * empiricalMDP.P[i]).reshape(-1)
            c = c.reshape(N_s,N_a)
            c[s] += delta_hs
            c[i] -= delta_hi
            c = c.reshape(-1)         
            
        if _ % checkpoint_iters == checkpoint_iters-1:
            policies.append((mu.copy() / mu.sum(axis=1)[:, None]).T)
            times.append(time.time() - start_time)

    return policies, times