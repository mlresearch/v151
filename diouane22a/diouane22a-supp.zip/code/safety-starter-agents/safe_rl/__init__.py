from tensorflow.python.util import deprecation as deprecation
deprecation._PRINT_DEPRECATION_WARNINGS = False
from gym.envs.registration import register
from safe_rl.pg.algos import ppo, ppo_lagrangian, trpo, trpo_lagrangian, cpo, rcpo
from safe_rl.sac.sac import sac

register(
    id='CartSafe-v0',
    entry_point='safe_rl.my_env.envs:CartSafeEnv',
    max_episode_steps=200,
    reward_threshold=520.0,
)

register(
    id='MountainCarContinuousSafe-v0',
    entry_point='safe_rl.my_env.envs:Continuous_MountainCarSafeEnv',
    reward_threshold=90,
    max_episode_steps=999,
)