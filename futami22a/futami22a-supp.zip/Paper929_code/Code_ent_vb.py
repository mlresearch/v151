# -*- coding: utf-8 -*-

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function


import numpy as np
np.random.seed(0)
import tensorflow as tf


import tensorflow_probability
tensorflow_probability.math.diag_jacobian
tf.reset_default_graph()
import argparse

parser = argparse.ArgumentParser()

parser.add_argument('--vi', type=str, default='mean')#"iwae"
parser.add_argument('--temp', type=float, default=1.)
parser.add_argument('--tempKL', type=float, default=1.)
parser.add_argument('--sample_num', type=int, default=10)
parser.add_argument('--epoch', type=int, default=100)
parser.add_argument('--data', type=str, default='mnist')#"cifar10"




args = parser.parse_args()



if __name__ == '__main__':

    if args.data=="mnist":
        dataSource=tf.keras.datasets.fashion_mnist
        NPixels=28
    elif args.data=="cifar10":
        dataSource=tf.keras.datasets.cifar10
        NPixels=32        

    sample_num=args.sample_num
    batch_size=100
    num_epochs=args.epoch
    num_hidden_units=20


    np.random.seed(1)
    tf.set_random_seed(1)

    sess = tf.InteractiveSession()#tf.InteraSession()


    (x_train, y_train), (x_test, y_test) = dataSource.load_data()

    if (dataSource.__name__.__contains__('cifar')):
        x_train=sess.run(tf.cast(tf.squeeze(tf.image.rgb_to_grayscale(x_train)),dtype=tf.float32))
        x_test=sess.run(tf.cast(tf.squeeze(tf.image.rgb_to_grayscale(x_test)),dtype=tf.float32))

    NPixels = np.int(NPixels/2)

    y_train = x_train[:, NPixels:]
    x_train = x_train[:, 0:NPixels]

    y_test = x_test[:, NPixels:]
    x_test = x_test[:, 0:NPixels]

    NPixels= NPixels * NPixels * 2

    x_train, x_test = x_train / 255.0, x_test / 255.0
    y_train, y_test = y_train / 255.0, y_test / 255.0



    N = x_train.shape[0]
    M = batch_size

    x_batch = tf.placeholder(dtype=tf.float32, name="x_batch", shape=[None, NPixels])
    y_batch = tf.placeholder(dtype=tf.float32, name="y_batch", shape=[None, NPixels])

    def model(NHIDDEN,W,b,W_out,b_out, x,sample_num):
        pW = tf.distributions.Normal(loc=tf.zeros([NPixels, NHIDDEN]), scale=1., name="W")
        pb = tf.distributions.Normal(loc=tf.zeros([1, NHIDDEN]), scale=1., name="b")

        pW_out = tf.distributions.Normal(loc=tf.zeros([NHIDDEN, NPixels]), scale=1., name="W_out")
        pb_out = tf.distributions.Normal(loc=tf.zeros([1, NPixels]), scale=1., name="b_out")
        
        hidden_layer = tf.nn.relu(tf.matmul(x, W) + b)
        out = tf.matmul(hidden_layer, W_out) + b_out
        y = tf.distributions.Normal(loc=out, scale=1./255, name="y")
        
        return pW,pb,pW_out,pb_out,x, y



    def qmodel(NHIDDEN):
        W_loc = tf.Variable(tf.random_normal([NPixels, NHIDDEN], 0.0, 0.1, dtype=tf.float32))
        b_loc = tf.Variable(tf.random_normal([1, NHIDDEN], 0.0, 0.1, dtype=tf.float32))



        W_scale = tf.nn.softplus(tf.Variable(tf.random_normal([NPixels, NHIDDEN], -3., stddev=0.1, dtype=tf.float32)))
        b_scale = tf.nn.softplus(tf.Variable(tf.random_normal([1, NHIDDEN], -3., stddev=0.1, dtype=tf.float32)))

        qW = tf.distributions.Normal(loc=W_loc, scale=W_scale)


        qb = tf.distributions.Normal(loc=b_loc, scale=b_scale)

        W_out_loc = tf.Variable(tf.random_normal([NHIDDEN, NPixels], 0.0, 0.1, dtype=tf.float32))
        b_out_loc = tf.Variable(tf.random_normal([1, NPixels], 0.0, 0.1, dtype=tf.float32))

        W_out_scale = tf.nn.softplus(tf.Variable(tf.random_normal([NHIDDEN, NPixels], -3., stddev=0.1, dtype=tf.float32)))
        b_out_scale = tf.nn.softplus(tf.Variable(tf.random_normal([1, NPixels], -3., stddev=0.1, dtype=tf.float32)))


        qW_out = tf.distributions.Normal(loc=W_out_loc, scale=W_out_scale)
        qb_out = tf.distributions.Normal(loc=b_out_loc, scale=b_out_scale)


        return qW,  qb, qW_out, qb_out,W_loc,b_loc,W_out_loc,b_out_loc

    
    def model_mean(W,b,W_out,b_out, x,sample_num):
        
        hidden_layer = tf.nn.relu(tf.matmul(x, W) + b)
        out = tf.matmul(hidden_layer, W_out) + b_out
        y = tf.distributions.Normal(loc=out, scale=1./255, name="mean")
        
        return y
    

    qW,  qb, qW_out, qb_out,W_loc,b_loc,W_out_loc,b_out_loc = qmodel(num_hidden_units)
    dist=qW,  qb, qW_out, qb_out
    samples=[]
    for i in dist:
        samples.append(i.sample(sample_num))
    
    pW,pb,pW_out,pb_out,x,y=model(num_hidden_units,samples[0],samples[1],samples[2],samples[3], x_batch,sample_num)
    dist_prior=[pW,pb,pW_out,pb_out]
    
    # ys is shape=(30, ?, 392) dtype=int32>
    
    # log posterior
    post=[tf.reduce_sum(i.log_prob(j),[-1,-2]) for i,j in zip(dist,samples)]
    
    
    prior=[tf.reduce_sum(i.log_prob(j),[-1,-2]) for i,j in zip(dist_prior,samples)]


    
    KL=tf.reduce_mean(tf.reduce_sum(post,0)-tf.reduce_sum(prior,0))
    

    pylogprob = tf.reduce_sum(y.log_prob(y_batch),axis=2) # samples. batchsize, outputdim
    vi=args.vi
    if vi=="mean":
        nlpp = -tf.reduce_mean(pylogprob)
    elif vi=="iwae":
        nlpp = -tf.reduce_mean(args.temp*tf.math.reduce_logsumexp(pylogprob/args.temp, axis=0),axis=0)+tf.log(np.float32(sample_num))

    mean_log=model_mean(W_loc,b_loc,W_out_loc,b_out_loc, x_batch,sample_num)
    #test_log = tf.reduce_mean(tf.math.reduce_logsumexp(tf.reduce_sum(mean_log.log_prob(y_batch),axis=2), axis=0))
    test_log = tf.reduce_sum(mean_log.log_prob(y_batch),axis=1)

    elbo=nlpp + KL /(N*args.tempKL)

    _samples=[]
    for i in dist:
        _samples.append(i.sample(300))
    _post=[tf.reduce_sum(i.log_prob(j),[-1,-2]) for i,j in zip(dist,_samples)]
    _prior=[tf.reduce_sum(i.log_prob(j),[-1,-2]) for i,j in zip(dist_prior,_samples)]
    test_KL=tf.reduce_mean(tf.reduce_sum(_post,0)-tf.reduce_sum(_prior,0))


    #Frobenius norm
    _nn_var=tf.trainable_variables()
    nn_var=[_nn_var[0],_nn_var[1],_nn_var[4],_nn_var[5]]

    weight_norm=tf.reduce_sum(tf.square(tf.linalg.svd(_nn_var[0],compute_uv=False)))+tf.reduce_sum(tf.square(tf.linalg.svd(_nn_var[4],compute_uv=False)))

    
    
    verbose=True
    optimizer = tf.train.AdamOptimizer(0.001)
    

    t = []
    train = optimizer.minimize(elbo)
    init = tf.global_variables_initializer()
    sess.run(init)




    for i in range(num_epochs+1):
        perm = np.random.permutation(N)
        x_train = np.take(x_train, perm, axis=0)
        y_train = np.take(y_train, perm, axis=0)

        x_batches = np.array_split(x_train, N / M)
        y_batches = np.array_split(y_train, N / M)

        for j in range(N // M):
            batch_x = np.reshape(x_batches[j], [x_batches[j].shape[0], -1]).astype(np.float32)
            batch_y = np.reshape(y_batches[j],[y_batches[j].shape[0],-1]).astype(np.float32)

            value, _ = sess.run([elbo, train],feed_dict={x_batch: batch_x, y_batch: batch_y})
            t.append(-value)
            if verbose:
                #if j % 1 == 0: print(".", end="", flush=True)
                if i%50==0 and j%1000==0:
                #if j >= 5 :
                    print("\nEpoch: " + str(i))
                    str_elbo = str(t[-1])
                    print("\n" + str(j) + " epochs\t" + str_elbo, end="", flush=True)
                    #print("\n" + str(j) + " data\t" + str(sess.run(datalikelihood,feed_dict={x_batch: batch_x, y_batch: batch_y})), end="", flush=True)
                    #print("\n" + str(j) + " var\t" + str(sess.run(var,feed_dict={x_batch: batch_x, y_batch: batch_y})), end="", flush=True)
                    print("\n" + str(j) + " KL\t" + str(sess.run(KL,feed_dict={x_batch: batch_x, y_batch: batch_y})), end="", flush=True)
                    #print("\n" + str(j) + " energy\t" + str(sess.run(logprior,feed_dict={x_batch: batch_x, y_batch: batch_y})), end="", flush=True)
                    #print("\n" + str(j) + " entropy\t" + str(sess.run(entropy,feed_dict={x_batch: batch_x, y_batch: batch_y})), end="", flush=True)
                    #print("\n" + str(j) + " hmax\t" + str(sess.run(tf.reduce_mean(hmax),feed_dict={x_batch: batch_x, y_batch: batch_y})), end="", flush=True)
                    #print("\n" + str(j) + " alpha\t" + str(sess.run(tf.reduce_mean(alpha),feed_dict={x_batch: batch_x, y_batch: batch_y})), end="", flush=True)
                    #print("\n" + str(j) + " logmax\t" + str(sess.run(tf.reduce_mean(logmax),feed_dict={x_batch: batch_x, y_batch: batch_y})), end="", flush=True)

    M=1000


    N=x_test.shape[0]
    x_batches = np.array_split(x_test, N / M)
    y_batches = np.array_split(y_test, N / M)
    

    
    


    NLL = 0
    GAP=[]
    weights=sess.run(weight_norm)
    testkl=sess.run(test_KL)
    print("weight",weights)
    print("KL",testkl)
    #local=[]
    for j in range(N // M):
        batch_x = np.reshape(x_batches[j], [x_batches[j].shape[0], -1]).astype(np.float32)
        batch_y = np.reshape(y_batches[j], [y_batches[j].shape[0],-1]).astype(np.float32)
        y_pred_list = []
        y_preds = sess.run(pylogprob,feed_dict={x_batch: batch_x, y_batch: batch_y})#np.concatenate(y_pred_list, axis=1)
        score = tf.reduce_sum(tf.math.reduce_logsumexp(y_preds,axis=0)-tf.log(np.float32(sample_num)))
        score = sess.run(score)
        NLL = NLL + score

        if verbose:
            if j % 1 == 0: print(".", end="", flush=True)
            if j % 1 == 0:
                str_elbo = str(score)
                print("\n" + str(j) + " epochs\t" + str_elbo, end="", flush=True)

    print("\nNLL: "+str(NLL))

    
    
    output=[NLL,weights,testkl]
    file_name2=args.data+str("_TempKL_")+args.vi+str("_")+str(args.sample_num)+str("_")+str(args.temp)+str(args.epoch)+"_tempKL_"+str(args.tempKL)+"_opt_"+".npy"
    np.save("./results_structure/"+file_name2,output)