import math
import time
import torch
import random
import numpy as np
import torch.optim as optim

from utils.cuda import cuda_var
from utils.beautify_time import beautify
from model.discriminator_wrapper import DiscriminatorWrapper
from learner.downstream_training import DownstreamClassificationTask


class NCEKLossArticle:

    LOG_LOSS, LOG_LOSS_BATCH, MARGIN = range(3)

    def __init__(self, config, constants):

        self.config = config
        self.use_class_info = config["use_class_info"]
        self.no_collision = config["no_collision"]
        self.forced_diversity = config["forced_diversity"]
        self.add_collision = config["add_collision"]
        self.constants = constants
        self.max_epoch = constants["max_epoch"]
        self.lr = constants["lr"]
        self.batch_size = constants["batch_size"]
        self.patience = constants["patience"]
        self.train_size = constants["sample_size"]
        self.eval_size = constants["eval_sample_size"]
        self.grad_clip = constants["grad_clip"]
        self.temperature = constants["temperature"]
        self.mask = dict()
        for b in range(1, self.batch_size + 1):
            self.mask[b] = self.get_negative_mask(b)
        # self.mask[self.batch_size] = self.get_negative_mask(self.batch_size)

        if self.constants["loss"] == "log_loss":
            self.loss_type = NCEKLossArticle.LOG_LOSS
        elif self.constants["loss"] == "log_loss_batch":
            self.loss_type = NCEKLossArticle.LOG_LOSS_BATCH
        elif self.constants["loss"] == "margin":
            self.loss_type = NCEKLossArticle.MARGIN
        else:
            raise AssertionError("Unhandled loss type %r" % self.constants["loss"])

        self.downstream_task = DownstreamClassificationTask(config, constants)

    @staticmethod
    def get_negative_mask(batch_size):

        negative_mask = torch.ones((batch_size, 2 * batch_size)).float()
        for i in range(batch_size):
            negative_mask[i, i] = 0.0
            negative_mask[i, i + batch_size] = 0.0

        negative_mask = torch.cat((negative_mask, negative_mask), 0)

        return negative_mask

    def calc_loss(self, model, batch, k):

        if self.loss_type == NCEKLossArticle.LOG_LOSS:
            return self.calc_loss_log_loss(model, batch, k)
        elif self.loss_type == NCEKLossArticle.LOG_LOSS_BATCH and not self.no_collision:
            return self.calc_loss_log_loss_batched(model, batch, k)
        elif self.loss_type == NCEKLossArticle.LOG_LOSS_BATCH and self.no_collision:
            return self.calc_loss_log_loss_batched_no_coll(model, batch, k)
        elif self.loss_type == NCEKLossArticle.MARGIN:
            return self.calc_loss_margin(model, batch, k)
        else:
            raise AssertionError("Unhandled loss type %r" % self.constants["loss"])

    def calc_loss_log_loss_batched(self, model, batch, k):

        # A single point contains the following in order:
        #   x_token, x_count, x_pos_token, x_pos_count, x_negs_token, x_negs_count
        #   x_token, x_count, x_pos_token, x_pos_count are of size max_len while
        #    x_negs_token, x_negs_count is of size k x max_len

        batch_size = len(batch)

        # Next two tensors are of size batch x max_len
        x_token = cuda_var(torch.cat([torch.from_numpy(point[0]).view(1, -1) for point in batch], dim=0)).long()
        x_count = cuda_var(torch.cat([torch.from_numpy(point[1]).view(1, -1) for point in batch], dim=0)).float()

        # Next two tensors are of size batch x max_len
        x_pos_token = cuda_var(torch.cat([torch.from_numpy(point[2]).view(1, -1) for point in batch], dim=0)).long()
        x_pos_count = cuda_var(torch.cat([torch.from_numpy(point[3]).view(1, -1) for point in batch], dim=0)).float()

        x_all_token = torch.cat([x_token, x_pos_token], dim=0)       # 2 batch x max_len
        x_all_pos_count = torch.cat([x_count, x_pos_count], dim=0)   # 2 batch x max_len

        encoding = model.encode_input(x_all_token, x_all_pos_count)      # 2 batch x dim
        encoding_x1 = encoding[:batch_size, :]                       # batch x dim
        encoding_x2 = encoding[batch_size:, :]                       # batch x dim

        pos = (encoding_x1 * encoding_x2).sum(1)              # batch
        pos = torch.cat([pos, pos], dim=0)                    # 2 batch

        neg_scores = torch.mm(encoding, encoding.t().contiguous())   # 2 batch x 2 batch

        # 2 batch x 2 batch with each row having 2 * (batch - 1) 1's and remaining 0's
        default_mask = cuda_var(self.mask[batch_size])
        # neg_scores = neg_scores.masked_select(default_mask).view(2 * batch_size, -1)  # 2 batch x k

        # We select k <= 2 * (batch - 1) columns for each row without replacement.
        # We only pick those whose default_mask is 1
        sampled_indices = torch.multinomial(default_mask / default_mask.sum(1)[:, None],
                                            num_samples=k,
                                            replacement=False)  # 2 batch x k
        neg_scores = neg_scores.gather(1, sampled_indices)      # 2 batch x k

        denom = torch.cat([pos.view(-1, 1), neg_scores], dim=1)      # 2 batch x (k + 1)
        loss = - pos / self.temperature + torch.logsumexp(denom / self.temperature, dim=1)                # 2 batch
        loss = loss.mean()

        return loss, dict()

    def calc_loss_log_loss_batched_no_coll(self, model, batch, k):

        # A single point contains the following in order:
        #   x_token, x_count, x_pos_token, x_pos_count, x_negs_token, x_negs_count
        #   x_token, x_count, x_pos_token, x_pos_count are of size max_len while
        #    x_negs_token, x_negs_count is of size k x max_len

        batch_size = len(batch)

        # Next two tensors are of size batch x max_len
        x_token = cuda_var(torch.cat([torch.from_numpy(point[0]).view(1, -1) for point in batch], dim=0)).long()
        x_count = cuda_var(torch.cat([torch.from_numpy(point[1]).view(1, -1) for point in batch], dim=0)).float()

        # Next two tensors are of size batch x max_len
        x_pos_token = cuda_var(torch.cat([torch.from_numpy(point[2]).view(1, -1) for point in batch], dim=0)).long()
        x_pos_count = cuda_var(torch.cat([torch.from_numpy(point[3]).view(1, -1) for point in batch], dim=0)).float()

        class_label = cuda_var(torch.LongTensor([point[4] for point in batch])).long().view(-1)     # 2 batch
        class_label = torch.cat([class_label, class_label], dim=0)                                  # 2 batch

        class_mask = class_label.view(2 * batch_size, 1) != class_label.view(1, 2 * batch_size)     # 2 batch x 2 batch
        class_mask = class_mask.float()

        # We want each row of class_mask to have at least k entries so we can sample
        if min(class_mask.sum(1)).item() < k:   # 2 batch
            return None, dict()

        x_all_token = torch.cat([x_token, x_pos_token], dim=0)       # 2 batch x max_len
        x_all_pos_count = torch.cat([x_count, x_pos_count], dim=0)   # 2 batch x max_len

        encoding = model.encode_input(x_all_token, x_all_pos_count)      # 2 batch x dim
        encoding_x1 = encoding[:batch_size, :]                       # batch x dim
        encoding_x2 = encoding[batch_size:, :]                       # batch x dim

        pos = (encoding_x1 * encoding_x2).sum(1)              # batch
        pos = torch.cat([pos, pos], dim=0)                    # 2 batch

        neg_scores = torch.mm(encoding, encoding.t().contiguous())   # 2 batch x 2 batch

        # We select k <= 2 * (batch - 1) columns for each row without replacement.
        # We only pick those whose default_mask is 1
        sampled_indices = torch.multinomial(class_mask / class_mask.sum(1)[:, None],
                                            num_samples=k,
                                            replacement=False)  # 2 batch x k
        neg_scores = neg_scores.gather(1, sampled_indices)      # 2 batch x k

        denom = torch.cat([pos.view(-1, 1), neg_scores], dim=1)      # 2 batch x (k + 1)
        loss = - pos / self.temperature + torch.logsumexp(denom / self.temperature, dim=1)                # 2 batch
        loss = loss.mean()

        return loss, dict()

    @staticmethod
    def calc_loss_log_loss(model, batch, k):

        # A single point contains the following in order:
        #   x_token, x_count, x_pos_token, x_pos_count, x_negs_token, x_negs_count
        #   x_token, x_count, x_pos_token, x_pos_count are of size max_len wihle
        #    x_negs_token, x_negs_count is of size k x max_len

        # Next two tensors are of size batch x max_len
        x_token = cuda_var(torch.cat([torch.from_numpy(point[0]).view(1, -1) for point in batch], dim=0)).long()
        x_count = cuda_var(torch.cat([torch.from_numpy(point[1]).view(1, -1) for point in batch], dim=0)).float()

        # Next two tensors are of size batch x max_len
        x_pos_token = cuda_var(torch.cat([torch.from_numpy(point[2]).view(1, -1) for point in batch], dim=0)).long()
        x_pos_count = cuda_var(torch.cat([torch.from_numpy(point[3]).view(1, -1) for point in batch], dim=0)).float()

        # Next two tensors are of size batch x k x max_len
        x_neg_token = cuda_var(torch.cat([torch.from_numpy(point[4]).view(1, k, -1) for point in batch], dim=0)).long()
        x_neg_count = cuda_var(torch.cat([torch.from_numpy(point[5]).view(1, k, -1) for point in batch], dim=0)).float()

        x_pos_gen_score = model.gen_score(x_token, x_count, x_pos_token, x_pos_count)  # Batch
        x_neg_gen_score = model.gen_score(x_token, x_count, x_neg_token, x_neg_count)  # Batch x k
        x_pos_neg = torch.cat([x_pos_gen_score[:, None], x_neg_gen_score], dim=1)  # Batch x (K + 1)

        diff = x_pos_neg - x_pos_gen_score[:, None]        # Batch x (k + 1)
        loss = torch.logsumexp(diff, dim=1)                # Batch
        loss = loss.mean()

        # loss = loss / float(k)                             # Divide by k to avoid gradients being scaled with k

        info_dict = {"loss": loss}

        return loss, info_dict

    @staticmethod
    def calc_loss_unsup(model, batch, k):

        # A single point contains the following in order:
        #   x_token, x_count, x_pos_token, x_pos_count, x_negs_token, x_negs_count, x_pos_class, x_neg_class
        #   x_token, x_count, x_pos_token, x_pos_count are of size max_len wihle
        #    x_negs_token, x_negs_count is of size k x max_len

        # Next two tensors are of size batch x max_len
        x_token = cuda_var(torch.cat([torch.from_numpy(point[0]).view(1, -1) for point in batch], dim=0)).long()
        x_count = cuda_var(torch.cat([torch.from_numpy(point[1]).view(1, -1) for point in batch], dim=0)).float()

        # Next two tensors are of size batch x max_len
        x_pos_token = cuda_var(torch.cat([torch.from_numpy(point[2]).view(1, -1) for point in batch], dim=0)).long()
        x_pos_count = cuda_var(torch.cat([torch.from_numpy(point[3]).view(1, -1) for point in batch], dim=0)).float()

        # Next two tensors are of size batch x k x max_len
        x_neg_token = cuda_var(torch.cat([torch.from_numpy(point[4]).view(1, k, -1) for point in batch], dim=0)).long()
        x_neg_count = cuda_var(torch.cat([torch.from_numpy(point[5]).view(1, k, -1) for point in batch], dim=0)).float()

        x_pos_class = cuda_var(torch.cat([torch.from_numpy(np.array(point[6])).view(-1) for point in batch], dim=0)).long()
        x_neg_class = cuda_var(torch.cat([torch.from_numpy(point[7]).view(1, k) for point in batch], dim=0)).long()

        # 1 if it is 1 then we need to mask it
        mask = (x_pos_class[:, None] == x_neg_class).float()        # Batch x k

        x_pos_gen_score = model.gen_score(x_token, x_count, x_pos_token, x_pos_count)  # Batch
        x_neg_gen_score = model.gen_score(x_token, x_count, x_neg_token, x_neg_count)  # Batch x k
        x_pos_neg = torch.cat([x_pos_gen_score[:, None], x_neg_gen_score], dim=1)  # Batch x (K + 1)

        diff = x_pos_neg - x_pos_gen_score[:, None]        # Batch x (k + 1)

        # Apply the mask, note the first row containing x+ should not be masked out
        diff[:, 1:] = diff[:, 1:] - 1e6 * mask             # Batch x (k + 1)

        loss = torch.logsumexp(diff, dim=1)                # Batch
        loss = loss.mean()

        encoded_val = model.encode_input(x_token, x_count).detach().cpu().data.numpy()      # Batch x dim

        return loss, encoded_val

    @staticmethod
    def calc_loss_margin(model, batch, k):

        # A single point contains the following in order:
        #   x_token, x_count, x_pos_token, x_pos_count, x_negs_token, x_negs_count
        #   x_token, x_count, x_pos_token, x_pos_count are of size max_len wihle
        #    x_negs_token, x_negs_count is of size k x max_len

        # Next two tensors are of size batch x max_len
        x_token = cuda_var(torch.cat([torch.from_numpy(point[0]).view(1, -1) for point in batch], dim=0)).long()
        x_count = cuda_var(torch.cat([torch.from_numpy(point[1]).view(1, -1) for point in batch], dim=0)).float()

        # Next two tensors are of size batch x max_len
        x_pos_token = cuda_var(torch.cat([torch.from_numpy(point[2]).view(1, -1) for point in batch], dim=0)).long()
        x_pos_count = cuda_var(torch.cat([torch.from_numpy(point[3]).view(1, -1) for point in batch], dim=0)).float()

        # Next two tensors are of size batch x k x max_len
        x_neg_token = cuda_var(torch.cat([torch.from_numpy(point[4]).view(1, k, -1) for point in batch], dim=0)).long()
        x_neg_count = cuda_var(torch.cat([torch.from_numpy(point[5]).view(1, k, -1) for point in batch], dim=0)).float()

        x_pos_gen_score = model.gen_score(x_token, x_count, x_pos_token, x_pos_count)  # Batch
        x_neg_gen_score = model.gen_score(x_token, x_count, x_neg_token, x_neg_count)  # Batch x k

        gap = x_neg_gen_score - x_pos_gen_score[:, None]          # Batch x k
        max_gap, _ = torch.max(gap, dim=1)                        # Batch
        batch_margin_loss = torch.clamp(1 + max_gap, min=0.0)     # Batch
        loss = batch_margin_loss.mean()

        info_dict = {"loss": loss}

        return loss, info_dict

    def eval_model(self, model, test_batch, k):

        model_state = model.training
        model.eval()

        loss, info_dict = self.calc_loss(model, test_batch, k)

        if model_state:
            model.train()

        return loss, info_dict

    def _generate_nce_datapoint(self, task, k, data_type):

        if self.use_class_info:
            # Use class information to sample two different classes
            c_pos = task.sample_class()

            x_token, x_count = task.sample_from_class(c_pos, data_type)
            x_pos_token, x_pos_count = task.sample_from_class(c_pos, data_type)
        else:
            # Use data augmentation approach to create a pair
            x_token, x_count, x_pos_token, x_pos_count, c_pos = task.sample_pairs(data_type, return_class=True)

        if self.loss_type == NCEKLossArticle.LOG_LOSS_BATCH:
            return x_token, x_count, x_pos_token, x_pos_count

        # Force self.add_collision entries to come from the same class
        x_negs = [task.sample_from_class(c_pos, data_type, return_class=True) for _ in range(0, self.add_collision)]

        if self.forced_diversity:

            num_class = task.get_num_class()
            if num_class < 2:
                raise AssertionError("Cannot force diversity with fewer than 2 classes")

            class_id = 0
            to_add = k - self.add_collision
            while to_add > 0:

                if class_id != c_pos or not self.no_collision:
                    x_negs.append(task.sample_from_class(class_id, data_type, return_class=True))
                    to_add -= 1

                class_id = (class_id + 1) % num_class

        elif self.no_collision:
            # Remaining entries come from class other than c_pos
            x_negs = x_negs + [task.sample_except(c_pos, data_type, return_class=True)
                               for _ in range(0, k - self.add_collision)]
        else:
            # Remaining entries come from any class
            x_negs = x_negs + [task.sample(data_type, return_class=True) for _ in range(0, k - self.add_collision)]

        # x_negs is a list of tuple
        x_negs_token = np.vstack([x_neg[0] for x_neg in x_negs])     # k x max_len
        x_negs_count = np.vstack([x_neg[1] for x_neg in x_negs])     # k x max_len
        x_negs_class = np.array([x_neg[2] for x_neg in x_negs])      # k

        return x_token, x_count, x_pos_token, x_pos_count, x_negs_token, x_negs_count, c_pos, x_negs_class

    def generate_statistics(self, model, test_batches, k, logger):

        test_unsup_loss, num_test_examples = 0.0, 0
        features_per_class = dict()

        for test_batch in test_batches:

            loss, encoded_val = self.calc_loss_unsup(model, test_batch, k)

            for i, dp in enumerate(test_batch):
                class_id = dp[6]
                if class_id in features_per_class:
                    features_per_class[class_id].append(encoded_val[i, :])
                else:
                    features_per_class[class_id] = [encoded_val[i, :]]

            batch_size = len(test_batch)
            test_unsup_loss = test_unsup_loss + float(loss.item()) * batch_size
            num_test_examples = num_test_examples + batch_size

        test_unsup_loss = test_unsup_loss / float(max(1, num_test_examples))

        s_f = 0.0
        for class_id, encoded_features in features_per_class.items():

            feature_matrix = np.vstack(encoded_features)                            # Num_examples x dim
            mean_l2_norm = np.sqrt((feature_matrix * feature_matrix).sum(1)).mean()

            cov = np.cov(feature_matrix.T)                                          # dim x dim
            op_cov = np.linalg.norm(cov, ord=2)
            s_f += mean_l2_norm * math.sqrt(op_cov)

            logger.log("Class_id=%d. Mean l2 norm %f, Operator norm of covariance matrix %f. "
                       "Feature matrix has shape %r, and covariance matrix has shape %r" %
                       (class_id, mean_l2_norm, op_cov, feature_matrix.shape, cov.shape))

        s_f = s_f / float(max(1, len(features_per_class)))

        return test_unsup_loss, s_f

    def train(self, task, k, logger, tensorboard):

        logger.log("Performing Noise Contrastive Estimation with k=%d, batch size=%d, and loss type %s (%r)."
                   "Add colision %r, No collision %r, Forced diversity %r." %
                   (k, self.batch_size, self.constants["loss"], self.loss_type, self.add_collision,
                    self.no_collision, self.forced_diversity))

        unsup_train = "unsup_train" if self.use_class_info else "unsup_train_pair"
        unsup_test = "unsup_test" if self.use_class_info else "unsup_test_pair"

        time_dataset_start = time.time()
        test_dataset = [self._generate_nce_datapoint(task, k, unsup_test) for _ in range(0, self.eval_size)]
        logger.log("Time taken to process test dataset is %s" % (beautify(time.time() - time_dataset_start)))

        # Current model
        model = DiscriminatorWrapper.get_wrapper(self.config, self.constants)

        # Model for storing the best model as measured by performance on the test set
        best_model = DiscriminatorWrapper.get_wrapper(self.config, self.constants)

        logger.log("Logging random mean classifier performance")
        random_classifier_result = self.downstream_task.get_mean_classifier_acc(
            task=task,
            encoder_model=best_model,
            logger=logger,
            plot_fname="./seed_%d_random_plot.png" % (self.config["seed"])
                                                                                )
        logger.log("Logged")

        param_with_grad = filter(lambda p: p.requires_grad, model.parameters())
        optimizer = optim.Adam(params=param_with_grad, lr=self.lr)

        random.shuffle(test_dataset)
        test_batches = [test_dataset[i:i + self.batch_size] for i in range(0, self.eval_size, self.batch_size)]

        best_test_loss, best_epoch, train_loss = float('inf'), -1, float('inf')
        patience_counter = 0
        total_time_taken = 0

        for epoch_ in range(1, self.max_epoch + 1):

            time_dataset_start = time.time()
            train_dataset = [self._generate_nce_datapoint(task, k, unsup_train) for _ in range(0, self.train_size)]
            random.shuffle(train_dataset)
            train_batches = [train_dataset[i:i + self.batch_size] for i in range(0, self.train_size, self.batch_size)]
            time_taken = time.time() - time_dataset_start
            total_time_taken += time_taken

            logger.log("Time taken to process train dataset of size %d for epoch=%d, is %s. Total time taken %s" %
                       (self.train_size, epoch_, beautify(time_taken), beautify(total_time_taken)))

            train_loss, num_train_examples = 0.0, 0

            for train_batch in train_batches:

                loss, info_dict = self.calc_loss(model, train_batch, k)
                loss_val = float(loss.item())

                if np.isnan(loss_val) or np.isinf(loss_val):
                    logger.log("NCE Loss=%r is either Inf or NaN. Skippy updates for this one." % loss_val)
                    continue

                optimizer.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), self.grad_clip)
                optimizer.step()

                tensorboard.log_scalar("NCE Loss ", loss_val)

                for key in info_dict:
                    tensorboard.log_scalar(key, info_dict[key])

                batch_size = len(train_batch)
                train_loss = train_loss + loss_val * batch_size
                num_train_examples = num_train_examples + batch_size

            train_loss = train_loss / float(max(1, num_train_examples))

            # Evaluate on test batches
            test_loss, num_test_examples = 0.0, 0
            for test_batch in test_batches:
                loss, _ = self.eval_model(model, test_batch, k)

                batch_size = len(test_batch)
                test_loss = test_loss + float(loss.item()) * batch_size
                num_test_examples = num_test_examples + batch_size

            test_loss = test_loss / float(max(1, num_test_examples))

            logger.debug("NCE Train Loss after epoch %r is %f, Test Loss %f, Best Test Loss %f" %
                         (epoch_, train_loss, test_loss, min(best_test_loss, test_loss)))

            if test_loss < best_test_loss:
                patience_counter = 0
                best_test_loss = test_loss
                best_epoch = epoch_
                best_model.load_state_dict(model.state_dict())
            else:
                # Check patience condition
                patience_counter += 1  # number of epoch since last increase

                if patience_counter == self.patience:
                    logger.log("Patience Condition Triggered: No improvement for %r epochs" % patience_counter)
                    break

        # logger.log("Pretraining done. Logging some statistics")
        # l_unsup, s_f = self.generate_statistics(best_model, test_batches, k, logger)
        # logger.log("Found L_{unsup} = %f and S(f) = %f" % (l_unsup, s_f))

        # logger.log("Statistics logged. Starting downstream training.")
        logger.log("Starting downstream training.")
        downstream_result = self.downstream_task.train(task=task,
                                                       encoder_model=best_model,
                                                       logger=logger,
                                                       tensorboard=tensorboard)

        downstream_result["best_nce_test_loss"] = best_test_loss
        downstream_result["best_nce_best_epoch"] = best_epoch
        # downstream_result["best_nce_l_unsup"] = l_unsup
        # downstream_result["best_nce_s_f"] = s_f
        downstream_result["random_mean_classifier_acc"] = random_classifier_result["downstream_mean_classifier_acc"]
        downstream_result["random_mean_classifier_loss"] = random_classifier_result["downstream_mean_classifier_loss"]

        return downstream_result

    def train_fixed_epoch(self, task, k, logger, tensorboard):

        logger.log("Performing Noise Contrastive Estimation with k=%d, batch size=%d, and loss type %s (%r)."
                   "Add colision %r, No collision %r, Forced diversity %r." %
                   (k, self.batch_size, self.constants["loss"], self.loss_type, self.add_collision,
                    self.no_collision, self.forced_diversity))

        unsup_train = "unsup_train+unsup_test" if self.use_class_info else "unsup_train_pair+unsup_test_pair"

        assert self.loss_type == NCEKLossArticle.LOG_LOSS_BATCH, "Can only handle log_loss_batch"

        # Current model
        model = DiscriminatorWrapper.get_wrapper(self.config, self.constants)

        logger.log("Logging random mean classifier performance")
        random_classifier_result = self.downstream_task.get_mean_classifier_acc(
            task=task,
            encoder_model=model,
            logger=logger,
            plot_fname="./seed_%d_random_plot.png" % (self.config["seed"])
                                                                                )
        logger.log("Logged")

        param_with_grad = filter(lambda p: p.requires_grad, model.parameters())
        optimizer = optim.Adam(params=param_with_grad, lr=self.lr)

        succ_grad, failed_grad = 0, 0
        total_time_taken = 0

        for epoch_ in range(1, self.max_epoch + 1):

            time_dataset_start = time.time()
            train_dataset = task.get_paired_dataset(unsup_train)
            # train_dataset = [self._generate_nce_datapoint(task, k, unsup_train) for _ in range(0, self.train_size)]
            train_size = len(train_dataset)
            random.shuffle(train_dataset)
            train_batches = [train_dataset[i:i + self.batch_size] for i in range(0, train_size, self.batch_size)]
            time_taken = time.time() - time_dataset_start
            total_time_taken += time_taken

            logger.log("Time taken to process train dataset of size %d for epoch=%d, is %s. Total time taken %s" %
                       (train_size, epoch_, beautify(time_taken), beautify(total_time_taken)))

            train_loss, num_train_examples = 0.0, 0

            for train_batch in train_batches:

                if self.loss_type == NCEKLossArticle.LOG_LOSS_BATCH and k > 2 * (len(train_batch) - 1):
                    # In batch mode, we can sample at most 2 * (batch - 1) many k.
                    continue

                loss, info_dict = self.calc_loss(model, train_batch, k)

                if loss is None:
                    failed_grad += 1
                    continue
                else:
                    succ_grad += 1

                loss_val = float(loss.item())

                if np.isnan(loss_val) or np.isinf(loss_val):
                    logger.log("NCE Loss=%r is either Inf or NaN. Skippy updates for this one." % loss_val)
                    continue

                optimizer.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), self.grad_clip)
                optimizer.step()

                tensorboard.log_scalar("NCE Loss ", loss_val)

                for key in info_dict:
                    tensorboard.log_scalar(key, info_dict[key])

                batch_size = len(train_batch)
                train_loss = train_loss + loss_val * batch_size
                num_train_examples = num_train_examples + batch_size

            train_loss = train_loss / float(max(1, num_train_examples))
            logger.debug("NCE Train Loss after epoch %r is %f" % (epoch_, train_loss))

        # logger.log("Pretraining done. Logging some statistics")
        # l_unsup, s_f = self.generate_statistics(best_model, test_batches, k, logger)
        # logger.log("Found L_{unsup} = %f and S(f) = %f" % (l_unsup, s_f))

        # logger.log("Statistics logged. Starting downstream training.")
        logger.log("Starting downstream training.")
        downstream_result = self.downstream_task.train(task=task,
                                                       encoder_model=model,
                                                       logger=logger,
                                                       tensorboard=tensorboard)

        # downstream_result["best_nce_l_unsup"] = l_unsup
        # downstream_result["best_nce_s_f"] = s_f
        downstream_result["random_mean_classifier_acc"] = random_classifier_result["downstream_mean_classifier_acc"]
        downstream_result["random_mean_classifier_loss"] = random_classifier_result["downstream_mean_classifier_loss"]
        downstream_result["failed_grad"] = failed_grad
        downstream_result["succ_grad"] = succ_grad
        downstream_result["succ_grad_ratio"] = (succ_grad * 100.0) / float(max(1, succ_grad + failed_grad))

        return downstream_result
