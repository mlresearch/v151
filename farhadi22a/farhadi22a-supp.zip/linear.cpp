#include <iostream>
#include <vector>
#include <set>
#include <queue>
#include <random>
#include <thread>


using namespace std;

const int MN=1000*1000;




const int tno=8;

const int repeat=100;

double _eps=1e-6;

vector<double> ec={0.1,0.2,0.5,1,2,3.5,5};

int n,m;
vector<int> list[MN];


double cdf(double b, double x)
{
	if (x>=0) return 1-0.5*exp(-x/b);
	return 0.5*exp(x/b);
}



random_device seedgen[tno]; 
mt19937 gen[tno];
uniform_real_distribution<> dis[tno];

double random(int no)
{
	return dis[no](gen[no]);
}

double exp_sample(double scale,int no)
{
	return -scale*log(random(no));
}

double random(double scale,int no)
{
	double e1=exp_sample(scale,no),e2=exp_sample(scale,no);
	return e1-e2;
}



double random_uniform(int no)
{
	return random(no);
}


class prefix_sum
{
	public:
		prefix_sum(double _eps,int _no)
		{
			no=_no;
			eps=_eps;
		}
		int no;
		double eps=0;
		double sum=0,sumerr=0;
		vector<pair<int,double> > errs;
		void add(double v)
		{
			sum+=v;
			errs.push_back({1,random(log(n)/eps,no)});
			while (errs.size()>1 && errs[errs.size()-1].first==errs[errs.size()-2].first)
			{
				int t=errs[errs.size()-1].first;
				errs.pop_back();
				errs.pop_back();
				errs.push_back({2*t,random(log(n)/eps,no)});
			}
			sumerr=0;
			for (auto & x:errs) sumerr+=x.second;
		}
		double get()
		{
			return sum+sumerr;
		}
};
double deg[tno][MN];
vector<prefix_sum> ps[tno];
bool mark[tno][MN];
int cnt[tno][MN];
double noise[tno][MN];
int cnter[tno][MN];
int queueno[tno][MN];

vector<pair<int,int> > _queue[tno][MN];

int pointer[tno];


int tau(double dis,int no, double eps)
{
	double p=cdf(1/eps,dis);
	if (p>=1-1e-6) return (1<<29);
	double r=random(no);
	return round(max(1.,ceil(log(1-r)/log(p))));
}

void add(int no,int v, double eps, double gamma)
{
	queueno[no][v]++;
	int bucketsize=1/eps*log(n)*log(1/gamma);
	double _deg=deg[no][v]-ps[no][v].get();
	_deg=max(_deg,0.);
	int b=ceil(_deg/bucketsize);
	_queue[no][b].push_back({v,queueno[no][v]});
}
int get(int no)
{
	pointer[no]=max(0,pointer[no]-1);
	while (pointer[no]<MN)
	{
		int & p=pointer[no];
		while (_queue[no][p].size()>0)
		{
			auto & x=_queue[no][p].back();
			_queue[no][p].resize(_queue[no][p].size()-1);
			if (x.second==queueno[no][x.first])
				return x.first;
		}
		p++;
	}
	return -1;
}

double dsp_dp(double eps, double gamma,int no)
{
	for (int i=0;i<n;i++) queueno[no][i]=0, cnter[no][i]=0;
	pointer[no]=0;
	double t=1/eps*log(n)*log(1/gamma);
	ps[no].clear();
	for (int i=0;i<MN;i++) _queue[no][i].clear();
	for (int i=0;i<n;i++) ps[no].push_back(prefix_sum(eps,no));
	for (int i=0;i<n;i++) deg[no][i]=list[i].size()+random(2/eps,no),mark[no][i]=0,cnt[no][i]=0;
	for (int i=0;i<n;i++) add(no,i,eps,gamma);
	for (int i=0;i<n;i++) noise[no][i]=random(1/eps,no);
	int te=m;
	double dmax=0, sol=0;
	vector<vector<pair<int,int>>> events;
	events.resize(n);
	for (int i=0;i<n;i++)
	{
		auto v=get(no);
		if (v==-1) break;
		mark[no][v]=true;
		sol=max(sol,min(double(n-i-1)/2,(te+random(1/eps,no))/(n-i)));
		for (auto & x:list[v]) if (!mark[no][x])
		{
			te--;
			cnt[no][x]++;
			int step=tau(t-cnt[no][x]-noise[no][x],no,eps);
			cnter[no][x]++;
			if (i+step-1<n)
				events[i+step-1].push_back({x,cnter[no][x]});
		}
		for (auto & x: events[i]) if (!mark[no][x.first] && cnter[no][x.first]==x.second)
		{
			int j=x.first;
			ps[no][j].add(cnt[no][j]);
			add(no,i,eps,gamma);
			cnt[no][j]=0;
			noise[no][j]=random(1/eps,no);
			int step=tau(t-cnt[no][j]-noise[no][j],no,eps);
			cnter[no][j]++;
			if (i+step-1<n)
				events[i+step-1].push_back({j,cnter[no][j]});
		}
	}
	return sol;
}


double thread_answer[tno+10];

void dsp_dp_thread(double eps, double gamma, int no)
{
	double res=0;
	for (int i=no;i<repeat;i+=tno) res+=dsp_dp(eps,gamma,no);
	thread_answer[no]=res;
}
double _time;
double dsp_dp_multiple_thread(double eps,double gamma)
{
	_time=time(0);
	vector<thread> _threads;
	for (int i=0;i<tno;i++)
		_threads.push_back(thread(dsp_dp_thread,eps,gamma,i));
	for (auto & x:_threads) x.join();
	double res=0;
	for (int i=0;i<tno;i++) res+=thread_answer[i];
	_time=time(0)-_time;
	return res/repeat;
}

int c_deg[MN];
bool c_mark[MN];

double dsp_charikar()
{
	for (int i=0;i<n;i++) c_deg[i]=list[i].size(),c_mark[i]=0;
	int te=m;
	double dmax=0, sol=0;
	for (int i=0;i<n;i++)
	{
		double mn=1e20; int v=-1;
		for (int j=0;j<n;j++) if (!c_mark[j] && c_deg[j]<mn)
			mn=c_deg[j],v=j;
		c_mark[v]=true;
		sol=max(sol,min(double(n-i-1)/2,double(te)/(n-i)));
		for (auto & x:list[v]) if (!c_mark[x])
		{
			te--;
			c_deg[x]--;
		}
	}
	return sol;
}

set<pair<int,int>> edge_mark;
int main() 
{
	for (int i=0;i<tno;i++)
	{
		gen[i]=mt19937(seedgen[i]());
		dis[i]=uniform_real_distribution<> (0,1);
	}

	cin>>n>>m;
	for (int i=0;i<m;i++)
	{
		int a,b;
		cin>>a>>b; a--; b--;
		if (edge_mark.find({a,b})!=edge_mark.end() || a==b)
			cout<<"Invalid input!"<<endl;
		edge_mark.insert({a,b});
		edge_mark.insert({b,a});
		list[a].push_back(b);
		list[b].push_back(a);
	}
	cout<<"Charikar: "<<dsp_charikar()<<endl;
	for (double eps:ec)
	{
		double gamma=1;
		for (int i=0;i<30;i++) gamma/=2;
		cout<<"Epsilon: "<<eps<<", Sol: "<<dsp_dp_multiple_thread(eps/4,gamma)<<endl;
		cout<<"Time: "<<_time<<endl;
	}

	return 0;
}
