import sys
import os

print("Checking in", file=sys.stderr, flush=True)
os.system("echo blah > blah2.txt")