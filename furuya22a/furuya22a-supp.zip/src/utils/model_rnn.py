from typing import Tuple

import torch
import torch.nn as nn
from torch import Tensor


class classifier_rnn(nn.Module):
    """(Basic) RNN for classification task."""

    def __init__(
        self,
        input_size: int,
        hidden_size: int,
        num_layers: int,
        output_size: int,
        irnn: bool = False,
    ):
        super(classifier_rnn, self).__init__()
        nonlinearity = "relu" if irnn else "tanh"
        self.rnn = nn.RNN(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            bias=True,
            batch_first=True,
            nonlinearity=nonlinearity,
        )
        self.out = nn.Linear(hidden_size, output_size, bias=True)
        self.hidden_size = hidden_size
        self.irnn = irnn
        if irnn:
            self.init_weights()

    def init_weights(self) -> None:
        # Initialize h2h weights to identity function
        # [A Simple Way to Initialize Recurrent Networks of Rectified Linear Units](https://arxiv.org/abs/1504.00941)
        for p in self.rnn.named_parameters():
            if "weight_hh_l" in p[0]:
                nn.init.eye_(p[1])
            elif "bias_hh_l" in p[0]:
                nn.init.zeros_(p[1])
            else:
                pass

    def forward(self, x: Tensor, s: Tensor = None) -> Tuple[Tensor, Tensor]:
        _, output = self.rnn(x, s)
        output = self.out(output)
        return output


class classifier_rnn_CS(classifier_rnn):
    """CS means Column Sparsification.

    [Acceleration of LSTM With Structured Pruning Method on FPGA](https://ieeexplore.ieee.org/document/8716654)
    """

    def __init__(
        self,
        input_size: int,
        hidden_size: int,
        m_sharp: int,
        num_layers: int,
        output_size: int,
        irnn: bool = False,
    ):
        super().__init__(input_size, hidden_size, num_layers, output_size, irnn)
        setattr(self, "m_sharp", m_sharp)
        setattr(self, "removed", False)

    def forward(self, inputs: Tensor, hidden: Tensor = None) -> Tuple[Tensor, Tensor]:
        if self.removed:
            output = super().forward(inputs, hidden)
        else:
            # Computational graph does not record this mask
            h2h_tmp = self.rnn.weight_hh_l0.data.clone()
            mask = self.get_structured_mask(h2h_tmp, self.m_sharp)
            self.rnn.weight_hh_l0.data.mul_(mask)

            output = super().forward(inputs, hidden)

            # Reset the mask
            self.rnn.weight_hh_l0.data = h2h_tmp
        return output

    def get_structured_mask(self, tensor, m_sharp):
        with torch.no_grad():
            norm = torch.norm(tensor, dim=0, p=1)
            norm += torch.randn_like(norm) * norm.min() / 1000  # noise for IRNN
            idx = torch.topk(norm, m_sharp, largest=True).indices
            mask = torch.full_like(tensor, False, dtype=bool)
            mask[:, idx] = True
        return mask

    def remove_mask_(self):
        if self.removed:
            raise Exception("Mask has already removed.")
        else:
            mask = self.get_structured_mask(self.rnn.weight_hh_l0, self.m_sharp)
            self.rnn.weight_hh_l0.data.mul_(mask)
            self.removed = True


class classifier_rnn4FT(classifier_rnn):
    """Non-structured-pruned RNN for fine-tuning."""

    def __init__(
        self,
        input_size: int,
        hidden_size: int,
        num_layers: int,
        output_size: int,
        irnn: bool = False,
    ):
        super().__init__(input_size, hidden_size, num_layers, output_size, irnn)
        setattr(self, "mask", 1)
        setattr(self, "mask_keys", [])

    def forward(self, x: Tensor, s: Tensor = None) -> Tuple[Tensor, Tensor]:
        self.update_weight()
        output = super().forward(x, s)
        return output

    def set_mask(self, mask: Tensor, keys: str) -> None:
        self.mask = mask
        self.mask_keys = keys

    def update_weight(self) -> None:
        for key in self.mask_keys:
            self.state_dict()[key] *= self.mask


def prepare_trained_rnn(weight, irnn: bool, requires_grad: bool = False, m_sharp: int = None, ft: bool = False):
    """Return trained RNN model whose parameters have `requires_grad` option."""
    input_size = weight["rnn.weight_ih_l0"].shape[1]
    hidden_size = weight["rnn.weight_ih_l0"].shape[0]
    output_size = weight["out.weight"].shape[0]
    if ft:
        model = classifier_rnn4FT(
            input_size=input_size, hidden_size=hidden_size, num_layers=1, output_size=output_size, irnn=irnn
        )
    elif m_sharp is None:
        model = classifier_rnn(
            input_size=input_size, hidden_size=hidden_size, num_layers=1, output_size=output_size, irnn=irnn
        )
    else:
        model = classifier_rnn_CS(
            input_size=input_size,
            m_sharp=m_sharp,
            hidden_size=hidden_size,
            num_layers=1,
            output_size=output_size,
            irnn=irnn,
        )
    model.load_state_dict(weight)

    for param in model.parameters():
        param.requires_grad = requires_grad
    return model
