function IX = free_set(u, grad, lambda)
    IX = ~((grad > 10 * eps & u == -lambda) | (grad < -10 * eps & u == lambda));
end

