#!/bin/bash
#SBATCH --partition=p100
#SBATCH -c 2
#SBATCH --account=legacy
#SBATCH --qos=legacy
#SBATCH --mem=16G
#SBATCH --gres=gpu:1
#SBATCH --array=0-11%12
#SBATCH --output=logs/task_%A_%a.log


list=(
"python -W ignore main.py --arch resnet --resample False --dataset svhn --adv_loss hinge --g_lr 2e-3 --d_lr 2e-3 --optim extra-sgd"
"python -W ignore main.py --arch resnet --resample False --dataset svhn --adv_loss hinge --g_lr 1e-3 --d_lr 1e-3 --optim extra-sgd"
"python -W ignore main.py --arch resnet --resample False --dataset svhn --adv_loss hinge --g_lr 5e-3 --d_lr 5e-3 --optim extra-sgd"
"python -W ignore main.py --arch resnet --resample False --dataset svhn --adv_loss hinge --g_lr 1e-2 --d_lr 1e-2 --optim extra-sgd"
"python -W ignore main.py --arch resnet --resample False --dataset svhn --adv_loss hinge --g_lr 2e-2 --d_lr 2e-2 --optim extra-sgd"
"python -W ignore main.py --arch resnet --resample False --dataset svhn --adv_loss hinge --g_lr 5e-4 --d_lr 5e-4 --optim extra-sgd"
"python -W ignore main.py --arch resnet --resample False --alternating False --dataset svhn --adv_loss hinge --g_lr 2e-3 --d_lr 2e-3 --optim extra-sgd"
"python -W ignore main.py --arch resnet --resample False --alternating False --dataset svhn --adv_loss hinge --g_lr 1e-3 --d_lr 1e-3 --optim extra-sgd"
"python -W ignore main.py --arch resnet --resample False --alternating False --dataset svhn --adv_loss hinge --g_lr 5e-3 --d_lr 5e-3 --optim extra-sgd"
"python -W ignore main.py --arch resnet --resample False --alternating False --dataset svhn --adv_loss hinge --g_lr 1e-2 --d_lr 1e-2 --optim extra-sgd"
"python -W ignore main.py --arch resnet --resample False --alternating False --dataset svhn --adv_loss hinge --g_lr 2e-2 --d_lr 2e-2 --optim extra-sgd"
"python -W ignore main.py --arch resnet --resample False --alternating False --dataset svhn --adv_loss hinge --g_lr 5e-4 --d_lr 5e-4 --optim extra-sgd"
)
${list[SLURM_ARRAY_TASK_ID]} --bup_path /checkpoint/${SLURM_JOB_USER}/${SLURM_JOB_ID} --total_step 400000