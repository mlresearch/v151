import os
import time
import datetime
import copy
import numpy as np
import json
import torch
import torch.nn as nn
from torch.autograd import Variable
from torchvision.utils import save_image
from torch.distributions import bernoulli
from utils import *
import tensorflow.compat.v1 as tf
import math
import functools
import misc.fid as fid
import misc.inception_utils as inception_utils
from ckpt_utils.save_func import checkpoint_save
from ckpt_utils.load_func import latest_checkpoint_load


class Trainer(object):
    def __init__(self, data_loader, config):
        # Fix seed
        torch.manual_seed(config.seed)
        torch.cuda.manual_seed(config.seed)

        # Data loader
        self.data_loader = data_loader

        # arch and loss
        self.arch = config.arch
        self.adv_loss = config.adv_loss

        # Model hyper-parameters
        self.imsize = config.imsize
        self.g_num = config.g_num
        self.z_dim = config.z_dim
        self.g_conv_dim = config.g_conv_dim
        self.d_conv_dim = config.d_conv_dim
        self.parallel = config.parallel

        self.lambda_gp = config.lambda_gp
        self.total_step = config.total_step
        self.d_iters = config.d_iters
        self.batch_size = config.batch_size
        self.num_workers = config.num_workers
        self.g_lr = config.g_lr
        self.d_lr = config.d_lr
        self.optim = config.optim
        self.lr_scheduler = config.lr_scheduler
        self.g_beta1 = config.g_beta1
        self.d_beta1 = config.d_beta1
        self.beta2 = config.beta2
        self.pretrained_model = config.pretrained_model
        self.momentum = config.momentum
        self.alternating = config.alternating
        self.resample = config.resample

        self.dataset = config.dataset
        self.use_tensorboard = config.use_tensorboard
        self.image_path = config.image_path
        self.log_path = config.log_path
        self.model_save_path = config.model_save_path
        self.sample_path = config.sample_path
        self.log_step = config.log_step
        self.sample_step = config.sample_step
        self.model_save_step = config.model_save_step
        self.version = config.version
        self.backup_freq = config.backup_freq
        self.bup_path = config.bup_path
        self.metrics_path = config.metrics_path

        self.build_model()

        # imagenet
        if self.dataset == 'imagenet':
            z_ = inception_utils.prepare_z_(self.batch_size, self.z_dim, device='cuda', z_var=1.0)
            # Prepare Sample function for use with inception metrics
            self.sample_G_func = functools.partial(inception_utils.sample, G=self.G, z_=z_)
            self.sample_G_ema_func = functools.partial(inception_utils.sample, G=self.G_ema, z_=z_)
            # Prepare inception metrics: FID and IS
            self.get_inception_metrics = inception_utils.prepare_inception_metrics(dataset="./I32",
                                                                               parallel=False, no_fid=False)

        if self.use_tensorboard:
            self.build_tensorboard()

        # Start with trained model
        if self.pretrained_model:
            self.load_pretrained_model()

        self.info_logger = setup_logger(self.log_path)
        self.info_logger.info(config)
        self.fid_freq = config.fid_freq

        if self.fid_freq > 0 and self.dataset != 'imagenet':
            self.fid_json_file = os.path.join(self.model_save_path, '../FID', 'fid.json')
            self.sample_size_fid = config.sample_size_fid
            if os.path.isfile(self.fid_json_file):
                # load json files with fid scores
                self.fid_scores = load_json(self.fid_json_file)
            else:
                self.fid_scores = []
            sample_noise = torch.FloatTensor(self.sample_size_fid, self.z_dim).normal_()
            self.fid_noise_loader = torch.utils.data.DataLoader(sample_noise,
                                                                batch_size=200,
                                                                shuffle=False)
            # Inception Network
            _INCEPTION_PTH = fid.check_or_download_inception('./precalculated_statistics/inception-2015-12-05.pb')
            self.info_logger.info('Loading the Inception Network from: {}'.format(_INCEPTION_PTH))
            fid.create_inception_graph(_INCEPTION_PTH)  # load the graph into the current TF graph
            _gpu_options = tf.GPUOptions(per_process_gpu_memory_fraction=0.4)
            # _gpu_options = tf.compat.v1.GPUOptions(per_process_gpu_memory_fraction=0.4)
            self.fid_session = tf.Session(config=tf.ConfigProto(gpu_options=_gpu_options))
            self.info_logger.info('Loading real data FID stats from: {}'.format(config.fid_stats_path))
            _real_fid = np.load(config.fid_stats_path)
            self.mu_real, self.sigma_real = _real_fid['mu'][:], _real_fid['sigma'][:]
            _real_fid.close()
            make_folder(os.path.dirname(self.fid_json_file))
        elif self.fid_freq > 0:
            # make_folder(self.path)
            self.metrics_json_file = os.path.join(self.metrics_path, 'metrics.json')

    def train(self):
        self.data_gen = self._data_gen()

        # Fixed noise
        fixed_z = tensor2var(torch.randn(self.batch_size, self.z_dim))

        start = self.load_backup()

        if self.lr_scheduler > 0:
            _epoch = (start // len(self.data_loader)) if start > 0 else -1
            # Exponentially decaying learning rate
            self.scheduler_g = torch.optim.lr_scheduler.ExponentialLR(self.g_optimizer,
                                                                      gamma=self.lr_scheduler,
                                                                      last_epoch=_epoch)
            self.scheduler_d = torch.optim.lr_scheduler.ExponentialLR(self.d_optimizer,
                                                                      gamma=self.lr_scheduler,
                                                                      last_epoch=_epoch)
            self.scheduler_g_extra = torch.optim.lr_scheduler.ExponentialLR(self.g_optimizer_extra,
                                                                            gamma=self.lr_scheduler,
                                                                            last_epoch=_epoch)
            self.scheduler_d_extra = torch.optim.lr_scheduler.ExponentialLR(self.d_optimizer_extra,
                                                                            gamma=self.lr_scheduler,
                                                                            last_epoch=_epoch)

        # Start time
        start_time = time.time()
        for step in range(start, self.total_step):

            # ================= Train pair ================= #
            self._update_pair(step)

            # Print out log info
            if (step + 1) % self.log_step == 0:
                elapsed = time.time() - start_time
                elapsed = str(datetime.timedelta(seconds=elapsed))
                print("Elapsed [{}], Step [{}/{}]".format(elapsed, step + 1, self.total_step))

            # Sample images
            if (step + 1) % self.sample_step == 0:
                save_image(denorm(self.G(fixed_z).data),
                           os.path.join(self.sample_path, 'gen', 'iter%08d.png' % step))
                save_image(denorm(self.G_ema(fixed_z).data),
                           os.path.join(self.sample_path, 'gen_ema', 'iter%08d.png' % step))
            if self.model_save_step > 0 and (step+1) % self.model_save_step == 0:
                torch.save(self.G.state_dict(),
                           os.path.join(self.model_save_path, 'gen', 'iter%08d.pth' % step))
                torch.save(self.G_ema.state_dict(),
                           os.path.join(self.model_save_path, 'gen_ema', 'iter%08d.pth' % step))
            if self.backup_freq > 0 and (step+1) % self.backup_freq == 0:
                self.backup(step)

            # If activated, compute Frechlet Inception Distance on the fly
            if self.fid_freq > 0 and (step + 1) % self.fid_freq == 0:
                if self.dataset == 'imagenet':
                    is_mean, is_std, FID = self.get_inception_metrics(self.sample_G_func, 50000, num_splits=10)
                    print("Non-EMA metrics: Step [{}/{}], FID: {}, IS: {}/{}".format(
                        step + 1, self.total_step, FID, is_mean, is_std))
                    is_mean_ema, is_std_ema, FID_ema = self.get_inception_metrics(self.sample_G_ema_func, 50000,
                                                                                  num_splits=10)
                    print("EMA metrics: Step [{}/{}], FID: {}, IS: {}/{}".format(
                        step + 1, self.total_step, FID_ema, is_mean_ema, is_std_ema))

                    with open(self.metrics_json_file, 'a') as fs:
                        s = json.dumps(dict(itr=step+1,
                                       FID=float(FID),
                                       FID_ema=float(FID_ema),
                                       IS_mean=float(is_mean),
                                       IS_std=float(is_std),
                                       IS_mean_ema=float(is_mean_ema),
                                       IS_std_ema=float(is_std_ema)))
                        fs.write(f"{s}\n")
                else:
                    self.compute_fid_score(generator=self.G, generator_ema=self.G_ema, timestamp=step)
                    self.info_logger.info("Step [{}/{}], FID: {} | EMA: {}".format(
                        step + 1, self.total_step, self.fid_scores[-1]['fid'], self.fid_scores[-1]['fid_ema']))
                    if self.use_tensorboard:
                        self.writter.add_scalars('metrics', 
                            {'FID_single': self.fid_scores[-1]['fid'], 
                            'FID_ema': self.fid_scores[-1]['fid_ema']}, step + 1)

    def _data_gen(self):
        """ Data iterator

        :return: s
        """
        data_iter = iter(self.data_loader)
        while True:
            try:
                real_images, _ = next(data_iter)
            except StopIteration:
                data_iter = iter(self.data_loader)
                real_images, _ = next(data_iter)
            yield real_images

    def _disc_loss(self, real_images, fake_images, d_out_real, d_out_fake):
        if self.adv_loss == 'wgan-gp':
            d_loss = - d_out_real.mean() + d_out_fake.mean()
        elif self.adv_loss == 'hinge':
            d_loss = torch.nn.ReLU()(1.0 - d_out_real).mean() + torch.nn.ReLU()(1.0 + d_out_fake).mean()
        else:
            raise NotImplementedError

        if self.adv_loss == 'wgan-gp':  # todo: add SVRG
            # Compute gradient penalty
            alpha = torch.rand(real_images.size(0), 1, 1, 1).cuda().expand_as(real_images)
            interpolated = Variable(alpha * real_images.data + (1 - alpha) * fake_images.data, requires_grad=True)
            out = self.D(interpolated)

            grad = torch.autograd.grad(outputs=out,
                                       inputs=interpolated,
                                       grad_outputs=torch.ones(out.size()).cuda(),
                                       retain_graph=True,
                                       create_graph=True,
                                       only_inputs=True)[0]

            grad = grad.view(grad.size(0), -1)
            grad_l2norm = torch.sqrt(torch.sum(grad ** 2, dim=1))
            d_loss_gp = torch.mean((grad_l2norm - 1) ** 2)

            # Backward + Optimize
            d_loss += self.lambda_gp * d_loss_gp

        return d_loss

    def _gen_loss(self, g_out_fake):
        if self.adv_loss == 'wgan-gp' or self.adv_loss == 'hinge':
            g_loss = - g_out_fake.mean()
        else:
            raise NotImplementedError

        return g_loss

    def _update_pair(self, step):
        _lr_scheduler = self.lr_scheduler > 0 and step > 0 and step % len(self.data_loader) == 0
        self.D.train()
        self.G.train()

        real_images = tensor2var(next(self.data_gen))
        z = tensor2var(torch.randn(real_images.size(0), self.z_dim))
        fake_images = self.G(z)
        d_out_real = self.D(real_images)
        d_out_fake = self.D(fake_images.detach())

        if not self.alternating:
            if self.resample:
                z = tensor2var(torch.randn(real_images.size(0), self.z_dim))
                fake_images = self.G(z)
            g_out_fake = self.D(fake_images)
            g_loss = self._gen_loss(g_out_fake)
            self.g_optimizer.zero_grad()
            g_loss.backward()

        d_loss = self._disc_loss(real_images, fake_images, d_out_real, d_out_fake)
        self.d_optimizer.zero_grad()
        d_loss.backward()

        self.d_optimizer.step()
        if _lr_scheduler:
            self.scheduler_d.step()
  
        if self.alternating:
            if self.resample:
                z = tensor2var(torch.randn(real_images.size(0), self.z_dim))
                fake_images = self.G(z)
            g_out_fake = self.D(fake_images)
            g_loss = self._gen_loss(g_out_fake)
            self.g_optimizer.zero_grad()
            g_loss.backward()
        
        self.g_optimizer.step()
        if _lr_scheduler:
            self.scheduler_g.step()

        # === Moving avg Generator-nets ===
        self._update_ema_gen()

    def build_model(self):
        # Models                    ###################################################################
        if self.arch == 'resnet':
            from models import resnet_models
            self.G = resnet_models.Generator(self.z_dim).cuda()
            self.D = resnet_models.Discriminator().cuda()
        elif self.arch == 'dcgan':
            from models import dcgan
            self.G = dcgan.Generator(self.z_dim).cuda()
            self.D = dcgan.Discriminator(self.z_dim).cuda()
        else:
            raise NotImplementedError

        if self.parallel:
            self.G = nn.DataParallel(self.G)
            self.D = nn.DataParallel(self.D)

        self.G_ema = copy.deepcopy(self.G)
        self._requires_grad(self.G_ema, False)

        if self.optim == 'sgd':
            self.g_optimizer = torch.optim.SGD(filter(lambda p: p.requires_grad, self.G.parameters()),
                                               self.g_lr, momentum=self.momentum)
            self.d_optimizer = torch.optim.SGD(filter(lambda p: p.requires_grad, self.D.parameters()),
                                               self.d_lr, momentum=self.momentum)

        elif self.optim == 'adam':
            self.g_optimizer = torch.optim.Adam(filter(lambda p: p.requires_grad, self.G.parameters()),
                                                self.g_lr, [self.g_beta1, self.beta2])
            self.d_optimizer = torch.optim.Adam(filter(lambda p: p.requires_grad, self.D.parameters()),
                                                self.d_lr, [self.d_beta1, self.beta2])

        elif self.optim == 'amsgrad':
            self.g_optimizer = torch.optim.Adam(filter(lambda p: p.requires_grad, self.G.parameters()),
                                                self.g_lr, [self.g_beta1, self.beta2], amsgrad=True)
            self.d_optimizer = torch.optim.Adam(filter(lambda p: p.requires_grad, self.D.parameters()),
                                                self.d_lr, [self.d_beta1, self.beta2], amsgrad=True)

        elif self.optim == 'extra-sgd':
            import optimizers as optims
            self.g_optimizer = optims.SGD(filter(lambda p: p.requires_grad, self.G.parameters()),
                                           self.g_lr, momentum=self.momentum, optimistic=True)
            self.d_optimizer = optims.SGD(filter(lambda p: p.requires_grad, self.D.parameters()),
                                           self.d_lr, momentum=self.momentum, optimistic=True)

        elif self.optim == 'extra-amsgrad':
            import optimizers as optims
            self.g_optimizer = optims.Adam(filter(lambda p: p.requires_grad, self.G.parameters()),
                                           self.g_lr, [self.g_beta1, self.beta2], amsgrad=True, optimistic=True)
            self.d_optimizer = optims.Adam(filter(lambda p: p.requires_grad, self.D.parameters()),
                                           self.d_lr, [self.d_beta1, self.beta2], amsgrad=True, optimistic=True)

    def build_tensorboard(self):
        from tensorboardX import SummaryWriter
        self.writter = SummaryWriter(self.log_path)

    def load_pretrained_model(self):
        self.G.load_state_dict(torch.load(os.path.join(
            self.model_save_path, '{}_G.pth'.format(self.pretrained_model))))
        self.D.load_state_dict(torch.load(os.path.join(
            self.model_save_path, '{}_D.pth'.format(self.pretrained_model))))
        print('loaded trained models (step: {})..!'.format(self.pretrained_model))

    @staticmethod
    def _requires_grad(_net, _bool=True):
        """Helper function which sets the requires_grad of _net to _bool.

        Raises:
            TypeError: _net is given but is not derived from nn.Module, or
                       _bool is not boolean

        :param _net: [nn.Module]
        :param _bool: [bool, optional] Default: True
        :return: [None]
        """
        if _net and not isinstance(_net, torch.nn.Module):
            raise TypeError("Expected torch.nn.Module. Got: {}".format(type(_net)))
        if not isinstance(_bool, bool):
            raise TypeError("Expected bool. Got: {}".format(type(_bool)))

        if _net is not None:
            for _w in _net.parameters():
                _w.requires_grad = _bool

    def save_sample(self, data_iter):
        real_images, _ = next(data_iter)
        save_image(denorm(real_images), os.path.join(self.sample_path, 'real.png'))

    def backup(self, iteration):
        """Back-ups the networks & optimizers' states.

        Note: self.g_extra & self.d_extra are not stored, as these are copied from
        self.G & self.D at the beginning of each iteration. However, the optimizers
        are backed up.

        :param iteration: [int]
        :return: [None]
        """
        print("Save models to %s, at timestamp %d." % (self.bup_path, iteration))
        checkpoint_name = checkpoint_save({'G_state_dict': self.G.state_dict(),
                                           'G_ema_state_dict': self.G_ema.state_dict(),
                                           'D_state_dict': self.D.state_dict(),
                                           'g_optimizer': self.g_optimizer.state_dict(),
                                           'd_optimizer': self.d_optimizer.state_dict(),
                                           'step': iteration}, self.bup_path)


    def load_backup(self):
        """Loads the Backed-up networks & optimizers' states.

        Note: self.g_extra & self.d_extra are not stored, as these are copied from
        self.G & self.D at the beginning of each iteration. However, the optimizers
        are backed up.

        :return: [int] timestamp to continue from
        """
        if not os.path.exists(self.bup_path):
            raise ValueError('Cannot load back-up. Directory {} '
                             'does not exist.'.format(self.bup_path))

        checkpoint = latest_checkpoint_load(self.bup_path)
        if checkpoint != None:
            self.G.load_state_dict(checkpoint[0]['G_state_dict'])
            self.G_ema.load_state_dict(checkpoint[0]['G_ema_state_dict'])
            self.D.load_state_dict(checkpoint[0]['D_state_dict'])
            self.g_optimizer.load_state_dict(checkpoint[0]['g_optimizer'])
            self.d_optimizer.load_state_dict(checkpoint[0]['d_optimizer'])
            timestamp = checkpoint[0]['step']
            self.info_logger.info("Loaded models from %s, at timestamp %d." %
                (self.bup_path, timestamp))
        else:
            timestamp = 0

        return timestamp

    def _update_ema_gen(self, beta_ema=0.999, net=None):
        """ Updates the exponential moving average generator. """
        net = net or self.G_ema  # can also be called with net=self.G_ema_slow
        gen_dict = self.G.state_dict()
        gen_ema_dict = net.state_dict()
        if len(gen_dict) != len(gen_ema_dict):
            raise ValueError("Got different lengths: {}, {}".format(len(gen_dict), len(gen_ema_dict)))

        for key in gen_dict:
            with torch.no_grad():
                gen_ema_dict[key].data.copy_(gen_ema_dict[key].data.mul(beta_ema).add(
                    gen_dict[key].data.mul(1-beta_ema)))

    def compute_fid_score(self, generator, generator_ema, timestamp):
        """
        Computes FID of generator using fixed noise dataset;
        appends the current score to the list of computed scores;
        and overwrites the json file that logs the fid scores.

        :param generator: [nn.Module]
        :param timestamp: [int]
        :return: none
        """
        generator.eval()
        fake_samples = np.empty((self.sample_size_fid, self.imsize, self.imsize, 3))
        for j, noise in enumerate(self.fid_noise_loader):
            noise = noise.cuda()
            i1 = j * 200  # batch_size = 200
            i2 = i1 + noise.size(0)
            samples = generator(noise).cpu().data.add(1).mul(255 / 2.0)
            fake_samples[i1:i2] = samples.permute(0, 2, 3, 1).numpy()
        generator.train()
        mu_g, sigma_g = fid.calculate_activation_statistics(fake_samples, self.fid_session, batch_size=100)
        fid_score = fid.calculate_frechet_distance(mu_g, sigma_g, self.mu_real, self.sigma_real)

        generator_ema.eval()
        fake_samples = np.empty((self.sample_size_fid, self.imsize, self.imsize, 3))
        for j, noise in enumerate(self.fid_noise_loader):
            noise = noise.cuda()
            i1 = j * 200  # batch_size = 200
            i2 = i1 + noise.size(0)
            samples = generator_ema(noise).cpu().data.add(1).mul(255 / 2.0)
            fake_samples[i1:i2] = samples.permute(0, 2, 3, 1).numpy()
        generator_ema.train()
        mu_g, sigma_g = fid.calculate_activation_statistics(fake_samples, self.fid_session, batch_size=100)
        fid_score_ema = fid.calculate_frechet_distance(mu_g, sigma_g, self.mu_real, self.sigma_real)


        result = {'entry': len(self.fid_scores),
                  'iter': timestamp,
                  'fid': fid_score,
                  'fid_ema': fid_score_ema}

        self.fid_scores.append(result)
        with open(self.fid_json_file, 'w') as _f_fid:
            json.dump(self.fid_scores, _f_fid, sort_keys=True, indent=4, separators=(',', ': '))

