

import sys
sys.path.append("..")

import numpy as np
import cvxpy as cp
import sys
import itertools

import multiprocessing as mp

from environment.LinBandit_env import LinBandit_env


class XY_Static_Sampling(object):
    
    
    
    
    def __init__(self, env):
        '''
        Constructor
        '''
        self.T = env.T
        self.num_trials = env.num_trials
        self.num_dims = env.num_dims
        self.num_arms = env.num_arms
        self.rec = 10 # record err every rec samples
        #self.unif_sample_complexity = []
        self.sigma = env.sigma
        self.theta_star = env.theta_star
        self.best_arm = env.best_arm
        self.X = env.X
        self.delta = env.delta
        
        self.alpha = 0.1
        
        self.env = env
        
        
    def init_XY_Static_Sampling(self, env):
        
        self.theta_star = env.theta_star
        self.best_arm = env.best_arm
        self.X = env.X
        


    #Add observation
    def add_observe(self, A , b, x, theta, sigma):
        A += np.expand_dims(x,-1).dot(np.expand_dims(x,axis=0))
        r_t = self.observe(x, theta, sigma)
        b += r_t*x
        return A, b, r_t
    
    def observe(self, x, theta, sigma):
        return x.dot(theta) + np.random.randn()*sigma




    def search_next_arm(self, A, X, b, Y, n, final_score, verbose=False):
        
        
        score = []
        for x in X:
            #print(x)
            A_tmp = A + np.expand_dims(x, -1).dot(np.expand_dims(x, axis=0))
            A_inv_tmp = np.linalg.inv(A_tmp)
            err = np.max([y.T.dot(A_inv_tmp.dot(y)) for y in Y])
            score.append(err)
        
    
        score = np.array(score)
        idx = np.random.choice(np.arange(len(X))[score == np.min(score)])
        return idx, score

    # calculate confidence bound
    
    def confidence_bound(self, y, n, A_inv, K, sigma, delta):
        tmp = y.T.dot(A_inv.dot(y))
        if(tmp <= 0):
            sys.exit(1)
        return 2 * np.sqrt(2) * sigma * np.sqrt(tmp) * (np.sqrt(np.log(6 / np.pi / np.pi * n * n * K * K / delta)))


    def check_stop_condition(self, X, n, A, b, sigma, delta, error_XY_static, verbose=False):
        theta_hat = np.linalg.solve(A, b)
        A_inv = np.linalg.inv(A)
        est_reward = X.dot(theta_hat)
        best_arm = np.argmax(est_reward)
        
        if best_arm not in self.env.best_arm_set:
            if n < self.T:
                error_XY_static[n] = 1
    
        for i in range(len(X)):
            if(i == best_arm):
                continue
            #print(i)
            est_dif = est_reward[best_arm] - est_reward[i]
            arm_dif = X[best_arm] - X[i]
            conf_bound = self.confidence_bound(arm_dif, n, A_inv, len(X), sigma, delta)
            #print(est_dif,arm_dif,conf_bound)
            if(est_dif < conf_bound) :
            #if(est_dif < conf_bound) and (conf_bound > 0.0015) :
                
                if(verbose):
                    print("--------at %d step-------" % n)
                    print("arm %d violates stop condition" % i)
                    print("best estimated arm: %d" % best_arm)
                    print("best estimated reward: %f" % est_reward[best_arm])
                    print("estimated rewards difference:%f" % est_dif)
                    print("confidence bound:%f" % conf_bound)
                return -1
            
        return best_arm

    # constrct Y which contations all directions to be distinguished


    def const_Y(self, X, candidate):
        Y = []
        for x0, x1 in itertools.combinations(X[candidate], 2):
            Y.append(x0 - x1)
        return np.array(Y)

    # do one simulation
    def simulation(self, X, theta, d, sigma, delta, arm_selections, error_XY_static, error_est_XY_static, verbose=True):
        # initilization
        A = np.eye(d) * 0.01
        b = np.zeros(d)
        n = 0
        K = len(X)
    
        
        #arm_count = np.zeros(K, dtype=int)
        Y = self.const_Y(X, range(K))
    
      
        # select arms one times for each
        for i, x in enumerate(X):
            self.add_observe(A, b, x, theta, sigma)
    
            #calculate best arm for error
            if n%20 == 0:
                theta_hat = np.linalg.solve(A, b)
            #A_inv = np.linalg.inv(A)
            est_reward = X.dot(theta_hat)
            best_arm = np.argmax(est_reward)
    
            
            if best_arm not in self.env.best_arm_set:
                if n < self.T:
                    error_XY_static[n] = 1
                    error_est_XY_static[n] = np.linalg.norm(theta_hat - self.theta_star, ord=1)
            
            n += 1
            
    
        # select arm in a greedy manner until stop condition is satisified
    
        final_score = []
        while(self.check_stop_condition(X, n, A, b, sigma, delta, error_XY_static) < 0):
            '''
            if n > 40 and n%40 == 0:
              if (check_stop_condition(X, n, A, b, sigma, delta, error_XY_static) < 0):
                break
            '''
    
            if (verbose):
                if (n % 100 == 0):
                    ch = self.check_stop_condition(X, n, A, b, sigma, delta, error_XY_static)
                    #print(ch)
            arm, final_score = self.search_next_arm(A,X,b,Y,n,final_score,verbose)
            A, b, r_t = self.add_observe(A, b, X[arm], theta, sigma)
            n += 1
            
            if n%1000 == 0:
                print(n, best_arm, self.check_stop_condition(X, n, A, b, sigma, delta, error_XY_static))
            
            arm_selections[arm] += 1
            if n >= self.T-1:
                break
        best_arm = self.check_stop_condition(X, n, A, b, sigma, delta, error_XY_static)
        error_XY_static[0] = 1
        return error_XY_static, arm_selections, error_est_XY_static

    
    
    def run_XY_Static_Sampling(self):
        
        self.total_error_XY_Static = []
        self.total_arm_selection = []
        self.total_error_est_XY_Static = []
    
        
        #res_list = []
        trial_rec = self.num_trials//self.rec
        #print(trial_rec)
        
        tr = 0
        for j in range(0,self.rec):
        
            pool = mp.Pool(trial_rec)
            res_list = pool.starmap(self.simulation, [(self.X, self.theta_star, self.num_dims, self.sigma, self.delta, np.zeros(self.num_arms),np.zeros(self.T), np.zeros(self.T), True) for i in range(trial_rec)])
            #res_list.append(res_list1)
            
            for tr in range(0,trial_rec):
                trial_error = res_list[tr][0]
                arm_selection_trial = res_list[tr][1]
                est_trial = res_list[tr][2]
                
                self.total_error_XY_Static.append(trial_error)
                self.total_arm_selection.append(arm_selection_trial)
                self.total_error_est_XY_Static.append(est_trial)
            
                print(' XYS:'+ str(tr), end=', ')
                if tr % 25 == 0:
                    print()
            
            pool.terminate()
            
        
        '''
        for tr in range(self.num_trials):
            
            trial_error = res_list[tr][0]
            arm_selection_trial = res_list[tr][1]
            est_trial = res_list[tr][2]
            
            self.total_error_XY_Static.append(trial_error)
            self.total_arm_selection.append(arm_selection_trial)
            self.total_error_est_XY_Static.append(est_trial)
        '''   
        '''
        for tr in range(self.num_trials):
            np.random.seed(tr)
            arm_selections = np.zeros(self.num_arms)
            error_XY_static = np.zeros(self.T)
            error_est_XY_static = np.zeros(self.T)
            
            
            trial_error, arm_selection_trial, est_trial = self.simulation(self.X, self.theta_star, self.num_dims, self.sigma, self.delta, arm_selections, error_XY_static, error_est_XY_static, True)
            
            self.total_error_XY_Static.append(trial_error)
            self.total_arm_selection.append(arm_selection_trial)
            self.total_error_est_XY_Static.append(est_trial)
            
            
            print(tr, end=', ')
            if tr % 25 == 0:
                print()
        '''        
        
        #return error_XY_static, arm_selections, error_est_XY_static 
        
if __name__ == "__main__":
    
    #trials = 4
    env = LinBandit_env()
    env.LinBandit_env1(55,2,12)
    
    obj = XY_Static_Sampling(env)
    obj.run_XY_Static_Sampling()
    
    print(obj.total_arm_selection)
    print(len(obj.total_arm_selection))
    
    
    
    
    