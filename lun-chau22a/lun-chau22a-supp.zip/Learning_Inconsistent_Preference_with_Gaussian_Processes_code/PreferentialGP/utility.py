import torch
import numpy as np
import pandas as pd
import itertools

from sklearn.metrics import accuracy_score

from numpy.random import rand, randn, randint
from numpy import sign, sqrt, count_nonzero, cos, sin, pi, ones, zeros, mean, shape, reshape, exp, sort, diag, eye, \
    around, \
    linspace, dot, sqrt, argsort, allclose, bool, fill_diagonal, concatenate, empty, arange
from numpy.linalg import svd, solve, inv, eig, eigh, cholesky, norm



def split_C(C, z):
    """
    Args:
        C: Comparison matrix
        z: the cluster label

    Returns:
        C_i for i in number of len(z.unique)
    """
    l = np.max(z) + 1 # Number of clusters
    num_per_clus = [(z==i).sum() for i in range(l)]

    C_pd = pd.DataFrame(C)
    C_clus_ls = []
    for i in range(l):
        C_clus_ls.append(np.array(C_pd.iloc[z==i, z==i]))

    return C_clus_ls


def cluster_evaluation_for_ranking(C_test, r, z):
    C_predr = r @ np.ones_like(r).T - np.ones_like(r) @ r.T
    C_predr = np.sign(C_predr)

    C_clus_ls_test = split_C(C_test, z)
    C_clus_ls_pred = split_C(C_predr, z)

    accuracy_ls = []
    for ind in range(len(C_clus_ls_test)):
        mat_prod = C_clus_ls_test[ind]*C_clus_ls_pred[ind]
        num_compare = (mat_prod != 0).sum()
        correct_compare = (mat_prod == 1).sum()

        accuracy_ls.append(correct_compare/num_compare)

    return accuracy_ls


def cluster_evaluation(choix_test, ypred, z):
    """

    Args:
        choix_test: testing choix ls
        ypred: prediction to the list
        z: cluster assignment

    Returns: cluster accuracy

    """
    num_items = len(z)
    num_clus = np.max(z) + 1
    C_test = choix_to_mat(choix_test, num_items)
    C_clus_ls = split_C(C_test, z)

    # make a C_pred
    C_pred = np.zeros((num_items, num_items))
    for ind in range(len(choix_test)):
        i,j = choix_test[ind]
        C_pred[i, j] = ypred[ind]
        C_pred[j, i] = -ypred[ind]

    C_pred_ls = split_C(C_pred, z)

    accuracy_ls = []
    for clus_ind in range(len(C_clus_ls)):
        mat_prod = (C_pred_ls[clus_ind] * C_clus_ls[clus_ind])
        num_comparisons = (mat_prod!=0).sum()
        num_correct = (mat_prod == 1).sum()
        accuracy_ls.append(num_correct/num_comparisons)

    return accuracy_ls

def sqrtm_psd(A, check_finite=True):
    """
    Returns the matrix square root of a positive semidefinite matrix,
    truncating negative eigenvalues.
    """
    s, V = eigh(A)
    s[s <= 0] = 0
    s = sqrt(s)
    A_sqrt = (V * s).dot(V.conj().T)
    return A_sqrt


def invsqrtm_psd(A, check_finite=True):
    """
    Returns the inverse matrix square root of a positive semidefinite matrix,
    truncating negative eigenvalues.
    """
    s, V = eigh(A)
    s[s <= 1e-16] = 0
    s[s > 0] = 1 / sqrt(s[s > 0])
    A_invsqrt = (V * s).dot(V.conj().T)
    return A_invsqrt


def centering_matrix(n):
    # centering matrix, projection to the subspace orthogonal
    # to all-ones vector
    return eye(n) - ones((n, n)) / n


def rank_items(array):
    temp = array.argsort()
    ranks = empty(len(array), int)
    ranks[temp] = arange(len(array))
    return ranks + 1


def get_the_subspace_basis(n, verbose=True):
    # returns the orthonormal basis of the subspace orthogonal
    # to all-ones vector
    H = centering_matrix(n)
    s, Zp = eigh(H)
    ind = argsort(-s)  # order eigenvalues descending
    s = s[ind]
    Zp = Zp[:, ind]  # second axis !!
    if (verbose):
        print("...forming the Z-basis")
        print("check eigenvalues: ", allclose(
            s, concatenate((ones(n - 1), [0]), 0)))

    Z = Zp[:, :(n - 1)]
    if (verbose):
        print("check ZZ'=H: ", allclose(dot(Z, Z.T), H))
        print("check Z'Z=I: ", allclose(dot(Z.T, Z), eye(n - 1)))
    return Z


def compute_upsets(r, C, verbose=True, which_method=""):
    n = shape(r)[0]
    totmatches = count_nonzero(C) / 2
    if (len(shape(r)) == 1):
        r = reshape(r, (n, 1))
    e = ones((n, 1))
    Chat = r.dot(e.T) - e.dot(r.T)
    upsetsplus = count_nonzero(sign(Chat[C != 0]) != sign(C[C != 0]))
    upsetsminus = count_nonzero(sign(-Chat[C != 0]) != sign(C[C != 0]))
    winsign = 2 * (upsetsplus < upsetsminus) - 1
    if (verbose):
        print(which_method + " upsets(+): %.4f" %
              (upsetsplus / float(2 * totmatches)))
        print(which_method + " upsets(-): %.4f" %
              (upsetsminus / float(2 * totmatches)))
    return upsetsplus / float(2 * totmatches), upsetsminus / float(2 * totmatches), winsign




def offdiagonal(G):
    ls = []
    n = G.shape[0]
    for i in range(n):
        for j in range(i + 1, n):
            ls.append(G[i, j])

    return np.array(ls)


def RankabilityTest(G, r_ls):
    """

    Args:
        G: Preference Matrix
        r_ls: A list of possible rank to test for

    Returns:
        p-value_ls
    """




def Conjugate_GD(K, f, num_rounds=20, cuda=False):
    """
    Implement the Conjugate Gradient Method on tensors

    return x ~= K^-1 f
    """
    p = []
    r = []
    alpha = []
    beta = []
    if cuda:
        x = [torch.zeros_like(f).cuda()]
    else:
        x = [torch.zeros_like(f)]

    # Algorithm
    count = 0
    r.append(f)
    p.append(r[count])

    while count < num_rounds:
        alpha.append(((r[count].T @ r[count]) / (p[count].T @ K @ p[count]))[0][0])
        x.append(x[count] + alpha[count] * p[count])
        r.append(r[count] - alpha[count] * K @ p[count])
        beta.append((r[count + 1].T @ r[count + 1]) / (r[count].T @ r[count]))
        p.append(r[count + 1] + beta[count] * p[count])
        count += 1

    return x[count]



def include_sparsity(C, sparsity=0.7):
    n, p = C.shape
    zero_ls = np.random.choice([0, 1], n*p, p=(sparsity, 1-sparsity))
    zero_ls = zero_ls.reshape(n, p)

    flip_mat = np.triu(zero_ls) + np.triu(zero_ls).T - \
        np.diag(np.diag(zero_ls))

    return C*flip_mat


def choix_to_mat(choix_ls, num_items):
    """
    there are situation that choix_ls alone does not generate a connected graph.
    """

    C = np.zeros((num_items, num_items))
    for pairs in choix_ls:
        i, j = pairs
        C[i, j] = 1
        C[j, i] = -1

    return C


def train_test_split(choix_ls, split=0.7):
    """
    Given choix_ls, return C_train, C_test, choix_train, choix_test, y_train, y_test

    """

    num_items = np.max(np.matrix(choix_ls).reshape(1, -1)) + 1
    n = int(len(choix_ls))
    split = int(n * split)
    shuffled_index = np.random.choice(n, n, replace=False)
    shuffled_ls = [choix_ls[i] for i in shuffled_index]
    choix_train, choix_test = shuffled_ls[:split], shuffled_ls[split:]
    C_train, C_test = choix_to_mat(choix_train, num_items), choix_to_mat(choix_test, num_items)
    y_train = [1 for i in range(len(choix_train))]
    y_test = [1 for i in range(len(choix_test))]

    return C_train, C_test, choix_train, choix_test, y_train, y_test


def experiment0(n, p, n_states, shift=1):
    """
    Args:
        n: number of items to be compared
        p: number of features for each item
        n_states: number of latent states determining the "type"

    Returns:
    """
    # Generate features
    mean_vec = np.zeros(p)
    # Generate states
    latent_states = np.random.choice(n_states, n)

    num_per_clus = [(latent_states==i).sum() for i in range(n_states)]
    X_per_c = [np.random.multivariate_normal(mean_vec + i*shift, np.eye(p), num_per_clus[i]) for i in range(n_states)]

    X = pd.DataFrame(np.zeros((n, p)))
    for i in range(n_states):
        X.iloc[latent_states==i, :] = X_per_c[i]
    X = np.array(X)

    # Generate different consideration factors
    beta_dict = dict()
    for i in range(n_states):
        for j in range(i, n_states):
            beta = np.random.normal(size=p)
            beta_dict[(i, j)] = beta
            beta_dict[(j, i)] = beta

    return X, beta_dict, latent_states


def preprocessingC(C):
    """

    Args:
        C: The skew Symmetric Comparison Matrix

    Returns:
        train_choix_ls
        train_y_ls

    """
    n = C.shape[0]
    choix_ls = []
    for i in range(n):
        for j in range(i + 1, n):
            if C[i, j] == 1:
                choix_ls.append((i, j))
            elif C[i, j] == -1:
                choix_ls.append((j, i))

    y_ls = [1] * len(choix_ls)

    # train_choix_ls = choix_ls + [(i[1], i[0]) for i in choix_ls]
    # train_y_ls = y_ls + [-1] * len(choix_ls)

    return choix_ls, y_ls


def generate_match(x, beta_dict, z):
    """

    Args:
        x: features of size n x p
        beta_dict: dictionary of "size" zC2, all possible latent states combination
        z: latent states vector

    Returns:

    """
    n = x.shape[0]
    C = np.zeros((n, n))
    for i in range(n):
        for j in range(i + 1, n):
            skill_i, skill_j = x[[i, j], :] @ beta_dict[(z[i], z[j])]
            if skill_i >= skill_j:
                C[i, j] = 1
                C[j, i] = -1
            else:
                C[i, j] = -1
                C[j, i] = 1

    return C


def include_sparsity(C, sparsity=0.7):
    n, p = C.shape
    zero_ls = np.random.choice([0, 1], n*p, p=(sparsity, 1-sparsity))
    zero_ls = zero_ls.reshape(n, p)

    flip_mat = np.triu(zero_ls) + np.triu(zero_ls).T - \
        np.diag(np.diag(zero_ls))

    return C*flip_mat


def FLIP(C, η=0.1):
    """
    Given a C matrix, randomly create noise to the problem.

    """
    n, p = C.shape
    flip_ls = np.random.choice([1, -1], n*p, p=(1-η, η))
    flip_ls = flip_ls.reshape(n, p)

    flip_mat = np.triu(flip_ls) + np.triu(flip_ls).T - \
        np.diag(np.diag(flip_ls))

    return C*flip_mat

def Compute_Sim(C):
    """
    Compute the Similarity matrix
    """
    n = C.shape[0]
    ones_mat = n * np.dot(np.ones(n).reshape(-1, 1), np.ones(n).reshape(1, -1))
    S = 0.5 * (ones_mat + np.dot(C, C.T))
    return S


def multicluster_evaluation(pred_label, label):
    result = []
    num_clus = len(set(pred_label))
    all_labelling = list(itertools.permutations([i for i in range(num_clus)]))

    for ls in all_labelling:
        new_labels = [ls[i] for i in pred_label]
        result.append(accuracy_score(new_labels, label))

    return np.max(result)


def SBM_include_sparsity(C, p, r, z):
    """

    Args:
        C: Comparison matrix
        p: Probability of an edge missing within cluster
        r: Probablity of an edge missing across clsuter
        z: latent cluster membership

    Returns:
        C matrix with SBM structure
    """
    n = C.shape[0]

    for i in range(n):
        for j in range(i, n):
            if z[i] == z[j]:
                C[i, j] = C[i, j] * np.random.choice([0, 1], p=[p, 1 - p])
            elif z[i] != z[j]:
                C[i, j] = C[i, j] * np.random.choice([0, 1], p=[r, 1 - r])

    return C

