"""
Algorithm implementations. GP-UCB is implemented as Hierarchical GP-UCB with
a single cover element.
"""

import numpy as np
import gp_regression
import Partitioned_GP_UCB
import Partitioned_GP_EI


class BanditAlg:
    """Interface for bandit algorithm."""
    def __init__(self, horizon: int, grid: np.array):
        self._horizon = horizon
        self._grid = grid

    def select_arm(self):
        raise NotImplementedError

    def update(self, arm, value):
        raise NotImplementedError


class UniformAlg(BanditAlg):
    """Samples arms uniformly."""
    def select_arm(self):
        index = np.random.randint(len(self._grid))
        return self._grid[index]

    def update(self, arm, value):
        pass


class UCB(BanditAlg):
    """Improved GP-UCB algorithm."""
    def __init__(self, horizon: int, grid: np.array,
                 kernel: gp_regression.MaternKernel,
                 index_fn: gp_regression.UCBIndex):
        super().__init__(horizon, grid)

        self._index_fn = index_fn
        self._kernel = kernel

        _, ndim = grid.shape
        self._intervals = [Partitioned_GP_UCB.Interval(Partitioned_GP_UCB.Bound([[0, 1]] * ndim),
                                            kernel, index_fn, grid)]

    def select_arm(self):
        _, argmax = self._intervals[0].get_ucb()
        return argmax

    def update(self, arm, value):
        self._intervals[0].update(arm, value)


class EI(BanditAlg):
    def __init__(self, horizon: int, grid: np.array,
                 kernel: gp_regression.MaternKernel,
                 index_fn: gp_regression.EIIndex_new):
        super().__init__(horizon, grid)

        self._index_fn = index_fn
        self._kernel = kernel

        _, ndim = grid.shape
        self._intervals = [Partitioned_GP_EI.Interval(Partitioned_GP_EI.Bound([[0, 1]] * ndim),
                                            kernel, index_fn, grid)]

    def select_arm(self):
        _, argmax = self._intervals[0].get_ei()
        return argmax

    def update(self, arm, value):
        self._intervals[0].update(arm, value)


class PGPUCB(UCB):
    """Raw Partitioned GP-UCB algorithm."""
    def __init__(self, horizon: int, grid: np.array,
                 kernel: gp_regression.MaternKernel,
                 index_fn: gp_regression.UCBIndex):
        super().__init__(horizon, grid, kernel, index_fn)

        self._successive_tightening = False

    def update(self, arm, value):
        super().update(arm, value)

        if self._intervals[0].needs_split:
            interval = self._intervals.pop(0)
            self._intervals += interval.split(
                successive_tightening=self._successive_tightening)

        self._intervals.sort(key=lambda interval: interval.get_ucb()[0],
                             reverse=True)

class PGPEI(UCB):
    """Raw Partitioned GP-UCB algorithm."""
    def __init__(self, horizon: int, grid: np.array,
                 kernel: gp_regression.MaternKernel,
                 index_fn: gp_regression.EIIndex_new):
        super().__init__(horizon, grid, kernel, index_fn)

        self._successive_tightening = False

    def update(self, arm, value):
        super().update(arm, value)

        if self._intervals[0].needs_split:
            interval = self._intervals.pop(0)
            self._intervals += interval.split(
                successive_tightening=self._successive_tightening)

        self._intervals.sort(key=lambda interval: interval.get_ucb()[0],
                             reverse=True)


