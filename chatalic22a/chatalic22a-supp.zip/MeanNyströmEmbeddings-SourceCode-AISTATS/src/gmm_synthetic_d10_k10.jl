include("gmm_synthetic.jl")

main_gmm_synthetic(10, 10)
