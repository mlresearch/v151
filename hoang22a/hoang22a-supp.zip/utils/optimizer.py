from utils.enums import *

import tensorflow as tf
from tensorflow.keras.optimizers import Optimizer

class KerasOptimizerWrapper(object):  # thin wrapper for keras optimizer: enum -> corresponding loss implementation. Make it more convenient to configure the model
    def __init__(self, optimizer: Optimizers, learning_rate: float):
        if optimizer == Optimizers.adagrad:
            self.optimizer: Optimizer = tf.keras.optimizers.Adagrad(learning_rate)
        if optimizer == Optimizers.adam:
            self.optimizer: Optimizer = tf.keras.optimizers.Adam(learning_rate)
        else:
            raise ValueError('Optimizer not supported')