import math
import operator
import random

import matplotlib
import matplotlib.pyplot as plt
import numpy as np


###################################
######## FUNCTIONS ################
###################################


# Base Functions #
def base_convert(i, b):
    result = []
    while i > 0:
        result.insert(0, i % b)
        i = i // b
    return result

def base_invert(array,b):
    t = 0
    index = 0
    while len(array)>0:
        t = t + array.pop()*b**index
        index = index + 1
    return t


def optimalBase(T):
    def f(b):
        Lb = np.floor(math.log(T,b))+1
        return (b-1) * Lb* np.ceil(math.log(T,b))
    argmin = 2
    min = f(2)
    for b in range(3,100):
        if f(b) < min:
            argmin = b
            min = f(b)
    return argmin, min

# Compute standard deviation of noise for different bases
def baseSD(b,T):
    return np.sqrt((b-1) * (np.floor(np.log(T)/np.log(b))+1) * np.ceil(math.log(T,b)))

# Functions to generate samples in a stream from some Zipfian data distribution with some domain size #

def ZipfsLawDistribution(d):
    fDist = np.array([])
    for i in range(1,d+1):
        fDist = np.append(fDist,1.0/float(i))
    normalization = np.sum(fDist)
    fdistDistribution = [ (i, count/float(normalization)) for i,count in enumerate(fDist)]
    return fdistDistribution

def sampleDataDistribution(s, dist):
    itemsArray = [pair[0] for pair in dist]
    pArray = [pair[1] for pair in dist]
    sample = np.random.choice(
        itemsArray,
        s,
        p=pArray
    )
    return sample

# Restricted \ell_0-Sensitivity and Known Domain Algorithm #
def knownBase(t, hist, T, tau=1, rootSeed=0):
    base = optimalBase(T)[0]
    scaleNoise = tau * np.sqrt(np.floor(np.log(T)/np.log(base)) + 1)
    noisyHist = {}
    for u in hist:
        baseArray = base_convert(t, base) # [base^0, base^1, ..., ]
        sumNoise = 0
        tPrime = t
        for row, element in enumerate(reversed(baseArray)):
            if element > 0:
                for cell in range(element):
                    tupleSeed = (rootSeed, row, tPrime/base**row - element + cell, u)
                    random.seed(tupleSeed)
                    Z = random.normalvariate(0,1)
                    #print(tupleSeed,Z)
                    sumNoise = sumNoise + scaleNoise*Z
                tPrime = tPrime - element * base**row
        noisyHist[u] = hist[u] + sumNoise
    return noisyHist

# Same function as knownBase, but generates a stream of data from a distribution and returns the noisy max at each
# round #
def knownBaseMax(T,tau, dataDistribution, rootSeed=0):
    d = len(dataDistribution)
    scaleNoise = tau * np.sqrt(d)
    universe = {u[0] for u in dataDistribution}
    histogram = {u:0 for u in universe}
    errMax = []
    for t in range(1,T+1):
        itemArray = sampleDataDistribution(1,dataDistribution)
        for item in itemArray:
            histogram[item] = histogram[item] + 1
        noisyHistogram = knownBase(t,histogram, T, scaleNoise, rootSeed)
        # For Python3 use the following lines
        # noisyMax = max(noisyHistogram.items(), key=operator.itemgetter(1))[0]
        # currMax = max(histogram.items(), key=operator.itemgetter(1))[0]
        # For Python2 use the following lines
        noisyMax = max(noisyHistogram.iteritems(), key=operator.itemgetter(1))[0]
        currMax = max(histogram.iteritems(), key=operator.itemgetter(1))[0]
        diff = np.abs(noisyHistogram[noisyMax] - histogram[currMax])
        #print(diff)
        errMax.append(diff)
    return errMax

# Unrestricted \ell_0-Sensitivity and Known Domain Algorithm #
def sparseGumbMax(T, switches, eta, tau, dataDistribution, rootSeed = 0):
    scaleNoise = tau * np.sqrt(6)
    universe = {u[0] for u in dataDistribution}
    histogram = {u:0 for u in universe}
    itemArray = sampleDataDistribution(1,dataDistribution)
    for item in itemArray:
        histogram[item] = histogram[item] + 1
    histogramArray = [ (key, histogram[key]) for key in histogram]
    topElement = histogramArray[np.argmax([u[1] + np.random.gumbel(0,scaleNoise * np.sqrt(switches + 1) / 2.0) for u in histogramArray])][0]

    if switches != 0:
        thresholdNoise = np.random.laplace(0,2.0 * np.sqrt(switches) * scaleNoise)

    noisyHistogram = knownBase(1,{topElement: histogram[topElement]}, T, np.sqrt(switches+1)*scaleNoise )
    # For Python3 use the following lines
    # currMax = max(histogram.items(), key=operator.itemgetter(1))[0]
    # For Python2 use the following lines
    # currMax = max(histogram.iteritems(), key=operator.itemgetter(1))[0]
    errMax = [np.abs(noisyHistogram[topElement] - 1)]
    # Debug #
    #print(topElement, currMax)
    switchesCurr = switches
    tSwitches = []
    for t in range(2,T+1):
        itemArray = sampleDataDistribution(1,dataDistribution)
        for item in itemArray:
            histogram[item] = histogram[item] + 1
        currCount =  knownBase(t,{topElement: histogram[topElement]}, T, np.sqrt(switches+1)*scaleNoise, rootSeed)[topElement]
        if switchesCurr > 0:
            for u in universe:
                if u != topElement:
                    LHS = histogram[u] + np.random.laplace(0,4 * scaleNoise * np.sqrt(switches))
                    RHS = currCount + thresholdNoise + eta
                    if LHS > RHS:
                        #print(t, u, LHS, RHS)
                        histogramArray = [ (key, histogram[key]) for key in histogram if key != topElement]
                        topElement = histogramArray[np.argmax([u[1] + np.random.gumbel(0,scaleNoise * np.sqrt(switches + 1) / 2.0) for u in histogramArray])][0]
                        switchesCurr = switchesCurr-1
                        tSwitches.append(t)
                        thresholdNoise = np.random.laplace(0,2 * np.sqrt(switches) * scaleNoise)
                        break
        # For Python3 use the following lines
        # currMax = max(histogram.items(), key=operator.itemgetter(1))[0]
        # For Python2 use the following lines
        currMax = max(histogram.iteritems(), key=operator.itemgetter(1))[0]
        errMax.append(np.abs(currCount - histogram[currMax]))
        # Debug #
        #print(topElement, currMax)
    return errMax, tSwitches

# Functions for Meta Algorithm with unrestricted ell_0-sensitivity and known domain #

def getTopElement(histogram):
    positionOfTopElement = np.argmax([value for (_,value) in histogram ])
    # For Python3 use the following lines
    # topElement = list(histogram)[positionOfTopElement][0]
    # value = list(histogram)[positionOfTopElement][1]
    # For Python2 use the following lines
    topElement = histogram[positionOfTopElement][0]
    value = histogram[positionOfTopElement][1]
    return topElement, value

# h1, h2 are lists of tuples
def aggregateTwoHistograms(h1,h2):
    aggregate = dict(h1)
    for (k,v) in h2:
        if k in aggregate:
            aggregate[k] = aggregate[k] + v
        else:
            aggregate[k] = v
    return aggregate.items()

def aggregateListOfHistograms(listOfHistograms):
    cummulative = listOfHistograms[0]
    for i in range(1,len(listOfHistograms)):
        cummulative = aggregateTwoHistograms(cummulative,listOfHistograms[i])
    return cummulative

def generateDictOfPartialHistograms(T,base,stream): # stream = list of lists of tuples
    dictOfPartialHistograms = {}
    L_b = int(np.floor(np.log(T)/np.log(base)) + 1)
    for i in range(1,L_b+1):
        start = 1
        for j in range(1, int(np.floor(T/(np.power(base,i-1)))) + 1):
            end = start + np.power(base,i-1) - 1
            dictOfPartialHistograms[(i,j)] = aggregateListOfHistograms(stream[start-1:end])
            start = end + 1
    return dictOfPartialHistograms # a dictionary of lists row,column in 1,2,...

def findSmallestNonZeroIndex(nums):
    for i in range(len(nums)):
        if nums[i]!=0:
            return i

def getListOfTrueMax(stream):
    trueMax = [0] * len(stream)
    currentHist = stream[0]
    trueMax[0] = getTopElement(currentHist)[1]

    for i in range(1,len(stream)):
        currentHist = aggregateTwoHistograms(currentHist,stream[i])
        trueMax[i] = getTopElement(currentHist)[1]
    return trueMax

def padWithZeros(histogram,universe):
    dictHistogram = dict(histogram)
    for u in universe:
        if u not in dictHistogram:
            dictHistogram[u] = 0
    return dictHistogram.items()

# Meta Algorithm with unrestricted ell_0-sensitivity and known domain #
def knownMetaMax(T, tau, dataDistribution, rootSeed=0):
    base = optimalBase(T)[0]

    L_b = np.floor(np.log(T)/np.log(base)) + 1
    gumbelNoiseScale = np.sqrt(L_b) * tau / 2.0
    gaussianNoiseStd = np.sqrt(L_b) * tau

    random.seed(rootSeed)
    stream = [[(sampleDataDistribution(1,dataDistribution)[0],1)] for _ in range(1,int(T)+1) ]

    trueMax = getListOfTrueMax(stream)

    def getTopElementDP(histogram): #should this be a list, or a dictionary
        positionOfTopElement = np.argmax([value + np.random.gumbel(0,gumbelNoiseScale) for (_,value) in histogram ])
        # For Python3 use the following lines
        # topElement = list(histogram)[positionOfTopElement][0]
        # value = list(histogram)[positionOfTopElement][1]
        # For Python2 use the following lines
        topElement = histogram[positionOfTopElement][0]
        value = histogram[positionOfTopElement][1]
        return topElement, value + np.random.normal(0, gaussianNoiseStd)

    universe = {u[0] for u in dataDistribution}
    dictOfPartialNoisyHistograms = {}
    dictOfPartialHistograms = generateDictOfPartialHistograms(T,base,stream)

    errMax = []
    for t in range(1,T+1):
        tPrime = t

        listOfNoisyHistograms = []
        while tPrime > 0:
            baseArray = base_convert(tPrime, base)
            baseArray.reverse()
            i = findSmallestNonZeroIndex(baseArray)
            start = np.floor(tPrime/(np.power(base,i))) - baseArray[i] +1
            end = np.floor(tPrime/(np.power(base,i)))
            for l in range(int(start),int(end) + 1):
                if (i+1,l) in dictOfPartialNoisyHistograms:
                    noisyHistogram = dictOfPartialNoisyHistograms[(i+1,l)]
                else:
                    paddedHistogram = padWithZeros(dictOfPartialHistograms[(i+1,l)],universe)
                    noisyHistogram = [getTopElementDP(paddedHistogram)]
                    dictOfPartialNoisyHistograms[(i+1,l)] = noisyHistogram
                listOfNoisyHistograms.append(noisyHistogram)
            tPrime = int(tPrime - baseArray[i]*np.power(base,i))
        aggregatedDPhistograms = aggregateListOfHistograms(listOfNoisyHistograms) #histograms here already noisy
        dpAnswer = getTopElement(aggregatedDPhistograms)
        diff = np.abs(dpAnswer[1] - trueMax[t-1])
        errMax.append(diff)

    return errMax



#######################################################
######### PLOTS #######################################
#######################################################
matplotlib.rcParams['pdf.fonttype'] = 42

# Plot the standard deviation of noise for multiple bases in KnownBase #
Tarray= np.logspace(2, 10, 9, base = 10, endpoint=True)

yOptBaseSD = [np.sqrt(optimalBase(T)[1]) for T in Tarray]
binSD = [baseSD(2,T) for T in Tarray]
base3SD = [baseSD(3,T) for T in Tarray]
base4SD = [baseSD(4,T) for T in Tarray]
base5SD = [baseSD(5,T) for T in Tarray]
base6SD = [baseSD(6,T) for T in Tarray]
base7SD = [baseSD(7,T) for T in Tarray]
base20SD = [baseSD(20,T) for T in Tarray]

plt.plot(Tarray,binSD, label="Binary Mechanism")
plt.plot(Tarray,base3SD, label="Base Mechanism $r = 3$")
plt.plot(Tarray,base4SD, label="Base Mechanism $r = 4$")
plt.plot(Tarray,base5SD, label="Base Mechanism $r = 5$")
plt.plot(Tarray,base6SD, label="Base Mechanism $r = 6$")
plt.plot(Tarray,base7SD, label="Base Mechanism $r = 7$")
plt.plot(Tarray,base20SD, label="Base Mechanism $r = 20$")

plt.xscale("log")
plt.xlabel('$T$')
plt.ylabel('Standard Deviation of Noise')
plt.title('Comparing Noise Between Binary Mechanism and Base Mechanism')
plt.legend()
#plt.savefig('BaseMechanismNoise.pdf')
plt.show()

# Plot Data Distribution #
d = 100
dataDistribution = ZipfsLawDistribution(d)

plt.bar(*zip(*dataDistribution))
plt.xlabel('Element')
plt.ylabel('Frequency Distribution')
plt.title('Data Distribution')
#plt.savefig('dataDistribution.pdf')
plt.show()

# Plot error of selected max element and the count of the true max element for various DP algorithms #

d = 100
dataDistribution = ZipfsLawDistribution(d)

rootSeed = 2
T = 1000
switches0 = 10
switches1 = 1
switches2 = 5
switches3 = 2
eta0 = 180
eta1 = 50
eta2 = 100
eta3 = 75
tau = 0.5
trials = 1000
yErrorsSparse0 = np.array([0]*T)
yErrorsSparse1 = np.array([0]*T)
yErrorsSparse2 = np.array([0]*T)
yErrorsSparse3 = np.array([0]*T)
yErrorsBase = np.array([0]*T)
yErrorsMetaKnown = np.array([0]*T)

# For 1000 trials and d = 100, the following code takes about 2 hours.
for n in range(trials):
    print("Currently in trial: " + str(n))
    yErrorsSparse0 = yErrorsSparse0 + sparseGumbMax(T, switches0, eta0, tau, dataDistribution, n)[0]
    yErrorsSparse1 = yErrorsSparse1 + sparseGumbMax(T, switches1, eta1, tau, dataDistribution, n+trials)[0]
    yErrorsSparse2 = yErrorsSparse2 + sparseGumbMax(T, switches2, eta2, tau, dataDistribution, n+2*trials)[0]
    yErrorsSparse3 = yErrorsSparse3 + sparseGumbMax(T, switches3, eta3, tau, dataDistribution, n+3*trials)[0]
    yErrorsBase = yErrorsBase + knownBaseMax(T,tau, dataDistribution, n+4*trials)
    yErrorsMetaKnown = yErrorsMetaKnown + knownMetaMax(T, np.sqrt(2)*tau, dataDistribution, n+5*trials)


yErrorsSparse0 = [y/trials for y in yErrorsSparse0]
yErrorsSparse1 = [y/trials for y in yErrorsSparse1]
yErrorsSparse2 = [y/trials for y in yErrorsSparse2]
yErrorsSparse3 = [y/trials for y in yErrorsSparse3]
yErrorsBase = [y/trials for y in yErrorsBase]
yErrorsMetaKnown = [y/trials for y in yErrorsMetaKnown]

Tarray = range(1,T+1)

plt.plot(Tarray,yErrorsSparse0, label="sparseGumbel with $s$ = %i" %switches0 + ", $\eta$ = %i" %eta0)
plt.plot(Tarray,yErrorsSparse1, label="sparseGumbel with $s$ = %i" %switches1 + ", $\eta$ = %i" %eta1)
plt.plot(Tarray,yErrorsSparse2, label="sparseGumbel with $s$ = %i" %switches2 + ", $\eta$ = %i" %eta2)
plt.plot(Tarray,yErrorsSparse3, label="sparseGumbel with $s$ = %i" %switches3 + ", $\eta$ = %i" %eta3)
plt.plot(Tarray,yErrorsBase,'--', label="knownBase", linewidth=0.5)
plt.plot(Tarray,yErrorsMetaKnown,label="metaKnownGumbel")


plt.xlabel('Round $t$')
plt.ylabel('Error in Max Element and Selected Element')
plt.ylim(0,100)
plt.title('Comparing error in Max Element with $d$ = %i' %d + r', $\tau$ = %1.1f' %tau)
plt.legend()
#plt.savefig('sparseGumbelZipf1000.pdf')
plt.show()
