# Estimators of Entropy and Information via Inference in Probabilistic Models

This folder contains experiment code for

    Estimators of Entropy and Information via Inference in Probabilistic Models.
    F. A. Saad; M. Cusumano-Towner; V. K. Mansinghka.
    AISTATS 2022

## Getting started

1. Install julia v1.6.2 from

    https://github.com/JuliaLang/julia/releases/tag/v1.6.2

2. Set current directory to the Julia project using

    export JULIA_PROJECT=.

3. Instantiate the package dependencies using

    julia -e 'using Pkg; Pkg.instantiate()'

    The main dependency is the Gen.jl package,

## Running experiments

Please navigate to [./examples](./examples) and follow the README.
