import torch


def evaluate(model, test_dl, device=torch.device("cuda:0")):
    """Algorithm for evaluation."""
    model = model.to(device)
    model.eval()
    dataloader = test_dl

    input_sizes = 0
    running_corrects = 0

    for inputs, labels in dataloader:
        input_sizes += len(inputs)
        inputs = inputs.to(device, non_blocking=True)
        labels = labels.to(device, non_blocking=True)

        with torch.no_grad():
            outputs = model(inputs)[-1]
            _, preds = torch.max(outputs, 1)
        # statistics
        running_corrects += torch.sum(preds == labels.data)
    acc = (running_corrects.double() / input_sizes).item()
    return acc
