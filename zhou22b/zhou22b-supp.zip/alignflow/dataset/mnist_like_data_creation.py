from dataset.load_MNIST import load_MNIST
from dataset.create_MINIST_data import create_MINIST_dataset
from dataset.create_paired_dataset import create_paired_image
import argparse, os, sys

def preloadData(data_dir):
    print('Start loading the npy data...')
    load_MNIST(dir)
    print('Start creating the data...')
    src = ['0','1']
    phases = ['train', 'cnn', 'eval', 'demo']
    for phase in phases:
        create_MINIST_dataset(src, data_dir, 'phase')
        if phase == 'train':
            percent = 0.2
        else:
            percent = 1
        create_paired_image(data_dir, phase, percent)
    print('Finish loading the data!')

parser = argparse.ArgumentParser(description='data directory for the data')
my_parser.add_argument('data_dir',
                       type=str,
                       help='the path of your data')

# Execute the parse_args() method
args = my_parser.parse_args()

input_path = args.data_dir

if not os.path.isdir(input_path):
    print('The path specified does not exist')
    sys.exit()
else:
    preloadData(input_path)