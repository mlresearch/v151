import numpy as np
from .base_builder import BaseBuilder
from cbp.node import FactorNode
from .potential_utils import diagonal_potential, diagonal_potential_conv
# * This is used for barycenter


class StarBuilder(BaseBuilder):
    def __init__(self, num_node, d, policy, rand_seed):
        self.num_node = num_node
        super().__init__(d, policy, rand_seed)

    def add_branch(self, head_node=None, is_constrained=False,
                   prob=None, is_conv=False):
        if head_node is None:
            head_node = f"VarNode_{self.graph.cnt_varnode-1:03d}"
        if is_constrained:
            node = self.add_constrained_node(prob)
        else:
            node = self.add_trivial_node()

        name_list = [head_node, node.name]
        inv_eta = 2 * self.num_node * \
            np.log(self.node_dim) / self.graph.cfg.itsbp_outer_tolerance
        # inv_eta = 100
        self.graph.inv_eta = inv_eta
        self.add_factor(name_list, is_conv, inv_eta)
    # *  add inverse_eta and exp to potential

    def deterministic_cost(self, d_1: int, d_2: int) -> np.ndarray:
        # *promises the largest cost is 1
        array1 = np.repeat(np.linspace(0, 1, d_1).reshape(-1, 1), d_2, axis=1)
        array2 = np.linspace(0, 1, d_2)
        cost = (array1 - array2)**2
        return cost

    def add_factor(self, name_list, is_conv=False, inverse_eta=5000):
        # if is_conv:
        #     factor_potential = diagonal_potential_conv(
        #         self.node_dim, self.node_dim, self.rng)
        # else:
        #     factor_potential = diagonal_potential(
        #         self.node_dim, self.node_dim, self.rng)
        factor_potential = self.deterministic_cost(
            self.node_dim, self.node_dim)
        factornode = FactorNode(
            name_list, np.exp(-inverse_eta * factor_potential))
        self.graph.add_factornode(factornode)
        return factornode

    def init_graph(self):
        center_node = "VarNode_000"
        self.add_trivial_node()

        for _ in range(self.num_node - 1):
            self.add_branch(head_node=center_node, is_constrained=True)
