# Usage: python run_all_inception_scores.py NUM_JOBS_IN_PARALLEL
# Example: python run_all_inception_scores.py --num=4
import os
import ipdb
import argparse

parser = argparse.ArgumentParser(description='Command Script Generator & Runner for Inception Score Computation')
parser.add_argument('--num', type=int,
                    help='How many jobs to run in parallel (e.g., how many GPUs to use simultaneously)')
parser.add_argument('--overwrite', action='store_true', default=False,
                    help='Whether to overwrite Inception Score CSV files that already exist in the subfolders')
args = parser.parse_args()

def create_inception_score_commands():
    base_dir = 'samples_np'

    COMMAND_TEMPLATE = 'srun -p gpu --gres=gpu:1 -x guppy12,guppy13 --mem=16G python compute_is_from_samples.py --load={}'
    command_list = []

    exp_folders = os.listdir(base_dir)
    for exp_folder in exp_folders:
        exp_path = os.path.join(base_dir, exp_folder)
        if exp_path[-3:] == 'pkl' or exp_path[-3:] == 'png' or exp_path[-3:] == 'pdf':
            continue
        numbered_subfolders = os.listdir(exp_path)  # Gives us a list of numbered subfolders like [2000, 4000, 6000, ...]
        for subfolder in numbered_subfolders:
            #print(subfolder)
            if subfolder[-3:] == 'pkl' or subfolder[-3:] == 'png' or subfolder[-3:] == 'pdf':
                continue
            subfolder_path = os.path.join(base_dir, exp_folder, subfolder)
            
            if (not args.overwrite) and ('inception_score.csv' in os.listdir(subfolder_path)):
                continue
            else:
                command = COMMAND_TEMPLATE.format(os.path.join(subfolder_path, 'samples.npz'))
                command_list.append(command)

    command_script_dir = 'is_commands'

    # Save the commands to a file
    if not os.path.exists(command_script_dir):
        os.makedirs(command_script_dir)

    with open(os.path.join(command_script_dir, 'is_command_script.sh'), 'w') as f:
        for command in command_list:
            f.write('{}\n'.format(command))
            f.flush()

    return os.path.join(command_script_dir, 'is_command_script.sh')

if __name__ == '__main__':
    command_filename = create_inception_score_commands()
    system_command = '''xargs -P {} -I {{}} sh -c 'eval "$1"' - {{}} < {}'''.format(args.num, command_filename)
    os.system(system_command)
