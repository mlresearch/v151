import torch

import os
import copy
import dgl
import random
from logzero import logger
import logging
import numpy as np
import matplotlib.pyplot as plt

from decomp_gen.data_structures.dataset import GraphDataset
from decomp_gen.utils.dist_helper import *
from decomp_gen import configs
from decomp_gen.utils.eval_helper import (
    spectral_stats, orbit_stats_all, clustering_stats, degree_stats, is_lobster_graph
)
from decomp_gen.data_structures.generating_tree import GeneratingTree, InCompleteDT

logger.setLevel(logging.INFO)

random_seed = 1234
random.seed(random_seed)
torch.manual_seed(random_seed)

SHARING_MODE = 'probabilistic'
ADDING_MODE = 'probabilistic'

#options: ['probabilistic', 'deterministic']

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


def negative_log_likelihood(output, y):
    y = torch.Tensor(y).long().to(device)
    tmp = -(torch.log(output.gather(1, y.view(-1, 1))))
    tmp = tmp.sum()
    return tmp


def generateTree(model, seed=12345):
    MaskLenForData = model.MaskLen
    np.random.seed(seed)
    GT = GeneratingTree()
    NLL = torch.tensor([0.0]).to(device)
    count = 0
    TPLR = []
    while not GT.isFinished():
        T = GT.getSimpleTree()
        limits = GT.nextStepLimit()

        DGLT = dgl.DGLGraph(T)

        p = nx.shortest_path_length(T, source=0)
        for ii, v in enumerate(DGLT.nodes()):
            vv = int(v.item())
            d = torch.zeros((1, 4)).type(torch.FloatTensor)
            # height = TPLR[0]-p[vv]
            if vv == 0:
                d[0, 0] = 1.0
            else:
                d[0, 1] = 1.0
            d[0, 2] = float(T.degree[vv])
            d[0, 3] = float(p[vv])
            DGLT.nodes[[v]].data['d'] = d

        DGLT = [DGLT]

        mask = [0.0] * MaskLenForData
        if limits[1] == -1:
            limits[1] = MaskLenForData
        for i in range(limits[0], limits[1]):
            mask[i] = 1.0

        extendingNodes = [GT.currentNode().getLabel()]
        Masks = [mask]

        Masks = torch.tensor(Masks)
        Masks = Masks.to(device)

        if limits[1] - limits[0] > 1:
            output = model(DGLT, extendingNodes, Masks)
            probs = [i.item() for i in output[0]]
            l = np.random.multinomial(1, probs / np.sum(probs), size=1)
            l = np.argmax(l)
            y = [l]
            nll = negative_log_likelihood(output, y)
            NLL += nll
        else:
            l = limits[0]

        GT.makeStep(l)
        TPLR.append(l)

    return GT.getSimpleTree(), GT, NLL


def process_node_sharing_data(graph, c, node_sharing_model):
    data = {
        'graph': None,
        'tree': dgl.DGLGraph(graph['IDT'].T),
        'cluster_node_idx': None,
        'super_node_idx': np.array([c]),
        'samples_per_tree': 1,
        'masked_shared': torch.zeros(1, node_sharing_model.C)
    }

    sn = graph['IDT'].nodes[c]
    parent = sn.parent

    parent_nodes = np.array(sorted(parent.nodes))
    data['cluster_node_idx'] = parent_nodes

    # raw_data['Gi'] = partial graph down to this supernode
    dglGi = dgl.DGLGraph(graph['graph'])
    dglGi = dgl.transform.add_self_loop(dglGi)

    adj_matrix = nx.to_numpy_matrix(graph['graph'])
    adj_matrix = np.pad(adj_matrix, [(0, 0), (0, node_sharing_model.N - adj_matrix.shape[1])],
                        mode='constant', constant_values=0.0)
    dglGi.ndata['a'] = torch.tensor(adj_matrix, dtype=torch.float32)

    dglGi.ndata['last_cluster_idx'] = torch.zeros(graph['graph'].number_of_nodes(),
                                                  node_sharing_model.C)

    for i, v in enumerate(parent_nodes):
        dglGi.ndata['last_cluster_idx'][v, i] = 1.0

    data['graph'] = dglGi

    return data


def process_node_adding_data(graph, c, node_adding_model):
    data = {
        'graph': None,
        'tree': dgl.DGLGraph(graph['IDT'].T)
    }

    if graph['IDT'].nodes[c].nodes is None:
        graph['IDT'].nodes[c].nodes = []

    sn = graph['IDT'].nodes[c]

    # print('in cluster ', c, 'nodes are:', sn.nodes)

    v = graph['max_node_id'] + 1
    Gi = copy.deepcopy(graph['graph'])
    Gi.add_node(v)

    dglGi = dgl.DGLGraph(Gi)
    dglGi = dgl.transform.add_self_loop(dglGi)

    adj_matrix = nx.to_numpy_matrix(Gi)
    adj_matrix = np.pad(adj_matrix, [(0, 0), (0, node_adding_model.N - adj_matrix.shape[1])],
                        mode='constant', constant_values=0.0)
    dglGi.ndata['a'] = torch.tensor(adj_matrix, dtype=torch.float32)

    last_cluster_node_idx = torch.zeros(Gi.number_of_nodes(), node_adding_model.C)
    for i, u in enumerate(sn.nodes):
        last_cluster_node_idx[u, i] = 1.0

    last_cluster_node_idx[v, len(sn.nodes)] = 1.0

    dglGi.ndata['c'] = last_cluster_node_idx

    data['graph'] = dglGi

    return data


def generate_graphs(tree_model, node_sharing_model, node_adding_model, cnt, seed):
    """
    Uses trained models to generate graph during inference time
    """
    tree_model.eval()
    node_sharing_model.eval()
    node_adding_model.eval()

    graphs = []

    with torch.no_grad():
        # initializing the graphs and their trees:
        in_process = set()

        # data = GraphDataset('test_grid', 'test_grid.dat', reorder_epochs=10000)
        # G = [data[0], copy.deepcopy(data[0])]
        # G[1].reOrder()
        # G.T.showTree(printNodes=True)
        # nx.draw(G.G, with_labels=True)
        # plt.show()
        for i in range(cnt):
            g = nx.Graph()

            # # print('tree_model.MaskLen: ', tree_model.MaskLen)
            tree, gt, nll = generateTree(tree_model, seed+i)
            IDT = gt.IDT

            # T = G[i].T.getSimpleTree()
            # IDT = InCompleteDT(T)

            graph = {'graph': copy.deepcopy(g),
                     'IDT': copy.deepcopy(IDT),
                     'max_node_id': -1
                     }
            graphs.append(graph)
            in_process.add(i)

        c = 0
        while len(in_process) > 0:
            print('***************************************starting cluster ', c)
            # node_sharing, happens for clusters after first cluster (c>0):
            in_sharing_process = copy.copy(in_process)
            if c > 0:
                # print('sharing from {} to {}'.format(graphs[0]['IDT'].nodes[c].parent.label, c))
                data = {}
                for idx in in_sharing_process:
                    graph_data = process_node_sharing_data(
                        copy.deepcopy(graphs[idx]), c, node_sharing_model)
                    data[idx] = graph_data

                pid = 0
                while len(in_sharing_process):
                    model_graphs = list()
                    model_trees = list()
                    cluster_node_idx = list()
                    super_node_idx = list()
                    samples_per_tree = list()
                    masked_shared = list()
                    for idx in in_sharing_process:
                        model_graphs.append(copy.deepcopy(data[idx]['graph']))
                        model_trees.append(copy.deepcopy(data[idx]['tree']))
                        cluster_node_idx.append(np.array([data[idx]['cluster_node_idx'][pid]]))
                        super_node_idx.append(data[idx]['super_node_idx'])
                        samples_per_tree.append(data[idx]['samples_per_tree'])
                        masked_shared.append(data[idx]['masked_shared'])

                    masked_shared = torch.cat(masked_shared, dim=0)

                    # breakpoint()

                    output = node_sharing_model(model_graphs, model_trees,
                                                cluster_node_idx,
                                                super_node_idx,
                                                samples_per_tree,
                                                masked_shared)

                    # m = torch.nn.Sigmoid()
                    # output = m(output)
                    if SHARING_MODE == 'deterministic':
                        pred = output >= 0.5
                        pred = pred.type(torch.IntTensor)
                    else:
                        pred = torch.bernoulli(output)

                    pred = pred.squeeze()
                    if pred.shape == torch.Size([]):
                        pred = pred.view(1)

                    # print('pid: ', pid)
                    # print('data[0][cluster_node_idx]:', data[0]['cluster_node_idx'])
                    # print('data[1][cluster_node_idx]:', data[1]['cluster_node_idx'])
                    # print('output for sharing node ',
                    #       data[0]['cluster_node_idx'][pid], 'from ',
                    #       graphs[0]['IDT'].nodes[c].parent.label, 'to ',
                    #       c, 'is: ', output, ' pred:', pred)

                    for ii, idx in enumerate(in_sharing_process):
                        node_id = data[idx]['cluster_node_idx'][pid]
                        if pred[ii] > 0.5:
                            if graphs[idx]['IDT'].nodes[c].nodes is not None:
                                graphs[idx]['IDT'].nodes[c].nodes.append(node_id)
                            else:
                                graphs[idx]['IDT'].nodes[c].nodes = [node_id]
                        data[idx]['masked_shared'][0][pid] = pred[ii] * 2.0 - 1.0

                    pid += 1

                    tmp = copy.copy(in_sharing_process)
                    for idx in tmp:
                        if data[idx]['cluster_node_idx'].shape[0] <= pid:
                            in_sharing_process.remove(idx)
            ##################################################################node sharing finished

            in_cluster_process = copy.copy(in_process)
            # add nodes to clusters:
            nid = -1
            while len(in_cluster_process) > 0:
                nid += 1

                # needed for edge calculations
                edge_data = {}

                if nid == 0:
                    # adding one necessary node for each cluster:
                    for idx in in_cluster_process:
                        graph_data = process_node_adding_data(copy.deepcopy(graphs[idx]), c,
                                                              node_adding_model)
                        edge_data[idx] = {'graph': graph_data['graph'],
                                          'tree': graph_data['tree'],
                                          'masked_edges': torch.zeros([1, node_adding_model.C])}

                        graphs[idx]['max_node_id'] += 1
                        graphs[idx]['graph'].add_node(graphs[idx]['max_node_id'])
                        if graphs[idx]['IDT'].nodes[c].nodes is not None:
                            graphs[idx]['IDT'].nodes[c].nodes.append(graphs[idx]['max_node_id'])
                        else:
                            graphs[idx]['IDT'].nodes[c].nodes = [graphs[idx]['max_node_id']]

                        # print('for graph id: {}, adding node {} to cluster {}'.format(idx, graphs[idx]['max_node_id'], c))

                else:
                    # preparing data for node adding:
                    model_graphs = list()
                    model_trees = list()
                    node_graph_idx = np.array(range(len(in_cluster_process)))
                    node_super_node_idx = list()
                    node_tree_idx = np.array(range(len(in_cluster_process)))
                    edges = np.zeros([0, 2])
                    edge_super_node_idx = np.array([])
                    edge_tree_idx = np.array([])
                    masked_edges = torch.zeros(0, node_adding_model.C)
                    edge_graph_idx = np.array([])

                    tree_super_node_offset = 0

                    for idx in in_cluster_process:
                        graph_data = process_node_adding_data(copy.deepcopy(graphs[idx]), c,
                                                              node_adding_model)
                        model_graphs.append(copy.deepcopy(graph_data['graph']))
                        model_trees.append(copy.deepcopy(graph_data['tree']))

                        edge_data[idx] = {'graph': graph_data['graph'],
                                          'tree': graph_data['tree'],
                                          'masked_edges': torch.zeros([1, node_adding_model.C])}

                        node_super_node_idx.append(c + tree_super_node_offset)
                        tree_super_node_offset += graph_data['tree'].number_of_nodes()

                    node_super_node_idx = np.array(node_super_node_idx)

                    # breakpoint()

                    output_node, _ = node_adding_model(model_graphs, model_trees,
                                                       node_graph_idx,
                                                       node_super_node_idx,
                                                       node_tree_idx,
                                                       edges,
                                                       edge_super_node_idx,
                                                       edge_tree_idx,
                                                       masked_edges,
                                                       edge_graph_idx)

                    if ADDING_MODE == 'deterministic':
                        pred = output_node >= 0.5
                        pred = pred.type(torch.IntTensor)
                    else:
                        pred = torch.bernoulli(output_node)

                    pred = pred.squeeze()
                    if pred.shape == torch.Size([]):
                        pred = pred.view(1)
                    # print('output for node: ', output_node, ' pred: ', pred)

                    tmp = copy.copy(in_cluster_process)
                    for ii, idx in enumerate(tmp):
                        if pred[ii] < 0.5:
                            in_cluster_process.remove(idx)
                        else:
                            graphs[idx]['max_node_id'] += 1
                            # print('graph id: {}, adding node {} to cluster {}'.format(idx, graphs[idx]['max_node_id'], c))
                            graphs[idx]['graph'].add_node(graphs[idx]['max_node_id'])
                            graphs[idx]['IDT'].nodes[c].nodes.append(graphs[idx]['max_node_id'])

                # Finding connections for recently added nodes:
                in_edge_process = copy.copy(in_cluster_process)
                # print('in_edge_process: ', in_edge_process)
                pid = 0
                while len(in_edge_process) > 0:

                    if graphs[idx]['graph'].number_of_nodes() == 1:
                        break

                    # preparing data for node adding model
                    model_graphs = list()
                    model_trees = list()
                    node_graph_idx = np.array([])
                    node_super_node_idx = np.array([])
                    node_tree_idx = np.array([])
                    edges = list()
                    edge_super_node_idx = list()
                    edge_graph_idx = np.array(range(len(in_edge_process)))
                    edge_tree_idx = np.array(range(len(in_edge_process)))
                    masked_edges = list()

                    tree_super_node_offset = 0
                    graph_nodes_offset = 0
                    for idx in in_edge_process:
                        model_graphs.append(copy.deepcopy(edge_data[idx]['graph']))
                        model_trees.append(copy.deepcopy(edge_data[idx]['tree']))
                        edge_super_node_idx.append(tree_super_node_offset + c)
                        tree_super_node_offset += edge_data[idx]['tree'].number_of_nodes()

                        u = graphs[idx]['max_node_id']
                        tmp = sorted(graphs[idx]['IDT'].nodes[c].nodes)
                        v = tmp[pid]
                        edges.append([u + graph_nodes_offset, v + graph_nodes_offset])
                        graph_nodes_offset += edge_data[idx]['graph'].number_of_nodes()

                        masked_edges.append(edge_data[idx]['masked_edges'])

                    edge_super_node_idx = np.array(edge_super_node_idx)
                    masked_edges = torch.cat(masked_edges, dim=0)
                    edges = np.array(edges)

                    # print('model_graph: ', model_graphs[0])
                    # print('model_tree:', model_trees[0])
                    # print('edges: ', edges)
                    # print('edge_super_node_idx: ', edge_super_node_idx)
                    # print('edge_tree_idx: ', edge_tree_idx)
                    # print('masked_edges: ', masked_edges)
                    # breakpoint()
                    _, output_edge = node_adding_model(model_graphs, model_trees,
                                                       node_graph_idx,
                                                       node_super_node_idx,
                                                       node_tree_idx,
                                                       edges,
                                                       edge_super_node_idx,
                                                       edge_tree_idx,
                                                       masked_edges,
                                                       edge_graph_idx)


                    if ADDING_MODE == 'deterministic':
                        pred = output_edge >= 0.5
                        pred = pred.type(torch.IntTensor)
                    else:
                        pred = torch.bernoulli(output_edge)

                    pred = pred.squeeze()
                    if pred.shape == torch.Size([]):
                        pred = pred.view(1)

                    # print('output for edge: ', output_edge, ' pred: ', pred, 'for edges: ', edges)

                    for i, idx in enumerate(in_edge_process):
                        edge_data[idx]['masked_edges'][0][pid] = 2.0 * pred[i] - 1.0
                        if pred[i] > 0.5:
                            tmp = sorted(graphs[idx]['IDT'].nodes[c].nodes)
                            vv = tmp[pid]
                            # print('adding edge in cluster ', c, ' between nodes: ', edges[i][0], edges[i][1])
                            graphs[idx]['graph'].add_edge(graphs[idx]['max_node_id'], vv)

                    tmp = copy.copy(in_edge_process)
                    for idx in tmp:
                        if len(graphs[idx]['IDT'].nodes[c].nodes) <= (pid + 2):
                            in_edge_process.remove(idx)

                    pid += 1

            tmp = copy.copy(in_process)
            for idx in tmp:
                if graphs[idx]['IDT'].T.number_of_nodes() <= (c + 1):
                    in_process.remove(idx)

            c += 1

    simple_graphs = []
    for g in graphs:
        simple_graphs.append(g['graph'])
    return simple_graphs, graphs


def dist_stats(tree_model, node_sharing_model, node_adding_model, ref_test_graphs):
    """
    Generates graphs the same number as the length of the test_data
    """
    # test_data.__class__ = GraphDataset
    # ref_test_graphs = []
    # for G in test_data:
    #     ref_test_graphs.append(G.G)

    generated_graphs = []
    ii = 0

    seed = 1234
    while ii < len(ref_test_graphs):
        try:
            g, _ = generate_graphs(tree_model, node_sharing_model,
                                          node_adding_model, 1, seed=seed)
            generated_graphs.append(g[0])
            ii += 1
        except:
            print('failed in generation')
        seed += 1


    graph_empty = [
        G for G in generated_graphs if G.number_of_nodes() == 0
    ]
    logger.info(f'len empty graphs: {len(graph_empty)}')

    deg_stats = degree_stats(ref_test_graphs, generated_graphs)
    spec_stats = spectral_stats(ref_test_graphs, generated_graphs)
    clus_stats = clustering_stats(ref_test_graphs, generated_graphs)
    mmd_dist = orbit_stats_all(ref_test_graphs, generated_graphs)

    print('degree_stats: ', deg_stats)
    print('clustering_stats: ', clus_stats)
    print('orbit_stats_all: ', mmd_dist)
    print('spectral_stats: ', spec_stats)

    return deg_stats, clus_stats, mmd_dist, spec_stats

def dist_stats_lobster(tree_model, test_graphs):
    generated_trees = []
    correct_cnt = 0.0
    for i in range(100):
        tree, _, _ = generateTree(tree_model, random_seed+i)
        generated_trees.append(tree)
        if is_lobster_graph(tree):
            correct_cnt += 1.0
            print(i, ': correct')
        else:
            print(i, 'incorrect!!!!!!!!!!!')

    deg_stats = degree_stats(test_graphs, generated_trees)
    spec_stats = spectral_stats(test_graphs, generated_trees)
    clus_stats = clustering_stats(test_graphs, generated_trees)
    mmd_dist = orbit_stats_all(test_graphs, generated_trees)

    print('degree_stats: ', deg_stats)
    print('clustering_stats: ', clus_stats)
    print('orbit_stats_all: ', mmd_dist)
    print('spectral_stats: ', spec_stats)
    print('accuracy = ', correct_cnt)



def main():
    ############################################################################################
    # adr = os.path.join(configs.root_dir, 'saved_models')
    #
    # adr_tree = os.path.join(adr, 'treeModel_data_grid')
    # adr_sharing = os.path.join(adr, 'node_sharing_grid')
    # adr_adding = os.path.join(adr, 'node_adding_grid')
    #
    # tree_model = torch.load(adr_tree, map_location=device)
    # node_sharing_model = torch.load(adr_sharing, map_location=device)
    # node_adding_model = torch.load(adr_adding, map_location=device)
    #
    # simple_graphs, _ = generate_graphs(tree_model, node_sharing_model, node_adding_model, 1)
    # #
    # # # plt.ioff()
    # nx.draw(simple_graphs[0], with_labels=True)
    # plt.show()
    #############################################################################################
    # #
    # # nx.draw(simple_graphs[1], with_labels=True)
    # # plt.show(block=False)
    #
    # test_data = GraphDataset('test_grid', 'test_grid.dat')
    # test_ref_graphs = [g.G for g in test_data.graphs]
    # dist_stats(tree_model, node_sharing_model, node_adding_model, test_ref_graphs)
    ############################################################################################
    # adr = os.path.join(configs.root_dir, 'saved_models')
    #
    # adr_tree = os.path.join(adr, 'tree_generator_lobster_2')
    #
    # tree_model = torch.load(adr_tree, map_location=device)
    #
    # # plt.ioff()
    # # nx.draw(simple_graphs[0], with_labels=True)
    # # plt.show(block=False)
    # #
    # # nx.draw(simple_graphs[1], with_labels=True)
    # # plt.show(block=False)
    #
    # data = GraphDataset('lobster', 'lobster.dat')
    # trees = data.graphs
    # test_data = trees[80:100]
    #
    # test_graphs = [t.getSimpleTree() for t in test_data]
    # dist_stats_lobster(tree_model, test_graphs)
    ############################################################################################


    SEED = 1234
    IS_SHUFFLE = True

    data = GraphDataset('ladder_small', 'ladder_small.dat')

    # making indices for train/test
    train_last_idx = int(float(len(data)) * 0.8)
    len_test = len(data) - train_last_idx

    indices = list(range(len(data)))
    ### shuffle all graphs
    if IS_SHUFFLE:
        npr = np.random.RandomState(SEED)
        npr.shuffle(indices)

    train_idxs = indices[0:len_test]
    test_idxs = indices[train_last_idx:]

    test_graphs = []
    for idx in test_idxs:
        test_graphs.append(data.graphs[idx].G)

    train_graphs = []
    for idx in train_idxs:
        train_graphs.append(data.graphs[idx].G)

    deg_stats = degree_stats(test_graphs, train_graphs)
    spec_stats = spectral_stats(test_graphs, train_graphs)
    clus_stats = clustering_stats(test_graphs, train_graphs)
    mmd_dist = orbit_stats_all(test_graphs, train_graphs)

    print('degree_stats: ', deg_stats)
    print('clustering_stats: ', clus_stats)
    print('orbit_stats_all: ', mmd_dist)
    print('spectral_stats: ', spec_stats)


if __name__ == "__main__":
    main()
