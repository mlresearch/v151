library(RandomFields)
library(randtoolbox)
library(GPfit)
library(geoR)
library(lhs)
library(flexclust)
library(mlegp)
library(mvtnorm)
library("latex2exp")

nuset = c(1.5,2.5,3.5)

for(ig in 1:3){
  if(ig == 1){
    load("GPrealizationnu15DATA")
  }
  if(ig == 2){
    load("GPrealizationnu25DATA")
  }
  if(ig == 3){
    load("GPrealizationnu35DATA")
  }
    for(nu in nuset){
    mynu = nu

    ##### copy
    n1 = 101
    myPreX <- seq(0, 1, length.out = n1)
    myPreY <- seq(0, 1, length.out = n1) # prediction points
    myd <- expand.grid(x = myPreX, y = myPreY) # gridpoints
    d1 <- myd
    d1[,1] <- myd[,2]
    d1[,2] <- myd[,1]
    
    sigma2 = 1
    
    pointeval = function(x,X){
      for(i in 1:dim(X)[1]){
        if(x[1] == X[i,1] & x[2] == X[i,2]){
          return(i)
        }
      }
    }
    
    findY = function(y,Y){
      for(i in 1:length(Y)){
        if(Y[i] == y){
          return(i)
        }
      }
    }
    
    desnum = 5
    itmax = 30
    itnum = seq(5, itmax, by = 5)
    itnumlen = length(itnum)
    
    myX = optimumLHS(n=desnum, k=2) # ini design
    myXX = round(myX/(1/(n1-1)))*(1/(n1-1)) # LHS on grids
    
    # gpva <- matrix(data = 1,nrow = 100, ncol = n1^2)
    nipos <- matrix(data = 1,nrow = 100, ncol = desnum + itmax)
    mycover <- seq(0.2,1.5,by = 0.1)
    myclen <- length(mycover)
    mycoverrate95 <- matrix(data = 0,nrow = myclen, ncol = itnumlen)
    mycoverrate50 <- matrix(data = 0,nrow = myclen, ncol = itnumlen)
    trocoverrate95 <- matrix(data = 0,nrow = itnumlen, ncol = 1)
    trocoverrate50 <- matrix(data = 0,nrow = itnumlen, ncol = 1)
    
    myoutput <- matrix(data = 0,nrow = 200, ncol = itnumlen)
    myoutputnew <- matrix(data = 0,nrow = 1, ncol = itnumlen)
    
    myoutputwd <- matrix(data = 0, nrow = 200, ncol = itnumlen)
    myoutputnewwd <- matrix(data = 0, nrow = 1, ncol = itnumlen)
    
    Ciwidth5 <- matrix(data = 0,nrow = myclen, ncol = 100)
    Ciupper5 <- matrix(data = 0,nrow = myclen, ncol = 100)
    
    Ciwidth10 <- matrix(data = 0,nrow = myclen, ncol = 100)
    Ciupper10 <- matrix(data = 0,nrow = myclen, ncol = 100)
    
    Ciwidth15 <- matrix(data = 0,nrow = myclen, ncol = 100)
    Ciupper15 <- matrix(data = 0,nrow = myclen, ncol = 100)
    
    Ciwidth20 <- matrix(data = 0,nrow = myclen, ncol = 100)
    Ciupper20 <- matrix(data = 0,nrow = myclen, ncol = 100)
    
    Ciwidth25 <- matrix(data = 0,nrow = myclen, ncol = 100)
    Ciupper25 <- matrix(data = 0,nrow = myclen, ncol = 100)
    
    Ciwidth30 <- matrix(data = 0,nrow = myclen, ncol = 100)
    Ciupper30 <- matrix(data = 0,nrow = myclen, ncol = 100)
    
    Ciwidthtr <- matrix(data = 0,nrow = itnumlen, ncol = 100)
    Ciuppertr <- matrix(data = 0,nrow = itnumlen, ncol = 100)
    
    Ciwidthtr50 <- matrix(data = 0,nrow = itnumlen, ncol = 100)
    
    Ci50width5 <- matrix(data = 0,nrow = myclen, ncol = 100)
    Ci50upper5 <- matrix(data = 0,nrow = myclen, ncol = 100)
    
    Ci50width10 <- matrix(data = 0,nrow = myclen, ncol = 100)
    Ci50upper10 <- matrix(data = 0,nrow = myclen, ncol = 100)
    
    Ci50width15 <- matrix(data = 0,nrow = myclen, ncol = 100)
    Ci50upper15 <- matrix(data = 0,nrow = myclen, ncol = 100)
    
    Ci50width20 <- matrix(data = 0,nrow = myclen, ncol = 100)
    Ci50upper20 <- matrix(data = 0,nrow = myclen, ncol = 100)
    
    Ci50width25 <- matrix(data = 0,nrow = myclen, ncol = 100)
    Ci50upper25 <- matrix(data = 0,nrow = myclen, ncol = 100)
    
    Ci50width30 <- matrix(data = 0,nrow = myclen, ncol = 100)
    Ci50upper30 <- matrix(data = 0,nrow = myclen, ncol = 100)
    
    numtemp <- 0
    n1 = n1^2
    
    EIdata <- matrix(data = 1,nrow = 100,ncol = 1) 
    A0D <- 25
    
    myscalenu = function(nu,p){
      D = sqrt(p)
      return((p*4*sqrt(nu)*gamma(nu + 1/2)*D/(sqrt(pi) * (2*nu - 1)*gamma(nu)))/A0D)
    }
    
    Mtheta <- myscalenu(mynu,2)
    myphi = Mtheta/(2*sqrt(mynu))
    
    gpdrawsimu = function(n,A){
      bdr = as.matrix(rnorm(n))
      return(A %*% bdr)
    }
    
    myDist=as.matrix(dist(myPreX,diag=TRUE,upper=TRUE))
    PhiEval1 <- matern(u = myDist, phi = myphi, kappa = mynu)
    A1 <- t(cholx(PhiEval1))
    PhiEval <- kronecker(PhiEval1,PhiEval1)
    
    inipos <- 1:desnum
    for(k in 1:desnum){
      inipos[k] <- pointeval(myXX[k,],d1)
    }
    
    
    
    for(i in 1:100){
      # GPdraw = sigma2 * gpdrawsimu(n1,kronecker(A1,A1))
      # GPdraw = rmvnorm(n=1,sigma = PhiEval)
      # gpva[i,] <- GPdraw
      GPdraw <- gpva[i,]
      mypoints <- myXX
      myY <- 1:desnum
      
      for(k in 1:desnum){
        myY[k] <- GPdraw[inipos[k]]
      }
      posnow <- inipos
      ## start EI
      for(j in 1:itmax){
        print(c(i,j))
        # calculate kernel matrix
        # myDistx1=as.matrix(dist(matrix(as.matrix(mypoints[,1]),ncol = 1),diag=TRUE,upper=TRUE))
        # myDisty1=as.matrix(dist(matrix(as.matrix(mypoints[,2]),ncol = 1),diag=TRUE,upper=TRUE))
        # PhiEval1 <- matern(u = myDistx1, phi = 1/(2*sqrt(mynu)), kappa = mynu) *
        #   matern(u = myDisty1, phi = 1/(2*sqrt(mynu)), kappa = mynu)
        ## start prediction
        fHat <- as.matrix(PhiEval[,posnow])%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum-1+j),myY,tol = 0)
        curmaxf <- max(fHat)
        sigmax <- matrix(1:n1,ncol = 1)
        for(xnum in 1:n1){
          sigmax[xnum] <- sigma2 * sqrt(1 - PhiEval[xnum,posnow]%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum-1+j),PhiEval[posnow,xnum],tol = 0))
        }
        ## calculate GPUCB
        fei <- 1:n1
        for(p in 1:n1){
          myttt <- sqrt(log(16/0.05))
          temp <- sqrt(2 * log(j^2*2*pi^2/(3*0.05)) + 4*log(j^2*2*myttt))
          fei[p] <- fHat[p] + sigmax[p]*temp
        }
        curmpos <- which.max(fei)
        mypoints <- rbind(mypoints,as.matrix(d1[curmpos,],nrow =1))
        myY <- c(myY,GPdraw[curmpos])
        posnow <- c(posnow,curmpos)
        ## save data j=5
        if(j == 5){
          ## last calculation
          fHat <- as.matrix(PhiEval[,posnow])%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),myY,tol = 0)
          curmaxf <- max(fHat)
          sigmax <- matrix(1:n1,ncol = 1)
          for(xnum in 1:n1){
            sigmax[xnum] <- sigma2 * sqrt(1 - PhiEval[xnum,posnow]%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),PhiEval[posnow,xnum],tol = 0))
          }
          
          ## cover?
          gpmaxpos <- which.max(GPdraw)
          temp4 <- max(fHat + sigmax* 1.64)
          Ciwidthtr[1,i] <- temp4 - max(myY)
          Ciuppertr[1,i] <- temp4
          Ciwidthtr50[1,i] <- max(fHat) - max(myY)
          if(GPdraw[gpmaxpos] < temp4){
            trocoverrate95[1] <- trocoverrate95[1] + 1
          }
          for(p in 1:200){
            temp5 = max(fHat + sigmax* (1.64 + p*0.01))
            if(GPdraw[gpmaxpos] < temp5){
              myoutput[p,1] <- myoutput[p,1] + 1
            }
            myoutputwd[p,1] <- myoutputwd[p,1] + temp5 -  max(myY)
          }
          temp5 <- max(fHat)
          if(GPdraw[gpmaxpos] < temp5){
            trocoverrate50[1] <- trocoverrate50[1] + 1
          }
          for(k in 1:myclen){
            temp1 <- max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(log(max(exp(1),A0D))) + sqrt(-log(0.5)*2)))
            temp2 <- max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(log(max(exp(1),A0D))) + sqrt(-log(0.05)*2)))
            Ciwidth5[k,i] <- temp2 - max(myY)
            Ciupper5[k,i] <- temp2
            Ci50width5[k,i] <- temp1 - max(myY)
            Ci50upper5[k,i] <- temp1
            if(GPdraw[gpmaxpos] < temp1){
              mycoverrate50[k,1] <- mycoverrate50[k,1] + 1
            }
            if(GPdraw[gpmaxpos] < temp2){
              mycoverrate95[k,1] <- mycoverrate95[k,1] + 1
            }
            # print(temp1 - max(fHat))
            # print(temp4 - max(fHat))
            # print(temp1-temp4)
          }
          temp6 = max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (1 + sqrt(-log(0.05)*2)))
          if(GPdraw[gpmaxpos] < temp6){
            myoutputnew[1] <- myoutputnew[1] + 1
          }
          myoutputnewwd[1] <-  myoutputnewwd[1] + temp6 -  max(myY)
          
        }
        ## save data j=10
        if(j == 10){
          ## last calculation
          fHat <- as.matrix(PhiEval[,posnow])%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),myY,tol = 0)
          curmaxf <- max(fHat)
          sigmax <- matrix(1:n1,ncol = 1)
          for(xnum in 1:n1){
            sigmax[xnum] <- sigma2 * sqrt(1 - PhiEval[xnum,posnow]%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),PhiEval[posnow,xnum],tol = 0))
          }
          
          ## cover?
          gpmaxpos <- which.max(GPdraw)
          temp4 <- max(fHat + sigmax* 1.64)
          Ciwidthtr[2,i] <- temp4 - max(myY)
          Ciuppertr[2,i] <- temp4
          Ciwidthtr50[2,i] <- max(fHat) - max(myY)
          if(GPdraw[gpmaxpos] < temp4){
            trocoverrate95[2] <- trocoverrate95[2] + 1
          }
          temp5 <- max(fHat)
          if(GPdraw[gpmaxpos] < temp5){
            trocoverrate50[2] <- trocoverrate50[2] + 1
          }
          for(p in 1:200){
            temp5 = max(fHat + sigmax* (1.64 + p*0.01))
            if(GPdraw[gpmaxpos] < temp5){
              myoutput[p,2] <- myoutput[p,2] + 1
            }
            myoutputwd[p,2] <- myoutputwd[p,2] + temp5 -  max(myY)
          }
          for(k in 1:myclen){
            temp1 <- max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(log(max(exp(1),A0D))) + sqrt(-log(0.5)*2)))
            temp2 <- max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(log(max(exp(1),A0D))) + sqrt(-log(0.05)*2)))
            Ciwidth10[k,i] <- temp2 - max(myY)
            Ciupper10[k,i] <- temp2
            Ci50width10[k,i] <- temp1 - max(myY)
            Ci50upper10[k,i] <- temp1
            if(GPdraw[gpmaxpos] < temp1){
              mycoverrate50[k,2] <- mycoverrate50[k,2] + 1
            }
            if(GPdraw[gpmaxpos] < temp2){
              mycoverrate95[k,2] <- mycoverrate95[k,2] + 1
            }
            # print(temp1 - max(fHat))
            # print(temp4 - max(fHat))
            # print(temp1-temp4)
          }
          temp6 = max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (1 + sqrt(-log(0.05)*2)))
          if(GPdraw[gpmaxpos] < temp6){
            myoutputnew[2] <- myoutputnew[2] + 1
          }
          myoutputnewwd[2] <-  myoutputnewwd[2] + temp6 -  max(myY)
        }
        ## save data j=15
        if(j == 15){
          ## last calculation
          fHat <- as.matrix(PhiEval[,posnow])%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),myY,tol = 0)
          curmaxf <- max(fHat)
          sigmax <- matrix(1:n1,ncol = 1)
          for(xnum in 1:n1){
            sigmax[xnum] <- sigma2 * sqrt(1 - PhiEval[xnum,posnow]%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),PhiEval[posnow,xnum],tol = 0))
          }
          
          ## cover?
          gpmaxpos <- which.max(GPdraw)
          temp4 <- max(fHat + sigmax* 1.64)
          Ciwidthtr[3,i] <- temp4 - max(myY)
          Ciuppertr[3,i] <- temp4
          Ciwidthtr50[3,i] <- max(fHat) - max(myY)
          if(GPdraw[gpmaxpos] < temp4){
            trocoverrate95[3] <- trocoverrate95[3] + 1
          }
          temp5 <- max(fHat)
          if(GPdraw[gpmaxpos] < temp5){
            trocoverrate50[3] <- trocoverrate50[3] + 1
          }
          for(p in 1:200){
            temp5 = max(fHat + sigmax* (1.64 + p*0.01))
            if(GPdraw[gpmaxpos] < temp5){
              myoutput[p,3] <- myoutput[p,3] + 1
            }
            myoutputwd[p,3] <- myoutputwd[p,3] + temp5 -  max(myY)
          }
          for(k in 1:myclen){
            temp1 <- max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(log(max(exp(1),A0D))) + sqrt(-log(0.5)*2)))
            temp2 <- max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(log(max(exp(1),A0D))) + sqrt(-log(0.05)*2)))
            Ciwidth15[k,i] <- temp2 - max(myY)
            Ciupper15[k,i] <- temp2
            Ci50width15[k,i] <- temp1 - max(myY)
            Ci50upper15[k,i] <- temp1
            if(GPdraw[gpmaxpos] < temp1){
              mycoverrate50[k,3] <- mycoverrate50[k,3] + 1
            }
            if(GPdraw[gpmaxpos] < temp2){
              mycoverrate95[k,3] <- mycoverrate95[k,3] + 1
            }
            # print(temp1 - max(fHat))
            # print(temp4 - max(fHat))
            # print(temp1-temp4)
          }
          temp6 = max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (1 + sqrt(-log(0.05)*2)))
          if(GPdraw[gpmaxpos] < temp6){
            myoutputnew[3] <- myoutputnew[3] + 1
          }
          myoutputnewwd[3] <-  myoutputnewwd[3] + temp6 -  max(myY)
        }
        ## save data j=20
        if(j == 20){
          ## last calculation
          fHat <- as.matrix(PhiEval[,posnow])%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),myY,tol = 0)
          curmaxf <- max(fHat)
          sigmax <- matrix(1:n1,ncol = 1)
          for(xnum in 1:n1){
            sigmax[xnum] <- sigma2 * sqrt(1 - PhiEval[xnum,posnow]%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),PhiEval[posnow,xnum],tol = 0))
          }
          
          ## cover?
          gpmaxpos <- which.max(GPdraw)
          temp4 <- max(fHat + sigmax* 1.64)
          Ciwidthtr[4,i] <- temp4 - max(myY)
          Ciuppertr[4,i] <- temp4
          Ciwidthtr50[4,i] <- max(fHat) - max(myY)
          if(GPdraw[gpmaxpos] < temp4){
            trocoverrate95[4] <- trocoverrate95[4] + 1
          }
          for(p in 1:200){
            temp5 = max(fHat + sigmax* (1.64 + p*0.01))
            if(GPdraw[gpmaxpos] < temp5){
              myoutput[p,4] <- myoutput[p,4] + 1
            }
            myoutputwd[p,4] <- myoutputwd[p,4] + temp5 -  max(myY)
          }
          temp5 <- max(fHat)
          if(GPdraw[gpmaxpos] < temp5){
            trocoverrate50[4] <- trocoverrate50[4] + 1
          }
          for(k in 1:myclen){
            temp1 <- max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(log(max(exp(1),A0D))) + sqrt(-log(0.5)*2)))
            temp2 <- max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(log(max(exp(1),A0D))) + sqrt(-log(0.05)*2)))
            Ciwidth20[k,i] <- temp2 - max(myY)
            Ciupper20[k,i] <- temp2
            Ci50width20[k,i] <- temp1 - max(myY)
            Ci50upper20[k,i] <- temp1
            if(GPdraw[gpmaxpos] < temp1){
              mycoverrate50[k,4] <- mycoverrate50[k,4] + 1
            }
            if(GPdraw[gpmaxpos] < temp2){
              mycoverrate95[k,4] <- mycoverrate95[k,4] + 1
            }
            # print(temp1 - max(fHat))
            # print(temp4 - max(fHat))
            # print(temp1-temp4)
          }
          temp6 = max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (1 + sqrt(-log(0.05)*2)))
          if(GPdraw[gpmaxpos] < temp6){
            myoutputnew[4] <- myoutputnew[4] + 1
          }
          myoutputnewwd[4] <-  myoutputnewwd[4] + temp6 -  max(myY)
        }
        ## save data j=25
        if(j == 25){
          ## last calculation
          fHat <- as.matrix(PhiEval[,posnow])%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),myY,tol = 0)
          curmaxf <- max(fHat)
          sigmax <- matrix(1:n1,ncol = 1)
          for(xnum in 1:n1){
            sigmax[xnum] <- sigma2 * sqrt(1 - PhiEval[xnum,posnow]%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),PhiEval[posnow,xnum],tol = 0))
          }
          
          ## cover?
          gpmaxpos <- which.max(GPdraw)
          temp4 <- max(fHat + sigmax* 1.64)
          Ciwidthtr[5,i] <- temp4 - max(myY)
          Ciuppertr[5,i] <- temp4
          Ciwidthtr50[5,i] <- max(fHat) - max(myY)
          if(GPdraw[gpmaxpos] < temp4){
            trocoverrate95[5] <- trocoverrate95[5] + 1
          }
          temp5 <- max(fHat)
          if(GPdraw[gpmaxpos] < temp5){
            trocoverrate50[5] <- trocoverrate50[5] + 1
          }
          for(p in 1:200){
            temp5 = max(fHat + sigmax* (1.64 + p*0.01))
            if(GPdraw[gpmaxpos] < temp5){
              myoutput[p,5] <- myoutput[p,5] + 1
            }
            myoutputwd[p,5] <- myoutputwd[p,5] + temp5 -  max(myY)
          }
          for(k in 1:myclen){
            temp1 <- max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(log(max(exp(1),A0D))) + sqrt(-log(0.5)*2)))
            temp2 <- max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(log(max(exp(1),A0D))) + sqrt(-log(0.05)*2)))
            Ciwidth25[k,i] <- temp2 - max(myY)
            Ciupper25[k,i] <- temp2
            Ci50width25[k,i] <- temp1 - max(myY)
            Ci50upper25[k,i] <- temp1
            if(GPdraw[gpmaxpos] < temp1){
              mycoverrate50[k,5] <- mycoverrate50[k,5] + 1
            }
            if(GPdraw[gpmaxpos] < temp2){
              mycoverrate95[k,5] <- mycoverrate95[k,5] + 1
            }
            # print(temp1 - max(fHat))
            # print(temp4 - max(fHat))
            # print(temp1-temp4)
          }
          temp6 = max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (1 + sqrt(-log(0.05)*2)))
          if(GPdraw[gpmaxpos] < temp6){
            myoutputnew[5] <- myoutputnew[5] + 1
          }
          myoutputnewwd[5] <-  myoutputnewwd[5] + temp6 -  max(myY)
        }
        ## save data j=30
        if(j == 30){
          ## last calculation
          fHat <- as.matrix(PhiEval[,posnow])%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),myY,tol = 0)
          curmaxf <- max(fHat)
          sigmax <- matrix(1:n1,ncol = 1)
          for(xnum in 1:n1){
            sigmax[xnum] <- sigma2 * sqrt(1 - PhiEval[xnum,posnow]%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),PhiEval[posnow,xnum],tol = 0))
          }
          
          ## cover?
          gpmaxpos <- which.max(GPdraw)
          temp4 <- max(fHat + sigmax* 1.64)
          Ciwidthtr[6,i] <- temp4 - max(myY)
          Ciuppertr[6,i] <- temp4
          Ciwidthtr50[6,i] <- max(fHat) - max(myY)
          if(GPdraw[gpmaxpos] < temp4){
            trocoverrate95[6] <- trocoverrate95[6] + 1
          }
          temp5 <- max(fHat)
          if(GPdraw[gpmaxpos] < temp5){
            trocoverrate50[6] <- trocoverrate50[6] + 1
          }
          for(p in 1:200){
            temp5 = max(fHat + sigmax* (1.64 + p*0.01))
            if(GPdraw[gpmaxpos] < temp5){
              myoutput[p,6] <- myoutput[p,6] + 1
            }
            myoutputwd[p,6] <- myoutputwd[p,6] + temp5 -  max(myY)
          }
          for(k in 1:myclen){
            temp1 <- max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(log(max(exp(1),A0D))) + sqrt(-log(0.5)*2)))
            temp2 <- max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(log(max(exp(1),A0D))) + sqrt(-log(0.05)*2)))
            Ciwidth30[k,i] <- temp2 - max(myY)
            Ciupper30[k,i] <- temp2
            Ci50width30[k,i] <- temp1 - max(myY)
            Ci50upper30[k,i] <- temp1
            if(GPdraw[gpmaxpos] < temp1){
              mycoverrate50[k,6] <- mycoverrate50[k,6] + 1
            }
            if(GPdraw[gpmaxpos] < temp2){
              mycoverrate95[k,6] <- mycoverrate95[k,6] + 1
            }
            # print(temp1 - max(fHat))
            # print(temp4 - max(fHat))
            # print(temp1-temp4)
          }
          temp6 = max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (1 + sqrt(-log(0.05)*2)))
          if(GPdraw[gpmaxpos] < temp6){
            myoutputnew[6] <- myoutputnew[6] + 1
          }
          myoutputnewwd[6] <-  myoutputnewwd[6] + temp6 -  max(myY)
        }
      }
      nipos[i,] <- posnow
      # ## last calculation
      # fHat = as.matrix(PhiEval[,posnow])%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+itnum),myY,tol = 0)
      # curmaxf <- max(fHat)
      # sigmax = matrix(1:n1,ncol = 1)
      # for(xnum in 1:n1){
      #   sigmax[xnum] = sqrt(1 - PhiEval[xnum,posnow]%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+itnum),PhiEval[posnow,xnum],tol = 0))
      # }
      # 
      # ## cover?
      # gpmaxpos <- which.max(GPdraw)
      # A0D = sqrt(2) * 2*4*sqrt(mynu)*gamma(mynu + 1/2)/(sqrt(pi) * (2*mynu - 1)*gamma(mynu))
      # for(k in 1:myclen){
      #   temp1 = fHat[gpmaxpos] + sigmax[gpmaxpos] * sqrt(log(exp(1)/sigmax[gpmaxpos])) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.05)*2))
      #   if(GPdraw[gpmaxpos] < temp1){
      #     mycoverrate95[k] <- mycoverrate95[k] + 1
      #   }
      # }
      # temp4 = max(fHat + sigmax* 1.64)
      # if(GPdraw[gpmaxpos] < temp4){
      #   trocoverrate95 <- trocoverrate95 + 1
      # }
      if(gpmaxpos == which.max(fHat)){
        numtemp = numtemp + 1
        print(numtemp)
        print(c(gpmaxpos,which.max(fHat)))
      }
    }


rm(d1,metadata,myDistw,myDistx,myDisty,myDistz,otu_table,PhiEval,PhiEval22)
save.image(...)
    }
}

# mydata3 for imposed nu
load("DATA")
mydata1 <- c(mean(Ciwidth5[9,]),mean(Ciwidth10[9,]),mean(Ciwidth15[9,]),mean(Ciwidth20[9,]),mean(Ciwidth25[9,]),mean(Ciwidth30[9,]))
plot(itnum, rowMeans(Ciwidthtr), xlab = "Iterations", ylab = "Width",type = "b",lty=1,ylim = c(0,5), col = colors()[7],lwd=2,cex.axis=1.5,cex.lab=1.5)
points(itnum, mydata1,type = "b",lty=2, col = colors()[12],lwd=2)

mydata3 <- c(1.865675, 1.757064, 1.691477, 1.587564, 1.489295, 1.389921) #nu15
# mydata3 <- c(1.829040, 1.721766, 1.659473, 1.575304, 1.476700, 1.391559) #nu25
# mydata3 <- c(1.968476, 1.765726, 1.684060, 1.594315, 1.521530, 1.470450) #nu35
points(itnum, mydata3,type = "b",lty=3, col = colors()[29],lwd=2)

load("DATA")
myoutput
mydata1 <- c(mean(Ciwidth5[9,]),mean(Ciwidth10[9,]),mean(Ciwidth15[9,]),mean(Ciwidth20[9,]),mean(Ciwidth25[9,]),mean(Ciwidth30[9,]))
points(itnum, rowMeans(Ciwidthtr),type = "b",lty=4, col =  colors()[34],lwd=2)
points(itnum, mydata1,type = "b",lty=5, col =  colors()[30],lwd=2)

# mydata3 <- c(1.771573, 1.657210, 1.618114, 1.553835, 1.470891, 1.392341) #nu15
mydata3 <- c(1.861971, 1.731726, 1.655860, 1.597548, 1.522713, 1.464914) #nu25
# mydata3 <- c(2.081262, 1.928602, 1.817199, 1.751170, 1.639804, 1.571281) #nu35
points(itnum, mydata3,type = "b",lty=6, col = colors()[50],lwd=2)

load("DATA")
mydata1 <- c(mean(Ciwidth5[9,]),mean(Ciwidth10[9,]),mean(Ciwidth15[9,]),mean(Ciwidth20[9,]),mean(Ciwidth25[9,]),mean(Ciwidth30[9,]))
points(itnum, rowMeans(Ciwidthtr),type = "b",lty=7,col = colors()[37],lwd=2)
points(itnum, mydata1,type = "b",lty=8, col = colors()[48],lwd=2)

# mydata3 <- c(1.847931, 1.732464, 1.647274, 1.608068, 1.544495, 1.502973)#nu15
# mydata3 <- c(2.010696, 1.909961, 1.834414, 1.728538, 1.671370, 1.608288) #nu25
mydata3 <- c(1.930512, 1.780545, 1.735878, 1.689472, 1.652152, 1.551744) #nu35
points(itnum, mydata3,type = "b",lty=9, col = colors()[59],lwd=2)

aa=TeX('$\\nu = 1.5, CI_G$')

legend('topright',ncol = 3, legend=c(TeX('$\\nu = 1.5, CI_G$'),TeX('$\\nu = 1.5, CI_t^{seq}$'),
                                     TeX('$\\nu = 1.5, CI_a$'),TeX('$\\nu = 2.5, CI_G$'), 
                                     TeX('$\\nu = 2.5, CI_t^{seq}$'),TeX('$\\nu = 2.5, CI_a$'),
                                     TeX('$\\nu = 3.5, CI_G$'),TeX('$\\nu = 3.5, CI_t^{seq}$'),TeX('$\\nu = 3.5, CI_a$')),
       lty=c(1,2,3,4,5,6),col=colors()[c(7,12,29,34,30,50,37,48,59)],cex=1.1)



load("DATA")
plot(itnum, trocoverrate95, xlab = "Iterations", ylab = "Coverage rate",type = "b",lty=1,ylim = c(0,140), col = "black",lwd=2,cex.axis=1.5,cex.lab=1.5)
points(itnum, mycoverrate95[9,],type = "b",lty=2, col = "blue",lwd=2)
load("DATA")
points(itnum, trocoverrate95,type = "b",lty=3, col = "brown",lwd=2)
points(itnum, mycoverrate95[9,],type = "b",lty=4, col = "orange",lwd=2)
load("DATA")
points(itnum, trocoverrate95,type = "b",lty=5,col = "purple",lwd=2)
points(itnum, mycoverrate95[9,],type = "b",lty=6, col = "red",lwd=2)

legend('topright',legend=c(TeX('$\\nu = 1.5, CI_G$'),TeX('$\\nu = 1.5, CI_t^{seq}$'),
                           TeX('$\\nu = 2.5, CI_G$'), 
                           TeX('$\\nu = 2.5, CI_t^{seq}$'),
                           TeX('$\\nu = 3.5, CI_G$'),TeX('$\\nu = 3.5, CI_t^{seq}$')),
       lty=c(1,2,3,4,5,6),col=c("black","blue","brown","orange","purple","red"), ncol=2,cex=1.1)