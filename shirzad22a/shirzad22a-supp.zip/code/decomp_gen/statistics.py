from decomp_gen.data_structures.dataset import GraphDataset

def main():
    data_name = 'citeseer'

    data = GraphDataset(data_name, '{}.dat'.format(data_name))

    stats = data.save_stats()

    print(len(stats['tree_size']))

if __name__ == "__main__":
    main()