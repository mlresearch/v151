import numpy as np
import pickle, os, random
import tensorflow as tf

def announce(message, verbal = True):
    if verbal:
        print(message)

def record(set, k, v):
    if k not in set:
        set[k] = {v}
    else:
        set[k].add(v)

def count(set, item):
    if item not in set:
        set[item] = 1.0
    else:
        set[item] += 1.0


def fix_seed(seed = 1234):
    os.environ['PYTHONHASHSEED'] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    tf.random.set_seed(seed)

def save_object(obj, filename):
    with open(filename, 'wb') as output:
        pickle.dump(obj, output)

def load_object(filename):
    with open(filename, 'rb') as output:
        return pickle.load(output)