import numpy as np
import scipy.linalg
from sklearn.cluster import KMeans
from sklearn.metrics import accuracy_score
from sklearn.neighbors import NearestNeighbors
from sklearn.utils.graph import graph_shortest_path
from sklearn.utils.validation import check_symmetric


def run_ssp(x_train_a, x_train_b, y_train, x_test, y_test):
    K = 5
    sigma = 1
    n = len(y_train)
    ml = [(i, n + i) for i in range(n) if y_train[i] == 1]
    cl = [(i, n + i) for i in range(n) if y_train[i] == -1]
    x_train = np.vstack([x_train_a, x_train_b, x_test])

    # x_train -= np.mean(x_train, axis=0)
    # x_train /= np.std(x_train, axis=0) + 1e-8

    nbrs = NearestNeighbors(n_neighbors=K + 1, algorithm="ball_tree").fit(
        x_train
    )
    distances, indices = nbrs.kneighbors(x_train)

    # G = kneighbors_graph(x_train, 5, mode='connectivity', include_self=False)
    G = nbrs.kneighbors_graph(x_train).toarray()
    G = np.where(G + G.T > 0, 1, 0)
    G = check_symmetric(G, raise_exception=True)

    dist = graph_shortest_path(G, directed=False)
    dist = np.where(dist > 37, 0, dist)  # deal with underflow
    dist = np.where(dist == 0, np.inf, dist)
    A = -(dist ** 2) / (2 * sigma ** 2)
    S = np.exp(A)
    S = np.where(S < 1e-10, 0, S)  # deal with underflow

    # Must-link Propagation
    for i, j in ml:
        S[i, j] = 1
        S[j, i] = 1
    for i0, j0 in ml:
        for i in indices[i]:
            for j in indices[j]:
                S[i, j] = max(S[i, j], S[i, i0] * S[i0, j0] * S[j0, j])
                S[j, i] = S[i, j]

    # Cannot-link Propagation
    for i, j in cl:
        S[i, j] = 0
        S[j, i] = 0
    for i0, j0 in cl:
        for i in indices[i]:
            for j in indices[j]:
                if (j in indices[i]) or (i in indices[j]):
                    continue
                else:
                    S[i, j] = min(S[i, j], 1 - S[i, i0] * S[j0, j])
                    S[j, i] = S[i, j]

    S = check_symmetric(S, raise_exception=True)

    D_inv = np.diag(1 / np.sum(S, axis=1))
    W = np.matmul(D_inv, S)
    w, v = scipy.sparse.linalg.eigsh(W, k=2, which="LA")

    clf = KMeans(n_clusters=2)
    y_pred = clf.fit_predict(v)[-len(x_test) :] * 2 - 1
    accuracy = accuracy_score(y_test, y_pred)

    return accuracy
