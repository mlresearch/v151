include("clustering_synthetic.jl")

main_clustering_synthetic(30,20)
