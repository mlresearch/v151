import argparse
import os

import torch
import torch.nn as nn
import yaml

from src import get_module_logger
from src.data.dataloader4img import calc_input_sizes, mydataloader
from src.models.train_model4img import train
from src.utils.model_rnn import classifier_rnn, classifier_rnn_CS


def main():
    artifacts = {}

    logger = get_module_logger("train")
    logger.debug("Begin...")
    parser = argparse.ArgumentParser()
    parser.add_argument("--irnn", type=bool, default=False, help="Use IRNN initialization if True.")
    parser.add_argument("--hidden_size", type=int, help="")
    parser.add_argument("--m_CS", type=int, default=None, help="Use RNN_CS.")
    parser.add_argument("--output_size", type=int, default=10, help="")
    parser.add_argument("--nonlinearity", type=str, default="tanh", help="tanh or relu")
    parser.add_argument("--lr", type=float, help="")
    parser.add_argument("--epochs", type=int, help="")
    parser.add_argument("--batch_size", type=int, help="")
    parser.add_argument("--dataset", type=str, help="MNIST, FashionMNIST or CIFAR10.")
    parser.add_argument("--task", type=str, default="pix", help="pix, seq or whole.")
    parser.add_argument("--data_dir", type=str, default="data", help="")
    # parser.add_argument("--log_dir", type=str, default="models/logs/", help="")
    # parser.add_argument("--log_exp", type=str, default="", help="Experiment tag.")
    parser.add_argument("--lr_step", type=float, default=1.0, help="LR-scheduler related.")
    parser.add_argument("--lr_gamma", type=float, default=0.1, help="LR-scheduler related.")
    parser.add_argument("--clip_value", type=float, default=None, help="Gradient clipping related.")
    parser.add_argument("--clip_norm", type=float, default=None, help="Gradient clipping related.")
    parser.add_argument("--experiment", type=str, default=None, help="Experimental name.")
    parser.add_argument("--tags", type=dict, default=None, help="Experimental tags to be converted to dictionary type.")
    parser.add_argument("--cfg", type=str, default="", help="Path for configuration file.")
    args = parser.parse_args()
    if args.cfg != "":
        with open(args.cfg, "r") as f:
            data = yaml.load(f, Loader=yaml.SafeLoader)
        for key in data:
            args.__setattr__(key, data[key])
    logger.debug(args)

    # Model parameters
    hidden_size = args.hidden_size
    m_CS = args.m_CS
    output_size = args.output_size
    irnn = args.irnn

    # Learning parameters
    batch_size = args.batch_size
    lr = args.lr
    lr_step = args.lr_step
    gamma = args.lr_gamma
    epochs = args.epochs
    semi_epoch = epochs // 2
    clip_value = args.clip_value
    clip_norm = args.clip_norm

    # Dataset parameters
    dataset = args.dataset
    task = args.task
    data_dir = args.data_dir
    _, input_size = calc_input_sizes(dataset, task)

    # Log path
    experiment = args.experiment
    tags = args.tags
    log_dir = os.path.join('models/logs', experiment, 'model')
    logger.info("log_dir = %s" % log_dir)

    # Make log directory and save configure yaml file
    if not os.path.isdir(log_dir):
        os.makedirs(os.path.join(log_dir, 'best_acc_wts'))
        os.makedirs(os.path.join(log_dir, 'best_loss_wts'))
    if args.cfg != "":
        cfg_path = os.path.join(log_dir, "config.yaml")
        with open(cfg_path, "w") as cfg:
            yaml.dump(data, cfg)
        artifacts["./" + cfg_path] = "model"
        logger.info("Saved configure yaml.")

    # Prepare dataloader
    train_dl, test_dl = mydataloader(dataset=dataset, task=task, data_dir=data_dir, batch_size=batch_size)
    logger.debug("Datasets are loaded.")

    # Check device
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    if torch.cuda.is_available():
        torch.backends.cudnn.benchmark = True
    logger.debug("GPU or CPU: %s" % device)

    # Train RNN classifier
    if m_CS is None:
        model = classifier_rnn(
            input_size=input_size, hidden_size=hidden_size, num_layers=1, output_size=output_size, irnn=irnn
        ).to(device)
    else:
        model = classifier_rnn_CS(
            input_size=input_size,
            hidden_size=hidden_size,
            m_sharp=m_CS,
            num_layers=1,
            output_size=output_size,
            irnn=irnn,
        ).to(device)
    criterion = nn.CrossEntropyLoss(reduction="sum")
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    if gamma is not None:
        scheduler = torch.optim.lr_scheduler.StepLR(optimizer, lr_step, gamma=gamma)
    else:
        scheduler = None
    logger.debug("--Begin Training--")
    train(
        model,
        criterion,
        optimizer,
        train_dl,
        test_dl,
        epochs=epochs,
        device=device,
        scheduler=scheduler,
        clip_value=clip_value,
        clip_norm=clip_norm,
        semi_epoch=semi_epoch,
        tags=tags,
        artifacts=artifacts,
        experiment=experiment,
    )
    logger.debug("--Finished Training--")

    logger.debug("Done!!")


if __name__ == "__main__":
    main()
