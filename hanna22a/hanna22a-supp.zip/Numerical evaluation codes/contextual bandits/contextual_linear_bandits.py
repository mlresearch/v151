import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
import pickle
from scipy.stats import bernoulli

from dependencies import *
sns.set()

T = int(1e5) # horizon
n_arms = 5 # number of actions
n_features = 20 # dimension of unknown parameter
noise_std = 0.1 # noise standard deviation

confidence_scaling_factor = noise_std

trunc = 10 # truncation for SQ

bits_unif = 3 # number of bits for SQ

n_sim = 10 # average over multiple runs

### mean reward function
a = np.random.randn(n_features)
a /= np.linalg.norm(a, ord=2)
h = lambda x: 1*np.dot(a, x)

print('unquantized:')
bandit = ContextualBandit(T, n_arms, n_features, h, trunc, noise_std=noise_std)

regrets = np.empty((n_sim, T))

for i in range(n_sim):
    bandit.reset_rewards()
    model = LinUCB(bandit,
                   reg_factor=1.0,
                   delta=0.1,
                   confidence_scaling_factor=confidence_scaling_factor,
                  )
    model.run()
    regrets[i] = np.cumsum(model.regrets)

print('proposed:')
bandit = ContextualBandit(T, n_arms, n_features, h, trunc, noise_std=noise_std, quant_type='our')

regrets_our = np.empty((n_sim, T))
bits = np.empty((n_sim, T))

for i in range(n_sim):
    bandit.reset_rewards()
    model = LinUCB(bandit,
                   reg_factor=1.0,
                   delta=0.1,
                   confidence_scaling_factor=confidence_scaling_factor,
                  )
    model.run()
    regrets_our[i] = np.cumsum(model.regrets)
    bits[i] = model.bits

print('SQ:')
std_unif = 2*trunc/(2**bits_unif-1)
bandit = ContextualBandit(T, n_arms, n_features, h, trunc, bits_unif=bits_unif, noise_std=noise_std, quant_type='uniform')

regrets_unif = np.empty((n_sim, T))

for i in range(n_sim):
    bandit.reset_rewards()
    model = LinUCB(bandit,
                   reg_factor=1.0,
                   delta=0.5,
                   confidence_scaling_factor=std_unif,
                  )
    model.run()
    regrets_unif[i] = np.cumsum(model.regrets)

## save variables
vars = {
    'unquant_regret': regrets,
    'regret_proposed': regrets_our,
    'regret_SQ_3': regrets_unif,
    'bits': bits
}
pickle_out = open("context_bandits.pickle","wb")
pickle.dump(vars, pickle_out)
pickle_out.close()

## load variables and plot
vars = pickle.load(open("context_bandits.pickle", "rb"))
regrets = vars['unquant_regret']
regrets_our = vars['regret_proposed']
regrets_unif_3 = vars['regret_SQ_3']
bits = vars['bits']


plt.rcParams.update(plt.rcParamsDefault)
plt.figure(figsize=(12,8))
plt.plot(range(1,regrets.shape[1]+1),np.log10(np.mean(regrets,axis=0)), 's-', color='black', linewidth=2, markevery=5000, label="unquantized LinUCB")
plt.plot(range(1,regrets_unif_3.shape[1]+1),np.log10(np.mean(regrets_unif_3,axis=0)), '--', color='green', linewidth=2, label="$3$-bit SQ LinUCB")
plt.plot(range(1,regrets_our.shape[1]+1),np.log10(np.mean(regrets_our,axis=0)), '*-', linewidth=2, markevery=3000, color='blue', label="QuBan LinUCB")
plt.legend(prop={'size': 36})
plt.xlabel("Iterations",size=30)
plt.ylabel("$\log_{10}$(regret)",size=30)
plt.grid()
plt.rc('xtick', labelsize=20) 
plt.rc('ytick', labelsize=20) 
plt.ticklabel_format(axis="x", style="sci", scilimits=(0,0))
plt.savefig('regrets_LinUCB.pdf', dpi=300)
plt.show()