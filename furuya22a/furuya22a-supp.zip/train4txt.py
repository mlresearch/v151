import argparse
import os

import torch
import torch.nn as nn
import yaml

from src import get_module_logger
from src.data.dataloader4txt import BatchfiedPTB, build_vocab
from src.models.train_model4txt import train
from src.utils.model_rnnlm import RNNLM, RNNLM_CS


def main():
    artifacts = {}

    logger = get_module_logger("train")
    logger.debug("Begin...")
    parser = argparse.ArgumentParser()
    parser.add_argument("--dropout", type=float, default=0.0, help="Dropout ratio.")
    parser.add_argument("--irnn", type=bool, default=False, help="Use IRNN initialization if True.")
    parser.add_argument("--tie_weights", type=bool, default=False, help="Use weight tying if True.")
    parser.add_argument("--embedding_size", type=int, help="")
    parser.add_argument("--hidden_size", type=int, help="")
    parser.add_argument("--m_CS", type=int, default=None, help="Use RNNLM_CS.")
    parser.add_argument("--bptt", type=int, help="")
    parser.add_argument("--lr", type=float, help="")
    parser.add_argument("--epochs", type=int, help="")
    parser.add_argument("--batch_size", type=int, help="")
    parser.add_argument("--eval_batch_size", type=int, help="")
    parser.add_argument("--data_dir", type=str, default="data", help="")
    # parser.add_argument("--log_dir", type=str, default="models/logs/", help="")
    # parser.add_argument("--log_exp", type=str, default="", help="Experiment tag.")
    parser.add_argument("--lr_milestones", type=list, default=None, help="LR-scheduler related.")
    parser.add_argument("--lr_gamma", type=float, default=0.1, help="LR-scheduler related.")
    parser.add_argument("--clip_value", type=float, default=None, help="Gradient clipping related.")
    parser.add_argument("--clip_norm", type=float, default=None, help="Gradient clipping related.")
    parser.add_argument("--experiment", type=str, default=None, help="Experimental name for mlflow.")
    parser.add_argument("--tags", type=dict, default=None, help="Experimental tags to be converted to dictionary type.")
    parser.add_argument("--cfg", type=str, default="", help="Path for configuration file.")
    args = parser.parse_args()
    if args.cfg != "":
        with open(args.cfg, "r") as f:
            data = yaml.load(f, Loader=yaml.SafeLoader)
        for key in data:
            args.__setattr__(key, data[key])
    logger.debug(args)

    # Model parameters
    embedding_size = args.embedding_size
    hidden_size = args.hidden_size
    m_CS = args.m_CS
    dropout = args.dropout
    irnn = args.irnn
    tie_weights = args.tie_weights

    # Learning parameters
    batch_size = args.batch_size
    eval_batch_size = args.eval_batch_size
    lr = args.lr
    # milestones = args.lr_milestones
    # gamma = args.lr_gamma
    epochs = args.epochs
    clip_value = args.clip_value
    clip_norm = args.clip_norm
    bptt = args.bptt

    # Dataset parameters
    # dataset = args.dataset
    data_dir = args.data_dir

    # Log path
    experiment = args.experiment
    tags = args.tags
    log_dir = os.path.join('models/logs', experiment, 'model')
    logger.info("log_dir = %s" % log_dir)

    # Make log directory and save configure yaml file
    if not os.path.isdir(log_dir):
        os.makedirs(os.path.join(log_dir, 'best_wts'))
    if args.cfg != "":
        cfg_path = os.path.join(log_dir, "config.yaml")
        with open(cfg_path, "w") as cfg:
            yaml.dump(data, cfg)
        artifacts["./" + cfg_path] = "model"
        logger.info("Saved configure yaml.")

    # Prepare dataloader
    vocab = build_vocab(data_dir)
    train_ds = BatchfiedPTB(data_dir, "train", vocab, batch_size, bptt)
    train_dl = torch.utils.data.DataLoader(train_ds, batch_size=bptt, shuffle=False)
    val_ds = BatchfiedPTB(data_dir, "valid", vocab, eval_batch_size, bptt)
    val_dl = torch.utils.data.DataLoader(val_ds, batch_size=bptt, shuffle=False)
    logger.debug("Datasets are loaded.")

    # Check device
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    if torch.cuda.is_available():
        torch.backends.cudnn.benchmark = True
    logger.debug("GPU or CPU: %s" % device)

    # Train RNN classifier
    if m_CS is None:
        model = RNNLM(
            ntoken=len(vocab),
            d_model=embedding_size,
            d_hid=hidden_size,
            dropout=dropout,
            irnn=irnn,
            tie_weights=tie_weights,
        ).to(device)
    else:
        model = RNNLM_CS(
            ntoken=len(vocab),
            d_model=embedding_size,
            d_hid=hidden_size,
            m_sharp=m_CS,
            dropout=dropout,
            irnn=irnn,
            tie_weights=tie_weights,
        ).to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.SGD(model.parameters(), lr=lr)
    #     optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, 1.0, gamma=0.95)
    #     if milestones is not None:
    #         scheduler = torch.optim.lr_scheduler.MultiStepLR(optimizer, milestones=milestones, gamma=gamma)
    #     else:
    #         scheduler = None
    logger.debug("--Begin Training--")
    train(
        model,
        criterion,
        optimizer,
        train_dl,
        val_dl,
        epochs=epochs,
        device=device,
        scheduler=scheduler,
        clip_value=clip_value,
        clip_norm=clip_norm,
        tags=tags,
        artifacts=artifacts,
        experiment=experiment,
    )
    logger.debug("--Finished Training--")

    logger.debug("Done!!")


if __name__ == "__main__":
    main()
