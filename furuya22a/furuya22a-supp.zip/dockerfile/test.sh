#!/bin/bash
set -e

python3 --version
nvidia-smi

pip check

python3 -c "import torch;torch.__version__"
python3 -c "import torchvision;torchvision.__version__"
python3 -c "import torchtext;torchtext.__version__"
python3 -c "import numpy;numpy.__version__"
python3 -c "import matplotlib;matplotlib.__version__"
python3 -c "import yaml;yaml.__version__"
python3 -c "import torch; torch.cuda.is_available()"
