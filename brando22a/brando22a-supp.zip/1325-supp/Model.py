## Copyright 2022
##
## Licensed under the Apache License, Version 2.0 (the "License");
## you may not use this file except in compliance with the License.
## You may obtain a copy of the License at
##
##    http://www.apache.org/licenses/LICENSE-2.0
##
## Unless required by applicable law or agreed to in writing, software
## distributed under the License is distributed on an "AS IS" BASIS,
## WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
## See the License for the specific language governing permissions and
## limitations under the License.

import tensorflow as tf
from tensorflow.keras import backend as K
from tensorflow import keras
from tensorflow.keras.models import Sequential, Model
from tensorflow.keras.layers import Dense
from tensorflow.keras.layers import Lambda
from tensorflow.keras.layers import concatenate
from tensorflow.keras.layers import Flatten
from tensorflow.keras.optimizers import RMSprop, Adam
import numpy as np

general_type = 'float64'
tf.keras.backend.set_floatx(general_type)

class Model(tf.keras.Model):
    def __init__(self, degree=15., K='q0', arch=[300,300,300], K_arch=[160,10]):
        super(Model, self).__init__(name='Model')
        self.degree = np.array(degree).astype(general_type.replace('float', 'int'))
        self.architecture = []
        for hn in arch:
            self.architecture += [tf.keras.layers.Dense(hn, activation=tf.keras.activations.relu)]   
        self.architecture += [
            tf.keras.layers.Dense(self.degree, 
                                  activation=lambda x: 1e-6 + tf.keras.activations.softplus(x + 1e-6))]
        self.K_architecture = []
        for hn in K_arch:
            self.K_architecture += [tf.keras.layers.Dense(hn, activation=tf.keras.activations.relu)]
        self.K_architecture += [tf.keras.layers.Dense(1, activation=None)]
        if K in ['q0', 'Mean']:
            self.K = K
        else:
            raise Exception(
                "The definition of the K is invalid. Use 'q0' or 'Mean'.")

    def _cheb_cs(self, inputs):

        K_output = inputs
        for layer in self.K_architecture:
            K_output = layer(K_output)
        K_output = tf.keras.backend.flatten(K_output)
        self.K_output = K_output
        
        output_x = inputs
        for layer in self.architecture:
            output_x = layer(output_x)
            
        self.output_x = output_x

        c_js = tf.signal.dct(tf.keras.backend.reshape(output_x, shape=(-1, self.degree)),
                             type=2,
                             norm=None) / self.degree
        C_is = tf.map_fn(fn=lambda i: (c_js[:, i - 1] - c_js[:, i + 1]) /
                         (4 * tf.cast(i, dtype=general_type)),
                         elems=tf.range(
                             1,
                             tf.cast(self.degree - 1,
                                     dtype=general_type.replace(
                                         'float', 'int'))),
                         dtype=general_type)
        C_is = tf.concat((C_is, [
            tf.cast(0.25 * c_js[:, -2] / (self.degree - 1), dtype=general_type)
        ]),
                         axis=0)

        if self.K == 'q0':
            C_is = tf.concat(
                (2 * tf.reshape(K_output, (1, -1)) +
                 tf.reduce_sum(C_is * ((
                     (tf.reshape(tf.range(self.degree - 1, dtype=general_type),
                                 (-1, 1)) % -2) * 4) + 2),
                               axis=0,
                               keepdims=True), C_is),
                axis=0)
        elif self.K == 'Mean':
            C_is = tf.concat(
                (2 * tf.reshape(K_output, (1, -1)) -
                 2 * tf.reduce_sum(C_is[1::2, :] * tf.reshape(
                     tf.map_fn(fn=lambda k: 1. / (k**2 - 4),
                               elems=tf.range(
                                   1, self.degree - 1, 2, dtype=general_type),
                               dtype=general_type,
                               fn_output_signature=general_type), (-1, 1)),
                                   axis=0,
                                   keepdims=True), C_is),
                axis=0)

        C_is = tf.transpose(C_is, (1, 0))
        return C_is, c_js, self.K_output

    def _eval_cheb(self, taus, n_taus, cs):
        xs = tf.reshape((taus * 2) - 1., shape=(-1, n_taus))
        d1 = 0.
        d2 = 0.
        d3 = 0.
        for j in range(self.degree - 1, 0, -1):
            d3 = d1
            d1 = 2 * xs * d1 - d2 + tf.keras.backend.reshape(cs[:, j], shape=(-1, 1))
            d2 = d3
        F = xs * d1 - d2 + 0.5 * tf.keras.backend.reshape(cs[:, 0],
                                           shape=(-1, 1))
        output = tf.keras.layers.concatenate([tf.reshape(F, (-1, 1)), taus],
                                             axis=-1,
                                             name="training_output")
        return output

    def call(self, inputs, n_taus=100):

        self.n_taus = n_taus
        C_is, _, K = self._cheb_cs(inputs)
        gen_tau = tf.random.uniform(shape=[
            tf.shape(inputs, out_type=tf.keras.backend.floatx().replace('float', 'int'))[0] *
            self.n_taus, 1
        ],
                                    minval=0. + 1e-2,
                                    maxval=1. - 1e-2,
                                    dtype=general_type)

        output = self._eval_cheb(gen_tau, self.n_taus, C_is)
        output = tf.reshape(output, (-1, 2))
        return output

    def forecast(self, inputs, input_tau):
        C_is, _, _ = self._cheb_cs(inputs)
        sel_tau = tf.reshape(
            tf.transpose(tf.keras.backend.repeat(
                tf.reshape(input_tau, [-1, 1]),
                tf.shape(inputs)[0]),
                         perm=(1, 0, 2)), (-1, 1))
        output = self._eval_cheb(sel_tau, tf.shape(input_tau)[0], C_is)
        return output


def qr(y_true, parameters, general_type=general_type, n_taus=None):
    assert n_taus is not None
    components = tf.keras.backend.reshape(parameters, [-1, n_taus, 2])
    mu = components[:, :, :-1]
    tau = components[:, :, -1:]
    y = tf.keras.backend.reshape(y_true, [-1, 1, 1])
    error = y - mu
    sums = tf.keras.backend.maximum(tau * (error), (tau - 1.) * (error))
    return tf.keras.backend.mean(tf.keras.backend.sum(sums, axis=[2]), axis=[0, 1])


def evaluate_qr(y_true, parameters, general_type=general_type, n_taus=None):
    assert n_taus is not None
    components = tf.keras.backend.reshape(parameters, [-1, n_taus, 2])
    mu = components[:, :, :-1]
    tau = components[:, :, -1:]
    y = tf.keras.backend.reshape(y_true, [-1, 1, 1])
    error = y - mu
    sums = tf.keras.backend.maximum(tau * (error), (tau - 1.) * (error))
    res = tf.keras.backend.sum(sums, axis=[1,2])
    return res