#include<iostream>
#include<stdlib.h>
#include<time.h>
#include<cstdio>
#include<cmath>
#include<set>
#include<vector>

using namespace std;

const double p = 1.9;//1.1 1.5 1.9
const double alpha = p + 0.05;//1.55 1.95
const double v = p - 1;
const double epsilon = 20; // 5 10 20 (LDP)
//const double epsilon = 1.0;// 0.5 1.0 (DP)
const int K = 5;
const double Up = 0.9;
const double Lo = 0.1;
const double u = alpha * pow((alpha - 1) * Up / alpha, p) / (alpha - p);
//const int T = (int) 1e6; //DP S1
//const int T = (int) 5e5; //DP S2
//const int T = (int) 5e6; //DP S3
const int T = (int) 1.5e7; //LDP S3
const double beta = 0.001;
const int test_time = 90;

double avg[T];
double s1[T];
double s2[T];

int sign(double x)
{
	if (x > 1e-8) return 1;
	if (x < -1e-8) return -1;
	return 0;
}

double Lap(double b)
{
	double noise;
	double uni;
	int num = rand();
	if (num == 0) num++;
	else if (num == RAND_MAX) num--;
	uni = num / double(RAND_MAX);
	noise = b * sign(uni - 0.5) * log(1 - 2 * fabs(uni - 0.5));
	return noise;
}

double phifunc(double x)
{
	double res = 0;
	double bp = pow(2.0 * pow((2.0 - p) / (p - 1.0), 1.0 - 2.0 / p) + pow((2.0 - p) / (p - 1.0), 2.0 - 2.0 / p), -p / 2.0);
	if (x >= 0)
	{
		res = log(bp * pow(fabs(x), p) + x + 1);
	}
	else
		res = -log(bp * pow(fabs(x), p) - x + 1);
	return res;
}

class Arm
{
public:
	double mean;
	double lambda;

	Arm()
	{
		mean = 0;
		lambda = 0;
	}
	Arm(double mu)
	{
		mean = mu;
		lambda = (alpha - 1.0) * mu / alpha;
	}
	double pull(void)
	{
		double reward;
		double uni;
		int num = rand();
		uni = (double)num / (double(RAND_MAX));
		//cout << "uni=" << uni << " lambda=" << lambda << " alpha=" << alpha;
		reward = lambda * pow(1.0 - uni, -1.0 / alpha);
		//cout << " reward=" << reward << endl;
		return reward;
	}
};

class Tree
{
public:
	int t;
	double psum[50];
	double npsum[50];
	Tree()
	{
		t = 0;
		for (int i = 0; i < 50; i++) psum[i] = 0;
		for (int i = 0; i < 50; i++) npsum[i] = 0;
	}
	void insert(double x, double B)
	{
		++t;
		int i = (int)(log(t & (-t))/log(2));
		psum[i] = x;
		for (int j = 0; j < i; j++)
		{
			psum[i] += psum[j];
		}
		for (int j = 0; j < i; j++)
		{
			psum[j] = 0;
			npsum[j] = 0;
		}
		npsum[i] = psum[i] + Lap(2 * B * log(T) / epsilon);
	}
	double sum()
	{
		double s = 0;
		for (int j = 0; j < (int)(log(t)/log(2)) + 1; j++)
		{
			s += npsum[j];
		}
		return s;
	}
};

Arm a[K];

void DPRUCB(void)
{
	double regret = 0;
	int n[K];
	Tree tr[K];
	for (int i = 0; i < K; i++) n[i] = 0;
	for (int t = 0; t < K; t++)
	{
		n[t]++;
		double sample = a[t].pull();
		//cout << "sample[" << t << "]=" << sample << endl;
		regret += Up - a[t].mean;
		//cout << "regret[" << t << "]=" << regret << endl;
		//fprintf(f, "%lf\n", regret);
		avg[t] += regret / test_time;
		s1[t] += regret;
		s2[t] += pow(regret, 2);
		double B = pow(epsilon * u * n[t] / pow(log(T), 1.5), 1 / (1 + v));
		//cout << "B= " << B << endl;
		if (fabs(sample) > B) sample = 0;
		tr[t].insert(sample, B);
	}
	for (int t = K; t < T; t++)
	{
		double S[K];
		double maxs = 0;
		int maxi = 0;
		for (int i = 0; i < K; i++)
		{
			S[i] = tr[i].sum();
			//cout << "S[" << i << "]=" << S[i] << " ";
			double ucb = S[i] / (int)n[i] + 0.425 * pow(u, 1 / (1 + v)) * pow(log(2 * pow(t + 1, 4)) * pow(log(T), 1.5 + 1 / v) / (n[i] * epsilon), v / (1 + v));
			//cout << "ucb[" << i << "]=" << ucb << " ";
			if (ucb> maxs)
			{

				maxs = ucb;
				maxi = i;
			}
		}
		//cout << maxi << endl;
		++n[maxi];
		double sample = a[maxi].pull();
		//cout << "sample[" << maxi << "]=" << sample << endl;
		regret += Up - a[maxi].mean;
		//cout << "regret[" << t << "]=" << regret << endl;
		//fprintf(f, "%lf\n", regret);
		avg[t] += regret / test_time;
		s1[t] += regret;
		s2[t] += regret * regret;
		double B = pow(epsilon * u * n[maxi] / pow(log(T), 1.5), 1 / (1 + v));
		//cout << "B= " << B << endl;
		if (sample > B) sample = 0;
		tr[maxi].insert(sample, B);
		if (t % 10000 == 0) cout << "regret[" << t << "]=" << regret << " ratio: "<< regret/t << " maxi: " << maxi << endl;
	}
	cout << "DPRUCB final regret: " << regret << endl;
}

void DPSE()
{
	set<int> S;
	for (int i = 0; i < K; i++) S.insert(i);
	double regret = 0.0;
	int t = 0, ep = 0;
	do
	{
		if (t >= T) break;
		ep++;
		cout << "ep=" << ep << endl;
		set<int>::iterator iter;
		
		for (iter = S.begin(); iter != S.end(); iter++) cout << *iter << ' ';
		cout << endl;
		
		double mubar[K];
		for (iter = S.begin(); iter != S.end(); iter++) mubar[*iter] = 0;
		int r = 0;
		double De = pow(2, -ep);
		int SS = S.size();
		long long Re = (long long)(0.85 * (pow(u, 1 / v) * log(4.0 * SS * pow(ep, 2) / beta) / (epsilon * pow(De, (1 + v) / v)) + 1));
		cout << "Re=" << Re << endl;
		double Be = pow(u * Re * epsilon / log(4.0 * SS * pow(ep, 2) / beta), 1 / (1 + v));
		cout << "Be=" << Be << endl;
		while (r < Re)
		{
			if (t >= T) break;
			r++;
			for (iter = S.begin(); iter != S.end(); iter++)
			{
				if (t >= T) break;
				t++;
				regret += Up - a[*iter].mean;
				//cout << regret << endl;
				//fprintf(f, "%lf\n", regret);
				avg[t - 1] += regret / test_time;
				s1[t - 1] += regret;
				s2[t - 1] += pow(regret, 2);
				double sample = a[*iter].pull();
				if (fabs(sample) > Be) sample = 0;
				mubar[*iter] = (mubar[*iter] * ((double)r - 1.0) + sample) / (double)r;
			}
		}
		double err = pow(u, 1 / (1 + v)) * pow(log(4.0 * SS * pow(ep, 2) / beta) / (Re * epsilon), v / (1 + v));

		for (iter = S.begin(); iter != S.end(); iter++)
		{
			cout << mubar[*iter] << " ";
		}
		cout << endl;

		for (iter = S.begin(); iter != S.end(); iter++)
		{
			mubar[*iter] += Lap(2 * Be / (Re * epsilon));
		}

		for (iter = S.begin(); iter != S.end(); iter++)
		{
			cout << mubar[*iter] << " ";
		}
		cout << endl;

		double maxmu = 0;
		for (iter = S.begin(); iter != S.end(); iter++)
		{
			if (mubar[*iter] > maxmu)
			{
				maxmu = mubar[*iter];
			}
		}
		cout << "maxmu=" << maxmu << " err=" << 0.66 * err << endl;
		for (iter = S.begin(); iter != S.end();)
		{
			if (maxmu - mubar[*iter] > 0.66 * err)
			{
				S.erase(iter++);
			}
			else ++iter;
		}
	} while (S.size() > 1);
	int opt = *S.begin();
	if (t < T)
	{
		for (int i = t; i < T ; i++)
		{
			regret += Up - a[opt].mean;
			//fprintf(f, "%lf\n", regret);
			avg[i] += regret / test_time;
			s1[i] += regret;
			s2[i] += pow(regret, 2);
		}
	}
	cout << "DPSE final regret: " << regret << endl;
	cout << "optimal arm: " << opt << endl;
	cout << "sample time: " << t << endl;
}

void LDPSE()
{
	set<int> S;
	for (int i = 0; i < K; i++) S.insert(i);
	double regret = 0;
	int t = 0, ep = 0;
	do
	{
		if (t >= T) break;
		ep++;
		cout << "ep=" << ep << endl;
		set<int>::iterator iter;
		for (iter = S.begin(); iter != S.end(); iter++) cout << *iter << ' ';
		cout << endl;
		double mubar[K];
		for (iter = S.begin(); iter != S.end(); iter++) mubar[*iter] = 0;
		int r = 0;
		double De = pow(4, -ep);
		int SS = S.size();
		long long Re = (long long)(0.000180 * (pow(u, 2 / v) * log(8.0 * SS * ep * ep / beta) / (epsilon * epsilon * pow(De * De, (1 + v) / v)) + log(8 * SS * ep * ep / beta)));
		cout << "Re=" << Re << endl;
		double Be = pow(u * sqrt(Re) * epsilon / sqrt(log(8.0 * SS * pow(ep, 2)/ beta)), 1 / (1 + v));
		cout << "Be=" << Be << endl;
		while (r < Re)
		{
			if (t >= T) break;
			r++;
			for (iter = S.begin(); iter != S.end(); iter++)
			{
				if (t >= T) break;
				t++;
				regret += Up - a[*iter].mean;
				//cout << regret << endl;
				//fprintf(f, "%lf\n", regret);
				avg[t - 1] += regret / test_time;
				s1[t - 1] += regret;
				s2[t - 1] += pow(regret, 2);
				double sample = a[*iter].pull();
				if (fabs(sample) > Be) sample = 0;
				sample += Lap(2 * Be / epsilon);
				mubar[*iter] = (mubar[*iter] * (r - 1) + sample) / (double)r;
			}
		}
		//cout << "regret: " << regret << endl;
		double err = pow(u, 1 / (1 + v)) * pow(sqrt(log(8.0 * SS * ep * ep / beta)) / (Re * epsilon), v / (1 + v));
		for (iter = S.begin(); iter != S.end(); iter++)
		{
			cout << mubar[*iter] << " ";
		}
		cout << endl;

		double maxmu = 0;
		for (iter = S.begin(); iter != S.end(); iter++)
		{
			if (mubar[*iter] > maxmu) maxmu = mubar[*iter];
		}

		cout << "maxmu=" << maxmu << " err=" << 3 * err << endl;
		for (iter = S.begin(); iter != S.end();)
		{
			if (maxmu - mubar[*iter] > 3 * err) S.erase(iter++);
			else ++iter;
		}
	} while (S.size() > 1);
	int opt = *S.begin();
	if (t < T)
	{
		for (int i = t; i < T; i++)
		{
			regret += Up - a[opt].mean;
			//fprintf(f, "%lf\n", regret);
			avg[i] += regret / test_time;
			s1[i] += regret;
			s2[i] += pow(regret, 2);
		}
	}
	cout << "LDPSE final regret: " << regret << endl;
	cout << "optimal arm: " << opt << endl;
	cout << "sample time: " << t << endl;
}

int main()
{
	srand((unsigned)time(NULL));
	//srand(0);
	cout << "u=" << u << endl;
	for (int i = 0; i < K; i++)
	{
		//a[i] = Arm((Lo - Up) / (K - 1) * i + Up);//set 1
		//a[i] = Arm((Up - Lo) / pow(1 - K, 2) * pow(i + 1 - K, 2) + Lo);//set 2
		a[i] = Arm((Lo - Up) / pow(K - 1, 2) * pow(i, 2) + Up);//set 3
	}
	for (int i = 0; i < K; i++)
	{
		cout << a[i].mean << ' ';
	}
	cout << endl;


	//DPRUCB(f);
	/*for (int i = 0; i < T; i++)
	{
		avg[i] = 0.0;
		s1[i] = 0.0;
		s2[i] = 0.0;
	}
	for (int i = 0; i < test_time; i++)
	{
		cout << "DPRUCB_test " << i+1 << endl;
		DPRUCB();
	}
	char c1[30];
	c1[0] = '\0';
	sprintf(c1, "DPRUCB_%.1lf_%.1lf_.txt", v, epsilon);
	FILE* f1 = fopen(c1, "w");
	for (int i = 0; i < T; i++)
	{
		fprintf(f1, "%lf %lf\n", avg[i], sqrt(fabs(s2[i] - pow(s1[i], 2) / test_time) / (test_time - 1)));
	}
	cout << "DPRUCB_AVG: " << avg[T - 1] << " Standard Deviation: " << sqrt(fabs(s2[T - 1] - pow(s1[T - 1], 2) / test_time) / (test_time - 1)) << endl;
	fclose(f1);

	//DPRSE(f);
	for (int i = 0; i < T; i++)
	{
		avg[i] = 0.0;
		s1[i] = 0.0;
		s2[i] = 0.0;
	}
	for (int i = 0; i < test_time; i++)
	{
		cout << "DPSE_test "<< i+1 << endl;
		DPSE();
	}
	char c2[30];
	c2[0] = '\0';
	sprintf(c2, "DPRSE_%.1lf_%.1lf_.txt", v, epsilon);
	FILE* f2 = fopen(c2, "w");
	for (int i = 0; i < T; i++)
	{
		fprintf(f2, "%lf %lf\n", avg[i], sqrt(fabs(s2[i] - pow(s1[i], 2) / test_time) / (test_time - 1)));
	}
	cout << "DPSE_AVG: " << avg[T - 1] << " Standard Deviation: " << sqrt((s2[T - 1] - pow(s1[T - 1], 2) / test_time) / (test_time - 1)) << endl;
	fclose(f2);*/

	//LDPRSE(f);
	for (int i = 0; i < T; i++)
	{
		avg[i] = 0.0;
		s1[i] = 0.0;
		s2[i] = 0.0;
	}
	for (int i = 0; i < test_time; i++)
	{
		cout << "LDPSE_test " << i+1 << endl;
		LDPSE();
	}
	char c3[30];
	c3[0] = '\0';
	sprintf(c3, "LDPRSE_%.1lf_%.1lf_.txt", v, epsilon);
	FILE* f3 = fopen(c3, "w");
	for (int i = 0; i < T; i++)
	{
		fprintf(f3, "%lf %lf\n", avg[i], sqrt(fabs(s2[i] - pow(s1[i], 2) / test_time) / (test_time - 1)));
	}
	cout << "LDPSE_AVG: " << avg[T - 1] << " Standard Deviation: " << sqrt((s2[T - 1] - pow(s1[T - 1], 2) / test_time) / (test_time - 1)) << endl;
	fclose(f3);

}