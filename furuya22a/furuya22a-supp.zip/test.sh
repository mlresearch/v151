#!/bin/bash

test_train4img() {
    python train4img.py --cfg models/configure/test_aistats4img/seqMNIST.yaml
    python train4img.py --cfg models/configure/test_aistats4img/wholeMNIST.yaml
    python train4img.py --cfg models/configure/test_aistats4img/pixMNIST.yaml
    python train4img.py --cfg models/configure/test_aistats4img/pixFMNIST.yaml
    python train4img.py --cfg models/configure/test_aistats4img/pixCIFAR.yaml
    python train4img.py --cfg models/configure/test_aistats4img/pixMNIST-non-irnn.yaml
    python train4img.py --cfg models/configure/test_aistats4img/pixMNIST-CS.yaml
}

test_train4txt() {
    python train4txt.py --cfg models/configure/test_aistats4txt/PTB_128.yaml
    python train4txt.py --cfg models/configure/test_aistats4txt/PTB_128-irnn.yaml  # ill-condition
    python train4txt.py --cfg models/configure/test_aistats4txt/PTB_128-untie.yaml
    python train4txt.py --cfg models/configure/test_aistats4txt/PTB_128-CS.yaml
}


test_predict(){
    python predict4img.py \
        --wts_path models/logs/pixMNIST/model/best_acc_wts/state_dict.pth
    python predict4img.py \
        --wts_path models/logs/pixMNIST-CS/model/best_acc_wts/state_dict.pth
    python predict4txt.py \
        --wts_path models/logs/PTB/model/best_wts/state_dict.pth
    python predict4txt.py \
        --wts_path models/logs/PTB-CS/model/best_wts/state_dict.pth
}

test_sp(){
    python SP4img.py \
        --wts_path models/logs/pixMNIST/model/best_acc_wts/state_dict.pth \
        --m 42
    python SP4txt.py \
        --wts_path models/logs/PTB/model/best_wts/state_dict.pth \
        --m 42
}

test_prune(){
    python prune4img.py \
        --wts_path models/logs/pixMNIST/model/best_acc_wts/state_dict.pth \
        --m 42
    python prune4txt.py \
        --wts_path models/logs/PTB/model/best_wts/state_dict.pth \
        --m 42
}

test_ft() {
    python FT4img.py \
        --wts_path models/logs/pixMNIST/model/best_acc_wts/wts_pruned.pth \
        --m 42 \
        --lr_decay 2.0 \
        --epochs 2 \
        --non_structured_pruned False \
        --experiment ft-pixMNIST
    python FT4img.py \
        --wts_path models/logs/pixMNIST/model/best_acc_wts/wts_magnitude_weight_pruned.pth \
        --m 42 \
        --lr_decay 2.0 \
        --epochs 2 \
        --non_structured_pruned True \
        --experiment ft-pixMNIST-mag
    python FT4txt.py \
        --wts_path models/logs/PTB/model/best_wts/wts_pruned.pth \
        --m 42 \
        --lr_decay 2.0 \
        --non_structured_pruned False \
        --experiment ft-PTB
    python FT4txt.py \
        --wts_path models/logs/PTB/model/best_wts/wts_magnitude_weight_pruned.pth \
        --m 42 \
        --lr_decay 2.0 \
        --non_structured_pruned True \
        --experiment ft-PTB-mag
    python FT4txt.py \
        --wts_path models/logs/PTB/model/best_wts/wts_magnitude_weight_pruned_over.pth \
        --m 42 \
        --lr_decay 2.0 \
        --non_structured_pruned True \
        --prune_over True \
        --experiment ft-PTB-over
}

test_echo1() {
    echo Begin the test.
}

test_echo2() {
    echo End the test.
}

test_echo1
test_train4img
test_train4txt
test_predict
test_sp
test_prune
test_ft
test_echo2
