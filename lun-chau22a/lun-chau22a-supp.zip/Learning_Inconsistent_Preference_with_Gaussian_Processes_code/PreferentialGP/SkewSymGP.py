import numpy as np
import gpytorch
from gpytorch.kernels import RBFKernel
import torch
from PreferentialGP.skew_symmetric_kernel import SkewKernel
from numpy.linalg import inv
from PreferentialGP.utility import Conjugate_GD
import os
os.environ['KMP_DUPLICATE_LIB_OK']='True'



##################
# Latest Version #
##################
"""
The latest version of SSGP (SkewSymGP) allows one to use conjugate gradient descent
to speed up the computation. (Could potentially uses the Batch CG suggested in the GPytorch
paper later)
"""

class SSGP(torch.nn.Module):
    """
    Rewriting SkewSymGP in pytorch format for easier optimisation
    """

    def __init__(self, comp_ls, y_ls, phi):
        super().__init__()

        self.comp_ls = comp_ls
        self.y_ls = y_ls
        self.phi = phi
        self.kernel = RBFKernel(ard_num_dims=phi.shape[1])
        self.kernel.lengthscale = torch.tensor([2. for i in range(phi.shape[1])])
        self.f = torch.nn.Parameter(torch.randn(len(comp_ls), 1, requires_grad=True))
        self.T = None
        self.T_inv = None
        self.K = None

    def forward(self):

        K = self.kernel(torch.tensor(self.phi)).evaluate()
        self.K = K

        m = len(self.comp_ls)
        T = torch.zeros((m, m), requires_grad=False)

        for i in range(m):
            for j in range(i, m):
                x1, x2 = self.comp_ls[i]
                l1, l2 = self.comp_ls[j]

                T[i, j] = K[x1, l1] * K[x2, l2] - K[x1, l2] * K[x2, l1]
                T[j, i] = T[i, j]

        self.T = T
        self.T_free = T.detach()


def fit_sskernel(K, comp_ls):
    m = len(comp_ls)
    T = torch.zeros((m, m), requires_grad=False)

    for i in range(m):
        for j in range(i, m):
            x1, x2 = comp_ls[i]
            l1, l2 = comp_ls[j]

            T[i, j] = K[x1, l1] * K[x2, l2] - K[x1, l2] * K[x2, l1]
            T[j, i] = T[i, j]

    return T


def ssgp_predict(ssgp, new_comp_ls, num_rounds):
    """
    Args:
        ssgp: The trained SSGP object with f_map computed previously
        new_comp_ls: new competition list to do prediction

    Returns:
        the predicted f_map
    """
    complete_ls = ssgp.comp_ls + new_comp_ls
    Tn = fit_sskernel(ssgp.K, complete_ls)
    Tno = Tn[len(ssgp.comp_ls):, 0:len(ssgp.comp_ls)]
    # Tnn = Tn[len(ssgp.comp_ls):, len(ssgp.comp_ls):]
    # Too = Tn[:len(ssgp.comp_ls), :len(ssgp.comp_ls)]

    Too_invf = Conjugate_GD(ssgp.T_free, ssgp.f, num_rounds=num_rounds)

    return Tno @ Too_invf

# Loss function to minimise


def CG_GaussianLoglikelihood(f, T, y_tensor, num_rounds=50):
    """
    Loss function to optimise for f, uses CG.
    """
    sigma = torch.nn.Sigmoid()
    K_invf = Conjugate_GD(T, f, num_rounds=num_rounds)

    L = 0.5 * f.t() @ K_invf - torch.sum(torch.log(sigma(y_tensor * f)))

    return L


def CG_approx_Marginal_log_likelihood(f, T, y_tensor, num_rounds=50):
    sigma = torch.nn.Sigmoid()

    w_elements = (sigma(f) * sigma(-f)).reshape(1, -1)[0]
    W_half = torch.diag(w_elements ** (1 / 2))
    B = torch.eye(T.shape[0]) + W_half @ T @ W_half
    eig_vals, e_vecs = torch.symeig(B, eigenvectors=True)

    # likelihood = torch.sum(torch.log(sigma(y_tensor * f))).detach().numpy()

    mll = 0.5 * f.t() @ Conjugate_GD(T, f, num_rounds=num_rounds) - torch.sum(torch.log(sigma(y_tensor * f))) + 0.5 * torch.log(
        torch.prod(eig_vals))

    return mll


###############
# Old Version #
###############


class skewsymGaussianProcess(object):
    """
    To calculate the skewsymmetric GP for preferential learning
    using Laplace Method. We will fix the kernel for now.

    Inputs:
        - comp_ls: The list containing the matches
        - y_ls: The result
        - features: phi
    """

    def __init__(self, comp_ls, y_ls, phi):

       self.comp_ls = comp_ls
       self.y_ls = y_ls
       self.phi = phi

    def fit(self, epoch=300, lr=1e-2):

        # Turn the features into tensors and compute the kernel
        features = torch.tensor(self.phi)
        self.features = features
        sk = SkewKernel(self.comp_ls, features, 'rbf')
        T = sk.fit_kernel()

        # Add in some jitter for numerical stability
        jitter = torch.diag(torch.tensor([1 for i in range(T.shape[0])]))*1e-2

        # Matrix inversion with numpy is more stable than torch
        T_adj = T + jitter
        T_inv = torch.tensor(inv(T_adj.detach().numpy()))
        self.T_inv = T_inv

        # Set up the GP model
        y_tensor = torch.tensor(self.y_ls).reshape(-1, 1)
        sigma = torch.nn.Sigmoid()

        p = T_inv.shape[0]
        f = torch.randn(p, 1, requires_grad=True)

        for rd in range(epoch):
            L = f.t() @ T_inv @ f - torch.sum(torch.log(sigma(y_tensor * f)))
            L.backward()

            with torch.no_grad():
                f -= f.grad * lr
                f.grad.zero_()

        f_map = f.detach()
        self.posterior_mean = f_map
        D = torch.diag((sigma(f_map)*sigma(-f_map)).reshape(1, -1)[0])
        self.D = D
        T_invD___inv = torch.inverse(T_inv + D) + jitter
        self.posterior_var = T_invD___inv
        f_bar_y = gpytorch.distributions.MultivariateNormal(f_map.reshape(1, -1)[0], T_invD___inv)

        self.posterior = f_bar_y

    def pred(self, new_comp_ls):

        # With new data comes in, we will create a new kernel matrix T_new
        complete_ls = self.comp_ls + new_comp_ls
        sk = SkewKernel(complete_ls, self.features, 'rbf')
        Tn = sk.fit_kernel()
        Tno = Tn[len(self.comp_ls):, 0:len(self.comp_ls)]
        Tnn = Tn[len(self.comp_ls):, len(self.comp_ls):]
        Too = Tn[:len(self.comp_ls), :len(self.comp_ls)]
        D = self.D

        jitter_oo = torch.diag(torch.tensor([1 for i in range(Too.shape[0])]))*1e-2
        jitter_nn = torch.diag(torch.tensor([1 for i in range(Tnn.shape[0])]))*1e-2

        test_mean = Tno@self.T_inv@self.posterior_mean
        test_var = Tnn - Tno@torch.inverse(Too + torch.inverse(D) + jitter_oo) @ Tno.t() + jitter_nn

        f_prime_bar_y = gpytorch.distributions.MultivariateNormal(test_mean, test_var)

        self.test_posterior = f_prime_bar_y
        self.test_posterior_mean = test_mean
        sigma = torch.nn.Sigmoid()
        self.test_prediction = sigma(self.test_posterior_mean)


class skewsymGaussianProcess_Cuda(object):
    """
    To calculate the skewsymmetric GP for preferential learning
    using Laplace Method. We will fix the kernel for now.

    Inputs:
        - comp_ls: The list containing the matches
        - y_ls: The result
        - features: phi
    """

    def __init__(self, comp_ls, y_ls, phi):

       self.comp_ls = comp_ls
       self.y_ls = y_ls
       self.phi = phi

    def fit(self, epoch=300, lr=1e-2):

        # Turn the features into tensors and compute the kernel
        features = torch.tensor(self.phi).cuda()
        self.features = features
        sk = SkewKernel(self.comp_ls, features, 'rbf', cuda=True)
        T = sk.fit_kernel()

        # Add in some jitter for numerical stability
        jitter = (torch.diag(torch.tensor([1 for i in range(T.shape[0])]))*1e-2).cuda()

        # Matrix inversion with numpy is more stable than torch
        T_adj = T + jitter
        T_inv = torch.tensor(inv(T_adj.cpu().detach().numpy())).cuda()
        self.T_inv = T_inv

        # Set up the GP model
        y_tensor = torch.tensor(self.y_ls).reshape(-1, 1).cuda()
        sigma = torch.nn.Sigmoid()

        p = T_inv.shape[0]
        f = torch.randn(p, 1, requires_grad=True, device="cuda:0")

        for rd in range(epoch):
            L = f.t() @ T_inv @ f - torch.sum(torch.log(sigma(y_tensor * f)))
            L.backward()
            with torch.no_grad():
                f -= f.grad * lr
                f.grad.zero_()

        f_map = f.detach()
        self.posterior_mean = f_map
        D = torch.diag((sigma(f_map)*sigma(-f_map)).reshape(1, -1)[0]).cuda()
        self.D = D
        T_invD___inv = torch.inverse(T_inv + D) + jitter
        self.posterior_var = T_invD___inv
        f_bar_y = gpytorch.distributions.MultivariateNormal(f_map.reshape(1, -1)[0], T_invD___inv)

        self.posterior = f_bar_y

    def pred(self, new_comp_ls):

        # With new data comes in, we will create a new kernel matrix T_new
        complete_ls = self.comp_ls + new_comp_ls
        sk = SkewKernel(complete_ls, self.features, 'rbf')
        Tn = sk.fit_kernel()
        Tno = Tn[len(self.comp_ls):, 0:len(self.comp_ls)]
        Tnn = Tn[len(self.comp_ls):, len(self.comp_ls):]
        Too = Tn[:len(self.comp_ls), :len(self.comp_ls)]
        D = self.D

        jitter_oo = torch.diag(torch.tensor([1 for i in range(Too.shape[0])]))*1e-2
        jitter_nn = torch.diag(torch.tensor([1 for i in range(Tnn.shape[0])]))*1e-2

        test_mean = Tno@self.T_inv@self.posterior_mean
        test_var = Tnn - Tno@torch.inverse(Too + torch.inverse(D) + jitter_oo) @ Tno.t() + jitter_nn

        f_prime_bar_y = gpytorch.distributions.MultivariateNormal(test_mean, test_var)

        self.test_posterior = f_prime_bar_y
        self.test_posterior_mean = test_mean
