import numpy as np
from numpy import linalg as LA
from scipy.optimize import minimize


class Agent:
    '''
    Agent class with a true utility function 
    
  
    '''
    def __init__(self, e_i=None, sigma_i=None, w_i=1, rho_i=2, f_i = 0.5, 
               agent_type='CES'):
        '''
        e_i: entitlement of this agent, we assume scalar (same across resource)
    

        sigma_i: std of the noise for agent's feedbacks
        
        agent_type: CES or Amdahl
          
        
        parameters: 0 < rho_i < 1
        w_i: numpy array of shape m * 1, all entries non negative, total sum to 1
        
        f_i: 0 < f_i < 1, parallel fraction
        
        '''
        
        self.e_i = e_i
      
        self.sigma_i = sigma_i
        
        self.agent_type = agent_type
        
        # for specific CES utility in Zhang
        self.w_i = w_i
        self.rho_i = rho_i
        
        #for Amdahl's utility
        #w_i is already included
        self.f_i = f_i
        
        if abs(np.sum(self.w_i) - 1) > 0.1:  #numerical tolerance
            print('ERROR: w_i is not normalized')
            
        
        self.Q_it = 0
        self.theta_bar_it=0
        self.theta_it = 0
        
        #record history    
        self.x_i_hist = []
        self.y_i_hist = []
            
        
    def CES_util(self, x_i, use_theta_sample=False):
        ''' 
        compute CES utility given an allocation in Zhang's paper
        
        u_i =  sum_j=1^m w_{ij}^\rho_i (x_i)^\rho_i 
        
        
        
        x_i: numpy array of shape m * 1
    
        '''
        
        m = x_i.shape[0]
         
        u_i_list = []
        
        if use_theta_sample==False:

            for j in range(m):

                u_i_list.append( (x_i[j]**(self.rho_i)) *( self.w_i[j]**(self.rho_i)))
        else:
            
            for j in range(m):
                
                u_i_list.append( (x_i[j]**(self.rho_i)) * self.theta_it[j])

        return u_i_list

    def Amdahl_util(self, x_i, use_theta_sample=False):
        ''' 
        compute Amdahl utility given an allocation from Lee et al
    
        
        x_i: numpy array of shape m * 1
    
        '''
            
        m = x_i.shape[0]
         
        u_i_list = []
        
        if use_theta_sample==False:

            for j in range(m):
            
                s_ij = float(x_i[j])/float(self.f_i + (1-self.f_i)*x_i[j])

                u_i_list.append(float(self.w_i[j] * s_ij)/float(np.sum(self.w_i)))
                
        elif use_theta_sample==True:
            
            for j in range(m):
                
                s_ij = float(x_i[j])/float(self.f_i + (1-self.f_i)*x_i[j])

                u_i_list.append(float(self.theta_it[j] * s_ij))
                    
        
        return u_i_list
    
    def generate_feedback(self, x_i, true_util=False, use_theta_sample=False,
                          record_x = False, record_y=False):
        '''
        true_util: if True, will return the noiseless utility-- can still be computed using theta sample!
        
        '''
        
        if self.agent_type == 'CES':
        
            u_i_mean = sum(self.CES_util(x_i, use_theta_sample=use_theta_sample))
            
        elif self.agent_type == 'Amdahl':
        
            u_i_mean = sum(self.Amdahl_util(x_i, use_theta_sample=use_theta_sample))
        
        else:
            print('ERROR: agent type not supported yet')
            return
        
        if true_util:
            
            y_i = u_i_mean
            
        else:
        
            y_i = np.random.normal(u_i_mean, self.sigma_i, 1)[0]  #sample a scalar value y_i
        
        if record_x:
            self.x_i_hist.append(x_i)
            
        if record_y:
            self.y_i_hist.append(y_i)
        
        return y_i
    
    def generate_bids(self, x_i):
        '''
        generate numpy array of shape (m,) for bids over all resources, using PRD
        
        '''
        if self.agent_type == 'CES':
        
            util_list = self.CES_util(x_i, use_theta_sample=True)
            
        elif self.agent_type == 'Amdahl':
        
            util_list = self.Amdahl_util(x_i, use_theta_sample=True)
            
        util_list = np.array(util_list)
        norm = np.sum(util_list)
        util_list = util_list/norm
        
       
        bids = np.multiply(util_list,  self.b_i)
        
        return bids
    
    def record_bids(self, b_i):
        
        self.b_i = b_i
    
    
    def compute_Qit(self):
        
        '''
        Compute Q_it = sum_{s=1}^t phi(x_it) phi(x_it)^\top
        
        '''
 
        
        m = self.w_i.shape[0]
        
        Q_it = np.zeros((m,m))
        

        for x_is in self.x_i_hist:
        
            if self.agent_type == 'CES':
                phi_x_is = np.power(x_is, self.rho_i)
                
            elif self.agent_type == 'Amdahl':

                phi_x_is = np.array([float(x)/float(self.f_i + (1-self.f_i*x)) for x in list(x_is)])
                
            phi_x_is = np.reshape(phi_x_is, (m,1))
            
            phi_phi_top = np.dot(phi_x_is, np.transpose(phi_x_is)) 
           

            Q_it = np.add(Q_it, phi_phi_top)    
            
        self.Q_it = Q_it
        
        return self.Q_it
           
    
    def compute_theta_bar_it_MLE(self):
        
        print('Begin compute_theta_bar_it_MLE')
        
        m = self.w_i.shape[0]
       
        term_RX = np.zeros((m,))
        
        term_XXT = np.zeros((m,m))
    
        
        for i, x_is in enumerate(self.x_i_hist):
            
            
            
            if self.agent_type == 'CES':
                
                phi_x_is = np.power(x_is, self.rho_i)
                

                
            elif self.agent_type == 'Amdahl':

                phi_x_is = np.array([float(x)/float(self.f_i + (1-self.f_i*x)) for x in list(x_is)])
            
            term_RX = term_RX + (self.y_i_hist[i]) * phi_x_is
            
            phi_x_is = np.reshape(phi_x_is, (m,1))
            
            term_XXs_matrix = np.dot(phi_x_is, np.transpose(phi_x_is))
            
            
            term_XXT = np.add(term_XXT, term_XXs_matrix)

        
        self.theta_bar_it  = np.dot(LA.inv(term_XXT),term_RX)
        
        #projection to nonnegative space
        self.theta_bar_it[self.theta_bar_it < 0] = 0.01
        
        return self.theta_bar_it
    
    def sample_theta_it(self, alpha_t):
        
        mean = self.theta_bar_it
        
        
        cov = (float(alpha_t)**2) * LA.inv(self.Q_it)
        
        self.theta_it = np.random.multivariate_normal(mean, cov, 1)[0]
        
       
        
        while (self.theta_it>0).all() == False:
            
            self.theta_it = np.random.multivariate_normal(mean, cov, 1)[0]
            
            #projection to nonnegative space
        self.theta_it[self.theta_it < 0] = 0.01
        
        return self.theta_it