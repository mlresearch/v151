# Code in this file is copied and adapted from
# https://github.com/openai/evolution-strategies-starter.

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import gym
import numpy as np
import tensorflow as tf
import collections

import ray
from ray.rllib.evaluation.sampler import _unbatch_tuple_actions
from ray.rllib.models import ModelCatalog, FullyConnectedNetwork
from ray.rllib.utils.filter import get_filter
from ray.rllib.utils.error import UnsupportedSpaceException
from ray.rllib.utils.annotations import override
from ray.rllib.models.misc import linear, normc_initializer
from ray.rllib.models.misc import normc_initializer, get_activation_fn
import tensorflow.contrib.slim as slim


def rollout(policy, env, safe_exp=False, entropy_scale=0.01, reward_scale=5, timestep_limit=None, add_noise=False, clip_action = False, safety_gym=False):
    """Do a rollout.

    If add_noise is True, the rollout will take noisy actions with
    noise drawn from that stream. Otherwise, no action noise will be added.
    """
    env_timestep_limit = env.spec.max_episode_steps
    timestep_limit = (env_timestep_limit if timestep_limit is None else min(
        timestep_limit, env_timestep_limit))
    rews = []
    rews_h = []
    entrp = []
    cost = []
    t = 0
    observation = env.reset()
    # if cliff:
    #     observation = np.array(observation).reshape([1, 2])
    # else:
    #     observation = policy.transform_observation(observation)
    observation = policy.transform_observation(observation)
    for _ in range(timestep_limit or 999999):
        ac, entropy = policy.compute(observation, add_noise=add_noise)
        ac_clip = ac[0]
        if clip_action:
            ac_clip = np.clip(ac[0], -1, 1) # Pybullet
            # ac_clip = np.clip(ac, 0, 1)  # battleship
        observation, rew, done, info = env.step(ac_clip)
        if safe_exp and safety_gym:
            cost.append(info['cost'])
        elif safe_exp and not safety_gym:
            cost.append(info['constraint_costs'])
        # if cliff:
        #     observation = np.array(observation).reshape([1, 2])
        # else:
        #     observation = policy.transform_observation(observation)
        observation = policy.transform_observation(observation)
        if safe_exp and safety_gym:
            rew_h = reward_scale * rew + entropy_scale * entropy #- 0.5 * reward_scale * info['cost']
        elif safe_exp:
            rew_h = reward_scale * rew + entropy_scale * entropy# - 0.5* reward_scale * info['constraint_costs'][0]
        else:
            rew_h = reward_scale * rew + entropy_scale * entropy

        rews.append(rew)
        rews_h.append(rew_h)
        entrp.append(entropy)
        t += 1
        if done:
            break
    rews = np.array(rews, dtype=np.float32)
    rews_h = np.array(rews_h, dtype=np.float32)
    entropy_eval = np.sum(np.array(entrp, dtype=np.float32).flatten())
    episodic_cost = np.sum(np.array(cost, dtype=np.float32).flatten())
    return rews, t, rews_h, entropy_eval, episodic_cost


def rollout_with_surrogate(policy, env, discount_factor, calc_gradient, safe_exp=False, entropy_scale=0.01, reward_scale=5,
                            clip_action = True, clip_reward = False, timestep_limit=None, add_noise=False, safety_gym=False):
    """Do a rollout, return the reward and number of timesteps. Also, return the estimated policy gradient.
        Which will be then used to estimate the surrogate gradient subspace.
    """
    env_timestep_limit = env.spec.max_episode_steps
    timestep_limit = (env_timestep_limit if timestep_limit is None else min(
        timestep_limit, env_timestep_limit))
    rews = []
    rews_h = []
    entrp = []
    surrogate_grad = 0
    cost = []
    t = 0
    observation = env.reset()
    # if cliff:
    #     observation = np.array(observation).reshape([1,2])
    # else:
    #     observation = policy.transform_observation(observation)

    observation = policy.transform_observation(observation)
    Transition = collections.namedtuple("Transition", ["state", "action", "reward",
                                                       "next_state", "done"])
    episode = []
    for _ in range(timestep_limit or 999999):
        ac, entropy = policy.compute(observation, add_noise=add_noise)
        ## TODO: Use tanh to squash instead of clipping
        ac_clip = ac[0]
        if clip_action:
            ac_clip = np.clip(ac[0], -1, 1) # Pybullet
            # ac_clip = np.clip(ac, 0, 1) # battleship
        next_obs, rew, done, info = env.step(ac_clip)
        if clip_reward:
            rew = np.clip(rew, a_min=-10, a_max=None)
        if safe_exp and safety_gym:
            rew_h = reward_scale * rew + entropy_scale * entropy #- 0.5 * reward_scale * info['cost']
        elif safe_exp:
            rew_h = reward_scale * rew + entropy_scale * entropy# - 0.5* reward_scale * info['constraint_costs'][0]
        else:
            rew_h = reward_scale * rew + entropy_scale * entropy
        rews.append(rew)
        rews_h.append(rew_h)
        entrp.append(entropy)
        if safe_exp and safety_gym:
            cost.append(info['cost'])
        elif safe_exp and not safety_gym:
            cost.append(info['constraint_costs'])
        # if cliff:
        #     next_obs = np.array(next_obs).reshape([1, 2])
        # else:
        #     next_obs = policy.transform_observation(next_obs)
        next_obs = policy.transform_observation(next_obs)
        episode.append(Transition(state=observation, action=ac[0],
                                  reward=rew, next_state=next_obs, # changing to rew from rew_h
                                  done=done))
        t += 1
        if done:
            break
        observation = next_obs

    rews = np.array(rews, dtype=np.float32)
    rews_h = np.array(rews_h, dtype=np.float32)
    entropy_eval = np.sum(np.array(entrp, dtype=np.float32).flatten())
    episodic_cost = np.sum(np.array(cost, dtype=np.float32).flatten())
    value_grad = 0
    policy_grad = 0
    if calc_gradient:
        states = []
        policy_targets = []
        value_targets = []
        actions = []

        reward = 0
        # orders the transitions from end to start
        for transition in episode[::-1]:
            reward = transition.reward + discount_factor * reward
            advantage = reward - policy.value_predict(transition.state)

            # Accumulate updates
            states.append(transition.state)
            actions.append(transition.action)
            policy_targets.append(advantage)
            value_targets.append(reward)

        # actions, observations, advantages, v_target
        # return value and policy gradients
        # Policy loss
        if isinstance(env.action_space, gym.spaces.Box):
            ac_size = env.action_space.shape[0]
            actions = np.array(actions).reshape(len(actions), ac_size)
        elif isinstance(env.action_space, gym.spaces.Discrete):
            actions = np.array(actions, dtype=np.int64)
        # if cliff:
        #     state_input = np.array(states).reshape([-1,2])
        #     advantage_input = np.array(policy_targets).flatten()
        # else:
        #     state_input = np.squeeze(np.array(states))
        #     advantage_input = np.squeeze(np.array(policy_targets))
        policy_grad = policy.get_gradients(actions,
                                           np.squeeze(np.array(states)), np.squeeze(np.array(policy_targets)),
                                           np.array(value_targets))

        value_grad = policy.get_weights_vf()

    # Test for nan's
    if np.any(np.isnan(policy_grad)):
        print("Policy gradient has NAN's")
        policy_grad = np.zeros_like(policy_grad)
        # print("States:", states)
        # print("policy targets", policy_targets)
        # print("value targets", value_targets)


    return rews, t, value_grad, policy_grad, rews_h, entropy_eval, episodic_cost


class A3CLoss(object):
    def __init__(self,
                 action_dist,
                 actions,
                 advantages,
                 v_target,
                 vf,
                 vf_loss_coeff=0.5,
                 entropy_coeff=-0.01):
        log_prob = action_dist.logp(actions)

        # Policy gradient loss
        pi_loss = -tf.reduce_sum(log_prob * advantages)

        delta = vf - v_target
        self.vf_loss = 0.5 * tf.reduce_sum(tf.square(delta))
        self.entropy = tf.reduce_sum(action_dist.entropy())
        self.policy_loss = (pi_loss + self.entropy * entropy_coeff)


class GenericPolicy(object):
    def __init__(self, sess, action_space, obs_space, preprocessor,
                 observation_filter, model_options, action_noise_std):
        self.sess = sess
        self.action_space = action_space
        self.action_noise_std = action_noise_std
        self.preprocessor = preprocessor
        self.observation_filter = get_filter(observation_filter,
                                             self.preprocessor.shape)
        self.inputs = tf.placeholder(tf.float32,
                                     [None] + list(self.preprocessor.shape))

        # Policy network.
        dist_class, dist_dim = ModelCatalog.get_action_dist(
            self.action_space, model_options)
        model = ModelCatalog.get_model({
            "obs": self.inputs
        }, obs_space, dist_dim, model_options)
        dist = dist_class(model.outputs)
        self.sampler = dist.sample()

        self.variables = ray.experimental.TensorFlowVariables(
            model.outputs, self.sess)

        self.num_params = sum(
            np.prod(variable.shape.as_list())
            for _, variable in self.variables.variables.items())
        self.sess.run(tf.global_variables_initializer())

    def compute(self, observation, add_noise=False, update=True):
        action = self.sess.run(
            self.sampler, feed_dict={self.inputs: observation})
        action = _unbatch_tuple_actions(action)
        if add_noise and isinstance(self.action_space, gym.spaces.Box):
            action += np.random.randn(*action.shape) * self.action_noise_std
        return action

    def transform_observation(self, observation, update=True):
        observation = self.preprocessor.transform(observation)
        observation = self.observation_filter(observation[None], update=update)
        return observation

    def set_weights(self, x):
        self.variables.set_flat(x)

    def get_weights(self):
        return self.variables.get_flat()

    def get_filter(self):
        return self.observation_filter

    def set_filter(self, observation_filter):
        self.observation_filter = observation_filter


class AACritic(GenericPolicy):
    def __init__(self, sess, action_space, obs_space, preprocessor,
                 observation_filter, model_options, action_noise_std):
        self.sess = sess
        self.action_space = action_space
        self.action_noise_std = action_noise_std
        self.preprocessor = preprocessor
        self.observation_filter = get_filter(observation_filter,
                                             self.preprocessor.shape)

        # observations
        self.inputs = tf.placeholder(tf.float32,
                                     [None] + list(self.preprocessor.shape))
        # # other inputs
        # prev_actions = ModelCatalog.get_action_placeholder(action_space)
        # prev_rewards = tf.placeholder(tf.float32, [None], name="prev_reward")

        # Policy network.
        dist_class, dist_dim = ModelCatalog.get_action_dist(
            self.action_space, model_options)
        with tf.variable_scope("policy"):
            model = ModelCatalog.get_model({
                "obs": self.inputs,
                # "prev_actions": prev_actions,
                # "prev_rewards": prev_rewards,
            }, obs_space, dist_dim, model_options)
            dist = dist_class(model.outputs)
        self.sampler = dist.sample()

        # Entropy of the distribution
        self.entropy_dist = tf.reduce_sum(dist.entropy())
        # value network
        self.value_function = model.value_function(self.inputs, model_options)

        self.variables = ray.experimental.TensorFlowVariables(
            model.outputs, self.sess)

        self.variables_value = ray.experimental.TensorFlowVariables(
            self.value_function, self.sess)

        self.num_params = sum(
            np.prod(variable.shape.as_list())
            for _, variable in self.variables.variables.items())
        self.num_params_vf = sum(
            np.prod(variable.shape.as_list())
            for _, variable in self.variables_value.variables.items())

        # Policy loss
        if isinstance(action_space, gym.spaces.Box):
            ac_size = action_space.shape[0]
            self.actions = tf.placeholder(tf.float32, [None, ac_size], name="ac")
        elif isinstance(action_space, gym.spaces.Discrete):
            self.actions = tf.placeholder(tf.int64, [None], name="ac")
        else:
            raise UnsupportedSpaceException("Action space {} is not supported for A3C.".format(action_space))

        self.advantages = tf.placeholder(tf.float32, [None], name="advantages")
        self.v_target = tf.placeholder(tf.float32, [None], name="v_target")
        self.loss = A3CLoss(dist, self.actions, self.advantages, self.v_target, self.value_function,
                            model_options.get("vf_loss_coeff"), model_options.get("entropy_coeff"))

        self.value_vars = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope='value')

        self.policy_vars = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope='policy')

        # get gradients
        # not using the learning rate, setting it to some constant
        self.optimizer = tf.train.AdamOptimizer(0.01)
        self.gradients_value = self.optimizer.compute_gradients(self.loss.vf_loss, self.value_vars)
        self.gradients_policy = self.optimizer.compute_gradients(self.loss.policy_loss, self.policy_vars)

        self.value_op = self.optimizer.apply_gradients(self.gradients_value)
        # Initialize TFPolicyGraph
        self.sess.run(tf.global_variables_initializer())

    @override(GenericPolicy)
    def compute(self, observation, add_noise=False, update=True):
        action, entropy = self.sess.run(
            [self.sampler, self.entropy_dist], feed_dict={self.inputs: observation})
        action = _unbatch_tuple_actions(action)
        if add_noise and isinstance(self.action_space, gym.spaces.Box):
            action += np.random.randn(*action.shape) * self.action_noise_std
        return action, entropy

    def transform_observation(self, observation, update=True):
        observation = self.preprocessor.transform(observation)
        observation = self.observation_filter(observation[None], update=update)
        return observation

    def value_predict(self, observation):
        value = self.sess.run(self.value_function,
                              feed_dict={self.inputs: observation})
        return value

    def get_gradients(self, action, observations, advantages, v_target):

        _, policy_grad = self.sess.run([self.value_op, self.gradients_policy],
                                       feed_dict={self.inputs: observations,
                                                  self.advantages: advantages, self.v_target: v_target,
                                                  self.actions: action})
        pgrad = []
        for grad, vars in policy_grad:
            pgrad.append(grad.flatten())
        pgrad = np.hstack(pgrad)

        return pgrad

    def set_weights_vf(self, x):
        self.variables_value.set_flat(x)

    def get_weights_vf(self):
        return self.variables_value.get_flat()


# Model to use for surrogate gradients
class MyModelClass(FullyConnectedNetwork):
    @override(FullyConnectedNetwork)
    def value_function(self, input, options):
        """Builds the value function output.

        This method can be overridden to customize the implementation of the
        value function (e.g., not sharing hidden layers).

        Returns:
            Tensor of size [BATCH_SIZE] for the value function.
        """

        hiddens = options.get("fcnet_hiddens_vf")
        activation = get_activation_fn(options.get("fcnet_activation"))

        with tf.name_scope("value"):
            i = 1
            last_layer = input
            for size in hiddens:
                label = "fc{}".format(i)
                last_layer = slim.fully_connected(
                    last_layer,
                    size,
                    weights_initializer=normc_initializer(1.0),
                    activation_fn=activation,
                    scope=label)
                i += 1
            output = tf.reshape(linear(last_layer, 1,
                                       "value_output", normc_initializer(1.0)), [-1])

        return output
