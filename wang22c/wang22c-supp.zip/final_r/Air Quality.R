library(lubridate)
library(dplyr)


library(genlasso)
library(doParallel)
library(foreach)
library(ITALE)
library(mvtnorm)


cv.fusedlasso <- function(object, D, k=5) {
  
  y = object$y
  X = object$X
  n = length(y)
  
  if(k<2 || round(k)!=k || k>n-2) {
    stop("The number of folds must an integer between 2 and n-2.")
  }
  
  foldid = c(0,rep(Seq(1,k),n-2)[Seq(1,n-2)],0)
  
  lambda = object$lambda
  cvall = matrix(0,k,length(lambda))
  
  for (i in Seq(1,k)) {
    cat(sprintf("Fold %i ... ",i))
    
    otr = which(foldid!=i)
    ntr = length(otr)
    ytr = y[otr]
    Xtr = X[otr, ]  
    
    out = fusedlasso(ytr, Xtr, D)
    b = coef.genlasso(out, lambda = lambda)$beta  
    
    
    ote = which(foldid==i)
    yte = matrix(y[ote],length(ote),length(lambda))
    Xte = X[ote, ]
    pred = Xte %*% b
    
    cvall[i, ] = colMeans((yte-pred)^2) 
  }
  
  cverr = colMeans(cvall)
  i0 = which.min(cverr)
  lam.min = lambda[i0]
  out.list = list(lambda.min = lam.min, i.min = i0)
  return(out.list)
}

Seq <- function(a, b, ...) {
  if (a<=b) return(seq(a,b,...))
  else return(numeric(0))
}


path = "/Users/apple/air quality"
fileNames = dir(path)
filepath = sapply(fileNames, function(x){paste(path, x, sep = "/")})
filepath
data_air_quality = lapply(filepath, function(x){read.csv2(x,header = T, sep = ",")})

data_air_quality = lapply(data_air_quality, function(x){
  x$date = as.Date(x$date)
  x$date = ymd(x$date)
  x = x[order(x$date,decreasing = T),]
  x = x[, c(1,2)]
  x
})

date_1 = ymd(as.Date("2021-07-30"))
date_2 = ymd(as.Date("2020-07-31"))

data_air_quality = lapply(data_air_quality, function(x){
  x[which(x$date == date_1): which(x$date == date_2), ]
})

date_interval = data_air_quality$`beijing-air-quality.csv`$date

date_miss =  lapply(data_air_quality, function(x){
     which(is.na(match(date_interval, x$date)))
  })

data_full =  lapply(data_air_quality, function(x){
  date_miss = which(is.na(match(date_interval, x$date)))
  col_1 = date_interval[date_miss]
  col_2 = rep(NA, length(date_miss))
  data_new = data.frame(date = col_1, pm25 = col_2)
  rbind(x, data_new)
})


data_full = lapply(data_full, function(x){
  x = x[order(x$date,decreasing = T),]
  x
})

data_full = lapply(data_full, function(x){
  x[, 2]
})


data_full_new = cbind(data_full$`amsterdam-air-quality.csv`, 
                      data_full$`bangkok-air-quality.csv`, 
                      data_full$`beijing-air-quality.csv`,
                      data_full$`central,-singapore-air-quality.csv`,
                      data_full$`changsha-air-quality.csv`,
                      data_full$`chongqing-air-quality.csv`,
                      data_full$`dalian-air-quality.csv`,
                      data_full$`frankfurt-(oder), germany-air-quality.csv`,
                      data_full$`guangzhou-air-quality.csv`,
                      data_full$`haerbin-air-quality.csv`,
                      data_full$`hefei-air-quality.csv`,
                      data_full$`hongkong-air-quality.csv`, 
                      data_full$`kunming-air-quality.csv`,
                      data_full$`kyoto-air-quality.csv`,
                      data_full$`lhasa-air-quality.csv`,
                      data_full$`london-air-quality.csv`, 
                      data_full$`los-angeles-north main street-air-quality.csv`,
                      data_full$`manchester-piccadilly, united kingdom-air-quality.csv`,
                      data_full$`nanjing-air-quality.csv`, 
                      data_full$`osaka-air-quality.csv`, 
                      data_full$`paris-air-quality.csv`, 
                      data_full$`sanya-air-quality.csv`,
                      data_full$`seoul-air-quality.csv`,
                      data_full$`shanghai-air-quality.csv`, 
                      data_full$`sternschanze,-hamburg, germany-air-quality.csv`, 
                      data_full$`suzhou-air-quality.csv`,
                      data_full$`tianjin-air-quality.csv`, 
                      data_full$`xiamen-air-quality.csv`,
                      data_full$`xian-air-quality.csv`, 
                      data_full$`yamatocho,-itabashi, tokyo, japan-air-quality.csv`)

data_matrix = data.matrix(data_full_new)

X_matrix = data_matrix[2:1191, ] 

X_matrix_mean = matrix(NA, ncol = 30, nrow = 170)


for (i in 1:170){
  X_matrix_mean[i, ] = colMeans(X_matrix[(i*7-6):(i*7), ], na.rm = T)
}  
  
X_train_1 =  t( X_matrix_mean[seq(1,nrow(X_matrix_mean),2), ])

X_train_1 = scale(X_train_1)

X_test_1 =  t (X_matrix_mean[seq(2,nrow(X_matrix_mean),2), ])

X_test_1 = scale(X_test_1)

y_1 = data_matrix[1, ]

y_1 = scale(y_1)

p = dim(X_train_1)[2]

n = dim(X_train_1)[1]

D = getD1d(p)

res = fusedlasso (y_1, X_train_1, D)

cv = cv.fusedlasso(res, D)

fit_1 = coef(res, lambda = cv$lambda.min)$beta


mse_fl_train_1 = sum((y_1 - X_train_1 %*% fit_1)^2)/n

mse_fl_test_1 = sum((y_1 - X_test_1 %*% fit_1)^2)/n




X_train_2 =  t( X_matrix_mean[1:52, 1:20 ])

scale = scale(X_train_2)

X_test_2 =  t (X_matrix_mean[ 1:52, 21:30 ])

scale = scale(X_test_2)

y_2 = data_matrix[1, 1:20]

y_2 = scale(y_2)

y_test =  data_matrix[1, 21:30]

y_test = scale(y_test)

p = dim(X_train_2)[2]

n = dim(X_train_2)[1]

D = getD1d(p)

res = fusedlasso (y_2, X_train_2, D)

cv = cv.fusedlasso(res, D)

fit_2 = coef(res, lambda = cv$lambda.min)$beta

n_test = length(y_test)

mse_fl_train_2 = sum((y_2 - X_train_2 %*% fit_2)^2)/n

mse_fl_test_2 = sum((y_test - X_test_2 %*% fit_2)^2)/n_test




  
