from argparse import ArgumentParser

import loss_functions
import models
import torch
from data_loader import load_dataset
from ignite.engine import (
    Events,
    create_supervised_evaluator,
    create_supervised_trainer,
)
from ignite.metrics import Loss, RunningAverage
from torch.optim import SGD
from torch.utils.data import DataLoader
from utils import create_train_evaluator, create_trainer, create_val_evaluator

dataset_pi = {
    "adult": 7841 / 32561,
    "banana": 2376 / 5300,
    "codrna": 19845 / 59535,
    "ijcnn1": 4853 / 49990,
    "magic": 6688 / 19020,
    "phishing": 4898 / 11055,
    "phoneme": 3818 / 5404,
    "spambase": 1813 / 4601,
    "w8a": 1479 / 49749,
    "waveform": 1657 / 5000,
    "mnist": 1 / 2,
    "kmnist": 1 / 2,
    "fashion": 1 / 2,
}


def get_data_loaders(
    train_batch_size, val_batch_size, dataset, nsd, ntest, seed=0, prior=None
):
    x_train_a, x_train_b, y_train, x_test, y_test = load_dataset(
        dataset, nsd, ntest, seed, prior=prior
    )

    train = torch.utils.data.TensorDataset(
        torch.Tensor(x_train_a), torch.Tensor(x_train_b), torch.Tensor(y_train)
    )
    test = torch.utils.data.TensorDataset(
        torch.Tensor(x_test), torch.Tensor(y_test)
    )

    train_loader = DataLoader(train, batch_size=train_batch_size, shuffle=True)
    val_loader = DataLoader(test, batch_size=val_batch_size, shuffle=False)

    return train_loader, val_loader


def run(
    train_batch_size,
    val_batch_size,
    epochs,
    lr,
    momentum,
    weight_decay,
    display_gpu_info,
    loss,
    model,
    dataset,
    nsd,
    ntest,
    seed,
    algorithm,
    prior=None,
):
    train_loader, val_loader = get_data_loaders(
        train_batch_size, val_batch_size, dataset, nsd, ntest, seed, prior=prior
    )
    device = "cpu"

    if torch.cuda.is_available():
        device = "cuda"

    loss_fn = getattr(loss_functions, loss)
    model = getattr(models, model)(train_loader.dataset[0][0].shape[0])
    model.to(device)  # Move model before creating optimizer
    optimizer = SGD(
        model.parameters(), lr=lr, momentum=momentum, weight_decay=weight_decay
    )
    trainer = create_trainer(
        model,
        optimizer,
        loss_fn,
        device=device,
        type=algorithm,
        prior=(prior or dataset_pi[dataset]),
    )
    train_evaluator = create_train_evaluator(
        model,
        metrics={"accuracy": Loss(loss_fn=loss_functions.zero_one)},
        device=device,
    )
    val_evaluator = create_val_evaluator(
        model,
        metrics={"accuracy": Loss(loss_fn=loss_functions.zero_one)},
        device=device,
    )

    RunningAverage(output_transform=lambda x: x).attach(trainer, "loss")

    if display_gpu_info:
        from ignite.contrib.metrics import GpuInfo

        GpuInfo().attach(trainer, name="gpu")

    @trainer.on(Events.EPOCH_COMPLETED)
    def log_training_results(engine):
        train_evaluator.run(train_loader)
        metrics = train_evaluator.state.metrics
        avg_accuracy = metrics["accuracy"]
        print(
            "Epoch: {:>4}  Train accuracy: {:.3f} ".format(
                engine.state.epoch, max(avg_accuracy, 1 - avg_accuracy)
            ),
            end=" ",
        )

    @trainer.on(Events.EPOCH_COMPLETED)
    def log_validation_results(engine):
        val_evaluator.run(val_loader)
        metrics = val_evaluator.state.metrics
        avg_accuracy = metrics["accuracy"]
        print(
            "Validation accuracy: {:.3f}".format(
                max(avg_accuracy, 1 - avg_accuracy)
            )
        )

    trainer.run(train_loader, max_epochs=epochs)

    acc = val_evaluator.state.metrics["accuracy"]
    return max(acc, 1 - acc)


def run_supervised(
    train_batch_size,
    val_batch_size,
    epochs,
    lr,
    momentum,
    weight_decay,
    display_gpu_info,
    loss,
    model,
    dataset,
    nsd,
    ntest,
    seed,
    prior=None,
):
    x_train, y_train, x_test, y_test = load_dataset(
        dataset, nsd, ntest, seed, supervised=True, prior=prior
    )

    train = torch.utils.data.TensorDataset(
        torch.Tensor(x_train), torch.Tensor(y_train)
    )
    test = torch.utils.data.TensorDataset(
        torch.Tensor(x_test), torch.Tensor(y_test)
    )

    train_loader = DataLoader(train, batch_size=train_batch_size, shuffle=True)
    val_loader = DataLoader(test, batch_size=val_batch_size, shuffle=False)

    device = "cpu"

    if torch.cuda.is_available():
        device = "cuda"

    loss_fn = getattr(loss_functions, loss)
    model = getattr(models, model)(train_loader.dataset[0][0].shape[0])
    model.to(device)  # Move model before creating optimizer
    optimizer = SGD(
        model.parameters(), lr=lr, momentum=momentum, weight_decay=weight_decay
    )
    trainer = create_supervised_trainer(
        model, optimizer, loss_fn, device=device
    )
    evaluator = create_supervised_evaluator(
        model,
        metrics={"accuracy": Loss(loss_fn=loss_functions.zero_one)},
        device=device,
    )

    RunningAverage(output_transform=lambda x: x).attach(trainer, "loss")

    if display_gpu_info:
        from ignite.contrib.metrics import GpuInfo

        GpuInfo().attach(trainer, name="gpu")

    @trainer.on(Events.EPOCH_COMPLETED)
    def log_training_results(engine):
        evaluator.run(train_loader)
        metrics = evaluator.state.metrics
        avg_accuracy = metrics["accuracy"]
        print(
            "Epoch: {:>4}  Train accuracy: {:.3f} ".format(
                engine.state.epoch, max(avg_accuracy, 1 - avg_accuracy)
            ),
            end=" ",
        )

    @trainer.on(Events.EPOCH_COMPLETED)
    def log_validation_results(engine):
        evaluator.run(val_loader)
        metrics = evaluator.state.metrics
        avg_accuracy = metrics["accuracy"]
        print(
            "Validation accuracy: {:.3f}".format(
                max(avg_accuracy, 1 - avg_accuracy)
            )
        )

    trainer.run(train_loader, max_epochs=epochs)
    acc = evaluator.state.metrics["accuracy"]
    return max(acc, 1 - acc)


if __name__ == "__main__":
    parser = ArgumentParser()
    parser.add_argument(
        "--batch_size",
        type=int,
        default=64,
        help="input batch size for training (default: 64)",
    )
    parser.add_argument(
        "--val_batch_size",
        type=int,
        default=1000,
        help="input batch size for validation (default: 1000)",
    )
    parser.add_argument(
        "--epochs",
        type=int,
        default=500,
        help="number of epochs to train (default: 500)",
    )
    parser.add_argument(
        "--lr", type=float, default=0.01, help="learning rate (default: 0.01)"
    )
    parser.add_argument(
        "--momentum",
        type=float,
        default=0.0,
        help="SGD momentum (default: 0.0)",
    )
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument(
        "--dataset",
        type=str,
        default="phishing",
        choices=[
            "adult",
            "banana",
            "codrna",
            "ijcnn1",
            "magic",
            "phishing",
            "phoneme",
            "spambase",
            "w8a",
            "waveform",
            "higgs",
            "susy",
            "mnist",
            "fashion",
        ],
    )
    parser.add_argument("--nsd", type=int, default=500)
    parser.add_argument("--ntest", type=int, default=1000)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--model", type=str, default="LinearClassifier")
    parser.add_argument(
        "--loss", type=str, default="logistic", help="Loss function "
    )
    parser.add_argument(
        "--algorithm",
        type=str,
        default="sl",
        choices=["sl", "sd", "mcl"],
        help="learning method",
    )
    parser.add_argument(
        "--display_gpu_info",
        action="store_true",
        help="Display gpu usage info. This needs python 3.X and pynvml package",
    )

    args = parser.parse_args()

    print("# Dataset: {}".format(args.dataset))
    print("# Loss: {}".format(args.loss))
    print("# Train batchsize: {}".format(args.batch_size))
    print("# Vdalidation batchsize: {}".format(args.val_batch_size))
    print("# Weight Decay: {}".format(args.weight_decay))
    print("# epoch: {}".format(args.epochs))
    print("# NSD: {}".format(args.nsd))
    print("# Ntest: {}".format(args.ntest))
    print("# Algorithm: {}".format(args.algorithm))
    print("# Seed: {}".format(args.seed))
    print("# Learning Rate: {}".format(args.lr))
    print("# Momentum: {}".format(args.momentum))
    print("# Model: {}".format(args.model))
    print("")

    run(
        train_batch_size=args.batch_size,
        val_batch_size=args.val_batch_size,
        epochs=args.epochs,
        lr=args.lr,
        momentum=args.momentum,
        weight_decay=args.weight_decay,
        display_gpu_info=args.display_gpu_info,
        loss=args.loss,
        model=args.model,
        dataset=args.dataset,
        nsd=args.nsd,
        ntest=args.ntest,
        seed=args.seed,
        algorithm=args.algorithm,
    )
