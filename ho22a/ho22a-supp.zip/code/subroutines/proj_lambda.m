function u_proj = proj_lambda(u, lambda)
    u_proj  = min(u, lambda);
    u_proj  = max(u_proj, -lambda);
end
