import numpy as np
from PreferentialGP.utility import include_sparsity, experiment0, preprocessingC, generate_match

import sys
sys.path.append("/src/")
import pickle
import os
os.environ['KMP_DUPLICATE_LIB_OK']='True'

from PreferentialGP.SkewSymGP import skewsymGaussianProcess_Cuda, skewsymGaussianProcess
from src.spektrankers import *
from gpytorch.kernels import RBFKernel


n = 20
p = 8
n_states = 2

X, beta_dict, latent_states = experiment0(n, p, n_states)
C = generate_match(X, beta_dict, latent_states)

C_sparse = include_sparsity(C, 0.3)
choix_ls, y_ls = preprocessingC(C_sparse)

skewgp = skewsymGaussianProcess_Cuda(choix_ls, y_ls, X)
skewgp.fit(10000, 1e-4)
sigma = torch.nn.Sigmoid()
pred = (sigma(skewgp.posterior_mean.cpu()).numpy() > 0.5) * 1

skewgp_accuracy = 1 - pred[: int(len(y_ls)/2)].mean()

print(skewgp_accuracy)

