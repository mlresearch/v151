import numpy as np
from sklearn.metrics import mean_absolute_error


def mae(predictions, labels, label_std=None, allow_empty_list=False):
    """
    :param predictions: Regression outputs from a model. Either a list of NumPy arrays of shape
    [N] or [N, 1, ...] or a single NumPy array of shape [N] or [N, 1, ...]. In case of a list,
    the individual arrays are first concatenated into a single array along the first dimension.
    :param labels: Regression labels. Either a list of NumPy arrays of shape
    [N] or [N, 1, ...] or a single NumPy array of shape [N] or [N, 1, ...]. In case of a list,
    the individual arrays are first concatenated into a single array along the first dimension.
    :param label_std: Standard deviation of the labels before standardization. If not None, the
    MAE is scaled back to the original standard deviation of the data.
    :param allow_empty_list: If True, the method returns NaN if the list of predictions is empty.
    Otherwise it throws an exception.
    """
    if allow_empty_list and len(predictions) == 0:
        return np.nan
    if isinstance(predictions, list):
        predictions = np.concatenate(predictions, axis=0)
    if isinstance(labels, list):
        labels = np.concatenate(labels)
    if allow_empty_list:
        return np.nan
    if label_std is not None:
        labels = labels * label_std.reshape(1, -1)
        predictions = predictions * label_std.reshape(1, -1)
    predictions = predictions.reshape(-1, predictions.shape[-1])
    labels = labels.reshape(-1, labels.shape[-1])
    mae = mean_absolute_error(labels, predictions)
    return mae


def compute_multiclass_accuracy(predictions, labels):
    if isinstance(predictions, list):
        predictions = np.concatenate(predictions, axis=0)
    if isinstance(labels, list):
        labels = np.concatenate(labels, axis=0)
    labels = labels.reshape(-1)
    pred_classes = np.argmax(predictions, axis=-1).reshape(-1)
    acc = np.mean(pred_classes == labels)
    return acc