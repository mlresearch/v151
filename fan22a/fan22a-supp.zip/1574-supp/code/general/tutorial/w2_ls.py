from collections import namedtuple
import cbp.utils.np_utils as npu
import matplotlib.pyplot as plt
import numpy as np
from cbp.graph import MOTGraph
from cbp.node import MOTCluster, MOTSeperator, VarNode

from cbp.graph.coef_policy import bp_policy
from matplotlib.lines import Line2D
from mpl_toolkits.mplot3d import Axes3D
from scipy.ndimage import gaussian_filter1d
import time

from tutorial.w2_ls_builder import W2LsBuilder

PLTLine = namedtuple('PLTLine', ['x', 'density', 'color'])


class VizDist:
    def __init__(self, num_sample, locs):
        self.num_sample = num_sample
        self.bin_locs = locs
        self.lines = []

    def add_line(self, x, density, color='blue'):
        self.lines.append(PLTLine(x / (self.num_sample - 1), density, color))

    def plot(self, name='wasserstein_ls_sq.png'):
        fig = plt.figure()
        ax = fig.gca(projection='3d')
        len_x = len(self.bin_locs)
        for line in self.lines:
            if line.color == 'blue':
                alpha = 0.4
            else:
                alpha = 0.8
            ax.plot(np.ones(len_x) * line.x, self.bin_locs, line.density,
                    line.color, alpha=alpha)

        ax.legend([Line2D([0], [0], color='blue'), Line2D(
            [0], [0], color='red')], ['Ground Truth', 'Estimated Interpolation'])
        ax.view_init(60, 300)
        plt.show()
        plt.savefig(name)
        plt.close()


class BuildMOTLsPotential:
    def __init__(self, num_dim, locs):
        tensor_shape = (num_dim, num_dim, num_dim)
        self.inter_point = npu.nd_expand(locs, tensor_shape, 1)
        self.start_point = npu.nd_expand(locs, tensor_shape, 0)
        self.end_point = npu.nd_expand(locs, tensor_shape, 2)

    def tri_potential(self, per_start):
        diff = self.inter_point - per_start * self.start_point - \
            (1 - per_start) * self.end_point
        return np.power(diff, 2)

    def bi_potential(self):
        start_point = self.start_point[:, :, 0]
        end_point = self.end_point[0, :, :]
        return np.power(start_point - end_point, 2)


def construct_dist(num_dim, num_sample):
    start = np.zeros(num_dim)
    end = np.zeros(num_dim)
    for i in range(int(num_dim / 2), num_dim, 5):
        start[i] = num_dim - i
    start[int(num_dim / 3)] = (num_dim) / 3
    for i in range(0, int(num_dim / 2), 5):
        end[i] = i
    end[int(2 * num_dim / 3)] = (num_dim) / 3
    start_dist = gaussian_filter1d(start, 5)
    end_dist = gaussian_filter1d(end, 5)

    interpolater = DistInterpolate(
        start_dist, end_dist, num_dim, np.linspace(
            0, 1, num_dim))

    rtn_list = [start_dist]
    for i in range(1, num_sample - 1):
        rtn_list.append(interpolater.interpolate(1 - i / (num_sample - 1)))

    rtn_list.append(end_dist)
    return np.array(rtn_list)


class DistInterpolate:
    def __init__(self, start_dist, end_dist, num_dim, locs):
        ex_shape = (num_dim, num_dim)
        self.start_dist = npu.nd_expand(start_dist, ex_shape, 0)
        self.end_dist = npu.nd_expand(end_dist, ex_shape, 1)
        self.dist = (self.start_dist * self.end_dist).flatten()
        self.start_val = npu.nd_expand(locs, ex_shape, 0)
        self.end_val = npu.nd_expand(locs, ex_shape, 1)
        self.locs = np.append(locs, [1.01])

    def interpolate(self, per_start):
        val = (self.start_val * per_start +
               self.end_val * (1 - per_start)).flatten()
        rtn_dist, _ = np.histogram(val, self.locs, weights=self.dist)
        return rtn_dist


class TestMotLeastSq:
    def __init__(self, m=7, n=10, random_state=1):
        # self.strength = 50000
        self.rng = np.random.RandomState(random_state)
        self.dim = n
        self.num_sample = m  # * This is actually N+2 in our note
        self.locs = np.linspace(0, 1.0, self.dim)
        self.viz = VizDist(self.num_sample, self.locs)
        self.varnode = {}
        self.construct_var()
        self.potential_maker = BuildMOTLsPotential(self.dim, self.locs)
        # self.is_penalty = True

    def random_marginal_seed(self):
        log_probability = self.rng.normal(size=self.dim)
        probability = np.exp(log_probability)
        return probability / np.sum(probability)

    def random_marginal_no_seed(self):
        log_probability = np.random.normal(size=self.dim)
        probability = np.exp(log_probability)
        return probability / np.sum(probability)

    def random_marginal(self):
        log_probability = self.rng.normal(size=self.dim)
        probability = np.exp(log_probability)
        return probability / np.sum(probability)

    def construct_var(self):
        for i in range(0, self.num_sample):
            if i > 0 and i < self.num_sample - 1:
                node = VarNode(
                    rv_dim=self.dim,
                    constrained_marginal=self.random_marginal_seed())
            else:
                node = VarNode(
                    rv_dim=self.dim,
                    constrained_marginal=self.random_marginal_no_seed())
            node.format_name(f"VarNode_{i:03d}")
            self.varnode[node.name] = node

        for i in [0, self.num_sample - 1]:
            node = self.varnode[f"VarNode_{i:03d}"]
            self.viz.add_line(i, node.constrained_marginal)

    def cal_potential(self, i, inverse_eta=5000):
        potential = self.potential_maker.tri_potential(
            1 - i / (self.num_sample - 1)) + 10 * self.potential_maker.bi_potential() / (self.num_sample - 2)
        # * promises the largest cost is 1
        potential /= potential.max()
        # print("potential", potential.min(), potential.max())
        # *This potential is actually C
        return np.exp(-inverse_eta * potential)

    def constuct_graph(self):
        motgraph = MOTGraph()
        node_start, node_end = VarNode(self.dim), VarNode(self.dim)
        node_start.format_name("VarNode_000")
        node_end.format_name(f"VarNode_{self.num_sample-1:03d}")
        center_sep = MOTSeperator([node_start, node_end])
        motgraph.add_seperator(center_sep)
        leaf_list = np.arange(1, self.num_sample - 1)
        inv_eta = 2 * (self.num_sample) * \
            np.log(self.dim) / motgraph.cfg.itsbp_outer_tolerance
        motgraph.inv_eta = inv_eta

        for i in leaf_list:
            cur_var = self.varnode[f"VarNode_{i:03d}"]
            sep = MOTSeperator([cur_var])
            motgraph.add_seperator(sep)

            cluster_p = self.cal_potential(i, inv_eta)
            cluster = MOTCluster(
                [center_sep.name, sep.name],
                [node_start, cur_var, node_end],
                # * adds inv_eta here.
                potential=cluster_p)
            motgraph.add_cluster(cluster)
            leaf = MOTCluster([sep.name], [cur_var])
            motgraph.add_cluster(leaf)

            self.viz.add_line(i, cur_var.constrained_marginal)

        motgraph.bake()
        # motgraph.plot("data/least_sq.png")
        print("Finish build graph")
        return motgraph, leaf_list

    def run(self):
        mot, x_array = self.constuct_graph()
        # mot.plot("mot-graph.png")
        print(mot)
        start = time.time()
        eps, steps, _ = mot.itsbp()
        # total_cost = 0
        total_cost = get_total_cost(mot)
        end = time.time()

        return steps, end - start, total_cost


def get_total_cost(graph):
    total_cost = 0
    for _, f_node in graph.factornode_recorder.items():
        factor_marginal = f_node.marginal(
        )
        C_B = factor_marginal * (
            -np.log(f_node.potential) / graph.inv_eta)
        C_B[C_B < 0] = 0
        print(factor_marginal.sum(), C_B.min(), C_B.shape)
        if C_B.ndim > 1:
            total_cost += C_B.sum()
    return total_cost


if __name__ == "__main__":
    for name_type in ['bp', 'Sinkhorn']:
        num_outer_iter = 1
        num_inner_iter = 4

        m_value = 5
        n_start = 20
        n_step = 10

        run_time_list = np.zeros([num_inner_iter, num_outer_iter])
        for repeat in range(num_outer_iter + 1):
            for idx in range(num_inner_iter):
                if name_type == 'bp':
                    wass_least_sq = TestMotLeastSq(
                        m=m_value, n=n_start + n_step * idx, random_state=repeat)
                    steps, run_time, total_cost = wass_least_sq.run()
                else:
                    graph = W2LsBuilder(
                        m=m_value, node_dim=n_start + n_step * idx, policy=bp_policy, rand_seed=repeat)()

                    graph.bake()
                    start = time.time()
                    eps, steps, _ = graph.sinkhorn(
                        max_iter=500000,
                        tolerance=graph.cfg.itsbp_outer_tolerance / 8)

                    end = time.time()
                    run_time = end - start
                    total_cost = get_total_cost(graph)

                run_time_list[idx, repeat - 1] = run_time
                print("steps:", steps, "time:", run_time)
                print("steps:", steps, "cost:", total_cost)

        np.save(f'draw/{name_type}_n_change.npy', run_time_list)
        result = np.load(f'draw/{name_type}_n_change.npy')
        print(result.mean(axis=1), result.std(axis=1))

    for name_type in ['bp', 'Sinkhorn']:
        num_outer_iter = 5
        num_inner_iter = 4

        n_value = 10
        m_start = 5
        m_step = 1

        run_time_list = np.zeros([num_inner_iter, num_outer_iter])
        for repeat in range(num_outer_iter + 1):
            for idx in range(num_inner_iter):
                if name_type == 'bp':
                    wass_least_sq = TestMotLeastSq(
                        m=m_start + idx * m_step, n=n_value, random_state=repeat)
                    steps, run_time = wass_least_sq.run()
                else:
                    graph = W2LsBuilder(
                        m=m_start + idx * m_step, node_dim=n_value, policy=bp_policy, rand_seed=repeat)()

                    graph.bake()

                    start = time.time()
                    eps, steps, _ = graph.sinkhorn(
                        max_iter=500000,
                        tolerance=graph.cfg.itsbp_outer_tolerance / 8)
                    total_cost = get_total_cost(graph)
                    end = time.time()
                    run_time = end - start

                run_time_list[idx, repeat - 1] = run_time
                print("steps:", steps, "time:", run_time)

        np.save(f'draw/{name_type}_m_change.npy', run_time_list)
        result = np.load(f'draw/{name_type}_m_change.npy')
        print(result.mean(axis=1), result.std(axis=1))
