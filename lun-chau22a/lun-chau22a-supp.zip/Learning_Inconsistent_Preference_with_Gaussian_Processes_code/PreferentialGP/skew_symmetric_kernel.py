import numpy as np
import torch
from gpytorch.kernels import RBFKernel, MaternKernel, LinearKernel

class SkewKernel_simple(object):
    def __init__(self, comp_ls, phi, kernel_choice='rbf', cuda=False):

        if kernel_choice == 'rbf':
            if cuda == True:
                self.kernel = RBFKernel().cuda()
                self.kernel.lengthscale = 2
            else:
                self.kernel = RBFKernel()
                self.kernel.lengthscale = 2
        elif kernel_choice == 'Matern':
            self.kernel = MaternKernel()
        self.comp_ls = comp_ls
        self.phi = phi
        self.cuda = cuda

    def fit_kernel(self):
        if self.cuda:
            RBF = self.kernel(self.phi).evaluate().cuda()
            m = len(self.comp_ls)
            T = torch.zeros((m, m), requires_grad=False).cuda()
        else:
            RBF = self.kernel(self.phi).evaluate()
            m = len(self.comp_ls)
            T = torch.zeros((m, m), requires_grad=False)

        for i in range(m):
            for j in range(m):
                x1, x2 = self.comp_ls[i]
                l1, l2 = self.comp_ls[j]

                T[i, j] = RBF[x1, l1] + RBF[x2, l2] - RBF[x1, l2] - RBF[x2, l1]

        return T

class SkewKernel(object):
    def __init__(self, comp_ls, phi, kernel_choice='rbf', cuda=False):

        if kernel_choice == 'rbf':
            if cuda == True:
                self.kernel = RBFKernel().cuda()
                self.kernel.lengthscale = 2
            else:
                self.kernel = RBFKernel()
                self.kernel.lengthscale = 2
        elif kernel_choice == 'Matern':
            self.kernel = MaternKernel()
        self.comp_ls = comp_ls
        self.phi = phi
        self.cuda = cuda

    def fit_kernel(self):
        if self.cuda:
            RBF = self.kernel(self.phi).evaluate().cuda()
            m = len(self.comp_ls)
            T = torch.zeros((m, m), requires_grad=False).cuda()
        else:
            RBF = self.kernel(self.phi).evaluate()
            m = len(self.comp_ls)
            T = torch.zeros((m, m), requires_grad=False)

        for i in range(m):
            for j in range(m):
                x1, x2 = self.comp_ls[i]
                l1, l2 = self.comp_ls[j]

                T[i, j] = RBF[x1, l1] * RBF[x2, l2] - RBF[x1, l2] * RBF[x2, l1]

        return T
