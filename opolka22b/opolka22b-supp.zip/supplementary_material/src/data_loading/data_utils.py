import numpy as np
import networkx as nx
from gensim.models import Word2Vec
from node2vec import node2vec


def _generate_node2vec_embeddings(adj_matrix, emb_size, negative_injection,
                                  neg_train_edges):
    adj_matrix[np.diag_indices(adj_matrix.shape[0])] = 0.0
    if negative_injection:
        adj_matrix = adj_matrix.copy()
        adj_matrix[neg_train_edges[:, 0]][:, neg_train_edges[:, 1]] = 1.0
        adj_matrix[neg_train_edges[:, 1]][:, neg_train_edges[:, 0]] = 1.0
    nx_graph = nx.from_scipy_sparse_matrix(adj_matrix)
    graph = node2vec.Graph(nx_graph, is_directed=False, p=1, q=1)
    graph.preprocess_transition_probs()
    walks = graph.simulate_walks(num_walks=10, walk_length=80)
    walks = [list(map(str, walk)) for walk in walks]
    model = Word2Vec(walks, size=emb_size, window=10, min_count=0, sg=1,
                     workers=1, iter=1)
    wv = model.wv
    embeddings = np.zeros([adj_matrix.shape[0], emb_size], dtype=np.float32)
    sum_embeddings = 0
    empty_list = []
    for i in range(adj_matrix.shape[0]):
        if str(i) in wv:
            embeddings[i] = wv.word_vec(str(i))
            sum_embeddings += embeddings[i]
        else:
            empty_list.append(i)
    mean_embedding = sum_embeddings / (adj_matrix.shape[0] - len(empty_list))
    embeddings[empty_list] = mean_embedding
    return embeddings


def subsample_neighbors(node_idcs, sample_sizes, adj_list_mat):
    """
    Given a set of node indices, this method samples a fixed number of
    neighbors for each of the nodes. Depending on the input, it may
    recursively sample a fixed number of neighbors for the nodes that have
    just been sampled.
    :param node_idcs: Numpy array of indices of central nodes for which
    neighbors should be sampled.
    :param sample_sizes: Tuple or list of integers. The first entry
    specifies the number of neighbors to sample from the one-hop
    neighborhood, the second entry specifies the number of neighbors to
    sample from the two-hop neighborhood etc.
    :param adj_list_mat: Array of shape [N, max_degree] listing for each
    node the indices of its neighboring nodes.
    :return:
    """
    sample_size = sample_sizes[0]
    neighbors = adj_list_mat[node_idcs]
    # shuffle columns
    np.random.shuffle(neighbors.T)
    sampled_neighbors = neighbors[:, :sample_size]  # Shape [B, sample_size]
    subgraph_node_idcs = np.unique(np.concatenate(
            (node_idcs, sampled_neighbors.reshape(-1)), axis=0))
    if len(sample_sizes) > 1:
        return subsample_neighbors(subgraph_node_idcs, sample_sizes[1:],
                                   adj_list_mat)
    return subgraph_node_idcs


def get_adj_list_matrix(adj_matrix):
    """
    Given a NxN SciPy sparse adjacency matrix returns a dense adjacency list
    matrix of shape [N, max_degree] where each row i contains the node indices
    of neighbors of i. If node i has less than max_degree neighbors, some of
    its neighbors are randomly resampled.
    """
    adj_matrix[np.diag_indices(adj_matrix.shape[0])] = 0.0
    max_degree = int(np.max(np.sum(adj_matrix, axis=0)))
    adj_matrix.eliminate_zeros()
    adj_matrix = adj_matrix.tolil()
    rows = []
    for idx, neighbors in enumerate(adj_matrix.rows):
        if len(neighbors) == 0:     # isolated node
            rows.append(np.array([idx for _ in range(max_degree)]))
            continue
        num_additional = int(max_degree - len(neighbors))
        add_samples = np.random.choice(neighbors, size=num_additional)
        row = np.concatenate((neighbors, add_samples), axis=0)
        np.random.shuffle(row)
        rows.append(row)
    adj_list_mat = np.array(rows)
    return adj_list_mat


def get_subgraph_matrix(adj_matrix, num_hops):
    """
    Given a NxN SciPy sparse adjacency matrix, computes a NxN dense matrix
    that indicates for each node its neighbors in the K hop neighborhood,
    where K=num_hops.
    """
    adj_matrix[np.diag_indices(adj_matrix.shape[0])] = 1.0
    power = adj_matrix
    for hop in range(num_hops - 1):
        power = power.dot(adj_matrix)
    subgraph_matrix = np.array(power.todense())
    subgraph_matrix[subgraph_matrix > 0.0] = 1.0
    subgraph_matrix = subgraph_matrix.astype(np.bool)
    return subgraph_matrix


def get_subgraph_matrix_sparse(adj_matrix, num_hops):
    """
    Same as `get_subgraph_matrix` but only returns the indices of shape [N, 2]
    of non-zero indices in the subgraph matrix.
    """
    adj_matrix[np.diag_indices(adj_matrix.shape[0])] = 1.0
    power = adj_matrix
    for hop in range(num_hops - 1):
        power = power.dot(adj_matrix)
    power = power.tocoo()
    return np.stack((power.row, power.col), axis=-1)


# def get_subgraph_information(adj_matrix, num_hops, one_diag=True):
#     """
#     Given an NxN SciPy sparse adjacency matrix, computes which nodes are in the
#     K-hop neighborhood of each node, where K=num_hops.
#     :return:
#     - offsets: Array of shape (N) where the ith entry indicates at which
#      position in the indices array the neighbors of the ith node start. E.g. an
#      offset array [8, 15, ...] means that the first neighbor of the second node
#      is at position 8 in indices, the first neighbor of the third node is at
#      position 15 in indices, etc. The last entry in offset should be equal to
#      the length of indices.
#     - indices: Array of shape (P) of indices of the neighboring nodes.
#     """
#     if one_diag is True:
#         adj_matrix[np.diag_indices(adj_matrix.shape[0])] = 1.0
#     power = adj_matrix
#     for hop in range(num_hops - 1):
#         power = power.dot(adj_matrix)
#     power = power.tolil()
#     offsets = np.cumsum(np.array(list(map(lambda x: len(x), power.rows))))
#     indices = np.concatenate(power.rows, axis=0)
#     assert offsets[-1] == len(indices)
#     return offsets, indices


# def get_neighborhood_matrix(adj_matrix, max_hops):
#     """
#     Given an NxN SciPy sparse adjacency matrix, computes the neighborhood
#     matrix. That is an NxN sparse matrix where each element (i, j) indicates
#     the minimum number of hops required to get from i to j. Only considers up
#     to max_hops.
#     """
#     adj_matrix[np.diag_indices(adj_matrix.shape[0])] = 0.0
#     neighb_mat = adj_matrix.copy()
#     power = adj_matrix
#     for hop in range(max_hops - 1):
#         # power matrix indicating where element (i, j) indicates how many paths
#         # there are from node i to node j in exactly (hop+2) hops without loops
#         power = power.dot(adj_matrix)
#         # reachable_mat is like power but all non-zero elements are replaced
#         # by the current max hop, which is hop+2.
#         reachable_mat = power.copy()
#         reachable_mat[reachable_mat > 0.0] = hop+2
#         # Add reachable_mat onto neigh_mat. Elements that were 0 before (i.e.
#         # could not be reached with less than hop+2 hops) have the value hop+2
#         # now (hence now indicating the the minimum number of hops required to
#         # get from i to j). Elements that were non-zero before will have a
#         # value greater than hop+2. To ensure they also indicate the minimum
#         # number of hops required to reach them, we subtract hop+2 from them.
#         neighb_mat = neighb_mat + reachable_mat
#         neighb_mat.data[neighb_mat.data > hop+2] = neighb_mat.data[neighb_mat.data > hop+2]  - (hop+2)
#     neighb_mat[np.diag_indices(adj_matrix.shape[0])] = 0.0
#     return neighb_mat