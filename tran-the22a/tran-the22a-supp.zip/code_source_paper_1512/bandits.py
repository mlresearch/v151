"""
Interface to bandit problems.
"""

import numpy as np
import test_fns


def gaussian_noise_fn(noise):
    return lambda: np.random.randn() * noise


def uniform_noise_fn(noise):
    return lambda: (np.random.rand(1).item() * 2 - 1) * noise


_noises = {
    'gaussian': gaussian_noise_fn,
    'uniform': uniform_noise_fn,
}
