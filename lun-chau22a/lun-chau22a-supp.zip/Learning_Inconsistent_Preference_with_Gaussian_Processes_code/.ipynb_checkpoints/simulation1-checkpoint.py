"""
Simulation 1:

We generate some static features for every players along
with different latent states Z that govern how the pairwise comparisons are done.

A beta matrix of size len(Z) x len(Z) for which each entries are the corresponding
linear coef governing how each comparisons are made

thus

skill1, skill2 = X[[i,j],:] @ beta_mat[(latent_i, latent_j)]

Data simulated this way contains tons of cycles and their signals
will weight equally in the system
"""

from PreferentialGP.utility import include_sparsity, experiment0, preprocessingC, generate_match

import sys
sys.path.append("/src/")
import pickle
import os
os.environ['KMP_DUPLICATE_LIB_OK']='True'

from PreferentialGP.SkewSymGP import skewsymGaussianProcess_Cuda
from src.spektrankers import *
from gpytorch.kernels import RBFKernel


if __name__ == '__main__':

    n = 50
    p = 5

    num_experiments = 10
    sparsity_vec = [0, 0.3, 0.6, 0.9]
    n_states_ls = [1, 2, 5]

    results_dict = dict()

    for epoch in range(num_experiments):
        print(epoch)
        results_dict[epoch] = dict()
        for sparsity in sparsity_vec:
            for n_states in n_states_ls:
                X, beta_dict, latent_states = experiment0(n, p, n_states)
                kernel = RBFKernel()
                K = kernel(torch.tensor(X)).evaluate().detach().numpy()
                C = generate_match(X, beta_dict, latent_states)

                C_sparse = include_sparsity(C, sparsity)
                choix_ls, y_ls = preprocessingC(C_sparse)

                # Setup the comparison methods

                # 1. SkewGP
                skewgp = skewsymGaussianProcess_Cuda(choix_ls, y_ls, X)
                skewgp.fit(50000, 1e-4)
                sigma = torch.nn.Sigmoid()
                pred = (sigma(skewgp.posterior_mean).cpu().numpy() > 0.5) * 1

                skewgp_accuracy = pred[: int(len(y_ls)/2)].mean()

                # 2. BinSVD
                bsvd = BinSVDKCovSGD(C, K, epoch=1000, lr=1e3, verbose=False)
                bsvd.fit()

                bsvd_accuracy = 1 - np.min(np.abs(compute_upsets(bsvd.r, C, verbose=False)))

                # 3. Serial Rank
                ser = SerialRank(C)
                ser.fit()

                serial_accuracy = 1 - np.min(np.abs(compute_upsets(ser.r, C, verbose=False)))

                # 4. SVDKCov
                svdk = SVDRankerNKCov(C, K, verbose=False)
                svdk.fit()

                svdk_accuracy = 1 - np.min(np.abs(compute_upsets(svdk.r, C, verbose=False)))

                # 5. SVDCov
                svdc = SVDRankerNCov(C, X, verbose=False)
                svdc.fit()

                svdc_accuracy = 1 - np.min(np.abs(compute_upsets(svdc.r, C, verbose=False)))

                # Gathering Accuracies
                results_dict[epoch][(sparsity, n_states)] = [skewgp_accuracy,
                                                             bsvd_accuracy,
                                                             serial_accuracy,
                                                             svdk_accuracy,
                                                             svdc_accuracy
                                                             ]

                print(results_dict)

    with open("./simulations_equal_signal.pickle", "wb") as f:
        pickle.dump(results_dict, f)