## helper functions: compute best subset search
helper.func <- function(z, Y, Theta, J,mtd="exhaustive"){
  leaps::regsubsets(x = Y[, Theta, drop = F],
                    y = Y[, z, drop = F],
                    method=mtd,
                    nbest = 1,
                    nvmax = min(J, sum(Theta > 0)),
                    intercept = F, really.big = T)
}

## Lasso for conditional variance estimation
lasso.func = function(z, Y, Theta) {
  est = cv.glmnet(Y[,Theta], Y[,z], nfold=3, intercept=FALSE, parallel=TRUE)
  return(mean((predict(est, Y[,Theta]) - Y[,z])^2))
}

## EqVar topological ordering
getOrdering <- function(Y, J){
  p <- dim(Y)[2]
  variances <- apply(Y, MAR = 2, sd)
  Theta <- rep(0, p)
  Theta[1] <- which.min(variances)
  out <- sapply(setdiff(1:p, Theta[1]),
                function(z){
                  sum(resid(RcppEigen
                            ::fastLm(Y[, z] ~ Y[, Theta[1], drop = F]) )^2)})
  Theta[2] <- setdiff(1:p, Theta[1])[which.min(out)]
  for(i in 3:p){
    out <- lapply(setdiff(1:p, Theta),
                  function(jj)helper.func(jj, Y, Theta[seq(i-1)], J))
    nextRoot <- which.min(sapply(out,function(x){min(x$rss)}))
    Theta[i] <- setdiff(1:p, Theta)[nextRoot]
  }
  return(Theta)
}

## EqVar topological ordering with lasso
getOrdering.lasso <- function(Y){
  p <- dim(Y)[2]
  variances <- apply(Y, MAR = 2, sd)
  Theta <- rep(0, p)
  Theta[1] <- which.min(variances)
  out <- sapply(setdiff(1:p, Theta[1]),
                function(z){
                  sum(resid(RcppEigen
                            ::fastLm(Y[, z] ~ Y[, Theta[1], drop = F]) )^2)})
  Theta[2] <- setdiff(1:p, Theta[1])[which.min(out)]
  for(i in 3:p){
    print(i)
    out <- sapply(setdiff(1:p, Theta),
                  function(jj)lasso.func(jj,Y,Theta[seq(i-1)]))
    Theta[i] <- setdiff(1:p, Theta)[which.min(out)]
  }
  return(Theta)
}

## BSS find parents
find.parents = function(X, TO, q) {
  p = length(TO)
  est = matrix(0, nrow = p, ncol = p)
  # Second node
  node = TO[2]
  possible.parent = TO[1]
  mylm0 = lm(X[, node] ~ 0)
  mylm1 = lm(X[, node] ~ X[, possible.parent] + 0)
  if (BIC(mylm1) < BIC(mylm0)) {
    est[possible.parent, node] = 1
  }
  # main loop
  for (i in 3:p) {
    node = TO[i]
    possible.parent = TO[1:(i-1)]
    out = leaps::regsubsets(x = X[, possible.parent],
                            y = X[, node],
                            method='exhaustive',
                            nbest = 1,
                            nvmax = q,
                            intercept = F, really.big = T)
    out2 = summary(out)
    if (min(out2$bic) < 0) {
      est[possible.parent[out2$which[which.min(out2$bic),]], node] = 1
    }
  }
  return(est)
}

### Data generation

randomDAG2_chain <- function(p, q)
{
  DAG <- diag(rep(0,p))
  causalOrder <- sample(p)
  DAG[causalOrder[1],causalOrder[2]] <- 1
  for(i in 3:(p))
  {
    node <- causalOrder[i]
    possibleParents <- causalOrder[1:(i-1)]
    Parents <- sample(possibleParents,min(length(possibleParents),q))
    DAG[Parents,node] <- rep(1,length(Parents))
  }
  return(list(DAG=DAG,TO=causalOrder))
}



simu_DAG = function(p, q, pc, type) {
  if (type=='hub'){
    D <- randomDAG2_hub(p,pc)
  } else if (type=='chain') {
    D <- randomDAG2_chain(p,q)
  } else {
    D <- randomDAG2_er(p,pc)
  }
  truth <- D$DAG
  TO <- D$TO
  return(list(truth=truth,TO=TO))
}

simu_data<-function(n, p, err, dag, betamin=0.5, sd=0.3){
  if (err == 'nong'){
    errs <- matrix((rbinom(p * n,1,0.5)*2-1)*sqrt(0.8), nrow = p, ncol = n)
  } else if (err == 'gaussian') {
    errs <- matrix(rnorm(p * n, sd=sd), nrow = p, ncol = n)
  } else {
    print('not this err!')
  }
  B <- t(dag$truth)
  B[B==1] <- runif(sum(dag$truth),betamin,1)*(2*rbinom(sum(dag$truth),1,0.5)-1)
  X <- solve(diag(rep(1, p)) - B, errs)
  X <- t(X)
  return(list(B=B,X=X))
}


computeCausOrder <- function(G)
  # Copyright (c) 2013  Jonas Peters  [peters@stat.math.ethz.ch]
  # All rights reserved.  See the file COPYING for license terms.
{
  p <- dim(G)[2]
  remaining <- 1:p
  causOrder <- rep(NA,p)
  for(i in 1:(p-1))
  {
    root <- min(which(colSums(G) == 0))
    causOrder[i] <- remaining[root]
    remaining <- remaining[-root]
    G <- G[-root,-root]
  }
  causOrder[p] <- remaining[1]
  return(causOrder)
}

test_order = function(topo_order, adj){
  edges = which(adj == 1, arr.ind = T)
  order_Index = order(topo_order)
  count = 0
  for (i in 1:nrow(edges)) {
    if (order_Index[edges[i,1]] > order_Index[edges[i,2]]) {
      count = count + 1
    }
  }
  return(list(right = as.numeric(count==0), count = count))
}

EqVarDAG_TD_internal<-function(X){
  n<-dim(X)[1]
  p<-dim(X)[2]
  done<-p+1
  S<-cov(X)
  Sinv<-solve(S)
  for(i in 1:p){
    varmap<-seq(p)[-done]
    v<-which.min(diag(solve(Sinv[-done,-done])))[1]
    done<-c(done,varmap[v])
  }
  return(done[-1])
}

SHD = function(G_est, G_true){
  pred = which(G_est == 1)
  cond = which(G_true != 0)
  cond_reversed = which(t(G_true) != 0)
  extra = setdiff(pred, cond)
  reverse = intersect(extra, cond_reversed)
  gig_true = G_true + t(G_true)
  gig_est = G_est + t(G_est)
  gig_true[upper.tri(gig_true)] = 0
  gig_est[upper.tri(gig_est)] = 0
  pred_lower = which(gig_true != 0)
  cond_lower = which(gig_est != 0)
  extra_lower = setdiff(pred_lower, cond_lower)
  missing_lower = setdiff(cond_lower, pred_lower)
  shd = length(extra_lower) + length(missing_lower) + length(reverse)
  return(shd)
}

