

# plot average errors
import matplotlib
import matplotlib.pyplot as plt
import numpy as np
#matplotlib.use('TkAgg')

#plt.style.use('seaborn-muted')
import sys
sys.path.append("..")

from util.file_IO import file_IO1

def plot_error_rate(chern_err, bchern_err, rand_err, top2_err, njav_err, num_sources, num_hypo, T, filename):
    plt.style.use('ggplot')
    plt.figure(dpi=200)
    
    
    
    #print(np.average(rand_err, axis=0), range(env.T))
    plt.plot(range(T), np.average(rand_err, axis=0), color = (0.6,0.2,0.3), linewidth = 3.0, label='Unif sampling')
    plt.plot(range(T), np.average(chern_err, axis=0), color = (0.1,0.2,0.3), linewidth = 3.0, label='Chernoff Procedure')
    plt.plot(range(T), np.average(top2_err, axis=0), color = (0.4,0.2,0.6), linewidth = 3.0, label='Top2 likelihood')
    plt.plot(range(T), np.average(njav_err, axis=0), color = (0.7,0.8,0.6), linewidth = 3.0, label='Two-phase')
    
    plt.plot(range(T), np.average(bchern_err, axis=0), color = (0.21,0.34,0.76), linewidth = 3.0, label='BGC')
    
    #plt.errorbar(range(T), np.average(rand_err, axis=0),color = "m", yerr=np.std(rand_err, axis=0), alpha=0.3, label='random sampling') 
    #plt.errorbar(range(T), np.average(chern_err, axis=0),color = "g", yerr=np.std(chern_err, axis=0), alpha=0.3, label='chernoff sampling')
    #plt.errorbar(range(T), np.average(top2_err, axis=0),color = "r",  yerr=np.std(top2_err, axis=0), alpha=0.3, label='top2 likelihood')
    
    
    plt.fill_between(range(T), np.average(rand_err, axis=0) + np.std(rand_err, axis=0),np.clip(np.average(rand_err, axis=0) - np.std(rand_err, axis=0), a_min=0, a_max= None), alpha=0.2, edgecolor=(0.6,0.2,0.3), facecolor=(0.6,0.2,0.3), linewidth=2, linestyle='dashdot', antialiased=True)
    plt.fill_between(range(T), np.average(chern_err, axis=0) + np.std(chern_err, axis=0),np.clip(np.average(chern_err, axis=0) - np.std(chern_err, axis=0), a_min=0, a_max= None), alpha=0.2, edgecolor=(0.1,0.2,0.3), facecolor=(0.1,0.2,0.3), linewidth=2, linestyle='dashdot', antialiased=True)
    plt.fill_between(range(T), np.average(top2_err, axis=0) + np.std(top2_err, axis=0),np.clip(np.average(top2_err, axis=0) - np.std(top2_err, axis=0), a_min=0, a_max= None), alpha=0.2, edgecolor=(0.4,0.2,0.6), facecolor=(0.4,0.2,0.6), linewidth=2, linestyle='dashdot', antialiased=True)
    plt.fill_between(range(T), np.average(njav_err, axis=0) + np.std(njav_err, axis=0),np.clip(np.average(njav_err, axis=0) - np.std(njav_err, axis=0), a_min=0, a_max= None), alpha=0.2, edgecolor=(0.7,0.8,0.6), facecolor=(0.7,0.8,0.6), linewidth=2, linestyle='dashdot', antialiased=True)
     
    #plt.errorbar(range(T), np.average(top2_err, axis=0), yerr=np.std(top2_err, axis=0), fmt='v', marker = 'v', ecolor='g', markerfacecolor='g', markersize=10.0, capsize=6, capthick=2, linewidth = 2, lolims = False, uplims = False, xlolims = False, xuplims = False, label='top2 likelihood')
            
    
    plt.legend()
    plt.xticks(size = 10)
    plt.yticks(size = 10)
    plt.ylabel('Average error rate')
    plt.xlabel('Samples')
    plt.title('{0} Arms, {1} Discretized Parameters'.format(num_sources, num_hypo))
    #plt.grid()
    plt.grid(b=True, which='major', linestyle='-')
    plt.tight_layout()
    plt.xlim(0,300)
    plt.savefig('../plots/error_rate_'+filename+'.png')
    #plt.show()
    


def plot_error_rate1(mm_armerr, u_armerr, total_error_LinGapE, num_sources, num_dims, T, filename):
    
    plt.style.use('ggplot')
    plt.figure(dpi=200)
    
    #print(T)
    #print(np.shape(np.average(mm_armerr, axis=0)),T)
    plt.plot(range(T), np.average(u_armerr, axis=0), color = (0.1,0.4,0.9), linewidth = 1.0, label='Unif')
    plt.plot(range(T), np.average(mm_armerr, axis=0), color = (0.7,0.0,0.9), linewidth = 1.0, label='Max-min')
    plt.plot(range(T), np.average(total_error_LinGapE, axis=0), color = (0.6,0.9,0.6), linewidth = 1.0, label='LinGap-E')
    #plt.plot(range(T), np.average(total_error_XY_static, axis=0), color = (0.2,0.4,0.6), linewidth = 1.0, label='XY-static')
    #plt.plot(range(T), np.average(total_error_A_XY, axis=0), color = (0.3,0.9,0.6), linewidth = 1.0, label='XY-adap')
    
    
    
    
    
    plt.fill_between(range(T), np.average(u_armerr, axis=0) + np.std(u_armerr, axis=0),np.clip(np.average(u_armerr, axis=0) - np.std(u_armerr, axis=0), a_min=0, a_max= None), alpha=0.8, edgecolor=(0.1,0.4,0.9), facecolor=(0.1,0.4,0.9), linewidth=2, linestyle='dashdot', antialiased=True)
    plt.fill_between(range(T), np.average(mm_armerr, axis=0) + np.std(mm_armerr, axis=0),np.clip(np.average(mm_armerr, axis=0) - np.std(mm_armerr, axis=0), a_min=0, a_max= None), alpha=0.5, edgecolor=(0.7,0.0,0.9), facecolor=(0.7,0.0,0.9), linewidth=2, linestyle='dashdot', antialiased=True)
    plt.fill_between(range(T), np.average(total_error_LinGapE, axis=0) + np.std(total_error_LinGapE, axis=0),np.clip(np.average(total_error_LinGapE, axis=0) - np.std(total_error_LinGapE, axis=0), a_min=0, a_max= None), alpha=0.2, edgecolor=(0.6,0.9,0.6), facecolor=(0.6,0.9,0.6), linewidth=2, linestyle='dashdot', antialiased=True)
    #plt.fill_between(range(T), np.average(mm_esterr, axis=0) + np.std(mm_esterr, axis=0),np.clip(np.average(mm_esterr, axis=0) - np.std(mm_esterr, axis=0), a_min=0, a_max= None), alpha=0.4, edgecolor=(0.7,0.0,0.9), facecolor=(0.7,0.0,0.9), linewidth=2, linestyle='dashdot', antialiased=True)
    
    
    plt.legend()
    plt.xticks(size = 10)
    plt.yticks(size = 10)
    plt.ylabel('Average error rate')
    plt.xlabel('Samples')
    plt.title('{0} Arms, {1} Dimension'.format(num_sources,num_dims))
    plt.grid(b=True, which='major', linestyle='-')
    
    plt.xlim(10,1500)
    
    plt.savefig('../plots/error_rate_'+filename+'.png')
    
    #plt.show()

def plot_error_rate2(mm_armerr, u_armerr, total_error_LinGapE, total_error_XY_Static, total_error_XY_Adaptive, num_sources, num_dims, T, filename):
    
    plt.style.use('ggplot')
    plt.figure(dpi=200)
    
    #print(T)
    #print(np.shape(np.average(mm_armerr, axis=0)),T)
    plt.plot(range(T), np.average(u_armerr, axis=0), color = (0.1,0.4,0.9), linewidth = 1.0, label='Unif')
    plt.plot(range(T), np.average(mm_armerr, axis=0), color = (0.7,0.0,0.9), linewidth = 1.0, label='Max-min')
    plt.plot(range(T), np.average(total_error_LinGapE, axis=0), color = (0.6,0.9,0.6), linewidth = 1.0, label='LinGap-E')
    plt.plot(range(T), np.average(total_error_XY_Static, axis=0), color = (0.2,0.4,0.6), linewidth = 1.0, label='XY-static')
    plt.plot(range(T), np.average(total_error_XY_Adaptive, axis=0), color = (0.3,0.9,0.6), linewidth = 1.0, label='XY-adap')
    
    
    
    
    
    plt.fill_between(range(T), np.average(u_armerr, axis=0) + np.std(u_armerr, axis=0),np.clip(np.average(u_armerr, axis=0) - np.std(u_armerr, axis=0), a_min=0, a_max= None), alpha=0.8, edgecolor=(0.1,0.4,0.9), facecolor=(0.1,0.4,0.9), linewidth=2, linestyle='dashdot', antialiased=True)
    plt.fill_between(range(T), np.average(mm_armerr, axis=0) + np.std(mm_armerr, axis=0),np.clip(np.average(mm_armerr, axis=0) - np.std(mm_armerr, axis=0), a_min=0, a_max= None), alpha=0.5, edgecolor=(0.7,0.0,0.9), facecolor=(0.7,0.0,0.9), linewidth=2, linestyle='dashdot', antialiased=True)
    plt.fill_between(range(T), np.average(total_error_LinGapE, axis=0) + np.std(total_error_LinGapE, axis=0),np.clip(np.average(total_error_LinGapE, axis=0) - np.std(total_error_LinGapE, axis=0), a_min=0, a_max= None), alpha=0.2, edgecolor=(0.6,0.9,0.6), facecolor=(0.6,0.9,0.6), linewidth=2, linestyle='dashdot', antialiased=True)
    
    plt.fill_between(range(T), np.average(total_error_XY_Static, axis=0) + np.std(total_error_XY_Static, axis=0),np.clip(np.average(total_error_XY_Static, axis=0) - np.std(total_error_XY_Static, axis=0), a_min=0, a_max= None), alpha=0.2, edgecolor=(0.2,0.4,0.6), facecolor=(0.2,0.4,0.6), linewidth=2, linestyle='dashdot', antialiased=True)
    plt.fill_between(range(T), np.average(total_error_XY_Adaptive, axis=0) + np.std(total_error_XY_Adaptive, axis=0),np.clip(np.average(total_error_XY_Adaptive, axis=0) - np.std(total_error_XY_Adaptive, axis=0), a_min=0, a_max= None), alpha=0.2, edgecolor=(0.3,0.9,0.6), facecolor=(0.3,0.9,0.6), linewidth=2, linestyle='dashdot', antialiased=True)
    
    
    plt.legend()
    plt.xticks(size = 10)
    plt.yticks(size = 10)
    plt.ylabel('Average error rate')
    plt.xlabel('Samples')
    plt.title('{0} Arms, {1} Dimension'.format(num_sources,num_dims))
    plt.grid(b=True, which='major', linestyle='-')
    
    plt.xlim(10,1500)
    
    plt.savefig('../plots/error_rate_'+filename+'.png')
    
    #plt.show()



if __name__ == "__main__":
    
    #top2_err, rand_err, chern_err, njav_err, top2_sample_complexity, rand_sample_complexity, chern_sample_complexity, njav_sample_complexity = file_IO('../main/discrete_env1')
    #plot_error_rate(chern_err, rand_err, top2_err, njav_err, 50, 6, 10000, 'env1')
    
    dim = 12
    mm_armerr, u_armerr, total_error_LinGapE, mm_T, u_T, total_arm_selection = file_IO1('../main/linBandit_dim'+str(dim))
    plot_error_rate1(mm_armerr, u_armerr, total_error_LinGapE, 20, dim, 100000, "linBandit_dim"+str(dim))
   
    
    

    