import numpy as np
import sys
from mpi4py import MPI
import machines
import time

# Usage: optimize_main.py n d filename alg block epsilon num_chunks min_eta epochs step_index sync

# Hyperparameters
n = int(sys.argv[1])
d = int(sys.argv[2])
filename = str(sys.argv[3])
alg = str(sys.argv[4])
block = int(sys.argv[5])
epsilon = float(sys.argv[6])
num_chunks = int(sys.argv[7])
min_eta = float(sys.argv[8])
epochs = int(sys.argv[9])
step_index = int(sys.argv[10])
sync = sys.argv[11]
suffix = sys.argv[12] #"%s_%s_%s.txt" % (n*block, d, sigma)
if sync == "True":
    sync = True
else:
    sync = False
max_its = n*epochs

# MPI SetUp
comm = MPI.COMM_WORLD
rank = comm.Get_rank()
size = comm.Get_size()

sizes = [min_eta*(1.2**i) for i in range(-8, 2)]
chunks_per_worker = int(num_chunks/(size - 1))
samples_per_worker = int(n/(size - 1))

# Master Bookkeeping
if rank == 0:
    f = open("%s/statistics.txt" % filename, 'w', buffering=1)
    fnice = open("%s/statistics_nice.txt" % filename, 'w', buffering=1)
    best_err = np.inf
    best_wallclock = np.inf
    met_eps = False
    print("Logging time before master init: %s" % time.time(), file=sys.stderr, flush=True)
    master = machines.Master(d, size, filename, n, block, None, max_its, alg, xhat_file="xhat_%s.npy" % suffix, epsilon=epsilon, comm=comm)
    print("Logging time after master init: %s" % time.time(), file=sys.stderr, flush=True)
else:
    print("Logging time before worker %s init: %s" % (rank, time.time()), file=sys.stderr, flush=True)
    if alg == 'asaga':
        worker = machines.Worker(rank, d, filename, n, block, alg, comm=comm)
        worker.load_data(num_chunks=num_chunks, chunks_per_worker=num_chunks, data_file="data_%s" % suffix, label_file="labels_%s" % suffix)
    else:
        worker = machines.Worker(rank, d, filename, samples_per_worker, block, alg, comm=comm)
        worker.load_data(num_chunks=num_chunks, chunks_per_worker=chunks_per_worker, data_file="data_%s" % suffix, label_file="labels_%s" % suffix)
    print("Logging time after worker %s init: %s" % (rank, time.time()), file=sys.stderr, flush=True)

# Iterate Through Stepsizes
j = -1
for eta in sizes:
    j+=1
    # if j < 5:
    #     continue
    if j != step_index and step_index != -1:
        continue
    # Master
    if rank == 0:
        master.reset(eta, tag=10*j)
        master.master_init()
        print("Logging time after init: %s" % time.time(), file=sys.stderr, flush=True)
        if sync:
            errors_per_epoch, wallclock, its = master.master_routine_sync()
        else:
            errors_per_epoch, wallclock, its = master.master_routine()
        print("Logging time after run %s" % time.time(), file=sys.stderr, flush=True)
        err = errors_per_epoch[-1]
        f.write("Error after %s iterations with eta = %s %s in %s seconds.\n" % (its, eta, err, wallclock))
        to_write = [its, eta, wallclock] + ['\n']
        fnice.write(" ".join(str(x) for x in to_write))
        if err < best_err:
            best_err = err
        if wallclock < best_wallclock:
            best_wallclock = wallclock
        if met_eps and wallclock/best_wallclock > 1.2:
            print("Aborting from Master because degrading wallclock, while at epsilon.", file=sys.stderr, flush=True)
            comm.Abort()
        elif (err/best_err) > 5:
            print("Aborting from Master because degrading error.", file=sys.stderr, flush=True)
            comm.Abort()

    # Worker
    else:
        worker.reset(tag=10*j)
        worker.worker_init()
        worker.worker_routine()
