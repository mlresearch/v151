
rm(list = ls())

setwd("/Users/oscar/Desktop/2D project/code")

source("utils.R")
source("utils4.R")
library(igraph)
library(factoextra)

n_grid =  c(128,64);
kappa_grid = c(1, 2,0.25);
lambda_grid = 10^seq(-1,3,length= 20)
#### penalty tuning parameter
lambda_grid = 10^seq(-1,3,length= 20)

NMC =  50;

hausdorff_dist =  array(0,c(length(n_grid), length(kappa_grid),4,NMC));
hausdorff_dist2 =  array(0,c(length(n_grid), length(kappa_grid),4,NMC));

#hausdorff_dist_l0 =  zeros(length(n_grid), length(kappa_grid),4,NMC);


hausdorff_dist_average =  array(0,c(length(n_grid), length(kappa_grid),4));
hausdorff_dist_sd =  array(0,c(length(n_grid), length(kappa_grid),4));

hausdorff_dist_average2 =  array(0,c(length(n_grid), length(kappa_grid),4));
hausdorff_dist_sd2 =  array(0,c(length(n_grid), length(kappa_grid),4));


for(ind_n in 1:length(n_grid))
{
  n =  n_grid[ind_n];
  print('n')
  print(n)
  
  for( ind_kappa in 1:length(kappa_grid))
  {
    kappa = kappa_grid[ind_kappa];
    print('kappa')
    print(kappa)
    
    for(scenario in 1:4)
    {
      for(iter in 1:NMC)
      {
        print(paste("iter = ", iter))
        name =  "/Users/oscar/Desktop/CodePlayground-main/ComputerVision/simulations/"
        name = paste(name,"y_ind_n_",as.character(ind_n),sep = '')
        name = paste(name,"ind_kappa",as.character(ind_kappa),sep = '')
        name = paste(name,"scenario",as.character(scenario),sep = '')
        name = paste(name,"iter",as.character(iter),'.txt',sep = '')
        y = read.table(name,sep = ",")
        y = as.numeric(unlist(y))
        y = matrix(y,n,n)
        
        
        name =  "/Users/oscar/Desktop/CodePlayground-main/ComputerVision/simulations/"
        name = paste(name,"theta0_ind_n_",as.character(ind_n),sep = '')
        name = paste(name,"ind_kappa",as.character(ind_kappa),sep = '')
        name = paste(name,"scenario",as.character(scenario),sep = '')
        name = paste(name,"iter",as.character(iter),'.txt',sep = '')
        theta0 = read.table(name,sep = ",")
        theta0 = as.numeric(unlist(theta0))
        theta0 = matrix(theta0,n,n)
        l= log(n)/log(2)
        #Lambad0 = 
          
        ##DCART
          
        R = Dcart_computations_2d(y)
          
        score =  rep(0,length(lambda_grid))
        MSE = rep(0,length(lambda_grid))
        for(j in 1:length(lambda_grid))
        {
          theta = twoD_cart(y,lambda_grid[j],R)
          sigmahat2 = mean(diff(y)^2)/2 
          score[j] = sum((y - theta)^2) +  sigmahat2*length(unique(as.vector(theta)))*log(n^2)
          MSE[j ] =  mean((theta0 -theta)^2)
        }
        best_j =  which.min(score)
        theta_hat = twoD_cart(y,lambda_grid[best_j],R)
        
        aux = unique(as.vector(theta_hat))
        theta_hat_new = theta_hat
        
        if(length(aux)>2)
        {
          temp = kmeans(aux,2)
          temp_clus = temp$cluster
          temp_centers = temp$centers
          
          theta_hat_new = theta_hat
          for(j in 1:length(aux))
          {
            ind = which(theta_hat==aux[j])
            theta_hat_new[ind] =  temp_centers[temp_clus[j]]
          }
        }
        

        
        hausdorff_dist[ind_n,ind_kappa,scenario,iter] = hausdorff(theta0,theta_hat_new) 
      
        ######
        best_j =  which.min(MSE)
        theta_hat = twoD_cart(y,lambda_grid[best_j],R)
        
        aux = unique(as.vector(theta_hat))
        theta_hat_new = theta_hat
        if(length(aux)>2)
        {
          temp = kmeans(aux,2)
          temp_clus = temp$cluster
          temp_centers = temp$centers
          
          theta_hat_new = theta_hat
          for(j in 1:length(aux))
          {
            ind = which(theta_hat==aux[j])
            theta_hat_new[ind] =  temp_centers[temp_clus[j]]
          }
        }
        
        
        hausdorff_dist2[ind_n,ind_kappa,scenario,iter] = hausdorff(theta0,theta_hat_new) 
        
        
        
      }## iter
      ################
      hausdorff_dist_average[ind_n,ind_kappa,scenario] = median(hausdorff_dist[ind_n,ind_kappa,scenario,])
      hausdorff_dist_sd[ind_n,ind_kappa,scenario] = sd(hausdorff_dist[ind_n,ind_kappa,scenario,])
      
      hausdorff_dist_average2[ind_n,ind_kappa,scenario] = median(hausdorff_dist2[ind_n,ind_kappa,scenario,])
      hausdorff_dist_sd2[ind_n,ind_kappa,scenario] = sd(hausdorff_dist2[ind_n,ind_kappa,scenario,])
      
      print("Hausdorff")
      print( hausdorff_dist_average[ind_n,ind_kappa,scenario])
      print( hausdorff_dist_sd[ind_n,ind_kappa,scenario])
      
      print("Hausdorff2")
      print( hausdorff_dist_average2[ind_n,ind_kappa,scenario])
      print( hausdorff_dist_sd2[ind_n,ind_kappa,scenario])
    }
  }
  
  
}

write.table(hausdorff_dist_average,"hausdorff_dist_average_R.txt")
write.table(hausdorff_dist_average2,"hausdorff_dist_average2_R.txt")
