import os
import json
import logging
import argparse

from task.task_wrapper import TaskWrapper
from utils.multiprocess_logger import MultiprocessingLoggerManager


def main():

    parser = argparse.ArgumentParser()
    parser.add_argument("--name", default="create-datasets", help="Name of the experiment")
    parser.add_argument("--save_path", default="./results/", type=str, help="Folder where to save results")
    parser.add_argument("--data_path", default="./cache", type=str, help="Folder where cached data is saved")
    args = parser.parse_args()

    exp_name = args.name
    experiment_name = exp_name
    experiment = "%s/%s" % (args.save_path, experiment_name)

    # Create the experiment folder
    if not os.path.exists(experiment):
        os.makedirs(experiment)

    # Define log settings
    log_path = experiment + '/create_dataset.log'
    multiprocess_logging_manager = MultiprocessingLoggerManager(
        file_path=log_path, logging_level=logging.INFO)
    master_logger = multiprocess_logging_manager.get_logger("Master")
    master_logger.log("----------------------------------------------------------------")
    master_logger.log("                    STARING NEW EXPERIMENT                      ")
    master_logger.log("----------------------------------------------------------------")
    master_logger.log("Experiment Name %r" % exp_name)

    master_logger.log("START SCRIPT CONTENTS")
    with open(__file__) as f:
        for line in f.readlines():
            master_logger.log(">>> " + line.strip())
    master_logger.log("END SCRIPT CONTENTS")

    task_names = ["wiki-3029"]

    for task_name in task_names:

        master_logger.log("Create dataset for task: %s" % task_name)

        # Read configuration and constant files. Configuration contain environment information and
        # constant file contains hyperparameters for the model and learning algorithm.
        with open("data/%s/config.json" % task_name) as f:
            config = json.load(f)
            # Add command line arguments. Command line arguments supersede file settings.

            config["data_path"] = args.data_path
            config["save_path"] = experiment
            config["exp_name"] = experiment_name

        print(json.dumps(config, indent=2))

        # log core experiment details
        master_logger.log("CONFIG DETAILS")
        for k, v in sorted(config.items()):
            master_logger.log("    %s --- %r" % (k, v))

        TaskWrapper.make_task(config, task_name, master_logger)
        master_logger.log("Task Named %s Created" % task_name)


if __name__ == "__main__":

    print("SETTING THE START METHOD ")
    main()
