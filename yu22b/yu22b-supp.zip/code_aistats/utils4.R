Dcart_computations_2d =  function(y)
{
  n = dim(y)[1]
  R = list()
  OPT = list()
  SPLT = list()
  
  
  p = log(n)/log(2)
  
  
  for(j in 0:p)
  {
    R[[j+1]] = list()
    
    for(i in 0:p)
    {
      R[[j+1]][[i+1]] = list()
      
      
      for(l in 1:2^j)
      {
        R[[j+1]][[i+1]][[l]] = list()
        
        for(k in 1:2^i)
        { 
          #R[[j+1]] = list()
          #R[[j+1]][[i+1]] = list()
          #R[[j+1]][[i+1]][[l]] = list()
          #R[[j+1]][[i+1]][[l]][[k]] = list()
          R[[j+1]][[i+1]][[l]][[k]] = mean(y[((l-1)*n/2^{j}+1):(l*n/2^{j}),((k-1)*n/2^{i}+1):(k*n/2^{i})  ])
        }
      }
    }
  }
  return(R)
}



twoD_cart =  function(y,lambda,R,h=0)
{
  n = dim(y)[1]
  p = log(n)/log(2)
  
  OPT = list()
  SPLT = list()
  
  
  OPT[[p+1]] = list()
  OPT[[p+1]][[p+1]] = list()
  
  SPLT[[p+1]] = list()
  SPLT[[p+1]][[p+1]] = list()
  
  for(l in 1:2^p)
  {
    OPT[[p+1]][[p+1]][[l]] = list()
    SPLT[[p+1]][[p+1]][[l]] = list()
    
    for(k in 1:2^p)
    { 
      OPT[[p+1]][[p+1]][[l]][[k]] = lambda
      SPLT[[p+1]][[p+1]][[l]][[k]] = 0
    }
  }
  
  
  for(j in p:0)
  {
    if(j < p)
    {
      OPT[[j+1]] = list()
      SPLT[[j+1]] = list()
    }
    for(i in p:0)
    {
      if(j<p || i<p)
      {
        OPT[[j+1]][[i+1]] = list()
        SPLT[[j+1]][[i+1]] = list()
      }
      
      for(l in 1:2^j)
      { 
        if(j<p || i<p)
        {
          OPT[[j+1]][[i+1]][[l]] = list()
          SPLT[[j+1]][[i+1]][[l]] = list()
        }
        for(k in 1:2^i)
        { 
          #R[[j+1]] = list()
          #R[[j+1]][[i+1]] = list()
          #R[[j+1]][[i+1]][[l]] = list()
          #R[[j+1]][[i+1]][[l]][[k]] = list()
          #if(j ==p  && i==p)
          #{
          #  OPT[[j+1]][[i+1]][[l]][[k]] = lambda
          #  SPLT[[j+1]][[i+1]][[l]][[k]] = 0
          #}
          aux1 = NULL 
          if(j<p)
          {
            ## horizontal split
            aux1 = OPT[[j+2]][[i+1]][[2*l-1]][[k]] + OPT[[j+2]][[i+1]][[2*l]][[k]]
          }  
          aux2 = NULL 
          if(i<p)
          {
            ## vertical split
            aux2 = OPT[[j+1]][[i+2]][[l]][[2*k-1]] + OPT[[j+1]][[i+2]][[l]][[2*k]]
          }
          if(i<p ||  j<p)
          {
            ## no split
            qest = R[[j+1]][[i+1]][[l]][[k]]
            dat = as.vector(y[((l-1)*n/2^{j}+1):(l*n/2^{j}),((k-1)*n/2^{i}+1):(k*n/2^{i})  ])
            aux3 = 0.5*sum((dat-qest)^2)+lambda
              #sum(pmax(tau*(dat-qest),(tau-1)*(dat-qest))) +lambda
            
            if(is.null(aux1)==FALSE)
            {
              if(aux1 <= min(aux2,aux3))
              {
                OPT[[j+1]][[i+1]][[l]][[k]] = aux1
                SPLT[[j+1]][[i+1]][[l]][[k]] = 1
              }
            }
            if(is.null(aux2)==FALSE)
            {
              if(aux2 <= min(aux1,aux3))#<
              {
                OPT[[j+1]][[i+1]][[l]][[k]] = aux2
                SPLT[[j+1]][[i+1]][[l]][[k]] = 2
              }
            }
            
            
            if(aux3 <= min(aux1,aux2))#<
            {
              OPT[[j+1]][[i+1]][[l]][[k]] = aux3
              SPLT[[j+1]][[i+1]][[l]][[k]] = 0
            }
          }
        }    
      }
    }
  }
  
  
  yhat = matrix(R[[1]][[1]][[1]][[1]],n,n)
  
  SPLT2 = SPLT
  inval =  SPLT
  if(SPLT[[1]][[1]][[1]][[1]] !=0)
  {
    
    for(j in 0:p)
    {
      for(i in 0:p)
      {
        for(l in 1:2^j)
        { 
          for(k in 1:2^i)
          {
            inval[[j+1]][[i+1]][[l]][[k]]  =1
          }
        }
      }
    }
    inval[[1]][[1]][[1]][[1]]  =0
    #inval[[1]][[1]][[1]][[1]]  =0
    for(j in 0:p)
    {
      for(i in 0:p)
      {
        for(l in 1:2^j)
        { 
          for(k in 1:2^i)
          {
            if(j <p && SPLT2[[j+1]][[i+1]][[l]][[k]] ==1 && inval[[j+1]][[i+1]][[l]][[k]] ==0 )
            {
              inval[[j+2]][[i+1]][[2*l-1]][[k]] = 0
              inval[[j+2]][[i+1]][[2*l]][[k]] = 0 
            }
            if(i <p && SPLT2[[j+1]][[i+1]][[l]][[k]] ==2&& inval[[j+1]][[i+1]][[l]][[k]] ==0 )
            {
              inval[[j+1]][[i+2]][[l]][[2*k-1]] = 0 
              inval[[j+1]][[i+2]][[l]][[2*k]] = 0
            }
            # if(SPLT2[[j+1]][[i+1]][[l]][[k]] ==0)
            # { 
            #   yhat[((l-1)*n/2^{j}+1):(l*n/2^{j}),((k-1)*n/2^{i}+1):(k*n/2^{i})  ] = R[[j+1]][[i+1]][[l]][[k]]
            # }
          }
        }
      }
    }
    ########################
    for(j in 0:(p-h))
    {
      for(i in 0:(p-h))
      {
        for(l in 1:2^j)
        { 
          for(k in 1:2^i)
          {
            if(SPLT2[[j+1]][[i+1]][[l]][[k]] ==0 && inval[[j+1]][[i+1]][[l]][[k]] ==0)
            { 
              yhat[((l-1)*n/2^{j}+1):(l*n/2^{j}),((k-1)*n/2^{i}+1):(k*n/2^{i})  ] = R[[j+1]][[i+1]][[l]][[k]]
            }
          }
        }
      }
    }
    ############
  }
  return(yhat)
  
  
}
hausdorff =  function(theta0,theta_hat)
{
   u_theta0  =  unique(as.vector(theta0))
   u_theta_hat  =  unique(as.vector(theta_hat))
   
   if(length(u_theta0) >length(u_theta_hat))
   {
     return(Inf)
   }
   
   dists =  rep(0,length(u_theta0))
   for(i in 1:length(u_theta0))
   {
     c = u_theta0[i]
     
     j = which.min(abs(u_theta_hat-c) )
     j = j[1]
     
     S =  which(theta0==c)
     Shat = which(theta_hat== u_theta_hat[j])
     dists[i] =   length(setdiff(S,Shat))
   }
   return(max(dists))
}
