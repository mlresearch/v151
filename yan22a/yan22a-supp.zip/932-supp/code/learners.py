import numpy as np
import pandas as pd
import polytopewalk as pw
import cvxpy as cp
import copy

from sklearn.linear_model import LogisticRegression
from sklearn.neural_network import MLPClassifier

def append_offset(X):
    X1 = np.hstack([X, np.ones((X.shape[0], 1))])
    return X1

def apply_sign(X, y):
    X1 = copy.copy(X)
    X1[np.where(y)[0], :] *= -1 #-y^TXw \leq 0
    return X1

def sample_polytope(X, w0, n_samples=100, mix_time=100):
    A = copy.copy(X)
    A = np.vstack([A, np.ones(A.shape[1]), -np.ones(A.shape[1])])
    b = np.vstack([np.zeros(X.shape[0]), np.ones(1), -np.ones(1)])
    polytope = Polytope(A=X, b=np.zeros(X.shape[0]))
    init_hitandrun = HitAndRun(polytope=polytope, starting_point=w0)
    latest_w = init_hitandrun.get_samples(n_samples=mixing_time)[-1]
    hitandrun = HitAndRun(polytope=polytope, starting_point=latest_w)
    samples = hitandrun.get_samples(n_samples=n_samples)
    return samples

def random_walk_polytope(X, w0, n_samples=100, mix_time=100, r=0.5):
    b = - X @ w0
    samples = pw.run_john_walk(n_samples, mix_time, A=X, b=b, r=r)[:, :, -1] #d x num_samples
    return (samples + np.tile(w0, (1, n_samples))).T

'''
Train model with logistic regression, no bias
'''

def train_logistic_regression(X, y, rand_state=1, offset=True):
    clf = LogisticRegression(penalty='l2', random_state=rand_state, 
                             solver="saga", max_iter=3000, fit_intercept=offset).fit(X, y)
    w = clf.coef_.reshape(-1)
    w = np.append(w, clf.intercept_)
    return w

def label_linear_dataset(w, X):
    return (X @ w >= 0).astype("int")

def label_mlp_dataset(mlp, X):
    return mlp.predict(X)

def evaluate_linear(w, X, y):
    return np.average(label_linear_dataset(w, X)  == y)

'''
MLP
'''
from sklearn.neural_network import MLPClassifier

def train_MLP(X, y, layer_size=None, rand_state=1, mother_seed=100, batch_size=200, l2_penalty=0.01, lr=0.001, momentum=0.9, max_iter=500, rand_param=True):
    print("random state is {}".format(rand_state))
    print("data size is {}".format(X.shape))
    
    if layer_size is None:
        layer_size = (X.shape[1],)
    
    '''
    Randomly sample hyperparams
    '''
    np.random.seed(rand_state * mother_seed) #ensure randomness
    if rand_param:
        l2_penalty = 1e-3 + (1e-1 - 1e-3) * np.random.random()
        lr = 1e-4 + (1e-2 - 1e-4) * np.random.random()
        momentum = 0.5 + (0.95 - 0.5) * np.random.random()
        batch_size = int(20 + (300 - 20) * np.random.random())
    
    print((l2_penalty, lr, batch_size, max_iter))
    
    clf = MLPClassifier(hidden_layer_sizes=layer_size, solver="sgd", alpha=l2_penalty, random_state=rand_state, learning_rate_init=lr, momentum=momentum, batch_size=batch_size, max_iter=max_iter).fit(X, y)
    return clf