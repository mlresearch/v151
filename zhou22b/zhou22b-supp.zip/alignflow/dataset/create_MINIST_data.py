import os, shutil
import random

IMG_EXTENSIONS = ['.jpg', '.JPG', '.jpeg', '.JPEG',
                  '.png', '.PNG', '.ppm', '.PPM', '.bmp', '.BMP']

def get_image_paths(data_dir):
    """Get paths to images in a folder of images."""
    images = []
    assert os.path.isdir(data_dir), '%s is not a valid directory' % data_dir

    def _is_image_file(filename):
        return any(filename.endswith(extension) for extension in IMG_EXTENSIONS)

    for root, _, filenames in sorted(os.walk(data_dir)):
        for filename in filenames:
            if _is_image_file(filename):
                path = os.path.join(root, filename)
                images.append(path)

    return images

def create_MINIST_dataset(src, data_dir, phase='train'):
    """Create training and test dataset with specified source"""
    
    # num_test = int(min(len(img_paths_A), len(img_paths_B))*train_test_ratio)
    # num_train = int(min(len(img_paths_A), len(img_paths_B))*(1-train_test_ratio))

    data_dir_A = os.path.join(data_dir, phase, src[0])
    data_dir_B = os.path.join(data_dir, phase, src[1])
    img_paths_A = sorted(get_image_paths(data_dir_A))
    img_paths_B = sorted(get_image_paths(data_dir_B))
    random.shuffle(img_paths_A)
    random.shuffle(img_paths_B)
    num_sample = int(min(len(img_paths_A), len(img_paths_B)))
    print(f'There are total of {num_sample} samples')
    paired_dir_A = os.path.join(data_dir, f'{phase}A')
    paired_dir_B = os.path.join(data_dir, f'{phase}B')
    os.makedirs(paired_dir_A, exist_ok=True)
    os.makedirs(paired_dir_B, exist_ok=True)
    for idx in range(num_sample):
        shutil.copy(img_paths_A[idx], paired_dir_A)
        shutil.copy(img_paths_B[idx], paired_dir_B)


if __name__ == '__main__':

    src = ['0','1']
    data_dir = r'../data/CIFAR10'
    # create_MINIST_dataset(src, data_dir, 'train')
    # create_MINIST_dataset(src, data_dir, 'cnn')
    # create_MINIST_dataset(src, data_dir, 'eval')
    create_MINIST_dataset(src, data_dir, 'demo')