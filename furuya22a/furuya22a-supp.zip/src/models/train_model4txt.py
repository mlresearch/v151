import copy
import math
import os

import torch
from src import get_module_logger


def train_one_epoch(model, criterion, optimizer, train_dl, val_dl, device, clip_value=None, clip_norm=None):
    """Algorithm for one epoch training with gradient monitor."""
    epoch_loss = {"train": [], "val": []}

    running_grad_hh = 0.0
    running_grad_ih = 0.0
    running_grad_out = 0.0
    running_grad_hh_clip = 0.0
    running_grad_ih_clip = 0.0
    running_grad_out_clip = 0.0
    if (clip_value is not None) or (clip_norm is not None):
        clipping = True
    else:
        clipping = False

    for phase in ["train", "val"]:
        if phase == "train":
            model.train()
            dataloader = train_dl
            n_iters = (dataloader.dataset.datanum + 1) // dataloader.batch_size
        else:
            model.eval()
            dataloader = val_dl
            n_iters = (dataloader.dataset.datanum + 1) // dataloader.batch_size

        ntoken = model.ntoken
        running_loss = 0.0
        hidden = None

        for inputs, labels in dataloader:
            inputs = inputs.to(device, non_blocking=True)
            labels = labels.to(device, non_blocking=True)
            optimizer.zero_grad()

            # forward pass
            with torch.set_grad_enabled(phase == "train"):
                outputs, hidden = model(inputs, hidden)
                loss = criterion(outputs.view(-1, ntoken), labels.view(-1))

                # backward pass
                if phase == "train":
                    loss.backward()
                    # gradient monitor
                    grad_hh = float(
                        torch.norm(model.rnn.weight_hh_l0.grad.detach().to(device)).to("cpu").numpy().astype("float64")
                    )
                    grad_ih = float(
                        torch.norm(model.rnn.weight_ih_l0.grad.detach().to(device)).to("cpu").numpy().astype("float64")
                    )
                    grad_out = float(
                        torch.norm(model.decoder.weight.grad.detach().to(device)).to("cpu").numpy().astype("float64")
                    )
                    running_grad_hh = max(running_grad_hh, grad_hh)
                    running_grad_ih = max(running_grad_ih, grad_ih)
                    running_grad_out = max(running_grad_out, grad_out)
                    if clip_value is not None:
                        torch.nn.utils.clip_grad_value_(model.rnn.parameters(), clip_value)
                    if clip_norm is not None:
                        torch.nn.utils.clip_grad_norm_(model.rnn.parameters(), clip_norm)
                    if clipping:
                        grad_hh_clip = float(
                            torch.norm(model.rnn.weight_hh_l0.grad.detach().to(device))
                            .to("cpu")
                            .numpy()
                            .astype("float64")
                        )
                        grad_ih_clip = float(
                            torch.norm(model.rnn.weight_ih_l0.grad.detach().to(device))
                            .to("cpu")
                            .numpy()
                            .astype("float64")
                        )
                        grad_out_clip = float(
                            torch.norm(model.decoder.weight.grad.detach().to(device))
                            .to("cpu")
                            .numpy()
                            .astype("float64")
                        )
                        running_grad_hh_clip = max(running_grad_hh_clip, grad_hh_clip)
                        running_grad_ih_clip = max(running_grad_ih_clip, grad_ih_clip)
                        running_grad_out_clip = max(running_grad_out_clip, grad_out_clip)
                    optimizer.step()

                # statistics
                running_loss += loss.item() / n_iters

        epoch_loss[phase] = running_loss
    return (
        epoch_loss,
        running_grad_hh,
        running_grad_ih,
        running_grad_out,
        running_grad_hh_clip,
        running_grad_ih_clip,
        running_grad_out_clip,
    )


def train(
    model,
    criterion,
    optimizer,
    train_dl,
    val_dl,
    epochs,
    device,
    clip_value=None,
    clip_norm=None,
    scheduler=None,
    tags=None,
    artifacts=None,
    experiment=None,
):
    """Algorithm for whole training for language model."""
    logger = get_module_logger(__name__)

    best_loss = {phase: float("inf") for phase in ["train", "val"]}
    best_epoch = {phase: 0 for phase in ["train", "val"]}
    best_ppl = {phase: float("inf") for phase in ["train", "val"]}

    model = model.to(device)
    best_wts = copy.deepcopy(model.state_dict())

    # logger.debug('--Begin Training--')
    for epoch in range(1, epochs + 1):
        logger.info("Epoch {}/{}".format(epoch, epochs))
        logger.info("-" * 10)
        (epoch_loss, grad_hh, grad_ih, grad_out, grad_hh_clip, grad_ih_clip, grad_out_clip,) = train_one_epoch(
            model, criterion, optimizer, train_dl, val_dl, device, clip_value=clip_value, clip_norm=clip_norm
        )
        for phase in ["train", "val"]:
            logger.info(
                "{:5} Loss: {:5.2f} ppl: {:8.2f}".format(phase, epoch_loss[phase], math.exp(epoch_loss[phase]))
            )
            if best_loss[phase] > epoch_loss[phase]:
                best_loss[phase] = epoch_loss[phase]
                best_epoch[phase] = epoch
                best_ppl[phase] = math.exp(epoch_loss[phase])
                if phase == "val":
                    best_wts = copy.deepcopy(model.state_dict())

        if scheduler is not None:
            scheduler.step()

    if experiment is not None:
        log_dir = os.path.join('models/logs', experiment, 'model')
        torch.save(best_wts, os.path.join(log_dir, 'best_wts/state_dict.pth'))

    return None
