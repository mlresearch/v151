import itertools
import os
import shutil
import urllib.request

import numpy as np
import pandas as pd
import sklearn.preprocessing


class Dataset(object):
    def __init__(self, nodes, edges, labels):
        self.nodes = nodes
        self.edges = edges
        self.labels = labels
        self.test_ratio = 0.2
        self.positive_class = self.labels.unique()[0]
        self.negative_class = self.labels.unique()[1]
        self.summary = None

        self.scaler = sklearn.preprocessing.StandardScaler()
        self.scaler.fit(self.nodes)

    def set_labels(self, positive_class, negative_class):
        self.positive_class = positive_class
        self.negative_class = negative_class

    def set_test_ratio(self, ratio: float):
        self.test_ratio = ratio

    def get_summary(self):
        if self.summary is None:
            raise RuntimeError("`generate_train_test_split` must be invoked")

        return self.summary

    def generate_train_test_split(self, similarity_label=False):
        """
        Generate train test split based on self.test_ratio.

        If similarity_label == True, then the train set consists of
        a triplet (x0, x1, y), where x0 and x1 are pairs of data
        and y indicates whether x0 and x1 are similar/dissimilar.
        """

        # handle binary classification
        mask_valid_labels = self.labels.isin([
            self.positive_class,
            self.negative_class,
        ])

        n_test = int(len(self.nodes) * self.test_ratio)
        n_train = len(self.nodes) - n_test
        index_test = np.random.choice(
            self.nodes[mask_valid_labels].index,
            replace=False,
            size=n_test,
        )
        index_train = np.setdiff1d(
            self.nodes[mask_valid_labels].index,
            index_test,
        )

        mask_train = self.nodes.index.isin(index_train)
        mask_test = self.nodes.index.isin(index_test)

        mask_train_edges = \
            self.edges.source.isin(index_train) & \
            self.edges.target.isin(index_train)

        nodes = self.nodes[mask_train]
        edges = self.edges[mask_train_edges]

        n_nodes = len(nodes)
        n_sim = len(edges)

        if similarity_label:
            # make similar/dissimilar pairs for training
            # flatten node indices into 1d array
            index1d_pairs_all = np.setdiff1d(
                np.arange(n_nodes ** 2),
                np.arange(n_nodes) ** 2,
            )
            index1d_pairs_sim = np.array([
                n_nodes * nodes.index.get_loc(e[1].target)
                + nodes.index.get_loc(e[1].source)
                for e in edges.iterrows()
            ])
            # regard non-connected nodes as dissimilar
            index1d_pairs_dissim = np.setdiff1d(
                index1d_pairs_all, index1d_pairs_sim,
            )
            # randomly sample the same # of dissimilar pairs as similar pairs
            index1d_pairs_dissim = np.random.choice(
                index1d_pairs_dissim, n_sim, replace=False,
            )

            # make pairwise dataset for training
            x0_train = nodes.iloc[
                np.hstack([index1d_pairs_sim, index1d_pairs_dissim]) % n_nodes
            ].to_numpy(dtype=np.float32)
            x1_train = nodes.iloc[
                np.hstack([index1d_pairs_sim, index1d_pairs_dissim]) // n_nodes
            ].to_numpy(dtype=np.float32)
            y_train = np.hstack([
                np.ones((n_sim, )), np.zeros((n_sim, )),
            ]).astype(np.float32)

            # preprocessing
            x0_train = self.scaler.transform(x0_train)
            x1_train = self.scaler.transform(x1_train)

            data_train = (x0_train, x1_train, y_train)

            # save data statistics
            from sklearn.metrics import confusion_matrix
            sim_obs = y_train
            sim_true = [
                self.labels[mask_train].iloc[i % n_nodes] ==
                self.labels[mask_train].iloc[i // n_nodes]
                for i in np.hstack([index1d_pairs_sim, index1d_pairs_dissim])]
            self.summary = confusion_matrix(sim_true, sim_obs)

        else:
            x_train = nodes.to_numpy(dtype=np.float32)
            y_train = np.apply_along_axis(
                lambda y: np.where(y == self.positive_class, 1, 0),
                0,
                self.labels[mask_train].to_numpy(),
           ).astype(np.float32)

            x_train = self.scaler.transform(x_train)

            data_train = (x_train, y_train)

        # make pointwise dataset for evaluation
        x_test = self.nodes[mask_test].to_numpy(dtype=np.float32)
        y_test = np.apply_along_axis(
            lambda y: np.where(y == self.positive_class, 1, 0),
            0,
            self.labels[mask_test].to_numpy(),
        ).astype(np.float32)

        x_test = self.scaler.transform(x_test)

        data_test = (x_test, y_test)

        return data_train, data_test


class DatasetLoader(object):
    """
    Dataset loader class.
    """
    def __init__(self):
        pass

    def load(self) -> Dataset:
        # return Dataset(nodes, edges, labels)
        pass


class TwonormDatasetLoader(DatasetLoader):
    def __init__(self):
        super(TwonormDatasetLoader, self).__init__()
        self.n_class = 2
        self.dim = 2
        self.n_nodes = 2000
        self.n_edges = 1000
        self.mean_p = +2.
        self.mean_n = -2.
        self.var = 1.

    def load(self):
        nodes = np.vstack([
            np.random.normal(
                self.mean_p,
                self.var,
                size=(self.n_nodes // 2, self.dim),
            ),
            np.random.normal(
                self.mean_n,
                self.var,
                size=(self.n_nodes // 2, self.dim),
            ),
        ])
        labels = np.hstack([
            np.ones(self.n_nodes // 2),
            -np.ones(self.n_nodes // 2),
        ])

        n_nodes_p = self.n_nodes // 2

        # flattened index of positive data pairs
        index_pairs = np.setdiff1d(
            np.arange(n_nodes_p ** 2),
            np.arange(n_nodes_p) ** 2,
        )

        # randomly generate similarity pairs from positive data
        index_pairs = np.random.choice(
            index_pairs,
            self.n_edges // 2,
            replace=False,
        )

        # make source/target list of edges
        edge_sources = np.hstack([
            index_pairs % n_nodes_p,
            index_pairs % n_nodes_p + n_nodes_p,
        ])
        edge_targets = np.hstack([
            index_pairs // n_nodes_p,
            index_pairs // n_nodes_p + n_nodes_p,
        ])

        # make dataframes
        nodes = pd.DataFrame(nodes)
        labels = pd.Series(labels)
        edges = pd.DataFrame({
            "source": edge_sources,
            "target": edge_targets,
        })

        return Dataset(nodes, edges, labels)


class DownloadableDatasetLoader(DatasetLoader):
    """
    Largely immitates StellarGraph.

    cf. https://github.com/stellargraph/stellargraph/blob/develop/stellargraph/datasets/datasets.py
    """

    url = None
    url_archive_format = None
    directory_name = None
    fname_nodes = None
    fname_edges = None

    def _check_if_downloadable(self):
        return (self.url is not None) and \
            (self.url_archive_format is not None) and \
            (self.directory_name is not None)

    def download(self):
        if not self._check_if_downloadable():
            raise AttributeError(
                "DownloadableDatasetLoader is not inherited appropriately",
            )

        if os.path.exists(self.directory_name):
            return

        fname_local, _ = urllib.request.urlretrieve(self.url)
        shutil.unpack_archive(
            fname_local,
            format=self.url_archive_format,
        )
        os.remove(fname_local)

    def _resolve_path(self, fname: str) -> str:
        return os.path.join(self.directory_name, fname)


class PubmedDatasetLoader(DownloadableDatasetLoader):
    """
    Load Pubmed-Diabetes dataset.
    """

    url = "https://linqs-data.soe.ucsc.edu/public/datasets/pubmed-diabetes/pubmed-diabetes.tar.gz"
    url_archive_format = "gztar"
    directory_name = "pubmed-diabetes"
    fname_nodes = "data/Pubmed-Diabetes.NODE.paper.tab"
    fname_edges = "data/Pubmed-Diabetes.DIRECTED.cites.tab"


    def load(self):
        self.download()

        edges = pd.read_csv(
            self._resolve_path(self.fname_edges),
            sep="\t",
            skiprows=2,
            header=None,
            names=["id", "source", "pipe", "target"],
            usecols=["source", "target"],
        )
        edges.source = edges.source.str.lstrip("paper:").astype(int)
        edges.target = edges.target.str.lstrip("paper:").astype(int)

        def parse_feature(feature):
            name, value = feature.split("=")
            return name, float(value)

        def parse_line(line):
            pid, raw_label, *raw_features, _summary = line.split("\t")
            features = dict(parse_feature(feature) for feature in raw_features)
            features["pid"] = int(pid)
            features["label"] = int(parse_feature(raw_label)[1])
            return features

        with open(self._resolve_path(self.fname_nodes)) as fp:
            nodes = pd.DataFrame(
                parse_line(line) for line in itertools.islice(fp, 2, None)
            )

        nodes.fillna(0, inplace=True)
        nodes.set_index("pid", inplace=True)

        labels = nodes["label"]
        nodes = nodes.drop(columns="label")

        return Dataset(nodes, edges, labels)


def load_twonorm():
    loader = TwonormDatasetLoader()
    return loader.load()


def load_pubmed():
    loader = PubmedDatasetLoader()
    return loader.load()
