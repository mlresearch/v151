from tensorflow.keras.layers import Layer
from tensorflow.keras import Input

from loaders.pairloader import *

from utils.loss import *
from utils.optimizer import *

import tensorflow.keras.backend as KB

def sims_euclidean_distance(vectors):  # compute the Euclidean distance between two feature vectors A and B encapsulated by a "vectors" object
    # unpack the vectors into separate lists
    [A, B] = vectors
    # compute the sum of squared distances between the vectors
    sumSquared = KB.sum(KB.square(A - B), axis = 1, keepdims = True)
    # return the euclidean distance between the vectors
    return KB.sqrt(KB.maximum(sumSquared, KB.epsilon()))


class QuadLayer(Layer):
    def __init__(self):
        super(QuadLayer, self).__init__()
        self.kernel = None

    def build(self, input_shape):
        self.kernel = self.add_weight("kernel", shape = [int(input_shape[-1]), 1], trainable = True)

    def call(self, input):
        return tf.matmul(input ** 2.0, self.kernel ** 2.0)  # input^T * diag() * input


class SIMSMetricNet:  # this is our item-to-item metric net -- it maps from [item_A's id embedding, item_A's feature, item_B's id embedding, item_B's feature] to a probability of dissimilarity -- P(Y = 1 | item_A, item_B)
    def __init__(self, params):
        self.loss = KerasLossWrapper(params.loss)  # here goes the loss
        self.optimizer = KerasOptimizerWrapper(params.optimizer, params.learning_rate)  # here goes the optimizer
        self.learning_rate = params.learning_rate  # here goes the learning rate
        self.id_embedding_dim = params.id_embedding_dim  # here is the dimension of the id embedding -- 1 int value -> "id_embedding_dim"-dim vector
        self.feature_channel_dims = params.feature_channels_dim  # here is the map from channel name to feature-dim of that channel
        self.hidden_dim = params.hidden_dim  # here is the hidden dim used in the feature embedding network segment: feature-dim --> 2 * hidden-dim --> hidden-dim
        self.no_item, self.no_user = params.no_item, params.no_user  # no. of unique items and users
        self.model = None

    def compute_item_embedding(self, items):
        return None

    def build_tower(self):
        item = Input(shape = (1,))  # here are the placeholders of the item id
        features = {}  # here are the placeholders of the items' multiple channels of features

        for channel in self.feature_channel_dims.keys():  # for each channel
            features[channel] = Input(shape = self.feature_channel_dims[channel])  # create the placeholder and put it in the dict

        inputs = [item, features]  # now, here is the placeholder for the input

        id_pipe = K.Sequential()  # we now create a network segment to embed the item id
        id_embed: Layer = K.layers.Embedding(input_dim = self.no_item, output_dim = self.id_embedding_dim, input_length = 1)
        id_pipe.add(id_embed)
        id_pipe.add(K.layers.Flatten())
        id = id_pipe(item)

        output = [id]  # the list of embeddings (one per channel, including the id channel)

        for channel in self.feature_channel_dims.keys():  # for each feature channel
            feature_pipe = K.Sequential()  # we create a separate network segment for each channel to embed its feature vector
            feature_pipe.add(K.layers.Dense(2 * self.hidden_dim, activation = Activations.relu.name))  # feature-dim -> 2 * hidden-dim via Dense
            feature_pipe.add(K.layers.Dense(self.hidden_dim, activation = Activations.tanh.name))  # 2 * hidden-dim -> hidden-dim via Dense
            feature = feature_pipe(features[channel])  # compute the feature embeddings for item
            output.append(feature)  # add it to the distance list

        return K.Model(inputs = inputs, outputs = output)

    def build_aggregator(self):
        id_A, id_B = Input(shape = self.id_embedding_dim), Input(shape = self.id_embedding_dim)
        input_A, input_B = [id_A], [id_B]
        for channel in self.feature_channel_dims.keys():
            input_A.append(Input(shape = self.hidden_dim))
            input_B.append(Input(shape = self.hidden_dim))

        L2 = K.layers.Lambda(sims_euclidean_distance)
        distances = []

        for i in range(len(input_A)):
            distances.append(L2([input_A[i], input_B[i]]))  # compute [D1 D2 ... Dn]

        if len(distances) == 1:
            meta_distances = distances[0]
        else:
            meta_distances = K.layers.Concatenate(axis = 1)(distances)

        inputs = [input_A, input_B]
        outputs = K.layers.Dense(1, activation = Activations.sigmoid.name)(meta_distances)
        return K.Model(inputs = inputs, outputs = outputs)

    def build_network(self):
        return None

    def compile_network(self, verbal = True):  # compile the created model
        if self.model is not None:
            self.model.compile(loss = self.loss.loss, optimizer = self.optimizer.optimizer, metrics = ['accuracy'])
            if verbal:
                self.model.summary()  # print out a summary of model architecture
        else:
            print("ERROR: Model has NOT been constructed.")


class SIMSMetricNetV1(SIMSMetricNet):  # this is our item-to-item metric net -- it maps from [item_A's id embedding, item_A's feature, item_B's id embedding, item_B's feature] to a probability of dissimilarity -- P(Y = 1 | item_A, item_B)
    def __init__(self, params):
        super().__init__(params)
        self.tower = self.build_tower()
        self.aggregator = self.build_aggregator()
        self.model = self.build_network()

    def compute_item_embedding(self, items):
        return self.tower(items)

    def build_network(self):
        item_A, item_B = Input(shape = (1,)), Input(shape = (1,))  # here are the placeholders of the item ids
        features_A, features_B = {}, {}  # here are the placeholders of the items' multiple channels of features

        for channel in self.feature_channel_dims.keys():  # for each channel
            features_A[channel] = Input(shape = self.feature_channel_dims[channel])  # create the placeholder and put it in the dict
            features_B[channel] = Input(shape = self.feature_channel_dims[channel])  # create the placeholder and put it in the dict

        input_A, input_B = [item_A, features_A], [item_B, features_B]  # now, here is the placeholder for the input
        output_A, output_B = self.tower(input_A), self.tower(input_B)
        output = self.aggregator([output_A, output_B])
        return K.Model(inputs = [item_A, features_A, item_B, features_B], outputs = output)


class SIMSMetricNetV2(SIMSMetricNetV1):  # this is our item-to-item metric net (with add, sub + mult encoding) which maps from (item_A, item_B) to a probability of dissimilarity -- P(Y = 1 | item_A, item_B)
    def __init__(self, params):
        super().__init__(params)
        self.tower = self.build_tower()
        self.aggregator = self.build_aggregator()
        self.model = self.build_network()

    def build_aggregator(self):
        id_A, id_B = Input(shape = self.id_embedding_dim), Input(shape = self.id_embedding_dim)
        input_A, input_B = [id_A], [id_B]
        for channel in self.feature_channel_dims.keys():
            input_A.append(Input(shape = self.hidden_dim))
            input_B.append(Input(shape = self.hidden_dim))

        adds, subs, multiplies = [], [], []

        for i in range(len(input_A)):
            adds.append(K.layers.Add()([input_A[i], input_B[i]]))
            subs.append(K.layers.Subtract()([input_A[i], input_B[i]]))
            multiplies.append(K.layers.Multiply()([input_A[i], input_B[i]]))

        features = adds + subs + multiplies
        meta_features = K.layers.Concatenate(axis = 1)(features)

        inputs = [input_A, input_B]
        outputs = K.layers.Dense(1, activation = Activations.sigmoid.name)(meta_features)
        return K.Model(inputs = inputs, outputs = outputs)


class SIMSMetricNetV3(SIMSMetricNetV1):  # this is our item-to-item metric net (with quad form aggregator) which maps from (item_A, item_B) to a probability of dissimilarity -- P(Y = 1 | item_A, item_B)
    def __init__(self, params):
        super().__init__(params)
        self.tower = self.build_tower()
        self.aggregator = self.build_aggregator()
        self.model = self.build_network()

    def build_aggregator(self):
        id_A, id_B = Input(shape = self.id_embedding_dim), Input(shape = self.id_embedding_dim)
        input_A, input_B = [id_A], [id_B]
        for channel in self.feature_channel_dims.keys():
            input_A.append(Input(shape = self.hidden_dim))
            input_B.append(Input(shape = self.hidden_dim))

        L2 = K.layers.Lambda(sims_euclidean_distance)
        features = []

        for i in range(len(input_A)):
            features.append(L2([input_A[i], input_B[i]]))  # compute [D1 D2 ... Dn]

        meta_features = K.layers.Concatenate(axis = 1)(features)

        inputs = [input_A, input_B]
        outputs = QuadLayer()(meta_features)
        return K.Model(inputs = inputs, outputs = outputs)


class SIMSMetricNetV4(SIMSMetricNetV1):  # this is our item-to-item metric net -- it maps from [item_A's id embedding, item_A's feature, item_B's id embedding, item_B's feature] to a probability of dissimilarity -- P(Y = 1 | item_A, item_B)
    def __init__(self, params):
        super().__init__(params)
        self.tower = self.build_tower()
        self.aggregator = self.build_aggregator()
        self.model = self.build_network()

    def build_tower(self):
        item = Input(shape = (1,))  # here are the placeholders of the item id
        features = {}  # here are the placeholders of the items' multiple channels of features

        for channel in self.feature_channel_dims.keys():  # for each channel
            features[channel] = Input(shape = self.feature_channel_dims[channel])  # create the placeholder and put it in the dict

        inputs = [item, features]  # now, here is the placeholder for the input

        id_pipe = K.Sequential()  # we now create a network segment to embed the item id
        id_embed: Layer = K.layers.Embedding(input_dim = self.no_item, output_dim = self.id_embedding_dim, input_length = 1)
        id_pipe.add(id_embed)
        id_pipe.add(K.layers.Flatten())
        id = id_pipe(item)

        output = [id]  # the list of embeddings (one per channel, including the id channel)

        for channel in self.feature_channel_dims.keys():  # for each feature channel
            feature_pipe = K.Sequential()  # we create a separate network segment for each channel to embed its feature vector
            feature_pipe.add(K.layers.Dense(2 * self.hidden_dim, activation = Activations.relu.name))  # feature-dim -> 2 * hidden-dim via Dense
            feature_pipe.add(K.layers.Dense(self.hidden_dim, activation = Activations.sigmoid.name))  # 2 * hidden-dim -> hidden-dim via Dense
            feature_pipe.add(K.layers.Dense(self.hidden_dim, activation = Activations.tanh.name))
            feature = feature_pipe(features[channel])  # compute the feature embeddings for item
            output.append(feature)  # add it to the distance list

        return K.Model(inputs = inputs, outputs = output)


class SIMSMetricNetV5(SIMSMetricNetV3):  # this is our item-to-item metric net -- it maps from [item_A's id embedding, item_A's feature, item_B's id embedding, item_B's feature] to a probability of dissimilarity -- P(Y = 1 | item_A, item_B)
    def __init__(self, params):
        super().__init__(params)
        self.tower = self.build_tower()
        self.aggregator = self.build_aggregator()
        self.model = self.build_network()

    def build_tower(self):
        item = Input(shape = (1,))  # here are the placeholders of the item id
        features = {}  # here are the placeholders of the items' multiple channels of features

        for channel in self.feature_channel_dims.keys():  # for each channel
            features[channel] = Input(shape = self.feature_channel_dims[channel])  # create the placeholder and put it in the dict

        inputs = [item, features]  # now, here is the placeholder for the input

        id_pipe = K.Sequential()  # we now create a network segment to embed the item id
        id_embed: Layer = K.layers.Embedding(input_dim = self.no_item, output_dim = self.id_embedding_dim, input_length = 1)
        id_pipe.add(id_embed)
        id_pipe.add(K.layers.Flatten())
        id = id_pipe(item)

        output = [id]  # the list of embeddings (one per channel, including the id channel)

        for channel in self.feature_channel_dims.keys():  # for each feature channel
            feature_pipe = K.Sequential()  # we create a separate network segment for each channel to embed its feature vector
            feature_pipe.add(K.layers.Dense(2 * self.hidden_dim, activation = Activations.relu.name))  # feature-dim -> 2 * hidden-dim via Dense
            feature_pipe.add(K.layers.Dense(self.hidden_dim, activation = Activations.sigmoid.name))  # 2 * hidden-dim -> hidden-dim via Dense
            feature_pipe.add(K.layers.Dense(self.hidden_dim, activation = Activations.tanh.name))
            feature = feature_pipe(features[channel])  # compute the feature embeddings for item
            output.append(feature)  # add it to the distance list

        return K.Model(inputs = inputs, outputs = output)