import numpy as np
import torch.nn as nn
import torch
import torch.distributions as distributions

class RealNVPLoss(nn.Module):
    """Get the NLL loss for a RealNVP model.

    Args:
        k (int or float): Number of discrete values in each input dimension.
            E.g., `k` is 256 for natural images.

    See Also:
        Equation (3) in the RealNVP paper: https://arxiv.org/abs/1605.08803
    """
    def __init__(self, k=256):

        super(RealNVPLoss, self).__init__()
        self.k = k


    def forward(self, z, sldj):

        prior_ll = -0.5 * (z ** 2 + np.log(2 * np.pi))
        prior_ll = prior_ll.view(z.size(0), -1).sum(-1) \
            - np.log(self.k) * np.prod(z.size()[1:])
        ll = prior_ll + sldj
        nll = -ll.mean()

        return nll

class RealNVPFCLoss(nn.Module):

    def __init__(self, device, dim=2):

        super(RealNVPFCLoss, self).__init__()
        self.prior = distributions.MultivariateNormal(torch.zeros(dim).to(device), \
                                                      torch.eye(dim).to(device))


    def forward(self, z, sldj):
        
        prior_ll = self.prior.log_prob(z)
        ll = prior_ll + sldj
        nll = -ll.mean()

        return nll
