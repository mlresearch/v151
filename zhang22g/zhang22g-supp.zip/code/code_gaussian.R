library(rmutil)

truncation_f<-function(x,M){
  a=sapply(x,min,M)
  a=sapply(a,max,-M)
  return(a)
}

n=1000
mu=1
A=0.5;
D=A;
delta=1e-5
c=sqrt(2*log(1.25/delta))

rep=1000
eps=0.5
a=-8;
b=8;
i=1
expectation=array(1:18)
error=array(1:18)
while(b < 26){
  a=-b
  iter_expectation=array(1:10)
  iter_error=array(1:10)
  for(t in 1:10){
    decision=array(1:rep)
    record=array(1:rep)
    for(j in 1:rep){
      X=rnorm(n=n,mean=mu,sd=1);
      l=array(1:n);
      l2=array(1:n); 
      Z_A=rnorm(n=1,mean=0,sd=2*sqrt(2)*A/eps);
      Z_B=rnorm(n=1,mean=0,sd=2*sqrt(2)*A/eps);
      for(k in 1:n){
        l[k]=sum((X[1:k]-mu/2)*mu);
        l2[k]=sum(truncation_f((X[1:k]-mu/2)*mu,A));
        Z_1=rnorm(n=1,mean=0,sd=4*A/eps);
        Z_2=rnorm(n=1,mean=0,sd=4*A/eps);
        #    if((l[k]+Z_1>B+Z_B)||(l[k]+Z_2<A+Z_A)){
        if((l2[k]+Z_1>(b+Z_B))){
          d=1
          break;
        }else if((l2[k]+Z_2<(a+Z_A))){
          d=0
          break;
        }
      }
      record[j]=k
      decision[j]=d*exp(-l[k])
    }
    iter_expectation[t]=mean(record)
    iter_error[t]=log((sum(decision)/rep)^{-1})
  }
  expectation[i]=mean(iter_expectation)
  error[i]=mean(iter_error)
  i=i+1
  b=b+1
}
error_eps05=error
expectation_eps05=expectation

rep=1000
eps=1
a=-1;
b=1;
i=1
expectation=array(1:18)
error=array(1:18)
while(b < 10){
  a=-b
  iter_expectation=array(1:10)
  iter_error=array(1:10)
  for(t in 1:10){
    decision=array(1:rep)
    record=array(1:rep)
    for(j in 1:rep){
      X=rnorm(n=n,mean=mu,sd=1);
      l=array(1:n);
      l2=array(1:n); 
      Z_A=rnorm(n=1,mean=0,sd=2*sqrt(2)*A/eps);
      Z_B=rnorm(n=1,mean=0,sd=2*sqrt(2)*A/eps);
      for(k in 1:n){
        l[k]=sum((X[1:k]-mu/2)*mu);
        l2[k]=sum(truncation_f((X[1:k]-mu/2)*mu,A));
        Z_1=rnorm(n=1,mean=0,sd=4*A/eps);
        Z_2=rnorm(n=1,mean=0,sd=4*A/eps);
        #    if((l[k]+Z_1>B+Z_B)||(l[k]+Z_2<A+Z_A)){
        if((l2[k]+Z_1>(b+Z_B))){
          d=1
          break;
        }else if((l2[k]+Z_2<(a+Z_A))){
          d=0
          break;
        }
      }
      record[j]=k
      decision[j]=d*exp(-l[k])
    }
    iter_expectation[t]=mean(record)
    iter_error[t]=log((sum(decision)/rep)^{-1})
  }
  expectation[i]=mean(iter_expectation)
  error[i]=mean(iter_error)
  i=i+1
  b=b+0.5
}
error_eps1=error
expectation_eps1=expectation

rep=1000
eps=2
a=-0.5;
b=0.5;
i=1
expectation=array(1:18)
error=array(1:18)
while(b < 8){
  a=-b
  iter_expectation=array(1:10)
  iter_error=array(1:10)
  for(t in 1:10){
    decision=array(1:rep)
    record=array(1:rep)
    for(j in 1:rep){
      X=rnorm(n=n,mean=mu,sd=1);
      l=array(1:n);
      l2=array(1:n); 
      Z_A=rnorm(n=1,mean=0,sd=2*sqrt(2)*A/eps);
      Z_B=rnorm(n=1,mean=0,sd=2*sqrt(2)*A/eps);
      for(k in 1:n){
        l[k]=sum((X[1:k]-mu/2)*mu);
        l2[k]=sum(truncation_f((X[1:k]-mu/2)*mu,A));
        Z_1=rnorm(n=1,mean=0,sd=4*A/eps);
        Z_2=rnorm(n=1,mean=0,sd=4*A/eps);
        #    if((l[k]+Z_1>B+Z_B)||(l[k]+Z_2<A+Z_A)){
        if((l2[k]+Z_1>(b+Z_B))){
          d=1
          break;
        }else if((l2[k]+Z_2<(a+Z_A))){
          d=0
          break;
        }
      }
      record[j]=k
      decision[j]=d*exp(-l[k])
    }
    iter_expectation[t]=mean(record)
    iter_error[t]=log((sum(decision)/rep)^{-1})
  }
  expectation[i]=mean(iter_expectation)
  error[i]=mean(iter_error)
  i=i+1
  b=b+0.4
}
error_eps2=error
expectation_eps2=expectation

df<-data.frame(error_eps05[1:18],expectation_eps05[1:18], error_eps1[1:18],expectation_eps1[1:18],error_eps2[1:18],expectation_eps2[1:18])
write.csv(df, file="data_gaussian.csv", row.names = FALSE)

