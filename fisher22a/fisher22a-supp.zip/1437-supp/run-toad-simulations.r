rm(list=ls())

source('toad.r')
library(ggplot2)
library(dplyr)
library(pbapply)


nsim <- 500
tmax <- 3000
alpha <- 0.05
a_toad <- rep(1/tmax, tmax)
a_toad <- a_toad/(sum(a_toad))

mypdf <- function(file, ...){
	pdf(file= paste0('plots/',Sys.Date(),'_', file,'.pdf'), ...)
}
mypng <- function(file, ...){
	png(file= paste0('plots/',Sys.Date(),'_', file,'.png'), units='in', res=256, ...)
}

sim_df <- expand.grid(
		batch_size = c(10, 100, 1000),
		corr_type = c('0', '0.5','AR1'),
		pi1 = c(seq(.01,.1, length=10), 2:5/10),
		mu1 = c('fixed','varied'),
		method = factor(c('TOAD','Batch-BH','Naive-BH','Batch-PRDS-BH')),
		seed = 1:nsim
	) %>%
	mutate(
		TP = NA,
		FP = NA,
		TN = NA,
		FN = NA
	) %>% 
	filter(mu1=='fixed' | corr_type != 'AR1')
dim(sim_df)
print(object.size(sim_df), units='auto')

for(s in 1:nrow(sim_df)){
	if(s==1) pb <- timerProgressBar(1, nrow(sim_df))

	set.seed(sim_df$seed[s])
	null_hyp <- (1:tmax) %in% sample(tmax, 
		ceiling((1-sim_df$pi1[s])*tmax),
		replace = FALSE)
	if(sim_df$mu1[s] == 'fixed') mu <- rep(3, tmax)
	if(sim_df$mu1[s] == 'varied'){
		mu <- rnorm(tmax, 0, sqrt(2*log(tmax)))
	}
	mu[null_hyp] <- 0
	batch_ends <- seq(0, tmax, by = sim_df$batch_size[s])[-1]
	deadlines <- sapply(1:tmax, function(t)
		min(batch_ends[batch_ends>=t]))

	z_base <- rnorm(tmax, 0, 1)
	z_corr <- rnorm(tmax, 0, 1)
	if(sim_df$corr_type[s] %in% c('0','0.5')){
		rho_s <- as.numeric(as.character(sim_df$corr_type[s]))
		z <- z_base * sqrt(1-rho_s) + 
			z_corr[deadlines] * sqrt(rho_s) +
			mu
	} else if (sim_df$corr_type[s]=='AR1') {
		z_noise <- z_base
		ar_weight <- 0.90
		ar_c1 <- sqrt(ar_weight)
		ar_c2 <- sqrt(1-ar_weight)
		#var(zj) = var(zn_{j-1} c1 + zc_{j} c2)
		# = var(zn_{j-1}) c1^2 + var(zc_{j}) c2^2
		# = c1^2 + c2^2
		# Cov(zn_j, zn_j+1) = Cov(zn_j, zn_j * c1 + zc_j+1 *c2)
		# = Cov(zn_j, zn_j * c1)
		# = c1
		for (j in 2:tmax){
			if(deadlines[j]!=deadlines[j-1]){ next }
			z_noise[j] <- z_noise[j-1] * ar_c1  + z_corr[j] * ar_c2
		}
		z <- z_noise + mu
	} else {
		stop('invalid corr_type')
	}

	if(sim_df$mu1[s] == 'fixed'){
		p <- pnorm(-z)
	}
	if(sim_df$mu1[s] == 'varied'){
		p <- 2 * pnorm(-abs(z))
	}

	if(sim_df$method[s] == 'TOAD'){
		rej <- toad_loop(p=p, a=a_toad, alpha=alpha, deadlines=deadlines)
	}
	if(sim_df$method[s] == 'Naive-BH'){
		rej <- naive_bh(p=p, alpha=alpha, batch_ends=batch_ends)
	}
	if(sim_df$method[s] == 'Batch-PRDS-BH'){
		G <- length(batch_ends)
		a_batch <- rep(1/G, G)
		rej <- batch_prds_bh(p=p, alpha=alpha, a=a_batch, batch_ends=batch_ends,
			check_theory = sim_df$seed[s] < 100)
	}
	if(sim_df$method[s] == 'Batch-BH'){
		n_batch <- length(batch_ends)
		if(sim_df$batch_size[s] == 10){
			gamma_seq <- (1:n_batch)^(-2)
			gamma_seq <- gamma_seq/sum(gamma_seq)
		} else {
			gamma_seq <- rep(0, n_batch)
			gamma_seq[1:2] <- 1/2
		}
		rej <- batch_bh(p=p, alpha=alpha, 
			gamma_seq = gamma_seq, 
			batch_ends = batch_ends)
	}


	sim_df$FP[s] <- sum(rej %in% which(null_hyp))
	sim_df$TP[s] <- sum(rej %in% which(!null_hyp))
	sim_df$FN[s] <- sum(!(which(!null_hyp) %in% rej))
	sim_df$TN[s] <- sum(!(which( null_hyp) %in% rej))

	if(s %% 200 == 0) setTimerProgressBar(pb, s)
}


# ## saveRDS(list(df = sim_df, alpha = alpha), paste0(Sys.Date(), '_sim_results_toad_batch.rds'))
# sim_results <- readRDS('2021-10-11_sim_results_toad_batch.rds')
# alpha <- sim_results$alpha
# sim_df <- sim_results$df

head(sim_df)

na.rm <- FALSE
batch_sizes <- unique(sim_df$batch_size)
corr_types <- unique(sim_df$corr_type)
sim_sum <- mutate(sim_df, total_alts = TP + FN) %>%
	mutate(
		batch_size = factor(batch_size, 
			levels = batch_sizes,
			labels = paste('Batch size =', batch_sizes)),
		corr_lab = factor(corr_type, 
			levels = corr_types,
			labels =  paste('Correlation =', corr_types))
		) %>%
	group_by(method, batch_size, pi1, mu1, corr_lab) %>%
	summarize(
		n = sum(!is.na(TP)),
		prob_zero_alts = mean(total_alts==0, na.rm=na.rm),
		FDR = mean(FP/pmax(1, FP + TP), na.rm=na.rm),
		Power = mean( (TP/total_alts)[total_alts>0] , na.rm=na.rm),
		sdPow = sd( (TP/total_alts)[total_alts>0] , na.rm=na.rm)/ sqrt(n),
		PowUpper = Power + 2*sdPow,
		PowLower = Power - 2*sdPow,
		sdFDR = sd( FP/pmax(1, FP + TP) , na.rm=na.rm) / sqrt(n),
		FDRupper = FDR + 2*sdFDR,
		FDRlower = FDR - 2*sdFDR)
stopifnot(all(sim_sum$prob_zero_alts==0))
stopifnot(var(sim_sum$n)==0)


cases <- c(as.character(unique(sim_sum$mu1)), 'AR1')
for(cc in cases){
	if(cc != 'AR1') dfc <- filter(sim_sum , mu1 == cc, 
			!grepl('AR1', as.character(corr_lab)))
	if(cc == 'AR1'){
		dfc <- filter(sim_sum, 
			grepl('AR1', as.character(corr_lab)))
		stopifnot(all(dfc$mu1 == 'fixed'))
	}

	ggpow <- dfc %>%
		ggplot( aes(x=pi1, y=Power)) +
			geom_line(aes(col=method, group = method, lty = method), lwd=.75) +
			geom_ribbon(aes(ymax = PowUpper, ymin = PowLower, fill=method), alpha = 0.3) +
			labs(x= expression(paste('Proportion of tests where null hypothesis is false (',pi[1],')')),
				y = 'Power (probability of rejecting an alternative hypothesis)',
				col='Method', group = 'Method', lty='Method', fill='Method')+
			ylim(0,1) + theme_bw() +
			theme(legend.position='top') +
			guides(group=guide_legend(nrow=2,byrow=TRUE),
				col=guide_legend(nrow=2,byrow=TRUE),
				lty=guide_legend(nrow=2,byrow=TRUE))

	ggfdr <- dfc %>%
		ggplot(aes(x=pi1, y=FDR)) +
		geom_line(aes(col=method, group = method, lty = method), lwd=.75) +
		labs(x= expression(paste('Proportion of tests where null hypothesis is false (',pi[1],')')),
			col='Method', group = 'Method', lty='Method', fill='Method')+
		theme_bw() +
		geom_ribbon(aes(ymax = FDRupper, ymin = FDRlower, fill=method), alpha = 0.3) +
		geom_hline(yintercept = alpha, lty=2) +
		theme(legend.position='top') +
			guides(group=guide_legend(nrow=2,byrow=TRUE),
				col=guide_legend(nrow=2,byrow=TRUE),
				lty=guide_legend(nrow=2,byrow=TRUE))


	if(cc !='AR1'){
		ggpow <- ggpow + facet_grid(batch_size ~ corr_lab)
		ggfdr <- ggfdr + facet_grid(batch_size ~ corr_lab)
		width = 4.4
	} else {
		ggpow <- ggpow + facet_grid(batch_size ~ .)
		ggfdr <- ggfdr + facet_grid(batch_size ~ .)
		width = 4
	}

	mypdf(paste0('toad-batch-power-case-',cc), height=6, width=width)
		print(ggpow)
	dev.off()

	mypdf(paste0('toad-batch-fdr-case-',cc), height=6, width=width)
		print(ggfdr)
	dev.off()

}

