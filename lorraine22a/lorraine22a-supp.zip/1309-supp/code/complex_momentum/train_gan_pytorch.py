"""Train GANs on toy data, MNIST, and CIFAR-10.

Example Commands
================
python train_gan.py \
    --dataset=mnist \
    --gan_loss=standard \
    --G_lr=1e-4 \
    --D_lr=1e-4

python train_gan.py \
    --dataset=gaussians \
    --z_dim=4 \
    --batch_size=1000 \
    --G_lr=1e-4 \
    --D_lr=1e-4
"""
import os
import ipdb
import time
import math
import cmath
import datetime
import argparse
import numpy as np

from tqdm import tqdm
import matplotlib.pyplot as plt

# YAML setup
from ruamel.yaml import YAML

yaml = YAML()
yaml.preserve_quotes = True
yaml.boolean_representation = ['False', 'True']

import torch
import torch.nn as nn
import torch.optim.sgd
import torch.optim as optim
import torch.nn.functional as F
from torch.autograd import grad
from torch.utils.data import DataLoader

import matplotlib
matplotlib.use('Agg')

import torch.backends.cudnn as cudnn
from torchvision import datasets, transforms
from torchvision import utils as torchvision_utils

# Local imports
import models
import toy_data
import complex_optimizers
from csv_logger import CSVLogger, plot_csv
import pickle

# ------------------------------------------------------------------------------
toy_datasets = ['gaussians', 'checkerboard', 'spirals', 'rings', 'grid']
dataset_choices = ['mnist', 'cifar10'] + toy_datasets

toy_data_funcs = {'gaussians': toy_data.sample_gaussians,
                  'checkerboard': toy_data.sample_checkerboard,
                  'spirals': toy_data.sample_spirals,
                  'rings': toy_data.sample_rings,
                  'grid': toy_data.sample_grid_gaussians}

parser = argparse.ArgumentParser()
# Training
parser.add_argument('--dataset', type=str, default='spirals', choices=dataset_choices,
                    help='Choose the dataset')
parser.add_argument('--batch_size', type=int, default=1000,
                    help='Batch size')
parser.add_argument('--n_epochs', type=int, default=1000,
                    help='Number of epochs to train')

# GAN hyperparameters
parser.add_argument('--z_dim', type=int, default=4,
                    help='The dimensionality of the latent space')
parser.add_argument('--gan_loss', type=str, default='standard', choices=['standard', 'wgan'],
                    help='Choose which version of the GAN loss to use')

parser.add_argument('--optimizer', type=str, default='adam', choices=['sgd', 'adam'],
                    help='Choose the type of optimizer (sgd or adam), which is the same for both G and D')

parser.add_argument('--G_lr', type=float, default=1e-4,
                    help='Generator learning rate')
parser.add_argument('--G_mom', type=float, default=0.9,
                    help='Generator SGD: momentum')
parser.add_argument('--G_mom_phase', type=float, default=16.0,
                    help='Generator SGD: phase')
parser.add_argument('--G_b1', type=float, default=0.5,
                    help='Generator adam: decay of first order momentum of gradient')
parser.add_argument('--G_b2', type=float, default=0.99,
                    help='Generator adam: decay of second order momentum of gradient')
parser.add_argument('--G_b1_phase', type=float, default=16.0,
                    help='Generator adam: phase of first order momentum of gradient')
parser.add_argument('--G_b2_phase', type=float, default=16.0,
                    help='Generator adam: phase of second order momentum of gradient')
parser.add_argument('--complex_G', action='store_true', default=False,
                    help='Whether to use complex momentum for the generator')

parser.add_argument('--D_lr', type=float, default=1e-4,
                    help='Discriminator learning rate')
parser.add_argument('--D_mom', type=float, default=0.9,
                    help='Discriminator SGD: momentum')
parser.add_argument('--D_mom_phase', type=float, default=16.0,
                    help='Discriminator SGD: phase')
parser.add_argument('--D_b1', type=float, default=0.5,
                    help='Discriminator adam: decay of first order momentum of gradient')
parser.add_argument('--D_b2', type=float, default=0.99,
                    help='Discriminator adam: decay of second order momentum of gradient')
parser.add_argument('--D_b1_phase', type=float, default=16.0,
                    help='Discriminator adam: phase of first order momentum of gradient')
parser.add_argument('--D_b2_phase', type=float, default=16.0,
                    help='Discriminator adam: phase of second order momentum of gradient')
parser.add_argument('--complex_D', action='store_true', default=False,
                    help='Whether to use complex momentum for the discriminator')

parser.add_argument('--gp_lambda', type=float, default=10.0,
                    help='Weighting of the gradient penalty term for WGAN')
parser.add_argument('--input_noise', type=float, default=None,
                    help='Standard deviation of additive input noise')
parser.add_argument('--critic_iters', type=int, default=1,
                    help='Number of discriminator updates per generator update')

# Logging
parser.add_argument('--log_every', type=int, default=1000,
                    help='print NLL every _ minibatches')
parser.add_argument('--save_every', type=int, default=600,
                    help='print NLL every _ minibatches')
parser.add_argument('--save_dir', type=str, default='saves',
                    help='directory for log / saving')
parser.add_argument('--seed', type=int, default=3,
                    help='Random seed')
args = parser.parse_args()

use_device = 'cuda:0' if torch.cuda.is_available() else 'cpu'

cudnn.benchmark = True  # Should make training should go faster for large models

# Set random seed for reproducibility
if args.seed is not None:
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)

timestamp = '{:%Y-%m-%d}'.format(datetime.datetime.now())
exp_name = '{}-d:{}-zdim:{}-glr:{}-cg:{}-gb1:{}-gb2:{}-gb1p:{}-gb2p:{}-dlr:{}-cd:{}-db1:{}-db2:{}-db1p:{}-db2p:{}-s:{}'.format(
            timestamp, args.dataset, args.z_dim,
            args.G_lr, int(args.complex_G), args.G_b1, args.G_b2, args.G_b1_phase, args.G_b2_phase,
            args.D_lr, int(args.complex_D), args.D_b1, args.D_b2, args.D_b1_phase, args.D_b2_phase, args.seed)

save_dir = os.path.join(args.save_dir, exp_name)
if not os.path.exists(save_dir):
    os.makedirs(save_dir)
    os.makedirs(os.path.join(save_dir, 'samples'))

# Save command-line arguments
with open(os.path.join(save_dir, 'args.yaml'), 'w') as f:
    yaml.dump(vars(args), f)

# Set up logging
iteration_logger = CSVLogger(fieldnames=['global_iteration', 'G_loss', 'D_loss'],
                             filename=os.path.join(save_dir, 'iteration_log.csv'))

every_N_logger = CSVLogger(fieldnames=['global_iteration', 'G_loss', 'D_loss'],
                           filename=os.path.join(save_dir, 'every_N_log.csv'))

# Data loading
# ------------
tf_test = transforms.Compose([transforms.Resize(32), transforms.ToTensor()])
tf = transforms.Compose([transforms.Resize(32), transforms.ToTensor()])

if args.dataset == 'mnist':
    train_dataset = datasets.MNIST('data/mnist', train=True, download=True, transform=tf)
    train_loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True)
    test_dataset = datasets.MNIST('data/mnist', train=False, transform=tf_test)
    test_loader = DataLoader(test_dataset, batch_size=args.batch_size, shuffle=False)
    channels = 1
elif args.dataset == 'cifar10':
    train_dataset = datasets.CIFAR10('data/cifar10', train=True, download=True, transform=tf)
    train_loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True)
    test_dataset = datasets.CIFAR10('data/cifar10', train=False, download=True, transform=tf_test)
    test_loader = DataLoader(test_dataset, batch_size=args.batch_size, shuffle=False)
    channels = 3
else:  # If one of the toy datasets
    class ToyDataLoader(object):
        def __init__(self, data_gen_func, batch_size):
            self.data_gen_func = data_gen_func
            self.batch_size = batch_size

        def __iter__(self):
            return self

        def __next__(self):
            return self.data_gen_func(self.batch_size)

        def next(self):
            return self.data_gen_func(self.batch_size)


    train_loader = ToyDataLoader(toy_data_funcs[args.dataset], args.batch_size)
    test_loader = ToyDataLoader(toy_data_funcs[args.dataset], args.batch_size)

# Build models
# ------------
if args.dataset in toy_datasets:
    hidden_dim = 25  # 200
    generator = models.MLP(input_dim=args.z_dim, hidden_dim=hidden_dim, output_dim=2)  # To generate 2D datapoints
    discriminator = models.MLP(input_dim=2, hidden_dim=hidden_dim, output_dim=1)  # To assign scores to each datapoint
else:
    generator = models.Generator(args.z_dim, channels=channels)
    discriminator = models.Discriminator(channels=channels)

generator = generator.to(use_device)
discriminator = discriminator.to(use_device)

if args.optimizer == 'sgd':
    G_momentum = 0.9
    D_momentum = args.D_mom * cmath.exp(1j*(math.pi / args.D_mom_phase)) if args.complex_D else args.D_mom
    G_optimizer = complex_optimizers.ComplexSGD(generator.parameters(), lr=1e-2, momentum=G_momentum)
    D_optimizer = complex_optimizers.ComplexSGD(discriminator.parameters(), lr=1e-2, momentum=D_momentum)
elif args.optimizer == 'adam':
    G_b1 = args.G_b1 * cmath.exp(1j*(math.pi / args.G_b1_phase)) if args.complex_G else args.G_b1
    G_b2 = args.G_b2 * cmath.exp(1j*(math.pi / args.G_b2_phase)) if args.complex_G else args.G_b2

    D_b1 = args.D_b1 * cmath.exp(1j*(math.pi / args.D_b1_phase)) if args.complex_D else args.D_b1
    D_b2 = args.D_b2 * cmath.exp(1j*(math.pi / args.D_b2_phase)) if args.complex_D else args.D_b2

    G_optimizer = complex_optimizers.ComplexAdam(generator.parameters(), lr=args.G_lr, betas=(G_b1, G_b2))
    D_optimizer = complex_optimizers.ComplexAdam(discriminator.parameters(), lr=args.D_lr, betas=(D_b1, D_b2))


def save_models(name='checkpoint'):
    torch.save(generator, os.path.join(save_dir, 'G_{}.pt'.format(name)))
    torch.save(discriminator, os.path.join(save_dir, 'D_{}.pt'.format(name)))


def gradient_penalty(x, y, f):
    """From https://github.com/LynnHo/Pytorch-WGAN-GP-DRAGAN-Celeba/blob/master/train_celeba_wgan_gp.py
    """
    # Interpolation
    shape = [x.size(0)] + [1] * (x.dim() - 1)
    alpha = torch.rand(shape, device='cuda:0' if torch.cuda.is_available() else 'cpu', requires_grad=True)
    z = x + alpha * (y - x)

    # Gradient penalty
    o = f(z)
    g = grad(o, z, grad_outputs=torch.ones(o.size(), device=x.device), create_graph=True)[0].view(z.size(0), -1)
    gp = ((g.norm(p=2, dim=1) - 1) ** 2).mean() * args.gp_lambda
    return gp


global_iteration = 0

save_data = {'iter': [], 'eigs': [], 'eig_vecs': [], 'grad': [], 'hess': [], 'num_G': [], 'num_D': []}
save_data_mem_impact = None
save_iteration = 0
try:
    for epoch in range(args.n_epochs):
        generator.train()
        discriminator.train()

        progress_bar = tqdm(train_loader)
        for i, (x, label) in enumerate(progress_bar):
            progress_bar.set_description('Epoch ' + str(epoch))

            x = x.to(use_device)
            label = label.to(use_device) if label is not None else None

            if args.input_noise:
                x += args.input_noise * torch.randn(x.size(), device=x.device)

            if args.gan_loss == 'wgan':
                for iter_d in range(args.critic_iters):
                    x_real, _ = iter(
                        train_loader).next()  # Should give a different minibatch each time because train_loader has shuffle=True
                    x_real = x_real.to(use_device)

                    D_real = discriminator(x_real)
                    noise = torch.randn((x_real.size(0), args.z_dim), device=x.device)
                    x_fake = generator(noise)
                    D_fake = discriminator(x_fake.detach())
                    gp = gradient_penalty(x_real.detach(), x_fake.detach(), discriminator)

                    D_loss = -D_real.mean() + D_fake.mean() + gp
                    discriminator.zero_grad()
                    D_loss.backward()
                    D_optimizer.step()

                noise = torch.randn((x.size(0), args.z_dim), device=x.device)
                x_fake = generator(noise)
                G_loss = -discriminator(x_fake).mean()
                generator.zero_grad()
                G_loss.backward()
                G_optimizer.step()


            elif args.gan_loss == 'standard':
                # Does it matter if we use the same fake examples from the generator update, for the discriminator update?
                # Or should we re-sample noise and generate new examples for the discriminator update?
                z = torch.randn((x.size(0), args.z_dim), device=x.device)
                x_gen = generator(z)

                D_real_loss = F.binary_cross_entropy_with_logits(discriminator(x.detach()),
                                                                 torch.ones((x.size(0), 1), device=x.device))
                D_fake_loss = F.binary_cross_entropy_with_logits(discriminator(x_gen.detach()),
                                                                 torch.zeros((x.size(0), 1), device=x.device))
                D_loss = D_real_loss + D_fake_loss

                D_optimizer.zero_grad()
                D_loss.backward()
                D_optimizer.step()

                # Train generator
                z = torch.randn((x.size(0), args.z_dim), device=x.device)
                x_gen = generator(z)
                G_loss = F.binary_cross_entropy_with_logits(discriminator(x_gen), torch.ones((x.size(0), 1), device=x.device))

                G_optimizer.zero_grad()
                G_loss.backward()
                G_optimizer.step()

            # if i % args.log_every == 0:

            #     def gather_flat_grad(loss_grad):
            #         return torch.cat([p.view(-1) for p in loss_grad])

            #     z = torch.randn((x.size(0), args.z_dim), device=x.device)
            #     x_gen = generator(z)
            #     D_real_loss = F.binary_cross_entropy_with_logits(discriminator(x.detach()),
            #                                                      torch.ones((x.size(0), 1), device=x.device))
            #     D_fake_loss = F.binary_cross_entropy_with_logits(discriminator(x_gen),
            #                                                      torch.zeros((x.size(0), 1), device=x.device))
            #     # TODO: Had to get rid of detach from fake loss?
            #     D_loss = D_real_loss + D_fake_loss

            #     z = torch.randn((x.size(0), args.z_dim), device=x.device)
            #     x_gen = generator(z)
            #     G_loss = F.binary_cross_entropy_with_logits(discriminator(x_gen),
            #                                                 torch.ones((x.size(0), 1), device=x.device))

            #     num_D_weights = sum(p.numel() for p in D_params)
            #     flat_D_grad = torch.zeros(num_D_weights).cuda()
            #     flat_D_grad += gather_flat_grad(grad(D_loss, D_params, create_graph=True))

            #     num_G_weights = sum(p.numel() for p in G_params)
            #     flat_G_grad = torch.zeros(num_G_weights).cuda()
            #     flat_G_grad += gather_flat_grad(grad(G_loss, G_params, create_graph=True))

            #     flat_joint_grad = torch.cat((flat_D_grad, flat_G_grad))

            #     joint_hessian = torch.eye(num_D_weights + num_G_weights)
            #     for index, param in enumerate(flat_joint_grad):
            #         joint_hessian_entry_D = gather_flat_grad(grad(param, D_params, retain_graph=True))
            #         joint_hessian_entry_G = gather_flat_grad(grad(param, G_params, retain_graph=True))
            #         joint_hessian_entry = torch.cat((joint_hessian_entry_D, joint_hessian_entry_G))
            #         joint_hessian[index] = joint_hessian_entry
            #         if index % 500 == 0: print(f"Computing joint Hessian at index {index}")

            #     # TODO: REDUCE HIDDEN SIZE TO 50 IF TIMEOUT
            #     eig_data = torch.eig(joint_hessian, eigenvectors=True)  # TODO: Do I want this comp on GPU?
            #     eigs = torch.eig(joint_hessian, eigenvectors=True)[0].data.numpy()
            #     '''eigs = np.abs(eigs) + 1e-12
            #     #eigs[np.abs(eigs) < 1e-10] = 0
            #     #eigs = np.ma.masked_equal(eigs,0)
            #     #eigs[:, 1][np.abs(eigs[:, 1]) < 1e-10] = 0
            #     #eigs[:, 1] = np.ma.masked_equal(eigs[:, 1], 0)
            #     fig = plt.figure()
            #     plt.hist2d(np.log(eigs[:, 0]), np.log(eigs[:, 1]), bins=100, range=[[-30, 1.0], [-30, 1.0]], cmap=plt.cm.jet)  # range=[[0, range_lim], [0.0, range_lim]],
            #     plt.tight_layout()
            #     plt.savefig(os.path.join(save_dir, 'eig_heatmap', '{}.png'.format(global_iteration)), bbox_inches='tight',
            #                 pad_inches=0)
            #     plt.close(fig)'''
            #     # TODO: Save eigenvalues to a pickle file, and add a plotting file
            #     save_data = {'iter': [], 'eigs': [], 'eig_vecs': [], 'grad': [], 'hess': [], 'num_G': [], 'num_D': []}
            #     save_data['iter'] += [i]
            #     save_data['eigs'] += [eig_data[0].data.numpy()]
            #     save_data['eig_vecs'] += [eig_data[1].data.numpy()]
            #     save_data['grad'] += [flat_joint_grad.data.cpu().numpy()]
            #     save_data['grad'] += [flat_joint_grad.data.cpu().numpy()]
            #     save_data['hess'] += [joint_hessian.data.numpy()]
            #     save_data['num_D'] += [num_D_weights]
            #     save_data['num_G'] += [num_G_weights]

            #     '''from sys import getsizeof

            #     gigabyte = 1000000000  # A gigabyte
            #     if save_data_mem_impact is None:
            #         mydict_as_string = pickle.dumps(save_data)
            #         save_data_mem_impact = getsizeof(mydict_as_string)
            #         del mydict_as_string'''
            #     with open(os.path.join(save_dir, f'eig_info_{save_iteration}.pickle'), 'wb') as handle:
            #         pickle.dump(save_data, handle, protocol=pickle.HIGHEST_PROTOCOL)
            #     save_iteration += 1

            if i % args.log_every == 0:
                every_N_logger.writerow({'global_iteration': global_iteration,
                                         'G_loss': G_loss.item(),
                                         'D_loss': D_loss.item(),
                                         })

                plot_csv(every_N_logger.filename)

                generator.eval()
                if args.dataset in toy_datasets:
                    z = torch.randn((100000, args.z_dim), device=x.device)  # Generate more datapoints here
                    x_gen = generator(z)
                    range_lim = 6
                    x_cpu = x_gen.cpu().detach().numpy()
                    fig = plt.figure()
                    plt.hist2d(x_cpu[:, 0], x_cpu[:, 1], range=[[-range_lim, range_lim], [-range_lim, range_lim]],
                               bins=100, cmap=plt.cm.jet)
                    plt.tight_layout()
                    plt.savefig(os.path.join(save_dir, 'samples', '{}.png'.format(global_iteration)),
                                bbox_inches='tight', pad_inches=0)
                    plt.close(fig)
                else:
                    z = torch.randn((args.batch_size, args.z_dim), device=x.device)
                    x_gen = generator(z)
                    grid = torchvision_utils.make_grid(torch.cat([x[:20], x_gen[:20]]), nrow=20)
                    torchvision_utils.save_image(grid, os.path.join(save_dir, 'samples',
                                                                    '{}_{}.png'.format(epoch, i // args.log_every)))
                generator.train()

            # if i % args.save_every == 0:
            #    save_models('iter_{}'.format(global_iteration))

            iteration_logger.writerow({'global_iteration': global_iteration,
                                       'G_loss': G_loss.item(),
                                       'D_loss': D_loss.item(),
                                       })

            progress_bar.set_postfix(G_loss='{:6.4f}'.format(G_loss.item()),
                                     D_loss='{:6.4f}'.format(D_loss.item()))
            global_iteration += 1

except KeyboardInterrupt:
    print('-' * 80)
    print('Exiting training early!')
    print('-' * 80)
