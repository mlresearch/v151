function [IPSD_analytical,PSDX_analytical,WF,H] = Model_at_f(Adj,h,f, E_factor)
Nnodes = size(Adj,1);
syms z;

H = z*zeros(Nnodes);
for i = 1:Nnodes
neighbors = find(Adj(i,:)==1);
for j = neighbors
        H(i,j) =  h(i,j)/(z-h(i,i));
end
end

%%%%%%% inv(PSD_X) transfer function %%%%%%%
H = double( subs(H,exp(1j*f) ));
I_H = eye(Nnodes)-H;
holder =inv( diag(double(subs(z-diag(h),exp(1j*f) ))));
Noise_filter = 5*double(subs(eye(Nnodes)*(1-0.3*z^(-1)), exp(1j*f)));

A = inv(I_H)*holder*E_factor*Noise_filter;
%%%%%%% PSD E %%%%%%%%
PSD_E = eye(Nnodes,Nnodes);
IPSD_analytical = conj(transpose(inv(A)))*inv(PSD_E)*inv(A);

%%%% Evaluationg at frequency IPSD_analytical = double(subs(PSDX_inv_TF, exp(1j*f)));
PSDX_analytical = inv(IPSD_analytical);

%%%%%%%%% Computing the variables at different frequencies
WF = zeros(Nnodes, Nnodes);    
for i = 1:Nnodes
    i_bar =  setdiff(1:Nnodes,i);
    cross_i_Ibar = PSDX_analytical(i,i_bar );
    psd_Ibar = PSDX_analytical(i_bar,i_bar);
    WF(i,i_bar)= cross_i_Ibar*inv(psd_Ibar);        
end



end

