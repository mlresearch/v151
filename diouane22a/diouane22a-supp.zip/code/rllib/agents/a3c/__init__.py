from ray.rllib.agents.a3c.a3c import A3CAgent, DEFAULT_CONFIG
from ray.rllib.agents.a3c.a2c import A2CAgent

__all__ = ["A2CAgent", "A3CAgent", "DEFAULT_CONFIG"]
