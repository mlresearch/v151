library(RandomFields)
#library(deldir) 
library(randtoolbox)
library(GPfit)
library(geoR)
library(lhs)
library(flexclust)
library(mlegp)
library(mvtnorm)

n1 = 101
myPreX <- seq(0, 1, length.out = n1)
myPreY <- seq(0, 1, length.out = n1) # prediction points
myd <- expand.grid(x = myPreX, y = myPreY) # gridpoints
d1 <- myd
d1[,1] <- myd[,2]
d1[,2] <- myd[,1]

sigma2 = exp(0.9)

pointeval = function(x,X){
  for(i in 1:dim(X)[1]){
    if(x[1] == X[i,1] & x[2] == X[i,2]){
      return(i)
    }
  }
}

findY = function(y,Y){
  for(i in 1:length(Y)){
    if(Y[i] == y){
      return(i)
    }
  }
}

desnum = 5
itmax = 30
itnum = seq(5, itmax, by = 5)
itnumlen = length(itnum)

myX = optimumLHS(n=desnum, k=2) # ini design
myXX = round(myX/(1/(n1-1)))*(1/(n1-1)) # LHS on grids

# gpva <- matrix(data = 1,nrow = 100, ncol = n1^2)
nipos <- matrix(data = 1,nrow = 100, ncol = desnum + itmax)
mycover <- seq(0.2,1.5,by = 0.1)
myclen <- length(mycover)
mycoverrate95 <- matrix(data = 0,nrow = myclen, ncol = itnumlen)
mycoverrate50 <- matrix(data = 0,nrow = myclen, ncol = itnumlen)
trocoverrate95 <- matrix(data = 0,nrow = itnumlen, ncol = 1)
trocoverrate50 <- matrix(data = 0,nrow = itnumlen, ncol = 1)

Ciwidth5 <- matrix(data = 0,nrow = myclen, ncol = 100)
Ciupper5 <- matrix(data = 0,nrow = myclen, ncol = 100)

Ciwidth10 <- matrix(data = 0,nrow = myclen, ncol = 100)
Ciupper10 <- matrix(data = 0,nrow = myclen, ncol = 100)

Ciwidth15 <- matrix(data = 0,nrow = myclen, ncol = 100)
Ciupper15 <- matrix(data = 0,nrow = myclen, ncol = 100)

Ciwidth20 <- matrix(data = 0,nrow = myclen, ncol = 100)
Ciupper20 <- matrix(data = 0,nrow = myclen, ncol = 100)

Ciwidth25 <- matrix(data = 0,nrow = myclen, ncol = 100)
Ciupper25 <- matrix(data = 0,nrow = myclen, ncol = 100)

Ciwidth30 <- matrix(data = 0,nrow = myclen, ncol = 100)
Ciupper30 <- matrix(data = 0,nrow = myclen, ncol = 100)

Ciwidthtr <- matrix(data = 0,nrow = itnumlen, ncol = 100)
Ciuppertr <- matrix(data = 0,nrow = itnumlen, ncol = 100)

Ciwidthtr50 <- matrix(data = 0,nrow = itnumlen, ncol = 100)

Ci50width5 <- matrix(data = 0,nrow = myclen, ncol = 100)
Ci50upper5 <- matrix(data = 0,nrow = myclen, ncol = 100)

Ci50width10 <- matrix(data = 0,nrow = myclen, ncol = 100)
Ci50upper10 <- matrix(data = 0,nrow = myclen, ncol = 100)

Ci50width15 <- matrix(data = 0,nrow = myclen, ncol = 100)
Ci50upper15 <- matrix(data = 0,nrow = myclen, ncol = 100)

Ci50width20 <- matrix(data = 0,nrow = myclen, ncol = 100)
Ci50upper20 <- matrix(data = 0,nrow = myclen, ncol = 100)

Ci50width25 <- matrix(data = 0,nrow = myclen, ncol = 100)
Ci50upper25 <- matrix(data = 0,nrow = myclen, ncol = 100)

Ci50width30 <- matrix(data = 0,nrow = myclen, ncol = 100)
Ci50upper30 <- matrix(data = 0,nrow = myclen, ncol = 100)

CiRegion1 <- 0
CiRegion2 <- 0
CiRegion3 <- 0
CiRegion4 <- 0
CiRegion5 <- 0
CiRegion6 <- 0

CiRegion1t <- 0
CiRegion2t <- 0
CiRegion3t <- 0
CiRegion4t <- 0
CiRegion5t <- 0
CiRegion6t <- 0

numtemp <- 0
n1 = n1^2

EIdata <- matrix(data = 1,nrow = 100,ncol = 1) 

mynu = 3.5
# myphi = 1/(2*sqrt(mynu))
# mynu <- c(1.5,2.5,3.5)
A0D <- 25

myscalenu = function(nu,p){
  D = sqrt(p)
  return((p*4*sqrt(nu)*gamma(nu + 1/2)*D/(sqrt(pi) * (2*nu - 1)*gamma(nu)))/A0D)
}

Mtheta <- myscalenu(mynu,2)
myphi = Mtheta/(2*sqrt(mynu))

gpdrawsimu = function(n,A){
  bdr = as.matrix(rnorm(n))
  return(A %*% bdr)
}

myDist=as.matrix(dist(myPreX,diag=TRUE,upper=TRUE))
PhiEval1 <- matern(u = myDist, phi = myphi, kappa = mynu)
A1 <- t(cholx(PhiEval1))
PhiEval <- kronecker(PhiEval1,PhiEval1)
# myDistx=as.matrix(dist(matrix(as.matrix(d1[,1]),ncol = 1),diag=TRUE,upper=TRUE))
# myDisty=as.matrix(dist(matrix(as.matrix(d1[,2]),ncol = 1),diag=TRUE,upper=TRUE))
# PhiEval22 <- matern(u = myDistx, phi = myphi, kappa = mynu) *
#   matern(u = myDisty, phi = myphi, kappa = mynu)

inipos <- 1:desnum
for(k in 1:desnum){
  inipos[k] <- pointeval(myXX[k,],d1)
}



for(ii in 1:1){
  # GPdraw = sigma2 * gpdrawsimu(n1,kronecker(A1,A1))
  # GPdraw = rmvnorm(n=1,sigma = PhiEval)
  # gpva[i,] <- GPdraw
  i=42
  
  
  
  GPdraw <- sigma2*gpva[i,]
  mypoints <- myXX
  myY <- 1:desnum
  
  for(k in 1:desnum){
    myY[k] <- GPdraw[inipos[k]]
  }
  posnow <- inipos
  ## start EI
  for(j in 1:itmax){
    print(c(i,j))
    # calculate kernel matrix
    # myDistx1=as.matrix(dist(matrix(as.matrix(mypoints[,1]),ncol = 1),diag=TRUE,upper=TRUE))
    # myDisty1=as.matrix(dist(matrix(as.matrix(mypoints[,2]),ncol = 1),diag=TRUE,upper=TRUE))
    # PhiEval1 <- matern(u = myDistx1, phi = 1/(2*sqrt(mynu)), kappa = mynu) *
    #   matern(u = myDisty1, phi = 1/(2*sqrt(mynu)), kappa = mynu)
    ## start prediction
    fHat <- as.matrix(PhiEval[,posnow])%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum-1+j),myY,tol = 0)
    curmaxf <- max(fHat)
    sigmax <- matrix(1:n1,ncol = 1)
    for(xnum in 1:n1){
      sigmax[xnum] <- sigma2 * sqrt(1 - PhiEval[xnum,posnow]%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum-1+j),PhiEval[posnow,xnum],tol = 0))
    }
    ## calculate GPUCB
    fei <- 1:n1
    for(p in 1:n1){
      myttt <- sqrt(log(16/0.05))
      temp <- sqrt(2 * log(j^2*2*pi^2/(3*0.05)) + 4*log(j^2*2*myttt))
      fei[p] <- fHat[p] + sigmax[p]*temp
    }
    curmpos <- which.max(fei)
    mypoints <- rbind(mypoints,as.matrix(d1[curmpos,],nrow =1))
    myY <- c(myY,GPdraw[curmpos])
    posnow <- c(posnow,curmpos)
    ## save data j=5
    if(j == 5){
      ## last calculation
      fHat <- as.matrix(PhiEval[,posnow])%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),myY,tol = 0)
      curmaxf <- max(fHat)
      sigmax <- matrix(1:n1,ncol = 1)
      for(xnum in 1:n1){
        sigmax[xnum] <- sigma2 * sqrt(1 - PhiEval[xnum,posnow]%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),PhiEval[posnow,xnum],tol = 0))
      }
      
      ## cover?
      gpmaxpos <- which.max(GPdraw)
      temp4 <- max(fHat + sigmax* 1.64)
      Ciwidthtr[1,i] <- temp4 - max(myY)
      Ciuppertr[1,i] <- temp4
      Ciwidthtr50[1,i] <- max(fHat) - max(myY)
      if(GPdraw[gpmaxpos] < temp4){
        trocoverrate95[1] <- trocoverrate95[1] + 1
      }
      temp5 <- max(fHat)
      if(GPdraw[gpmaxpos] < temp5){
        trocoverrate50[1] <- trocoverrate50[1] + 1
      }
      for(k in 1:myclen){
        temp1 <- max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.5)*2)))
        temp2 <- max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.05)*2)))
        Ciwidth5[k,i] <- temp2 - max(myY)
        Ciupper5[k,i] <- temp2
        Ci50width5[k,i] <- temp1 - max(myY)
        Ci50upper5[k,i] <- temp1
        if(GPdraw[gpmaxpos] < temp1){
          mycoverrate50[k,1] <- mycoverrate50[k,1] + 1
        }
        if(GPdraw[gpmaxpos] < temp2){
          mycoverrate95[k,1] <- mycoverrate95[k,1] + 1
        }
        # print(temp1 - max(fHat))
        # print(temp4 - max(fHat))
        # print(temp1-temp4)
      }
      #Draw confidence region
      temp12 <- fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.05)*2))
      maxY = max(myY)
      temp13 <- fHat + sigmax* 1.64
      
      for(kkk in 1:n1){
        if(temp12[kkk]>maxY){
          CiRegion1 = c(CiRegion1,kkk)
        }
        if(temp13[kkk]>maxY){
          CiRegion1t = c(CiRegion1t,kkk)
        }
      }
      
      
      
    }
    ## save data j=10
    if(j == 10){
      ## last calculation
      fHat <- as.matrix(PhiEval[,posnow])%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),myY,tol = 0)
      curmaxf <- max(fHat)
      sigmax <- matrix(1:n1,ncol = 1)
      for(xnum in 1:n1){
        sigmax[xnum] <- sigma2 * sqrt(1 - PhiEval[xnum,posnow]%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),PhiEval[posnow,xnum],tol = 0))
      }
      
      ## cover?
      gpmaxpos <- which.max(GPdraw)
      temp4 <- max(fHat + sigmax* 1.64)
      Ciwidthtr[2,i] <- temp4 - max(myY)
      Ciuppertr[2,i] <- temp4
      Ciwidthtr50[2,i] <- max(fHat) - max(myY)
      if(GPdraw[gpmaxpos] < temp4){
        trocoverrate95[2] <- trocoverrate95[2] + 1
      }
      temp5 <- max(fHat)
      if(GPdraw[gpmaxpos] < temp5){
        trocoverrate50[2] <- trocoverrate50[2] + 1
      }
      for(k in 1:myclen){
        temp1 <- max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.5)*2)))
        temp2 <- max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.05)*2)))
        Ciwidth10[k,i] <- temp2 - max(myY)
        Ciupper10[k,i] <- temp2
        Ci50width10[k,i] <- temp1 - max(myY)
        Ci50upper10[k,i] <- temp1
        if(GPdraw[gpmaxpos] < temp1){
          mycoverrate50[k,2] <- mycoverrate50[k,2] + 1
        }
        if(GPdraw[gpmaxpos] < temp2){
          mycoverrate95[k,2] <- mycoverrate95[k,2] + 1
        }
        # print(temp1 - max(fHat))
        # print(temp4 - max(fHat))
        # print(temp1-temp4)
      }
      #Draw confidence region
      temp12 <- fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.05)*2))
      maxY = max(myY)
      temp13 <-fHat + sigmax* 1.64
      
      for(kkk in 1:n1){
        if(temp12[kkk]>maxY){
          CiRegion2 = c(CiRegion2,kkk)
        }
        if(temp13[kkk]>maxY){
          CiRegion2t = c(CiRegion2t,kkk)
        }
      }
      
    }
    ## save data j=15
    if(j == 15){
      ## last calculation
      fHat <- as.matrix(PhiEval[,posnow])%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),myY,tol = 0)
      curmaxf <- max(fHat)
      sigmax <- matrix(1:n1,ncol = 1)
      for(xnum in 1:n1){
        sigmax[xnum] <- sigma2 * sqrt(1 - PhiEval[xnum,posnow]%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),PhiEval[posnow,xnum],tol = 0))
      }
      
      ## cover?
      gpmaxpos <- which.max(GPdraw)
      temp4 <- max(fHat + sigmax* 1.64)
      Ciwidthtr[3,i] <- temp4 - max(myY)
      Ciuppertr[3,i] <- temp4
      Ciwidthtr50[3,i] <- max(fHat) - max(myY)
      if(GPdraw[gpmaxpos] < temp4){
        trocoverrate95[3] <- trocoverrate95[3] + 1
      }
      temp5 <- max(fHat)
      if(GPdraw[gpmaxpos] < temp5){
        trocoverrate50[3] <- trocoverrate50[3] + 1
      }
      for(k in 1:myclen){
        temp1 <- max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.5)*2)))
        temp2 <- max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.05)*2)))
        Ciwidth15[k,i] <- temp2 - max(myY)
        Ciupper15[k,i] <- temp2
        Ci50width15[k,i] <- temp1 - max(myY)
        Ci50upper15[k,i] <- temp1
        if(GPdraw[gpmaxpos] < temp1){
          mycoverrate50[k,3] <- mycoverrate50[k,3] + 1
        }
        if(GPdraw[gpmaxpos] < temp2){
          mycoverrate95[k,3] <- mycoverrate95[k,3] + 1
        }
        # print(temp1 - max(fHat))
        # print(temp4 - max(fHat))
        # print(temp1-temp4)
      }
      #Draw confidence region
      temp12 <- fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.05)*2))
      maxY = max(myY)
      temp13 <-fHat + sigmax* 1.64
      
      for(kkk in 1:n1){
        if(temp12[kkk]>maxY){
          CiRegion3 = c(CiRegion3,kkk)
        }
        if(temp13[kkk]>maxY){
          CiRegion3t = c(CiRegion3t,kkk)
        }
      }
    }
    ## save data j=20
    if(j == 20){
      ## last calculation
      fHat <- as.matrix(PhiEval[,posnow])%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),myY,tol = 0)
      curmaxf <- max(fHat)
      sigmax <- matrix(1:n1,ncol = 1)
      for(xnum in 1:n1){
        sigmax[xnum] <- sigma2 * sqrt(1 - PhiEval[xnum,posnow]%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),PhiEval[posnow,xnum],tol = 0))
      }
      
      ## cover?
      gpmaxpos <- which.max(GPdraw)
      temp4 <- max(fHat + sigmax* 1.64)
      Ciwidthtr[4,i] <- temp4 - max(myY)
      Ciuppertr[4,i] <- temp4
      Ciwidthtr50[4,i] <- max(fHat) - max(myY)
      if(GPdraw[gpmaxpos] < temp4){
        trocoverrate95[4] <- trocoverrate95[4] + 1
      }
      temp5 <- max(fHat)
      if(GPdraw[gpmaxpos] < temp5){
        trocoverrate50[4] <- trocoverrate50[4] + 1
      }
      for(k in 1:myclen){
        temp1 <- max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.5)*2)))
        temp2 <- max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.05)*2)))
        Ciwidth20[k,i] <- temp2 - max(myY)
        Ciupper20[k,i] <- temp2
        Ci50width20[k,i] <- temp1 - max(myY)
        Ci50upper20[k,i] <- temp1
        if(GPdraw[gpmaxpos] < temp1){
          mycoverrate50[k,4] <- mycoverrate50[k,4] + 1
        }
        if(GPdraw[gpmaxpos] < temp2){
          mycoverrate95[k,4] <- mycoverrate95[k,4] + 1
        }
        # print(temp1 - max(fHat))
        # print(temp4 - max(fHat))
        # print(temp1-temp4)
      }
      #Draw confidence region
      temp12 <- fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.05)*2))
      maxY = max(myY)
      temp13 <-fHat + sigmax* 1.64
      
      for(kkk in 1:n1){
        if(temp12[kkk]>maxY){
          CiRegion4 = c(CiRegion4,kkk)
        }
        if(temp13[kkk]>maxY){
          CiRegion4t = c(CiRegion4t,kkk)
        }
      }
    }
    ## save data j=25
    if(j == 25){
      ## last calculation
      fHat <- as.matrix(PhiEval[,posnow])%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),myY,tol = 0)
      curmaxf <- max(fHat)
      sigmax <- matrix(1:n1,ncol = 1)
      for(xnum in 1:n1){
        sigmax[xnum] <- sigma2 * sqrt(1 - PhiEval[xnum,posnow]%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),PhiEval[posnow,xnum],tol = 0))
      }
      
      ## cover?
      gpmaxpos <- which.max(GPdraw)
      temp4 <- max(fHat + sigmax* 1.64)
      Ciwidthtr[5,i] <- temp4 - max(myY)
      Ciuppertr[5,i] <- temp4
      Ciwidthtr50[5,i] <- max(fHat) - max(myY)
      if(GPdraw[gpmaxpos] < temp4){
        trocoverrate95[5] <- trocoverrate95[5] + 1
      }
      temp5 <- max(fHat)
      if(GPdraw[gpmaxpos] < temp5){
        trocoverrate50[5] <- trocoverrate50[5] + 1
      }
      for(k in 1:myclen){
        temp1 <- max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.5)*2)))
        temp2 <- max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.05)*2)))
        Ciwidth25[k,i] <- temp2 - max(myY)
        Ciupper25[k,i] <- temp2
        Ci50width25[k,i] <- temp1 - max(myY)
        Ci50upper25[k,i] <- temp1
        if(GPdraw[gpmaxpos] < temp1){
          mycoverrate50[k,5] <- mycoverrate50[k,5] + 1
        }
        if(GPdraw[gpmaxpos] < temp2){
          mycoverrate95[k,5] <- mycoverrate95[k,5] + 1
        }
        # print(temp1 - max(fHat))
        # print(temp4 - max(fHat))
        # print(temp1-temp4)
      }
      #Draw confidence region
      temp12 <- fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.05)*2))
      maxY = max(myY)
      temp13 <-fHat + sigmax* 1.64
      
      for(kkk in 1:n1){
        if(temp12[kkk]>maxY){
          CiRegion5 = c(CiRegion5,kkk)
        }
        if(temp13[kkk]>maxY){
          CiRegion5t = c(CiRegion5t,kkk)
        }
      }
    }
    ## save data j=30
    if(j == 30){
      ## last calculation
      fHat <- as.matrix(PhiEval[,posnow])%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),myY,tol = 0)
      curmaxf <- max(fHat)
      sigmax <- matrix(1:n1,ncol = 1)
      for(xnum in 1:n1){
        sigmax[xnum] <- sigma2 * sqrt(1 - PhiEval[xnum,posnow]%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),PhiEval[posnow,xnum],tol = 0))
      }
      
      ## cover?
      gpmaxpos <- which.max(GPdraw)
      temp4 <- max(fHat + sigmax* 1.64)
      Ciwidthtr[6,i] <- temp4 - max(myY)
      Ciuppertr[6,i] <- temp4
      Ciwidthtr50[6,i] <- max(fHat) - max(myY)
      if(GPdraw[gpmaxpos] < temp4){
        trocoverrate95[6] <- trocoverrate95[6] + 1
      }
      temp5 <- max(fHat)
      if(GPdraw[gpmaxpos] < temp5){
        trocoverrate50[6] <- trocoverrate50[6] + 1
      }
      for(k in 1:myclen){
        temp1 <- max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.5)*2)))
        temp2 <- max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.05)*2)))
        Ciwidth30[k,i] <- temp2 - max(myY)
        Ciupper30[k,i] <- temp2
        Ci50width30[k,i] <- temp1 - max(myY)
        Ci50upper30[k,i] <- temp1
        if(GPdraw[gpmaxpos] < temp1){
          mycoverrate50[k,6] <- mycoverrate50[k,6] + 1
        }
        if(GPdraw[gpmaxpos] < temp2){
          mycoverrate95[k,6] <- mycoverrate95[k,6] + 1
        }
        # print(temp1 - max(fHat))
        # print(temp4 - max(fHat))
        # print(temp1-temp4)
      }
      #Draw confidence region
      temp12 <- fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.05)*2))
      maxY = max(myY)
      temp13 <- fHat + sigmax* 1.64
      
      for(kkk in 1:n1){
        if(temp12[kkk]>maxY){
          CiRegion6 = c(CiRegion6,kkk)
        }
        if(temp13[kkk]>maxY){
          CiRegion6t = c(CiRegion6t,kkk)
        }
      }
    }
  }
  nipos[i,] <- posnow
  if(gpmaxpos == which.max(fHat)){
    numtemp = numtemp + 1
    print(numtemp)
    print(c(gpmaxpos,which.max(fHat)))
  }
}

plot(d1[CiRegion6,1],d1[CiRegion6,2],xlab="",ylab="", xlim=c(0,1), ylim=c(0,1),pch=20,cex.axis=1.3)

plot(d1[CiRegion6t,1],d1[CiRegion6t,2],xlab="",ylab="", xlim=c(0,1), ylim=c(0,1),pch=20,cex.axis=1.3)
