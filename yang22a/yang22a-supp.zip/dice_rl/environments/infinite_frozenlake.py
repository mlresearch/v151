
import gym
from gym.envs.toy_text.frozen_lake import FrozenLakeEnv

class InfiniteFrozenLake(FrozenLakeEnv):

  def step(self, action):
    obs, reward, done, info = super(InfiniteFrozenLake, self).step(action)
    if done:
      self.reset()

    return obs, reward, False, info
