# -*- coding: utf-8 -*-
""" ``Policies`` module : contains all the (single-player) bandits algorithms:

- "Stupid" algorithms: :class:`Uniform`, :class:`UniformOnSome`, :class:`TakeFixedArm`, :class:`TakeRandomFixedArm`,

- Greedy algorithms: :class:`EpsilonGreedy`, :class:`EpsilonFirst`, :class:`EpsilonDecreasing`, :class:`EpsilonDecreasingMEGA`, :class:`EpsilonExpDecreasing`,
- And variants of the Explore-Then-Commit policy: :class:`ExploreThenCommit.ETC_KnownGap`, :class:`ExploreThenCommit.ETC_RandomStop`, :class:`ExploreThenCommit.ETC_FixedBudget`, :class:`ExploreThenCommit.ETC_SPRT`, :class:`ExploreThenCommit.ETC_BAI`, :class:`ExploreThenCommit.DeltaUCB`,

- Probabilistic weighting algorithms: :class:`Hedge`, :class:`Softmax`, :class:`Softmax.SoftmaxDecreasing`, :class:`Softmax.SoftMix`, :class:`Softmax.SoftmaxWithHorizon`, :class:`Exp3`, :class:`Exp3.Exp3Decreasing`, :class:`Exp3.Exp3SoftMix`, :class:`Exp3.Exp3WithHorizon`, :class:`Exp3.Exp3ELM`, :class:`ProbabilityPursuit`, :class:`Exp3PlusPlus`, a smart variant :class:`BoltzmannGumbel`, and a recent extension :class:`TsallisInf`,

- Index based UCB algorithms: :class:`EmpiricalMeans`, :class:`UCB`, :class:`UCBalpha`, :class:`UCBmin`, :class:`UCBplus`, :class:`UCBrandomInit`, :class:`UCBV`, :class:`UCBVtuned`, :class:`UCBH`, :class:`CPUCB`, :class:`UCBimproved`,

- Index based MOSS algorithms: :class:`MOSS`, :class:`MOSSH`, :class:`MOSSAnytime`, :class:`MOSSExperimental`,

- Bayesian algorithms: :class:`Thompson`, :class:`BayesUCB`, and :class:`DiscountedThompson`,

- Based on Kullback-Leibler divergence: :class:`klUCB`, :class:`klUCBloglog`, :class:`klUCBPlus`, :class:`klUCBH`, :class:`klUCBHPlus`, :class:`klUCBPlusPlus`, :class:`klUCBswitch`,

- Other index algorithms: :class:`DMED`, :class:`DMED.DMEDPlus`, :class:`IMED`, :class:`OCUCBH`, :class:`OCUCBH.AOCUCBH`, :class:`OCUCB`, :class:`UCBdagger`,

- Hybrids algorithms, mixing Bayesian and UCB indexes: :class:`AdBandits`,

- Aggregation algorithms: :class:`Aggregator` (mine, it's awesome, go on try it!), and :class:`CORRAL`, :class:`LearnExp`,

- Finite-Horizon Gittins index, approximated version: :class:`ApproximatedFHGittins`,

- An experimental policy, using a sliding window of for instance 100 draws, and reset the algorithm as soon as the small empirical average is too far away from the full history empirical average (or just restart for one arm, if possible), :class:`SlidingWindowRestart`, and 3 versions for UCB, UCBalpha and klUCB: :class:`SlidingWindowRestart.SWR_UCB`, :class:`SlidingWindowRestart.SWR_UCBalpha`, :class:`SlidingWindowRestart.SWR_klUCB` (my algorithm, unpublished yet),

- An experimental policy, using just a sliding window of for instance 100 draws, :class:`SlidingWindowUCB.SWUCB`, and :class:`SlidingWindowUCB.SWUCBPlus` if the horizon is known. There is also :class:`SlidingWindowUCB.SWklUCB`.

- Another experimental policy with a discount factor, :class:`DiscountedUCB` and :class:`DiscountedUCB.DiscountedUCBPlus`, as well as versions using klUCB, :class:`DiscountedUCB.DiscountedklUCB`, and :class:`DiscountedUCB.DiscountedklUCBPlus`.

- Other policies for the non-stationary problems: :class:`LM_DSEE`, :class:`SWHash_UCB.SWHash_IndexPolicy`, :class:`CD_UCB.CUSUM_IndexPolicy`, :class:`CD_UCB.PHT_IndexPolicy`, :class:`CD_UCB.UCBLCB_IndexPolicy`, :class:`CD_UCB.GaussianGLR_IndexPolicy`, :class:`CD_UCB.BernoulliGLR_IndexPolicy`, :class:`Monitored_UCB.Monitored_IndexPolicy`, :class:`OracleSequentiallyRestartPolicy`, :class:`AdSwitch`.

- A policy designed to tackle sparse stochastic bandit problems, :class:`SparseUCB`, :class:`SparseklUCB`, and :class:`SparseWrapper` that can be used with *any* index policy.

- A policy that implements a "smart doubling trick" to turn any horizon-dependent policy into a horizon-independent policy without loosing in performances: :class:`DoublingTrickWrapper`,

- An *experimental* policy, implementing a another kind of doubling trick to turn any policy that needs to know the range :math:`[a,b]` of rewards a policy that don't need to know the range, and that adapt dynamically from the new observations, :class:`WrapRange`,

- The *Optimal Sampling for Structured Bandits* (OSSB) policy: :class:`OSSB` (it is more generic and can be applied to almost any kind of bandit problem, it works fine for classical stationary bandits but it is not optimal), a variant for gaussian problem :class:`GaussianOSSB`, and a variant for sparse bandits :class:`SparseOSSB`. There is also two variants with decreasing rates, :class:`OSSB_DecreasingRate` and :class:`OSSB_AutoDecreasingRate`,

- The Best Empirical Sampled Average (BESA) policy: :class:`BESA` (it works crazily well),

- **New!** The UCBoost (Upper Confidence bounds with Boosting) policies, first with no boosting: :class:`UCBoost.UCB_sq`, :class:`UCBoost.UCB_bq`, :class:`UCBoost.UCB_h`, :class:`UCBoost.UCB_lb`, :class:`UCBoost.UCB_t`, and then the ones with non-adaptive boosting: :class:`UCBoost.UCBoost_bq_h_lb`, :class:`UCBoost.UCBoost_bq_h_lb_t`, :class:`UCBoost.UCBoost_bq_h_lb_t_sq`, :class:`UCBoost.UCBoost`, and finally the epsilon-approximation boosting with :class:`UCBoost.UCBoostEpsilon`,


- Some are designed only for (fully decentralized) multi-player games: :class:`MusicalChair`, :class:`MEGA`, :class:`TrekkingTSN`, :class:`MusicalChairNoSensing`, :class:`SIC_MMAB`...

.. note::

    The list above might not be complete, see the details below.


All policies have the same interface, as described in :class:`BasePolicy`,
in order to use them in any experiment with the following approach: ::

    my_policy = Policy(nbArms)
    my_policy.startGame()  # start the game
    for t in range(T):
        chosen_arm_t = k_t = my_policy.choice()  # chose one arm
        reward_t     = sampled from an arm k_t   # sample a reward
        my_policy.getReward(k_t, reward_t)       # give it the the policy
"""
from __future__ import division, print_function  # Python 2 compatibility

# --- Simple UCB policies
from .UCB import UCB


# --- Strategic UCB policies
from .StrategicBasePolicy import StrategicBasePolicy
from .StrategicIndexPolicy import StrategicIndexPolicy
from .H_UCB import H_UCB
from .RH_UCB import RH_UCB
from .Sampled_R_UCB import Sampled_R_UCB

from .usenumba import jit
