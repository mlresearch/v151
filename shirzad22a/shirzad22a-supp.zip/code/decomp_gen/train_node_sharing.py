import torch
torch.multiprocessing.set_sharing_strategy('file_system')

import wandb
import argparse

from decomp_gen.models.node_sharing import NodeSharing, NodeSharing_Without_Tree_Encoding, NodeSharing_Simple
from decomp_gen.data_structures.dataset import NodeSharingDataset, GraphDataset

from decomp_gen.models.nnutils import *
from decomp_gen import configs

import numpy as np
import math

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

SEED = 1234
TRAIN_RATIO = 0.7
VAL_RATIO = 0.1
TEST_RATIO = 1.0 - TRAIN_RATIO - VAL_RATIO

ALL_TARGETS = False

K = 5
EARLY_STOP_EPOCHS = 50

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--continue-training', default=False, type=bool)
    parser.add_argument('--model-name', default='node_sharing_tmp', type=str)
    # parser.add_argument('--mode', default='train', type=str)
    parser.add_argument('--optimizer', default='Adam', type=str)
    parser.add_argument('--lr', default=0.001, type=float)
    parser.add_argument('--loss-function', default='BCE', type=str)
    parser.add_argument('--data-name', default='grid', type=str)
    parser.add_argument('--epochs', default=5000, type=int)
    parser.add_argument('--tree-hidden-dim', default=64, type=int)
    parser.add_argument('--gnn-input-dim', default=128, type=int)
    parser.add_argument('--gnn-hidden-dim', default=128, type=int)
    parser.add_argument('--gnn-num-layers', default=7, type=int)
    parser.add_argument('--mlp-hidden-dim', default=64, type=int)
    parser.add_argument('--use-wandb', default=False, type=bool)
    parser.add_argument('--reorder-epochs', default=1, type=int)
    parser.add_argument('--num-workers', default=0, type=int)
    parser.add_argument('--batch-size', default=4, type=int)
    parser.add_argument('--sample-per-graph', default=64, type=int)
    args = parser.parse_args()

    return args

args = parse_args()


BATCH_SIZE = args.batch_size
data = NodeSharingDataset(args.data_name, '{}.dat'.format(args.data_name),
                              reorder_epochs=args.reorder_epochs)
data.sample_per_graph = args.sample_per_graph

def single_cluster_best_target_nll(output, all_targets):
    # best_nll = torch.tensor(1000.0)
    output = output.squeeze().view(-1, 1)

    loss_func = nn.BCELoss()
    total_prob = torch.tensor(0.0)

    for target in all_targets:
        target_tensor = torch.tensor(target).squeeze().view(-1, 1).to(device)
        # breakpoint()
        loss = loss_func(output, target_tensor) * output.shape[0]
        total_prob += torch.exp(-loss)

        # if loss.data < best_nll.data:
        #     best_nll = loss

    return -torch.log(total_prob)

def nll_with_all_targets(output, all_targets):
    output = output.squeeze()
    i = 0
    nll = torch.tensor(0.0)
    for t in all_targets:
        l = len(t[0])
        output_c = output[i:i+l]
        nll += single_cluster_best_target_nll(output_c, t)
        i = i + l

    return nll/len(output)

def collate(samples):
    batch = {
        'graphs': list(),
        'trees': list(),
        'cluster_nodes_idx': list(),
        'super_node_idx': list(),
        'samples_per_tree': list(),
        'masked_shared': list(),
        'target': list(),
        'all_correct_targets': list()
    }
    for sample in samples:
        if sample is None:
            continue
        batch['graphs'] = batch['graphs'] + sample['partial_graphs']
        batch['trees'].append(sample['tree'])
        batch['cluster_nodes_idx'] = batch['cluster_nodes_idx'] + sample['parent_nodes']
        batch['super_node_idx'].append(sample['super_node_idx'])
        batch['samples_per_tree'].append(sample['total_number_of_decisions'])
        batch['masked_shared'].append(sample['masked_shared'])
        batch['target'].append(sample['shared'])
        if ALL_TARGETS:
            batch['all_correct_targets'] = batch['all_correct_targets'] + sample['all_correct_targets']

    batch['target'] = torch.cat(batch['target'])
    batch['masked_shared'] = torch.cat(batch['masked_shared'], dim=0)

    return batch


def evaluate(model, eval_data, kk=K):
    model.eval()
    # data.mode = 'eval'
    data_loader = torch.utils.data.DataLoader(eval_data,
                                              batch_size=BATCH_SIZE, shuffle=True,
                                              num_workers=args.num_workers, collate_fn=collate,
                                              pin_memory=True)

    eval_loss = torch.tensor([0.0], device=device)

    if args.loss_function == 'BCE':
        loss_fn = nn.BCELoss()
    else:
        loss_fn = nn.MSELoss()

    Acc = BinaryClassificationMeter()

    with torch.no_grad():
        Acc.reset()
        cnt = 0

        for jj in range(kk):
            for i, batch in enumerate(data_loader):
                output = model(batch['graphs'], batch['trees'],
                               batch['cluster_nodes_idx'],
                               batch['super_node_idx'],
                               batch['samples_per_tree'],
                               batch['masked_shared'])

                output = output.view(-1, 1)
                batch['target'] = batch['target'].view(-1, 1).to(device)

                if ALL_TARGETS:
                    batch_loss = nll_with_all_targets(output, batch['all_correct_targets'])
                else:
                    batch_loss = loss_fn(output, batch['target'])

                eval_loss += batch_loss.data.detach() * batch['target'].shape[0]
                cnt += batch['target'].shape[0]

                Acc.update(output, batch['target'])

    return eval_loss / cnt, Acc, eval_loss/kk


def train_node_sharing(model, train_data, eval_data, model_name, checkpoint=None):
    best_loss = torch.tensor(1000000.0, device=device)
    best_accuracy = torch.tensor(0.0, device=device)

    data_loader = torch.utils.data.DataLoader(train_data,
                                                 batch_size=BATCH_SIZE, shuffle=True,
                                                 num_workers=args.num_workers, collate_fn=collate,
                                                 pin_memory=True)

    adr = os.path.join(configs.root_dir, 'saved_models', model_name)
    adr_state_dict = os.path.join(configs.root_dir, 'saved_models', model_name + '_state_dict')
    adr_state_dict_best = os.path.join(configs.root_dir, 'saved_models', model_name + '_state_dict_best')
    print("Saving model to: ", adr)

    if args.optimizer == 'Adam':
        optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, betas=(0.9, 0.999), eps=1e-08,
                                    weight_decay=0, amsgrad=False)
    elif args.optimizer == 'SGD':
        optimizer = torch.optim.SGD(model.parameters(), lr=args.lr, momentum=0.9)
    else:
        raise Exception('optimizer is not in options')

    if args.loss_function == 'BCE':
        loss_fn = nn.BCELoss()
    else:
        loss_fn = nn.MSELoss()

    Acc = BinaryClassificationMeter()

    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=25,
                                                           threshold=0.01,
                                                           threshold_mode='rel', cooldown=0, min_lr=0.0002, eps=1e-08,
                                                           verbose=True)

    start_epoch = 0

    if checkpoint is not None:
        optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        scheduler.load_state_dict(checkpoint['scheduler_state_dict'])
        start_epoch = checkpoint['epoch'] + 1
        best_loss = checkpoint['best_loss']
        best_accuracy = checkpoint['best_accuracy']

    early_stop_counter = 0

    for epoch in range(start_epoch, args.epochs):
        model.train()
        print("\nepoch: ", epoch)
        epoch_loss = torch.tensor([0.0], device=device)
        cnt = 0
        Acc.reset()

        for i, batch in enumerate(data_loader):

            optimizer.zero_grad()

            output = model(batch['graphs'], batch['trees'],
                           batch['cluster_nodes_idx'],
                           batch['super_node_idx'],
                           batch['samples_per_tree'],
                           batch['masked_shared'])

            output = output.view(-1, 1)
            batch['target'] = batch['target'].view(-1, 1).to(device)

            if ALL_TARGETS:
                batch_loss = nll_with_all_targets(output, batch['all_correct_targets'])
            else:
                batch_loss = loss_fn(output, batch['target'])

            epoch_loss += batch_loss.data.detach() * batch['target'].shape[0]
            cnt += batch['target'].shape[0]

            Acc.update(output, batch['target'])

            batch_loss.backward()
            optimizer.step()

            if i % 4 == 0:
                print('batch {}: average loss = {}'.format(i, epoch_loss / cnt))

        epoch_avg_loss = epoch_loss / cnt
        print("epoch loss: ", epoch_avg_loss)
        print("accuracy: ", Acc.acc)

        print('average loss per graph: ', epoch_loss / len(train_data))

        eval_loss_avg, eval_acc, eval_loss = evaluate(model, eval_data=eval_data)
        print("evaluation loss: ", eval_loss_avg)
        print('evaluation accuracy: ', eval_acc.acc)
        print('evaluation loss average per graph: ', eval_loss/len(eval_data))

        early_stop_counter += 1

        if eval_loss_avg < best_loss:
            best_loss = eval_loss_avg.data.detach()
            best_accuracy = eval_acc.acc.cpu().detach()
            torch.save(model, adr)
            torch.save({
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'scheduler_state_dict': scheduler.state_dict(),
                'best_loss': best_loss,
                'best_accuracy': best_accuracy
            }, adr_state_dict_best)

            early_stop_counter = 0

        torch.save({
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'scheduler_state_dict': scheduler.state_dict(),
                'best_loss': best_loss,
                'best_accuracy': best_accuracy
            }, adr_state_dict)

        print('best loss: ', best_loss)
        print('best accuracy: ', best_accuracy)

        scheduler.step(epoch_avg_loss)

        if wandb.run is not None:  # is initialized
            wandb.log(
                {'train/loss': epoch_loss.cpu() / cnt,
                 'train/acc': Acc.acc.cpu(),
                 'eval/loss': eval_loss_avg.cpu(),
                 'eval/acc': eval_acc.acc.cpu(),
                 'best_eval/loss': best_loss.cpu()
                 },
                step=epoch
            )

        if early_stop_counter >= EARLY_STOP_EPOCHS:
            return


def main():
    print(f'root_dir={configs.root_dir}')

    if args.use_wandb:
        wandb.init(project='decomp_gen', config=args)

    #making indices for train/test
    train_last_idx = int(float(len(data)) * TRAIN_RATIO)
    test_last_idx = int(float(len(data)) * TEST_RATIO) + train_last_idx

    indices = list(range(len(data)))

    train_idxs = indices[0:train_last_idx]
    test_idxs = indices[train_last_idx:test_last_idx]
    eval_idxs = indices[test_last_idx:]

    train_data = torch.utils.data.Subset(data, train_idxs)
    test_data = torch.utils.data.Subset(data, test_idxs)
    eval_data = torch.utils.data.Subset(data, eval_idxs)

    model = NodeSharing(max_cluster_size=data.C,
                        max_graph_size=data.N,
                        tree_hidden_dim=args.tree_hidden_dim,
                        gat_hidden_dim=args.gnn_hidden_dim,
                        gat_num_layers=args.gnn_num_layers,
                        node_feat_dim=args.gnn_input_dim,
                        mlp_hidden_dim=args.mlp_hidden_dim)

    checkpoint = None

    if args.continue_training:
        print('loading model to continue training ....')
        adr = os.path.join(configs.root_dir, 'saved_models', args.model_name + '_state_dict')
        # model = torch.load(adr, map_location=device)
        try:
            checkpoint = torch.load(adr)
            model.load_state_dict(checkpoint['model_state_dict'])
        except:
            print('state dict not found trying to load model . . .')
            adr = os.path.join(configs.root_dir, 'saved_models', args.model_name)
            model = torch.load(adr, map_location=device)

    model = model.to(device)
    try:
        train_node_sharing(model, train_data, eval_data, args.model_name, checkpoint)
    except:
        print('\ntraining finished')

    adr = os.path.join(configs.root_dir, 'saved_models', args.model_name)
    best_model = torch.load(adr, map_location=device)

    test_nlls = list()
    has_converged = False

    while not has_converged:
        test_eval_loss_per_decision, Acc, test_eval_loss = evaluate(best_model, test_data, kk=1)
        test_nlls.append(test_eval_loss / len(test_data))
        mean = np.mean(np.array(test_nlls))
        std = np.std(np.array(test_nlls))

        print('mean: ', mean)
        print('std: ', std)

        if len(test_nlls) > 5 and std/(math.sqrt(len(test_nlls))) < 0.01*mean:
            has_converged = True


    print('test nll/graph: ', np.mean(np.array(test_nlls)))

    train_eval_loss_per_decision, Acc, train_eval_loss = evaluate(best_model, train_data, kk=100)
    print('train nll/graph: ', train_eval_loss / len(train_data))
    print('train nll/decision: ', train_eval_loss_per_decision)

    # val_eval_loss_per_decision, Acc, val_eval_loss = evaluate(best_model, eval_data, kk=10)
    # print('val nll/graph: ', val_eval_loss / len(eval_data))
    # print('val nll/decision: ', val_eval_loss_per_decision)



if __name__ == "__main__":
    main()
