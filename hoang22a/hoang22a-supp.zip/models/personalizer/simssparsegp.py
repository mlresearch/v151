from models.personalizer.kernel import *


class SIMSSparseGP:
    def __init__(self, cov, mean, noise = np.log(0.5)):
        self.cov = cov
        self.mean = mean
        self.noise = noise

    @staticmethod
    def compute_log_det_inv(X):
        chol_X = tf.linalg.cholesky(X)
        chol_X_inv = tf.linalg.inv(chol_X)
        X_inv = tf.matmul(tf.transpose(chol_X_inv), chol_X_inv)
        logdet_X = 2.0 * KB.sum(KB.log(tf.linalg.tensor_diag_part(chol_X)))
        return X_inv, logdet_X

    def NLL(self, X, Y, Xs):  # this the ELBO of variational GP
        Yr = tf.reshape(tf.cast(tf.convert_to_tensor(Y), tf.float32), [-1, 1])
        Yc = Yr - self.mean.m(X)

        Kss = self.cov.cov(Xs)
        Ksx = self.cov.cov(Xs, X)
        Kxs = tf.transpose(Ksx)
        Ksx_Kxs = tf.matmul(Ksx, Kxs)

        T = Kss + tf.cast(KB.exp(-2.0 * self.noise), tf.float32) * Ksx_Kxs
        T_inv, logdet_T = self.compute_log_det_inv(T)

        Kss_inv, logdet_Kss = self.compute_log_det_inv(Kss)
        Ksx_Yc = tf.matmul(Ksx, Yc)

        quad_term = tf.cast(KB.exp(-2.0 * self.noise), tf.float32) * tf.matmul(tf.transpose(Yc), Yc) \
                    - tf.cast(KB.exp(-4.0 * self.noise), tf.float32) * tf.matmul(tf.transpose(Ksx_Yc), tf.matmul(T_inv, Ksx_Yc))

        logdet_Q_inv = -logdet_T + logdet_Kss - 2.0 * len(X) * self.noise
        trace_term = len(X) * Kss[0, 0] - tf.linalg.trace(tf.matmul(Kss_inv, Ksx_Kxs))

        res = -0.5 * logdet_Q_inv + 0.5 * quad_term + 0.5 * tf.cast(KB.exp(-2.0 * self.noise), tf.float32) * trace_term

        return res

    def predict(self, Xt, X, Y, Xs, var = False):
        Yr = tf.reshape(tf.cast(tf.convert_to_tensor(Y), tf.float32), [-1, 1])
        Yc = Yr - self.mean.m(X)
        if len(Xt) > len(Xs):
            Kts = tf.transpose(self.cov.cov(Xs, Xt))
        else:
            Kts = self.cov.cov(Xt, Xs)
        Kss, Ksx = self.cov.cov(Xs), self.cov.cov(Xs, X)
        Kxs = tf.transpose(Ksx)
        T = tf.linalg.inv(Kss + tf.cast(KB.exp(-2.0 * self.noise), tf.float32) * tf.matmul(Ksx, Kxs))
        Yt = self.mean.m(Xt) + tf.cast(KB.exp(-2.0 * self.noise), tf.float32) * tf.matmul(Kts, tf.matmul(T, tf.matmul(Ksx, Yc)))
        if var is False:
            return Yt
        return Yt, None