import sys
import os
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"
from os.path import dirname
sys.path.append(dirname("/home/user/neurips21/"))  # this is to add the project's path to PYTHONPATH so python can tell where to load the relevant parts of the code

# importing our utils function
from utils.utilities import *
# importing bits for our metric implementations
from utils.metric import *

# importing keras
from tensorflow.keras import backend as KB
import tensorflow as tf

# importing bits for our recommenders
from models.nets.simsnet import *
from models.nets.spenet import *
from models.recommenders.sims import *
from models.recommenders.spe import *
from models.recommenders.simsssl import *

# importing bits for our personalizers
from models.personalizer.kernel import *
from models.personalizer.simsgp import *
from models.personalizer.simspersonalizer import *
from models.personalizer.simssparsegp import *

# importing bits for our data loaders
from loaders.dataloader import *
from loaders.pairloader import *
from loaders.featureloader import *
from loaders.factory import *

# set random seed
fix_seed()

# set the GPU -- which one to be used for training -- later: figure out how to do multi-GPU training
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

INPUT_PATH = "/home/user/data/movielens/20M"  # base path for data
OUTPUT_PATH = "/home/user/neurips21_cache"  # base path for model + data saves

if not os.path.exists(OUTPUT_PATH):
    os.mkdir(OUTPUT_PATH)

MODEL_VERSION = "spenet-base-model"  # specific name for model cache
DATA_VERSION = "movielens-data"  # specific name for data loader cache

MODEL_CACHE = os.path.sep.join([OUTPUT_PATH, MODEL_VERSION])  # path to MODEL CACHE -- where to save our model artifacts
DATA_CACHE = os.path.sep.join([OUTPUT_PATH, DATA_VERSION])  # path to DATA CACHE -- where to save our data objects

if not os.path.exists(MODEL_CACHE):  # check if the folder exists already
    os.makedirs(MODEL_CACHE)  # if not, create it

META_CHANNELS = ['Plot', 'AveRating']
channels = {}
for CHANNEL in META_CHANNELS:
    channels[CHANNEL] = os.path.sep.join([INPUT_PATH, "{}.npz".format(CHANNEL)])

n_pair_per_user, window, timecut, version = 10, 10, 1365957431, 1

print("Loading Data")
DataBuilder : DataFactory = load_object(DATA_CACHE + "/data-pair-per-user-{}-window-{}-timecut-{}.dat".format(n_pair_per_user, window, timecut))
DataBuilder.reset_feature_channel(channels)

test = DataBuilder.unseen_items
print("No. of test item = {}".format(len(test)))

print("Loading Parameters ...")  # this is the user-provided parameters needed to build our metric net
hyper_params = {'max_no_item' : 26801, 'feature_channels_dim' : DataBuilder.featurizer.feature_dims,  # {"Title" : 50, "Poster" : 512}
                'loss' : Losses.BinaryCrossEntropy, 'hidden_dim' : 50, 'id_embedding_dim' : 16, 'learning_rate' : 5 * 1e-4}

n_iter = 50
md_name = "spe-version-{}-pair-per-user-{}-window-{}-timecut-{}-epoch-{}-seed-{}".format(version, n_pair_per_user, window, timecut, n_iter, seed)
SPEEngine = SPE(hyper_params, 'Plot', 'AveRating', md_name)  # load these parameters and create a metric net

print("Training [GPU = {}] ...".format(os.environ["CUDA_VISIBLE_DEVICES"]))
SPEEngine.fit(DataBuilder.train_dataset, DataBuilder.validate_dataset, MODEL_CACHE, max_num_epoch = n_iter)  # fit the model

print("Saving Model ...")
SPEEngine.save(MODEL_CACHE)  # save the model

print("Loading Model ...")
SPEEngine.load(MODEL_CACHE)  # save the model

print("Recommendation Metric Evaluating ...")  # evaluate the model on an official set of metrics
K = 10  # the metrics will be evaluated with respect to this specification of top K

metrics = {'mrr': mean_reciprocal_rank, 'precision_at_{}'.format(K): precision_at_k, 'ndcg_at_{}'.format(K): ndcg_at_k}
message, unseen_results = DataBuilder.metric_eval_streamline_unpersonalized(SPEEngine, metrics, test,
                                                                            K = K, forward = False, verbal = False)
print(message)