import torch
import torch.nn as nn

class Mlp(nn.Module):

    def __init__(self, input_size, output_size, hidden_sizes):
        super(Mlp, self).__init__()
        self.input_linear = nn.Linear(input_size, hidden_sizes[0])
        self.hidden_layers = nn.ModuleList([nn.Linear(hidden_sizes[i], hidden_sizes[i+1])
                                            for i in range(len(hidden_sizes)-1)])
        self.output_linear = nn.Linear(hidden_sizes[-1], output_size)
        self.f = nn.ReLU()
        # self.f = nn.Tanh()

    def forward(self, x):
        h = self.f(self.input_linear(x))
        for L in self.hidden_layers:
            h = self.f(L(h))
        output = self.output_linear(h)
        return output
