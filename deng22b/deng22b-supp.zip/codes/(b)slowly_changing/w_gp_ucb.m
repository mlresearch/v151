
 function [regrets_track, arm_track] = w_gp_ucb(gamma ,B, f_test,kernel,T,lambda,epsilon,R)
   
    


        [~, arms] = size(f_test(1,:));
        %[max_value,max_arm] = max(f_test);
        %kernel_t = kernel;
        mu_t = zeros(arms,1); sigma2_t = zeros(arms,1);
        
        regrets_cumula = 0;
        regrets_track = zeros(T,1);

        rewards_cumula = 0;
        rewards_track = zeros(T,1);
        
        arm_track = zeros(T,1);
        y_track = zeros(T,1);

     
        for t = 1 : T   
            if t <= T/2
                ft = f_test(1,:) + (f_test(2,:) - f_test(1,:))* (2* t/T);
            else
                ft = f_test(2,:) + (f_test(3,:) - f_test(2,:))* (  (2* t - T)/T);
            end
            
                %ft = f_test(1,:) + (f_test(2,:) - f_test(1,:))* (t/T);
                B = max(ft);
                max_value = max(ft);
                
                gamma_t =  log(t);  % x_t only 1 dimension
                
                beta_t = B+   R/sqrt(lambda) *sqrt(2*gamma_t + 2);   %%%?
                if t == 1
                    arm_t = randi(arms);
                else
                    [~,arm_t] = max( mu_t + beta_t*sqrt(sigma2_t) );
                end
                arm_track(t) = arm_t;
                
                rewards_cumula = rewards_cumula + ft(arm_t);
                rewards_track(t) = rewards_cumula;
                               
                
                regrets_cumula = regrets_cumula + max_value - ft(arm_t);
                regrets_track(t) = regrets_cumula;

                noise = randn;  %sub-gaussian  normal 
                y_t = ft(arm_t) + epsilon*noise;
                y_track(t) = y_t;

                
                sqomegat=zeros(t,1);
                for i = 1:t
                    sqomegat(i) = sqrt(gamma^(-t));
                end
                
                W = diag(sqomegat);
                
                y1t = y_track(1:t);
                y1t = W* y1t;
                
                
                
                ktx = W*zeros(t, arms);
                Kt = zeros(t, t);
                for i = 1 : t
                    ktx(i, :) = kernel(arm_track(i),:);
                    for j = 1 : t
                        Kt(i,j) = kernel(arm_track(i), arm_track(j));
                    end
                end
                
                ktx= W* ktx;
                Kt = W* Kt * W;
                
                for k = 1 : arms
                    mu_t (k) = transpose( ktx(:, k) ) * inv(Kt + lambda*gamma^(-t)*eye(t))* y1t;
                    sigma2_t(k) = kernel(k,k) - transpose( ktx(:, k) )* inv(Kt + lambda*gamma^(-t)*eye(t)) * ktx(:, k);
                end
                

                
            
        end
        end
