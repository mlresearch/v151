% plot(mean(tgp_regrets_light)./T_vec,'r')
% hold on
% plot(mean(ata_regrets_light)./T_vec,'b')
% plot(mean(mom_regrets_light)./T_vec,'g')
T = 500
% k = ceil(log(T));
% N = floor(T/k);

% load('tgp_regrets_total_stu.mat')
% 
% 
% load('tgp_regrets_avg_stu.mat')



tgp_total = mean(tgp_regrets_total_stu);
tgp_total_restart = mean(tgp_regrets_total_stu_restart);



plot(tgp_total(1:T),'r','linewidth',4,'linestyle','-.')
hold on
% plot(tgp_total_restart(1:T),'b','linestyle','--','linewidth',4)
plot(tgp_total_restart(1:T),'linewidth',4,'color',[0.13,0.54,0.13])
% axis([0 20000 0 1.6e4])
xlabel('Iteration','FontSize',20)
ylabel('Cumulative Regret','FontSize',20)
legend('Static','Restart','Location','northwest')



% plot(tgp_total(1:k*N),'r')
% hold on
% plot(ata_total(1:k*N),'b')
% plot(mom_total(1:k*N),'g')
% axis([100 10000 0 2])

figure
tgp_avg = mean(tgp_regrets_avg_stu);
tgp_avg_restart = mean(tgp_regrets_avg_stu_restart);

plot(tgp_avg(1:T),'r','linewidth',1.5,'linestyle','-.')
hold on
plot(tgp_avg_restart(1:T),'b','linestyle','--','linewidth',1.5)
% plot(mom_avg(1:k*N),'linewidth',1.5,'color',[0.13,0.54,0.13])
% axis([100 20000 0 2])
xlabel('Iteration','FontSize',20)
ylabel('Time-average Regret','FontSize',20)
legend('static','restart')
% legend({'TGP-UCB','ATA-GP-UCB','MoMA-GP-UCB'},'FontSize',18, 'Location','northeast','FontWeight','Normal')