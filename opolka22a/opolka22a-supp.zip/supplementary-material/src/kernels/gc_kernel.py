import numpy as np
import gpflow
from gpflow import Parameter
from gpflow import covariances as cov
import tensorflow as tf
import tensorflow_probability as tfp

from inducing_points import NodeInducingPoints
from utils import sparse_mat_to_sparse_tensor, normalize_adj, \
    dense_tensor_to_sparse_tensor, get_submatrix


class GraphConvolutional(gpflow.kernels.base.Kernel):

    def __init__(self, base_kernel, sparse, num_convs):
        super().__init__()
        self.base_kernel = base_kernel
        self.sparse = sparse
        self.num_convs = num_convs
        self.weights = [Parameter(np.array([(1.0 / (i + 2.0))]), transform=tfp.bijectors.Sigmoid(),
                                  name=f"weight_{i + 1}") for i in range(num_convs)]

        # To be set with `set_subgraph` before the kernel is first used
        self.conv_mat = None
        self.center_idcs = None

        # Setup for sparse vs dense operations
        if sparse:
            self.matmul_f = tf.sparse.sparse_dense_matmul
            self.eye_f = tf.sparse.eye
            self.add_f = tf.sparse.add
        else:
            self.matmul_f = tf.matmul
            self.eye_f = tf.eye
            self.add_f = tf.add

    def K(self, X, Y=None, presliced=False):
        """
        X are the nodes features of the subgraph currently set with `set_subgraph` and has shape
        [subgraph_size, num_features].
        """
        assert Y is None, "Unexpected argument Y"
        num_nodes = self.conv_mat.shape[0]

        cov = self.base_kernel.K(X)
        for i in range(self.num_convs):
            conv_mat = self.add_f(self.weights[i] * self.conv_mat,
                                  (1.0 - self.weights[i]) * self.eye_f(num_nodes, dtype=cov.dtype))
            cov = self.matmul_f(conv_mat, cov)
            cov = self.matmul_f(conv_mat, cov, adjoint_b=True)
        # cov = tf.gather(tf.gather(cov, self.center_idcs, axis=0), self.center_idcs, axis=1)
        return cov

    def K_diag(self, X, presliced=False):
        return tf.linalg.diag_part(self.K(X))

    def Kzx(self, Z, X):
        """
        X are the nodes features of the subgraph currently set with `set_subgraph` and has shape
        [subgraph_size, num_features]. Z are the inducing points of shape [num_inducing,
        num_features].
        """
        num_nodes = self.conv_mat.shape[0]

        cov = self.base_kernel.K(X, Z)                                                              # [subgraph_size, num_inducing]
        for i in range(self.num_convs):
            conv_mat = self.add_f(self.weights[i] * self.conv_mat,
                                  (1.0 - self.weights[i]) * self.eye_f(num_nodes, dtype=cov.dtype)) # [subgraph_size, subgraph_size]
            cov = self.matmul_f(conv_mat, cov)                                                      # [subgraph_size, num_inducing]
        # cov = tf.gather(cov, self.center_idcs, axis=0)                                              # [batch_size, num_inducing]
        cov = tf.transpose(cov)
        return cov

    def Kzz(self, Z):
        cov = self.base_kernel.K(Z)
        return cov

    def set_subgraph(self, conv_mat, center_idcs):
        """
        A convolution operation may be applied only for the subgraph relevant to the current batch.
        This saves a lot of time as it reduces the size of the convolution and covariance matrix
        from the number of all nodes to the number of nodes in the image of the convolution
        operation.
        :param conv_mat: Convolution matrix of shape [subgraph_size, subgraph_size]. May either be
        a sparse or dense tensor.
        :param center_idcs: The subgraph contains nodes that are required for performing the
        convolution but which may not be part of the minibatch for which we would like to compute
        the covariance. Therefore, this Tensor contains the indices of the nodes in the subgraph,
        for which we want to compute the covariance. The indexing is relative to the subgraph.
        For example let's say our graph has 10 nodes in total, our minibatch contains nodes 4 and 8
        and nodes 2, 3, 4, 6, 8 are required to compute the convolution (i.e. these nodes are in the
        domain of the convolution operation). Then these nodes form the subgraph with a 5x5
        convolution matrix and center_idcs is equal to [2, 5].
        """
        self.center_idcs = center_idcs
        self.conv_mat = conv_mat
        if not self.sparse and isinstance(conv_mat, tf.sparse.SparseTensor):
            self.conv_mat = tf.sparse.to_dense(tf.sparse.reorder(conv_mat))


@cov.Kuu.register(NodeInducingPoints, GraphConvolutional)
def Kuu_graph_polynomial(inducing_variable, kernel, jitter=None):
    """
    Computes the covariance matrix between the inducing points (which are not
    associated with any node).
    :param inducing_variable: Set of inducing points of type
    NodeInducingPoints.
    :param kernel: Kernel of type GraphPolynomial.
    :return: Covariance matrix between the inducing variables.
    """
    return kernel.Kzz(inducing_variable.Z)


@cov.Kuf.register(NodeInducingPoints, GraphConvolutional, tf.Tensor)
def Kuf_graph_polynomial(inducing_variable, kernel, X):
    """
    Computes the covariance matrix between inducing points (which are not
    associated with any node) and normal inputs.
    :param inducing_variable: Set of inducing points of type
    NodeInducingPoints.
    :param kernel: Kernel of type GraphPolynomial.
    :param X: Normal inputs. Note, however, that to simplify the
    implementation, we pass in the indices of the nodes rather than their
    features directly.
    :return: Covariance matrix between inducing variables and inputs.
    """
    return kernel.Kzx(inducing_variable.Z, X)
