from utils.defaults import *

class SIMSHyperParams:  # the place where we load the SIMS parameters provided by users and convert them into expected form for the model
    def __init__(self, hyper_param_dict):
        """
        Takes dictionary of hyper params as passed from sagemaker_wrapper or entry script
        and instantiate a param object
        :param hyper_param_dict:
        """
        self.no_item = hyper_param_dict.get('max_no_item', SIMSDefaults.DEFAULT_MAX_ITEM)
        self.no_user = hyper_param_dict.get('max_no_user', SIMSDefaults.DEFAULT_MAX_USER)

        self.id_embedding_dim = hyper_param_dict.get('id_embedding_dim', SIMSDefaults.DEFAULT_ID_DIM)
        self.feature_channels_dim = hyper_param_dict.get('feature_channels_dim', SIMSDefaults.DEFAULT_FEATURE_CHANNEL_DIM)
        # feature_channels: feature_channel_name -> feature_channel_dim
        self.hidden_dim = hyper_param_dict.get('hidden_dim', SIMSDefaults.DEFAULT_HIDDEN_DIM)

        self.loss = hyper_param_dict.get('loss', SIMSDefaults.DEFAULT_LOSS)
        self.optimizer: Optimizers = hyper_param_dict.get('optimizer', SIMSDefaults.DEFAULT_OPTIMIZER)
        self.learning_rate: float = hyper_param_dict.get('learning_rate', SIMSDefaults.DEFAULT_LEARNING_RATE)


class SPEHyperParams:  # the place where we load the SPE parameters provided by users and convert them into expected form for the model
    def __init__(self, hyper_param_dict):
        """
        Takes dictionary of hyper params as passed from sagemaker_wrapper or entry script
        and instantiate a param object
        :param hyper_param_dict:
        """
        self.no_item = hyper_param_dict.get('max_no_item', SPEDefaults.DEFAULT_MAX_ITEM)
        self.no_user = hyper_param_dict.get('max_no_user', SPEDefaults.DEFAULT_MAX_USER)

        self.id_embedding_dim = hyper_param_dict.get('id_embedding_dim', SPEDefaults.DEFAULT_ID_DIM)
        self.feature_channels_dim = hyper_param_dict.get('feature_channels_dim', SPEDefaults.DEFAULT_FEATURE_CHANNEL_DIM)
        # feature_channels: feature_channel_name -> feature_channel_dim
        self.hidden_dim = hyper_param_dict.get('hidden_dim', SPEDefaults.DEFAULT_HIDDEN_DIM)

        self.loss = hyper_param_dict.get('loss', SPEDefaults.DEFAULT_LOSS)
        self.optimizer: Optimizers = hyper_param_dict.get('optimizer', SPEDefaults.DEFAULT_OPTIMIZER)
        self.learning_rate: float = hyper_param_dict.get('learning_rate', SPEDefaults.DEFAULT_LEARNING_RATE)