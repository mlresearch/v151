from .base import ProposalModelBase
from .adapter import *
