import torch
import torch.nn as nn


class DiscriminatorLinear(nn.Module):
    """ Model for discrimination via latent bottleneck class """

    NAME = "linear"

    def __init__(self, config, constants, bootstrap_model=None):
        super(DiscriminatorLinear, self).__init__()

        self.config = config
        self.constants = constants
        self.dim = constants["n_hidden"]

        if config["feature_type"] == 'feature':

            self.word_embedding = nn.Embedding(config["vocab_size"], constants["n_hidden"])

            self.input_encoder = nn.Sequential(
            )

            self.context_encoder = self.input_encoder

        else:
            raise NotImplementedError()

        if torch.cuda.is_available():
            self.cuda()

        if bootstrap_model is not None:
            self.load_state_dict(bootstrap_model.state_dict())

    def gen_score(self, batch_input, batch_input_count, batch_context, batch_context_count):

        if batch_context.dim() == 2:

            encode_input = self.encode_input(batch_input, batch_input_count)              # Batch x dim
            encode_context = self.encode_input(batch_context, batch_context_count)        # Batch x dim

            return torch.mul(encode_input, encode_context).sum(1)                         # Batch

        elif batch_context.dim() == 3:

            encode_input = self.encode_input(batch_input, batch_input_count)              # Batch x dim
            encode_context = self.encode_input(batch_context, batch_context_count)        # Batch x k x dim

            return torch.mul(encode_input[:, None, :], encode_context).sum(2)  # Batch x k

        else:
            raise AssertionError("Unhandled context dimension %d" % batch_context.dim())

    def encode_input(self, batch_input, batch_count):
        """
        batch_input: of size batch x max_len containing tokens in {0, 1, 2, ...., vocab_size - 1 }
                     batch_input[doc, i]  contains a token_id
        batch_count: of size batch x max_len where batch_count[doc, i] is the normalized number of times
                    token batch_input[doc, i] appears in doc. We normalize it by dividing by the number of tokens
                    in doc
        """

        if batch_input.dim() == 2:

            word_embed = self.word_embedding(batch_input)               # batch x max_len x word_embedding
            word_embed_mul = word_embed * batch_count[:, :, None]       # batch x max_len x word_embedding
            word_embed_mul = word_embed_mul.sum(1)                      # batch x word_embedding
            return self.input_encoder(word_embed_mul)                   # Batch x dim

        elif batch_input.dim() == 3:

            word_embed = self.word_embedding(batch_input)               # batch x k x max_len x word_embedding
            word_embed_mul = word_embed * batch_count[:, :, :, None]    # batch x k x max_len x word_embedding
            word_embed_mul = word_embed_mul.sum(2)                      # batch x k x word_embedding
            return self.input_encoder(word_embed_mul)                   # Batch x k x dim

        else:
            raise AssertionError("Unhandled context dimension %d" % batch_input.dim())

    def save(self, folder_name, model_name=None):

        if model_name is None:
            torch.save(self.state_dict(), folder_name + "nce_k_model")
        else:
            torch.save(self.state_dict(), folder_name + model_name)

    def load(self, folder_name, model_name=None):

        if model_name is None:
            self.load_state_dict(torch.load(folder_name + "nce_k_model"))
        else:
            self.load_state_dict(torch.load(folder_name + model_name))
