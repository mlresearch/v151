function [x, history, time] = admm_v2(y, D, k, lambda, rho, varargin)
%%
flag = ~mod(k, 2);  % if k is even, then we have a D in front

n    = length(y);
m    = size(D,1);

if size(D,2) == 2
    
    edges1  = D(:,1);
    edges2  = D(:,2);
    
    %Make sparse D matrix
    D       = sparse((1:m)', edges1, 1, m, n, 10*m);
    D       = D + sparse((1:m)', edges2, -1, m, n);

else
    edges1  = zeros(m,1);
    edges2  = zeros(m,1);
    
    for i = 1:m
        Iy          = find(D(i,:) ~= 0);
        edges1(i)   = Iy(1);
        edges2(i)   = Iy(2);
    end
    
    D=sparse(D);

end

% Choose the right algorithm
if k == 0 % direct solution
    fprintf('k=0: Direct Solution.\n');
    x       = graphtv(y, edges1, edges2, lambda);
    history = 0;
    return;
end

history = [];
time    = [];
L       = D'*D;
Lk      = speye(n);

for i = 1:ceil(k/2)
    Lk = L*Lk;
end

% preprocessing for SDD solver
A           = (rho * (Lk*Lk) + speye(n));
tol_pcg     = 1e-6;
CHOLESKY    = 0;

tol_abs     = 1e-5;
tol_rel     = 1e-4;
maxiter     = 500;

% initialization
x           = y;
m           = n;
z           = zeros(size(A,1), 1);
u           = z;
t0          = cputime;

for iter = 1:1:maxiter 

   if ~CHOLESKY
        [x, pcg_flg] = pcg(A, (Lk*(rho*z-u)+y), tol_pcg, k*100, spdiags(diag(A), 0, ...
            size(A,1), size(A,2)));
        if pcg_flg~=0
            fprintf('Warning: PCG did not converge. Start using Cholesky\n');
            CHOLESKY=1;
            [LF, ~, S] = chol(A, 'lower', 'matrix');
        end
   end
   
   if CHOLESKY   
        xx  = Lk * (rho * z - u) + y;
        x   = S*(LF'\(LF\(S'*xx)));
   end

    Lkx     = Lk*x;
    
    if flag
        z_new = graphtv(Lkx + u/rho, edges1, edges2, lambda/rho);
    else
        z_new = soft_thresh(Lkx + u/rho, lambda/rho);
    end
    s   = rho * norm(Lk * (z_new - z));
    z   = z_new;
    
    u   = u + rho*(Lkx - z);
    r   = norm(Lkx-z);
    
    eps_pri = sqrt(n)*tol_abs + tol_rel*max(norm(Lkx), norm(z));    
    eps_dual = sqrt(m)*tol_abs + tol_rel*norm(Lk'*u);
    fobj     = obj_eval(D, L, k, y, x, lambda);  
    ftime    = cputime - t0; 
    
    if ~mod(iter, 50)
        fprintf('iter = %d. fobj = %f\n', iter, fobj);    
    end
   
%     if ~mod(iter,50)
%         fprintf('[%d] [r,s] = %f, %f, [eps_pri, eps_dual] = %f, %f. \n', iter, r, s, eps_pri, eps_dual);
%     end
%     
%     if r < eps_pri && s< eps_dual
%         conv = 1;
%         fprintf('converged.\n')
%     elseif iter >= maxiter
%         conv = 1;
%         fprintf('Reached maxiter.\n')
%     end
    
    history = [history, fobj];
    time    = [time, ftime]; 
    
    if r > 10*s
        
        rho = rho*2;
        A   = A * 2 - speye(n);
        if CHOLESKY
            [LF, ~, S] = chol(A, 'lower', 'matrix');
        end
        
    elseif s > 10*r
        rho = rho/2;
        A   = A/2 + speye(n)/2;
        if CHOLESKY
            [LF, ~, S] = chol(A, 'lower', 'matrix');
        end
    end
    
end


end