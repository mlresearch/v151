function [x, history, time] = gradbb(y, D, k, lambda)
%%
n   = length(y);
m   = size(D,1);

if size(D, 2) == 2
    
    edges1  = D(:,1);
    edges2  = D(:,2);

    %Make sparse D matrix
    D       = sparse((1:m)', edges1, 1, m, n, 10*m);
    D       = D + sparse((1:m)', edges2, -1, m, n);

else
    edges1  = zeros(m, 1);
    edges2  = zeros(m, 1);
    
    for i = 1:m
        Iy          = find(D(i, :) ~= 0);
        edges1(i)   = Iy(1);
        edges2(i)   = Iy(2);
    end
    
    D = sparse(D);

end

L = D'*D;
D = sparse(D);
O = D;

for i = 1:k
    if mod(i, 2)
        O = D' * O;
    else
        O = D * O;
    end
end

%line-search parameter
alpha   = 0.1; %intepolation parameter
beta    = 0.8; %backtracking parameter

%tolerance and maxiter
upper_gamma = 0.05; 
maxiter     = 5000;
history     = [];
time        = [];

% initialization with line search
u           = zeros(size(O, 1), 1);
fx          = 0; 
eta         = 0;
fobj        = obj_eval(D, L, k, y, y, lambda);
flag        = 0;
t0          = cputime; 

for iter = 1:1:maxiter 
    %
    if iter == 1
        grad = compute_grad(D, L, k, y, u);
        
        %Projected gradient step with backtracking line search
        gamma   = 1;
        u_new   = proj_lambda(u - gamma*grad, lambda);
        fx_new  = dobj_eval(D, L, k, y, u_new); 
    
        while fx_new > fx - alpha * gamma * norm(grad, 2) * norm(grad, 2)
            gamma   = beta*gamma;
            u_new   = proj_lambda(u - gamma*grad, lambda);
            fx_new  = dobj_eval(D, L, k, y, u_new); 
        end
        
        grad_new = compute_grad(D, L, k, y, u_new);
        z_new    = u_new;
    end
    
    if iter > 1 && flag == 0
    
        % calculate the stepsize
        diff_u      = u_new - u; 
        diff_grad   = grad_new - grad; 
        gamma       = min(upper_gamma, diff_u'*diff_grad/(diff_grad'*diff_grad));

        %Projected gradient step with momentum and barzilai-borwein step.
        u           = u_new; 
        z           = z_new; 
        grad        = grad_new;
        
        z_new       = proj_lambda(u - gamma*grad, lambda);
        temp        = 1/2 + sqrt(1 + 4*eta*eta)/2;
        ratio       = (1 - eta)/temp;
        eta         = temp; 
        u_new       = ratio * z + (1 - ratio) * z_new;         
        grad_new    = compute_grad(D, L, k, y, u_new);
    end
    
    if iter > 1 && flag == 1
        
        % recalculate the iterates. 
        u_new       = z_new;
        grad_new    = compute_grad(D, L, k, y, u_new);
        flag        = 2; 
    
    end
       
    if iter > 1 && flag == 2
        
        % calculate the stepsize
        diff_u      = u_new - u; 
        diff_grad   = grad_new - grad; 
        gamma       = min(upper_gamma, diff_u'*diff_grad/(diff_grad'*diff_grad));
        
        %Projected gradient step with barzilai-borwein step.
        u           = u_new; 
        grad        = grad_new;
        u_new       = proj_lambda(u - gamma*grad, lambda);
        grad_new    = compute_grad(D, L, k, y, u_new);
        
    end
    
    STu        = Times_ST(D, L, k, u_new);
    x          = -STu + y; 
    fobj_old   = fobj;
    fobj       = obj_eval(D, L, k, y, x, lambda);
    ftime      = cputime - t0; 

    if fobj > fobj_old && iter > 12000 && flag == 0
        flag = 1; 
    end
        
    if ~mod(iter, 100)
        fprintf('iter = %d. fobj = %f. gamma = %f. flag = %d\n', iter, fobj, gamma, flag);  
    end
    
    history = [history, fobj];
    time    = [time, ftime]; 
    
end

end
