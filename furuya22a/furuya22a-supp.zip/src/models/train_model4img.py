import copy
import os

import torch
from src import get_module_logger


def train_one_epoch(model, criterion, optimizer, train_dl, test_dl, device, clip_value=None, clip_norm=None):
    """Algorithm for one epoch training with gradient monitor."""
    epoch_loss = {"train": [], "val": []}
    epoch_acc = {"train": [], "val": []}

    running_grad_hh = 0.0
    running_grad_ih = 0.0
    running_grad_out = 0.0
    running_grad_hh_clip = 0.0
    running_grad_ih_clip = 0.0
    running_grad_out_clip = 0.0
    if (clip_value is not None) or (clip_norm is not None):
        clipping = True
    else:
        clipping = False

    for phase in ["train", "val"]:
        if phase == "train":
            model.train()
            dataloader = train_dl
        else:
            model.eval()
            dataloader = test_dl

        input_sizes = 0
        running_loss = 0.0
        running_corrects = 0

        for inputs, labels in dataloader:
            input_sizes += len(inputs)
            inputs = inputs.to(device, non_blocking=True)
            labels = labels.to(device, non_blocking=True)
            optimizer.zero_grad()

            # forward pass
            with torch.set_grad_enabled(phase == "train"):
                outputs = model(inputs)[-1]
                _, preds = torch.max(outputs, 1)
                loss = criterion(outputs, labels)

                # backward pass
                if phase == "train":
                    loss.backward()
                    # gradient monitor
                    grad_hh = float(
                        torch.norm(model.rnn.weight_hh_l0.grad.detach().to(device)).to("cpu").numpy().astype("float64")
                    )
                    grad_ih = float(
                        torch.norm(model.rnn.weight_ih_l0.grad.detach().to(device)).to("cpu").numpy().astype("float64")
                    )
                    grad_out = float(
                        torch.norm(model.out.weight.grad.detach().to(device)).to("cpu").numpy().astype("float64")
                    )
                    running_grad_hh = max(running_grad_hh, grad_hh)
                    running_grad_ih = max(running_grad_ih, grad_ih)
                    running_grad_out = max(running_grad_out, grad_out)
                    if clip_value is not None:
                        torch.nn.utils.clip_grad_value_(model.rnn.parameters(), clip_value)
                    if clip_norm is not None:
                        torch.nn.utils.clip_grad_norm_(model.rnn.parameters(), clip_norm)
                    if clipping:
                        grad_hh_clip = float(
                            torch.norm(model.rnn.weight_hh_l0.grad.detach().to(device))
                            .to("cpu")
                            .numpy()
                            .astype("float64")
                        )
                        grad_ih_clip = float(
                            torch.norm(model.rnn.weight_ih_l0.grad.detach().to(device))
                            .to("cpu")
                            .numpy()
                            .astype("float64")
                        )
                        grad_out_clip = float(
                            torch.norm(model.out.weight.grad.detach().to(device)).to("cpu").numpy().astype("float64")
                        )
                        running_grad_hh_clip = max(running_grad_hh_clip, grad_hh_clip)
                        running_grad_ih_clip = max(running_grad_ih_clip, grad_ih_clip)
                        running_grad_out_clip = max(running_grad_out_clip, grad_out_clip)
                    optimizer.step()

                # statistics
                running_loss += loss.item()
                running_corrects += torch.sum(preds == labels.data)

        epoch_loss[phase] = running_loss / input_sizes
        epoch_acc[phase] = (running_corrects.double() / input_sizes).item()
    return (
        epoch_loss,
        epoch_acc,
        running_grad_hh,
        running_grad_ih,
        running_grad_out,
        running_grad_hh_clip,
        running_grad_ih_clip,
        running_grad_out_clip,
    )


def train(
    model,
    criterion,
    optimizer,
    train_dl,
    test_dl,
    epochs,
    device,
    scheduler=None,
    clip_value=None,
    clip_norm=None,
    semi_epoch=None,
    tags=None,
    artifacts=None,
    experiment=None,
):
    """Algorithm for whole training for classification task."""
    logger = get_module_logger(__name__)

    best_loss = {phase: float("inf") for phase in ["train", "val"]}
    best_loss_epoch = {phase: 0 for phase in ["train", "val"]}
    best_acc = {phase: 0.0 for phase in ["train", "val"]}
    best_acc_epoch = {phase: 0 for phase in ["train", "val"]}

    model = model.to(device)
    best_loss_wts = copy.deepcopy(model.state_dict())
    best_acc_wts = copy.deepcopy(model.state_dict())

    # logger.debug('--Begin Training--')
    for epoch in range(1, epochs + 1):
        logger.info("Epoch {}/{}".format(epoch, epochs))
        logger.info("-" * 10)

        (
            epoch_loss,
            epoch_acc,
            grad_hh,
            grad_ih,
            grad_out,
            grad_hh_clip,
            grad_ih_clip,
            grad_out_clip,
        ) = train_one_epoch(
            model, criterion, optimizer, train_dl, test_dl, device, clip_value=clip_value, clip_norm=clip_norm
        )
        for phase in ["train", "val"]:
            logger.info("{:5} Loss: {:.4f} Acc: {:.4f}".format(phase, epoch_loss[phase], epoch_acc[phase]))
            if best_loss[phase] > epoch_loss[phase]:
                best_loss[phase] = epoch_loss[phase]
                best_loss_epoch[phase] = epoch
                if phase == "val":
                    best_loss_wts = copy.deepcopy(model.state_dict())
            if best_acc[phase] < epoch_acc[phase]:
                best_acc[phase] = epoch_acc[phase]
                best_acc_epoch[phase] = epoch
                if phase == "val":
                    best_acc_wts = copy.deepcopy(model.state_dict())

        if scheduler is not None:
            scheduler.step()

    if experiment is not None:
        log_dir = os.path.join('models/logs', experiment, 'model')
        torch.save(best_acc_wts, os.path.join(log_dir, 'best_acc_wts/state_dict.pth'))
        torch.save(best_loss_wts, os.path.join(log_dir, 'best_loss_wts/state_dict.pth'))

    return None
