from models.cycle_gan.cycle_gan import CycleGAN
