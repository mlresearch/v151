import numpy as np
from scipy.stats import norm
# import time

# start = time.time()

##############################################################################
#TS Normal Rewards
sample = 1000
T = 100

mu = np.array([1,1.5]) #normal mean
sigma = np.array([1,1])
K = mu.size

muhat31 = np.zeros([sample, K])
error31 = np.zeros([sample, K])
R = np.zeros([sample,T])
I = np.zeros([sample,T])
mutemp = np.zeros([sample, K, T])    
    
for i in range(K):
    I[:,i] = i

for s in range(sample): 
    theta = np.zeros([K, T])
    E = np.zeros([K,T])
    M = np.zeros([K,T])
    Ripw = np.zeros([K,T])
    Raipw = np.zeros([K,T])
    
    for t in range(K):
        R[s,t] = np.random.normal(mu[np.int(I[s,t])],sigma[np.int(I[s,t])])

    for i in range(K):
        mutemp[s,i,t] = np.sum(R[s,:t+1][I[s,:t+1]==i])/(np.where(I[s,:t+1]==i)[0].size+1)
    for t in range(K,T):
        for i in range(K):
            theta[i,t] = np.random.normal(mutemp[s,i,t-1],np.sqrt(1/(np.where(I[s,:t]==i)[0].size+1)))                       
        I[s,t] = np.argmax(theta[:,t])
        R[s,t] = np.random.normal(mu[np.int(I[s,t])],sigma[np.int(I[s,t])])

        for i in range(K):
            mutemp[s,i,t] = np.sum(R[s,:t+1][I[s,:t+1]==i])/(np.where(I[s,:t+1]==i)[0].size+1)
    
    muhat31[s,:]= mutemp[s,:,-1]
    error31[s,:] = mutemp[s,:,-1] - mu 
     
bias31 = np.mean(error31, axis=0)   
print('bias is', bias31) 
print('muhat is', np.mean(muhat31, axis=0))
np.save('bias31.npy', bias31)
np.save('mutemp31.npy', mutemp)
np.save('muhat31.npy', muhat31)        
np.save('R31.npy', R)
np.save('I31.npy', I)
np.savetxt('bias31.dat',np.transpose(bias31.reshape(2,1)),header='arm1,arm2',delimiter=',',newline='\n')
np.savetxt('muhat31.dat',np.transpose(muhat31),header='arm1,arm2',delimiter=',',newline='\n')

##############################################################################
#IPW
muipw31 = np.zeros([sample, K, T])
muaipw31 = np.zeros([sample, K, T])
MSEipw31 = np.zeros([K, T])
MSEaipw31 = np.zeros([K, T])
for s in range(sample):
    E = np.zeros([K,T])
    M = np.zeros([K,T])
    Ripw = np.zeros([K,T])
    Raipw = np.zeros([K,T])
    for t in range(K,T):
        for i in range(K):
            E[i,t] = norm.cdf((mutemp[s,i,t-1]-mutemp[s,1-i,t-1])/np.sqrt(1/(np.where(I[s,:t]==i)[0].size+1)+1/(np.where(I[s,:t]==1-i)[0].size+1)))
            # M[i,t] = np.sum(R[s,:t][I[s,:t]==i])/np.where(I[s,:t]==i)[0].size
            M[i,t] = mutemp[s,i,t-1]
            Ripw[i,t] = (I[s,t]==i)*R[s,t]/E[i,t]
            Raipw[i,t] = (I[s,t]==i)*R[s,t]/E[i,t]+(1-(I[s,t]==i)/E[i,t])*M[i,t]
        for i in range(K):
            muipw31[s,i,t] =  np.mean(Ripw[i,K:t+1])
            muaipw31[s,i,t] =  np.mean(Raipw[i,K:t+1])   

for t in range(K,T):
    for i in range(K):
        MSEipw31[i,t] = np.var(muipw31[:,i,t])+(np.mean(muipw31[:,i,t])-mu[i])**2
        MSEaipw31[i,t] = np.var(muaipw31[:,i,t])+(np.mean(muaipw31[:,i,t])-mu[i])**2     
        
muhatipw31 = np.mean(muipw31, axis=0)          
muhataipw31 = np.mean(muaipw31, axis=0)          
print('muipw is', muhatipw31[:,-1])
print('muaipw is', muhataipw31[:,-1])
np.save('muhatipw31.npy', muhatipw31)
np.save('muhataipw31.npy', muhataipw31)
np.save('muipw31.npy', muipw31)
np.save('muaipw31.npy', muaipw31)
np.save('MSEipw31.npy', MSEipw31)
np.save('MSEaipw31.npy', MSEaipw31)

###############################################################################
#MB
B = 1000

mumb31 = np.zeros([sample, K, T]) #bootstrap muhat
errormb31 = np.zeros([sample, K])
muhatmb31 = np.zeros([sample, K, T]) #corrected muhat
MSEmb31 = np.zeros([K, T])

for s in range(sample):
    print('MB normal sample is', s+1) 
    
    mub = np.zeros(K)
    varb = np.zeros(K)
    for i in range(K):
        mub[i] =  np.mean(R[s][I[s]==i])
        varb[i] = np.var(R[s][I[s]==i])
        
    muboots = np.zeros([K,B])
    Rmb = np.zeros([B,T])
    Imb = np.zeros([B,T])
    mutemp = np.zeros([B, K, T])  
    
    for i in range(K):       
        Imb[:,i] = i
    for b in range(B): 
        theta = np.zeros([K, T])
             
        for t in range(K):
            Rmb[b,t] = np.random.normal(mub[np.int(Imb[b,t])],np.sqrt(varb[np.int(Imb[b,t])]))         
        for i in range(K):
            mutemp[b, i, t] = np.sum(Rmb[b,:t+1][Imb[b,:t+1]==i])/(np.where(Imb[b,:t+1]==i)[0].size+1)        
        for t in range(K,T):
            for i in range(K):
                theta[i,t] = np.random.normal(mutemp[b, i, t-1],np.sqrt(1/(np.where(Imb[b,:t]==i)[0].size+1)))
            Imb[b,t] = np.argmax(theta[:,t])
            Rmb[b,t] = np.random.normal(mub[np.int(Imb[b,t])],np.sqrt(varb[np.int(Imb[b,t])]))
            for i in range(K):
                mutemp[b, i, t] = np.sum(Rmb[b,:t+1][Imb[b,:t+1]==i])/(np.where(Imb[b,:t+1]==i)[0].size+1)
        # muboots[:,b]= mutemp[:,-1]
    mumb31[s] = np.mean(mutemp,axis = 0)    
    muhatmb31[s] = 2*muhat31[s].reshape(K,1) - mumb31[s]
    
for t in range(K,T):
    for i in range(K):
        MSEmb31[i,t] = np.var(muhatmb31[:,i,t])+(np.mean(muhatmb31[:,i,t])-mu[i])**2

print('muhatmb is', np.mean(muhatmb31[:,:,-1], axis=0))

np.save('muhatmb31.npy', muhatmb31)
np.save('MSEmb31.npy', MSEmb31)

##############################################################################
#TS Bernoulli Rewards
mu = np.array([0.3, 0.6]) #bernoulli mean
K = mu.size
muhat32 = np.zeros([sample, K])
error32 = np.zeros([sample, K])

R = np.zeros([sample,T])
I = np.zeros([sample,T])
mutemp = np.zeros([sample, K, T])  

for i in range(K):
      I[:,i] = i
  
for s in range(sample): 
    theta = np.zeros([K, T]) 
    E = np.zeros([K,T])
    M = np.zeros([K,T])
    Ripw = np.zeros([K,T])
    Raipw = np.zeros([K,T])
    
    for t in range(K):
        R[s,t] = np.random.binomial(1, mu[np.int(I[s,t])])

    for i in range(K):
        mutemp[s,i,t] = np.sum(R[s,:t+1][I[s,:t+1]==i])/(np.where(I[s,:t+1]==i)[0].size+1)
    for t in range(K,T):
        for i in range(K):
            theta[i,t] = np.random.normal(mutemp[s,i,t-1],np.sqrt(1/(np.where(I[s,:t]==i)[0].size+1)))
                        
        I[s,t] = np.argmax(theta[:,t])
        R[s,t] = np.random.binomial(1, mu[np.int(I[s,t])])

        for i in range(K):
            mutemp[s,i,t] = np.sum(R[s,:t+1][I[s,:t+1]==i])/(np.where(I[s,:t+1]==i)[0].size+1)
            
    muhat32[s,:]= mutemp[s,:,-1]
    error32[s,:] = mutemp[s,:,-1] - mu 
   
bias32 = np.mean(error32, axis=0)   
print('bias is', bias32) 
print('muhat is', np.mean(muhat32, axis=0))
np.save('bias32.npy', bias32)
np.save('mutemp32.npy', mutemp)
np.save('muhat32.npy', muhat32)    
np.save('R32.npy', R)
np.save('I32.npy', I)
np.savetxt('bias32.dat',np.transpose(bias32.reshape(2,1)),header='arm1,arm2',delimiter=',',newline='\n')
np.savetxt('muhat32.dat',np.transpose(muhat32),header='arm1,arm2',delimiter=',',newline='\n')

##############################################################################
#IPW
muipw32 = np.zeros([sample, K, T])
muaipw32 = np.zeros([sample, K, T])
MSEipw32 = np.zeros([K, T])
MSEaipw32 = np.zeros([K, T])
for s in range(sample):
    E = np.zeros([K,T])
    M = np.zeros([K,T])
    Ripw = np.zeros([K,T])
    Raipw = np.zeros([K,T])
    for t in range(K,T):
        for i in range(K):
            E[i,t] = norm.cdf((mutemp[s,i,t-1]-mutemp[s,1-i,t-1])/np.sqrt(1/(np.where(I[s,:t]==i)[0].size+1)+1/(np.where(I[s,:t]==1-i)[0].size+1)))
            # M[i,t] = np.sum(R[s,:t][I[s,:t]==i])/np.where(I[s,:t]==i)[0].size
            M[i,t] = mutemp[s,i,t-1]
            Ripw[i,t] = (I[s,t]==i)*R[s,t]/E[i,t]
            Raipw[i,t] = (I[s,t]==i)*R[s,t]/E[i,t]+(1-(I[s,t]==i)/E[i,t])*M[i,t]
        for i in range(K):
            muipw32[s,i,t] =  np.mean(Ripw[i,K:t+1])
            muaipw32[s,i,t] =  np.mean(Raipw[i,K:t+1])   

for t in range(K,T):
    for i in range(K):
        MSEipw32[i,t] = np.var(muipw32[:,i,t])+(np.mean(muipw32[:,i,t])-mu[i])**2
        MSEaipw32[i,t] = np.var(muaipw32[:,i,t])+(np.mean(muaipw32[:,i,t])-mu[i])**2     
        
muhatipw32 = np.mean(muipw32, axis=0)          
muhataipw32 = np.mean(muaipw32, axis=0)          
print('muipw is', muhatipw32[:,-1])
print('muaipw is', muhataipw32[:,-1])
np.save('muhatipw32.npy', muhatipw32)
np.save('muhataipw32.npy', muhataipw32)
np.save('muipw32.npy', muipw32)
np.save('muaipw32.npy', muaipw32)
np.save('MSEipw32.npy', MSEipw32)
np.save('MSEaipw32.npy', MSEaipw32)


###############################################################################
#MB
B = 1000

mumb32 = np.zeros([sample, K, T]) #bootstrap muhat
errormb32 = np.zeros([sample, K])
muhatmb32 = np.zeros([sample, K, T]) #corrected muhat
MSEmb32 = np.zeros([K, T])


for s in range(sample):
    print('MB bernoulli sample is', s+1) 
    
    mub = np.zeros(K)
    varb = np.zeros(K)
    for i in range(K):
        mub[i] =  np.mean(R[s][I[s]==i])
        varb[i] = np.var(R[s][I[s]==i])
        
    muboots = np.zeros([K,B])
    Rmb = np.zeros([B,T])
    Imb = np.zeros([B,T])
    mutemp = np.zeros([B, K, T])  
    
    for i in range(K):       
        Imb[:,i] = i
    for b in range(B): 
        theta = np.zeros([K, T])
             
        for t in range(K):
            Rmb[b,t] = np.random.normal(mub[np.int(Imb[b,t])],np.sqrt(varb[np.int(Imb[b,t])])) 
        for i in range(K):
            mutemp[b, i, t] = np.sum(Rmb[b,:t+1][Imb[b,:t+1]==i])/(np.where(Imb[b,:t+1]==i)[0].size+1)        
        for t in range(K,T):
            for i in range(K):
                theta[i,t] = np.random.normal(mutemp[b, i, t-1],np.sqrt(1/(np.where(Imb[b,:t+1]==i)[0].size+1)))
            Imb[b,t] = np.argmax(theta[:,t])
            Rmb[b,t] = np.random.normal(mub[np.int(Imb[b,t])],np.sqrt(varb[np.int(Imb[b,t])])) 
            for i in range(K):
                mutemp[b, i,t] = np.sum(Rmb[b,:t+1][Imb[b,:t+1]==i])/np.where(Imb[b,:t+1]==i)[0].size
        # muboots[:,b]= mutemp[:,-1]
    mumb32[s] = np.mean(mutemp,axis = 0)    
    muhatmb32[s] = 2*muhat32[s].reshape(K,1) - mumb32[s]
    

        
for t in range(K,T):
    for i in range(K):
        MSEmb32[i,t] = np.var(muhatmb32[:,i,t])+(np.mean(muhatmb32[:,i,t])-mu[i])**2

print('muhatmb is', np.mean(muhatmb32[:,:,-1], axis=0))

np.save('muhatmb32.npy', muhatmb32)
np.save('MSEmb32.npy', MSEmb32)


