
import sys
sys.path.append("..")

from environment.Discrete_env import Discrete_env
from policies.Chernoff_sampling import Chernoff_Sampling
from policies.Chernoff_sampling_expl import Chernoff_Sampling_expl
from policies.Random_sampling import Random_Sampling
from policies.Top2_sampling import Top2_Sampling
from policies.Njav_sampling import Njav_Sampling
from plots.plot_sample_complexity import plot_sample_complexity
from plots.plot_error_rate import plot_error_rate
from util.file_IO import file_IO

import pickle


if __name__ == "__main__":
    env = Discrete_env()
    env.discrete_env4()
    
    chern = Chernoff_Sampling(env)
    chern.run_Chernoff_Sampling()
    
    rand = Random_Sampling(env)
    rand.run_Random_Sampling()
    
    top2 = Top2_Sampling(env)
    top2.run_Top2_Sampling()
    
    njav = Njav_Sampling(env)
    njav.run_Njav_Sampling()
    
    chern_e = Chernoff_Sampling_expl(env)
    chern_e.run_Chernoff_Sampling_expl()
    
    file = open('discrete_env4_1', 'wb')
    # dump information to that file
    pickle.dump([[top2.top2_err, rand.rand_err, chern.chern_err, njav.njav_err, chern_e.chern_err],[top2.top2_sample_complexity, rand.rand_sample_complexity, chern.chern_sample_complexity, 
                                                                                                    njav.njav_sample_complexity, chern_e.chern_sample_complexity]],file)
    # close the file
    file.close()
    
    top2_err, rand_err, chern_err, njav_err, top2_sample_complexity, rand_sample_complexity, chern_sample_complexity, njav_sample_complexity = file_IO('discrete_env4_1')
    
    
    
    plot_sample_complexity(chern.chern_sample_complexity, rand.rand_sample_complexity, top2.top2_sample_complexity, njav.njav_sample_complexity, env.num_sources, env.num_hypo, "env4_1")
    plot_error_rate(chern.chern_err, rand.rand_err, top2.top2_err, njav.njav_err, env.num_sources, env.num_hypo, env.T, "env4_1")
    
