rm(list = ls())
set.seed(123)
library(magrittr)
library(parallel)
library(RcppArmadillo)
library(RcppXPtrUtils)
library(parallelDist)

ITER = 100

source('dissim_sine.R')
source('dissim_sine_comp.R')

no.cores = round(detectCores() * 0.75)

#-- activate the following lines for analysing 'Computers' data set-------
  # training.data.original <-
  #   read.table( 'Computers/Computers_TRAIN.tsv', sep = '\t')
  # test.data.original <-
  #   read.table('Computers/Computers_TEST.tsv', sep = '\t')
#-------------------------------------------------------------------------
  
#-- activate the following lines for analysing 'Smooth Subspace' data set-------
  training.data.original <-
    read.table( 'SmoothSubspace/SmoothSubspace_TRAIN.tsv', sep = '\t')
  test.data.original <-
    read.table('SmoothSubspace/SmoothSubspace_TEST.tsv', sep = '\t')
#-------------------------------------------------------------------------
  
  
  training.data <-
    training.data.original %>% na.omit() %>% as.matrix()
  test.data <- test.data.original %>% na.omit() %>% as.matrix()
  
  rm(training.data.original)
  rm(test.data.original)
  
  whole.data = rbind(training.data, test.data)
  
  rm(training.data)
  rm(test.data)
  
  no.of.classes <- whole.data[, 1] %>% unique() %>% length()
  
  out1 <- list()
  
  split.class = split.data.frame(whole.data, f = whole.data[, 1]) #splitting the data by classlabels
  
  rm(whole.data)
  
  nj <- sapply(split.class, nrow)
  n.all <- sum(nj)
  prior_j <- nj / n.all
  d <- ncol(split.class[[1]]) - 1
  J <- length(nj)
  nj_train <- round(nj * 0.5)
  ntrain = sum(nj_train)
  
  D = do.call('rbind', split.class)
  ul = sapply(split.class, function(df)
    unique(df[, 1]))
  
  rm(split.class)
  ix = c(0, cumsum(nj))
  D.distmat = as.matrix(dissim.sin(train.set = D[, -1], no.cores = no.cores))
  D.distmat.comp = as.matrix(dissim.sin.comp(train.set = D[, -1], no.cores = no.cores))
  colnames(D.distmat) = rownames(D.distmat) = colnames(D.distmat.comp) = rownames(D.distmat.comp) = paste('V', 1:n.all, sep =
                                                                                                            '')
  
  rm(D)
  
  Tjj.mat = Tjj.comp.mat = NULL
  for (j in 1:J) {
    Tjj.mat[[j]] = D.distmat[(ix[j] + 1):ix[j + 1], (ix[j] + 1):ix[j + 1]]
    Tjj.comp.mat[[j]] = D.distmat.comp[(ix[j] + 1):ix[j + 1], (ix[j] + 1):ix[j +
                                                                               1]]
  }
  
  O = combn(1:no.of.classes, 2)
  Tij.mat = Tij.comp.mat = rep(list(NULL), J)
  for (nc in 1:ncol(O)) {
    vec = O[, nc]
    i = vec[1]
    j = vec[2]
    
    # print((ix[i]+1):ix[i+1])
    # print((ix[j]+1):ix[j+1])
    
    Tij.mat[[i]][[j]] = D.distmat[(ix[i] + 1):ix[i + 1], (ix[j] + 1):ix[j +
                                                                          1]]
    Tij.mat[[j]][[i]] = D.distmat[(ix[j] + 1):ix[j + 1], (ix[i] + 1):ix[i +
                                                                          1]]
    
    Tij.comp.mat[[i]][[j]] = D.distmat.comp[(ix[i] + 1):ix[i + 1], (ix[j] +
                                                                      1):ix[j + 1]]
    Tij.comp.mat[[j]][[i]] = D.distmat.comp[(ix[j] + 1):ix[j + 1], (ix[i] +
                                                                      1):ix[i + 1]]
  }
  # clusterExport(cl, ls())
  
  for(
    u in 1:ITER
    # .combine = rbind,
    # .packages = c('RcppArmadillo', 'RcppXPtrUtils', 'parallelDist', 'magrittr')
  ) {
    
    
    train.index = test.index = train.sample = test.sample = list(NULL)
    ground.label = NULL
    for (cnt in 1:J)
      # partitioning into training and test set
    {
      train.index[[cnt]] <- sort(sample(1:nj[cnt], size = nj_train[cnt]))
      test.index[[cnt]] <-
        sort(setdiff(1:nj[cnt], train.index[[cnt]]))
    }
    
    njtrain <- sapply(train.index, length) #training sizes
    njtest <- sapply(test.index, length)
    nj <- njtrain + njtest
    
    ground.label = unlist(sapply(1:J, function(val)
      rep(ul[val], njtest[val])))
    
    Tjj <- lapply(1:J, function(x) {
      tsin <- Tjj.mat[[x]][train.index[[x]], train.index[[x]]]
      tsin.comp <-
        Tjj.comp.mat[[x]][train.index[[x]], train.index[[x]]]
      
      return(c(sum(tsin), sum(tsin.comp)) / (njtrain[x] * (njtrain[x] - 1)))
    })
    
    Tjj <- Tjj %>% do.call('rbind', .) %>% as.data.frame()
    colnames(Tjj) <- c('sin', 'sin.comp')
    gc()
    
    
    T.sin = T.sin.comp = matrix(0, J, J)
    for (nc in 1:ncol(O)) {
      vec = O[, nc]
      i = vec[1]
      j = vec[2]
      
      y = Tij.mat[[i]][[j]][train.index[[i]], train.index[[j]]]
      T.sin[i, j] = T.sin[j, i] <- sum(y) / (njtrain[i] * njtrain[j])
      
      y = Tij.comp.mat[[i]][[j]][train.index[[i]], train.index[[j]]]
      T.sin.comp[i, j] = T.sin.comp[j, i] <-
        sum(y) / (njtrain[i] * njtrain[j])
      
    }
    
    gc()
    
    tmp1 = tmp1.comp =  NULL
    for (jx in 1:J) {
      tmp = tmp.comp =  NULL
      for (kx in 1:J) {
        if (jx == kx) {
          tmp[[kx]] = rowMeans(Tjj.mat[[jx]][test.index[[jx]], train.index[[kx]]])
          tmp.comp[[kx]] = rowMeans(Tjj.comp.mat[[jx]][test.index[[jx]], train.index[[kx]]])
        } else{
          tmp[[kx]] = rowMeans(Tij.mat[[jx]][[kx]][test.index[[jx]], train.index[[kx]]])
          tmp.comp[[kx]] = rowMeans(Tij.comp.mat[[jx]][[kx]][test.index[[jx]], train.index[[kx]]])
        }
      }
      tmp1[[jx]] = do.call('rbind', tmp)
      tmp1.comp[[jx]] = do.call('rbind', tmp.comp)
    }
    
    tmp2 = do.call('cbind', tmp1) # each column corresponds to a test observation. each row corresponds to a class
    tmp2.comp = do.call('cbind', tmp1.comp) # each column corresponds to a test observation. each row corresponds to a class
    
    d0.lbl = apply(tmp2, 2, function(vec) {
      which.min(Tjj$sin - 2 * vec)
    }) # labels predicted by delta0
    
    d0.comp.lbl = apply(tmp2.comp, 2, function(vec) {
      which.min(Tjj$sin.comp - 2 * vec)
    })# labels predicted by delta1
    
    theta.comp = rep(0, ncol(tmp2))
    
    for (kx in 1:ncol(tmp2)) {
        votes.comp = apply(O, 2, function(vec) {
        i = vec[1]
        j = vec[2]
        
        discrim = ((Tjj$sin.comp[i] + Tjj$sin.comp[j] - 2 * T.sin.comp[i, j]) * (
          Tjj$sin.comp[j] - 2 * tmp2.comp[j, kx] - Tjj$sin.comp[i] + 2 * tmp2.comp[i, kx]
        )
        ) +
          ((Tjj$sin.comp[j] - Tjj$sin.comp[i]) * (
            Tjj$sin.comp[j] - 2 * tmp2.comp[j, kx] + Tjj$sin.comp[i] - 2 * tmp2.comp[i, kx] + 2 *
              T.sin.comp[i, j]
          )
          )
        ifelse(discrim > 0, i, j)
      })
      
      theta.comp[kx] = as.numeric(names(which.max(table(votes.comp)))) #majority voting for delta2
    }
    
    out1[[u]] = c(
      mean(ul[d0.lbl] != ground.label),
      mean(ul[d0.comp.lbl] != ground.label),
      mean(ul[theta.comp] != ground.label)
    )
    if(u%%10==0) print(u)
  }
  
  out2 = do.call('rbind',out1)
  colnames(out2) <- c('delta0',
                      'delta1',
                      'delta2')
  
  ERR <- colMeans(out2)
  SE <- apply(out2, 2, sd) / sqrt(ITER)
  print(rbind(ERR,SE)) # estimated misclassification probabilities along with standard errors

