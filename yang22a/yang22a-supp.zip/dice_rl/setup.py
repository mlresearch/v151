from setuptools import find_packages
from setuptools import setup

setup(
    name='dice_rl',
    description=(
        'anonymous code submission for ICML 2021.'
    ),
    packages=find_packages(),
    package_data={},
    install_requires=[
        'tensorflow>=2.2.0',
        'tensorflow-probability>=0.9.0',
        'tf-agents>=0.5.0',
        'gym>=0.17.0',
        'numpy',
        'pyglib',
        'scipy',
    ])
