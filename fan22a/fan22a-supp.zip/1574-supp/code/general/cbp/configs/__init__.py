from .test_config import TestConfig

__all__ = [
    "TestConfig"
]
