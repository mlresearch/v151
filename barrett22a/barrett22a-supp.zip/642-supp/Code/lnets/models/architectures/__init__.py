from lnets.models.architectures.fully_convolutional_2d import FullyConv2D
from lnets.models.architectures.fully_connected import FCNet
from lnets.models.architectures.VAE import fcMNISTVAE
from lnets.models.architectures.hard_coded import *
