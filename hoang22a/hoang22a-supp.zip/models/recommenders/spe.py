from models.nets.spenet import *
import tqdm
from utils.params import *
from utils.utilities import announce


def compute_batch_acc(output, truth):
    Y_pred, Y_true = tf.reshape(tf.cast((output >= 0.5), tf.float32), [-1]), truth[:, 0]
    err = KB.sum(KB.abs(Y_pred - Y_true))
    n_pair = Y_pred.shape[0]
    return err, n_pair


def get_single_recommendation(item, item_pos, scores, candidates, K = 25):
    ratings = []
    for i in range(len(candidates)):
        ratings.append(scores[item_pos, i])
    ratings = np.asarray(ratings)
    indices = (-ratings).argsort()[:(K + 1)]
    res = []
    for pos in indices:
        if candidates[pos] != item and len(res) < K:
            res.append(candidates[pos])
    return res

class SPE:
    def __init__(self, params, content_name, side_name, md_name):
        self.params = SPEHyperParams(params)
        self.network = SPENet(self.params, content_name, side_name)
        self.content_name, self.side_name = content_name, side_name
        self.md_name = md_name

    def compute_acc(self, dataset):
        err, n_pairs = 0.0, 0
        for i in tqdm.tqdm(range(len(dataset))):
            batch = dataset[i]
            [item_A, features_A, item_B, features_B], truth = batch[0], batch[1]
            output = self.network.model([item_A, features_A[self.content_name], features_A[self.side_name],
                                         item_B, features_B[self.content_name], features_B[self.side_name]])  # probability that Y = 1
            batch_err, batch_size = compute_batch_acc(output, truth)
            err += batch_err
            n_pairs += batch_size
        return err, n_pairs

    def compute_training_loss(self, inputs, truth):
        [item_A, features_A, item_B, features_B] = inputs
        output = self.network.model([item_A, features_A[self.content_name], features_A[self.side_name],
                                     item_B, features_B[self.content_name], features_B[self.side_name]])  # probability that Y = 1
        if self.params.loss == Losses.BinaryCrossEntropy:
            return output, self.network.loss.loss(output, truth[:, 0]) # if this is keras binary cross entropy loss
        return output, self.network.loss.loss(output, truth)

    def fit(self, train_dataset, validate_dataset, MODEL_PATH, max_num_epoch = 100):
        self.network.compile_network(verbal = False)
        valid_acc = 0.
        for epoch in range(max_num_epoch):
            print("Epoch {}".format(epoch + 1))
            counter = tqdm.trange(len(train_dataset))
            for i in counter:
                batch = train_dataset[i]
                inputs, truth = batch[0], batch[1]
                with tf.GradientTape() as tape:
                    output, L = self.compute_training_loss(inputs, truth)
                err, batch_size = compute_batch_acc(output, truth)
                batch_acc = 1.0 - (err * 1.0 / batch_size)
                counter.set_postfix_str("Loss = {:.4f} and Batch Acc = {:.4f}".format(L, batch_acc))
                gradient = tape.gradient(L, self.network.model.trainable_weights)
                self.network.optimizer.optimizer.apply_gradients(zip(gradient, self.network.model.trainable_weights))

            err, n_pairs = self.compute_acc(validate_dataset)
            acc = 1.0 - (err * 1.0 / n_pairs)
            print("Validation Acc = {:.4f}".format(acc))

            self.network.model.save(MODEL_PATH + "/{}.last.hdf5".format(self.md_name))
            if acc > valid_acc:
                print("Validation improved from {} to {}. Saving model to {} ...".format(valid_acc, acc, MODEL_PATH + "/{}.best.hdf5".format(self.md_name)))
                self.network.model.save(MODEL_PATH + "/{}.best.hdf5".format(self.md_name))
                valid_acc = acc

    def load(self, MODEL_PATH, option = 'best'):  # available options are 'best' and 'last' with 'best' means the best checkpoint in terms of validation
        filepath = MODEL_PATH + "/{}.{}.hdf5".format(self.md_name, option)
        self.network = SPENet(self.params, self.content_name, self.side_name)  # the params here need to be consistent with those used to create and train the saved model
        self.network.model.load_weights(filepath)
        self.network.compile_network(verbal = False)

    def save(self, MODEL_PATH):  # save the model
        filepath = MODEL_PATH + "/{}.last.hdf5".format(self.md_name)  # this is called at the end of training so it is going to be the last model (could be different from the best model so far)
        self.network.model.save(filepath)

    def eval(self, test_dataset):  # evaluate the sims metric on a binary classification task: (item_A, item_B) -> similar or not?
        err, n_pairs = self.compute_acc(test_dataset)
        acc = 1.0 - (err * 1.0 / n_pairs)
        print("Test Acc = {:.4f}".format(acc))

    def get_recommendation(self, items, candidates, featurizer, interaction_data_loader = None, K = 25, verbal = False):  # generate the top-K items for a given item from a pool of candidates
        candidate_features, candidate_ids = featurizer.featurize(candidates)
        item_features, item_ids = featurizer.featurize(items)

        V_items = self.network.tower([item_ids, item_features[self.content_name], item_features[self.side_name]])
        V_candidates = self.network.tower([candidate_ids, candidate_features[self.content_name], candidate_features[self.side_name]])

        scores = 1.0 - 1.0 / (1.0 + KB.exp(-1.0 * tf.matmul(V_items, tf.transpose(V_candidates))))
        scores = scores.numpy()

        res = {}
        for i in range(len(items)):
            announce("Evaluating Item No {} with ID = {}".format(i + 1, items[i]), verbal = verbal)
            res[items[i]] = get_single_recommendation(items[i], i, scores, candidates, K = K)
        return res

