from sklearn.datasets import make_moons, make_circles, make_classification
from sklearn.model_selection import train_test_split
import numpy as np
import torchvision.transforms as transforms

class ToyDataset():

    def __init__(self, num_sample, direction, sample_type):

        rng = np.random.RandomState(0)

        if sample_type == 'make_circles':
            self.X, self.y = make_circles(n_samples=num_sample, factor=0.5,  noise=0.1, random_state=rng)
        elif sample_type == 'make_moons':
            self.X, self.y = make_moons(n_samples=num_sample, noise=0.1, random_state=rng)
        elif sample_type == 'make_classification':
            self.X, self.y = make_classification(n_samples=num_sample, n_features=2, n_redundant=0, random_state=rng)
        else:
            raise ValueError(f"Invalid sample type: \"{sample_type}\"")

        self.num_sample = num_sample//2
        self.reverse = (direction == 'ba')
        self.transform_fn = transforms.ToTensor()
        self.srcs, self.tgts = self.X[self.y==0,:], self.X[self.y==1,:]

        # X_train = torch.load("/X_train.pt") # shape 2000x2 / 2000x1, dtype = torch.Float32 .cuda() cuda.Float32
        # X_train = data['X_train']


    def __getitem__(self, index):
        # print(self.srcs[index].shape, self.tgts[index].shape)
        return {'src': transform_fn(self.tgts[index]) if self.reverse else self.srcs[index], 
                'tgt': transform_fn(self.srcs[index]) if self.reverse else self.tgts[index]}

    def __len__(self):
        return self.num_sample
