######################################
# Most parts of code from https://github.com/dmlc/dgl/tree/master/examples/pytorch/jtnn
######################################
import os
from typing import List
from dgl import DGLGraph


import torch
import torch.nn as nn
from .nnutils import GRUUpdate, cuda, tocpu, graphs_batch_offsets
from dgl import batch, bfs_edges_generator, line_graph
import dgl.function as DGLF
import numpy as np

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


def level_order(forest, roots):
    if torch.cuda.is_available() and not os.getenv('NOCUDA', None):
        forest = tocpu(forest)
    edges = bfs_edges_generator(forest, roots)
    if len(edges) == 0:
        # no edges in the tree; do not perform loopy BP
        return
    _, leaves = forest.find_edges(edges[-1])
    edges_back = bfs_edges_generator(forest, roots, reverse=True)
    yield from reversed(edges_back)
    yield from edges


class EncoderGatherUpdate(nn.Module):
    def __init__(self, hidden_size):
        nn.Module.__init__(self)
        self.hidden_size = hidden_size

        self.W = nn.Linear(2 * hidden_size, hidden_size)

    def forward(self, nodes):
        x = nodes.data['x']
        m = nodes.data['m']
        if torch.isnan(nodes.data['x']).any() or torch.isnan(nodes.data['m']).any():
            print('in EncoderGatherUpdate:')
            breakpoint()
        return {
            'h': torch.relu(self.W(torch.cat([x, m], 1))),
        }


class TreeEncoder(nn.Module):
    def __init__(self, hidden_size, max_num_nodes=None, embedding=None):
        # if max_num_nodes = None, we initialize node representations with random noise
        # o.w. we give them embedding from one-hot vectors
        nn.Module.__init__(self)
        self.hidden_size = hidden_size
        self.N = None

        if max_num_nodes is not None:
            self.N = max_num_nodes

            if embedding is None:
                self.embedding = nn.Embedding(self.N, hidden_size)
            else:
                self.embedding = embedding

        self.enc_tree_update = GRUUpdate(hidden_size)
        self.enc_tree_gather_update = EncoderGatherUpdate(hidden_size)

    def forward(self, trees: List[DGLGraph], extending_nodes=None):

        for i, tree in enumerate(trees):
            trees[i] = tree.to(device)
            trees[i].ndata['wid'] = torch.tensor(range(tree.number_of_nodes())).view(-1, 1).to(device)

        tree_batch = batch(trees)

        # Build line graph to prepare for belief propagation
        tree_batch_lg = line_graph(tree_batch, backtracking=False, shared=True)

        # breakpoint()

        return self.run(tree_batch, tree_batch_lg, extending_nodes)

    def run(self, tree_batch, tree_batch_lg, extending_nodes):
        # Since tree roots are designated to 0.  In the batched graph we can
        # simply find the corresponding node ID by looking at node_offset
        node_offset = graphs_batch_offsets(tree_batch)
        root_ids = node_offset[:-1]
        n_nodes = tree_batch.number_of_nodes()
        n_edges = tree_batch.number_of_edges()
        if extending_nodes is not None:
            extending_nodes = np.add(root_ids, extending_nodes)

        # print('before assigning features to trees')
        # breakpoint()

        # Assign representations to tree nodes
        if self.N is not None:
            xdata = self.embedding(tree_batch.ndata['wid'].view(-1))
        else:
            if 'd' in tree_batch.ndata.keys():
                d_dim = tree_batch.ndata['d'].shape[1]
                xdata = torch.empty(n_nodes, self.hidden_size - d_dim).normal_(mean=0.0, std=1.0).to(device)
                xdata = torch.cat([xdata, tree_batch.ndata['d']], dim=1)
            else:
                xdata = torch.empty(n_nodes, self.hidden_size).normal_(mean=0.0, std=1.0).to(device)

        tree_batch.ndata.update({
            'x': xdata,
            'm': torch.zeros(n_nodes, self.hidden_size).to(device),
            'h': torch.zeros(n_nodes, self.hidden_size).to(device),
        })


        # Initialize the intermediate variables according to Eq (4)-(8).
        # Also initialize the src_x and dst_x fields.
        tree_batch.edata.update({
            's': torch.zeros(n_edges, self.hidden_size).to(device),
            'm': torch.zeros(n_edges, self.hidden_size).to(device),
            'r': torch.zeros(n_edges, self.hidden_size).to(device),
            'z': torch.zeros(n_edges, self.hidden_size).to(device),
            'src_x': torch.zeros(n_edges, self.hidden_size).to(device),
            'dst_x': torch.zeros(n_edges, self.hidden_size).to(device),
            'rm': torch.zeros(n_edges, self.hidden_size).to(device),
            'accum_rm': torch.zeros(n_edges, self.hidden_size).to(device),
        })

        # Send the source/destination node features to edges
        tree_batch.apply_edges(
            func=lambda edges: {'src_x': edges.src['x'], 'dst_x': edges.dst['x']},
        )

        # Message passing
        # I exploited the fact that the reduce function is a sum of incoming
        # messages, and the uncomputed messages are zero vectors.  Essentially,
        # we can always compute s_ij as the sum of incoming m_ij, no matter
        # if m_ij is actually computed or not.
        tree_batch_lg.ndata.update(tree_batch.edata)
        for eid in level_order(tree_batch, root_ids):
            eid = eid.to(device)
            tree_batch_lg.pull(eid, DGLF.copy_u('m', 'm'), DGLF.sum('m', 's'))
            tree_batch_lg.pull(eid, DGLF.copy_u('rm', 'rm'), DGLF.sum('rm', 'rm'))
            tree_batch_lg.apply_nodes(self.enc_tree_update)

        # Readout
        tree_batch.edata.update(tree_batch_lg.ndata)
        tree_batch.update_all(DGLF.copy_e('m', 'm'), DGLF.sum('m', 'm'))
        tree_batch.apply_nodes(self.enc_tree_gather_update)

        root_vecs = tree_batch.nodes[root_ids].data['h']

        output_vecs = root_vecs
        if extending_nodes is not None:
            extending_vecs = tree_batch.nodes[extending_nodes].data['h']
            output_vecs = torch.cat([root_vecs, extending_vecs], 1)

        # breakpoint()
        if torch.isnan(output_vecs).any():
            print('end of decomposition tree')
            breakpoint()

        return output_vecs, tree_batch
