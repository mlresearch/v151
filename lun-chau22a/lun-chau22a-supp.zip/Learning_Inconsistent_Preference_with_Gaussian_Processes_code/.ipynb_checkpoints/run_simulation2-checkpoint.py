# Load stuff
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pylab as plt
from sklearn.cluster import KMeans
from sklearn.metrics import accuracy_score
from PreferentialGP.SkewSymGP import skewsymGaussianProcess, skewsymGaussianProcess_Cuda
from src.spektrankers import *
from src.Experiments import FLIP, include_sparsity
from simulation2 import experiment1
from PreferentialGP.utility import preprocessingC
import torch


# Set up simulation parameter
n = 25 # number of items
p = 5
n_clusters = 2
sparsity = 0.7
flip_noise = 0.2

C, X, beta_dict, z = experiment1(n, p, n_clusters=2)

C_ = include_sparsity(C, sparsity=sparsity)
C_ = FLIP(C_, flip_noise)

###################
# Run SVDCov Rank #
###################
svdc = SVDRankerCov(C_, X, verbose=False)
svdc.fit()
r_vec = svdc.r

compute_upsets(r_vec, C_)

#########################
# Run SkewSymmetric GP  #
#########################
train_choix_ls, train_y_ls = preprocessingC(C_)
skewGP = skewsymGaussianProcess_Cuda(train_choix_ls, train_y_ls, X)
skewGP.fit(epoch=20000, lr=1e-4)

# Sigmoid function
sig = torch.nn.Sigmoid()
n_obv = len(train_y_ls)//2
train_accuracy_GP = (sig(skewGP.posterior_mean)[:n_obv] > 0.5).sum()/(n_obv)

# Look at the full picture now
chx_ls = []
for i in range(n):
    for j in range(i+1, n):
        chx_ls.append((i, j))

skewGP.pred(chx_ls)

# Set up G_pref,G_prob matrices
G_prob = np.zeros_like(C)
G_pref = zp.zeros_like(C)
prob_score = sig(skewGP.test_posterior_mean)
pref_score = skewGP.test_posterior_mean

for pair in range(len(chx_ls)):
    i, j = chx_ls[pair]
    G_prob[i, j] = prob_score[pair]
    G_prob[j, i] = 1 - prob_score[pair]
    G_pref[i, j] = pref_score[pair]
    G_pref[j, i] = - pref_score[pair]

# Run Clustering to reveal the latent states based on the preferences.
u, s, vh = np.linalg.svd(G_pref) # SVD Decomposition

km = KMeans(n_clusters = n_clusters)
km.fit(u[:, :n_clusters*2])

pred_labels = km.labels_
cluster_accuracy = np.max([accuracy_score(z, pred_labels), accuracy_score(z, ((pred_labels)*-1)+1)])

