
This folder contains three python scripts, each corresponding to an experiment as described on the main submission file:
  - 'test_cec_all_scenarios.py'
  - 'test_cec_doublingtrick_forgetting.py'
  - 'test_cec_vs_cecce.py'

To run these scripts simply use the command:
  $> python3 scriptname.py
