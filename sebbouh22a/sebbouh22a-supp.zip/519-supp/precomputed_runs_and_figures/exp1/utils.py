import os
import numpy as np
import matplotlib.pyplot as plt

"""
def condition(dic, filterby):
    all_good = True
    for key, values in filterby.items():
        if dic[key] not in values:
            all_good = False
            break
    return all_good
"""

def condition(dic, filterby):
    all_good = True
    for key, values in filterby.items():
        if key not in dic.keys():
            continue
        elif dic[key] not in values:
            all_good = False
            break
    return all_good

def filter_dicts_and_scores(dicts, scores, filterby):
    return [(dic, score) for dic, score in zip(dicts, scores) if condition(dic, filterby)]


def create_result_list(dicts, scores, filterby, metrics):
    dicts_and_scores = filter_dicts_and_scores(dicts, scores, filterby)
    result = []
    for dic, score in dicts_and_scores:
        score_dict = {}
        for metric in metrics:
            score_dict[metric] = []
            for i in range(len(score)):
                score_dict[metric].append(score[i][metric])
        result.append((dic, score_dict))
    
    return result

def filter_div(scores, dicts, div_criteria):
    keep = [True] * len(scores)
    for i, score in enumerate(scores):
        for key, (comparison_type, threshold) in div_criteria.items():
            if comparison_type == -1:
                if score[-1][key] < threshold:
                    keep[i] = False
                    break
            else:
                if score[-1][key] > threshold:
                    keep[i] = False
                    break
            
    scores = [scores[i] for i in range(len(scores)) if keep[i]]
    dicts = [dicts[i] for i in range(len(dicts)) if keep[i]]
    
    
    return scores, dicts, keep

def plot(ax, xs, ys, plot_type='semilog', ylim=(None, None), skip_steps=None):
    if plot_type == 'semilog':
        ax.semilogy(xs, ys)
    elif plot_type == 'skip':
        ys = np.array([a for i, a in enumerate(ys) if i % skip_steps == 0])
        xs = np.array([a for i, a in enumerate(xs) if i % skip_steps == 0])
        ax.semilogy(xs, ys)
    else:
        ax.plot(xs, ys)
    
    ax.set_ylim(ylim)
    
def combine_metrics(results, metrics_to_combine, metric_function, new_metric_name):
    for result in results:
        args = (result[1][metric] for metric in metrics_to_combine)
        result[1][new_metric_name] = metric_function(*args)

def plot_results_metrics(results, metrics_x, metrics_y, ylims, display_params, plot_types, skip):
    legend = []
    for hyper_values, _ in results:
        params = ""
        for i, display_key in enumerate(display_params):
            if display_key not in hyper_values.keys():
                continue
            params += display_key + "=" + str(hyper_values[display_key])
            if i < len(display_params) - 1:
                params += ', '
        legend.append(params)
    
    fig, subplots = plt.subplots(len(metrics_x), len(metrics_y))
    fig.set_size_inches(20, 10.5)
    
    ax_list = subplots.tolist()
    for ax, metric_x in zip(ax_list, metrics_x):
        for i, metric_y in enumerate(metrics_y):
            ylim = ylims[i]
            plot_type = plot_types[i]
            for hyper_values, values in results:
                plot(ax[i], values[metric_x], values[metric_y],
                    plot_type=plot_type, ylim=ylim, skip_steps=skip[i])
            ax[i].set_xlabel(metric_x)
            ax[i].set_ylabel(metric_y)
            
    fig.subplots_adjust(top=0.9, left=0.1, right=0.9, bottom=0.15)  # create some space below the plots by increasing the bottom-value
    ax[i].legend(legend, loc='upper center', bbox_to_anchor=(0.5, -0.12))
    fig.show()


def get_results_stats(results, metric, specific_parameters, all_chosen_hyper,
             specific_results, order_hyperparams, skip_steps):

    all_hyper_without_runs = []
    for i, (result, _) in enumerate(results):
        if (result['lr_d'], result['lr_a'], result['loop_size'], result['p']) in specific_parameters:
            all_hyper_without_runs.append({key: val for key, val in all_chosen_hyper[i].items() if key != "runs"})


    # the same as the previous list but without duplicates: this will basically be the 
    # legend of the plot
    unique_hyperparameters_without_runs = []
    for hyperparameter_setting in all_hyper_without_runs:
        if hyperparameter_setting not in unique_hyperparameters_without_runs:
            unique_hyperparameters_without_runs.append(hyperparameter_setting)
    
    results_without_runs = [({key: val for key, val in hyper.items() if key != "runs"}, scores)
                        for (hyper, scores) in specific_results]

    # we compute the number of runs per hyperparameter setting and add that info
    unique_hyper_and_number_runs = [[hyper, 0] for hyper in unique_hyperparameters_without_runs]
    for i, (hyper, _) in enumerate(unique_hyper_and_number_runs):
        for hyper_results in all_hyper_without_runs:
            if hyper == hyper_results:
                unique_hyper_and_number_runs[i][1] += 1



    # now we stack the results which have these same hyperparameters
    n_epochs = results[0][0]['max_epoch']
    stacked_results = []
    for hyperparam_setting, number_runs in unique_hyper_and_number_runs:
        score_stack = np.zeros((number_runs, n_epochs))
        i = 0
        for j, (hyperparam_setting_in_results, scores) in enumerate(results_without_runs):
            if hyperparam_setting == all_hyper_without_runs[j]:
                score_stack[i] = scores[metric]
                i += 1
        statistics = [np.mean(score_stack, axis=0), np.std(score_stack, axis=0), 
                      np.max(score_stack, axis=0), np.min(score_stack, axis=0)]
        stacked_results.append((hyperparam_setting, statistics))


    for hyperparams, statistics in stacked_results:
        for i, stat in enumerate(statistics):
            statistics[i] = np.array([a for i, a in enumerate(stat) if i % skip_steps == 0])
    
    stacked_results_ordered = []
    for hyper in order_hyperparams:
        for stacked_result in stacked_results:
            if (stacked_result[0]['p'], stacked_result[0]['loop_size'], stacked_result[0]['lr_d']) == hyper:

                stacked_results_ordered.append(stacked_result) 
    
    return stacked_results_ordered
                                 
                                 