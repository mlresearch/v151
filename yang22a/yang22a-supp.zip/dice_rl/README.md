## Install

Navigate to the root of project, and perform:

    pip3 install -e .

To run taxi, download the pretrained policies and place them under policies/taxi:

    git clone https://github.com/zt95/infinite-horizon-off-policy-estimation.git
    cp -r infinite-horizon-off-policy-estimation/taxi/taxi-policy policies/taxi

## Run BayesDICE Algorithm
First, create datasets using the policy trained above:

    for alpha in {0.0,1.0}; do python3 scripts/create_dataset.py --save_dir=./tests/testdata --load_dir=./tests/testdata --env_name=reacher --num_trajectory=400 --max_trajectory_length=250 --alpha=$alpha --tabular_obs=0; done

Run BayesDICE estimator:

    python3 scripts/run_neural_bayes_dice.py --save_dir=./tests/testdata --load_dir=./tests/testdata --env_name=reacher --num_trajectory=400 --max_trajectory_length=250 --alpha=0.0 --tabular_obs=0