import os
import sys
import ipdb

if 'LD_LIBRARY_PATH' not in os.environ:
    print('library path doesnt exits tf may work only in cpu mode.')

from gan_cifar10 import *
import argparse
import copy


def collect_params(_):
    function_names = [func for func in globals() if not func.startswith('__')]
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', type=str, choices=function_names, default='run_simple_grid')
    parser.add_argument('--eid', type=str, default='default_grid_-3.5_to_-5.0')
    parser.add_argument('--grid_up', type=float, default=-3.5)
    parser.add_argument('--grid_low', type=float, default=-5.0)
    parser.add_argument('--grid_size', type=int, default=10)
    parser.add_argument('--args_B_LR', type=str, default='')
    parser.add_argument('--args_LR_multiplier', type=str, default='')
    parser.add_argument('--item', type=int, default=-1)
    parser.add_argument('--out_dir', type=str, default=os.getcwd() + '/out_dir/')
    parser.add_argument('--skip_if_exists', action='store_true', default=False)

    args = parser.parse_args()
    return args


def defaults(_):
    print('running defaults....')
    # Default Params.....
    optimizerD_fn = optim.Adam
    optimizerD_params = {'lr': 1e-4, 'betas': (0.5, 0.9)}

    # ---
    optimizerG_fn = optim.Adam
    optimizerG_params = {'lr': 1e-4, 'betas': (0.5, 0.9)}

    run_gan_cifar_10(optimizer_D_fn=optimizerD_fn, optimizer_D_params=optimizerD_params, optimizer_G_fn=optimizerG_fn,
                     optimizer_G_params=optimizerG_params, outdir='./tmp/defaults_adam/')


def run_complex_momentum(_):
    print('running complex momentum....')
    optimizerG_fn = optim.SGD
    optimizerG_params = {'lr': 1e-4, 'momentum': 0.5}

    optimizerD_fn = ComplexSGD
    # a≈0.46194 ∧ b≈0.191342 -- with this abs(momentum)=0.5 and phase=pi/8
    optimizerD_params = {'lr': 1e-4 + 0.0j, 'momentum': 0.46 + 0.19j}

    run_gan_cifar_10(optimizer_D_fn=optimizerD_fn, optimizer_D_params=optimizerD_params, optimizer_G_fn=optimizerG_fn,
                     optimizer_G_params=optimizerG_params, outdir='./tmp/opt_sgd_complexmomentum_abs_0.5_phase_pi8/')


def run_complex_adam(_):
    print('running complex adam....')
    optimizerG_fn = optim.Adam
    optimizerG_params = {'lr': 1e-4, 'betas': (0.5, 0.99)}

    optimizerD_fn = ComplexAdam
    optimizerD_params = {'lr': 1e-4, 'betas': (0.46 + 0.19j, 0.46 + 0.19j)}

    run_gan_cifar_10(optimizer_D_fn=optimizerD_fn, optimizer_D_params=optimizerD_params, optimizer_G_fn=optimizerG_fn,
                     optimizer_G_params=optimizerG_params, outdir='./tmp/complex_adam_abs_0.5_phase_pi8/')


def run_momentum(_):
    print('running momentum....')
    optimizerG_fn = optim.SGD
    optimizerG_params = {'lr': 1e-4, 'momentum': 0.5}

    optimizerD_fn = optim.SGD
    optimizerD_params = {'lr': 1e-4, 'momentum': 0.5}

    run_gan_cifar_10(optimizer_D_fn=optimizerD_fn, optimizer_D_params=optimizerD_params, optimizer_G_fn=optimizerG_fn,
                     optimizer_G_params=optimizerG_params, outdir='./tmp/opt_momentum_0.5/')


def run_simple_grid(args):
    optimizerG_fn = optim.SGD
    optimizerG_params = {'lr': 1e-4, 'momentum': 0.5}

    optimizerD_fn = ComplexSGD
    optimizerD_params = {'lr': 1e-4, 'momentum': 0.5}

    grid_low = args.grid_low
    grid_up = args.grid_up
    grid_size = args.grid_size
    args_B_LR_list = [np.pi / 16, 0.0]  # [np.pi / 8., 0.0]
    out_dir_root = args.out_dir
    argss = []
    for args_B_LR in args_B_LR_list:  # [np.pi / 8., 0.0]:
        for i, mag_lr in enumerate(np.exp(np.linspace(grid_low, grid_up, num=grid_size))):  # grid_size):
            for mag_B in np.linspace(0, 1.0, num=grid_size):  # grid_size):
                optimizerD_params_i = copy.deepcopy(optimizerD_params)

                lr = cmath.rect(mag_lr, args_B_LR)
                complex_momentum = cmath.rect(mag_B, args_B_LR)
                optimizerD_params_i['lr'] = np.round(lr, decimals=6)
                optimizerD_params_i['momentum'] = np.round(complex_momentum, decimals=6)

                if np.isreal(complex_momentum) is True and np.real(complex_momentum) == 0:
                    # if there is no momentum , sgd is faster.
                    optimizerD_fn = optim.SGD
                    # optimizerD_params_i['lr'] = np.real(optimizerD_params_i['lr'])
                elif np.iscomplex(lr) == False and np.iscomplex(complex_momentum) == False:
                    # If it is all real let's use pytorch native SGD that is faster
                    optimizerD_fn = optim.SGD
                else:
                    optimizerD_fn = ComplexSGD

                main_args = {'optimizer_D_fn': optimizerD_fn,
                             'optimizer_D_params': optimizerD_params_i,
                             'optimizer_G_fn': optimizerG_fn,
                             'optimizer_G_params': optimizerG_params,
                             'outdir': f'{out_dir_root}/{args.eid}/lr_d_{lr:.5f}_cm_d_{complex_momentum:.5f}/'}

                argss.append(copy.deepcopy(main_args))

    # if args.item == -8:
    #     import shutil
    #     aaaa = [120, 110, 100, 34, 25, 21, 16, 15, 14]
    #     for ii in aaaa:
    #         aaa = argss[ii]['outdir']  #+ 'log.pkl'
    #
    #         print('removing' + aaa)
    #         shutil.rmtree(aaa)
    #         # os.remove(aaa)
    #         # shutil.
    #     return

    ##not the most optimal but probably the easiest for slurm...
    if args.item >= 0:
        args_item = argss[args.item]
        print(f'Item: {args.item}/{len(argss)} :  {args_item}')
        if args.skip_if_exists is True:
            if os.path.isfile(f"{args_item['outdir']}/log.pkl") is True:
                print('log.pkl exists skipping.....')
                return

        print(f'Running Item: {args.item}/{len(argss)} :  {args_item}')
        run_gan_cifar_10(**args_item)

    else:
        print(argss)
        print(f'N jobs: {len(argss)}')
        print('Nothing to run... use --item=id')


if __name__ == "__main__":
    args = collect_params(None)
    globals()[args.mode](args)
    # run_simple_grid(args)
