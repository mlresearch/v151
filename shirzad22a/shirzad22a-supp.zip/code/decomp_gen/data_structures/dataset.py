from __future__ import print_function, division

import copy
import os
import pickle

import dgl
import numpy as np
import networkx as nx
from tqdm import tqdm
import itertools
import random

import torch
from torch.utils.data import Dataset
import torch.nn.functional as F
from decomp_gen.data_structures.graph import Graph, DecompositionTree
from decomp_gen import configs
import random
import matplotlib.pyplot as plt
import scipy.sparse as sp

MARGIN_FACTOR = 1.0
MARGIN_BIAS = 4

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

ALL_TARGETS = False

random.seed(1234)

def all_correct_answers(G, nodes, correct):
    A = nx.to_numpy_array(G)
    nodes = np.array(nodes)
    correct = np.array(correct)

    all_corrects = list()
    all_corrects.append(correct)
    indices = list(range(len(nodes)))

    for pi in list(itertools.permutations(indices)):
        pi = list(pi)
        new_correct = correct.copy()
        new_correct[indices] = new_correct[pi]
        if (new_correct == correct).all():
            continue

        nodes_pi = nodes.copy()
        nodes_pi[indices] = nodes_pi[pi]

        A_pi = A.copy()
        A_pi[nodes] = A_pi[nodes_pi]
        A_pi[:, nodes] = A_pi[:, nodes_pi]

        if (A_pi == A).all():
            all_corrects.append(new_correct)

    return all_corrects


class GraphDataset(Dataset):

    def __init__(self, data_name, saving_name=None, reorder_epochs=1):

        self.data_name = data_name
        self.saving_name = saving_name

        self.epoch_cnt = 0
        self.reorder_epochs = reorder_epochs

        self.sample_per_graph = 64

        self.mode = 'train'

        if self.saving_name is None:
            self.saving_name = "{}.dat".format(data_name)

        self.datasets_dir = os.path.join(configs.root_dir, 'data', 'Datasets')
        self.data_dir = os.path.join(self.datasets_dir, 'Graphs')
        os.makedirs(self.data_dir, exist_ok=True)
        self.data_dir = os.path.join(self.data_dir, self.saving_name)

        try:
            with open(self.data_dir, "rb") as f:
                tmp = pickle.load(f)
                self.graphs = tmp[0]
                self.max_tree_diam = tmp[1]
        except:
            print("Dataset not found in saved graphs, generating dataset:")

            if self.data_name == 'DD' or self.data_name == 'DB':
                self.graphs, self.max_tree_diam = self.preprocess_from_adjacency_list()
            else:
                self.graphs, self.max_tree_diam = self.create_graphs(self.data_name)

            with open(self.data_dir, "wb") as f:
                pickle.dump([self.graphs, self.max_tree_diam], f)

        self.N = int(self.max_graph_size() * MARGIN_FACTOR + MARGIN_BIAS)
        self.C = int(self.max_treewidth() * MARGIN_FACTOR + MARGIN_BIAS)

    def preprocess_from_adjacency_list(self):
        if self.data_name == "DD":
            path_graph_indicator = os.path.join(self.datasets_dir, 'GRAN_Datasets', 'DD',
                                                'DD_graph_indicator.txt')
            path_A = os.path.join(self.datasets_dir, 'GRAN_Datasets', 'DD', 'DD_A.txt')
            min_nodes = 100
            max_nodes = 500
        else:
            path_graph_indicator = os.path.join(self.datasets_dir, 'GRAN_Datasets', 'FIRSTMM_DB',
                                                'FIRSTMM_DB_graph_indicator.txt')
            path_A = os.path.join(self.datasets_dir, 'GRAN_Datasets', 'FIRSTMM_DB',
                                  'FIRSTMM_DB_A.txt')
            min_nodes = 0
            max_nodes = 6000

        print("Making graphs from: ", path_A)

        gindex = [0]
        gnodes = {}
        maxgraphid = 0
        with open(path_graph_indicator) as f:
            for i, l in enumerate(f):
                g = int(l)
                if (g > maxgraphid):
                    maxgraphid = g
                gindex.append(g)
                if g in gnodes:
                    gnodes[g].append(i + 1)
                else:
                    gnodes[g] = [i + 1]

        adj = {}
        with open(path_A) as f:
            for i, l in enumerate(f):
                tmp = l.split(',')
                u = int(tmp[0])
                v = int(tmp[1])

                if v in adj:
                    adj[v].add(u)
                else:
                    adj[v] = {u}

        def adj_matrix(nodes):
            n = len(nodes)
            if n > max_nodes or n < min_nodes:
                return np.zeros((1, 1))
            newidx = {}
            for i, v in enumerate(nodes):
                newidx[v] = i

            adjmat = np.zeros((n, n))
            for v in nodes:
                for u in adj[v]:
                    i = newidx[u]
                    j = newidx[v]
                    adjmat[i, j] = 1
                    adjmat[j, i] = 1

            return adjmat

        adjmats = {}
        for index in range(maxgraphid):
            adjmats[index] = adj_matrix(gnodes[index + 1])

        graphs = []
        print("Making Graph classes from adjacency matrices:")
        MaxLen = 0
        for index in tqdm(range(maxgraphid)):
            if adjmats[index].shape[0] < 2:
                continue
            G = Graph(adjmats[index])
            graphs.append(G)
            MaxLen = max(G.getDTdiameter(), MaxLen)

        MaxLen = int((MaxLen + 1) / 2)
        return graphs, MaxLen

    @staticmethod
    def n_community(c_sizes, seed, p=0.3, p_inter=0.05):
        graphs = [nx.gnp_random_graph(c_sizes[i], p, seed=seed + i) for i in range(len(c_sizes))]
        G = nx.disjoint_union_all(graphs)
        communities = [G.subgraph(cc) for cc in nx.connected_components(G)]

        #from graph generation using score matching paper:
        p_inter = p_inter*2/(len(c_sizes)*c_sizes[0])

        for i in range(len(communities)):
            subG1 = communities[i]
            nodes1 = list(subG1.nodes())
            for j in range(i + 1, len(communities)):
                subG2 = communities[j]
                nodes2 = list(subG2.nodes())
                has_inter_edge = False
                for n1 in nodes1:
                    for n2 in nodes2:
                        if np.random.rand() < p_inter:
                            G.add_edge(n1, n2)
                            has_inter_edge = True
                if not has_inter_edge:
                    G.add_edge(nodes1[0], nodes2[0])
        return G

    @staticmethod
    def caveman_special(c=2, k=20, p_path=0.1, p_edge=0.3):
        p = p_path
        path_count = max(int(np.ceil(p * k)), 1)
        G = nx.caveman_graph(c, k)
        # remove 50% edges
        p = 1-p_edge
        for (u, v) in list(G.edges()):
            if np.random.rand() < p and ((u < k and v < k) or (u >= k and v >= k)):
                G.remove_edge(u, v)
        # add path_count links
        for i in range(path_count):
            u = np.random.randint(0, k)
            v = np.random.randint(k, k * 2)
            G.add_edge(u, v)
        G_nodes = max(nx.connected_components(G), key=len)
        G = copy.deepcopy(G.subgraph(G_nodes))
        return G

    @staticmethod
    def parse_index_file(filename):
        index = []
        for line in open(filename):
            index.append(int(line.strip()))
        return index

    @staticmethod
    def Graph_load(dataset='cora'):
        '''
        Load a single graph dataset
        :param dataset: dataset name
        :return:
        '''
        names = ['x', 'tx', 'allx', 'graph']
        objects = []
        adr = configs.root_dir
        adr = os.path.join(adr, 'data', 'Datasets', 'GraphRNN_Datasets', 'dataset')
        for i in range(len(names)):
            adr_name = os.path.join(adr, "ind.{}.{}".format(dataset, names[i]))
            load = pickle.load(open(adr_name, 'rb'), encoding='latin1')
            # print('loaded')
            objects.append(load)
            # print(load)
        x, tx, allx, graph = tuple(objects)
        adr_name = os.path.join(adr, "ind.{}.test.index".format(dataset))
        test_idx_reorder = GraphDataset.parse_index_file(adr_name)
        test_idx_range = np.sort(test_idx_reorder)

        if dataset == 'citeseer':
            # Fix citeseer dataset (there are some isolated nodes in the graph)
            # Find isolated nodes, add them as zero-vecs into the right position
            test_idx_range_full = range(min(test_idx_reorder), max(test_idx_reorder) + 1)
            tx_extended = sp.lil_matrix((len(test_idx_range_full), x.shape[1]))
            tx_extended[test_idx_range - min(test_idx_range), :] = tx
            tx = tx_extended

        features = sp.vstack((allx, tx)).tolil()
        features[test_idx_reorder, :] = features[test_idx_range, :]
        G = nx.from_dict_of_lists(graph)
        adj = nx.adjacency_matrix(G)
        return adj, features, G

    @staticmethod
    # load ENZYMES and PROTEIN and DD dataset
    def Graph_load_batch(min_num_nodes=20, max_num_nodes=1000, name='ENZYMES', node_attributes=False, graph_labels=False):
        '''
        load many graphs, e.g. enzymes
        :return: a list of graphs
        '''
        print('Loading graph dataset: ' + str(name))
        G = nx.Graph()
        # load data
        path = 'data/Datasets/GraphRNN_Datasets/dataset/' + name + '/'
        data_adj = np.loadtxt(path + name + '_A.txt', delimiter=',').astype(int)
        if node_attributes:
            data_node_att = np.loadtxt(path + name + '_node_attributes.txt', delimiter=',')
        data_node_label = np.loadtxt(path + name + '_node_labels.txt', delimiter=',').astype(int)
        data_graph_indicator = np.loadtxt(path + name + '_graph_indicator.txt', delimiter=',').astype(int)
        if graph_labels:
            data_graph_labels = np.loadtxt(path + name + '_graph_labels.txt', delimiter=',').astype(int)

        data_tuple = list(map(tuple, data_adj))
        # print(len(data_tuple))
        # print(data_tuple[0])

        # add edges
        G.add_edges_from(data_tuple)
        # add node attributes
        for i in range(data_node_label.shape[0]):
            if node_attributes:
                G.add_node(i + 1, feature=data_node_att[i])
            G.add_node(i + 1, label=data_node_label[i])
        G.remove_nodes_from(list(nx.isolates(G)))

        # print(G.number_of_nodes())
        # print(G.number_of_edges())

        # split into graphs
        graph_num = data_graph_indicator.max()
        node_list = np.arange(data_graph_indicator.shape[0]) + 1
        graphs = []
        max_nodes = 0
        for i in range(graph_num):
            # find the nodes for each graph
            nodes = node_list[data_graph_indicator == i + 1]
            G_sub = G.subgraph(nodes)
            if graph_labels:
                G_sub.graph['label'] = data_graph_labels[i]
            # print('nodes', G_sub.number_of_nodes())
            # print('edges', G_sub.number_of_edges())
            # print('label', G_sub.graph)
            if G_sub.number_of_nodes() >= min_num_nodes and G_sub.number_of_nodes() <= max_num_nodes:
                graphs.append(G_sub)
                if G_sub.number_of_nodes() > max_nodes:
                    max_nodes = G_sub.number_of_nodes()
                # print(G_sub.number_of_nodes(), 'i', i)
        # print('Graph dataset name: {}, total graph num: {}'.format(name, len(graphs)))
        # logging.warning('Graphs loaded, total num: {}'.format(len(graphs)))
        print('Loaded')
        return graphs

    def create_graphs(self, data_name, seed=123):
        print('creating synthetic {} data'.format(data_name))
        np.random.RandomState(seed)

        graphs = []

        MaxLen = 0

        if data_name == 'grid':
            graphs = []
            for i in tqdm(range(10, 20)):
                for j in range(10, 20):
                    graph = Graph(AdjMatrix=None, nxGraph=nx.grid_2d_graph(i, j))
                    graphs.append(copy.deepcopy(graph))
                    d = int((graph.getDTdiameter() + 1) / 2)
                    MaxLen = max(MaxLen, d)

        elif data_name == 'lobster':
            graphs = []
            p1 = 0.7
            p2 = 0.7
            count = 0
            min_node = 10
            max_node = 100
            max_edge = 0
            mean_node = 80
            num_graphs = 100

            MaxLen = 0
            seed_tmp = seed
            while count < num_graphs:
                G = nx.random_lobster(mean_node, p1, p2, seed=seed_tmp)
                if min_node <= len(G.nodes()) <= max_node:
                    T = DecompositionTree(G, 2)
                    graphs.append(copy.deepcopy(T))
                    if G.number_of_edges() > max_edge:
                        max_edge = G.number_of_edges()
                    d = int((T.getDiameter() + 1) / 2)
                    MaxLen = max(MaxLen, d)
                    count += 1

                seed_tmp += 1

            random.shuffle(graphs)

        elif data_name == 'lobster_graph':
            graphs = []
            p1 = 0.7
            p2 = 0.7
            count = 0
            min_node = 10
            max_node = 100
            max_edge = 0
            mean_node = 80
            num_graphs = 100

            MaxLen = 0
            seed_tmp = seed
            while count < num_graphs:
                G = nx.random_lobster(mean_node, p1, p2, seed=seed_tmp)
                if min_node <= len(G.nodes()) <= max_node:
                    graph = Graph(AdjMatrix=None, nxGraph=G)
                    graphs.append(copy.deepcopy(graph))
                    if G.number_of_edges() > max_edge:
                        max_edge = G.number_of_edges()
                    d = int((graph.getDTdiameter() + 1) / 2)
                    MaxLen = max(MaxLen, d)
                    count += 1

                seed_tmp += 1

            random.shuffle(graphs)

        elif data_name == 'community':
            print("creating 500 two community networks, p=0.3, p_inter = 0.05")
            C = np.random.randint(51, size=500)
            C = C + 30
            graphs = []
            MaxLen = 0
            for c in C:
                g = self.n_community([c, c], seed=seed, p=0.7, p_inter=0.05)
                graph = Graph(AdjMatrix=None, nxGraph=g)
                graphs.append(graph)
                d = int((graph.getDTdiameter() + 1) / 2)
                MaxLen = max(MaxLen, d)

        elif data_name == 'community_small':
            print("creating 500 two community networks, p=0.3, p_inter = 0.05")
            C = np.random.randint(5, size=500)
            C = C + 6
            graphs = []
            MaxLen = 0
            for c in C:
                g = self.n_community([c, c], seed=seed, p=0.7, p_inter=0.05)
                graph = Graph(AdjMatrix=None, nxGraph=g)
                graphs.append(graph)
                d = int((graph.getDTdiameter() + 1) / 2)
                MaxLen = max(MaxLen, d)

        elif data_name == 'test_grid':
            print('creating test grid dataset with grid sides sizes from 4 to 8')
            graphs = []
            for i in range(4, 8):
                for j in range(4, 8):
                    graph = Graph(AdjMatrix=None, nxGraph=nx.grid_2d_graph(i, j))
                    graphs.append(copy.deepcopy(graph))
                    d = int((graph.getDTdiameter() + 1) / 2)
                    MaxLen = max(MaxLen, d)

        elif data_name == 'ladder':
            graphs = []
            for i in range(100, 201):
                graph = Graph(AdjMatrix=None, nxGraph=nx.ladder_graph(i))
                graphs.append(copy.deepcopy(graph))
                d = int((graph.getDTdiameter() + 1) / 2)
                MaxLen = max(MaxLen, d)

        elif data_name == 'ladder_small':
            graphs = []
            for i in range(2, 11):
                graph = Graph(AdjMatrix=None, nxGraph=nx.ladder_graph(i))
                graphs.append(copy.deepcopy(graph))
                d = int((graph.getDTdiameter() + 1) / 2)
                MaxLen = max(MaxLen, d)

        elif data_name == 'tree':
            graphs = []
            for i in range(2, 5):
                for j in range(3, 5):
                    graph = Graph(AdjMatrix=None, nxGraph=nx.balanced_tree(i, j))
                    graphs.append(copy.deepcopy(graph))
                    d = int((graph.getDTdiameter() + 1) / 2)
                    MaxLen = max(MaxLen, d)

        elif data_name == 'caveman':
            # graphs = []
            # for i in range(5,10):
            #     for j in range(5,25):
            #         for k in range(5):
            #             graphs.append(nx.relaxed_caveman_graph(i, j, p=0.1))
            graphs = []
            for i in range(2, 3):
                for j in tqdm(range(30, 81)):
                    for k in range(10):
                        graph = Graph(AdjMatrix=None, nxGraph=self.caveman_special(i, j, p_edge=0.3))
                        graphs.append(copy.deepcopy(graph))
                        d = int((graph.getDTdiameter() + 1) / 2)
                        MaxLen = max(MaxLen, d)

        elif data_name == 'caveman_small':
            # graphs = []
            # for i in range(5,10):
            #     for j in range(5,25):
            #         for k in range(5):
            #             graphs.append(nx.relaxed_caveman_graph(i, j, p=0.1))
            graphs = []
            for i in range(2, 3):
                for j in range(6, 11):
                    for k in range(20):
                        graph = Graph(AdjMatrix=None, nxGraph=self.caveman_special(i, j, p_edge=0.8))
                        graphs.append(copy.deepcopy(graph))
                        d = int((graph.getDTdiameter() + 1) / 2)
                        MaxLen = max(MaxLen, d)

        elif data_name == 'barabasi':
            graphs = []
            for i in tqdm(range(100, 200)):
                for j in range(4, 5):
                    for k in range(5):
                        graph = Graph(AdjMatrix=None, nxGraph=nx.barabasi_albert_graph(i, j))
                        graphs.append(copy.deepcopy(graph))
                        d = int((graph.getDTdiameter() + 1) / 2)
                        MaxLen = max(MaxLen, d)

        elif data_name == 'barabasi_small':
            graphs = []
            for i in tqdm(range(4, 21)):
                for j in range(3, 4):
                    for k in range(10):
                        graph = Graph(AdjMatrix=None, nxGraph=nx.barabasi_albert_graph(i, j))
                        graphs.append(copy.deepcopy(graph))
                        d = int((graph.getDTdiameter() + 1) / 2)
                        MaxLen = max(MaxLen, d)

        elif data_name == 'citeseer':
            _, _, G = self.Graph_load(dataset='citeseer')
            G_nodes = max(nx.connected_components(G), key=len)
            G = copy.deepcopy(nx.subgraph(G, G_nodes))
            G = nx.convert_node_labels_to_integers(G)
            graphs = []
            for i in range(G.number_of_nodes()):
                G_ego = nx.ego_graph(G, i, radius=3)
                if G_ego.number_of_nodes() >= 50 and (G_ego.number_of_nodes() <= 100):
                    graph = Graph(AdjMatrix=None, nxGraph=G_ego)
                    graphs.append(copy.deepcopy(graph))
                    d = int((graph.getDTdiameter() + 1) / 2)
                    MaxLen = max(MaxLen, d)

            random.shuffle(graphs)

        elif data_name == 'citeseer_small':
            _, _, G = self.Graph_load(dataset='citeseer')
            G_nodes = max(nx.connected_components(G), key=len)
            G = copy.deepcopy(nx.subgraph(G, G_nodes))
            G = nx.convert_node_labels_to_integers(G)
            graphs = []
            for i in range(G.number_of_nodes()):
                G_ego = nx.ego_graph(G, i, radius=1)
                if (G_ego.number_of_nodes() >= 4) and (G_ego.number_of_nodes() <= 18):
                    graph = Graph(AdjMatrix=None, nxGraph=G_ego)
                    graphs.append(copy.deepcopy(graph))
                    d = int((graph.getDTdiameter() + 1) / 2)
                    MaxLen = max(MaxLen, d)
            graphs = graphs[0:200]
            # random.shuffle(graphs)

        elif data_name == 'random_tree':
            graphs = []
            min_node = 40
            max_node = 50
            num_graphs_per_node_size = 50

            MaxLen = 0
            seed_tmp = seed
            for i in range(min_node, max_node):
                for j in range(num_graphs_per_node_size):
                    G = nx.random_tree(i, seed=seed_tmp)
                    T = DecompositionTree(G, 2)
                    graphs.append(copy.deepcopy(T))
                    d = int((T.getDiameter() + 1) / 2)
                    MaxLen = max(MaxLen, d)
                    seed_tmp += 1

            random.shuffle(graphs)

        elif data_name == 'enzymes':
            nx_graphs = self.Graph_load_batch(min_num_nodes=10, name='ENZYMES')
            graphs = []
            for g in nx_graphs:
                graph = Graph(AdjMatrix=None, nxGraph=g)
                graphs.append(copy.deepcopy(graph))
                d = int((graph.getDTdiameter() + 1) / 2)
                MaxLen = max(MaxLen, d)

            random.shuffle(graphs)

        elif data_name == 'enzymes_small':
            graphs_raw = self.Graph_load_batch(min_num_nodes=10, name='ENZYMES')
            graphs = []
            for G in graphs_raw:
                if G.number_of_nodes() <= 20:
                    graph = Graph(AdjMatrix=None, nxGraph=G)
                    graphs.append(copy.deepcopy(graph))
                    d = int((graph.getDTdiameter() + 1) / 2)
                    MaxLen = max(MaxLen, d)

            random.shuffle(graphs)

        elif data_name == 'protein':
            nx_graphs = self.Graph_load_batch(min_num_nodes=20, max_num_nodes=100, name='PROTEINS_full')
            for g in nx_graphs:
                graph = Graph(AdjMatrix=None, nxGraph=g)
                graphs.append(copy.deepcopy(graph))
                d = int((graph.getDTdiameter() + 1) / 2)
                MaxLen = max(MaxLen, d)

            random.shuffle(graphs)

        else:
            raise ValueError('dataset not found')

        num_nodes = [gg.getGraph().number_of_nodes() for gg in graphs]
        num_edges = [gg.getGraph().number_of_edges() for gg in graphs]
        tree_widthes = [gg.getTW() for gg in graphs]
        print('number of graphs: ', len(graphs))
        print('max # nodes = {} || min # nodes = {} || mean # nodes = {}'.format(max(num_nodes), min(num_nodes), np.mean(num_nodes)))
        print('max # edges = {} || min # edges = {} || mean # edges = {}'.format(max(num_edges), min(num_edges), np.mean(num_edges)))
        print('max # treewidth = {} || mean # treewidth = {}'.format(max(tree_widthes),
                                                                     np.mean(tree_widthes)))

        return graphs, MaxLen

    def __len__(self):
        return len(self.graphs)

    def __getitem__(self, idx):
        return self.graphs[idx]

    def max_treewidth(self):
        max_tw = 0
        for g in self.graphs:
            max_tw = max(max_tw, g.tw)

        return max_tw

    def max_graph_size(self):
        max_size = 0
        for g in self.graphs:
            max_size = max(max_size, g.n)

        return max_size

    def save_stats(self):
        stats = {'tree_size': list(),
                 'width': list(),
                 'cluster_size': list(),
                 'new_nodes_size': list()
                 }
        for g in self.graphs:
            cnt = g.getNumberofClusters()
            stats['tree_size'].append(cnt)
            stats['width'].append(g.tw)
            for cid in range(cnt):
                raw_data = g.getClusterData(cid)
                nodes = raw_data['sn'].getNewAndSharedNodes()
                stats['cluster_size'].append(len(nodes['shared']) + len(nodes['newNodes']))
                stats['new_nodes_size'].append(len(nodes['newNodes']))

        dir = os.path.join(configs.root_dir, 'data', 'stats')
        os.makedirs(dir, exist_ok=True)
        dir = os.path.join(dir, self.data_name + '_stats')

        with open(dir, "wb") as f:
            pickle.dump(stats, f)

        return stats




class NodeSharingDataset(GraphDataset):

    def __getitem__(self, idx):

        G = self.graphs[idx]

        if self.epoch_cnt % self.reorder_epochs == 0:
            G.reOrder()

        cnt = G.getNumberofClusters()

        # In some cases tree has just one node and no node sharing happens
        if cnt == 1:
            return None

        if (cnt - 1) >= self.sample_per_graph:
            cluster_indices = random.sample(range(1, cnt), k=self.sample_per_graph)
        else:
            cluster_indices = range(1, cnt)
            cluster_indices = np.random.permutation(cluster_indices)

        # batch of clusters of this graph
        graph_batch = {
            # size of all below: number of cluster = len(cluster_indices)
            'partial_graphs': list(),  # list of graphs/tensors
            'parent_nodes': list(),
            'shared': list(),  # torch.tensor
            'super_node_idx': list(),  # np.array

            # size = total_number_of_decisions x self.C (max_cluster_size)
            'masked_shared': list(),  # torch.tensor

            # sum(n_i) where n_i = size of cluster i
            'total_number_of_decisions': 0,

            # size = 1
            'tree': dgl.DGLGraph(G.T.getSimpleTree()),

            # for finding all correct targets
            'all_correct_targets': list()
        }

        for cid in cluster_indices:

            # get super node
            raw_data = G.getClusterData(cid)

            parent_nodes = np.array(sorted(raw_data['sn'].parent.nodes))
            parent_num_nodes = parent_nodes.shape[0]

            graph_batch['parent_nodes'].append(parent_nodes)
            graph_batch['super_node_idx'].append(np.array([cid] * parent_num_nodes))
            graph_batch['total_number_of_decisions'] += parent_num_nodes

            # shared = which nodes of parent are shared with this supernode
            #   shared.shape = #parent.number_of_nodes
            shared_raw = raw_data['sn'].getNewAndSharedNodes()['shared']
            shared = torch.zeros(parent_num_nodes)
            for j, x in enumerate(parent_nodes):
                if x in shared_raw:
                    shared[j] = 1.0

            graph_batch['shared'].append(shared.squeeze())

            if ALL_TARGETS:
                all_correct_targets = all_correct_answers(raw_data['Gi'].copy(), copy.copy(parent_nodes), copy.copy(shared.squeeze()))
                graph_batch['all_correct_targets'].append(all_correct_targets)

            # raw_data['Gi'] = partial graph down to this supernode
            dglGi = dgl.DGLGraph(raw_data['Gi'])
            dglGi = dgl.transform.add_self_loop(dglGi)

            adj_matrix = nx.to_numpy_matrix(raw_data['Gi'])
            adj_matrix = np.pad(adj_matrix, [(0, 0), (0, self.N - adj_matrix.shape[1])],
                                mode='constant', constant_values=0.0)
            dglGi.ndata['a'] = torch.tensor(adj_matrix, dtype=torch.float32)

            dglGi.ndata['last_cluster_idx'] = torch.zeros(raw_data['Gi'].number_of_nodes(), self.C)

            for ii, v in enumerate(parent_nodes):
                dglGi.ndata['last_cluster_idx'][v, ii] = 1.0

            graph_batch['partial_graphs'].append(dglGi)

            masked_shared = shared * 2.0 - 1.0
            masked_shared = masked_shared.repeat(parent_num_nodes, 1)
            masked_shared = torch.tril(masked_shared, diagonal=-1)
            masked_shared = F.pad(masked_shared, [0, self.C - masked_shared.shape[1]])
            graph_batch['masked_shared'].append(masked_shared)


        # Sanity checks
        expected_length = len(graph_batch['partial_graphs'])
        for key, val in graph_batch.items():
            if key in ['tree']:
                continue
            # if isinstance(val, list):
            #     assert len(val) == expected_length
            elif isinstance(val, torch.Tensor):
                assert val.shape[0] == expected_length

        graph_batch['super_node_idx'] = np.concatenate(graph_batch['super_node_idx'])
        graph_batch['shared'] = torch.cat(graph_batch['shared'])
        graph_batch['masked_shared'] = torch.cat(graph_batch['masked_shared'], dim=0)

        assert graph_batch['masked_shared'].shape[0] == graph_batch['total_number_of_decisions']
        assert graph_batch['shared'].shape[0] == graph_batch['total_number_of_decisions']

        return graph_batch


class NodeAddingDataset(GraphDataset):

    def __getitem__(self, idx):
        # G = Graph (Tree decomposition, list of clusters, order of nodes)
        G = self.graphs[idx]

        # G = self.graphs[0]
        # nx.draw(G.T.showTree(), with_labels=True)
        # plt.show()
        # print('getting graph with idx: ', idx)
        # breakpoint()

        if self.epoch_cnt % self.reorder_epochs == 0:
        #     # print('reorder, epoch_cnt = {}, mode = {}'.format(self.epoch_cnt, self.mode))
            G.reOrder()

        cnt = G.getNumberofClusters()
        if cnt >= self.sample_per_graph:
            cluster_indices = random.sample(range(cnt), k=self.sample_per_graph)
        else:
            cluster_indices = range(0, cnt)
            cluster_indices = np.random.permutation(cluster_indices)

        # batch of clusters of this graph
        graph_batch = {
            # size of all below: number of cluster = len(cluster_indices)
            'partial_graphs': list(),  # list of dgl graphs

            #data for nodes:
            'node_graph_idx': list(),  # np.array
            'node_super_node_idx': list(),  # np.array
            'node_target': list(),  # torch.tensor

            #data for edges:
            'edges': list(),  # np.array
            'edge_graph_idx': list(),  # np.array
            'edge_super_node_idx': list(),  # np.array
            'masked_edges': list(),  # torch.tensor
            'edge_target': list(),  #torch.tensor

            # size = 1
            'tree': dgl.DGLGraph(G.T.getSimpleTree()),
            'total_number_of_nodes': 0
        }

        graph_nodes_offset = 0

        for cid in cluster_indices:

            # get super node
            raw_data = G.getClusterData(cid)
            nodes = raw_data['sn'].getNewAndSharedNodes()

            shared_nodes = sorted(list(nodes['shared']))
            new_nodes = sorted(list(nodes['newNodes']))

            last_cluster_node_idx = torch.zeros(raw_data['Gi'].number_of_nodes(), self.C)
            for i, v in enumerate(shared_nodes):
                last_cluster_node_idx[v, i] = 1.0

            added_nodes = shared_nodes
            Ci = raw_data['Ci']
            adj_Ci = nx.to_numpy_matrix(Ci)
            adj_Ci = torch.tensor(adj_Ci, dtype=torch.float32)

            for v_idx, v in enumerate(new_nodes):
                Gi = G.partial_graph_before_node(v)
                Gi.add_node(v)

                dglGi = dgl.DGLGraph(Gi)
                dglGi = dgl.transform.add_self_loop(dglGi)

                adj_matrix = nx.to_numpy_matrix(Gi)
                adj_matrix = np.pad(adj_matrix, [(0, 0), (0, self.N - adj_matrix.shape[1])],
                                    mode='constant', constant_values=0.0)
                dglGi.ndata['a'] = torch.tensor(adj_matrix, dtype=torch.float32)

                one_hot_vector = torch.zeros(1, self.C)
                one_hot_vector[0, len(added_nodes)] = 1.0
                last_cluster_node_idx = torch.cat([last_cluster_node_idx, one_hot_vector], dim=0)
                dglGi.ndata['c'] = copy.deepcopy(last_cluster_node_idx)
                graph_batch['partial_graphs'].append(dglGi)

                if v_idx > 0:
                    graph_batch['node_graph_idx'].append(len(graph_batch['partial_graphs'])-1)
                    graph_batch['node_super_node_idx'].append(cid)
                    graph_batch['node_target'].append(1.0)

                for j, u in enumerate(added_nodes):
                    graph_batch['edges'].append((v+graph_nodes_offset, u+graph_nodes_offset))
                    graph_batch['edge_graph_idx'].append(len(graph_batch['partial_graphs'])-1)
                    graph_batch['edge_super_node_idx'].append(cid)
                    graph_batch['edge_target'].append(adj_Ci[len(added_nodes), j].item())

                masked_edges = adj_Ci[len(added_nodes)] * 2.0 - 1.0
                masked_edges = masked_edges.view(1, -1)
                masked_edges = masked_edges.repeat(len(added_nodes), 1)
                masked_edges = torch.tril(masked_edges, diagonal=-1)
                masked_edges = F.pad(masked_edges, [0, self.C-masked_edges.shape[1]])
                graph_batch['masked_edges'].append(masked_edges)

                added_nodes.append(v)
                graph_nodes_offset += dglGi.number_of_nodes()

            #decision to not to add new node:
            v = new_nodes[-1] + 1
            Gi = G.partial_graph_before_node(v)
            Gi.add_node(v)

            dglGi = dgl.DGLGraph(Gi)
            dglGi = dgl.transform.add_self_loop(dglGi)

            adj_matrix = nx.to_numpy_matrix(Gi)
            adj_matrix = np.pad(adj_matrix, [(0, 0), (0, self.N - adj_matrix.shape[1])],
                                mode='constant', constant_values=0.0)
            dglGi.ndata['a'] = torch.tensor(adj_matrix, dtype=torch.float32)

            one_hot_vector = torch.zeros(1, self.C)
            one_hot_vector[0, len(added_nodes)] = 1.0
            last_cluster_node_idx = torch.cat([last_cluster_node_idx, one_hot_vector], dim=0)
            dglGi.ndata['c'] = copy.deepcopy(last_cluster_node_idx)
            graph_batch['partial_graphs'].append(dglGi)
            graph_nodes_offset += dglGi.number_of_nodes()

            graph_batch['node_graph_idx'].append(len(graph_batch['partial_graphs']) - 1)
            graph_batch['node_super_node_idx'].append(cid)
            graph_batch['node_target'].append(0.0)

        graph_batch['masked_edges'] = torch.cat(graph_batch['masked_edges'], dim=0)
        graph_batch['node_target'] = torch.tensor(graph_batch['node_target'])
        graph_batch['edge_target'] = torch.tensor(graph_batch['edge_target'])
        graph_batch['node_super_node_idx'] = np.array(graph_batch['node_super_node_idx'])
        graph_batch['edge_super_node_idx'] = np.array(graph_batch['edge_super_node_idx'])
        graph_batch['node_graph_idx'] = np.array(graph_batch['node_graph_idx'])
        graph_batch['edge_graph_idx'] = np.array(graph_batch['edge_graph_idx'])
        graph_batch['edges'] = np.array(graph_batch['edges'])
        graph_batch['total_number_of_nodes'] = graph_nodes_offset

        return graph_batch


class TreeGeneratorDataset(Dataset):
    def __init__(self, samples):
        self.samples = samples

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        return self.samples[idx]