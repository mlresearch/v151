import numpy as np

def number_2_theta(ipolicy, d, M, delta_discrete):
    vec = np.zeros(d)
    i_bit = 0
    while i_bit < d:
        current_bit = ipolicy % (M+1)
        vec[i_bit] = current_bit
        ipolicy = ipolicy//(M+1)
        i_bit += 1
    vec = vec * delta_discrete
    return vec

def theta_mat(d, M, N, delta_discrete):
    mat = np.zeros((N, d))
    for i_policy in range(N):
        mat[i_policy] = number_2_theta(i_policy, d, M, delta_discrete)
    return mat
