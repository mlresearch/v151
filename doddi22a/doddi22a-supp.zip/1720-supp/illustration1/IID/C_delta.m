%% This code computes the value of C and delta^{-1}(<1) from timeseries

function [C,delta] = C_delta(E_factor,h)
Nnodes = size(h,1);
E = E_factor*randn(Nnodes,1e5);
[temp] = DataGenerator(1e5,h,E, zeros(Nnodes,1));
[acf,lags] = xcorr(temp','unbiased');

center = abs(lags(1));
delta = norm(reshape(acf(center+2,:),[],Nnodes),2)/norm(reshape(acf(center+1,:),[],Nnodes),2);
C = norm(reshape(acf(center+1,:),[],Nnodes),2);
end

