import torch.nn.functional as F
import numpy as np
import torch

def MultRandomCrop(X1, X2, padding=4):
    
    size = X1.shape[-1]
    images1 = F.pad(X1, [padding] * 4)
    images2 = F.pad(X2, [padding] * 4)

    res1 = []
    res2 = []

    for i in range(X1.shape[0]):

        x = np.random.randint(0, padding * 2 + 1)
        y = np.random.randint(0, padding * 2 + 1)

        res1.append(images1[None,i,:,x:x+size,y:y+size])
        res2.append(images2[None,i,:,x:x+size,y:y+size])

    return torch.cat(res1, dim=0), torch.cat(res2, dim=0)

def MultRandomFlip(X1, X2):
    
    res1 = []
    res2 = []
    
    for i in range(X1.shape[0]):
        
        if np.random.randint(low=0, high=2) == 0:
            res1.append(X1[None,i])
            res2.append(X2[None,i])
        else:
            res1.append(torch.flip(X1[i], dims=[-1])[None])
            res2.append(torch.flip(X2[i], dims=[-1])[None])
    
    return torch.cat(res1, dim=0), torch.cat(res2, dim=0)

def MultIdentity(X1, X2):
    return X1, X2

def MultCropFlip(X1, X2, padding=4):
    return MultRandomFlip(*MultRandomCrop(X1, X2, padding))