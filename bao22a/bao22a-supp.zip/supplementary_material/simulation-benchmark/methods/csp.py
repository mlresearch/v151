import random

import numpy as np
import scipy.linalg
from misc import convert_sdu_data_sklearn_compatible
from sklearn.cluster import KMeans, SpectralClustering
from sklearn.metrics import accuracy_score
from sklearn.metrics.pairwise import rbf_kernel


def csp(L, Q, D_norm, vol, N):
    # Normalize the constraint matrix
    Q_norm = np.matmul(np.matmul(D_norm, Q), D_norm)

    # Set the parameter alpha to 0.5*(the largest eigenvalue of Q_norm)
    lam = np.max(np.linalg.eig(Q_norm)[0])
    Q1 = Q_norm - 0.5 * lam * np.eye(N)
    val, vec = scipy.linalg.eig(L, Q1)

    # Find the positive eigenvectors
    I, _ = np.where(np.diag(val) > 0)

    # Compute the respective costs of the cuts
    cost = np.zeros(len(I))
    for i in range(len(I)):
        v = vec[I[i]] / np.linalg.norm(vec[I[i]]) * vol ** 0.5
        cost[i] = np.matmul(np.matmul(v.T, L), v)

    ind = np.argmin(cost)
    # Output the cluster indicator vector
    v = vec[I[ind]] / np.linalg.norm(vec[I[ind]]) * vol ** 0.5
    u = np.matmul(D_norm, v)

    return u


def run_csp(x_s, x_d, x_u, x_test, y_test, seed):
    # Load the toy data set
    random.seed(seed)
    np.random.seed(seed)
    n_test = len(y_test)

    ns = len(x_s)
    nd = len(x_d)
    ml = [(2 * i, 2 * i + 1) for i in range(ns)]
    cl = [(2 * ns + 2 * i, 2 * ns + 2 * i + 1) for i in range(nd)]

    x_train, y_train = convert_sdu_data_sklearn_compatible(x_s, x_d, x_u)
    x_train = np.concatenate((x_train, x_test))

    N = len(x_train)

    x_train -= np.mean(x_train, axis=0)
    x_train /= np.std(x_train, axis=0) + 1e-8

    # A = rbf_kernel(x_train, gamma=0.5) - np.eye(N)
    A = rbf_kernel(x_train) - np.eye(N)

    Q = np.eye(N)
    for i, j in ml:
        Q[i, j] = 1
        Q[j, i] = 1

    for i, j in cl:
        Q[i, j] = -1
        Q[j, i] = -1

    # Compute the graph Laplacian.
    D = np.diag(np.sum(A, axis=0))
    vol = np.sum(np.diag(D))
    D_norm = scipy.linalg.fractional_matrix_power(D, -0.5)
    L = np.eye(N) - np.matmul(np.matmul(D_norm, A), D_norm)

    # Apply our algorithm
    u = csp(L, Q, D_norm, vol, N)

    # Turn the relaxed indicator vector into a 2-way partition
    y_pred = np.where(u >= 0, 1, -1)[-n_test:]

    accuracy = accuracy_score(y_test, y_pred)
    accuracy = max(accuracy, 1 - accuracy)
    print("accuracy", accuracy)

    clf = SpectralClustering(n_clusters=2, affinity="precomputed")
    y_pred = clf.fit_predict(A)[-n_test:] * 2 - 1
    accuracy = accuracy_score(y_test, y_pred)
    accuracy = max(accuracy, 1 - accuracy)
    print("accuracy", accuracy)

    clf = KMeans(n_clusters=2)
    y_pred = clf.fit_predict(x_train)[-n_test:] * 2 - 1
    accuracy = accuracy_score(y_test, y_pred)
    accuracy = max(accuracy, 1 - accuracy)
    print("accuracy", accuracy)

    return accuracy
