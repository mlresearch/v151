import numpy as np
from numpy import linalg as LA
from scipy.optimize import minimize

def compute_CE_PRD(num_res=3, num_agents=5, agent_list=None, num_iter=10):
    
    '''
    
    Function that computes a competative equalibrium using proportional response dynamics.
    
    agent_list: list of agents
    
    budgets are proportional to entitlements
   
    '''

    # start with uniform bids across resources
    
    bids_matrix = []
    
    for agent in agent_list:
        
        bids_one_row = np.full((num_res,), agent.e_i/float(num_res))
        
        agent.record_bids(bids_one_row)
        bids_matrix.append(bids_one_row)
    
    prices, allocations = gen_price_allocations(bids_matrix)
    
    for iteration in range(num_iter):
        
        bids_matrix = []
        
        for i,agent in enumerate(agent_list):
            
            agent_bids = list(agent.generate_bids(allocations[i]))
            
            agent.record_bids(agent_bids)
            bids_matrix.append(agent_bids)
        
        bids_matrix = np.array(bids_matrix)
        
        prices, allocations = gen_price_allocations(bids_matrix)
        
    return prices, allocations

def gen_price_allocations(bids_matrix=None):
    '''
    bids_matrix: (n by m) 2D numpy array
    
    '''
    bids_matrix = np.array(bids_matrix)
    
    prices = np.sum(bids_matrix, axis=0)
    allocations = np.true_divide(bids_matrix, bids_matrix.sum(axis=0,keepdims=1))

    return prices, allocations


def approx_CE_loss(agents_list=None, CE_allocations=None, CE_prices=None, num_agents=3, num_res=2, num_samples=20, approx_std=1):
    
    
    loss_list = [0]*num_agents
       
    for i, agent in enumerate(agents_list):
        
        loss_i = 0
        
        num_sample = 0
        
        num_sample_attempts = 0
        
        x_i = CE_allocations[i]
#         print('learnt CE allocation: ', x_i)
        mean_y = np.full_like(x_i, agent.e_i)
        
        n = mean_y.shape[0]
        mean = np.full((n,), mean_y)
        cov = np.zeros((n, n))
        np.fill_diagonal(cov, approx_std**2)
           
        
        while num_sample < num_samples and num_sample_attempts < 2000:
 
            
            y_sample = np.random.uniform(low=0.0, high=1.0, size=(num_res,))
 
            if np.dot(y_sample, CE_prices) <=  np.dot(np.full_like(y_sample, agent.e_i), CE_prices):
                
                u_i_y = agent.generate_feedback(y_sample, true_util=True, use_theta_sample=False,
                          record_x = False, record_y=False)
                
                u_i_x = agent.generate_feedback(CE_allocations[i], true_util=True, use_theta_sample=False,
                          record_x = False, record_y=False)
                
                
                if u_i_y > u_i_x:

                    
                    loss_i = max(loss_i, max(0, u_i_y-u_i_x))

                    num_sample+= 1
                num_sample_attempts += 1

        loss_list[i] = loss_i
 
    return sum(loss_list)

def sample_simplex(n=3):
    '''
    generate n values that are nonnegative and sum to 1
    
    Return: 1D nparray
    
    '''

    X = [0]
    for i in range(n-1):
        X.append(np.random.uniform(0,1))
    X.append(1)
    X.sort()

    Z = [0] * n
    for i in range(n):
        Z[i] = X[i+1] - X[i]
    return np.array(Z)