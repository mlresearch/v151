from models import SMALL_CNN, PreActResNet8, PreActResNet18
from augmentations import MultIdentity, MultCropFlip
from utils import init_w_grad_buffer, save, pprint
from attacks import fgsm, pgd

import torchvision.transforms as transforms
import torch.nn.functional as F
import numpy as np

import torchvision
import torch
import time

def run(model, dataset, n_epochs, lr, eps, tau, eta, n_steps, p_iter, trial):
    
    # Load data
    if dataset == 'MNIST':
        trainset = torchvision.datasets.MNIST(root='./data', train=True, download=True, transform=[transforms.ToTensor()])
        testset = torchvision.datasets.MNIST(root='./data', train=False, download=True, transform=[transforms.ToTensor()])
        
        train_data = trainset.data.cuda()[:,None] / 255.
        train_labels = trainset.targets.cuda()

        test_data = testset.data.cuda()[:,None] / 255.
        test_labels = testset.targets.cuda()
        
        train_bs = 150
        test_bs = 10000
        n_channels = 1
        size = 28
        
        augmentation = MultIdentity
        weight_decay = 0.0
        
        eval_pgd_eta = 2.5 * eps / 20
        eval_pgd_J = 20
        eval_pgd_R = 0
        
    elif dataset == 'CIFAR-10':
        trainset = torchvision.datasets.CIFAR10(root='./data', train=True, download=False, transform=[transforms.ToTensor()])
        testset = torchvision.datasets.CIFAR10(root='./data', train=False, download=False, transform=[transforms.ToTensor()])
        
        train_data = torch.tensor(trainset.data).permute(0,3,1,2).cuda() / 255.
        train_labels = torch.tensor(trainset.targets).cuda()

        test_data = torch.tensor(testset.data).permute(0,3,1,2).cuda() / 255.
        test_labels = torch.tensor(testset.targets).cuda()
        
        train_bs = 100
        test_bs = 200
        n_channels = 3
        size = 32
        
        augmentation = MultCropFlip
        weight_decay = 5e-4
        
        eval_pgd_eta = 2.5 * eps / 20
        eval_pgd_J = 20
        eval_pgd_R = 0

    elif dataset == 'SVHN':
        trainset = torchvision.datasets.SVHN(root='./data', split='train', download=True, transform=[transforms.ToTensor()])
        testset = torchvision.datasets.SVHN(root='./data', split='test', download=True, transform=[transforms.ToTensor()])
        
        train_data = torch.tensor(trainset.data).cuda() / 255.
        train_labels = torch.tensor(trainset.labels).cuda()

        test_data = torch.tensor(testset.data).cuda() / 255.
        test_labels = torch.tensor(testset.labels).cuda()
        
        train_bs = 100
        test_bs = 200
        n_channels = 3
        size = 32
        
        augmentation = MultCropFlip
        weight_decay = 5e-4
        
        eval_pgd_eta = 2.5 * eps / 20
        eval_pgd_J = 20
        eval_pgd_R = 0

    n_train = train_data.shape[0]
    n_test = test_data.shape[0]
    n_train_batches = int(float(n_train) / float(train_bs))
    n_test_batches = int(np.ceil(float(n_test) / float(test_bs)))
    
    # Define variables
    model = model().cuda()
    deltas = [torch.zeros(size=[train_bs, n_channels, size, size]).cuda().uniform_(-eps, eps) for _ in range(n_train_batches)]
    
     # Gradient buffers
    w_grad_0_0 = init_w_grad_buffer(model)
    w_grad_1_1 = init_w_grad_buffer(model)
    w_mom_buf = init_w_grad_buffer(model)

    # Statistics
    comput_time = 0
    pgd_50_10_test_acc = None
    
    stats = []
    
    for epoch in range(n_epochs):
        for i in range(n_train_batches):
            X_data, y = train_data[i * train_bs:(i + 1) * train_bs], train_labels[i * train_bs:(i + 1) * train_bs]
            X, deltas[i].data = augmentation(X_data, deltas[i])
            iteration = epoch * n_train_batches + i + 1
            model.train()
            
            start = time.time()
            
            # Update deltas
            d = deltas[i].detach().clone().requires_grad_(True)
            n = torch.zeros_like(d).cuda().uniform_(-tau, tau)
            d.data = torch.clamp(d + n, -eps, eps)
            d.data = torch.clamp(X + d, 0, 1) - X
            
            for _ in range(n_steps):
                loss_2_1 = F.cross_entropy(model(X + d), y)
                loss_2_1.backward()
                d.data = d + eta * torch.sign(d.grad)
                d.data = torch.clamp(d - deltas[i], -tau, tau) + deltas[i]
                d.data = torch.clamp(d, -eps, eps)
                d.data = torch.clamp(X + d, 0, 1) - X
                d.grad.zero_()

            deltas[i].data = d
            
            # Update W
            loss_1_1 = F.cross_entropy(model(X + deltas[i]), y)
            model.zero_grad()
            loss_1_1.backward()
            
            w_grad_0_0 = [w_grad.clone() for w_grad in w_grad_1_1]
            w_grad_1_1 = [param.grad + weight_decay * param for param in model.parameters()]

            if iteration == 0:
                w_grad_0_0 = [torch.clone(w_grad) for w_grad in w_grad_1_1]

            with torch.no_grad():
                for j, param in enumerate(model.parameters()):
                    w_grad = 2 * w_grad_1_1[j] - w_grad_0_0[j]
                    w_mom_buf[j].mul_(0.9).add_(w_grad, alpha=1.0)
                    param.add_(w_mom_buf[j], alpha=-lr(iteration / n_train_batches))
            
            # Record statistics
            end = time.time()
            comput_time += (end - start)

            if iteration % p_iter == 0:
                model.eval()
                
                natural_test_acc = 0.
                fgsm_test_acc = 0.
                pgd_20_test_acc = 0.
                
                eval_pgd_50_10 = (iteration == n_epochs * n_train_batches) or (iteration == int(n_epochs / 2) * n_train_batches)
                if eval_pgd_50_10:
                    pgd_50_10_test_acc = 0.

                for k in range(n_test_batches):
                    X, y = test_data[k * test_bs:(k + 1) * test_bs], test_labels[k * test_bs:(k + 1) * test_bs]

                    output = model(X)
                    fgsm_output = model(X + fgsm(model, X, y, eps))
                    pgd_20_output = model(X + pgd(model, X, y, eps, eval_pgd_eta, eval_pgd_J, eval_pgd_R))

                    natural_test_acc += (output.max(1)[1] == y).sum().item() / n_test
                    fgsm_test_acc += (fgsm_output.max(1)[1] == y).sum().item() / n_test
                    pgd_20_test_acc += (pgd_20_output.max(1)[1] == y).sum().item() / n_test
        
                    if eval_pgd_50_10:
                        pgd_50_10_output = model(X + pgd(model, X, y, eps, 2.5 * eps / 50, 50, 10))
                        pgd_50_10_test_acc += (pgd_50_10_output.max(1)[1] == y).sum().item() / n_test

                stat = {
                    'Method': 'MSI-HG',
                    'Dataset': dataset,
                    'eps': eps,
                    'J': n_steps,
                    'eta': eta,
                    'Trial': trial,
                    'Iteration': iteration,
                    'Time': comput_time,
                    'Test Acc.': natural_test_acc,
                    'FGSM Test Acc.': fgsm_test_acc,
                    'PGD-20 Test Acc.': pgd_20_test_acc,
                    'PGD-50-10 Test Acc.': pgd_50_10_test_acc,
                }
                stats.append(stat)
                pprint(stat)

                yield stats

def main():
    model = SMALL_CNN
    dataset = 'MNIST'
    n_epochs = 50
    lr = lambda epoch : 0.01
    eps = 0.4
    tau = 0.2
    eta = 2.5 * eps / 5
    n_steps = 5
    p_iter = 400

    for trial in range(5):
        for stats in run(model, dataset, n_epochs, lr, eps, tau, eta, n_steps, p_iter,  trial + 1): pass
        save(stats, 'results/%s_eps-%s_msi_trial-%s_J-%s.pickle' % (dataset, eps, trial + 1, n_steps))

    model = PreActResNet18
    dataset = 'CIFAR-10'
    n_epochs = 15
    lr = lambda epoch : np.interp([epoch], [0, 5, 15, 20, 30], [0, 0.2, 0, 0.02, 0])[0]
    eps = 8. / 255
    tau = 14. / 255
    eta = 2.5 * eps / 10
    n_steps = 10
    p_iter = 125

    for trial in range(5):
        for stats in run(model, dataset, n_epochs, lr, eps, tau, eta, n_steps, p_iter, trial + 1): pass
        save(stats, 'results/%s_eps-%s_msi_trial-%s_J-%s.pickle' % (dataset, eps, trial + 1, n_steps))

    model = PreActResNet8
    dataset = 'SVHN'
    n_epochs = 15
    lr = lambda epoch : np.interp([epoch], [0, 5, 15], [0, 0.2, 0])[0]
    eps = 4. / 255
    tau = 6. / 255
    eta = 2.5 * eps / 10
    n_steps = 10
    p_iter = 183

    for trial in range(5):
        for stats in run(model, dataset, n_epochs, lr, eps, tau, eta, n_steps, p_iter, trial + 1): pass
        save(stats, 'results/%s_eps-%s_msi_trial-%s_J-%s.pickle' % (dataset, eps, trial + 1, n_steps))


if __name__ == '__main__':
    main()
