import jax
import jax.numpy as jnp

import haiku as hk


class Generator_BN(hk.Module):
    def __init__(self, channels):
        super().__init__()

        self.conv1 = hk.Conv2DTranspose(output_channels=512, kernel_shape=(4,4), stride=(1,1), padding='VALID', data_format='NCHW')
        self.bn1 = hk.BatchNorm(create_scale=True, create_offset=True, decay_rate=0.9)

        self.conv2 = hk.Conv2DTranspose(output_channels=256, kernel_shape=(4,4), stride=(2,2), padding='SAME', data_format='NCHW')
        self.bn2 = hk.BatchNorm(create_scale=True, create_offset=True, decay_rate=0.9)

        self.conv3 = hk.Conv2DTranspose(output_channels=128, kernel_shape=(4,4), stride=(2,2), padding='SAME', data_format='NCHW')
        self.bn3 = hk.BatchNorm(create_scale=True, create_offset=True, decay_rate=0.9)

        self.conv4 = hk.Conv2DTranspose(output_channels=64, kernel_shape=(4,4), stride=(2,2), padding='SAME', data_format='NCHW')
        self.bn4 = hk.BatchNorm(create_scale=True, create_offset=True, decay_rate=0.9)

        self.conv5 = hk.Conv2DTranspose(output_channels=channels, kernel_shape=(3,3), stride=(1,1), padding='SAME', data_format='NCHW')

    def __call__(self, z, is_training):
        x = z.reshape(z.shape[0], z.shape[1], 1, 1)  # (128, 100, 1, 1)

        x = self.conv1(x)   # (128, 512, 4, 4)
        x = self.bn1(x, is_training)
        x = jax.nn.relu(x)

        x = self.conv2(x)   # (128, 256, 8, 8)
        x = self.bn2(x, is_training)
        x = jax.nn.relu(x)

        x = self.conv3(x)   # (128, 128, 16, 16)
        x = self.bn3(x, is_training)
        x = jax.nn.relu(x)

        x = self.conv4(x)   # (128, 64, 32, 32)
        x = self.bn4(x, is_training)
        x = jax.nn.relu(x)

        x = self.conv5(x)   # (128, 1, 32, 32)  1 channel for MNIST
        x = jnp.tanh(x)

        return x

class Discriminator_BN(hk.Module):
    def __init__(self):
        super().__init__()

        self.conv1 = hk.Conv2D(64, 3, stride=1, padding='SAME', data_format='NCHW')
        self.bn1 = hk.BatchNorm(create_scale=True, create_offset=True, decay_rate=0.9)

        self.conv2 = hk.Conv2D(64, 4, stride=2, padding='SAME', data_format='NCHW')
        self.bn2 = hk.BatchNorm(create_scale=True, create_offset=True, decay_rate=0.9)

        self.conv3 = hk.Conv2D(128, 3, stride=1, padding='SAME', data_format='NCHW')
        self.bn3 = hk.BatchNorm(create_scale=True, create_offset=True, decay_rate=0.9)

        self.conv4 = hk.Conv2D(128, 4, stride=2, padding='SAME', data_format='NCHW')
        self.bn4 = hk.BatchNorm(create_scale=True, create_offset=True, decay_rate=0.9)

        self.conv5 = hk.Conv2D(256, 3, stride=1, padding='SAME', data_format='NCHW')
        self.bn5 = hk.BatchNorm(create_scale=True, create_offset=True, decay_rate=0.9)

        self.conv6 = hk.Conv2D(256, 4, stride=2, padding='SAME', data_format='NCHW')
        self.bn6 = hk.BatchNorm(create_scale=True, create_offset=True, decay_rate=0.9)

        self.conv7 = hk.Conv2D(512, 3, stride=1, padding='SAME', data_format='NCHW')
        self.bn7 = hk.BatchNorm(create_scale=True, create_offset=True, decay_rate=0.9)

        self.fc = hk.Linear(1)

    def __call__(self, inputs, is_training):
        x = inputs  # (128, 1, 32, 32) for MNIST

        x = self.conv1(x)   # (128, 64, 32, 32) RIGHT!  (128, 1, 32, 64) WRONG
        x = self.bn1(x, is_training)
        x = jax.nn.relu(x)

        x = self.conv2(x)   # (128, 64, 16, 16)
        x = self.bn2(x, is_training)
        x = jax.nn.relu(x)

        x = self.conv3(x)   # (128, 128, 16, 16)
        x = self.bn3(x, is_training)
        x = jax.nn.relu(x)

        x = self.conv4(x)   # (128, 128, 8, 8)
        x = self.bn4(x, is_training)
        x = jax.nn.relu(x)

        x = self.conv5(x)   # (128, 256, 8, 8)
        x = self.bn5(x, is_training)
        x = jax.nn.relu(x)

        x = self.conv6(x)   # (128, 256, 4, 4)
        x = self.bn6(x, is_training)
        x = jax.nn.relu(x)

        x = self.conv7(x)   # (128, 512, 4, 4)
        x = self.bn7(x, is_training)
        x = jax.nn.relu(x)

        x = self.fc(x.reshape(x.shape[0], -1))  # (128, 1)

        return x

class Discriminator_SN(hk.Module):
    def __init__(self):
        super().__init__()

        self.conv1 = hk.Conv2D(64, 3, stride=1, padding='SAME', data_format='NCHW')
        self.sn1 = hk.SpectralNorm()

        self.conv2 = hk.Conv2D(64, 4, stride=2, padding='SAME', data_format='NCHW')
        self.sn2 = hk.SpectralNorm()

        self.conv3 = hk.Conv2D(128, 3, stride=1, padding='SAME', data_format='NCHW')
        self.sn3 = hk.SpectralNorm()

        self.conv4 = hk.Conv2D(128, 4, stride=2, padding='SAME', data_format='NCHW')
        self.sn4 = hk.SpectralNorm()

        self.conv5 = hk.Conv2D(256, 3, stride=1, padding='SAME', data_format='NCHW')
        self.sn5 = hk.SpectralNorm()

        self.conv6 = hk.Conv2D(256, 4, stride=2, padding='SAME', data_format='NCHW')
        self.sn6 = hk.SpectralNorm()

        self.conv7 = hk.Conv2D(512, 3, stride=1, padding='SAME', data_format='NCHW')
        self.sn7 = hk.SpectralNorm()

        self.fc = hk.Linear(1)
        self.sn8 = hk.SpectralNorm()

    def __call__(self, inputs, is_training):
        x = inputs  # (128, 1, 32, 32) for MNIST

        x = self.conv1(x)   # (128, 64, 32, 32) RIGHT!  (128, 1, 32, 64) WRONG
        x = self.sn1(x, is_training)
        x = jax.nn.relu(x)

        x = self.conv2(x)   # (128, 64, 16, 16)
        x = self.sn2(x, is_training)
        x = jax.nn.relu(x)

        x = self.conv3(x)   # (128, 128, 16, 16)
        x = self.sn3(x, is_training)
        x = jax.nn.relu(x)

        x = self.conv4(x)   # (128, 128, 8, 8)
        x = self.sn4(x, is_training)
        x = jax.nn.relu(x)

        x = self.conv5(x)   # (128, 256, 8, 8)
        x = self.sn5(x, is_training)
        x = jax.nn.relu(x)

        x = self.conv6(x)   # (128, 256, 4, 4)
        x = self.sn6(x, is_training)
        x = jax.nn.relu(x)

        x = self.conv7(x)   # (128, 512, 4, 4)
        x = self.sn7(x, is_training)
        x = jax.nn.relu(x)

        x = self.fc(x.reshape(x.shape[0], -1))  # (128, 1)
        x = self.sn8(x)

        return x

class Generator(hk.Module):
    def __init__(self, channels):
        super().__init__()

        self.conv1 = hk.Conv2DTranspose(output_channels=512, kernel_shape=(4,4), stride=(1,1), padding='VALID', data_format='NCHW')
        self.conv2 = hk.Conv2DTranspose(output_channels=256, kernel_shape=(4,4), stride=(2,2), padding='SAME', data_format='NCHW')
        self.conv3 = hk.Conv2DTranspose(output_channels=128, kernel_shape=(4,4), stride=(2,2), padding='SAME', data_format='NCHW')
        self.conv4 = hk.Conv2DTranspose(output_channels=64, kernel_shape=(4,4), stride=(2,2), padding='SAME', data_format='NCHW')
        self.conv5 = hk.Conv2DTranspose(output_channels=channels, kernel_shape=(3,3), stride=(1,1), padding='SAME', data_format='NCHW')

    def __call__(self, z, is_training):
        x = z.reshape(z.shape[0], z.shape[1], 1, 1)  # (128, 100, 1, 1)

        x = self.conv1(x)   # (128, 512, 4, 4)
        x = jax.nn.relu(x)

        x = self.conv2(x)   # (128, 256, 8, 8)
        x = jax.nn.relu(x)

        x = self.conv3(x)   # (128, 128, 16, 16)
        x = jax.nn.relu(x)

        x = self.conv4(x)   # (128, 64, 32, 32)
        x = jax.nn.relu(x)

        x = self.conv5(x)   # (128, 1, 32, 32)  1 channel for MNIST
        x = jnp.tanh(x)

        return x

class Discriminator(hk.Module):
    def __init__(self):
        super().__init__()

        self.conv1 = hk.Conv2D(64, 3, stride=1, padding='SAME', data_format='NCHW')
        self.conv2 = hk.Conv2D(64, 4, stride=2, padding='SAME', data_format='NCHW')
        self.conv3 = hk.Conv2D(128, 3, stride=1, padding='SAME', data_format='NCHW')
        self.conv4 = hk.Conv2D(128, 4, stride=2, padding='SAME', data_format='NCHW')
        self.conv5 = hk.Conv2D(256, 3, stride=1, padding='SAME', data_format='NCHW')
        self.conv6 = hk.Conv2D(256, 4, stride=2, padding='SAME', data_format='NCHW')
        self.conv7 = hk.Conv2D(512, 3, stride=1, padding='SAME', data_format='NCHW')
        self.fc = hk.Linear(1)

    def __call__(self, inputs, is_training):
        x = inputs  # (128, 1, 32, 32) for MNIST

        x = self.conv1(x)   # (128, 64, 32, 32) RIGHT!  (128, 1, 32, 64) WRONG
        x = jax.nn.relu(x)

        x = self.conv2(x)   # (128, 64, 16, 16)
        x = jax.nn.relu(x)

        x = self.conv3(x)   # (128, 128, 16, 16)
        x = jax.nn.relu(x)

        x = self.conv4(x)   # (128, 128, 8, 8)
        x = jax.nn.relu(x)

        x = self.conv5(x)   # (128, 256, 8, 8)
        x = jax.nn.relu(x)

        x = self.conv6(x)   # (128, 256, 4, 4)
        x = jax.nn.relu(x)

        x = self.conv7(x)   # (128, 512, 4, 4)
        x = jax.nn.relu(x)

        x = self.fc(x.reshape(x.shape[0], -1))  # (128, 1)

        return x

class MLP_Discriminator(hk.Module):
    def __init__(self, hdim=200):
        super().__init__()

        self.fc1 = hk.Linear(hdim)
        self.fc2 = hk.Linear(hdim)
        self.fc3 = hk.Linear(1)

    def __call__(self, x, is_training):
        x = x.reshape(x.shape[0], -1)

        x = self.fc1(x)
        x = jax.nn.relu(x)

        x = self.fc2(x)
        x = jax.nn.relu(x)

        x = self.fc3(x)

        return x

class MLP_Generator(hk.Module):
    def __init__(self, hdim=200, output_dim=1024):
        super().__init__()

        self.fc1 = hk.Linear(hdim)
        self.fc2 = hk.Linear(hdim)
        self.fc3 = hk.Linear(output_dim)

    def __call__(self, x, is_training):
        x = self.fc1(x)
        x = jax.nn.relu(x)

        x = self.fc2(x)
        x = jax.nn.relu(x)

        x = self.fc3(x)
        x = jnp.tanh(x)

        return x
