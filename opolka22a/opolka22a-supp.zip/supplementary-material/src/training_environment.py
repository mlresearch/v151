import pathlib
import time
from collections import defaultdict
import numpy as np
import pickle as pk

import tensorflow as tf
import tensorflow_probability as tfp
from gpflow.utilities.utilities import _merge_leaf_components, leaf_components


class Trainer:
    """
    Class comprising all functionality for initializing, training and
    evaluating a model, as well as checkpointing and writing results.
    """

    def __init__(self, config, logger=None):
        """
        :param config: Object containing training settings, typically
        parsed from an argparser.
        """
        self.conf = config
        self.logger = logger

    def train_model(self, model, num_epochs, train_step_f, val_step_f=None, test_step_f=None,
                    eval_every=1, save_weights_fn=None, load_weights_fn=None, conv_last_improv=None,
                    conv_diff=None, callback_fn=None, min_epochs=0):
        for epoch in range(num_epochs):
            train_step_f(model)
            if val_step_f and epoch % eval_every == 0:
                val_step_f(model)
            self.logger.log_parameters(model)
            self.logger.visualize()
            self.logger.complete_epoch(save_weights_fn=save_weights_fn, offset=min_epochs)
            print(self.logger.previous_epoch_summary())
            if self.logger.has_converged(last_improvement=conv_last_improv, convergence_diff=conv_diff,
                                         earliest_epoch=min_epochs):
                break
            if callback_fn is not None:
                callback_fn(epoch)
        if test_step_f:
            if load_weights_fn:
                load_weights_fn()
            test_step_f(model)
        self.logger.write_epoch_outputs()
        self.logger.complete_epoch(offset=min_epochs)
        print(self.logger.previous_epoch_summary())
        print(self.logger.print_summary(offset=min_epochs))


class MetricLog:
    """
    Class describing how a single metric (e.g. train_loss) progresses
    over time.
    """
    def __init__(self):
        self.epochs = []
        self.values = []

    def append(self, epoch, value):
        self.epochs.append(epoch)
        self.values.append(value)

    def min_epoch(self, offset=0):
        """
        :param offset: The min epoch has to be after the offset. If fewer epochs than the offset have finished thus far,
        the most recent epoch is returned.
        """
        values = self.values[offset:]
        if len(values) == 0:
            return len(self.values)-1
        min_idx = np.argmin(values) + offset
        return self.epochs[min_idx]

    def value_at_epoch(self, epoch):
        try:
            idx = self.epochs.index(epoch)
        except ValueError:
            return np.nan
        else:
            return self.values[idx]

    def __getitem__(self, index):
        return self.values[index]

    def __len__(self):
        assert len(self.epochs) == len(self.values)
        return len(self.values)


class PerformanceLogger:
    def __init__(self, metric_funcs, minimizer, log_filepath, results_filepath, tf_log_dir,
                 write_every=20, visualize_fn=None, visualize_every=20, default_log_dir=None,
                 summary_prefix="", minimizer_phases=None, one_time_phases=None):
        """
        Class providing functionality for logging the performance of a model.
        :param metric_funcs: Dictionary of phases where each phase is a
        dictionary of metric functions. Typically, a phase might be
        training, validation, or testing. A metric function accepts
        exactly one argument, which is a dictionary of outputs from
        a single epoch. It returns the corresponding metric.
        A possible metric_funcs argument is
            ```
            metric_funcs = {
                "train": {
                    "train_acc": compute_train_acc_f,
                    "train_auc": compute_train_auc_f,
                },
                "val": {
                    "val_acc": compute_val_acc_f,
                    "val_auc": compute_val_auc_f,
                }
            }
            ```
        :param minimizer: Key of the variable that determines the final value
        stored in the summary. Usually the validation loss.
        :param default_log_dir: A pathlib.Path pointing to a directory that users of the
        PerformanceLogger can use to store additional files (e.g. save visualization plots). If
        None, it defaults to the directory provided in the log_filepath (i.e. log/log.pk becomes
        log).
        :param summary_prefix: String inserted at the start of each line of the summary produced
        with `print_summary` if that line contains a new result. Useful when printing a summary to
        be recognized by Guild.AI.
        :param minimizer_phases: List of phases matching keys in the provided metric_funcs
        dictionary that are evaluated multiple times and the best result is therefore the one where
        the minimizer metric is minimal. Typically this would be the train and validation phase.
        :param one_time_phases: List of phases matching keys in the provided metric_funcs dictionary
        that are evaluated only once during a run and the best result is therefore simply that one
        result. Typically this would be the test phase if it is only evaluated at the very end of
        training.
        """
        self._metric_funcs = metric_funcs
        self._current_epoch_outputs = defaultdict(list)                             # Stores all outputs of a training/validation/test step for the current epoch
        self.metric_dict = defaultdict(MetricLog)
        self.minimizer = minimizer
        self.log_filepath = pathlib.Path(log_filepath)
        self.results_filepath = pathlib.Path(results_filepath)
        self.write_every = write_every
        self._write_countdown = write_every
        self.visualize_fn = visualize_fn
        self.visualize_every = visualize_every
        self.summary_prefix = summary_prefix
        self.minimizer_phases = minimizer_phases
        self.one_time_phases = one_time_phases
        self._start_time = time.time()
        self.current_epoch = 0
        self.misc_info = {}
        self._tf_summary_writer = tf.summary.create_file_writer(str(tf_log_dir))
        self.default_log_dir = (pathlib.Path(default_log_dir) if default_log_dir
                                else self.log_filepath.parent)

        # Create log directories if necessary
        if not self.log_filepath.parent.exists():
            self.log_filepath.parent.mkdir(parents=True)
        if not self.results_filepath.parent.exists():
            self.results_filepath.parent.mkdir(parents=True)

        if "duration" in metric_funcs:
            raise ValueError("Key \"duration\" is a reserved key for internal"
                             "use of PerformanceLogger.")

    def add_values(self, metric_dict):
        for key, metric_batch in metric_dict.items():
            self._current_epoch_outputs[key].append(metric_batch)

    def compute_metrics(self, phase):
        """
        Compute metrics for the metrics of the given phase with all values currently in self._current_epoch_outputs.
        """
        for key, metric_f in self._metric_funcs[phase].items():
            metric = metric_f(self._current_epoch_outputs)
            self.metric_dict[key].append(self.current_epoch, metric)
            with self._tf_summary_writer.as_default():
                tf.summary.scalar(key, metric, step=self.current_epoch)

    def complete_epoch(self, save_weights_fn=None, offset=0):
        """
        Marks the epoch as finished, stores the weights if a new best has been reached, and writes out the log if
        necessary.
        :param offset: When determining the best epoch so far, it has to come after the specified offset.
        """
        # Add duration as additional metric
        duration = time.time() - self._start_time
        self.metric_dict["duration"].append(self.current_epoch, duration)
        self._start_time = time.time()

        self._current_epoch_outputs = defaultdict(list)
        self.current_epoch += 1

        # Save model weights if new minimum reached
        min_epoch = self.metric_dict[self.minimizer].min_epoch(offset)
        if save_weights_fn and min_epoch == self.current_epoch-1:
            save_weights_fn()
        # Write log if necessary
        if self.current_epoch % self.write_every == 0:
            self.write(self.log_filepath)

    def log_parameters(self, module):
        """
        Takes a list of parameters and logs their values using tensorboard.
        """
        with self._tf_summary_writer.as_default():
            summary = module_summary(module)
            for param_summary in summary:
                name = param_summary["name"] + " {}".format(param_summary["shape"])
                value = param_summary["value"]
                if len(value.shape) == 0:
                    tf.summary.scalar(name, value, step=self.current_epoch)
                else:
                    tf.summary.histogram(name, value, step=self.current_epoch)

    def visualize(self):
        if self.visualize_fn and self.current_epoch % self.visualize_every == 0:
            self.visualize_fn(self._current_epoch_outputs, self)

    def has_converged(self, convergence_diff=None, last_improvement=None,
                      earliest_epoch=0, window=20):
        if self.current_epoch < earliest_epoch:
            return False
        # Convergence based on insufficient difference in the minimizer metric
        if convergence_diff is not None:
            train_measures = self.metric_dict[self.minimizer]
            if len(train_measures) <= window+1:     # Number of epochs has not reached window size yet
                return False
            diff = train_measures[-1] - train_measures[-window]
            converged = (-diff < convergence_diff)
            return converged
        # Convergence based on no more improvement for at least K epochs
        if last_improvement is not None:
            min_epoch = self.metric_dict[self.minimizer].min_epoch(offset=earliest_epoch)
            if self.current_epoch - min_epoch > last_improvement:
                return True
        return False

    def reached_relative_reduction(self, metric_key, rel_reduct):
        if len(self.metric_dict[metric_key]) == 0:
            return False
        initial_val = self.metric_dict[metric_key][0]
        current_val = self.metric_dict[metric_key][-1]
        diff = initial_val - current_val
        if diff / initial_val > rel_reduct:
            return True
        return False

    def previous_epoch_summary(self):
        summary = f"{self.current_epoch}:"
        for key, log in self.metric_dict.items():
            if key == "duration": continue
            if log.epochs[-1] == self.current_epoch-1:
                summary += f"\t{key}: {log[-1]:.3f}"
        duration = self.metric_dict["duration"][-1]
        summary += f"\t[{duration:.2f}s]"
        return summary

    def write(self, filepath):
        with open(filepath, "wb") as fd:
            pk.dump(self.metric_dict, fd)

    def get_best_metrics(self, minimizer_phases=None, one_time_phases=None, offset=0):
        """
        Returns a dictionary of metric values for the epoch that minimizes the
        minimizer metric (e.g. validation loss). Each entry is the metric
        name and the value at the best epoch. It also allows to include
        metrics of phases that are just executed once (e.g. a test phase
        that only computes the test accuracy once after the training has
        finished).
        :param offset: When determining the best epoch so far, it has to come after the specified offset.
        """
        minimizer_phases = minimizer_phases if minimizer_phases is not None else self.minimizer_phases
        one_time_phases = one_time_phases if one_time_phases is not None else self.one_time_phases
        metrics = {}
        min_epoch = self.metric_dict[self.minimizer].min_epoch(offset)
        metrics["min_epoch"] = min_epoch
        for phase in minimizer_phases:
            for key in self._metric_funcs[phase].keys():
                metrics[key] = self.metric_dict[key].value_at_epoch(min_epoch)
        for phase in one_time_phases:
            for key in self._metric_funcs[phase].keys():
                metrics[key] = self.metric_dict[key][-1]
        return metrics

    def get_summary(self, settings_description="", prefix="", offset=0):
        """
        Returns a string containing a summary of the results of the run.
        :param settings_description: String containing details about the configuration of the run
        to be appended in front of the summary.
        :param offset: When determining the best epoch so far, it has to come after the specified offset.
        """
        best_results = self.get_best_metrics(offset=offset)
        summary = settings_description + "\n\n"
        for key, value in best_results.items():
            summary += f"{prefix}{key}: {value}\n"
        return summary

    def write_summary(self, filepath, settings_description="", offset=0):
        """
        Writes a text file containing a summary of the results of the run.
        :param filepath: Filepath of the summary.
        :param settings_description: String containing details about the configuration of the run
        to be appended in front of the summary.
        :param offset: When determining the best epoch so far, it has to come after the specified offset.
        """
        summary = self.get_summary(settings_description, offset=offset)
        with open(filepath, "w") as fd:
            fd.write(summary)

    def print_summary(self, settings_description="", prefix=None, offset=0):
        """
        Prints a summary of the results of a run.
        :param settings_description: String containing details about the configuration of the run
        to be appended in front of the summary.
        :param prefix: String inserted at the start of each line of the summary if that line
        contains a new result. Useful when printing a summary to be recognized by Guild.AI. If None,
        the PerformanceLogger's summary_prefix attribute is used, which defaults to "".
        :param offset: When determining the best epoch so far, it has to come after the specified offset.
        """
        if prefix is None:
            prefix = self.summary_prefix
        summary = self.get_summary(settings_description, prefix=prefix, offset=offset)
        print(summary)

    def write_epoch_outputs(self):
        """
        Writes the current, raw epoch metrics to file, for example to persist
        test predictions and labels.
        """
        with open(self.results_filepath, "wb") as fd:
            pk.dump(self._current_epoch_outputs, fd)


def module_summary(module: tf.Module):
    def get_transform(path, var):
        if hasattr(var, "transform") and var.transform is not None:
            if isinstance(var.transform, tfp.bijectors.Chain):
                return " + ".join(b.__class__.__name__ for b in var.transform.bijectors[::-1])
            return var.transform.__class__.__name__
        return None

    def get_prior(path, var):
        if hasattr(var, "prior") and var.prior is not None:
            return var.prior.name
        return None

    # list of (column_name: str, column_getter: Callable[[tf.Variable], str]) tuples:
    column_definitions = {
        "name": lambda path, var: path,
        "class": lambda path, var: var.__class__.__name__,
        "transform": get_transform,
        "prior": get_prior,
        "trainable": lambda path, var: var.trainable,
        "shape": lambda path, var: var.shape,
        "dtype": lambda path, var: var.dtype.name,
        "value": lambda path, var: var.numpy(),
    }
    merged_leaf_components = _merge_leaf_components(leaf_components(module))

    column_values = [
        {col_name: getter(path, variable) for col_name, getter in column_definitions.items()}
        for path, variable in merged_leaf_components.items()
    ]
    return column_values
