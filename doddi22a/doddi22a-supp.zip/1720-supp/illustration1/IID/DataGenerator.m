function [X] = DataGenerator(Nstep,h,E, initial)
Nnodes = size(h,1);
X = zeros(Nnodes,Nstep);
X(:,1)= initial;
for t = 3:(Nstep)
    X(:,t)= h*X(:,t-1) +5*(E(:,t-1)-0.3*E(:,t-2));    
end

end

