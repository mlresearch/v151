


#samplesize = 100
#test = datagen(5000,covsize,seed=ind+30000)
#train = datagen(samplesize,covsize,seed=loop+20002+samplesize)



subsetData<-function(Data,index){
  NewData=list()
  NewData$X=Data$X[index,]
  NewData$A=Data$A[index]
  NewData$Y=Data$Y[index]
  NewData$mu=Data$mu[index]
  NewData$S=Data$S[index]
  NewData$alpha =Data$alpha[index,]
  NewData$propensity = Data$propensity[index]
  NewData$opt = Data$opt[index] 
  NewData$label = Data$label[index]
  return(NewData)
}


measurement <- function(pred,test,lower=NULL,weights = rep(1,length(pred))){
  n=length(test$A)
  NA->correlation->Rsquare->misclass->cost->percentage->ATEm->ATEc
  region=drop(test$A>pred)
  if (!is.null(test$opt)){
     # if (family=='continuous'){
        Rsquare=1-mean((pred-test$opt)^2)/var(test$opt)
        correlation=cor(drop(pred),test$opt)
      #} else {
      #  value=obj$value
      #  Rsquare=1-mean((value-test$opt)^2)/var(test$opt)
      #  correlation=cor(value,test$opt)
     # }
    
  } 
  misclass=sum(weights*(test$alpha[,1]*(region)*(test$Y<test$S) + test$alpha[,2]*(!region)*(test$Y>test$S)))/sum(weights)
  cost=sum(weights*(test$alpha[,1]*(region)*pmax((test$S-test$Y),0) + test$alpha[,2]*(!region)*pmax((test$Y-test$S),0)))/sum(weights)
  percentage=sum(region)/length(test$A)
  
  if ((sum(!region)>(n/50))&(sum(region)>(n/50))){
    tmp=as.data.frame(cbind(region,test$X))
    #fit= weightit(factor(region)~.,data=tmp,method = "energy", estimand = "ATE")
    #inverseprobs=fit$weights
    inverseprobs= rep(1,nrow(test$X))
    #inverseprobs = rep(1,length(test$Y))
    TGm=weighted.mean(test$Y[region]>test$S[region],w=inverseprobs[region])*100
    CGm=weighted.mean(test$Y[!region]>test$S[!region],w=inverseprobs[!region])*100
    ATEm=TGm-CGm
    TGc=weighted.mean(test$Y[region]-test$S[region],w=inverseprobs[region])
    CGc=weighted.mean(test$Y[!region]-test$S[!region],w=inverseprobs[!region])
    ATEc=TGc-CGc
  } 
  
  return(list(TGm=TGm,CGm=CGm,correlation=correlation,Rsquare=Rsquare,pred=pred,misclass=misclass,cost=cost,percentage=percentage))
}


psi.eps <- function(a,b,Eps){
  pmin(pmax((a-b)/Eps,0),1)
}

psi1.eps <- function(a,b,Eps){
  pmax((a-b)/Eps,0)
}

psi2.eps <- function(a,b,Eps){
  pmax((a-b)/Eps -1,0)
}

lossfunc.eps <- function(Y,S,A,f.low,weights,alpha){
   values <- weights*(alpha*(Y < S)*psi.eps(A, f.low,Eps) +  (1 - alpha)*(Y > S)*psi.eps(f.low,A,Eps)) 
}

lossfunc <-  function(Y,S,A,f.low,weights,alpha){
  values <- weights*(alpha*(Y < S)*(A > f.low) +  (1 - alpha)*(Y > S)*(A < f.low)) 
}

obj.intercept <- function(x,weights,Y,S,Adose,pred.main,Eps){
  sum(weights*(alpha*(Y < S)*pmin(pmax((Adose - pred.main -x)/Eps,0),1)
               +  (1 - alpha)*(Y > S)*pmin(pmax((pred.main + x - Adose)/Eps,0),1))) 
} 

dc_loop <- function(input,Eps = NULL,alpha = 0.5,lambda,method = 'G-O-Learning',sigma.v = NULL, pred_old = NULL, weights = NULL){
  maxstep = 200
  steps = 0
  Adose = input$A
  X = input$X
  Y = input$Y
  S = input$S
  #S = median(Y)
  nsize <- nrow(X)
  if(method == 'G-O-Learning'){
    kerntype <- rbfdot(sigma = 1/ncol(X))
  } else{
    kerntype  <- vanilladot()
  }
  distmat = kernelMatrix(kerntype, X)
  #tmpdata = data.frame(A= Adose, X=X)
  #W3 <- weightit(A ~ ., data = tmpdata, method = "ebal")
  #weights <- W3$weights/nsize
  if(is.null(weights)){
  W3 <- total_distance_balance(Adose,X,gamma=0.1)
  weights <- W3$weights
  }
  doserange <- max(Adose) -  min(Adose)
  if(is.null(Eps)){Eps =  doserange/10}
  H_vec <- (1 - alpha)*(Y > S)*weights/lambda
  Hti_vec <-  alpha*(Y < S)*weights/lambda
  if(is.null(pred_old)){
  pred_old = Adose + runif(nrow(X),-doserange,doserange)
  }
  pred_current = pred_old + 1
  while(max(abs(pred_current - pred_old)) > 0.001 && steps < maxstep){
  steps = steps +1
  pred_old <- pred_current
  Q_vec <- (pred_old - Adose > Eps)/Eps
  Qti_vec <- (Adose - pred_old > Eps)/Eps
  lvec <- c(Hti_vec*Qti_vec - H_vec*Q_vec - Hti_vec/Eps,0)
  uvec <- c(Hti_vec*Qti_vec - H_vec*Q_vec + H_vec/Eps,0)
  Amat <- rbind(diag(1,nrow= nsize,ncol= nsize),rep(1, nsize))
  opt.out <- osqp::solve_osqp(P = distmat, q = Adose, A = Amat, l = lvec, u = uvec,
                                pars = osqp::osqpSettings(max_iter = 2e3,
                                                          eps_abs = 1e-8,
                                                          eps_rel = 1e-8,
                                                          verbose = FALSE))

  pred.main <-   as.vector(-opt.out$x %*% distmat)
  int.new <- optimize(obj.intercept,interval = c(-doserange,doserange),weights,Y,S,Adose,pred.main,Eps)$minimum
  pred_current <- pred.main + int.new
  }
  return(list(coefs=opt.out$x, trainX=X,lambda=lambda, intercept = int.new, kernel = kerntype))
}

predict.dose <- function(fit,test){
  distmat <- kernelMatrix(fit$kernel, fit$trainX,test$X)
  pred.value <- as.vector(-fit$coefs %*% distmat + fit$intercept)
  return(pred.value)
}

cv.doseInt<-function(train,test=NULL,pred0=NULL,nfolds=5,type='PDI',
                     method=c('L-O-Learning','G-O-Learning'), maxiter=100,lower=TRUE,
                     K=5, aL=NULL,aU=NULL,sigma.v=NULL,
                     Eps=NULL,lambda=2^seq(-12,1,0.5), pred_old = NULL){
  #if (is.null(Eps)) Eps=seq(0.1*sd(train$A),0.5*sd(train$A),length.out = 10)
  
  if (is.null(test)) test=train
  n=length(train$A)
  p=ncol(train$X)
  nsize=round(n/nfolds)
  if (is.null(sigma.v)) sigma.v = 1/p
  if (is.null(Eps)) Eps=0.1*(max(train$A) -  min(train$A))
  W3train <- total_distance_balance(train$A,train$X,gamma=0.1)
  weights.train <- W3train$weights
  #W3test <- total_distance_balance(test$A,test$X,gamma=0.1)
  #weights.test <- W3test$weights
  grid.cv = switch(method,
                   'L-O-Learning'=expand.grid(Eps = Eps, lambda = lambda),
                   'G-O-Learning'=expand.grid(Eps = Eps, lambda = lambda, sigma.v=sigma.v))

  Rec=rep(0,nrow(grid.cv))
  i=1;k=1
  for(i in 1:nfolds){
    print(paste("=== Fold ",i,"===",sep=" "))
    index = seq(((i-1)*nsize+1),(i*nsize))
    train0 = subsetData(train,-index)
    test0 = subsetData(train,index)
    pred_old0 = NULL
    W3train0 <- total_distance_balance(train0$A,train0$X,gamma=0.1)
    weights.train0 <- W3train0$weights
    W3test0 <- total_distance_balance(test0$A,test0$X,gamma=0.1)
    weights.test0 <- W3test0$weights
    if (!is.null(pred_old)){pred_old0 = pred_old[-index]}
    for(k in 1:dim(grid.cv)[1]){
      print(grid.cv[k,])
      if (dim(grid.cv)[2]>=3) sigma=grid.cv[k,3]
      fit.dc = dc_loop(input=train0,Eps = grid.cv[k,1],alpha = 0.5,lambda=grid.cv[k,2],method=method,sigma.v = sigma.v, 
                       pred_old=pred_old0, weights = weights.train0)
      tmp.pred = predict.dose(fit.dc,test0)
      testloss = measurement(tmp.pred,test0,weights.test0)
      Rec[k]= Rec[k]+ testloss$misclass
    }
  }
  Rec=Rec/nfolds
  Rec=cbind(Rec,grid.cv)
  names(Rec)[1:3]=c("Misclass","Eps","Para")
  id=which.min(Rec$Misclass)
  print(Rec[id,])
  misclass_min=Rec$Misclass[id]
  if (dim(Rec)[2]>=4) sigma=Rec[id,4]
  # independent test
  fit <- dc_loop(input=train,Eps = Rec[id,2],alpha = 0.5,lambda=grid.cv[id,2], method=method,sigma.v = sigma.v, pred_old=pred_old,
                 weights = weights.train)
  tmp.pred <- predict.dose(fit,test)
  #tmptest <- data.frame(A= test$A, X=test$X)
  #W3 <- weightit(A ~ ., data = tmptest, method = "ebal")
  testloss <- measurement(tmp.pred,test,lower=TRUE)
  output <- list(measures=testloss,fit=fit,Rec=Rec,bestPara=Rec[id,3],pred=tmp.pred)
  return(output)
}

#train <- Scenario1.continuous.prognostic(500,10,1000,aL=-2,aU=2)
#test <- Scenario1.continuous.prognostic(5000,10,2000,aL=-2,aU=2)
#s2_result <- cv.doseInt(train,test=test,method="L-O-Learning")

