import numpy as np
# import time

##############################################################################
#ETC Normal Rewards
# start = time.time()
sample = 1000
T = 100
m = 10
# mu = np.array([1,1.5]) #normal mean
# sigma = np.array([1,1])
mu = np.array([2,2.5,3,3.5]) #normal mean
sigma = np.array([2,1,1,2])
K = mu.size

muhat11 = np.zeros([K,sample])
error11 = np.zeros([K,sample])
R = np.zeros([sample,T])
I = np.zeros([sample,T])
   
mutemp = np.zeros([sample,K])       
for s in range(sample):  
    for i in range(K):
        I[s, i*m:(i+1)*m] = i
        R[s, i*m:(i+1)*m] = np.random.normal(mu[i],sigma[i],m)
        mutemp[s,i] = np.mean(R[s, i*m:(i+1)*m])
    opt = np.argmax(mutemp[s,:])
    I[s, K*m:] = opt
    R[s, K*m:] = np.random.normal(mu[opt],sigma[opt],T-K*m) 
    
    for i in range(K):       
        if i == opt:
            muhat11[i,s] = (mutemp[s,i]*m+np.sum(R[s, K*m:]))/(T-(K-1)*m)
        else:                 
            muhat11[i,s] = mutemp[s,i]
    error11[:,s] = muhat11[:, s] - mu    
          
bias11 = np.mean(error11, axis=1)  
print('bias is', np.round(bias11,4)) 
print('muhat is', np.round(np.mean(muhat11, axis=1),4))
# np.save('bias11.npy', bias11)
# np.save('muhat11.npy', muhat11)
# np.save('R11.npy', R)
# np.save('I11.npy', I)
# np.savetxt('bias11.dat',np.transpose(bias11.reshape(2,1)),header='arm1,arm2',delimiter=',',newline='\n')
# np.savetxt('muhat11.dat',np.transpose(muhat11),header='arm1,arm2',delimiter=',',newline='\n')
np.save('mulbias11.npy', bias11)
np.save('mulmuhat11.npy', muhat11)
np.save('mulR11.npy', R)
np.save('mulI11.npy', I)
np.savetxt('mulbias11.dat',np.transpose(bias11.reshape(4,1)),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')
np.savetxt('mulmuhat11.dat',np.transpose(muhat11),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')
 
##############################################################################
#MB
muhatmb11 = np.zeros([K,sample])
errormb11 = np.zeros([K,sample])
B = 1000

for s in range(sample):
    # print('MB normal sample is', s+1) 
    muboots = np.zeros([K,B])
    Rmb = np.zeros([B,T])
    Imb = np.zeros([B,T])
    mutemp = np.zeros([B,K])    
    for b in range(B): 
        for i in range(K):
            Imb[b, i*m:(i+1)*m] = i
            W = np.random.normal(0,1,size=(m,np.where(I[s]==i)[0].size))
            Rmb[b, i*m:(i+1)*m] = np.dot(W, R[s][I[s]==i]-np.mean(R[s][I[s]==i]))/np.sqrt(np.where(I[s]==i)[0].size)+np.mean(R[s][I[s]==i])
            mutemp[b,i] = np.mean(Rmb[b, i*m:(i+1)*m])
        opt = np.argmax(mutemp[b,:])
        Imb[b, K*m:] = opt
        W = np.random.normal(0,1,size=(T-K*m,np.where(I[s]==opt)[0].size))
        Rmb[b, K*m:] = np.dot(W, R[s][I[s]==opt]-np.mean(R[s][I[s]==opt]))/np.sqrt(np.where(I[s]==opt)[0].size)+np.mean(R[s][I[s]==opt])
        
        for i in range(K):       
            if i == opt:
                muboots[i,b] = (mutemp[b,i]*m+np.sum(Rmb[b, K*m:]))/(T-(K-1)*m)
            else:                 
                muboots[i,b] = mutemp[b,i]
        muhatmb11[:,s] = np.mean(muboots,axis = 1)        
errormb11 = muhatmb11 - muhat11
biasmb11 = np.mean(errormb11, axis=1)  
muhatmb11 = muhat11 - errormb11 
print('biasmb is', np.round(biasmb11,4))
print('muhatmb is', np.round(np.mean(muhatmb11, axis=1),5))
# np.save('biasmb11.npy', biasmb11)
# np.save('muhatmb11.npy', muhatmb11)
# np.savetxt('biasmb11.dat',np.transpose(biasmb11.reshape(2,1)),header='arm1,arm2',delimiter=',',newline='\n')
# np.savetxt('muhatmb11.dat',np.transpose(muhatmb11),header='arm1,arm2',delimiter=',',newline='\n')
np.save('mulbiasmb11.npy', biasmb11)
np.save('mulmuhatmb11.npy', muhatmb11)
np.savetxt('mulbiasmb11.dat',np.transpose(biasmb11.reshape(4,1)),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')
np.savetxt('mulmuhatmb11.dat',np.transpose(muhatmb11),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')



##############################################################################
#EB
muhateb11 = np.zeros([K,sample])
erroreb11 = np.zeros([K,sample])
B = 1000

for s in range(sample):  
    print('EB normal sample is', s+1)
    muboots = np.zeros([K,B])
    Reb = np.zeros([B,T])
    Ieb = np.zeros([B,T])
    mutemp = np.zeros([B,K])
    
    for i in range(K):
        locals()['Runiq'+str(i)]  = np.unique(R[s][I[s]==i])
        locals()['P'+str(i)] = np.zeros(locals()['Runiq'+str(i)].size)
        for j in range(locals()['Runiq'+str(i)].size):
            locals()['P'+str(i)][j] = np.where(R[s][I[s]==i]==locals()['Runiq'+str(i)][j])[0].size/np.where(I[s]==i)[0].size
    
    Rset = np.zeros([K,B,T])
    for i in range(K):
        Rset[i] = np.random.choice(locals()['Runiq'+str(i)], size=(B,T), p=locals()['P'+str(i)])
        # Rset[i] = np.random.choice(R[s][I[s]==i], size=(B,T), replace=True)
    
    for b in range(B):
        for i in range(K):          
            mutemp[b,i] = np.mean(Rset[i,b,i*m:(i+1)*m])
        opt = np.argmax(mutemp[b,:])    
        
        for i in range(K):
            if i == opt:
                muboots[i,b] = (mutemp[b,i]*m+np.sum(Rset[i, b, K*m:]))/(T-(K-1)*m)
            else:                 
                muboots[i,b] = mutemp[b,i]
        muhateb11[:,s] = np.mean(muboots,axis = 1)        
erroreb11 = muhateb11 - muhat11
biaseb11 = np.mean(erroreb11, axis=1)  
muhateb11 = muhat11 - erroreb11 
print('biaseb is', np.round(biaseb11,4))
print('muhateb is', np.round(np.mean(muhateb11, axis=1),4))
# np.save('biaseb11.npy', biaseb11)
# np.save('muhateb11.npy', muhateb11)
# np.savetxt('biaseb11.dat',np.transpose(biaseb11.reshape(2,1)),header='arm1,arm2',delimiter=',',newline='\n')
# np.savetxt('muhateb11.dat',np.transpose(muhateb11),header='arm1,arm2',delimiter=',',newline='\n')
np.save('mulbiaseb11.npy', biaseb11)
np.save('mulmuhateb11.npy', muhateb11)
np.savetxt('mulbiaseb11.dat',np.transpose(biaseb11.reshape(4,1)),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')
np.savetxt('mulmuhateb11.dat',np.transpose(muhateb11),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')


##############################################################################
#ETC Bernoulli Rewards
sample = 1000
T = 100
m = 10
# mu = np.array([0.3, 0.6]) #bernoulli mean
mu = np.array([0.4, 0.5, 0.7, 0.8]) #bernoulli mean
K = mu.size

muhat12 = np.zeros([K,sample])
error12 = np.zeros([K,sample])
R = np.zeros([sample,T])
I = np.zeros([sample,T])
   
mutemp = np.zeros([sample,K])       
for s in range(sample):  
    for i in range(K):
        I[s, i*m:(i+1)*m] = i
        R[s, i*m:(i+1)*m] = np.random.binomial(1, mu[i], m)
        mutemp[s,i] = np.mean(R[s, i*m:(i+1)*m])
    opt = np.argmax(mutemp[s,:])
    I[s, K*m:] = opt
    R[s, K*m:] = np.random.binomial(1, mu[opt], T-K*m)
    
    for i in range(K):       
        if i == opt:
            muhat12[i,s] = (mutemp[s,i]*m+np.sum(R[s, K*m:]))/(T-(K-1)*m)
        else:                 
            muhat12[i,s] = mutemp[s,i]
    error12[:,s] = muhat12[:, s] - mu    
          
bias12 = np.mean(error12, axis=1)  
print('bias is', np.round(bias12,4)) 
print('muhat is', np.round(np.mean(muhat12, axis=1),4))
# np.save('bias12.npy', bias12)
# np.save('muhat12.npy', muhat12)
# np.save('R12.npy', R)
# np.save('I12.npy', I)
# np.savetxt('bias12.dat',np.transpose(bias12.reshape(2,1)),header='arm1,arm2',delimiter=',',newline='\n')
# np.savetxt('muhat12.dat',np.transpose(muhat12),header='arm1,arm2',delimiter=',',newline='\n')
np.save('mulbias12.npy', bias12)
np.save('mulmuhat12.npy', muhat12)
np.save('mulR12.npy', R)
np.save('mulI12.npy', I)
np.savetxt('mulbias12.dat',np.transpose(bias12.reshape(4,1)),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')
np.savetxt('mulmuhat12.dat',np.transpose(muhat12),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')


############################################################################### 
#MB
muhatmb12 = np.zeros([K,sample])
errormb12 = np.zeros([K,sample])
B = 1000

for s in range(sample):
    print('MB bernoulli sample is', s+1) 
    muboots = np.zeros([K,B])
    Rmb = np.zeros([B,T])
    Imb = np.zeros([B,T])
    mutemp = np.zeros([B,K])   
    for b in range(B):
        for i in range(K):
            Imb[b, i*m:(i+1)*m] = i
            W = np.random.normal(0,1,size=(m,np.where(I[s]==i)[0].size))
            Rmb[b, i*m:(i+1)*m] = np.dot(W, R[s][I[s]==i]-np.mean(R[s][I[s]==i]))/np.sqrt(np.where(I[s]==i)[0].size)+np.mean(R[s][I[s]==i])
            mutemp[b,i] = np.mean(Rmb[b, i*m:(i+1)*m])
        opt = np.argmax(mutemp[b,:])
        Imb[b, K*m:] = opt
        W = np.random.normal(0,1,size=(T-K*m,np.where(I[s]==opt)[0].size))
        Rmb[b, K*m:] = np.dot(W, R[s][I[s]==opt]-np.mean(R[s][I[s]==opt]))/np.sqrt(np.where(I[s]==opt)[0].size)+np.mean(R[s][I[s]==opt])
        
        for i in range(K):       
            if i == opt:
                muboots[i,b] = (mutemp[b,i]*m+np.sum(Rmb[b, K*m:]))/(T-(K-1)*m)
            else:                 
                muboots[i,b] = mutemp[b,i]
        muhatmb12[:,s] = np.mean(muboots,axis = 1)        
errormb12 = muhatmb12 - muhat12
biasmb12 = np.mean(errormb12, axis=1)  
muhatmb12 = muhat12 - errormb12
print('biasmb is', np.round(biasmb12,4))
print('muhatmb is', np.round(np.mean(muhatmb12, axis=1),4))
# np.save('biasmb12.npy', biasmb12)
# np.save('muhatmb12.npy', muhatmb12)
# np.savetxt('biasmb12.dat',np.transpose(biasmb12.reshape(2,1)),header='arm1,arm2',delimiter=',',newline='\n')
# np.savetxt('muhatmb12.dat',np.transpose(muhatmb12),header='arm1,arm2',delimiter=',',newline='\n')
np.save('mulbiasmb12.npy', biasmb12)
np.save('mulmuhatmb12.npy', muhatmb12)
np.savetxt('mulbiasmb12.dat',np.transpose(biasmb12.reshape(4,1)),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')
np.savetxt('mulmuhatmb12.dat',np.transpose(muhatmb12),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')


##############################################################################
#EB
muhateb12 = np.zeros([K,sample])
erroreb12 = np.zeros([K,sample])
B = 1000

for s in range(sample):  
    print('EB bernoulli sample is', s+1)
    muboots = np.zeros([K,B])
    Reb = np.zeros([B,T])
    Ieb = np.zeros([B,T])
    mutemp = np.zeros([B,K])
    
    for i in range(K):
        locals()['Runiq'+str(i)]  = np.unique(R[s][I[s]==i])
        locals()['P'+str(i)] = np.zeros(locals()['Runiq'+str(i)].size)
        for j in range(locals()['Runiq'+str(i)].size):
            locals()['P'+str(i)][j] = np.where(R[s][I[s]==i]==locals()['Runiq'+str(i)][j])[0].size/np.where(I[s]==i)[0].size
    
    Rset = np.zeros([K,B,T])
    muraw = np.zeros([B,K])
    for i in range(K):
        Rset[i] = np.random.choice(locals()['Runiq'+str(i)], size=(B,T), p=locals()['P'+str(i)])
        # Rset[i] = np.random.choice(R[s][I[s]==i], size=(B,T), replace=True)
    
    for b in range(B):
        for i in range(K):          
            mutemp[b,i] = np.mean(Rset[i,b,i*m:(i+1)*m])
        opt = np.argmax(mutemp[b,:])    
        
        for i in range(K):
            if i == opt:
                muboots[i,b] = (mutemp[b,i]*m+np.sum(Rset[i, b, K*m:]))/(T-(K-1)*m)
            else:                 
                muboots[i,b] = mutemp[b,i]
        muhateb12[:,s] = np.mean(muboots,axis = 1)        
erroreb12 = muhateb12 - muhat12
biaseb12 = np.mean(erroreb12, axis=1)  
muhateb12 = muhat12 - erroreb12 
print('biaseb is', np.round(biaseb12,4))
print('muhateb is', np.round(np.mean(muhateb12, axis=1),4))
# np.save('biaseb12.npy', biaseb12)
# np.save('muhateb12.npy', muhateb12)
# np.savetxt('biaseb12.dat',np.transpose(biaseb12.reshape(2,1)),header='arm1,arm2',delimiter=',',newline='\n')
# np.savetxt('muhateb12.dat',np.transpose(muhateb12),header='arm1,arm2',delimiter=',',newline='\n')
np.save('mulbiaseb12.npy', biaseb12)
np.save('mulmuhateb12.npy', muhateb12)
np.savetxt('mulbiaseb12.dat',np.transpose(biaseb12.reshape(4,1)),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')
np.savetxt('mulmuhateb12.dat',np.transpose(muhateb12),header='arm1,arm2,arm3,arm4',delimiter=',',newline='\n')


# # end = time.time()
# # print(end-start)

