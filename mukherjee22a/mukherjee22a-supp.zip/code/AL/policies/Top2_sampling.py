

import sys
sys.path.append("..")

from util.check_stop_time import check_stop_time
from util.update_log_L import update_log_L
from util.sample_source import sample_source

from environment.Discrete_env import Discrete_env

import numpy as np

class Top2_Sampling(object):
    
    '''
    classdocs
    '''
    
    num_sources = 0
    num_hypo = 0
    mu = None
    
    def __init__(self, env):
        '''
        Constructor
        '''
        self.num_hypo = env.num_hypo
        self.num_sources = env.num_sources
        self.mu = env.mu
        self.sig = env.sig
        self.env = env
        self.trials = env.trials
        self.T = env.T
        self.jstar = env.jstar
        self.best_arm = env.best_arm
        
        
        self.top2_err = []
        self.top2_num = []
        #pre calculate chernoff sampling proportions
        

        self.top2_sample_complexity = np.zeros((self.trials, self.num_sources))

    
    
    def run_Top2_Sampling(self):
        
        print("\n Top2")
        for tr in range(self.trials): 
    
            self.top2_L = np.zeros(self.num_hypo)
            self.tr_top2_err = np.zeros(self.T)
    
            np.random.seed(tr)
    
            self.tr_top2_num = np.zeros(self.num_sources)
    
            for t in range(self.T):



                if check_stop_time(self.top2_L, self.num_hypo) == False:
                          
                    # do top2 likelihood sampling
                    top2_hypos = np.argsort(self.top2_L)[-2:]
                    #top2_top_hypo.append(top2_hypos[1])
                    # idx = np.argmax(np.abs(mu[:, top2_hypos[1]] - mu[:, top2_hypos[0]]))
                    top2_diff = np.abs(self.mu[:, top2_hypos[1]] - self.mu[:, top2_hypos[0]])
                    idx = np.random.choice([a for a in range(self.num_sources) if top2_diff[a] == max(top2_diff)])
                    self.tr_top2_num[idx] += 1  # recording number of pulls
                
                    val = sample_source(idx, self.mu, self.sig, self.jstar)
                    update_log_L(self.top2_L, self.mu, self.sig, idx, val)
                    top2_hypo_hat = np.random.choice([h for h in range(self.num_hypo) if self.top2_L[h] == max(self.top2_L)])
                    #tr_top2_err[t] += int(top2_hypo_hat != jstar)
                    top2_best_arm_hat = np.argmax(np.array(self.mu[:,top2_hypo_hat]))
                    self.tr_top2_err[t] += int(top2_best_arm_hat != self.best_arm)
                
                    self.top2_sample_complexity[tr][idx] += 1
                    
                    
            self.top2_err.append(self.tr_top2_err)
    
            self.top2_num.append(self.tr_top2_num)
            
            print(tr, end=', ')
            if tr % 100 == 0:
                print()
            