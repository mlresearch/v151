import torch 
import torch.nn as nn 
import torch.nn.functional as F 
from torch.utils.data import Dataset, DataLoader, TensorDataset
import torch.optim as optim
from collections import OrderedDict

class Toy2D_Dis_tiny(nn.Module): 
    def __init__(self, num_classes=3): 
        super(Toy2D_Dis_tiny, self).__init__()
        self.l1 = nn.Linear(2, 2)
        self.l4A = nn.Linear(2, 1)
        self.l4B = nn.Linear(2, num_classes)
    
    def forward(self, input, targets=None): 
        h = F.relu(self.l1(input))
        logits_A = self.l4A(h)
        logits_B = self.l4B(h)

        return torch.sigmoid(logits_A), logits_B

class Toy2D_Dis(nn.Module): 
    def __init__(self, num_classes=3): 
        super(Toy2D_Dis, self).__init__()
        self.l1 = nn.Linear(2, 10)
        self.l2 = nn.Linear(10, 2)
        self.l4A = nn.Linear(2, 1)
        self.l4B = nn.Linear(2, num_classes)
    
    def forward(self, input, targets=None): 
        h = F.relu(self.l1(input))
        h = F.relu(self.l2(h))
        logits_A = self.l4A(h)
        logits_B = self.l4B(h)

        return torch.sigmoid(logits_A), logits_B

class Toy2D_Dis_big(nn.Module): 
    def __init__(self, num_classes=3): 
        super(Toy2D_Dis_big, self).__init__()
        self.l1 = nn.Linear(2, 10)
        self.l2 = nn.Linear(10, 10)
        self.l3 = nn.Linear(10, 2)
        self.l4A = nn.Linear(2, 1)
        self.l4B = nn.Linear(2, num_classes)
    
    def forward(self, input, targets=None): 
        h = F.relu(self.l1(input))
        h = F.relu(self.l2(h))
        h = F.relu(self.l3(h))
        logits_A = self.l4A(h)
        logits_B = self.l4B(h)

        return torch.sigmoid(logits_A), logits_B

class Mnist_Dis(nn.Module):
    def __init__(self, activation=nn.ReLU(), drop=0.5):
        super(Mnist_Dis, self).__init__()

        self.num_channels = 1
        self.num_labels = 10
        self.num_manifold = 1

        self.feature_extractor = nn.Sequential(OrderedDict([
            ('conv1', nn.Conv2d(self.num_channels, 32, 3)),
            ('relu1', activation),
            ('conv2', nn.Conv2d(32, 32, 3)),
            ('relu2', activation),
            ('maxpool1', nn.MaxPool2d(2, 2)), # [14,14]
            ('conv3', nn.Conv2d(32, 64, 3)),
            ('relu3', activation),
            ('conv4', nn.Conv2d(64, 64, 3)),
            ('relu4', activation),
            ('maxpool2', nn.MaxPool2d(2, 2)), # [4, 4]
        ]))

        self.classifier = nn.Sequential(OrderedDict([
            ('fc1', nn.Linear(64 * 4 * 4, 200)),
            ('relu1', activation),
            ('drop', nn.Dropout(drop)),
            ('fc2', nn.Linear(200, 200)),
            ('relu2', activation),
            # ('fc3', nn.Linear(200, self.num_labels)),
        ]))

        self.fc3A = nn.Linear(200, self.num_manifold)
        self.fc3B = nn.Linear(200, self.num_labels)

        for m in self.modules():
            if isinstance(m, (nn.Conv2d)):
                nn.init.kaiming_normal_(m.weight)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)


    def forward(self, input, targets=None):
        features = self.feature_extractor(input)
        z = features.view(-1, 64 * 4 * 4)
        h = self.classifier(z)
        logits_A = self.fc3A(h)
        logits_B = self.fc3B(h)
        return torch.sigmoid(logits_A), logits_B


class Cifar10_Dis(nn.Module):
    def __init__(self, activation=nn.ReLU(), drop=0.5):
        super(Cifar10_Dis, self).__init__()

        self.num_channels = 3
        self.num_labels = 10
        self.num_manifold = 1

        self.feature_extractor = nn.Sequential(OrderedDict([
            ('conv1', nn.Conv2d(self.num_channels, 64, 3)),
            ('relu1', activation),
            ('conv2', nn.Conv2d(64, 64, 3)),
            ('relu2', activation),
            ('maxpool1', nn.MaxPool2d(2, 2)),
            ('conv3', nn.Conv2d(64, 128, 3)),
            ('relu3', activation),
            ('conv4', nn.Conv2d(128, 128, 3)),
            ('relu4', activation),
            ('maxpool2', nn.MaxPool2d(2, 2)),
        ]))

        self.classifier = nn.Sequential(OrderedDict([
            ('fc1', nn.Linear(128 * 3 * 3, 256)),
            ('relu1', activation),
            ('drop', nn.Dropout(drop)),
            ('fc2', nn.Linear(256, 256)),
            ('relu2', activation),
            # ('fc3', nn.Linear(256, self.num_labels)),
        ]))

        self.fc3A = nn.Linear(256, self.num_manifold)
        self.fc3B = nn.Linear(256, self.num_labels)

        for m in self.modules():
            if isinstance(m, (nn.Conv2d)):
                nn.init.kaiming_normal_(m.weight)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)


    def forward(self, input, targets=None):
        features = self.feature_extractor(input)
        # print('features_shape:',features.shape)
        z = features.view(-1, 128 * 3 * 3)
        h = self.classifier(z)
        logits_A = self.fc3A(h)
        logits_B = self.fc3B(h)
        return torch.sigmoid(logits_A), logits_B


class Cifar100_Dis(nn.Module):
    def __init__(self, activation=nn.ReLU(), drop=0.5):
        super(Cifar100_Dis, self).__init__()

        self.num_channels = 3
        self.num_labels = 100
        self.num_manifold = 1 

        self.feature_extractor = nn.Sequential(OrderedDict([
            ('conv1', nn.Conv2d(self.num_channels, 64, 3)),
            ('relu1', activation),
            ('conv2', nn.Conv2d(64, 64, 3)),
            ('relu2', activation),
            ('conv3', nn.Conv2d(64, 64, 3)),
            ('relu3', activation),
            ('maxpool1', nn.MaxPool2d(2, 2)),
            ('conv4', nn.Conv2d(64, 128, 3)),
            ('relu4', activation),
            ('conv5', nn.Conv2d(128, 128, 3)),
            ('relu5', activation),
            ('conv6', nn.Conv2d(128, 128, 3)),
            ('relu6', activation),
            ('maxpool2', nn.MaxPool2d(2, 2)),
        ]))

        self.classifier = nn.Sequential(OrderedDict([
            ('fc1', nn.Linear(128 * 3 * 3, 256)),
            ('relu1', activation),
            ('drop', nn.Dropout(drop)),
            ('fc2', nn.Linear(256, 256)),
            ('relu2', activation),
            ('fc3', nn.Linear(256, 256)),
            ('relu3', activation),
            # ('fc4', nn.Linear(256, self.num_labels)),
        ]))

        for m in self.modules():
            if isinstance(m, (nn.Conv2d)):
                nn.init.kaiming_normal_(m.weight)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

        self.fc4A = nn.Linear(256, self.num_manifold)
        self.fc4B = nn.Linear(256, self.num_labels)

    def forward(self, input, targets=None):
        features = self.feature_extractor(input)
        # print('features_shape:',features.shape)
        z = features.view(-1, 128 * 3 * 3)
        h = self.classifier(z)
        logits_A = self.fc4A(h)
        logits_B = self.fc4B(h)
        return torch.sigmoid(logits_A), logits_B


class Disc_FC(nn.Module):
    '''
        Discriminator which outputs 2 vectors: 
            vector A: manifold vector (dim=1 if method=LMAE, dim=nun_classes if our method) --> sigmoid 
            vector B: classification vector (dim=num_classes) --> logits 

    '''
    def __init__(self, activation=nn.ReLU(), num_manifold=10, num_classes=10, in_features=256, num_hidden=256):
        super(Disc_FC, self).__init__()

        self.in_features = in_features
        self.num_classes = num_classes
        self.num_manifold = num_manifold

        self.fc1 = nn.Linear(self.in_features, num_hidden*2)
        self.fc2 = nn.Linear(num_hidden*2, num_hidden)
        self.fc3A = nn.Linear(num_hidden, self.num_manifold)
        self.fc3B = nn.Linear(num_hidden, self.num_classes)
        self.act = activation

    def forward(self, input, targets=None):
        # del targets

        h = self.act(self.fc1(input))
        h = self.act(self.fc2(h))
        logits_A = self.fc3A(h)
        logits_B = self.fc3B(h)

        return torch.sigmoid(logits_A), logits_B


class Disc_FC_with_labels(nn.Module):
    '''
        Discriminator which outputs 2 vectors: 
            vector A: manifold vector (dim=1 if method=LMAE, dim=nun_classes if our method) --> sigmoid 
            vector B: classification vector (dim=num_classes) --> logits 

    '''
    def __init__(self, activation=nn.ReLU(), num_manifold=10, num_classes=10, in_features=256, num_hidden=256):
        super(Disc_FC_with_labels, self).__init__()

        del num_manifold 
        print('--- IGNORE num_manifold, always use num_manifold=1 ---')

        self.in_features = in_features
        self.num_classes = num_classes
        self.num_manifold = 1

        self.fc1 = nn.Linear(self.in_features, num_hidden*2)
        self.fc2 = nn.Linear(num_hidden*2, num_hidden)
        self.embed = nn.Embedding(num_embeddings=num_classes, embedding_dim=num_hidden)

        self.fc3A = nn.Linear(num_hidden*2, num_hidden//2)
        self.fc3B = nn.Linear(num_hidden, self.num_classes)

        self.fc4A = nn.Linear(num_hidden//2, self.num_manifold)

        self.act = activation

    def forward(self, input, targets):
        h = self.act(self.fc1(input))
        h = self.act(self.fc2(h))

        embed = self.embed(targets)

        h_A = self.act(self.fc3A(torch.cat((h, embed),dim=-1)))
        logits_A = self.fc4A(h_A)
        
        logits_B = self.fc3B(h)

        return torch.sigmoid(logits_A), logits_B
