"""Toy dataset generators.
"""
import os
import ipdb
import math
import random
import itertools
import numpy as np

import matplotlib.pyplot as plt

import torch


def sample_grid_gaussians(n_samples, num_components=25, label=None):
    z = torch.randn(n_samples, 2)

    centers = [np.array([i, j]) for i, j in itertools.product(range(-4, 5, 2), range(-4, 5, 2))]
    centers = torch.from_numpy(np.array(centers).astype('float32'))

    # std = 0.05
    std = 0.1

    if label is not None:
        labels = torch.LongTensor([random.choice(label) for _ in range(n_samples)])
    else:
        labels = torch.randint(len(centers), size=(n_samples,)).long()

    return (std * z + centers[labels]), labels


def sample_gaussians(n_samples, num_gaussians=8, label=None, std=0.4, scale=4):
    z = torch.randn(n_samples, 2)

    centers = []
    for i in range(num_gaussians):
        angle = i * 2 * np.pi / num_gaussians
        centers.append((scale * np.cos(angle), scale * np.sin(angle)))
    centers = torch.from_numpy(np.array(centers).astype('float32'))

    if label is not None:
        labels = torch.LongTensor([random.choice(label) for _ in range(n_samples)])
        # labels = (torch.ones(n_samples) * label).long()
    else:
        labels = torch.randint(len(centers), size=(n_samples,)).long()

    # return sq2 * (0.5 * z + centers[labels]), labels
    return (std * z + centers[labels]), labels


def sample_spirals(n_samples):
    z = torch.randn(n_samples, 2)
    n = torch.sqrt(torch.rand(n_samples // 2)) * 540 * (2 * math.pi) / 360
    d1x = - torch.cos(n) * n + torch.rand(n_samples // 2) * 0.5
    d1y =   torch.sin(n) * n + torch.rand(n_samples // 2) * 0.5
    x = torch.cat([torch.stack([ d1x,  d1y], dim=1),
                   torch.stack([-d1x, -d1y], dim=1)], dim=0) / 3
    return x + 0.1*z, None


def sample_checkerboard(n_samples):
    x1 = torch.rand(n_samples) * 4 - 2
    x2_ = torch.rand(n_samples) - torch.randint(0, 2, (n_samples,), dtype=torch.float) * 2
    x2 = x2_ + x1.floor() % 2
    return torch.stack([x1, x2], dim=1) * 2, None


def sample_rings(n_samples):
    n_samples4 = n_samples3 = n_samples2 = n_samples // 4
    n_samples1 = n_samples - n_samples4 - n_samples3 - n_samples2

    # so as not to have the first point = last point, set endpoint=False in np; here shifted by one
    linspace4 = torch.linspace(0, 2 * math.pi, n_samples4 + 1)[:-1]
    linspace3 = torch.linspace(0, 2 * math.pi, n_samples3 + 1)[:-1]
    linspace2 = torch.linspace(0, 2 * math.pi, n_samples2 + 1)[:-1]
    linspace1 = torch.linspace(0, 2 * math.pi, n_samples1 + 1)[:-1]

    circ4_x = torch.cos(linspace4)
    circ4_y = torch.sin(linspace4)

    circ3_x = torch.cos(linspace4) * 0.75
    circ3_y = torch.sin(linspace3) * 0.75

    circ2_x = torch.cos(linspace2) * 0.5
    circ2_y = torch.sin(linspace2) * 0.5

    circ1_x = torch.cos(linspace1) * 0.25
    circ1_y = torch.sin(linspace1) * 0.25

    x = torch.stack([torch.cat([circ4_x, circ3_x, circ2_x, circ1_x]),
                     torch.cat([circ4_y, circ3_y, circ2_y, circ1_y])], dim=1) * 3.0

    # random sample
    x = x[torch.randint(0, n_samples, size=(n_samples,)).long()]

    # Add noise
    return x + torch.normal(mean=torch.zeros_like(x), std=0.08*torch.ones_like(x)), None


if __name__ == '__main__':

    if not os.path.exists('toy_plots'):
        os.makedirs('toy_plots')

    # x, labels = sample_gaussians(100000, num_gaussians=10, label=[1,2,3])
    x, labels = sample_gaussians(100000, num_gaussians=10)
    n_pts = 1000
    range_lim = 6
    x = x.numpy()
    plt.figure()
    plt.hist2d(x[:,0], x[:,1], range=[[-range_lim, range_lim], [-range_lim, range_lim]], bins=n_pts, cmap=plt.cm.jet)
    plt.tight_layout()
    plt.savefig('toy_plots/gaussians.png', bbox_inches='tight', pad_inches=0)

    x, labels = sample_checkerboard(100000)
    n_pts = 1000
    range_lim = 4
    x = x.numpy()
    plt.figure()
    plt.hist2d(x[:,0], x[:,1], range=[[-range_lim, range_lim], [-range_lim, range_lim]], bins=n_pts, cmap=plt.cm.jet)
    plt.tight_layout()
    plt.savefig('toy_plots/checkerboard.png', bbox_inches='tight', pad_inches=0)

    x, labels = sample_spirals(100000)
    n_pts = 1000
    range_lim = 4
    x = x.numpy()
    plt.figure()
    plt.hist2d(x[:,0], x[:,1], range=[[-range_lim, range_lim], [-range_lim, range_lim]], bins=n_pts, cmap=plt.cm.jet)
    plt.tight_layout()
    plt.savefig('toy_plots/spirals.png', bbox_inches='tight', pad_inches=0)

    x, labels = sample_rings(100000)
    n_pts = 1000
    range_lim = 4
    x = x.numpy()
    plt.figure()
    plt.hist2d(x[:,0], x[:,1], range=[[-range_lim, range_lim], [-range_lim, range_lim]], bins=n_pts, cmap=plt.cm.jet)
    plt.tight_layout()
    plt.savefig('toy_plots/rings.png', bbox_inches='tight', pad_inches=0)

    # x, labels = sample_grid_gaussians(100000, label=list(set(list(range(25))) - set([5,6])))
    x, labels = sample_grid_gaussians(100000)
    n_pts = 1000
    range_lim = 4
    x = x.numpy()
    plt.figure()
    plt.hist2d(x[:,0], x[:,1], range=[[-range_lim, range_lim], [-range_lim, range_lim]], bins=n_pts, cmap=plt.cm.jet)
    plt.tight_layout()
    plt.savefig('toy_plots/grid.png', bbox_inches='tight', pad_inches=0)
