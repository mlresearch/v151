from gpytorch.kernels import RBFKernel
import torch
from PreferentialGP.utility import train_test_split
import numpy as np


class PreferentialGP(object):

    def __init__(self, comp_ls, y_ls, phi):
        self.comp_ls = comp_ls
        self.y_ls = y_ls
        self.phi = phi
        self.kernel = RBFKernel()
        self.kernel.lengthscale = 2
        self.C = train_test_split(comp_ls, 1.)[0]

    def fit(self, epoch=10000, lr=1e-3):

        features = torch.tensor(self.phi)
        K_np = self.kernel(features).evaluate().detach().numpy()
        K = torch.tensor(K_np).float()
        self.K = K

        K_inv = torch.tensor(np.linalg.inv(K_np + 0.001 * np.eye(K_np.shape[0]))).float()

        #K_inv = torch.inverse(K).float()
        self.K_inv = K_inv

        # Setup GP
        y_tensor = torch.tensor(self.y_ls).reshape(-1, 1).float()
        sigma = torch.nn.Sigmoid()

        p = K_inv.shape[0]
        f = torch.randn(p, 1, requires_grad=True).float()
        e_vec = torch.ones_like(f)

        # Compute f_map
        for rd in range(epoch):
            f_diff = f @ e_vec.t() - e_vec @ f.t()
            smoothness = 0.5 * (f.t()@(K_inv) @f).float()
            likelihood = torch.sum(
                torch.log(sigma(torch.tensor(self.C) * f_diff)))

            L = smoothness - likelihood
            L.backward()

            with torch.no_grad():
                f -= f.grad * lr
                f.grad.zero_()

        # Compute the mll
        f_map = f.detach()
        f_diff = f @ e_vec.t() - e_vec @ f.t()
        smoothness = 0.5 * (f_map.t()@(K_inv) @f_map).float()
        likelihood = torch.sum(
            torch.log(sigma(torch.tensor(self.C) * f_diff)))
        component1 = sigma(torch.tensor(self.C) * f_diff)
        component2 = sigma(-torch.tensor(self.C) * f_diff)
        W = (component1 * component2).float()

        B = torch.eye(W.shape[0]) + self.K @ W

        marginallikelihood = -smoothness + likelihood -0.5 * torch.log(torch.det(B))
        self.mll = marginallikelihood

        self.posterior_mean = f_map
