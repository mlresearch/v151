from typing import List
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from decomp_gen.models.decomp_tree_encoder import TreeEncoder
from decomp_gen.models.gat import GAT
from decomp_gen.models.mlp import Mlp
from decomp_gen.models.nnutils import graphs_batch_offsets

from dgl import batch
from dgl import DGLGraph

import gc

NUM_HEADS = 1

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

class NodeAdding(nn.Module):
    def __init__(self,
                 max_cluster_size,
                 max_graph_size,
                 tree_hidden_dim,
                 gat_hidden_dim,
                 gat_num_layers,
                 node_feat_dim,
                 mlp_hidden_dim
                 ):
        super(NodeAdding, self).__init__()

        self.C = max_cluster_size
        self.N = max_graph_size  # max number of nodes
        self.tree_hidden_dim = tree_hidden_dim
        self.gat_hidden_dim = gat_hidden_dim
        self.gat_num_layers = gat_num_layers
        self.node_feat_dim = node_feat_dim

        self.tree_encoder = TreeEncoder(self.tree_hidden_dim, self.N)

        # This only applies to a single node at a time (not the entire A)
        self.dimension_reductor = nn.Linear(self.N, self.node_feat_dim)

        self.gat = GAT(
            num_layers=self.gat_num_layers,
            in_dim=self.node_feat_dim,
            num_hidden=self.gat_hidden_dim,
            num_output=self.gat_hidden_dim,
            heads=[NUM_HEADS] * self.gat_num_layers,
            activation=F.elu,
            feat_drop=0,
            attn_drop=0,
            negative_slope=0.2,
            residual=False
        )

        self.mlp_node_input_size = self.gat_hidden_dim + 2 * self.tree_hidden_dim
        self.mlp_node = nn.Sequential(
                nn.Linear(self.mlp_node_input_size, mlp_hidden_dim),
                nn.ReLU(),
                nn.Linear(mlp_hidden_dim, mlp_hidden_dim//2),
                nn.ReLU(),
                nn.Linear(mlp_hidden_dim//2,1),
                nn.Sigmoid())

        self.mlp_edge_input_size = 3 * self.gat_hidden_dim + 2 * self.tree_hidden_dim + 3 * self.C
        self.mlp_edge = nn.Sequential(
            nn.Linear(self.mlp_edge_input_size, mlp_hidden_dim),
            nn.ReLU(),
            nn.Linear(mlp_hidden_dim, mlp_hidden_dim // 2),
            nn.ReLU(),
            nn.Linear(mlp_hidden_dim // 2, 1),
            nn.Sigmoid())


    def forward(self, graphs: List[DGLGraph], trees: List[DGLGraph],
                node_graph_idx: np.array,
                node_super_node_idx: np.array,
                node_tree_idx,
                edges: np.array,
                edge_super_node_idx: np.array,
                edge_tree_idx,
                masked_edges: torch.Tensor,
                edge_graph_idx):
        """
        Args:
            graphs: batch of DGL graphs (tensorized graph] of dimension:
              [B x (features of nodes, adjacency matrix=n, etc.)]
            trees: decomposition trees
              []
        """
        for i, g in enumerate(graphs):
            graphs[i] = g.to(device)

        graphs_batch = batch(graphs)

        del graphs

        input_features = self.dimension_reductor(graphs_batch.ndata['a'])

        del graphs_batch.ndata['a']
        gc.collect()

        for i, tree in enumerate(trees):
            trees[i] = tree.to(device)

        masked_edges = masked_edges.to(device)

        graph_encoded = self.gat(graphs_batch, input_features)

        # output size: sum(M_i) x GAT.num_outputs, where i=0..len(graphs)
        graphs_node_offset = graphs_batch_offsets(graphs_batch)

        graphs_representation = list()
        for idx in range(len(graphs_node_offset)-1):
            start = graphs_node_offset[idx]
            end = graphs_node_offset[idx+1]
            graph_representation = torch.sum(graph_encoded[start:end], dim=0, keepdim=True)
            graphs_representation.append(graph_representation)

        graphs_representation = torch.cat(graphs_representation, dim=0)

        # DecompTreeEncoder batches the given list of trees in its forward method
        roots_encode, tree_batch = self.tree_encoder(trees)

        node_gnn_reps = graphs_representation[node_graph_idx]
        node_tree_reps = roots_encode[node_tree_idx]
        node_sn_reps = tree_batch.ndata['h'][node_super_node_idx]

        concatenated_node_feat = torch.cat([node_gnn_reps, node_tree_reps, node_sn_reps], dim=1)
        node_probs = self.mlp_node(concatenated_node_feat)

        edge_nodes_gnn_reps = torch.cat([graph_encoded[edges[:, 0]], graph_encoded[edges[:, 1]]], dim=1)
        edge_gnn_reps = graphs_representation[edge_graph_idx]
        edge_tree_reps = roots_encode[edge_tree_idx]
        edge_sn_reps = tree_batch.ndata['h'][edge_super_node_idx]

        edges_nodes_id = torch.cat([graphs_batch.ndata['c'][edges[:, 0]], graphs_batch.ndata['c'][edges[:, 1]]], dim=1)

        concatenated_edge_feat = torch.cat([edge_nodes_gnn_reps, edge_gnn_reps, edge_tree_reps, edge_sn_reps, masked_edges, edges_nodes_id], dim=1)
        edge_probs = self.mlp_edge(concatenated_edge_feat)

        return node_probs, edge_probs


class NodeAdding_wo_tree_for_edge(nn.Module):
    def __init__(self,
                 max_cluster_size,
                 max_graph_size,
                 tree_hidden_dim,
                 gat_hidden_dim,
                 gat_num_layers,
                 node_feat_dim,
                 mlp_hidden_dim
                 ):
        super(NodeAdding_wo_tree_for_edge, self).__init__()

        self.C = max_cluster_size
        self.N = max_graph_size  # max number of nodes
        self.tree_hidden_dim = tree_hidden_dim
        self.gat_hidden_dim = gat_hidden_dim
        self.gat_num_layers = gat_num_layers
        self.node_feat_dim = node_feat_dim

        self.tree_encoder = TreeEncoder(self.tree_hidden_dim, self.N)

        # This only applies to a single node at a time (not the entire A)
        self.dimension_reductor = nn.Linear(self.N, self.node_feat_dim)

        self.gat = GAT(
            num_layers=self.gat_num_layers,
            in_dim=self.node_feat_dim,
            num_hidden=self.gat_hidden_dim,
            num_output=self.gat_hidden_dim,
            heads=[NUM_HEADS] * self.gat_num_layers,
            activation=F.elu,
            feat_drop=0,
            attn_drop=0,
            negative_slope=0.2,
            residual=False
        )

        self.mlp_node_input_size = self.gat_hidden_dim + 2 * self.tree_hidden_dim
        self.mlp_node = nn.Sequential(
                nn.Linear(self.mlp_node_input_size, mlp_hidden_dim),
                nn.ReLU(),
                nn.Linear(mlp_hidden_dim, mlp_hidden_dim//2),
                nn.ReLU(),
                nn.Linear(mlp_hidden_dim//2,1),
                nn.Sigmoid())

        self.mlp_edge_input_size = 3 * self.gat_hidden_dim + 3 * self.C
        self.mlp_edge = nn.Sequential(
            nn.Linear(self.mlp_edge_input_size, mlp_hidden_dim),
            nn.ReLU(),
            nn.Linear(mlp_hidden_dim, mlp_hidden_dim // 2),
            nn.ReLU(),
            nn.Linear(mlp_hidden_dim // 2, 1),
            nn.Sigmoid())


    def forward(self, graphs: List[DGLGraph], trees: List[DGLGraph],
                node_graph_idx: np.array,
                node_super_node_idx: np.array,
                node_tree_idx,
                edges: np.array,
                edge_super_node_idx: np.array,
                edge_tree_idx,
                masked_edges: torch.Tensor,
                edge_graph_idx):
        """
        Args:
            graphs: batch of DGL graphs (tensorized graph] of dimension:
              [B x (features of nodes, adjacency matrix=n, etc.)]
            trees: decomposition trees
              []
        """
        for i, g in enumerate(graphs):
            graphs[i] = g.to(device)

        for i, tree in enumerate(trees):
            trees[i] = tree.to(device)

        masked_edges = masked_edges.to(device)
        graphs_batch = batch(graphs)

        # input_features = torch.cat([self.dimension_reductor(graphs_batch.ndata['a']),
        #                             graphs_batch.ndata['c']], dim=1)
        input_features = self.dimension_reductor(graphs_batch.ndata['a'])

        graph_encoded = self.gat(graphs_batch, input_features)
        # output size: sum(M_i) x GAT.num_outputs, where i=0..len(graphs)
        graphs_node_offset = graphs_batch_offsets(graphs_batch)

        graphs_representation = list()
        for idx in range(len(graphs_node_offset)-1):
            start = graphs_node_offset[idx]
            end = graphs_node_offset[idx+1]
            graph_representation = torch.sum(graph_encoded[start:end], dim=0, keepdim=True)
            graphs_representation.append(graph_representation)

        graphs_representation = torch.cat(graphs_representation, dim=0)

        # print('before tree encoding')
        # breakpoint()

        # DecompTreeEncoder batches the given list of trees in its forward method
        roots_encode, tree_batch = self.tree_encoder(trees)

        node_gnn_reps = graphs_representation[node_graph_idx]
        node_tree_reps = roots_encode[node_tree_idx]
        node_sn_reps = tree_batch.ndata['h'][node_super_node_idx]

        concatenated_node_feat = torch.cat([node_gnn_reps, node_tree_reps, node_sn_reps], dim=1)
        node_probs = self.mlp_node(concatenated_node_feat)

        edge_nodes_gnn_reps = torch.cat([graph_encoded[edges[:, 0]], graph_encoded[edges[:, 1]]], dim=1)
        edge_gnn_reps = graphs_representation[edge_graph_idx]
        # edge_tree_reps = roots_encode[edge_tree_idx]
        # edge_sn_reps = tree_batch.ndata['h'][edge_super_node_idx]

        edges_nodes_id = torch.cat([graphs_batch.ndata['c'][edges[:, 0]], graphs_batch.ndata['c'][edges[:, 1]]], dim=1)

        concatenated_edge_feat = torch.cat([edge_nodes_gnn_reps, edge_gnn_reps, masked_edges, edges_nodes_id], dim=1)
        edge_probs = self.mlp_edge(concatenated_edge_feat)

        return node_probs, edge_probs


class NodeAdding_v01(nn.Module):
    def __init__(self,
                 max_cluster_size,
                 max_graph_size,
                 tree_hidden_dim,
                 gat_hidden_dim,
                 gat_num_layers,
                 node_feat_dim,
                 mlp_hidden_dim
                 ):
        super(NodeAdding_v01, self).__init__()

        self.C = max_cluster_size
        self.N = max_graph_size  # max number of nodes
        self.tree_hidden_dim = tree_hidden_dim
        self.gat_hidden_dim = gat_hidden_dim
        self.gat_num_layers = gat_num_layers
        self.node_feat_dim = node_feat_dim

        self.tree_encoder = TreeEncoder(self.tree_hidden_dim, self.N)

        # This only applies to a single node at a time (not the entire A)
        self.dimension_reductor = nn.Linear(self.N, self.node_feat_dim)

        self.gat = GAT(
            num_layers=self.gat_num_layers,
            in_dim=self.node_feat_dim + self.C,
            num_hidden=self.gat_hidden_dim + self.C,
            num_output=self.gat_hidden_dim,
            heads=[NUM_HEADS] * self.gat_num_layers,
            activation=F.elu,
            feat_drop=0,
            attn_drop=0,
            negative_slope=0.2,
            residual=False
        )

        self.mlp_node_input_size = self.gat_hidden_dim + 2 * self.tree_hidden_dim
        self.mlp_node = nn.Sequential(
                nn.Linear(self.mlp_node_input_size, mlp_hidden_dim),
                nn.ReLU(),
                nn.Linear(mlp_hidden_dim, mlp_hidden_dim//2),
                nn.ReLU(),
                nn.Linear(mlp_hidden_dim//2,1),
                nn.Sigmoid())

        self.mlp_edge_input_size = 2 * self.gat_hidden_dim \
                                   + 2 * self.tree_hidden_dim \
                                   + self.C
        self.mlp_edge = nn.Sequential(
            nn.Linear(self.mlp_edge_input_size, mlp_hidden_dim),
            nn.ReLU(),
            nn.Linear(mlp_hidden_dim, mlp_hidden_dim // 2),
            nn.ReLU(),
            nn.Linear(mlp_hidden_dim // 2, 1),
            nn.Sigmoid())


    def forward(self, graphs: List[DGLGraph], trees: List[DGLGraph],
                node_graph_idx: np.array,
                node_super_node_idx: np.array,
                node_tree_idx,
                edges: np.array,
                edge_super_node_idx: np.array,
                edge_tree_idx,
                masked_edges: torch.Tensor,
                edge_graph_idx = None):
        """
        Args:
            graphs: batch of DGL graphs (tensorized graph] of dimension:
              [B x (features of nodes, adjacency matrix=n, etc.)]
            trees: decomposition trees
              []
        """
        for i, g in enumerate(graphs):
            graphs[i] = g.to(device)

        for i, tree in enumerate(trees):
            trees[i] = tree.to(device)

        masked_edges = masked_edges.to(device)

        graphs_batch = batch(graphs)

        input_features = torch.cat([self.dimension_reductor(graphs_batch.ndata['a']),
                                    graphs_batch.ndata['c']], dim=1)

        graph_encoded = self.gat(graphs_batch, input_features)
        # output size: sum(M_i) x GAT.num_outputs, where i=0..len(graphs)
        graphs_node_offset = graphs_batch_offsets(graphs_batch)

        graphs_representation = list()
        for idx in range(len(graphs_node_offset)-1):
            start = graphs_node_offset[idx]
            end = graphs_node_offset[idx+1]
            graph_representation = torch.sum(graph_encoded[start:end], dim=0, keepdim=True)
            graphs_representation.append(graph_representation)

        graphs_representation = torch.cat(graphs_representation, dim=0)

        # DecompTreeEncoder batches the given list of trees in its forward method
        roots_encode, tree_batch = self.tree_encoder(trees)

        node_gnn_reps = graphs_representation[node_graph_idx]
        node_tree_reps = roots_encode[node_tree_idx]
        node_sn_reps = tree_batch.ndata['h'][node_super_node_idx]

        concatenated_node_feat = torch.cat([node_gnn_reps, node_tree_reps, node_sn_reps], dim=1)
        node_probs = self.mlp_node(concatenated_node_feat)

        edge_gnn_reps = torch.cat([graph_encoded[edges[:, 0]], graph_encoded[edges[:, 1]]], dim=1)
        edge_tree_reps = roots_encode[edge_tree_idx]
        edge_sn_reps = tree_batch.ndata['h'][edge_super_node_idx]

        # print('**********************edge_gnn_reps shape:', edge_gnn_reps.shape)
        # print('**********************edge_tree_reps shape:', edge_tree_reps.shape)
        # print('**********************edge_sn_reps shape:', edge_sn_reps.shape)
        # print('**********************masked_edges shape:', masked_edges.shape)

        concatenated_edge_feat = torch.cat([edge_gnn_reps, edge_tree_reps, edge_sn_reps, masked_edges], dim=1)
        edge_probs = self.mlp_edge(concatenated_edge_feat)

        # if len(edges) > 0 and edges[0][0] == 8 and edges[0][1] == 7:
        #     breakpoint()
        # breakpoint()

        return node_probs, edge_probs


class NodeAdding_Without_Tree_Encoding(nn.Module):
    def __init__(self,
                 max_cluster_size,
                 max_graph_size,
                 tree_hidden_dim,
                 gat_hidden_dim,
                 gat_num_layers,
                 node_feat_dim,
                 mlp_hidden_dim
                 ):
        super(NodeAdding_Without_Tree_Encoding, self).__init__()

        self.C = max_cluster_size
        self.N = max_graph_size  # max number of nodes
        # self.tree_hidden_dim = tree_hidden_dim
        self.gat_hidden_dim = gat_hidden_dim
        self.gat_num_layers = gat_num_layers
        self.node_feat_dim = node_feat_dim

        # This only applies to a single node at a time (not the entire A)
        self.dimension_reductor = nn.Linear(self.N, self.node_feat_dim)

        self.gat = GAT(
            num_layers=self.gat_num_layers,
            in_dim=self.node_feat_dim,
            num_hidden=self.gat_hidden_dim,
            num_output=self.gat_hidden_dim,
            heads=[NUM_HEADS] * self.gat_num_layers,
            activation=F.elu,
            feat_drop=0,
            attn_drop=0,
            negative_slope=0.2,
            residual=False
        )

        self.mlp_node_input_size = self.gat_hidden_dim
        self.mlp_node = nn.Sequential(
                nn.Linear(self.mlp_node_input_size, mlp_hidden_dim),
                nn.ReLU(),
                nn.Linear(mlp_hidden_dim, mlp_hidden_dim//2),
                nn.ReLU(),
                nn.Linear(mlp_hidden_dim//2,1),
                nn.Sigmoid())

        self.mlp_edge_input_size = 3 * self.gat_hidden_dim + 3 * self.C
        self.mlp_edge = nn.Sequential(
            nn.Linear(self.mlp_edge_input_size, mlp_hidden_dim),
            nn.ReLU(),
            nn.Linear(mlp_hidden_dim, mlp_hidden_dim // 2),
            nn.ReLU(),
            nn.Linear(mlp_hidden_dim // 2, 1),
            nn.Sigmoid())


    def forward(self, graphs: List[DGLGraph], trees: List[DGLGraph],
                node_graph_idx: np.array,
                node_super_node_idx: np.array,
                node_tree_idx,
                edges: np.array,
                edge_super_node_idx: np.array,
                edge_tree_idx,
                masked_edges: torch.Tensor,
                edge_graph_idx):
        """
        Args:
            graphs: batch of DGL graphs (tensorized graph] of dimension:
              [B x (features of nodes, adjacency matrix=n, etc.)]
            trees: decomposition trees
              []
        """
        for i, g in enumerate(graphs):
            graphs[i] = g.to(device)

        graphs_batch = batch(graphs)

        del graphs

        input_features = self.dimension_reductor(graphs_batch.ndata['a'])

        del graphs_batch.ndata['a']
        gc.collect()

        masked_edges = masked_edges.to(device)

        graph_encoded = self.gat(graphs_batch, input_features)

        # output size: sum(M_i) x GAT.num_outputs, where i=0..len(graphs)
        graphs_node_offset = graphs_batch_offsets(graphs_batch)

        graphs_representation = list()
        for idx in range(len(graphs_node_offset)-1):
            start = graphs_node_offset[idx]
            end = graphs_node_offset[idx+1]
            graph_representation = torch.sum(graph_encoded[start:end], dim=0, keepdim=True)
            graphs_representation.append(graph_representation)

        graphs_representation = torch.cat(graphs_representation, dim=0)

        node_gnn_reps = graphs_representation[node_graph_idx]

        concatenated_node_feat = torch.cat([node_gnn_reps], dim=1)
        node_probs = self.mlp_node(concatenated_node_feat)

        edge_nodes_gnn_reps = torch.cat([graph_encoded[edges[:, 0]], graph_encoded[edges[:, 1]]], dim=1)
        edge_gnn_reps = graphs_representation[edge_graph_idx]

        edges_nodes_id = torch.cat([graphs_batch.ndata['c'][edges[:, 0]], graphs_batch.ndata['c'][edges[:, 1]]], dim=1)

        concatenated_edge_feat = torch.cat([edge_nodes_gnn_reps, edge_gnn_reps, masked_edges, edges_nodes_id], dim=1)
        edge_probs = self.mlp_edge(concatenated_edge_feat)

        return node_probs, edge_probs




class NodeAdding_Simple(nn.Module):
    def __init__(self,
                 max_cluster_size,
                 max_graph_size,
                 tree_hidden_dim,
                 gat_hidden_dim,
                 gat_num_layers,
                 node_feat_dim,
                 mlp_hidden_dim
                 ):
        super(NodeAdding_Simple, self).__init__()

        self.C = max_cluster_size
        self.N = max_graph_size  # max number of nodes
        self.tree_hidden_dim = tree_hidden_dim
        self.gat_hidden_dim = gat_hidden_dim
        self.gat_num_layers = gat_num_layers
        self.node_feat_dim = node_feat_dim

        self.tree_encoder = TreeEncoder(self.tree_hidden_dim, self.N)

        # This only applies to a single node at a time (not the entire A)
        self.dimension_reductor = nn.Linear(self.N, self.node_feat_dim)

        self.gat = GAT(
            num_layers=self.gat_num_layers,
            in_dim=self.node_feat_dim,
            num_hidden=self.gat_hidden_dim,
            num_output=self.gat_hidden_dim,
            heads=[NUM_HEADS] * self.gat_num_layers,
            activation=F.elu,
            feat_drop=0,
            attn_drop=0,
            negative_slope=0.2,
            residual=False
        )

        self.mlp_node_input_size = self.gat_hidden_dim + 2 * self.tree_hidden_dim
        self.mlp_node = nn.Sequential(
                nn.Linear(self.mlp_node_input_size, mlp_hidden_dim),
                nn.ReLU(),
                nn.Linear(mlp_hidden_dim, mlp_hidden_dim//2),
                nn.ReLU(),
                nn.Linear(mlp_hidden_dim//2,1),
                nn.Sigmoid())

        self.mlp_edge_input_size = 3 * self.gat_hidden_dim + 2 * self.tree_hidden_dim + 2 * self.C
        self.mlp_edge = nn.Sequential(
            nn.Linear(self.mlp_edge_input_size, mlp_hidden_dim),
            nn.ReLU(),
            nn.Linear(mlp_hidden_dim, mlp_hidden_dim // 2),
            nn.ReLU(),
            nn.Linear(mlp_hidden_dim // 2, 1),
            nn.Sigmoid())


    def forward(self, graphs: List[DGLGraph], trees: List[DGLGraph],
                node_graph_idx: np.array,
                node_super_node_idx: np.array,
                node_tree_idx,
                edges: np.array,
                edge_super_node_idx: np.array,
                edge_tree_idx,
                masked_edges: torch.Tensor,
                edge_graph_idx):
        """
        Args:
            graphs: batch of DGL graphs (tensorized graph] of dimension:
              [B x (features of nodes, adjacency matrix=n, etc.)]
            trees: decomposition trees
              []
        """
        for i, g in enumerate(graphs):
            graphs[i] = g.to(device)

        graphs_batch = batch(graphs)

        del graphs

        input_features = self.dimension_reductor(graphs_batch.ndata['a'])

        del graphs_batch.ndata['a']
        gc.collect()

        for i, tree in enumerate(trees):
            trees[i] = tree.to(device)

        masked_edges = masked_edges.to(device)

        graph_encoded = self.gat(graphs_batch, input_features)

        # output size: sum(M_i) x GAT.num_outputs, where i=0..len(graphs)
        graphs_node_offset = graphs_batch_offsets(graphs_batch)

        graphs_representation = list()
        for idx in range(len(graphs_node_offset)-1):
            start = graphs_node_offset[idx]
            end = graphs_node_offset[idx+1]
            graph_representation = torch.sum(graph_encoded[start:end], dim=0, keepdim=True)
            graphs_representation.append(graph_representation)

        graphs_representation = torch.cat(graphs_representation, dim=0)

        # DecompTreeEncoder batches the given list of trees in its forward method
        roots_encode, tree_batch = self.tree_encoder(trees)

        node_gnn_reps = graphs_representation[node_graph_idx]
        node_tree_reps = roots_encode[node_tree_idx]
        node_sn_reps = tree_batch.ndata['h'][node_super_node_idx]

        concatenated_node_feat = torch.cat([node_gnn_reps, node_tree_reps, node_sn_reps], dim=1)
        node_probs = self.mlp_node(concatenated_node_feat)

        edge_nodes_gnn_reps = torch.cat([graph_encoded[edges[:, 0]], graph_encoded[edges[:, 1]]], dim=1)
        edge_gnn_reps = graphs_representation[edge_graph_idx]
        edge_tree_reps = roots_encode[edge_tree_idx]
        edge_sn_reps = tree_batch.ndata['h'][edge_super_node_idx]

        edges_nodes_id = torch.cat([graphs_batch.ndata['c'][edges[:, 0]], graphs_batch.ndata['c'][edges[:, 1]]], dim=1)

        concatenated_edge_feat = torch.cat([edge_nodes_gnn_reps, edge_gnn_reps, edge_tree_reps, edge_sn_reps, edges_nodes_id], dim=1)
        edge_probs = self.mlp_edge(concatenated_edge_feat)

        return node_probs, edge_probs
