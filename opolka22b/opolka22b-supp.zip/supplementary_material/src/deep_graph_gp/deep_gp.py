import numpy as np
import gpflow
import tensorflow as tf
from gpflow.base import Module
from gpflow.mean_functions import Zero, Identity, Linear
from gpflow.models.model import MeanAndVariance

from deep_graph_gp.dgp_utils import BroadcastingLikelihood


class DeepGP(Module):
    """
    This is the Doubly-Stochastic Deep GP, with linear/identity mean functions at each layer.
    The key reference is
    ::
      @inproceedings{salimbeni2017doubly,
        title={Doubly Stochastic Variational Inference for Deep Gaussian Processes},
        author={Salimbeni, Hugh and Deisenroth, Marc},
        booktitle={NIPS},
        year={2017}
      }
    """

    def __init__(self, layers, likelihood, X, Z, num_train_samples,
                 mean_function=Zero(), num_samples=1):
        super().__init__(name="DeepGP")
        self.layers = layers
        self.likelihood = BroadcastingLikelihood(likelihood)
        self.num_samples = num_samples
        self.num_data = num_train_samples

        self._init_layers_linear(X, Z, mean_function)

    def _init_layers_linear(self, X, Z, mean_function):
        """
        Initializes the layers of the deep Gaussian process to initially
        have a linear mapping.
        :param X: Input feature matrix.
        :param Z: Initial inducing point values.
        :param mean_function: The mean function that the last layer of the
        deep GP should have.
        """
        X_running, Z_running = X.copy(), Z.copy()
        dim_in = X.shape[-1]
        for layer in self.layers[:-1]:
            dim_out = layer.num_outputs

            # Initialize mean function to be either Identity or PCA projection
            if dim_in == dim_out:
                mf = Identity()
            else:
                if dim_in > dim_out:  # stepping down, use the pca projection
                    # use eigenvectors corresponding to dim_out largest eigenvalues
                    _, _, V = np.linalg.svd(X_running, full_matrices=False)
                    W = V[:dim_out, :].T
                else:                 # stepping up, use identity + padding
                    W = np.concatenate([np.eye(dim_in),
                                        np.zeros((dim_in, dim_out - dim_in))], 1)
                mf = Linear(W)
                gpflow.set_trainable(mf.A, False)
                gpflow.set_trainable(mf.b, False)

            layer.init_mapping(Z_running, mf)

            if dim_in != dim_out:
                Z_running = Z_running.dot(W)
                X_running = X_running.dot(W)
            dim_in = dim_out

        # final layer
        self.layers[-1].init_mapping(Z_running, mean_function)

    def propagate(self, X, full_cov=False, num_samples=1, zs=None):
        sX = tf.tile(tf.expand_dims(X, 0), [num_samples, 1, 1])
        Fs, Fmeans, Fvars = [], [], []
        F = sX
        zs = zs or [None, ] * len(self.layers)
        for layer, z in zip(self.layers, zs):
            F, Fmean, Fvar = layer.sample_from_conditional(F, z=z, full_cov=full_cov)
            Fs.append(F)
            Fmeans.append(Fmean)
            Fvars.append(Fvar)
        return Fs, Fmeans, Fvars

    def predict_f(self, predict_at, num_samples, full_cov=False) -> MeanAndVariance:
        Fs, Fmeans, Fvars = self.propagate(predict_at, full_cov=full_cov,
                                           num_samples=num_samples)
        return Fmeans[-1], Fvars[-1]

    def predict_all_layers(self, predict_at, num_samples, full_cov=False):
        return self.propagate(predict_at, full_cov=full_cov,
                              num_samples=num_samples)

    def predict_y(self, predict_at, num_samples):
        Fmean, Fvar = self.predict_f(predict_at, num_samples=num_samples,
                                     full_cov=False)
        return self.likelihood.predict_mean_and_var(Fmean, Fvar)

    def predict_log_density(self, data, num_samples):
        X, Y, idcs = data if len(data) == 3 else (*data, None)
        Fmean, Fvar = self.predict_f(X, num_samples=num_samples,
                                     full_cov=False)
        if idcs is not None:
            Fmean = tf.gather(Fmean, idcs, axis=1)
            Fvar = tf.gather(Fvar, idcs, axis=1)
        l = self.likelihood.predict_log_density(Fmean, Fvar, Y)
        log_num_samples = tf.math.log(tf.cast(self.num_samples, gpflow.base.default_float()))
        return tf.reduce_logsumexp(l - log_num_samples, axis=0)

    def expected_data_log_likelihood(self, X, Y, idcs=None):
        """
        Compute expectations of the data log likelihood under the variational
        distribution with MC samples. This is the first part of the loss
        function from eq. 17.
        """
        F_mean, F_var = self.predict_f(X, num_samples=self.num_samples,
                                       full_cov=False)
        if idcs is not None:
            F_mean = tf.gather(F_mean, idcs, axis=1)
            F_var = tf.gather(F_var, idcs, axis=1)
        var_exp = self.likelihood.variational_expectations(F_mean, F_var, Y) # Shape [S, N, D]
        return tf.reduce_mean(var_exp, 0)   # Shape [N, D]

    def elbo(self, data, kl_scale=1.0):
        """
        Computes the evidence lower bound according to eq. (17) in the paper.
        :param data: Tuple of two tensors for input data X and labels Y.
        :param kl_scale: Scaling factor for the KL term, allows a cold
        posterior start. Raised to power 5 for a slow start.
        :return: Tensor representing ELBO.
        """
        X, Y, idx_train = data if len(data) == 3 else (*data, None)
        batch_size = X.shape[0] if idx_train is None else len(idx_train)
        likelihood = tf.reduce_sum(self.expected_data_log_likelihood(X, Y, idx_train))
        # scale loss term corresponding to minibatch size
        scale = tf.cast(self.num_data, gpflow.default_float())
        scale /= tf.cast(batch_size, gpflow.default_float())
        # Compute KL term
        kl_scale = kl_scale ** 5
        KL = tf.reduce_sum([layer.KL() for layer in self.layers])
        # print(likelihood, -KL)
        return scale * likelihood - kl_scale * KL, scale * likelihood, KL

