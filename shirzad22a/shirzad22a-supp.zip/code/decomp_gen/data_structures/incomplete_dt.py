import networkx as nx
import matplotlib.pyplot as plt
from decomp_gen.data_structures.graph import superNode


class InCompleteDT:
    def __init__(self, T):
        '''
        T: tree decomposition of a graph, including tree structure and cluster nodes
        '''
        if len(T.nodes) == 0:
            raise Exception('Tree with zero nodes is invalid')
        if not nx.is_tree(T):
            raise Exception('Given graph is not a tree')

        self.n = len(T.nodes)
        self.nodes = [None] * self.n
        self.T = T

        for v in list(T.nodes):
            newSuperNode = superNode(nodes=None, label=v, adjacents=set(), parent=None,
                                     children=set())
            self.nodes[v] = newSuperNode

        self.setAdjLists()
        self.root = self.nodes[0]
        self.makeRooted(self.root)

    def addSuperNode(self, parentID, nodes=None):
        parentNode = self.nodes[parentID]
        newNode = superNode(nodes=nodes, label=self.n, adjacents=set([parentNode]),
                            parent=parentNode, children=set())
        self.nodes.append(newNode)
        parentNode.addChild(newNode)
        parentNode.addAdjacent(newNode)
        self.T.add_edge(parentID, newNode.getLabel())
        self.n = self.n + 1
        return newNode

    def deleteLastNode(self):
        if self.n == 0:
            print("empty tree, nothing to remove")
            return
        node = self.nodes.pop()
        parentNode = node.getParent()
        parentNode.removeChild(node)
        parentNode.removeAdjacent(node)
        self.T.remove_node(node.getLabel())
        self.n = self.n - 1

    def showTree(self, printNodes=True):
        '''
        Draws tree
        optional: Print the details of the superNodes inside the DecompositionTree
        '''
        nx.draw(self.T, with_labels=True)
        plt.show()

        if printNodes:
            for node in self.nodes:
                node.printInformation()

    def getNodes(self):
        return self.nodes

    def getRoot(self):
        return self.root

    def getSimpleTree(self):
        return self.T

    def getCanonicalName(self, sortBy='label'):
        '''
        sortBy options:
            cname: sort by canonicalNames of the children
            label: sort by the label of the nodes
        '''
        if sortBy == 'cname':
            return self.root.getCanonicalName()
        else:
            return self.root.getCanonicalNameSortedByLabel()

    def setAdjLists(self):
        '''
        Setting adjacency lists from given networkx graph
        '''
        for line in nx.generate_adjlist(self.T):
            tmpnodes = line.split()
            tmpnodes = [int(x) for x in tmpnodes]
            v = tmpnodes[0]
            for u in tmpnodes[1:]:
                self.nodes[v].addAdjacent(self.nodes[u])
                self.nodes[u].addAdjacent(self.nodes[v])

    def makeRooted(self, root):
        '''
        Input:
            root: a supernode from nodes of decomposition tree
            Makes tree rooted from given root
        '''
        self.root = root
        mark = [False] * self.n
        root.setParent(None)
        self.__DFSMakeRooted(root, mark)

    def __DFSMakeRooted(self, v, mark):
        '''
        Input:
            v: a superNode of the current DecompositionTree
            mark: A boolean Array for knowing which nodes we have seen and which we have not
        '''
        v.setChildren(set())
        mark[v.getLabel()] = True
        for u in v.getAdjacents():
            if not mark[u.getLabel()]:
                u.setParent(v)
                v.addChild(u)
                self.__DFSMakeRooted(u, mark)

    def pathRepresentation(self):
        return self.root.subTreePathRepresentatoin()

    def pathLenRepresentation(self):
        pr = self.pathRepresentation()
        plr = [len(x) for x in pr]
        return plr

    def makeNXTree(self):
        temp = nx.Graph()
        return self.root.makeNXTree(temp)
