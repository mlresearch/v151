import time
import numpy as np
from cbp import builder
from cbp.graph.coef_policy import bp_policy


for name_type in ['Sinkhorn', 'bp']:
    time_iter = 'total'
    if time_iter == 'per_iteration':
        num_inner_iter = 5
    else:
        # num_inner_iter = 3 if name_type == 'Sinkhorn' else 5
        num_inner_iter = 5
    num_outer_iter = 5
    max_ite = 5 if time_iter == 'per_iteration' else 500000
    run_time_list = np.zeros([num_inner_iter, num_outer_iter])
    step_list = np.zeros([num_inner_iter, num_outer_iter])

    m_value = 2
    n_start = 20
    n_step = 10

    for repeat in range(num_outer_iter + 1):
        for idx in range(num_inner_iter):
            graph = builder.HMMBuilder(
                length=m_value, node_dim=n_start + n_step * idx, policy=bp_policy, rand_seed=repeat)()
            # graph.plot(f"draw/barycenter.png")
            graph.bake()
            start = time.time()
            if name_type == 'Sinkhorn':
                eps, steps, timers = graph.sinkhorn(
                    max_iter=max_ite,
                    tolerance=graph.cfg.itsbp_outer_tolerance / (8))
            else:
                eps, steps, timers = graph.itsbp(max_iter=max_ite)
            end = time.time()
            if time_iter == 'per_iteration':
                run_time = timers / (m_value)
            else:
                run_time = end - start
            # if name_type == 'Sinkhorn':
            #     run_time_list[idx, repeat] = run_time
            if repeat > 0:
                run_time_list[idx, repeat - 1] = run_time
                step_list[idx, repeat - 1] = steps
            print("steps:", steps, "time:", run_time)

    np.save(
        f'draw/HMM_{name_type}_n_change_steps.npy', step_list)
    np.save(
        f'draw/HMM_{name_type}_{time_iter}_m_{m_value}_n_{n_start}_{n_step}_change.npy', run_time_list)
    result = np.load(
        f'draw/HMM_{name_type}_{time_iter}_m_{m_value}_n_{n_start}_{n_step}_change.npy')
    print(result.mean(axis=1), result.std(axis=1))
