use List::Util qw(max);
sub uniq { my %seen; grep !$seen{$_}++, @_; }
#parses input like L1*L2^4 L3  
my @rows = (); 
my $input = "\n";
sub process { 
 my @eqs = (); 
 foreach(@rows) {   
   my @vars = ();
   while ($_ =~ /(([*]??L[0-9]+(\^[0-9]+)?)+)/g) {
     push (@vars, $1);
   }
   push (@eqs, join("+",uniq(@vars)))
 }
 my $idx = 0;
# print $input;
 foreach(uniq(@eqs)) {
   if ($_) {
     $idx++;
     print "_[$idx]=".$_."\n";
   }
 }
};
while (<>) { 
#print $_;
 if ($_ =~ "input|done") { process(); @rows = (); print $_ } 
 else { push @rows, $_ }
}; process()

