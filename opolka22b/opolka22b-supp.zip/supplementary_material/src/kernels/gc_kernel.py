import numpy as np
import gpflow
from gpflow import Parameter
from gpflow import covariances as cov
import tensorflow as tf
import tensorflow_probability as tfp

from inducing_points import NodeInducingPoints
from utils import sparse_mat_to_sparse_tensor, normalize_adj, \
    dense_tensor_to_sparse_tensor, get_submatrix


class GraphConvolutional(gpflow.kernels.base.Kernel):

    def __init__(self, base_kernel, sparse_adj_mat, feature_mat, idx_train,
                 sparse, num_convs):
        super().__init__()
        self.base_kernel = base_kernel
        self.sparse = sparse
        self.num_convs = num_convs
        self.weights = [Parameter(np.array([(1.0/(i+2.0))]),
                                  transform=tfp.bijectors.Sigmoid(),
                                  name=f"weight_{i+1}")
                        for i in range(num_convs)]
        self.dense_feature_mat = feature_mat
        self.sparse_feature_mat = dense_tensor_to_sparse_tensor(feature_mat)

        # Pre-compute the convolution matrix
        sparse_adj_mat[np.diag_indices(sparse_adj_mat.shape[0])] = 1.0
        self.conv_mat = normalize_adj(sparse_adj_mat)
        self.conv_mat = tf.sparse.reorder(sparse_mat_to_sparse_tensor(self.conv_mat))

        # Compute data required for efficient computation of training
        # covariance matrix.
        (self.tr_feature_mat, self.tr_conv_mat,
         self.idx_train_relative) = self._compute_train_data(
            sparse_adj_mat,
            idx_train,
            feature_mat,
            tf.sparse.to_dense(self.conv_mat).numpy())

        # Setup for sparse vs dense operations
        if sparse:
            self.tr_conv_mat = dense_tensor_to_sparse_tensor(self.tr_conv_mat)
            self.matmul_f = tf.sparse.sparse_dense_matmul
            self.eye_f = tf.sparse.eye
            self.add_f = tf.sparse.add
        else:
            self.conv_mat = tf.sparse.to_dense(self.conv_mat)
            self.matmul_f = tf.matmul
            self.eye_f = tf.eye
            self.add_f = tf.add

    def K(self, X, Y=None, presliced=False):
        X = tf.reshape(tf.cast(X, tf.int32), [-1])
        X2 = tf.reshape(tf.cast(Y, tf.int32), [-1]) if Y is not None else X

        cov = self.base_kernel.K(self.dense_feature_mat)
        for i in range(self.num_convs):
            conv_mat = self.add_f(self.weights[i] * self.conv_mat,
                                  (1.0 - self.weights[i]) * self.eye_f(self.conv_mat.shape[0]))
            cov = self.matmul_f(conv_mat, cov)
            cov = self.matmul_f(conv_mat, cov, adjoint_b=True)
        cov = tf.gather(tf.gather(cov, X, axis=0), X2, axis=1)
        return cov

    def K_diag(self, X, presliced=False):
        return tf.linalg.diag_part(self.K(X))

    def Kzx(self, Z, X):
        X = tf.reshape(tf.cast(X, tf.int32), [-1])

        cov = self.base_kernel.K(self.dense_feature_mat, Z)
        for i in range(self.num_convs):
            conv_mat = self.add_f(self.weights[i] * self.conv_mat,
                                  (1.0 - self.weights[i]) * self.eye_f(self.conv_mat.shape[0]))
            cov = self.matmul_f(conv_mat, cov)
        cov = tf.gather(tf.transpose(cov), X, axis=1)
        return cov

    def Kzz(self, Z):
        cov = self.base_kernel.K(Z)
        return cov

    def K_diag_tr(self):

        cov = self.base_kernel.K(self.tr_feature_mat)
        for i in range(self.num_convs):
            conv_mat = self.add_f(self.weights[i] * self.tr_conv_mat,
                                   (1.0 - self.weights[i]) * self.eye_f(self.tr_conv_mat.shape[0]))
            cov = self.matmul_f(conv_mat, cov)
            cov = self.matmul_f(conv_mat, cov, adjoint_b=True)
        cov = tf.gather(tf.gather(cov, self.idx_train_relative, axis=0),
                        self.idx_train_relative, axis=1)
        return tf.linalg.diag_part(cov)

    def _compute_train_data(self, adj_matrix, train_idcs, feature_mat,
                            conv_mat):
        """
        Computes all the variables required for computing the covariance matrix
        for training in a computationally efficient way. The idea is to cut out
        those features from the original feature matrix that are required for
        predicting the training labels, which are the training nodes' features
        and their neihbors' features.
        :param adj_matrix: Original dense adjacency matrix of the graph.
        :param train_idcs: Indices of the training nodes.
        :param feature_mat: Original dense feature matrix.
        :param conv_mat: Original matrix used for computing the graph
        convolutions.
        :return: Cut outs of only the relevant nodes.
            - Feature matrix containing features of only the "relevant" nodes,
            i.e. the training nodes and their neighbors. Shape [num_rel,
            num_feats].
            - Convolutional matrix for only the relevant nodes. Shape [num_rel,
            num_rel].
            - Indices of the training nodes within the relevant nodes. Shape
            [num_rel].
        """
        sub_node_idcs = get_submatrix(adj_matrix, train_idcs,
                                      num_hops=self.num_convs)
        # Compute indices of actual train nodes (excluding their neighbours)
        # within the sub node indices
        relative_train_idcs = np.isin(sub_node_idcs, train_idcs)
        relative_train_idcs = np.where(relative_train_idcs == True)[0]
        return (feature_mat[sub_node_idcs],
                conv_mat[sub_node_idcs, :][:, sub_node_idcs],
                relative_train_idcs)


@cov.Kuu.register(NodeInducingPoints, GraphConvolutional)
def Kuu_graph_polynomial(inducing_variable, kernel, jitter=None):
    """
    Computes the covariance matrix between the inducing points (which are not
    associated with any node).
    :param inducing_variable: Set of inducing points of type
    NodeInducingPoints.
    :param kernel: Kernel of type GraphPolynomial.
    :return: Covariance matrix between the inducing variables.
    """
    return kernel.Kzz(inducing_variable.Z)


@cov.Kuf.register(NodeInducingPoints, GraphConvolutional, tf.Tensor)
def Kuf_graph_polynomial(inducing_variable, kernel, X):
    """
    Computes the covariance matrix between inducing points (which are not
    associated with any node) and normal inputs.
    :param inducing_variable: Set of inducing points of type
    NodeInducingPoints.
    :param kernel: Kernel of type GraphPolynomial.
    :param X: Normal inputs. Note, however, that to simplify the
    implementation, we pass in the indices of the nodes rather than their
    features directly.
    :return: Covariance matrix between inducing variables and inputs.
    """
    return kernel.Kzx(inducing_variable.Z, X)
