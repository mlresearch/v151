function plot_SupRec(trueBlockLocation, NumRowCustomers, NumColumnCustomers)

temp=NumRowCustomers*(NumColumnCustomers');
B=ones(3,3);
temptemp=conv2(temp,B,'same');

%imagesc( -log(NumRowCustomers*(NumColumnCustomers')) );
imagesc(-log(temptemp));
colormap(gray)

for ii=1:size(trueBlockLocation)
%     ExtractedRow = find( (trueBlockLocation(ii,1)<=sortedRowLocation)...
%         .* (sortedRowLocation <= trueBlockLocation(ii,2)) );
%     ExtractedColumn = find( (trueBlockLocation(ii,3)<=sortedColumnLocation)...
%         .* (sortedColumnLocation <= trueBlockLocation(ii,4)) );
    minR = trueBlockLocation(ii,1)-0.5;
    maxR = trueBlockLocation(ii,2)+0.5;
    minC = trueBlockLocation(ii,3)-0.5;
    maxC = trueBlockLocation(ii,4)+0.5;
    if numel(minR)~=0 && numel(maxR)~=0 && numel(minC)~=0 && numel(maxC)~=0
        rectangle('position', [minC,minR,maxC-minC,maxR-minR],'LineWidth',3,'EdgeColor','r');
    end
end