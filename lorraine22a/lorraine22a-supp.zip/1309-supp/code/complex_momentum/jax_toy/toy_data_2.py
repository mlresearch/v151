import numpy as np
from scipy.stats import multivariate_normal as mn
from scipy.stats.distributions import norm


def sample_gaussians(n_samples, num_gaussians=8, label=None, std=0.4, scale=4):
    z = np.random.randn(n_samples, 2)

    centers = []
    for i in range(num_gaussians):
        angle = i * 2 * np.pi / num_gaussians
        centers.append((scale * np.cos(angle), scale * np.sin(angle)))
    centers = np.array(centers).astype('float32')

    if label is not None:
        assert False
        # labels = torch.LongTensor([random.choice(label) for _ in range(n_samples)])
        # labels = (torch.ones(n_samples) * label).long()
    else:
        labels = np.random.randint(len(centers), size=(n_samples,))

    # return sq2 * (0.5 * z + centers[labels]), labels
    return (std * z + centers[labels]), labels


def mixture_of_gaussian_pack(num_gaussians=8, std=0.4, scale=4):
    gaussians = []
    PIs = [1. / num_gaussians] * num_gaussians

    for i in range(num_gaussians):
        angle = i * 2 * np.pi / num_gaussians
        g_i = mn(mean=(scale * np.cos(angle), scale * np.sin(angle)), cov=std * 0.5 * np.eye(2))
        gaussians.append(g_i)

    # This sampler is much more slower, but probabily easy to debug
    def sample_(n_samples_, **args):
        x = np.zeros((n_samples_, 2))
        m_id = np.random.randint(num_gaussians, size=(n_samples_,))
        for j in range(n_samples_):
            x[j, :] = gaussians[m_id[j]].rvs()
        return x, None

    def sample_f(n_samples_, **args):
        x = []
        m_id = np.random.randint(num_gaussians, size=(n_samples_,))
        counts = np.bincount(m_id)
        # assert len(counts) == num_gaussians
        for j in range(num_gaussians):
            xjs = gaussians[j].rvs(size=counts[j])
            x.append(xjs)
        x = np.concatenate(x)
        np.random.shuffle(x)
        return x, None

    def batch_neg_log_lk(batch, **args):
        # Eq 2.193 Bishops book
        ll = []
        for j in range(len(gaussians)):
            ll_j = gaussians[j].pdf(batch) * PIs[j]
            ll.append(ll_j)
        ll = np.array(ll).sum(axis=0)
        return -np.log(ll).sum() / (batch.shape[0] + 1e-6)

    return gaussians, sample_f, batch_neg_log_lk


def demo():
    import matplotlib.pyplot as plt
    _, sample_gaussians_2, batch_neg_log_lk = mixture_of_gaussian_pack(num_gaussians=8)

    x, labels = sample_gaussians_2(100000, num_gaussians=8)
    n_pts = 1000
    range_lim = 6
    # x = x$.numpy()
    plt.figure()
    # plt.hist2d(x[:, 0], x[:, 1], range=[[-range_lim, range_lim], [-range_lim, range_lim]], bins=n_pts, cmap=plt.cm.jet)
    # plt.tight_layout()
    # plt.show()

    Gz = x
    plt.hist2d(Gz[:, 0], Gz[:, 1], range=[[-range_lim, range_lim], [-range_lim, range_lim]],
               bins=1000, cmap=plt.cm.jet)
    plt.tight_layout()

    plt.savefig('toy_plot_gaussians.png', bbox_inches='tight', pad_inches=0)
    plt.show()


if __name__ == "__main__":
    demo()
