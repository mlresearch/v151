#' Four scenarios for simulating dose interval data
#'
#'
#' @param size the number of observations to be drawn
#' @param ncov the number of covariates to be generated
#' @param seed random seed
#'
#' @examples
#'


#' @export
Scenario1.continuous <- function(size,ncov,seed,aL=-1,aU=1,test=FALSE){
  set.seed(seed)
  X = matrix(runif(size*ncov,-1,1),ncol=ncov)
  A = rtruncnorm(size,a=aL,b=aU,mean=mean(aL+aU),sd=0.5)
  if(test){A = runif(size,aL,aU)}
  propensity=1/dnorm(A,mean(aL+aU),0.5)
  c =  0.3*(X[,1]+X[,2]+X[,3])
  r=10
  mu =(0*exp(c*r)+5*exp(r*A))/(exp(r*c)+exp(r*A))
  Y = rnorm(length(mu),mu,1)
  S=rep(2.5,size)
  label=mu>S
  alpha=matrix(rep(c(0.5,0.5),size),ncol=2,byrow=TRUE)
  traininfo = list(X=X,A=A,Y=Y,mu=mu,S=S,alpha=alpha,propensity=propensity/mean(propensity),opt=c,label=label)

  ggplot(aes(x=A,y=Y),data=data.frame(A=traininfo$A,Y=traininfo$mu))+
    geom_point()+geom_point(aes(x=c,y=S),color='red',alpha=0.2,size=2)+
    geom_hline(yintercept = S)+theme_light()+
    ggtitle('                                     Scenario 1 noiseless')
  
  ggplot(aes(x=A,y=Y),data=data.frame(A=traininfo$A,Y=traininfo$Y))+
    geom_point()+geom_point(aes(x=c,y=S),color='red',alpha=0.2,size=2)+
    geom_hline(yintercept = traininfo$S)+theme_light()+
    ggtitle('                                     Scenario 1 noisy')
  
  return(traininfo)
}
Scenario1.continuous.prognostic <- function(size,ncov,seed,aL=-2,aU=2,test=FALSE){
  set.seed(seed)
  X = matrix(runif(size*ncov,-1,1),ncol=ncov)
  c =  0.3*(X[,1]+X[,2]+X[,3])
  d = 0.6*(X[,2]+X[,3]+X[,4])
  
  A = rtruncnorm(size,a=aL,b=aU,mean=c,sd=0.5)
  if(test){A = runif(size,aL,aU)}
  propensity=1/dnorm(A,c,0.5)
  r = 10
  mu =(0*exp(c*r)+5*exp(r*A))/(exp(r*c)+exp(r*A))+d
  Y = rnorm(length(mu),mu,1.5)
  S=fitted(lm(Y~X))
  label=mu>S
  alpha=matrix(rep(c(0.5,0.5),size),ncol=2,byrow=TRUE)
  traininfo = list(X=X,A=A,Y=Y,mu=mu,S=S,alpha=alpha,propensity=propensity/mean(propensity),opt=c,label=label)
  
  ggplot(aes(x=A,y=Y),data=data.frame(A=traininfo$A,Y=traininfo$mu))+
    geom_point()+geom_point(aes(x=c,y=S),color='red',alpha=0.2,size=2)+
    theme_light()+
    ggtitle('                                     Scenario 1 noiseless')

  
  ggplot(aes(x=A,y=Y),data=data.frame(A=traininfo$A,Y=traininfo$Y))+
    geom_point()+geom_point(aes(x=c,y=S),color='red',alpha=0.2,size=2)+
    theme_light()+
    ggtitle('                                     Scenario 1 noisy')
  
  return(traininfo)
}

#' @export
Scenario2.continuous <- function(size,ncov,seed,aL=-2,aU=2,test=FALSE){
  set.seed(seed)
  X = matrix(runif(size*ncov,-1,1),ncol=ncov)
  A = rtruncnorm(size,a=aL,b=aU,mean=mean(aL+aU),sd=0.5)
  if(test){A = runif(size,aL,aU)}
  propensity=1/dnorm(A,mean(aL+aU),0.5)
  c =  (0.75*log(abs(X[,1])+1)-0.2*cos(pi*X[,2])+0.2*(X[,3]>0))-0.4
  r=10
  mu =(0*exp(c*r)+5*exp(r*A))/(exp(r*c)+exp(r*A))
  Y = rnorm(length(mu),mu,1.5)
  S=rep(2.5,size)
  label=mu>S
  alpha=matrix(rep(c(0.5,0.5),size),ncol=2,byrow=TRUE)
  traininfo = list(X=X,A=A,Y=Y,mu=mu,S=S,alpha=alpha,propensity=propensity/mean(propensity),opt=c,label=label)
  
  ggplot(aes(x=A,y=Y),data=data.frame(A=traininfo$A,Y=traininfo$mu))+
    geom_point()+geom_point(aes(x=c,y=S),color='red',alpha=0.2,size=2)+
    geom_hline(yintercept = S)+ theme_light()+
    ggtitle('                                     Scenario 2 noiseless')

  ggplot(aes(x=A,y=Y),data=data.frame(A=traininfo$A,Y=traininfo$Y))+
    geom_point()+geom_point(aes(x=c,y=S),color='red',alpha=0.2,size=2)+
    geom_hline(yintercept = traininfo$S)+theme_light()+
    ggtitle('                                     Scenario 2 noisy')
  
  return(traininfo)
}
Scenario2.continuous.prognostic <- function(size,ncov,seed,aL=-2,aU=2,test=FALSE){
  set.seed(seed)
  X = matrix(runif(size*ncov,-1,1),ncol=ncov)
  c =  (0.75*log(abs(X[,1])+1)-0.2*cos(pi*X[,2])+0.2*(X[,3]>0))-0.4
  d =  (0.4*sin(pi*X[,2])+0.4*I(pi*X[,3]>0)+0.4*abs(X[,4]))
  A = rtruncnorm(size,a=aL,b=aU,mean=c,sd=0.5)
  if(test){A = runif(size,aL,aU)}
  propensity=1/dnorm(A,c,0.5)
  r=10
  mu =(0*exp(c*r)+5*exp(r*A))/(exp(r*c)+exp(r*A))+d
  Y = rnorm(length(mu),mu,1.5)
  S=fitted(lm(Y~X+I(X^2)))
  label=mu>S
  alpha=matrix(rep(c(0.5,0.5),size),ncol=2,byrow=TRUE)
  traininfo = list(X=X,A=A,Y=Y,mu=mu,S=S,alpha=alpha,propensity=propensity/mean(propensity),opt=c,label=label)
  ggplot(aes(x=A,y=Y),data=data.frame(A=traininfo$A,Y=traininfo$mu))+
    geom_point()+geom_point(aes(x=c,y=S),color='red',alpha=0.2,size=2)+
    theme_light()+
    ggtitle('                                     Scenario 2 noiseless')
  
  ggplot(aes(x=A,y=Y),data=data.frame(A=traininfo$A,Y=traininfo$Y))+
    geom_point()+geom_point(aes(x=c,y=S),color='red',alpha=0.2,size=2)+
    theme_light()+
    ggtitle('                                     Scenario 2 noisy')
  return(traininfo)
}

Scenario1.prognostic.hn <- function(size,ncov,seed,aL=-2,aU=2,test=FALSE){
  set.seed(seed)
  X = matrix(runif(size*ncov,-1,1),ncol=ncov)
  c =  0.3*(X[,1]+X[,2]+X[,3])
  d = 0.6*(X[,2]+X[,3]+X[,4])
  
  A = rtruncnorm(size,a=aL,b=aU,mean=c,sd=0.5)
  if(test){A = runif(size,aL,aU)}
  propensity=1/dnorm(A,c,0.5)
  r = 10
  mu =(0*exp(c*r)+5*exp(r*A))/(exp(r*c)+exp(r*A))+d
  Y = rnorm(length(mu),mu,3)
  S=fitted(lm(Y~X))
  label=mu>S
  alpha=matrix(rep(c(0.5,0.5),size),ncol=2,byrow=TRUE)
  traininfo = list(X=X,A=A,Y=Y,mu=mu,S=S,alpha=alpha,propensity=propensity/mean(propensity),opt=c,label=label)
  
  ggplot(aes(x=A,y=Y),data=data.frame(A=traininfo$A,Y=traininfo$mu))+
    geom_point()+geom_point(aes(x=c,y=S),color='red',alpha=0.2,size=2)+
    theme_light()+
    ggtitle('                                     Scenario 1 noiseless')
  
  
  ggplot(aes(x=A,y=Y),data=data.frame(A=traininfo$A,Y=traininfo$Y))+
    geom_point()+geom_point(aes(x=c,y=S),color='red',alpha=0.2,size=2)+
    theme_light()+
    ggtitle('                                     Scenario 1 noisy')
  
  return(traininfo)
}


Scenario2.prognostic.hn <- function(size,ncov,seed,aL=-2,aU=2,test=FALSE){
  set.seed(seed)
  X = matrix(runif(size*ncov,-1,1),ncol=ncov)
  c =  (0.75*log(abs(X[,1])+1)-0.2*cos(pi*X[,2])+0.2*(X[,3]>0))-0.4
  d =  (0.4*sin(pi*X[,2])+0.4*I(pi*X[,3]>0)+0.4*abs(X[,4]))
  A = rtruncnorm(size,a=aL,b=aU,mean=c,sd=0.5)
  if(test){A = runif(size,aL,aU)}
  propensity=1/dnorm(A,c,0.5)
  r=10
  mu =(0*exp(c*r)+5*exp(r*A))/(exp(r*c)+exp(r*A))+d
  Y = rnorm(length(mu),mu,3)
  S=fitted(lm(Y~X+I(X^2)))
  label=mu>S
  alpha=matrix(rep(c(0.5,0.5),size),ncol=2,byrow=TRUE)
  traininfo = list(X=X,A=A,Y=Y,mu=mu,S=S,alpha=alpha,propensity=propensity/mean(propensity),opt=c,label=label)
  ggplot(aes(x=A,y=Y),data=data.frame(A=traininfo$A,Y=traininfo$mu))+
    geom_point()+geom_point(aes(x=c,y=S),color='red',alpha=0.2,size=2)+
    theme_light()+
    ggtitle('                                     Scenario 2 noiseless')
  
  ggplot(aes(x=A,y=Y),data=data.frame(A=traininfo$A,Y=traininfo$Y))+
    geom_point()+geom_point(aes(x=c,y=S),color='red',alpha=0.2,size=2)+
    theme_light()+
    ggtitle('                                     Scenario 2 noisy')
  return(traininfo)
}
