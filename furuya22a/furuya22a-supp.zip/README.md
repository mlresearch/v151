# Spectral Pruning for Recurrent Neural Networks

This repository is the official implementation of [Spectral Pruning for Recurrent Neural Networks](https://arxiv.org/abs/2105.10832).

## Requirements

To install requirements:

```setup
$ pip install -r dockerfile/requirements.txt
```

or build docker image and run it:

```shell
$ docker build \
  -f ./Dockerfile \
  -t sp4rnn/aistats:cuda10.2_torch1.7 .
$ docker run --rm -it --gpus all \
  -v `pwd`:/work \
  -w /work \
  sp4rnn/aistats:cuda10.2_torch1.7 bash
```

## Training

To train the model in the paper, run this command:

```train
python train4{img or txt}.py --cfg <path_to_config_yaml>
```

Default configure yaml files are in [models/configure/](models/configure/).
And trained parameters will be saved at [models/logs/](models/logs/) in default.

### Spectral Pruning for RNN

To conduct Spectral Pruning for RNN, run:

```SP
python SP4{img or txt}.py --w_dir <path_to_wts.pth> --m <pruned_hidden_size: integer>
```
or
```SP
python SP4{img or txt}.py --w_dir <path_to_wts.pth>
```

### Comparison with Other Pruning Methods

To compare Spectral Pruning with other pruning methods for RNN, run:

```prune
python prune4{img or txt}.py --w_dir <path_to_wts.pth> --m <pruned_hidden_size: integer>
```

### Fine-tuning for Pruned Models

To fine-tune some pruned model, for example, run:

```fine-tune
$ python FT4img.py \
    --wts_path <path_to_wts.pth> \
    --m <pruned_hidden_size: integer> \
    --lr_decay <lr_org/lr_decay is used as initial lr in fine-tuning:float> \
    --epochs <number_of_epochs_for_fine-tune: integer> \
    --non_structured_pruned <model_is_weight_pruned_or_not: bool>
$ python FT4txt.py \
    --wts_path <path_to_wts.pth> \
    --m <pruned_hidden_size: integer> \
    --lr_decay <lr_org/lr_decay is used as initial lr in fine-tuning:float> \
    --non_structured_pruned <model_is_weight_pruned_or_not: bool>
```


## Pre-trained Models

Some pre-trained models are prepared in [pretrained_models/](pretrained_models/).
