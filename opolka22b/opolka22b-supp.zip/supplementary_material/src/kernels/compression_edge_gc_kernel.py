import numpy as np
import gpflow
from gpflow import Parameter
from gpflow import covariances as cov
import tensorflow as tf
import tensorflow_probability as tfp

from inducing_points import BipartiteGraphInducingPoints, \
    GraphInducingPoints, ConvolvingGraphInducingPoints
from utils import sparse_mat_to_sparse_tensor, normalize_adj


class CompressionEdgeGraphConvolutional(gpflow.kernels.base.Kernel):

    def __init__(self, base_kernel, sparse_conv_mat, feature_mat, num_convs):
        super().__init__(None)
        self.base_kernel = base_kernel
        self.dense_feature_mat = tf.constant(feature_mat)
        self.num_convs = num_convs
        # Set default conv matrix and subgraph nodes
        self.conv_mat = tf.sparse.reorder(sparse_mat_to_sparse_tensor(sparse_conv_mat))
        self.conv_mat = tf.sparse.to_dense(self.conv_mat)
        self.subgraph_nodes = tf.constant(np.arange(len(self.dense_feature_mat)))

    def set_subgraph_information(self, conv_matrix, subgraph_nodes):
        """
        Sets the convolution matrix and indices of the nodes in the subgraph
        for the edges in the current batch.
        :param conv_matrix: Dense convolution matrix of shape [M, M]. If None,
        the value will not be updated.
        :param subgraph_nodes: Array of node indices of shape [M]. If None, the
        value will not be updated.
        """
        if conv_matrix is not None and subgraph_nodes is not None:
            if isinstance(conv_matrix, tf.sparse.SparseTensor):
                conv_matrix = tf.sparse.reorder(conv_matrix)
                conv_matrix = tf.sparse.to_dense(conv_matrix)
            self.conv_mat = conv_matrix
            self.subgraph_nodes = subgraph_nodes

    def K(self, X, Y=None, presliced=False):
        """
        :param X: Specifies node indices for each edge in the batch. Shape
        [B, 2].
        :param Y: Specifies node indices for each edge in the batch. Shape
        [B', 2].
        :param presliced:
        :return:
        """
        X = tf.reshape(tf.cast(X, tf.int32), [-1, 2])
        X2 = tf.reshape(tf.cast(Y, tf.int32), [-1, 2]) if Y is not None else X
        conv_mat = self.conv_mat

        feature_mat = tf.gather(self.dense_feature_mat, self.subgraph_nodes)
        cov = self.base_kernel.K(feature_mat)
        for i in range(self.num_convs):
            cov = tf.matmul(conv_mat, cov)
            cov = tf.matmul(cov, conv_mat, adjoint_b=True)

        cov_edges = (tf.gather(tf.gather(cov, X[:, 0], axis=0), X2[:, 0], axis=1)
                     * tf.gather(tf.gather(cov, X[:, 1], axis=0), X2[:, 1], axis=1))
        cov_edges += (tf.gather(tf.gather(cov, X[:, 0], axis=0), X2[:, 1], axis=1)
                      * tf.gather(tf.gather(cov, X[:, 1], axis=0), X2[:, 0], axis=1))
        return cov_edges

    def K_diag(self, X, presliced=False):
        return tf.linalg.diag_part(self.K(X))


@cov.Kuu.register(ConvolvingGraphInducingPoints, CompressionEdgeGraphConvolutional)
def Kuu_graph_polynomial(inducing_variable, kernel, jitter=None):
    Z = inducing_variable.Z
    idcs = tf.cast(inducing_variable.edge_indices, tf.dtypes.int32)
    ind_conv_mat = inducing_variable.conv_matrix()

    cov = kernel.base_kernel.K(Z)

    cov = tf.matmul(ind_conv_mat, cov)
    cov = tf.matmul(ind_conv_mat, cov, adjoint_b=True)
    cov = tf.matmul(ind_conv_mat, cov)
    cov = tf.matmul(ind_conv_mat, cov, adjoint_b=True)

    cov_edges = (tf.gather(tf.gather(cov, idcs[:, 0], axis=0), idcs[:, 0], axis=1)
                 * tf.gather(tf.gather(cov, idcs[:, 1], axis=0), idcs[:, 1], axis=1))
    cov_edges += (tf.gather(tf.gather(cov, idcs[:, 0], axis=0), idcs[:, 1], axis=1)
                  * tf.gather(tf.gather(cov, idcs[:, 1], axis=0), idcs[:, 0], axis=1))
    if jitter:
        jitter_matrix = tf.eye(cov_edges.shape[0], cov_edges.shape[1],
                               dtype=cov_edges.dtype) * jitter
        cov_edges += jitter_matrix
    return cov_edges


@cov.Kuf.register(ConvolvingGraphInducingPoints, CompressionEdgeGraphConvolutional, tf.Tensor)
def Kuf_graph_polynomial(inducing_variable, kernel, X):
    X = tf.reshape(tf.cast(X, tf.int32), [-1, 2])
    Z = inducing_variable.Z
    idcs = tf.cast(inducing_variable.edge_indices, tf.dtypes.int32)
    ind_conv_mat = inducing_variable.conv_matrix()
    conv_mat = kernel.conv_mat

    feature_mat = tf.gather(kernel.dense_feature_mat, kernel.subgraph_nodes)
    base_cov = kernel.base_kernel.K(feature_mat, Z)

    # input domain convolutions
    cov = tf.matmul(conv_mat, base_cov)
    cov = tf.matmul(conv_mat, cov)

    # # inducing domain convolutions
    cov = tf.matmul(cov, ind_conv_mat)
    cov = tf.matmul(cov, ind_conv_mat)

    cov_edges = (tf.gather(tf.gather(cov, X[:, 0], axis=0), idcs[:, 0], axis=1)
                 * tf.gather(tf.gather(cov, X[:, 1], axis=0), idcs[:, 1], axis=1))
    cov_edges += (tf.gather(tf.gather(cov, X[:, 0], axis=0), idcs[:, 1], axis=1)
                  * tf.gather(tf.gather(cov, X[:, 1], axis=0), idcs[:, 0], axis=1))
    return tf.transpose(cov_edges)
