function fx = obj_eval(D, L, k, y, x, lambda)  
    fx = 0.5*(x - y)'*(x - y) + lambda*norm(Times_S(D, L, k, x), 1); 
end

