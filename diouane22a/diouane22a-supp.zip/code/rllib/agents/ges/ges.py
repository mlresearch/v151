# Code in this file is copied and adapted from
# https://github.com/openai/evolution-strategies-starter.

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from collections import namedtuple
import logging
import numpy as np
import time
from scipy.spatial.distance import cosine

import ray
from ray.rllib.agents import Agent, with_common_config

from ray.rllib.agents.ges import optimizers
from ray.rllib.agents.ges import policies
from ray.rllib.agents.ges import utils
from ray.rllib.utils.annotations import override
from ray.rllib.utils import FilterManager
from ray.rllib.models.preprocessors import FourierPreprocessor
from ray.rllib.models import ModelCatalog
import os

# TODO: use ray get and put for sending U matrix

logger = logging.getLogger(__name__)

Result = namedtuple("Result", [
    "noise_indices", "noise_indices_k", "noisy_returns", "sign_noisy_returns", "noisy_lengths",
    "eval_returns", "eval_lengths", "value_gradients", "policy_gradients", "value_gradients_2", "policy_gradients_2", "noisy_ent_evals", "noisy_returns_h", "eval_returns_h", "cost", "eval_cost"
])

# yapf: disable
# __sphinx_doc_begin__
DEFAULT_CONFIG = with_common_config({
    "seed": 1045,
    "l2_coeff": 0.0001,
    "episodes_per_batch": 240, # 240
    "train_batch_size": 10000,
    "eval_prob": 0.03,
    "return_proc_mode": "centered_rank",
    "num_workers": 40,# 120
    "observation_filter": "MeanStdFilter",
    "noise_size": 250000000,
    "report_length": 10,
    "k": 20,
    # noise stuff
    "noise_stdev": 1.0, # 1.0, 0.02
    "anneal_noise_stdev": True,
    "anneal_noise_stdev_rate": 0.99, # 0.95
    "increase_noise_rate": 1.01,
    "minimum_noise_stdev": 0.0001, # 0.0001
    "maximum_noise_stdev": 1.0, # 1.0, 0.02
    # STEPSIZE/LEARNING RATE STUFF
    "stepsize": 0.1, # 0.1, 0.01
    "anneal_stepsize": True,
    "anneal_stepsize_rate": 0.99, # for safe exp 0.95
    "minimum_stepsize": 0.0001,
    "maximum_stepsize": 0.1,
    "c": 0.001,
    "alpha": 0.5,
    "beta": 5.0,
    "sufficient_increase": True, # True
    "suff_inc_type": "mean",  # four types 1) mean 2) popmean 3) relaxed_mean
    "scale_exp": -6,
    "stepsize_exp": 2,
    "increase_stepsize_rate": 1.01,
    "custom_preprocessor": None,  # "FourierPreprocessor",
    "order": 2,
    "discount_factor": 0.99,
    "policy_gradient": True,
    "action_noise": True,
    "cosine": True,
    "action_noise_std": 0.01,
    "clip_actions": False, # for battleship [0,1], for pybullet [-1,1]
    "clip_rewards": False,
    "reward_scale": 1,
    "entropy_scale": 0.0001, # 0.0001
    "sufficient_entropy": True, # use entropy + reward for sufficient decrease condition
    "store":False,
    "store_freq":20,
    "barrier":True,
    "penalty":-10000,
    "rank_penalty":-1, # after centering
    "entropy_upper":5000,
    "entropy_lower":-1000,
    "cliff":False,
    "anneal_lower_bound":False,
    "anneal_lower_bound_ratio":0.9999,
    "increase_reward_imp":False,
    "increase_reward_imp_ratio":1.1,
    "decrease_reward_imp_ratio":0.99999,
    "reward_imp_upper": 500,
    "reward_imp_lower": 1,
    "safe_exp":True,
    "increase_lower_bound_safe": False,
    "increase_safe_lb_rate":1.03,
    "safe_lb_up_bnd":200,
    "safe_lower": -1000,
    "safe_upper": 25,
    "verification": False,
    "safety_gym": True
})

# __sphinx_doc_end__
# yapf: enable

@ray.remote
def create_shared_noise(count, seed):
    """Create a large array of noise to be shared by all workers."""
    # creates a very large array of random numbers and returns it
    seed = seed #123,
    noise = np.random.RandomState(seed).randn(count).astype(np.float32)
    return noise


class SharedNoiseTable(object):
    def __init__(self, noise):
        self.noise = noise  # stores a very large array of random numbers
        assert self.noise.dtype == np.float32

    def get(self, i, dim):
        return self.noise[i:i + dim]

    def sample_index(self, dim):
        # returns a index, which can then be used to select noise array of size dim
        return np.random.randint(0, len(self.noise) - dim + 1)


@ray.remote
class Worker(object):
    def __init__(self,
                 config,
                 policy_params,
                 env_creator,
                 noise,
                 min_task_runtime=0.2):
        self.min_task_runtime = min_task_runtime
        self.config = config
        self.policy_params = policy_params
        self.noise = SharedNoiseTable(noise)

        self.env = env_creator(config["env_config"])
        from ray.rllib import models
        # self.preprocessor = models.ModelCatalog.get_preprocessor(
        #     self.env, config["model"])
        self.policy_gradient = self.config["policy_gradient"]
        self.discount_factor = self.config["discount_factor"]
        self.clip_reward = self.config["clip_rewards"]
        self.clip_action = self.config["clip_actions"]

        if self.config["custom_preprocessor"]:
            file_name = "cartpole"
            scale = np.loadtxt('/cluster/home/vipatil/msc_vihang/configs/' + file_name + '.txt')
            low = scale[0]
            high = scale[1]
            order = self.config["order"]
            options = {"custom_preprocessor": "FourierPreprocessor", "low": low, "high": high, "order": order}
            self.preprocessor = models.ModelCatalog.get_preprocessor(self.env, options)
        else:
            self.preprocessor = models.ModelCatalog.get_preprocessor(self.env)

        self.sess = utils.make_session(single_threaded=True)

        if self.policy_gradient:
            self.policy = policies.AACritic(
                self.sess, self.env.action_space, self.env.observation_space, self.preprocessor,
                self.config["observation_filter"], self.config["model"],
                **policy_params)
        else:
            self.policy = policies.GenericPolicy(
                self.sess, self.env.action_space, self.env.observation_space, self.preprocessor,
                self.config["observation_filter"], self.config["model"],
                **policy_params)

        self.alpha = self.config["alpha"]
        self.noise_stdev = self.config["noise_stdev"]

        # Add noise to our action probabilities
        self.action_noise = self.config["action_noise"]
        # reward scale
        self.reward_scale = self.config["reward_scale"]
        # entropy scale
        self.entropy_scale = self.config["entropy_scale"]
        self.cliff = self.config["cliff"]

        # constrains
        self.barrier = self.config["barrier"]
        self.penalty = self.config["penalty"]
        self.rank_penalty = self.config["rank_penalty"]
        self.entropy_upper = self.config["entropy_upper"]
        self.entropy_lower = self.config["entropy_lower"]
        self.anneal_lower_bound = self.config["anneal_lower_bound"]
        self.anneal_lower_bound_ratio = self.config["anneal_lower_bound_ratio"]
        self.increase_reward_imp = self.config["increase_reward_imp"]
        self.increase_reward_imp_ratio = self.config["increase_reward_imp_ratio"]

        # random seed
        self.seed = self.config["seed"]
        self.safe_exp = self.config["safe_exp"]
        self.safe_lower = self.config["safe_lower"]
        self.safe_upper = self.config["safe_upper"]
        self.increase_safe_lb_rate = self.config["increase_safe_lb_rate"]
        self.safe_lb_up_bnd = self.config["safe_lb_up_bnd"]
        self.increase_lb_safe = self.config["increase_lower_bound_safe"]

        # safety_gym
        self.safety_gym = self.config["safety_gym"]

    @property
    def filters(self):
        return {"default": self.policy.get_filter()}

    def sync_filters(self, new_filters):
        for k in self.filters:
            self.filters[k].sync(new_filters[k])

    def get_filters(self, flush_after=False):
        return_filters = {}
        for k, f in self.filters.items():
            return_filters[k] = f.as_serializable()
            if flush_after:
                f.clear_buffer()
        return return_filters

    def entropy_barrier_function(self, entropy_1, entropy_2, rewards_h_1, rewards_h_2):
        if entropy_1 > self.entropy_upper:
            rewards_h_1 = self.penalty
        elif entropy_1 < self.entropy_lower:
            rewards_h_1 = self.penalty
        else:
            rewards_h_1 = rewards_h_1.sum()

        if entropy_2 > self.entropy_upper:
            rewards_h_2 = self.penalty
        elif entropy_2 < self.entropy_lower:
            rewards_h_2 = self.penalty
        else:
            rewards_h_2 = rewards_h_2.sum()

        return rewards_h_1, rewards_h_2

    def safe_exp_barrier_func(self, entropy_1, entropy_2, rewards_h_1, rewards_h_2,
                              cost_1, cost_2, iteration):

        if cost_1 > self.safe_upper:# or entropy_1 > self.entropy_upper:
            rewards_h_1 = self.penalty
        elif cost_1 < self.safe_lower:# or entropy_1 < self.entropy_lower:
            rewards_h_1 = self.penalty
        else:
            rewards_h_1 = rewards_h_1.sum()

        if cost_2 > self.safe_upper or entropy_2 > self.entropy_upper:
            rewards_h_2 = self.penalty
        elif cost_2 < self.safe_lower or entropy_2 < self.entropy_lower:
            rewards_h_2 = self.penalty
        else:
            rewards_h_2 = rewards_h_2.sum()

        # if iteration > 100:
        #     if self.safe_lower < 0:
        #         self.safe_lower = 0.1
        #     if self.increase_lb_safe:
        #         self.safe_lower = self.safe_lower * self.increase_safe_lb_rate
        #     if self.safe_lower > self.safe_lb_up_bnd:
        #         self.safe_lower = self.safe_lb_up_bnd

        return rewards_h_1, rewards_h_2

    def rollout(self, timestep_limit, policy_gradient, add_noise=True):
        # toggle between using policy gradients as surrogates or not
        if policy_gradient:
            rollout_rewards, rollout_length, value_grad, policy_grad, rollout_r_h, entropy, cost = policies.rollout_with_surrogate(
                policy=self.policy,
                env=self.env,
                discount_factor=self.discount_factor,
                calc_gradient=True,
                safe_exp=self.safe_exp,
                entropy_scale=self.entropy_scale,
                reward_scale=self.reward_scale,
                clip_action=self.clip_action,
                clip_reward=self.clip_reward,
                timestep_limit=timestep_limit,
                add_noise=add_noise,
                safety_gym=self.safety_gym)
        else:
            rollout_rewards, rollout_length, rollout_r_h, entropy, cost = policies.rollout(
                policy=self.policy,
                env=self.env,
                safe_exp=self.safe_exp,
                entropy_scale=self.entropy_scale,
                reward_scale=self.reward_scale,
                timestep_limit=timestep_limit,
                add_noise=add_noise,
                clip_action=self.clip_action,
                safety_gym=self.safety_gym)
            value_grad = 0
            policy_grad = 0

        return rollout_rewards, rollout_length, value_grad, policy_grad, rollout_r_h, entropy, cost

    # TODO: send U using ray.put and ray.get
    def do_rollouts(self, params, params_vf, alpha, U, iteration, k, stdev, policy_gradient, eval_return,reward_scale,
                    timestep_limit=None):
        # Set the policy weights.
        self.policy.set_weights(params)
        # Set value weights
        self.policy.set_weights_vf(params_vf)
        # setting alpha value
        self.alpha = alpha
        # set reward scale
        self.reward_scale = reward_scale

        noise_indices, noise_indices_k, returns, sign_returns, lengths = [], [], [], [], []
        eval_returns, eval_lengths, entropy_eval, returns_h, eval_returns_h = [], [], [], [], []
        cost, eval_cost = [], []
        self.noise_stdev = stdev
        # use policy gradient or not
        policy_gradient = policy_gradient

        # Perform some rollouts with noise.
        task_tstart = time.time()
        while (len(noise_indices) == 0
               or time.time() - task_tstart < self.min_task_runtime):

            if np.random.uniform() < self.config["eval_prob"] or eval_return:
                # Do an evaluation run with no perturbation.
                self.policy.set_weights(params)
                rewards, length, value_grad_1, policy_grad_1, rewards_h_1, entropy_1, cost_1 = self.rollout(timestep_limit, policy_gradient, add_noise=False)
                value_grad_2, policy_grad_2 = value_grad_1, policy_grad_1
                eval_returns.append(rewards.sum())
                eval_lengths.append(length)
                eval_returns_h.append(rewards_h_1.sum())
                eval_cost.append(cost_1)
            else:
                # Do a regular run with parameter perturbations.
                # get noise index, input given num_params

                if iteration <= k:
                    noise_index = self.noise.sample_index(self.policy.num_params)
                    noise_index_k = 0
                    noise_indices_k.append(noise_index_k)

                    # give the noise index and dim, to get perturbation
                    # Sample n dimensional noise
                    perturbation = self.noise_stdev * self.noise.get(
                        noise_index, self.policy.num_params)

                    # These two sampling steps could be done in parallel on
                    # different actors letting us update twice as frequently.
                    self.policy.set_weights(params + perturbation)
                    rewards_pos, lengths_pos, value_grad_1, policy_grad_1, rewards_h_1, entropy_1, cost_1 = self.rollout(timestep_limit,
                                                                                         policy_gradient,
                                                                                         add_noise=self.action_noise)

                    self.policy.set_weights(params - perturbation)
                    rewards_neg, lengths_neg, value_grad_2, policy_grad_2, rewards_h_2, entropy_2, cost_2 = self.rollout(timestep_limit,
                                                                                         policy_gradient,
                                                                                         add_noise=self.action_noise)

                    entropy_eval.append([entropy_1, entropy_2])
                    returns_h.append([rewards_h_1.sum(), rewards_h_2.sum()])
                    noise_indices.append(noise_index)
                    returns.append([rewards_pos.sum(), rewards_neg.sum()])
                    sign_returns.append(
                        [np.sign(rewards_pos).sum(),
                         np.sign(rewards_neg).sum()])
                    lengths.append([lengths_pos, lengths_neg])
                    cost.append([cost_1, cost_2])
                else:
                    noise_index_n = self.noise.sample_index(self.policy.num_params)
                    noise_index_k = self.noise.sample_index(k)

                    # give the noise index and dim, to get perturbation
                    # Sample n dimensional noise
                    # perturbation_n = np.sqrt(self.alpha / self.policy.num_params) * self.noise.get(
                    #     noise_index_n, self.policy.num_params)
                    # remove square root and division by num_params
                    perturbation_n = self.alpha * self.noise.get(
                        noise_index_n, self.policy.num_params)

                    # Sample k dimensional noise for surrogate search
                    # and multiply with our surrogate matrix U
                    # perturbation_k = np.sqrt((1 - self.alpha) / k) * np.matmul(U, self.noise.get(g
                    #     noise_index_k, k))
                    # remove the square root and division by k
                    perturbation_k = (1 - self.alpha) * np.matmul(U, self.noise.get(
                        noise_index_k, k))
                    # adding the perturbation from identity and surrogate search will give the new perturbation
                    perturbation = self.noise_stdev * (perturbation_n + perturbation_k)
                    # These two sampling steps could be done in parallel on
                    # different actors letting us update twice as frequently.
                    self.policy.set_weights(params + perturbation)
                    rewards_pos, lengths_pos, value_grad_1, policy_grad_1, rewards_h_1, entropy_1, cost_1 = self.rollout(timestep_limit,
                                                                                         policy_gradient,
                                                                                         add_noise=self.action_noise)

                    self.policy.set_weights(params - perturbation)
                    rewards_neg, lengths_neg, value_grad_2, policy_grad_2, rewards_h_2, entropy_2, cost_2 = self.rollout(timestep_limit,
                                                                                         policy_gradient,
                                                                                         add_noise=self.action_noise)

                    # anneal entropy lower bound
                    if self.anneal_lower_bound:
                        self.entropy_lower = self.entropy_lower * self.anneal_lower_bound_ratio
                    # if self.increase_reward_imp:
                    #     self.reward_scale = self.reward_scale * self.increase_reward_imp_ratio

                    if self.barrier:
                        rewards_h_1, rewards_h_2 = self.entropy_barrier_function(entropy_1, entropy_2, rewards_h_1, rewards_h_2)
                    elif self.safe_exp:
                        rewards_h_1, rewards_h_2 = self.safe_exp_barrier_func(entropy_1, entropy_2, rewards_h_1, rewards_h_2, cost_1, cost_2, iteration)

                    entropy_eval.append([entropy_1, entropy_2])
                    returns_h.append([rewards_h_1, rewards_h_2])
                    noise_indices.append(noise_index_n)
                    noise_indices_k.append(noise_index_k)
                    returns.append([rewards_pos.sum(), rewards_neg.sum()])
                    sign_returns.append(
                        [np.sign(rewards_pos).sum(),
                         np.sign(rewards_neg).sum()])
                    lengths.append([lengths_pos, lengths_neg])
                    cost.append([cost_1, cost_2])

        return Result(
            noise_indices=noise_indices,
            noise_indices_k=noise_indices_k,
            noisy_returns=returns,
            sign_noisy_returns=sign_returns,
            noisy_lengths=lengths,
            eval_returns=eval_returns,
            eval_lengths=eval_lengths,
            value_gradients=value_grad_1,
            policy_gradients=policy_grad_1,
            value_gradients_2=value_grad_2,
            policy_gradients_2=policy_grad_2,
            noisy_ent_evals=entropy_eval,
            noisy_returns_h=returns_h,
            eval_returns_h=eval_returns_h,
            cost=cost,
            eval_cost=eval_cost,
        )


class GESAgent(Agent):
    """Large-scale implementation of Evolution Strategies in Ray."""

    _agent_name = "GES"
    _default_config = DEFAULT_CONFIG

    @override(Agent)
    def _init(self):
        policy_params = {"action_noise_std": self.config["action_noise_std"]}
        self.policy_gradient = self.config["policy_gradient"]

        self.env = self.env_creator(self.config["env_config"])
        from ray.rllib import models
        if self.config["custom_preprocessor"]:
            models.ModelCatalog.register_custom_preprocessor("FourierPreprocessor", FourierPreprocessor)
            file_name = "cartpole"
            scale = np.loadtxt('/cluster/home/vipatil/msc_vihang/configs/' + file_name + '.txt')
            low = scale[0]
            high = scale[1]
            order = self.config["order"]
            options = {"custom_preprocessor": "FourierPreprocessor", "low": low, "high": high, "order": order}
            preprocessor = models.ModelCatalog.get_preprocessor(self.env, options)
        else:
            preprocessor = models.ModelCatalog.get_preprocessor(self.env)

        self.sess = utils.make_session(single_threaded=False)

        if self.policy_gradient:
            print("Using policy gradients as surrogates.")
            ModelCatalog.register_custom_model("my_model", policies.MyModelClass)
            self.policy = policies.AACritic(
                self.sess, self.env.action_space, self.env.observation_space, preprocessor,
                self.config["observation_filter"], self.config["model"],
                **policy_params)
        else:
            print("Using previous estimated gradients as surrogates.")
            self.policy = policies.GenericPolicy(
                self.sess, self.env.action_space, self.env.observation_space, preprocessor,
                self.config["observation_filter"], self.config["model"],
                **policy_params)

        self.optimizer = optimizers.Adam(self.policy, self.config["stepsize"])
        self.report_length = self.config["report_length"]
        self.seed = self.config["seed"]

        # Create the shared noise table.
        logger.info("Creating shared noise table.")
        noise_id = create_shared_noise.remote(self.config["noise_size"], self.seed)
        self.noise = SharedNoiseTable(ray.get(noise_id))

        # Create the actors.
        logger.info("Creating actors.")
        self.workers = [
            Worker.remote(self.config, policy_params, self.env_creator,
                          noise_id) for _ in range(self.config["num_workers"])
        ]
        self.episodes_so_far = 0
        self.reward_list = []
        self.reward_list_mean = []
        self.reward_h_list_mean = []
        self.cost_list_mean = []
        self.tstart = time.time()
        # Track previous k gradients
        self.k = self.config["k"]
        self.prev_k = np.eye(self.policy.num_params, self.k)

        # orthonormal U matrix
        self.U = np.eye(self.policy.num_params, self.k)

        # Annealing of learning rate and step size
        # Noise standard deviation - sigma
        self.noise_stdev = self.config["noise_stdev"]
        self.anneal_noise_stdev = self.config["anneal_noise_stdev"]
        self.anneal_noise_stdev_rate = self.config["anneal_noise_stdev_rate"]
        self.noise_stdev_min = self.config["minimum_noise_stdev"]
        self.noise_stdev_max = self.config["maximum_noise_stdev"]

        # Learning rate - stepsize
        self.stepsize = self.config["stepsize"]
        self.anneal_stepsize = self.config["anneal_stepsize"]
        self.anneal_stepsize_rate = self.config["anneal_stepsize_rate"]
        self.stepsize_min = self.config["minimum_stepsize"]
        self.stepsize_max = self.config["maximum_stepsize"]

        # Add noise to our action probabilities
        self.action_noise = self.config["action_noise"]
        # calculate cosines or not
        self.cosine = self.config["cosine"]

        # if sufficient_increase then store a duplicate copy of the weights
        self.sufficient_increase = self.config["sufficient_increase"]
        if self.sufficient_increase:
            # old weights
            self.weights_t = self.policy.get_weights()
            # power of the scaling factor of the forcing function
            self.scale_exp = self.config["scale_exp"]
            # power of the step size factor of the forcing function
            self.stepsize_exp = self.config["stepsize_exp"]
            # what kind of sufficient increase to be used: mean, min, minmean, popmean
            self.suff_inc_type = self.config["suff_inc_type"]
            # Step size increase rate
        self.increase_stepsize_rate = self.config["increase_stepsize_rate"]
        # noise dev increase rate
        self.increase_noise_rate = self.config["increase_noise_rate"]
        # use return + entropy formulation
        self.sufficient_entropy = self.config["sufficient_entropy"]
        # entropy and reward scale
        self.reward_scale = self.config["reward_scale"]
        self.entropy_scale = self.config["entropy_scale"]
        self.clip_actions = self.config["clip_actions"]
        self.cliff = self.config["cliff"]
        self.store_freq = self.config["store_freq"]
        self.store = self.config["store"]

        # constrain optimization
        self.barrier = self.config["barrier"]
        self.penalty = self.config["penalty"]
        self.rank_penalty = self.config["rank_penalty"]
        self.entropy_upper = self.config["entropy_upper"]
        self.entropy_lower = self.config["entropy_lower"]

        # increase reward importance
        self.increase_reward_imp = self.config["increase_reward_imp"]
        self.increase_reward_imp_ratio = self.config["increase_reward_imp_ratio"]
        self.decrease_reward_imp_ratio = self.config["decrease_reward_imp_ratio"]
        self.reward_imp_upper = self.config["reward_imp_upper"]
        self.reward_imp_lower = self.config["reward_imp_lower"]

        self.alpha = self.config["alpha"]
        self.beta = self.config["beta"]

        # seed
        self.c = self.config["c"]
        self.safe_exp = self.config["safe_exp"]
        self.safe_upper = self.config["safe_upper"]
        self.safe_lower = self.config["safe_lower"]
        self.increase_safe_lb_rate = self.config["increase_safe_lb_rate"]
        self.safe_lb_up_bnd = self.config["safe_lb_up_bnd"]
        self.increase_lb_safe = self.config["increase_lower_bound_safe"]

        self.verification = self.config["verification"]

    def update_prev_grads(self, ch_m):
        """ Update surrogate gradients matrix."""

        self.prev_k = np.roll(self.prev_k, -1, axis=1)
        # Roll the first column as the new last column
        self.prev_k[:, self.k - 1] = ch_m  # append the surrogate gradient as the last column

    def get_cosine(self):
        """
        compute cosine similarity of last two added gradients. Cosine similarity is between 0 - 2, higher the value, more similar are the vectors.
        :return: cosine of the gradients
        """
        grad_k = self.prev_k[:, -1]
        grad_k_1 = self.prev_k[:, -2]

        cos = cosine(grad_k, grad_k_1)

        return cos

    def update_surrogate(self):
        """ QR decomposition of the previous k gradient estimates. Q is orthonormal matrix and r is upper triangular."""

        self.U, _ = np.linalg.qr(self.prev_k)

    def sample_n_k(self, noise_n, noise_k):
        """ Given some n and k dimensional noise get the perturbation."""
        # Sample n dimensional noise
        # perturbation_n = np.sqrt(self.alpha / self.policy.num_params) * noise_n
        # remove sqr root and division by num_params
        perturbation_n = self.alpha * noise_n

        # Sample k dimensional noise for surrogate search
        # and multiply with our surrogate matrix U
        # perturbation_k = np.sqrt((1 - self.alpha) / self.k) * np.matmul(self.U, noise_k)
        # remove sqr root and division by num_params
        perturbation_k = (1 - self.alpha) * np.matmul(self.U, noise_k)

        # adding the perturbation from identity and surrogate search will give the new perturbation
        perturbation = self.noise_stdev * (perturbation_n + perturbation_k)

        return perturbation

    def forcing_func(self):
        """ Return the value of the forcing function. 10 ^ -power_1 * stepsize^power_2.
        Recommended values from GC-ES paper: power_1:-4, power_2:2. """

        # Changed the forcing function according to the new update
        # pow(10, self.scale_exp) * pow(self.noise_stdev, self.stepsize_exp)
        return pow(self.stepsize * self.c * 0.5, 2)

    def entropy_barrier_function(self, rewards_t_h, entropy_t):

        if entropy_t > self.entropy_upper:
            rewards_t_h = self.penalty
        elif entropy_t < self.entropy_lower:
            rewards_t_h = self.penalty
        else:
            rewards_t_h = rewards_t_h

        return rewards_t_h

    def safe_exp_barrier_func(self, rewards_t_h, entropy_t, cost_t):

        if cost_t > self.safe_upper: #or entropy_t > self.entropy_upper:
            rewards_t_h = self.penalty
        elif cost_t < self.safe_lower:# or entropy_t < self.entropy_lower:
            rewards_t_h = self.penalty
        # elif entropy_t < self.entropy_lower:
        #     rewards_t_h = self.penalty
        else:
            rewards_t_h = rewards_t_h

        # if self.iteration > 100:
        #     if self.safe_lower < 0:
        #         self.safe_lower = 0.1
        #     if self.increase_lb_safe:
        #         self.safe_lower = self.safe_lower * self.increase_safe_lb_rate
        #     if self.safe_lower > self.safe_lb_up_bnd:
        #         self.safe_lower = self.safe_lb_up_bnd

        return rewards_t_h

    def sufficient_increase_func(self, theta_new, pop_return_avg_t, pop_return_min_t):
        """ Check if the return_t+1 > return_t - forcing_function. """

        # Sufficient increase conditions:
        # 1) mean: the return at the point new_theta > return at the point old_theta + constant * step_size^2
        # 2) min: the minimum return from a sampled population of the new theta should > minimum return from
        #         a sampled population of the old theta
        # 3) minmean: the minimum return from a sampled population of the new theta should > return at the point old_theta
        # 4) popmean: the average return of the population sampled from new theta > the average return of the
        #             population sampled from old_theta

        # store weights old weights
        self.weights_t = self.policy.get_weights()
        if self.suff_inc_type == "mean":
            # if: Sufficient increase condition type 1

            # Get return for the mean of the population at previous iteration
            rewards_mean_t, _, rews_h, entropy_t, cost_t = policies.rollout(self.policy, self.env, self.cliff, entropy_scale = self.entropy_scale, reward_scale = self.reward_scale, add_noise=False, clip_action = self.clip_actions)
            return_mean_t = np.sum(rewards_mean_t)
            return_mean_t_h = np.sum(rews_h)

            # Get the return for the new updated mean
            self.policy.set_weights(theta_new)
            rewards_mean_t_, _, rews_h_, entropy_t_, cost_t_ = policies.rollout(self.policy, self.env, self.cliff, entropy_scale = self.entropy_scale, reward_scale = self.reward_scale, add_noise=False, clip_action = self.clip_actions)
            return_mean_t_ = np.sum(rewards_mean_t_)
            return_mean_t_h_ = np.sum(rews_h_)

            # Apply the barrier function and obtain the function estimates
            if self.safe_exp:
                return_mean_t_h = self.safe_exp_barrier_func(return_mean_t_h, entropy_t, cost_t)
                return_mean_t_h_ = self.safe_exp_barrier_func(return_mean_t_h_, entropy_t_, cost_t_)
            else:
                return_mean_t_h = self.entropy_barrier_function(return_mean_t_h, entropy_t)
                return_mean_t_h_ = self.entropy_barrier_function(return_mean_t_h_, entropy_t_)

            if self.sufficient_entropy:
                return_mean_t = return_mean_t_h
                return_mean_t_ = return_mean_t_h_

            # Check for the sufficient increase condition
            # If sufficient increase happens update the weights and increase the stepsize
            # Else: discard the new mean, restore the old weights and decrease the stepsize
            increase = return_mean_t_ - return_mean_t
            if return_mean_t_ >= return_mean_t + self.forcing_func():
                successful = 1

                # Increase stdev of the noise - sigma
                if self.noise_stdev >= self.noise_stdev_min and self.anneal_noise_stdev:
                    self.noise_stdev *= self.increase_noise_rate
                    if self.noise_stdev > self.noise_stdev_max:
                        self.noise_stdev = self.noise_stdev_max
                    if self.noise_stdev < self.noise_stdev_min:
                        self.noise_stdev = self.noise_stdev_min

                # Increase the step size - learning rate
                if self.stepsize >= self.stepsize_min and self.anneal_stepsize:
                    # increase the step size - learning rate
                    self.stepsize *= self.increase_stepsize_rate
                    if self.stepsize > self.stepsize_max:
                        self.stepsize = self.stepsize_max
                    if self.stepsize < self.stepsize_min:
                        self.stepsize = self.stepsize_min

                # if return is improving explore more i.e decrease importance of reward
                if self.increase_reward_imp:
                    self.reward_scale = self.reward_scale * self.decrease_reward_imp_ratio
                    if self.reward_scale > self.reward_imp_upper:
                        self.reward_scale = self.reward_imp_upper
                    if self.reward_scale < self.reward_imp_lower:
                        self.reward_scale = self.reward_imp_lower

                # set the use surrogate_gradient flag to True
                use_surrogate_gradient = True
            else:
                successful = 0
                # restore the previous weights
                self.policy.set_weights(self.weights_t)

                # anneal stdev of the noise - sigma
                if self.noise_stdev >= self.noise_stdev_min and self.anneal_noise_stdev:
                    self.noise_stdev *= self.anneal_noise_stdev_rate
                    if self.noise_stdev > self.noise_stdev_max:
                        self.noise_stdev = self.noise_stdev_max
                    if self.noise_stdev < self.noise_stdev_min:
                        self.noise_stdev = self.noise_stdev_min

                # anneal the step size - learning rate
                if self.stepsize >= self.stepsize_min and self.anneal_stepsize:
                    self.stepsize *= self.anneal_stepsize_rate
                    if self.stepsize > self.stepsize_max:
                        self.stepsize = self.stepsize_max
                    if self.stepsize < self.stepsize_min:
                        self.stepsize = self.stepsize_min

                # if the return is not increasing then exploit
                if self.increase_reward_imp:
                    self.reward_scale = self.reward_scale * self.increase_reward_imp_ratio
                    if self.reward_scale > self.reward_imp_upper:
                        self.reward_scale = self.reward_imp_upper
                    if self.reward_scale < self.reward_imp_lower:
                        self.reward_scale = self.reward_imp_lower

                # set the use surrogate_gradient flag to false/true
                use_surrogate_gradient = False

        elif self.suff_inc_type == "popmean":
            # else: sufficient increase condition of type 4

            pop_return_avg_t = pop_return_avg_t

            # Sample a population for the new theta and check for the average return
            theta_vf = self.policy.get_weights_vf()
            # not using value params and pg here, should be using atleast the value params
            # TODO: sample_return not working without calculating policy gradient
            g, _, _, _, _, noisy_returns, _, _, _, _, _,_, _, _ = self.sample_return(theta_new, theta_vf, True, False, self.config["episodes_per_batch"])

            # avg of the return from the population
            pop_return_avg_t_ = np.mean(noisy_returns.flatten())
            increase = pop_return_avg_t_ - pop_return_avg_t
            if pop_return_avg_t_ >= pop_return_avg_t + self.forcing_func():
                # If sufficient increase happens update the weights
                print("Iteration Successful")
                successful = 1
                # Update weights
                self.policy.set_weights(theta_new)

                # Increase stdev of the noise - sigma
                if self.noise_stdev >= self.noise_stdev_min and self.anneal_noise_stdev:
                    self.noise_stdev *= self.increase_noise_rate
                    if self.noise_stdev > self.noise_stdev_max:
                        self.noise_stdev = self.noise_stdev_max
                    if self.noise_stdev < self.noise_stdev_min:
                        self.noise_stdev = self.noise_stdev_min

                # Increase the step size - learning rate
                if self.stepsize >= self.stepsize_min and self.anneal_stepsize:
                    # increase the step size - learning rate
                    self.stepsize *= self.increase_stepsize_rate
                    if self.stepsize > self.stepsize_max:
                        self.stepsize = self.stepsize_max
                    if self.stepsize < self.stepsize_min:
                        self.stepsize = self.stepsize_min

                # set the use surrogate_gradient flag to true
                use_surrogate_gradient = True
            else:
                # Else: discard the new mean and restore the old weights
                print("Iteration Unsuccessful")
                successful = 0

                # set the use surrogate_gradient flag to false
                use_surrogate_gradient = True

                # anneal stdev of the noise - sigma
                if self.noise_stdev >= self.noise_stdev_min and self.anneal_noise_stdev:
                    self.noise_stdev *= self.anneal_noise_stdev_rate
                    if self.noise_stdev > self.noise_stdev_max:
                        self.noise_stdev = self.noise_stdev_max
                    if self.noise_stdev < self.noise_stdev_min:
                        self.noise_stdev = self.noise_stdev_min

                # anneal the step size - learning rate
                if self.stepsize >= self.stepsize_min and self.anneal_stepsize:
                    self.stepsize *= self.anneal_stepsize_rate
                    if self.stepsize > self.stepsize_max:
                        self.stepsize = self.stepsize_max
                    if self.stepsize < self.stepsize_min:
                        self.stepsize = self.stepsize_min

        elif self.suff_inc_type == "relaxed_mean":
            # if: Sufficient increase condition type 5

            # Get return for the mean of the population at previous iteration
            rewards_mean_t, _, rews_h, _ = policies.rollout(self.policy, self.env,self.cliff, entropy_scale = self.entropy_scale, reward_scale = self.reward_scale, add_noise=False, clip_action = self.clip_actions)
            return_mean_t = np.sum(rewards_mean_t)
            return_mean_t_h = np.sum(rews_h)

            # Get the return for the new updated mean
            self.policy.set_weights(theta_new)
            rewards_mean_t_, _, rews_h_, _ = policies.rollout(self.policy, self.env,self.cliff, entropy_scale=self.entropy_scale, reward_scale=self.reward_scale, add_noise=False, clip_action=self.clip_actions)
            return_mean_t_ = np.sum(rewards_mean_t_)
            return_mean_t_h_ = np.sum(rews_h_)

            # if use entropy + return for sufficient decrease condition
            if self.sufficient_entropy:
                return_mean_t = return_mean_t_h
                return_mean_t_ = return_mean_t_h_

            # Check for the sufficient increase condition
            # If sufficient increase happens update the weights and increase the stepsize, add surrogate
            # gradient to the stored gradients
            # Else: update the weights, decrease the stepsize and dont add the surrogate to the stored gradients
            increase = return_mean_t_ - return_mean_t
            if return_mean_t_ >= return_mean_t + self.forcing_func():
                successful = 1

                # Increase stdev of the noise - sigma
                if self.noise_stdev >= self.noise_stdev_min and self.anneal_noise_stdev:
                    self.noise_stdev *= self.increase_noise_rate
                    if self.noise_stdev > self.noise_stdev_max:
                        self.noise_stdev = self.noise_stdev_max
                    if self.noise_stdev < self.noise_stdev_min:
                        self.noise_stdev = self.noise_stdev_min

                # Increase the step size - learning rate
                if self.stepsize >= self.stepsize_min and self.anneal_stepsize:
                    # increase the step size - learning rate
                    self.stepsize *= self.increase_stepsize_rate
                    if self.stepsize > self.stepsize_max:
                        self.stepsize = self.stepsize_max
                    if self.stepsize < self.stepsize_min:
                        self.stepsize = self.stepsize_min

                # use surrogate gradient flag to True
                use_surrogate_gradient = True
            else:
                successful = 0
                # not to restore the previous weights

                # set the use surrogate_gradient flag to false
                use_surrogate_gradient = False

                # anneal stdev of the noise - sigma
                if self.noise_stdev >= self.noise_stdev_min and self.anneal_noise_stdev:
                    self.noise_stdev *= self.anneal_noise_stdev_rate
                    if self.noise_stdev > self.noise_stdev_max:
                        self.noise_stdev = self.noise_stdev_max
                    if self.noise_stdev < self.noise_stdev_min:
                        self.noise_stdev = self.noise_stdev_min

                # anneal the step size - learning rate
                if self.stepsize >= self.stepsize_min and self.anneal_stepsize:
                    self.stepsize *= self.anneal_stepsize_rate
                    if self.stepsize > self.stepsize_max:
                        self.stepsize = self.stepsize_max
                    if self.stepsize < self.stepsize_min:
                        self.stepsize = self.stepsize_min

        return successful, increase, use_surrogate_gradient

    def verification_func(self, theta, theta_vf, calc_pg, eval_ret, min_episodes):
        """ For any given theta, sample a population and return gradient and reward information."""
        config = self.config
        theta = theta

        # Put the current policy weights in the object store.
        theta_id = ray.put(theta)
        # Put the current value weights in the object store.
        theta_id_vf = ray.put(theta_vf)
        # Use the actors to do rollouts, note that we pass in the ID of the
        # policy weights.

        results, num_episodes, num_timesteps = self._collect_results(
            theta_id, theta_id_vf, min_episodes, config["train_batch_size"], policy_gradient=calc_pg,
            eval_return=eval_ret)

        all_noise_indices = []
        all_noise_indices_k = []
        all_training_returns = []
        all_training_lengths = []
        all_eval_returns = []
        all_eval_lengths = []
        all_value_gradients = []
        all_policy_gradients = []
        all_training_entropy = []
        all_training_returns_h = []
        all_eval_returns_h = []
        all_eval_cost = []
        all_cost = []

        # Loop over the results.
        for result in results:
            all_eval_returns += result.eval_returns
            all_eval_lengths += result.eval_lengths
            all_eval_returns_h += result.eval_returns_h
            all_eval_cost += result.eval_cost

            all_noise_indices += result.noise_indices
            all_noise_indices_k += result.noise_indices_k
            all_training_returns += result.noisy_returns
            all_training_lengths += result.noisy_lengths
            all_training_returns_h += result.noisy_returns_h
            all_training_entropy += result.noisy_ent_evals
            all_cost += result.cost

            all_value_gradients.append(result.value_gradients)
            all_value_gradients.append(result.value_gradients_2)
            all_policy_gradients.append(result.policy_gradients)
            all_policy_gradients.append(result.policy_gradients_2)


        assert len(all_eval_returns) == len(all_eval_lengths)
        assert (len(all_noise_indices) == len(all_noise_indices_k) == len(all_training_returns) ==
                len(all_training_lengths))


        # Assemble the results.
        eval_cost = np.array(all_eval_cost)
        eval_returns = np.array(all_eval_returns)
        eval_lengths = np.array(all_eval_lengths)
        noise_indices = np.array(all_noise_indices)
        noise_indices_k = np.array(all_noise_indices_k)
        noisy_returns = np.array(all_training_returns)
        noisy_lengths = np.array(all_training_lengths)
        noisy_cost = np.array(all_cost)

        noisy_returns_h = np.array(all_training_returns_h)
        noisy_entropy = np.array(all_training_entropy)
        eval_returns_h = np.array(all_eval_returns_h)

        return eval_cost, noisy_cost, eval_returns, noisy_returns, noisy_returns_h, noisy_entropy, eval_returns_h


    def sample_return(self, theta, theta_vf, calc_pg, eval_ret, min_episodes):
        """ For any given theta, sample a population and return gradient and reward information."""
        config = self.config
        theta = theta

        # Put the current policy weights in the object store.
        theta_id = ray.put(theta)
        # Put the current value weights in the object store.
        theta_id_vf = ray.put(theta_vf)
        # Use the actors to do rollouts, note that we pass in the ID of the
        # policy weights.

        results, num_episodes, num_timesteps = self._collect_results(
            theta_id, theta_id_vf, min_episodes, config["train_batch_size"], policy_gradient=calc_pg,
            eval_return=eval_ret)

        all_noise_indices = []
        all_noise_indices_k = []
        all_training_returns = []
        all_training_lengths = []
        all_eval_returns = []
        all_eval_lengths = []
        all_value_gradients = []
        all_policy_gradients = []
        all_training_entropy = []
        all_training_returns_h = []
        all_eval_returns_h = []
        all_eval_cost = []
        all_cost = []

        # Loop over the results.
        for result in results:
            all_eval_returns += result.eval_returns
            all_eval_lengths += result.eval_lengths
            all_eval_returns_h += result.eval_returns_h
            all_eval_cost += result.eval_cost

            all_noise_indices += result.noise_indices
            all_noise_indices_k += result.noise_indices_k
            all_training_returns += result.noisy_returns
            all_training_lengths += result.noisy_lengths
            all_training_returns_h += result.noisy_returns_h
            all_training_entropy += result.noisy_ent_evals
            all_cost += result.cost

            all_value_gradients.append(result.value_gradients)
            all_value_gradients.append(result.value_gradients_2)
            all_policy_gradients.append(result.policy_gradients)
            all_policy_gradients.append(result.policy_gradients_2)


        assert len(all_eval_returns) == len(all_eval_lengths)
        assert (len(all_noise_indices) == len(all_noise_indices_k) == len(all_training_returns) ==
                len(all_training_lengths))

        self.episodes_so_far += num_episodes

        # Assemble the results.
        eval_cost = np.array(all_eval_cost)
        eval_returns = np.array(all_eval_returns)
        eval_lengths = np.array(all_eval_lengths)
        noise_indices = np.array(all_noise_indices)
        noise_indices_k = np.array(all_noise_indices_k)
        noisy_returns = np.array(all_training_returns)
        noisy_lengths = np.array(all_training_lengths)
        noisy_cost = np.array(all_cost)

        noisy_returns_h = np.array(all_training_returns_h)
        noisy_entropy = np.array(all_training_entropy)
        eval_returns_h = np.array(all_eval_returns_h)

        # value_gradient = copy.deepcopy(all_value_gradients[0])
        policy_gradient = np.mean(all_policy_gradients, axis=0)
        value_params = np.mean(all_value_gradients, axis=0)

        assert (policy_gradient.shape == (self.policy.num_params,))
        assert (value_params.shape == (self.policy.num_params_vf,))

        # Process the returns.
        # use the maximum entropy return to get ranks
        if config["return_proc_mode"] == "centered_rank":
            proc_noisy_returns = utils.compute_centered_ranks(noisy_returns_h, penalty=self.penalty, rank_penalty=self.rank_penalty, barrier=self.barrier)
        else:
            raise NotImplementedError(config["return_proc_mode"])

        diff = proc_noisy_returns[:, 0] - proc_noisy_returns[:, 1]

        if self.iteration > self.k:  # use n and k dimensional noise
            # Compute and take a step.
            g, count = utils.batched_weighted_sum(
                diff,
                (self.sample_n_k(self.noise.get(index, self.policy.num_params), self.noise.get(index_k, self.k))
                 for index, index_k in zip(noise_indices, noise_indices_k)),
                batch_size=500)

            g /= (noisy_returns.size * pow(self.noise_stdev, 2))
#             g /= (noisy_returns.size * self.noise_stdev)
            g *= self.beta
            assert (g.shape == (self.policy.num_params,) and g.dtype == np.float32
                    and count == len(noise_indices))

        else:  # use the n dimensional noise only
            # Compute and take a step.
            g, count = utils.batched_weighted_sum(
                proc_noisy_returns[:, 0] - proc_noisy_returns[:, 1],
                (self.noise.get(index, self.policy.num_params)
                 for index in noise_indices),
                batch_size=500)
            g /= noisy_returns.size
            assert (g.shape == (self.policy.num_params,) and g.dtype == np.float32
                    and count == len(noise_indices))

        return g, all_eval_returns, eval_returns, noisy_lengths, eval_lengths, noisy_returns, value_params, policy_gradient, noisy_returns_h, noisy_entropy, eval_returns_h, eval_cost, noisy_cost

    @override(Agent)
    def _train(self):
        config = self.config
        successful = -1

        # if self.store and self.iteration % self.store_freq ==0:
        #     self._save("/cluster/home/vipatil/msc_vihang/store")
        #
        # if self.compare_points and self.iteration == 0:
        #     print("Restoring at iteration 1")
        #     self._restore("/cluster/home/vipatil/msc_vihang/store/checkpoint-0")

        #     checkpoint_dir = "/cluster/home/vipatil/msc_vihang/store/"
        #     checkpoint_path = os.path.join(checkpoint_dir,
        #                                    "checkpoint-{}".format(self.iteration))

        # get policy weights
        theta = self.policy.get_weights()
        # get value function weights
        theta_vf = self.policy.get_weights_vf()
        assert theta.dtype == np.float32
        assert theta_vf.dtype == np.float32

        g, all_eval_returns, eval_returns, noisy_lengths, eval_lengths, noisy_returns, value_params, policy_gradient, noisy_returns_h, entropy_evals, eval_returns_h, eval_cost, noisy_cost = self.sample_return(theta, theta_vf, self.policy_gradient, False, config["episodes_per_batch"])

        if self.verification:
            if self.iteration%500 == 0:

                ver_eval_cost, ver_noisy_cost, ver_eval_returns, ver_noisy_returns, ver_noisy_returns_h, ver_noisy_entropy, ver_eval_returns_h = self.verification_func(theta, theta_vf, self.policy_gradient, False, 1000)
                np.savetxt('ver_noisy_cost_' +str(self.iteration) +  '.out', ver_noisy_cost, delimiter=',')
                np.savetxt('ver_eval_cost_' +str(self.iteration) +  '.out', ver_eval_cost, delimiter=',')
                np.savetxt('ver_eval_returns_' +str(self.iteration) +  '.out', ver_eval_returns, delimiter=',')
                np.savetxt('ver_noisy_returns_h_' +str(self.iteration) +  '.out', ver_noisy_returns_h, delimiter=',')
                np.savetxt('ver_noisy_returns_' +str(self.iteration) +  '.out', ver_noisy_returns, delimiter=',')
                np.savetxt('ver_noisy_entropy_' +str(self.iteration) +  '.out', ver_noisy_entropy, delimiter=',')
                np.savetxt('ver_eval_returns_h_' +str(self.iteration) +  '.out', ver_eval_returns_h, delimiter=',')

                sampling_size = [10, 100, 500, 1000]
                for samples in sampling_size:
                    ver_noisy_returns_list = []
                    ver_noisy_cost_list = []
                    for i in range(100):
                        ver_eval_cost, ver_noisy_cost, ver_eval_returns, ver_noisy_returns, ver_noisy_returns_h, ver_noisy_entropy, ver_eval_returns_h = self.verification_func(theta, theta_vf, self.policy_gradient, False, samples)
                        ver_noisy_returns = ver_noisy_returns.flatten()
                        ver_noisy_cost = ver_noisy_cost.flatten()
                        ver_noisy_returns_list.extend(list(ver_noisy_returns))
                        ver_noisy_cost_list.extend(list(ver_noisy_cost))

                    np.savetxt('all_batches_returns_' + str(samples) + '_' +str(self.iteration) +  '.out', np.array(ver_noisy_returns_list), delimiter=',')
                    np.savetxt('all_batches_cost_' + str(samples) + '_' +str(self.iteration) +  '.out', np.array(ver_noisy_cost_list), delimiter=',')

            # compute variance of 10 sampled compare_points
            # compute variance of 50 sampled compare_points
            # compute variance of 100 sampled compare_points
            # compute variance of 200 sampled compare_points
            # 500
            # 800
            # 1000


        # update value params
        self.policy.set_weights_vf(value_params)

        # Compute the new weights theta.
        update_ratio = 0

        # Store the rewards
        self.reward_list.append(np.mean(noisy_returns.flatten()))
        if len(all_eval_returns) > 0:
            self.reward_list_mean.append(np.mean(eval_returns))
            self.reward_h_list_mean.append(np.mean(eval_returns_h))
            self.cost_list_mean.append(np.mean(eval_cost))

        # mean of the return from the population
        # report length controls how many previous values are used for averaging
        pop_ret_avg = np.mean(noisy_returns.flatten())
        pop_ret_min = np.min(noisy_returns.flatten())
        pop_ret_max = np.max(noisy_returns.flatten())
        # replace mean with max, to see the best score
        mean_ret = np.mean(self.reward_list_mean[-self.report_length:])
        cost_mean = np.mean(self.cost_list_mean[-self.report_length:])
        # if len(self.reward_list_mean[-self.report_length:]) == 0:
        #     mean_ret = np.mean(self.reward_list_mean[-self.report_length:])
        # else:
        #     mean_ret = np.amax(self.reward_list_mean[-self.report_length:])
        entropy_avg = np.mean(entropy_evals.flatten())
        entropy_min = np.min(entropy_evals.flatten())
        entropy_max = np.max(entropy_evals.flatten())

        cost_avg = np.mean(noisy_cost.flatten())
        cost_min = np.min(noisy_cost.flatten())
        cost_max = np.max(noisy_cost.flatten())

        pop_ret_h_avg = np.mean(noisy_returns_h.flatten())
        pop_ret_h_min = np.min(noisy_returns_h.flatten())
        pop_ret_h_max = np.max(noisy_returns_h.flatten())
        mean_ret_h = np.mean(self.reward_h_list_mean[-self.report_length:])
        # if len(self.reward_h_list_mean[-self.report_length:]) == 0:
        #     mean_ret_h = np.mean(self.reward_h_list_mean[-self.report_length:])
        # else:
        #     mean_ret_h = np.amax(self.reward_h_list_mean[-self.report_length:])

        if self.iteration <= self.k:
            # g is the estimated gradient
            # track previous k g's

            if self.policy_gradient:
                self.update_prev_grads(policy_gradient)
            else:
                self.update_prev_grads(-g)

            increase = 0

        if self.iteration > self.k:
            # set the step size - learning rate
            self.optimizer.stepsize = self.stepsize

            # update weights only after k iterations
            theta, update_ratio = self.optimizer.update(-g +
                                                        config["l2_coeff"] * theta)

            # if sufficient increase then check if there
            # is some improvement in the return
            if self.sufficient_increase:
                successful, increase, use_surrogate_gradient = self.sufficient_increase_func(theta, pop_ret_avg,
                                                                                             pop_ret_min)

                if self.policy_gradient:
                    self.update_prev_grads(policy_gradient)
                    # Add the estimated gradient
                    if use_surrogate_gradient:
                        self.update_prev_grads(-g)
                else:
                    if successful:
                        # g is the estimated gradient
                        # track previous k g's
                        self.update_prev_grads(-g)
                    else:
                        update_ratio = 0
            else:
                # If not sufficient increase then, directly change the weights
                # of the policy
                # Set the new weights in the local copy of the policy.
                increase = 0
                self.policy.set_weights(theta)
                # g is the estimated gradient
                # track previous k g's
                if self.policy_gradient:
                    self.update_prev_grads(policy_gradient)
                    # Add the estimated gradient
                    self.update_prev_grads(-g)
                else:
                    self.update_prev_grads(-g)

        cos = 0
        if self.iteration > self.k:
            # currently updating the surrogate matrix even if the iteration is not successful - change this later
            # update the surrogate matrix after collecting k gradients
            self.update_surrogate()
            # if self.increase_reward_imp:
            #     self.reward_scale = self.reward_scale * self.increase_reward_imp_ratio

            if self.cosine:
                # get the cosine between previous two gradients
                cos = self.get_cosine()

        # Now sync the filters
        FilterManager.synchronize({
            "default": self.policy.get_filter()
        }, self.workers)

        # value of forcing function
        force_func = 0
        if self.sufficient_increase:
            force_func = self.forcing_func()

        info = {
            "weights_norm": np.square(theta).sum(),
            "grad_norm": np.square(g).sum(),
            "increase": increase,
            "forcing_func": force_func,
            "update_ratio": update_ratio,
            "cosine": cos,
            "episodes_this_iter": noisy_lengths.size,
            "episodes_so_far": self.episodes_so_far,
            "noise_stdev": self.noise_stdev,
            "learning_rate": self.stepsize,
            "num_params_policy": self.policy.num_params,
            "num_params_value": self.policy.num_params_vf,
            "Shape_pg": np.shape(policy_gradient),
            "reward_scale":self.reward_scale,
        }

        result = dict(
            successful=successful,
            episode_reward_pop=pop_ret_avg,
            episode_reward_mean=mean_ret,
            episode_reward_min=pop_ret_min,
            episode_reward_max=pop_ret_max,
            episode_reward_h_pop=pop_ret_h_avg,
            episode_reward_h_mean=mean_ret_h,
            episode_reward_h_min=pop_ret_h_min,
            episode_reward_h_max=pop_ret_h_max,
            entropy_max=entropy_max,
            entropy_avg=entropy_avg,
            entropy_min=entropy_min,
            cost_mean=cost_mean,
            cost_pop=cost_avg,
            cost_max=cost_max,
            cost_min=cost_min,
            episode_len_mean=noisy_lengths.mean(),
            timesteps_this_iter=noisy_lengths.sum(),
            info=info)

        logger.info(
            "This iteration was:{}".format(successful))

        return result

    @override(Agent)
    def compute_action(self, observation):
        return self.policy.compute(observation, update=False)[0]

    @override(Agent)
    def _stop(self):
        # workaround for https://github.com/ray-project/ray/issues/1516
        for w in self.workers:
            w.__ray_terminate__.remote()

    def _collect_results(self, theta_id, theta_id_vf, min_episodes, min_timesteps, policy_gradient, eval_return):
        num_episodes, num_timesteps = 0, 0
        results = []
        noise = self.noise_stdev
        # num_timesteps is usefull when we want to sample more initially.
        while num_episodes < min_episodes:  # or num_timesteps < min_timesteps:
            logger.info(
                "Collected {} episodes {} timesteps so far this iter".format(
                    num_episodes, num_timesteps))
            rollout_ids = [
                worker.do_rollouts.remote(theta_id, theta_id_vf, self.alpha, self.U, self.iteration, self.k,
                                          noise, policy_gradient, eval_return, self.reward_scale) for worker in self.workers
            ]
            # Get the results of the rollouts.
            for result in ray.get(rollout_ids):
                results.append(result)
                # Update the number of episodes and the number of timesteps
                # keeping in mind that result.noisy_lengths is a list of lists,
                # where the inner lists have length 2.
                num_episodes += sum(len(pair) for pair in result.noisy_lengths)
                num_timesteps += sum(
                    sum(pair) for pair in result.noisy_lengths)

        return results, num_episodes, num_timesteps

    def __getstate__(self):
        return {
            "weights": self.policy.get_weights(),
            "filter": self.policy.get_filter(),
            "episodes_so_far": self.episodes_so_far,
        }

    def __setstate__(self, state):
        self.episodes_so_far = state["episodes_so_far"]
        self.policy.set_weights(state["weights"])
        self.policy.set_filter(state["filter"])
        FilterManager.synchronize({
            "default": self.policy.get_filter()
        }, self.workers)
