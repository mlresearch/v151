import os, sys

sys.path.append(os.getcwd())

import time
import tflib as lib
import tflib.save_images
# import tflib.mnist
import tflib.cifar10
import tflib.plot
# pip install tensorflow-gpu==1.6.0
# pip install tensorflow-gpu==1.15.0
import tflib.inception_score

import numpy as np

import torch
import torchvision
from torch import nn
from torch import autograd
from torch import optim
from ComplexMachine import ComplexSGD
import pandas as pd
import cmath
import gc
import copy


def create_pandas_log_table():
    stats_table = pd.DataFrame(
        columns=['dataset', 'network', 'epoch', 'optimizer', 'lr_re', 'lr_complex', 'momentum_mass',
                 'momentum_mass_complex',
                 'loss_G',
                 'loss_D', 'neg_log_like',
                 'lr_mag', 'lr_arg', 'momentum_mag', 'momentum_arg', 'w_distance_d',
                 ]
    )
    return stats_table


# Taken from https://github.com/caogang/wgan-gp/blob/master/gan_cifar10.py
# and fixed to work in new pytorch versions...
def run_gan_cifar_10(optimizer_G_fn, optimizer_D_fn, optimizer_G_params, optimizer_D_params, outdir=None):
    # Download CIFAR-10 (Python version) at
    # https://www.cs.toronto.edu/~kriz/cifar.html and fill in the path to the
    # extracted files here!
    DATA_DIR = './data/cifar-10-batches-py/'
    if len(DATA_DIR) == 0:
        raise Exception('Please specify path to data directory in gan_cifar.py!')

    MODE = 'wgan-gp'  # Valid options are dcgan, wgan, or wgan-gp
    DIM = 128  # This overfits substantially; you're probably better off with 64
    LAMBDA = 10  # Gradient penalty lambda hyperparameter
    CRITIC_ITERS = 5  # How many critic iterations per generator iteration
    BATCH_SIZE = 64  # Batch size
    ITERS = 100001 #200000  # How many generator iterations to train for
    OUTPUT_DIM = 3072  # Number of pixels in CIFAR10 (3*32*32)
    print('ITERS:'+str(ITERS))
    class Generator(nn.Module):
        def __init__(self):
            super(Generator, self).__init__()
            preprocess = nn.Sequential(
                nn.Linear(128, 4 * 4 * 4 * DIM),
                nn.BatchNorm1d(4 * 4 * 4 * DIM),
                nn.ReLU(True),
            )

            block1 = nn.Sequential(
                nn.ConvTranspose2d(4 * DIM, 2 * DIM, 2, stride=2),
                nn.BatchNorm2d(2 * DIM),
                nn.ReLU(True),
            )
            block2 = nn.Sequential(
                nn.ConvTranspose2d(2 * DIM, DIM, 2, stride=2),
                nn.BatchNorm2d(DIM),
                nn.ReLU(True),
            )
            deconv_out = nn.ConvTranspose2d(DIM, 3, 2, stride=2)

            self.preprocess = preprocess
            self.block1 = block1
            self.block2 = block2
            self.deconv_out = deconv_out
            self.tanh = nn.Tanh()

        def forward(self, input):
            output = self.preprocess(input)
            output = output.view(-1, 4 * DIM, 4, 4)
            output = self.block1(output)
            output = self.block2(output)
            output = self.deconv_out(output)
            output = self.tanh(output)
            return output.view(-1, 3, 32, 32)

    class Discriminator(nn.Module):
        def __init__(self):
            super(Discriminator, self).__init__()
            main = nn.Sequential(
                nn.Conv2d(3, DIM, 3, 2, padding=1),
                nn.LeakyReLU(),
                nn.Conv2d(DIM, 2 * DIM, 3, 2, padding=1),
                nn.LeakyReLU(),
                nn.Conv2d(2 * DIM, 4 * DIM, 3, 2, padding=1),
                nn.LeakyReLU(),
            )

            self.main = main
            self.linear = nn.Linear(4 * 4 * 4 * DIM, 1)

        def forward(self, input):
            output = self.main(input)
            output = output.view(-1, 4 * 4 * 4 * DIM)
            output = self.linear(output)
            return output

    netG = Generator()
    netD = Discriminator()
    print(netG)
    print(netD)

    use_cuda = torch.cuda.is_available()
    if use_cuda:
        gpu = 0
    if use_cuda:
        netD = netD.cuda(gpu)
        netG = netG.cuda(gpu)

    one = torch.tensor(1.0)  # ([1])
    mone = one * -1
    if use_cuda:
        one = one.cuda(gpu)
        mone = mone.cuda(gpu)

    OUT_DIR = './tmp/cifar10/' if outdir is None else outdir

    os.makedirs(OUT_DIR, exist_ok=True)
    print(f'OUT_DIR: {OUT_DIR}')

    stats_table = create_pandas_log_table()
    stats_table.to_csv(OUT_DIR + '/stats.csv', index=False, header=True)

    if optimizer_D_fn is None:
        optimizerD = optim.Adam(netD.parameters(), lr=1e-4, betas=(0.5, 0.9))
    else:
        if optimizer_D_fn == optim.SGD:
            print('optimizer falling to SGD')
            # if optimizer is SGD, let's be sure is real for speed, but keep optimizer_D_params as theey are for logging.
            temp_D = copy.deepcopy(optimizer_D_params)
            temp_D['lr'] = np.real(temp_D['lr'])
            temp_D['momentum'] = np.real(temp_D['momentum'])
            optimizerD = optimizer_D_fn(netD.parameters(), **temp_D)
        else:
            optimizerD = optimizer_D_fn(netD.parameters(), **optimizer_D_params)

    if optimizer_G_fn is None:
        optimizerG = optim.Adam(netG.parameters(), lr=1e-4, betas=(0.5, 0.9))
    else:
        optimizerG = optimizer_G_fn(netG.parameters(), **optimizer_G_params)

    print(optimizerD)
    print(optimizerG)

    ##Logging the discriminator optimizer.  assuming the generator is the same or we are ignoring it.
    lr_d = optimizer_D_params['lr'] + 0.j
    cm_d = optimizer_D_params['momentum'] + 0.j
    lr_mag, lr_arg = cmath.polar(lr_d)
    momentum_mag, momentum_arg = cmath.polar(cm_d)
    # Stats...
    print(
        f'Discriminator Stats for Logging LR: {lr_d} Momentum: {cm_d}\nLR :mag:{lr_mag:.4} arg: {lr_arg} Momentum :mag:{momentum_mag:.4} arg: {momentum_arg}')

    def calc_gradient_penalty(netD, real_data, fake_data):
        # print "real_data: ", real_data.size(), fake_data.size()
        alpha = torch.rand(BATCH_SIZE, 1)
        alpha = alpha.expand(BATCH_SIZE, int(real_data.nelement() / BATCH_SIZE)).contiguous().view(BATCH_SIZE, 3, 32,
                                                                                                   32)
        alpha = alpha.cuda(gpu) if use_cuda else alpha

        interpolates = alpha * real_data + ((1 - alpha) * fake_data)

        if use_cuda:
            interpolates = interpolates.cuda(gpu)
        interpolates = autograd.Variable(interpolates, requires_grad=True)

        disc_interpolates = netD(interpolates)

        gradients = autograd.grad(outputs=disc_interpolates, inputs=interpolates,
                                  grad_outputs=torch.ones(disc_interpolates.size()).cuda(
                                      gpu) if use_cuda else torch.ones(
                                      disc_interpolates.size()),
                                  create_graph=True, retain_graph=True, only_inputs=True)[0]
        gradients = gradients.view(gradients.size(0), -1)

        gradient_penalty = ((gradients.norm(2, dim=1) - 1) ** 2).mean() * LAMBDA
        return gradient_penalty

    # For generating samples
    def generate_image(frame, netG):
        fixed_noise_128 = torch.randn(128, 128)
        if use_cuda:
            fixed_noise_128 = fixed_noise_128.cuda(gpu)

        with torch.no_grad():
            noisev = fixed_noise_128  # autograd.Variable(fixed_noise_128, volatile=True)
            samples = netG(noisev)
            samples = samples.view(-1, 3, 32, 32)
            samples = samples.mul(0.5).add(0.5)
            samples = samples.cpu().data.numpy()

            lib.save_images.save_images(samples, OUT_DIR + 'samples_{:08}.jpg'.format(frame))

    # For calculating inception score
    def get_inception_score(G, ):
        all_samples = []
        # removing stochasticity from rs
        rs = np.random.RandomState(0)
        for i in range(10):
            # samples_100 = torch.randn(100, 128)
            # work around to always get same seed
            samples_100 = torch.from_numpy(rs.randn(100, 128)).float()
            if use_cuda:
                samples_100 = samples_100.cuda(gpu)
            samples_100 = samples_100  # autograd.Variable(samples_100, volatile=True)
            all_samples.append(G(samples_100).cpu().data.numpy())

        all_samples = np.concatenate(all_samples, axis=0)
        all_samples = np.multiply(np.add(np.multiply(all_samples, 0.5), 0.5), 255).astype('int32')
        all_samples = all_samples.reshape((-1, 3, 32, 32)).transpose(0, 2, 3, 1)
        print('running inception....')
        return lib.inception_score.get_inception_score(list(all_samples))

    # Dataset iterator
    train_gen, dev_gen = lib.cifar10.load(BATCH_SIZE, data_dir=DATA_DIR)

    def inf_train_gen():
        while True:
            for images in train_gen():  # , target in train_gen():
                # yield images.astype('float32').reshape(BATCH_SIZE, 3, 32, 32).transpose(0, 2, 3, 1)
                yield images

    gen = inf_train_gen()
    preprocess = torchvision.transforms.Compose([
        torchvision.transforms.ToTensor(),
        torchvision.transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5)),
    ])

    for iteration in range(ITERS):
        start_time = time.time()
        ############################
        # (1) Update D network
        ###########################
        for p in netD.parameters():  # reset requires_grad
            p.requires_grad = True  # they are set to False below in netG update
        for i in range(CRITIC_ITERS):
            _data = next(gen)  # gen.next()
            netD.zero_grad()

            # train with real
            _data = _data.reshape(BATCH_SIZE, 3, 32, 32).transpose(0, 2, 3, 1)
            real_data = torch.stack([preprocess(item) for item in _data])

            if use_cuda:
                real_data = real_data.cuda(gpu)
            real_data_v = autograd.Variable(real_data)

            D_real = netD(real_data_v)
            D_real = D_real.mean()
            D_real.backward(mone)

            # train with fake
            noise = torch.randn(BATCH_SIZE, 128)
            if use_cuda:
                noise = noise.cuda(gpu)
            noisev = noise  # autograd.Variable(noise, volatile=True)  # totally freeze netG
            fake = netG(noisev)  # autograd.Variable(netG(noisev).data)
            inputv = fake
            D_fake = netD(inputv)
            D_fake = D_fake.mean()
            D_fake.backward(one)

            # train with gradient penalty
            gradient_penalty = calc_gradient_penalty(netD, real_data_v.data, fake.data)
            gradient_penalty.backward()

            # print "gradien_penalty: ", gradient_penalty

            D_cost = D_fake - D_real + gradient_penalty
            Wasserstein_D = D_real - D_fake
            optimizerD.step()
        ############################
        # (2) Update G network
        ###########################
        for p in netD.parameters():
            p.requires_grad = False  # to avoid computation
        netG.zero_grad()

        noise = torch.randn(BATCH_SIZE, 128)
        if use_cuda:
            noise = noise.cuda(gpu)
        noisev = autograd.Variable(noise)
        fake = netG(noisev)
        G = netD(fake)
        G = G.mean()
        G.backward(mone)
        G_cost = -G
        optimizerG.step()

        # Write logs and save samples
        lib.plot.plot(OUT_DIR + 'train disc cost', D_cost.cpu().data.numpy())
        lib.plot.plot(OUT_DIR + 'time', time.time() - start_time)
        lib.plot.plot(OUT_DIR + 'train gen cost', G_cost.cpu().data.numpy())
        lib.plot.plot(OUT_DIR + 'wasserstein distance', Wasserstein_D.cpu().data.numpy())

        # Calculate inception score every 1K iters
        if iteration % 10000 == 999:
            print(f'Computing inception score.... iteration {iteration}')
            inception_score = get_inception_score(netG)
            lib.plot.plot(OUT_DIR + 'inception score', inception_score[0])
            print('inception score done')
            sys.stdout.flush()
        elif iteration == 0:
            # let's compute it to have normalized results in the heatmaps....
            # inception_score = -1
            print(f'Computing inception score.... iteration {iteration}')
            if use_cuda is True:
                inception_score = get_inception_score(netG)
                print('inception score done')
                sys.stdout.flush()
            else:
                print('no cuda skipping...')
                inception_score = -1
        else:
            inception_score = -1

        # forcing printing ....
        sys.stdout.flush()
        ##logging csv...
        curr_loss_G_val = G_cost.cpu().data.numpy()
        curr_loss_D_val = D_cost.cpu().data.numpy()
        # columns = ['dataset', 'network', 'epoch', 'optimizer', 'lr_re', 'lr_complex', 'momentum_mass',
        #            'momentum_mass_complex',
        #            'loss_G',
        #            'loss_D', 'neg_log_like',
        #            'lr_mag', 'lr_arg', 'momentum_mag', 'momentum_arg',w_distance
        #            ]
        w_distance_d_ = Wasserstein_D.cpu().data.numpy()
        stats_table.loc[len(stats_table)] = ['CIFAR-10', 'wgan-gp-cifar10', lib.plot._iter[0] + 1,
                                             str(optimizerD.__class__.__name__),
                                             np.real(lr_d),
                                             np.imag(lr_d),
                                             np.real(cm_d),  # args.momentum_mass,
                                             np.imag(cm_d), curr_loss_G_val, curr_loss_D_val,
                                             inception_score,
                                             lr_mag, lr_arg, momentum_mag, momentum_arg, w_distance_d_]

        isnan = np.isnan(curr_loss_D_val).any().item() or np.isnan(curr_loss_G_val).any().item() or np.isnan(
            w_distance_d_).any().item()

        if (iteration % 5000) == 0 or isnan is True:
            print('\nPartially Saving stats....')
            fname = OUT_DIR + '/stats.csv'  # out_dir + '/stats.csv'

            # if file does not exist write header
            if not os.path.isfile(fname):
                stats_table.to_csv(fname, header=True, index=False)
            else:  # else it exists so append without writing the header
                stats_table.to_csv(fname, mode='a', header=False, index=False)

            # clear the memory if this grows then it becomes slow
            print('\nClearing Stats from memory')
            del stats_table
            gc.collect()
            # stats_table = None
            stats_table = create_pandas_log_table()

        # Calculate dev loss and generate samples every 100 iters
        if iteration % 100 == 99:
            dev_disc_costs = []
            for images in dev_gen():  # _ in dev_gen():
                images = images.reshape(BATCH_SIZE, 3, 32, 32).transpose(0, 2, 3, 1)
                imgs = torch.stack([preprocess(item) for item in images])

                # imgs = preprocess(images)
                if use_cuda:
                    imgs = imgs.cuda(gpu)
                imgs_v = imgs  # autograd.Variable(imgs, volatile=True)

                D = netD(imgs_v)
                _dev_disc_cost = -D.mean().cpu().data.numpy()
                dev_disc_costs.append(_dev_disc_cost)
            lib.plot.plot(OUT_DIR + 'dev disc cost', np.mean(dev_disc_costs))

            generate_image(iteration, netG)

        # Save logs every 100 iters
        if (iteration < 5) or (iteration % 100 == 99):
            lib.plot.flush(OUT_DIR)
        lib.plot.tick()

        if isnan is True:
            print(f'NAN detected... stopping {curr_loss_D_val}, {curr_loss_G_val}')
            return 1
            # break
        sys.stdout.flush()


if __name__ == "__main__":
    optimizerG_fn = optim.SGD
    optimizerG_params = {'lr': 1e-4, 'momentum': 0.5}

    optimizerD_fn = ComplexSGD
    # a≈0.46194 ∧ b≈0.191342 -- with this abs(momentum)=0.5 and phase=pi/8
    optimizerD_params = {'lr': 1e-4 + 0.0j, 'momentum': 0.46 + 0.19j}

    # optimizerD_fn = optim.SGD
    # optimizerD_params = {'lr': 1e-4, 'momentum': 0.5}

    run_gan_cifar_10(optimizer_D_fn=optimizerD_fn, optimizer_D_params=optimizerD_params, optimizer_G_fn=optimizerG_fn,
                     optimizer_G_params=optimizerG_params, outdir='./tmp/opt_sgd_complex_try/')

    exit(1)

    # Default Params.....
    # optimizerD_fn = optim.Adam
    # optimizerD_params = {'lr': 1e-4, 'betas': (0.5, 0.9)}
    #
    # # ---
    # optimizerG_fn = optim.Adam
    # optimizerG_params = {'lr': 1e-4, 'betas': (0.5, 0.9)}
    #
    # run_gan_cifar_10(optimizer_D_fn=optimizerD_fn, optimizer_D_params=optimizerD_params, optimizer_G_fn=optimizerG_fn,
    #                  optimizer_G_params=optimizerG_params, outdir='./tmp/defaults_adam')

    # ...
    # wgap-gp
    # gen_train_op = tf.train.AdamOptimizer(learning_rate=1e-4, beta1=0.5, beta2=0.9).minimize(gen_cost, var_list=gen_params)
    # disc_train_op = tf.train.AdamOptimizer(learning_rate=1e-4, beta1=0.5, beta2=0.9).minimize(disc_cost,

    # wgan
    # gen_train_op = tf.train.RMSPropOptimizer(learning_rate=5e-5).minimize(gen_cost, var_list=gen_params)
    # disc_train_op = tf.train.RMSPropOptimizer(learning_rate=5e-5).minimize(disc_cost, var_list=disc_params)
