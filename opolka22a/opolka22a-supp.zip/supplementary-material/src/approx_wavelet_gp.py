import argparse
import pathlib
import random
import sys

import pygsp.graphs.graph
import tensorflow as tf
import numpy as np
import gpflow
from gpflow.inducing_variables import InducingPoints
from scipy.cluster.vq import kmeans2

from data_loading.node_prediction_dataset import NodePredictionDataset
from graph_svgp import GraphSVGP
from kernels.chebyshev_kernel import SubgraphChebyshev

from kernels.wavelet_kernel import SubgraphAdaptiveApproximateWavelet
from metrics import compute_multiclass_accuracy
from training_environment import Trainer, PerformanceLogger
from wavelet_utils import low_pass_filter_from_string, band_pass_filter_from_string

parser = argparse.ArgumentParser('Dynamic Graph Differential Gaussian Processes')
parser.add_argument('--data_dir', type=str, default="../../data/", help='Path at which to store PyTorch Geometric datasets and look for precomputed files.')
parser.add_argument('--dataset', type=str, default="Cora", help='Name of the PyTorch Geometric dataset to evaluate on.')
parser.add_argument('--proj_mat_path', type=str, default="proj_mat.npy", help='Path of the pre-computed AdaptiveWaveletKernel projection matrix if available.')
parser.add_argument('--proj_mat_base', type=str, default="proj_mat", help='Path of the pre-computed AdaptiveWaveletKernel projection matrix up to the same, which allows adding `datasetname.npy`.')
parser.add_argument('--split_seed', type=int, default=None, help='If not None, a random train/val/test split is generated.')
parser.add_argument('--train_on_val', type=bool, default=False, help='If True, the training and validation set are concatenated to form the new training set.')
parser.add_argument('--train_frac', type=float, default=0.9, help='If not None, the model is only trained on a fraction of the original training data.')

parser.add_argument('--optimizer', type=str, default="adam", help='Indicates the optimizer to use (either `adam` or `scipy`)')
parser.add_argument('--lr', type=float, default=0.01, help='Learning rate')
parser.add_argument('--num_epochs', type=int, default=201, help='Number of epochs')

parser.add_argument('--seed', type=int, default=0, help='Random seed')
parser.add_argument('--float_type', type=np.dtype, default="float64", help='Floating point type used for all models')
parser.add_argument('--jitter', type=float, default=1e-6, help='Amount of jitter added to the covariance matrix to guarantee invertibility')
parser.add_argument('--kernel', type=str, default="wavelet_approx", help='Name of the GP kernel to use (options `wavelet`, `wavelet_approx`, `chebyshev`)')
parser.add_argument('--poly_degree', type=int, default=5, help='Degree of the polynomial used to approximate the wavelet filters (only relevant if kernel is set to `wavelet_approx` or `chebyshev`)')
parser.add_argument('--low_filter', type=str, default="low", help='Name of the low-pass filter to use (only `low` supported)')
parser.add_argument('--band_filter', type=str, default="mexican_hat_normalized", help='Name of the band-pass filter to use (only `mexican_hat`, `mexican_hat_normalized`, `morlet` supported)')
parser.add_argument('--low_pass_scale', type=float, default=5.0, help='Parameter of the low-pass filter')
parser.add_argument('--band_pass_scale1', type=float, default=0.4, help='Parameter of the first band-pass filter')
parser.add_argument('--band_pass_scale2', type=float, default=0.8, help='Parameter of the second band-pass filter')
parser.add_argument('--sd_steps_divider', type=int, default=512, help='')
parser.add_argument('--sd_degree', type=int, default=5, help='')
parser.add_argument('--sd_samples', type=int, default=10, help='')

try:
    args = parser.parse_args()
except:
    parser.print_help()
    sys.exit(0)


def training_step(data_loader, model, optimizer, logger):
    for node_feats, labels, normalized_L, center_idcs in data_loader:
        model.kernel.set_subgraph(normalized_L, center_idcs)
        with tf.GradientTape(watch_accessed_variables=False) as tape:
            tape.watch(model.trainable_variables)
            loss = -model.elbo((node_feats, labels))
            gradients = tape.gradient(loss, model.trainable_variables)
        optimizer.apply_gradients(zip(gradients, model.trainable_variables))
        logger.add_values({"nELBO": loss.numpy()})
    logger.compute_metrics("train")


def evaluation_step(data_loader, model, logger):
    gpflow.utilities.print_summary(model)
    for node_feats, labels, normalized_L, center_idcs in data_loader:
        model.kernel.set_subgraph(normalized_L, center_idcs)
        pred_y, pred_y_var = model.predict_y(node_feats)
        likelihood = model.predict_log_density((node_feats, labels))
        logger.add_values({f"test_preds": pred_y.numpy(),
                           f"test_pred_vars": pred_y_var.numpy(),
                           f"test_likelihood": likelihood.numpy(),
                           f"test_labels": labels.numpy().reshape(-1),
                           f"test_inputs": node_feats.numpy()})
    logger.compute_metrics("test")


def setup_training_env(args):
    metric_funcs = {
        "train": {
            "nELBO": lambda m: np.mean(m["nELBO"]),
            # "train_acc": lambda m: compute_multiclass_accuracy(m["train_predictions"], m["train_labels"])
        },
        "val": {
            "val_acc": lambda m: compute_multiclass_accuracy(m["test_preds"], m["test_labels"])
        },
        "test": {
            "test_acc": lambda m: compute_multiclass_accuracy(m["test_preds"], m["test_labels"])
        },
    }
    log_dir_path = pathlib.Path("./log/")
    log_filepath = log_dir_path / "log.pk"
    results_filepath = log_dir_path / "results.pk"
    logger = PerformanceLogger(metric_funcs=metric_funcs, minimizer="nELBO",
                               log_filepath=log_filepath, results_filepath=results_filepath,
                               tf_log_dir=log_dir_path, summary_prefix="-> ",
                               minimizer_phases=["train", "val"], one_time_phases=["test"])
    trainer = Trainer(config=args, logger=logger)

    # Set random seed
    random.seed(trainer.conf.seed)
    np.random.seed(trainer.conf.seed)
    tf.random.set_seed(trainer.conf.seed)
    # Set float type
    gpflow.config.set_default_float(trainer.conf.float_type)
    gpflow.config.set_default_jitter(trainer.conf.jitter)

    return trainer


def run_training():
    trainer = setup_training_env(args)

    # Dataset definition
    ds = NodePredictionDataset(trainer.conf.dataset, trainer.conf.data_dir,
                               split_seed=trainer.conf.split_seed, float_type=np.float64,
                               train_frac=trainer.conf.train_frac)
    train_loader, val_loader, test_loader = ds.get_data_loaders(
        num_hops=trainer.conf.poly_degree, train_batch_size=140, val_batch_size=140,
        test_batch_size=140, subsample_sizes=(5, 5, 5, 3, 3), train_on_val=trainer.conf.train_on_val)
    graph = pygsp.graphs.graph.Graph(ds.get_adj_matrix())
    graph.compute_laplacian("normalized")
    normalized_L = graph.L.todense()

    # Projection matrix path
    if trainer.conf.proj_mat_base is not None:
        proj_mat_path = trainer.conf.proj_mat_base + f"_{trainer.conf.dataset.lower()}.npy"
    else:
        proj_mat_path = trainer.conf.proj_mat_path

    # Kernel and likelihood definition
    base_kernel = gpflow.kernels.Polynomial()
    low_f = low_pass_filter_from_string(trainer.conf.low_filter)
    band_f = band_pass_filter_from_string(trainer.conf.band_filter)
    if trainer.conf.kernel == "wavelet_approx":
        kernel = SubgraphAdaptiveApproximateWavelet(
            normalized_L=normalized_L, base_kernel=base_kernel, poly_degree=trainer.conf.poly_degree,
            node_feats=ds.features.astype(np.float64), low_filter=low_f, band_filter=band_f,
            low_pass=trainer.conf.low_pass_scale, scales=(trainer.conf.band_pass_scale1, trainer.conf.band_pass_scale2),
            proj_mat_path=proj_mat_path, sd_steps_divider=trainer.conf.sd_steps_divider, sd_degree=trainer.conf.sd_degree,
            sd_samples=trainer.conf.sd_samples)
    elif trainer.conf.kernel == "chebyshev":
        kernel = SubgraphChebyshev(normalized_L=normalized_L, poly_degree=trainer.conf.poly_degree,
                                   node_feats=ds.features.astype(np.float64), base_kernel=base_kernel)
    invlink = gpflow.likelihoods.RobustMax(ds.num_classes)  # Robustmax inverse link function
    likelihood = gpflow.likelihoods.MultiClass(ds.num_classes, invlink=invlink)  # Multiclass likelihood

    inducing_inputs = InducingPoints(kmeans2(ds.features, len(ds.train_idx), minit="points")[0])
    model = GraphSVGP(kernel, likelihood=likelihood, inducing_variable=inducing_inputs,
                      num_latent_gps=ds.num_classes, num_data=len(ds.train_idx))

    opt = tf.optimizers.Adam(lr=trainer.conf.lr)
    trainer.train_model(model, trainer.conf.num_epochs, eval_every=20,
                        train_step_f=lambda model: training_step(train_loader, model, opt, trainer.logger),
                        val_step_f=lambda model: evaluation_step(val_loader, model, trainer.logger),
                        test_step_f=lambda model: evaluation_step(test_loader, model, trainer.logger))


if __name__ == '__main__':
    run_training()