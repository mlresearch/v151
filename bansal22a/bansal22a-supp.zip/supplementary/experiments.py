from mechanisms import *
import concurrent.futures
import time
import numpy as np
from scipy.stats import cauchy
from numpy import random
import matplotlib.pyplot as plt
import itertools
import sys


num_workers = 90

### GLOBAL PARAMETERS ####
numHists = 100 # take 100 histograms
numIters = 100 # runs of algorithm per histogram
numBars = 100 # default number of bars

def histogram(vals, nBars):
	bins = [0] * nBars
	for x in vals:
		v = int(np.round(x))
		if v < 0 or v >= nBars:
			continue
		bins[v] += 1
	return bins


# data functions

def getCauchyHist(nBars=numBars,rightMargin=10,median=45,scale=4,k=1):
	hist = histogram(list(cauchy.rvs(median, scale, size=10000)), nBars-rightMargin)
	hist.extend([0] * rightMargin)
	budget = int(sum(hist) * alpha)
	err, fxerr = errsMax(k,hist,budget)
	return hist, err, fxerr

def mkStepHist(steps):
	#each step is (val,tillindex)
	nbars = steps[-1][1]
	hist = [0] * nbars
	previndex = 0
	for st in steps:
		val, tillindex = st
		for i in range(previndex, tillindex):
			hist[i] = val
		previndex = tillindex
	return hist

def getMaxStepHist(nBars=numBars):
	k = 500
	hist = mkStepHist([(540,nBars//2),(490,nBars)])
	budget = alpha * sum(hist)
	err, fxerr = errsMax(k,hist,budget)
	return hist, err, fxerr

def getModeStepHist():
	hist = mkStepHist([(130,120),(200,125),(185,210),(190,220),(130,300)])
	#hist.extend([130] * 20) 
	# add some noise
	noise = random.laplace(0, 0.5, size=len(hist))
	hist = list((np.array(hist) + noise).astype(int))

	budget = alpha * sum(hist)
	err, fxerr = errsMode(hist,budget)
	return hist, err, fxerr

def getMaxHardHist(nBars=numBars):
	k = 1
	hist = mkStepHist([(1000,nBars//2),(5,nBars)])
	budget = alpha * sum(hist)
	err, fxerr = errsMax(1,hist,budget)
	return hist, err, fxerr


def getPoissonHist(nBars=numBars, poissonMean=250):
	hist = random.poisson(lam=poissonMean, size=nBars)
	budget = alpha * sum(hist)
	err, fxerr = errsMode(hist,budget)
	return hist, err, fxerr

# value could be negative (e.g., for max_k when no bar >= k exists)
def getError(val, err):
	val = int(np.round(val))
	if val < 0:
		return err[0] + abs(val)
	if val >= len(err):
		return err[-1] + val - len(err) + 1

	return err[val]

# get accuracies : parallelized. 
def getAccuracies(eps, plot, mechs):
	data = alldata[plot]
	all_ans = {}
	tot_trials = numHists * numIters
	for algo in mechs:
		acc, acc_f = 0, 0
		for i in range(numHists):
			hist, err, fxerr = data[i]
			nbars = len(hist)
			for _ in range(numIters):
				ans = plotmech[algo](plot, hist, eps, err)
				acc += getError(ans, err)
				acc_f += getError(ans, fxerr)
			accpair = (acc * 100)/ (nbars * tot_trials), (acc_f * 100)/ (nbars * tot_trials)
			all_ans[algo] = accpair
	# print(str([eps, plot]), "done")
	return all_ans

# for plotting
def revHist(hist):
	b = []
	for i in range(len(hist)):
		for j in range(hist[i]):
			b.append(i)
	return b

#############
# PLOTS SETUP
#############

plots = ['max1_cauchy', 'max1_hard', 'max500_cauchy', 'max500_step', 'mode_poisson', 'mode_step']

datagen = { 'max1_cauchy'       : getCauchyHist,
	    'max1_hard'       : getMaxHardHist,
	    'max500_step'     : getMaxStepHist,
	    'max500_cauchy'  : lambda: getCauchyHist(rightMargin=0,k=500),
	    'mode_step'     : getModeStepHist,
	    'mode_poisson': lambda : getPoissonHist(nBars=30) }

mechanisms = [ 'SS', 'sanPoints','exponential', 'PTR', 'BNS', 'TrLap', 'ESA']

lineColor = { 'TrLap'      : 'blue',
	      'BNS'        : 'red',
	      'PTR'        : 'brown',
	      'exponential': 'green',
	      'SS'         : 'orange',
	      'sanPoints'  : 'cyan',
	      'ESA'        :  'black' }

plotfun = { 'max1_cauchy'   : lambda hist: getIndexMax(hist,1),
	        'max1_hard'   : lambda hist: getIndexMax(hist,1),
            'max500_cauchy' : lambda hist: getIndexMax(hist,500),
            'max500_step' : lambda hist: getIndexMax(hist,500),
            'mode_step' : getIndexMode,
            'mode_poisson' : getIndexMode }

plotmech =  { 'TrLap' : lambda f,hist,eps,err: plotfun[f](getTrLapHist(hist,eps)),
              'BNS'   : lambda f,hist,eps,err: plotfun[f](getBNSHist(hist,eps)),
              'ESA'   : lambda f,hist,eps,err: plotfun[f](getESAHist(hist,eps)),
              'PTR'   : lambda f,hist,eps,err: getPTRmax(hist,eps,1) if f=='max1_cauchy' or f =='max1_hard'  
                                         else (getPTRmax(hist,eps,500) if f=='max500_step' or f=='max500_cauchy'
                                               else getPTRmode(hist,eps)),
	      'exponential': lambda f,hist,eps,err: getExpAns(hist, eps, err),
	      'SS' : lambda f,hist,eps,err: getSSMax(hist,eps, 1) if f=='max1_cauchy' or f =='max1_hard' 
                                         else (getSSMax(hist,eps,500) if f=='max500_step' or f=='max500_cauchy'
                                               else getSSMode(hist,eps)),
	      'sanPoints' : lambda f,hist,eps,err: plotfun[f](getSanPoints(hist,eps, 0.75))	}
	
epsrange = {'max1_cauchy' : np.linspace(0.3, 1.8, 101),
	    'max1_hard' : np.linspace(0.3, 1.8, 101),
	    'max500_step' : np.linspace(0.2, 1.7, 101),
	    'max500_cauchy' : np.linspace(0.2, 1.7, 101),
	    'mode_step'   : np.linspace(0.2, 1.7, 101),
	    'mode_poisson': np.linspace(0.01, 1.51, 101)}

# main code

if len(sys.argv) > 1:
	plot_num = int(sys.argv[1]) - 1
	plots = [plots[plot_num]]
	

# generate all data
alldata = {}
for f in plots:
	alldata[f] = [datagen[f]() for _ in range(numHists)]

# output sample histograms
for f in plots:
	sample = alldata[f][0][0]
	ylimit = int(max(sample)*1.15)
	print(ylimit)
	plt.ylim((0,ylimit))
	plt.hist(revHist(sample), bins=len(sample), color='black')
	plt.xticks([])
	plt.yticks([])
	filename = 'hist_' + f + '.pdf'
	plt.savefig(filename,  bbox_inches='tight')
	plt.clf()

print("all data generated")
print("Data Statistics:")
for f in plots:
	sums = [sum(alldata[f][i][0]) for i in range(len(alldata[f]))]
	print('For plot ' + f + ' #items: max = ' + str(max(sums)) + ' min= ' + str(min(sums)))
	#print('   sample: ' + str(alldata[f][0][0]))


# start plotting
plotData = {}
futures = {}
with concurrent.futures.ProcessPoolExecutor(max_workers=num_workers) as executor:
	for f in plots:
		plotData[f] = {}
		futures[f] = {}
		for eps in epsrange[f]:
			plotData[f][eps] = {}
			#print("Submitted ", str([eps, f]))
			future = executor.submit(getAccuracies, eps, f, mechanisms)
			futures[f][eps] = future
	for f in plots:
		print("computing plot ", str(f))
		for eps in epsrange[f]:
			plotData[f][eps] = futures[f][eps].result()
			print(".", end="", flush=True)
		print("done")

print("all computation done")


for f in plots:
	fData = plotData[f]
	pts = []
	y_acc = {}
	y_flex_acc = {}
	for algo in mechanisms:
		y_acc[algo] = []
		y_flex_acc[algo] = []
	for eps in fData:
		pts.append(eps)
		for algo in mechanisms:
			y_acc[algo].append(fData[eps][algo][0])
			y_flex_acc[algo].append(fData[eps][algo][1])
	for a in mechanisms:
		plt.plot(pts, y_acc[a], label=a, color=lineColor[a], linestyle=":")
		plt.plot(pts, y_flex_acc[a], label=a, color=lineColor[a])
	plt.ylim((0,80))
	plt.savefig(f + ".pdf", bbox_inches='tight')
	plt.clf()

	# print summary
	print("summary")
	print("\n", f, "function")
	print("Start eps", pts[0])
	for algo in mechanisms:
		print(algo, "%.2f"%y_acc[algo][0], end=",")
	print("\nFlexacc")
	for algo in mechanisms:
		print(algo, "%.2f"%y_flex_acc[algo][0], end=",")
	print("")

	print("End eps", pts[-1])
	for algo in mechanisms:
		print(algo, "%.2f"%y_acc[algo][-1], end=",")
	print("\nFlexacc")
	for algo in mechanisms:
		print(algo, "%.2f"%y_flex_acc[algo][-1], end=",")
	print("")
	

print("plotting done")
