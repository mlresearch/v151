clear all


f = 0.5*pi; %Frequency at which the toplogy is recnstructed
d= 8; %% maximum number of one-hop and two-hop neighbors of a node in the graph. For a 2D grid, d=8
epsilon = 0.7; %% accuracy of reconstruction
num_trial = 20; %% number of trials 
Nnodes =16;
C1=zeros(Nnodes,Nnodes,num_trial);
load(strcat('p',num2str(Nnodes),'.mat'));
lag = 3;
n =6560;
[IPSD_analytical,PSDX_analytical,WF,H] = Model_at_f(Adj,h,f,E_factor);
[L,U,m_i,n_bound,m] = Constants_at_f(IPSD_analytical,WF, epsilon,d);
[C,delta] = C_delta(E_factor,h,lag);

N =100; % floor(4*C*real(U)*delta/(1-delta)^2);

Lambda = 0 ; 
%%
for trial = 1:num_trial
Big_Matrix = Covaraiance_corr(n,E_factor,N,h,f,lag);
C1(:,:,trial) = Big_Matrix;
end
save(strcat('LeastSquares_C_',int2str(n) ,'.mat'), 'C1')


%% Regularized Wiener Filter
error = 500*ones(num_trial,1);
for trial =1:num_trial
Big_Matrix = C1(:,:,trial);    
RWFE = zeros(Nnodes,Nnodes);
for i= 1:Nnodes
i_bar = setdiff(1:Nnodes,i);
R=Big_Matrix(i_bar,i_bar);
P1 = Big_Matrix(i_bar,i);
P2 = Big_Matrix(i,i_bar);
cvx_begin 
variable param(Nnodes-1,1) complex 
minimize (  real(param'*R*param) -real(param'*P1) -real(P2*param) +real(Lambda*sum(abs(param))));    
cvx_end
RWFE(i,i_bar)= param;
end
%% Reconstructing the Topology from the Winer filter estimate
Recon_Top = zeros(Nnodes,Nnodes);
for i = 1:Nnodes
   for j = i+1:Nnodes 
       if abs(imag(RWFE(i,j)))+abs(imag(RWFE(j,i)))>0.028
            Recon_Top(i,j)=1;Recon_Top(j,i)=1;
       end 
   end
end
error(trial) = sum(sum(abs(Recon_Top-Adj)))/sum(sum(Adj));
error(trial)

end
