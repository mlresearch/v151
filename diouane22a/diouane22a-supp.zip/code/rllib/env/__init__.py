from ray.rllib.env.async_vector_env import AsyncVectorEnv
from ray.rllib.env.multi_agent_env import MultiAgentEnv
from ray.rllib.env.external_env import ExternalEnv
from ray.rllib.env.serving_env import ServingEnv
from ray.rllib.env.vector_env import VectorEnv
from ray.rllib.env.env_context import EnvContext
import pybullet_envs
import safety_gym
from gym.envs.registration import register

register(
    id='CartSafe-v0',
    entry_point='ray.rllib.env.my_env.envs:CartSafeEnv',
    max_episode_steps=200,
    reward_threshold=520.0,
)

register(
    id='MountainCarContinuousSafe-v0',
    entry_point='ray.rllib.env.my_env.envs:Continuous_MountainCarSafeEnv',
    reward_threshold=90,
    max_episode_steps=999,
)

#import safety_gym
#import gym_safety
#import gym_gridworlds

__all__ = [
    "AsyncVectorEnv", "MultiAgentEnv", "ExternalEnv", "VectorEnv",
    "ServingEnv", "EnvContext"
]
