import sys
sys.path.append("./../")
import matplotlib.pyplot as plt
from jax import random
import numpy as np
from nt_transferV1 import *
import numpy as onp
from nt_transferV1.nn_models import model_dict
from nt_transferV1.plot_tools import *
import matplotlib.ticker as ticker
import pickle

gen_kwargs_supervised = dict(
ntt_file_name = 'mnist_layerwise_prune_cnn_lenet_caffe', # the saved result in ntt_results file
dataset_str  = 'mnist', # dataset to use'
sup_density_list = [0.01,0.02,0.03,0.04,0.05],  # the density levels to achieve'
OPTIMIZER_STR = 'adam', # optimizer'
EXPLOITATION_NUM_EPOCHS = 100, #number of training epochs'
EXPLOITATION_BATCH_SIZE  = 64, # number of samples in a minibatch'
STEP_SIZE = 1e-4, # learning step-size'
REG = 1e-8, # l2 regularization constant'
EXPLOIT_TRAIN_DATASET_FRACTION = 0.1, # the fraction of training data used as validation data'
RECORD_ACC_FREQ = 2000, # frequency for saving the training and testing result'  
save_supervised_result_bool = True)



model = exploit_model(ntt_file_name = gen_kwargs_supervised['ntt_file_name'], ntt_saved_path = './ntt_results/', supervised_result_path = './supervised_results/')

# Proposed method: NTT sparse initialization
sup_learning_results_ntt_init = model.supervised_optimization(wiring_str = 'trans',  ** gen_kwargs_supervised)
