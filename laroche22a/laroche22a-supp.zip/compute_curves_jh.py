# Implementation to visualise the results
import pickle
import pandas as pd
import os
import operator
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1 import ImageGrid
import matplotlib.cm as cm
import matplotlib.patches as pat
from matplotlib import rc
from mpl_toolkits.mplot3d import Axes3D
from pylab import *
import seaborn
from mpl_toolkits.axes_grid1 import AxesGrid
import matplotlib.ticker as ticker
from utils import prt

NUM_COLORS = 10
cm = plt.get_cmap('gist_rainbow')
rc('text', usetex=True)
plt.rc('text.latex', preamble=r'\usepackage{amsmath}')


def shiftedColorMap(cmap, start=0, midpoint=0.5, stop=1.0, name='shiftedcmap'):
    '''
    Function to offset the "center" of a colormap. Useful for
    data with a negative min and positive max and you want the
    middle of the colormap's dynamic range to be at zero.

    Input
    -----
      cmap : The matplotlib colormap to be altered
      start : Offset from lowest point in the colormap's range.
          Defaults to 0.0 (no lower offset). Should be between
          0.0 and `midpoint`.
      midpoint : The new center of the colormap. Defaults to 
          0.5 (no shift). Should be between 0.0 and 1.0. In
          general, this should be  1 - vmax / (vmax + abs(vmin))
          For example if your data range from -15.0 to +5.0 and
          you want the center of the colormap at 0.0, `midpoint`
          should be set to  1 - 5/(5 + 15)) or 0.75
      stop : Offset from highest point in the colormap's range.
          Defaults to 1.0 (no upper offset). Should be between
          `midpoint` and 1.0.
    '''
    cdict = {
        'red': [],
        'green': [],
        'blue': [],
        'alpha': []
    }

    span = 11
    
    # regular index to compute the colors
    reg_index = np.linspace(start, stop, 2001 + span)

    # shifted index to match the data
    shift_index = np.hstack([
        np.linspace(0.0, midpoint, 1000, endpoint=False), 
        np.linspace(midpoint, 1.0, 1001, endpoint=True)
    ])

    for idx, si in enumerate(shift_index):
        sumr = 0
        sumg = 0
        sumb = 0
        suma = 0
        for i in range(span):
            r, g, b, a = cmap(reg_index[idx+i])
            sumr += r
            sumg += g
            sumb += b
            suma += a

        cdict['red'].append((si, sumr/span, sumr/span))
        cdict['green'].append((si, sumg/span, sumg/span))
        cdict['blue'].append((si, sumb/span, sumb/span))
        cdict['alpha'].append((si, suma/span, suma/span))

    newcmap = matplotlib.colors.LinearSegmentedColormap(name, cdict)
    plt.register_cmap(cmap=newcmap)

    return newcmap

def retrieve_name(algo):
    if algo['discounting'] == 'jh':
        return r'J\&H on-policy $\alpha=' + str(algo['alpha']) + '$'
    if algo['discounting'] == 'jh2':
        return r'J\&H off-policy $\alpha=' + str(algo['alpha']) + '$'
    entropy = ''
    if algo['lambada'] > 0:
        entropy = ' + entropy'
    return algo['discounting'] + entropy
    
def repair_name(name, lambada):
    if 'theory' in name:
        name = name.replace('theory', 'PG update')
        name = name.replace(' + entropy', '')
        name += ', $\lambda=' + str(lambada) + '$'
    if 'practice' in name:
        name = name.replace('practice', 'undiscounted update')
        name = name.replace(' + entropy', '')
        name += ', $\lambda=' + str(lambada) + '$'
    name = name.replace('d_{t}', 'o_{t}')
    name = name.replace(' $o_{t}', ', $o_{t}')
    name = name.replace('p_t', 'o_{t}')
    name = name.replace(' h_counts', '')
    return name
                       

def compute_stats_of_interest(path):
    absfiles = []
    files = os.listdir(path)
    for fil in files:
        if fil.endswith('.pkl'):
            absfiles.append(path + fil)
    if not os.path.isdir(path + 'curves'):
        os.mkdir(path + 'curves')
    
    filename = path + "curves/stats_of_interest.pkl"
    if False:
    # if os.path.isfile(filename):
        print("\nLoading compiled results from file {}".format(filename), flush=True)
        with open(filename, "rb") as f:
            stats_dic = pickle.load(f)
            print("Compiled results loaded.")
    else:
        resultVect = {}
        nb_files = 0
        for fil in absfiles:
            print(fil)
            # try:
            with (open(fil, "rb")) as openfile:
                expe = pickle.load(openfile)
                algos = expe['cfg']['algos']
                setting = expe['cfg']['setting']
                for algo in algos:
                    if 'name' in algo.keys():
                        name = repair_name(algo['name'], algo['lambada'])
                    else:
                        name = retrieve_name(algo)
                    if name not in resultVect.keys():
                        resultVect[name] = {}
                        for perf in algo['res'].keys():
                            nb_points = len(algo['res'][perf])
                            if nb_points % 10 == 0:
                                scale = expe['cfg']['max_nb_it']/nb_points
                            else:
                                scale = expe['cfg']['max_nb_it']/(nb_points-1)
                            resultVect[name][perf] = np.zeros((0, nb_points))
                    for perf in algo['res'].keys():
                        # resultVect[name][perf] = np.vstack([resultVect[name][perf],np.array(algo['res'][perf])])
                        resultVect[name][perf] = np.vstack([resultVect[name][perf],(np.array(algo['res'][perf])-expe['p_rand'])/(expe['p_star']-expe['p_rand'])])  
                if 'baselines' not in resultVect.keys():
                    resultVect['baselines'] = {}
                    resultVect['baselines']['pstar'] = np.zeros((0, nb_points))
                    resultVect['baselines']['prand'] = np.zeros((0, nb_points))
                resultVect['baselines']['pstar'] = np.vstack([resultVect['baselines']['pstar'], np.ones(nb_points)])
                resultVect['baselines']['prand'] = np.vstack([resultVect['baselines']['prand'], np.zeros(nb_points)])
                nb_files += 1
            # except:
            #     print('Could not open it.')
        print(str(nb_files) + ' records have been processed.')
        curve_types = {'mean': 1, 'median': 2, 'decile': 10, 'percentile': 100}
        stats_dic = {}
        for name in resultVect.keys():
            stats_dic[name] = {}
            for perf in resultVect[name].keys():
                stats_dic[name][perf] = {}
                for curve in curve_types.keys():
                    if curve == 'mean':
                        stats_dic[name][perf][curve] = np.mean(resultVect[name][perf], axis=0)
                    else:
                        stats_dic[name][perf][curve] = np.quantile(resultVect[name][perf], 1/curve_types[curve], axis=0)

        output_file = path + "curves/stats_of_interest.pkl"
        with open(output_file, 'wb') as f:
            print("\nSaving stats of interest in file {}".format(output_file), flush=True)
            pickle.dump(stats_dic, f)
    return stats_dic, setting, scale

def print_curve_chain_exact(path, var, prefix=''):
    
    if not os.path.isdir(path):
        os.mkdir(path)
    
    if not os.path.isdir(path + 'curves'):
        os.mkdir(path + 'curves')

    filename = prefix + path + "curves/stats_of_interest.pkl"
    # if False:
    if os.path.isfile(filename):
        print("\nLoading compiled results from file {}".format(filename), flush=True)
        with open(filename, "rb") as f:
            resultVect = pickle.load(f)
            environment = 'Random MDPs'
            print("Compiled results loaded.")
    else:
        resultVect = {}
        absfiles = []
        files = os.listdir(prefix + path)
        for fil in files:
            if fil.endswith('.pkl'):
                absfiles.append(prefix + path + fil)
        for fil in absfiles:
            print(fil)
            with (open(fil, "rb")) as openfile:
                # try:
                expe = pickle.load(openfile)
                algos = expe['cfg']['algos']
                environment = expe['cfg']['environment']
                for algo in algos:
                    if var == 'lr':
                        idx = algo['actor_stepsize']
                        idx = int(np.round(20*(4+np.log10(idx))))
                    elif var == 'qinit':
                        idx = algo['init_q']
                        idx = int(np.round(100*idx))
                    elif var == 'offpol':
                        idx = algo['offpol_param']
                        idx = int(np.round(100*idx))
                    elif var == 'epsilon':
                        idx = algo['hyde_param']
                        idx = int(np.round(100*idx))
                    elif var == 'clr':
                        idx = algo['critic_stepsize']
                        idx = int(np.round(20*(3+np.log10(idx))))
                    elif var == 'cucblr':
                        idx = algo['critic_UCB_stepsize']
                        idx = int(np.round(20*(4+np.log10(idx))))
                    elif var == 'lambada':
                        idx = algo['lambada']
                        idx = int(np.round(10*(4+np.log10(idx))))
                    else:
                        idx = expe['cfg'][var]
                        if var == 'vr':
                            idx = int(np.round(100*idx))
                    name = repair_name(algo['name'], algo['lambada'])
                    if name not in resultVect.keys():
                        resultVect[name] = {}
                        for perf in algo['res'].keys():
                            resultVect[name][perf] = np.zeros(1001)
                            resultVect[name]['counts'] = np.ones(1001)*0.0000001
                    resultVect[name]['counts'][idx] += 1
                    for perf in algo['res'].keys():
                        resultVect[name][perf][idx] += algo['res'][perf]
        print(str(len(absfiles)) + ' files loaded.')
  
    fig = plt.figure(figsize=(6, 4))
    mpl.rcParams['xtick.labelsize'] = 11 
    mpl.rcParams['ytick.labelsize'] = 11
    ax = fig.add_subplot(111)
    last_percentile = {}

    if var == 'vr':
        x = np.arange(100)/100
        plt.xlim(0, 1)
        plt.xlabel(r'value ratio $\beta$', fontsize=13)
    if var == 'qinit':
        x = np.arange(101)/100
        plt.xlim(0, 1)
        plt.xlabel(r'critic initialization $q_0$', fontsize=13)
    if var == 'offpol':
        x = np.arange(101)/100
        plt.xlim(0, 1)
        plt.xlabel(r'off-policiness $o_t$', fontsize=13)
    if var == 'epsilon':
        x = np.arange(101)/100
        plt.xlim(0, 1)
        plt.xlabel(r'Hyde selection ratio $\epsilon_t$', fontsize=13)
    # if var == 'lr':
    #     plt.xlabel(r'actor learning rate $\eta$', fontsize=13)
    #     plt.xscale('log')
    #     plt.xlim(0.1, 1000)
    #     x = 10**(np.arange(101)/10 - 2)
    if var == 'lr':
        plt.xlabel(r'actor learning rate $\eta$', fontsize=13)
        plt.xscale('log')
        plt.xlim(0.001, 1000)
        x = 10**(np.arange(1001)/20 - 4)
    if var == 'clr':
        plt.xlabel(r'critic learning rate $\eta_c$', fontsize=13)
        plt.xscale('log')
        plt.xlim(0.01, 1)
        x = 10**(np.arange(61)/20 - 3)
    if var == 'cucblr':
        plt.xlabel(r'UCB critic learning rate $\eta_u$', fontsize=13)
        plt.xscale('log')
        plt.xlim(0.0001, 1)
        x = 10**(np.arange(81)/20 - 4)
    if var == 'lambada':
        plt.xlabel(r'entropic regularization weight $\lambda$', fontsize=13)
        plt.xscale('log')
        plt.xlim(0.0001, 1)
        x = 10**(np.arange(51)/10 - 4)
    if var == 'nb_states':
        plt.xlabel('number of states $|\mathcal{S}|$', fontsize=13)
        x = np.arange(1000)
        plt.xlim(4, 15)
    if var == 'nb_actions':
        plt.xlabel('number of actions $|\mathcal{A}|$', fontsize=13)
        x = np.arange(1000)
        plt.xlim(2, 11)

    for name in resultVect.keys():
        for perf in resultVect[name].keys():
            if perf != 'counts':
                c = 'solid'
                where = np.where(resultVect[name]['counts']>0.5)
                if name.startswith('PG'):
                    c = (0, (3.0, 3.0))
                if name.startswith('undis'):
                    c = (3, (3.0, 3.0))
                # if var == 'vr':
                #     y = resultVect[name][perf][:100]/resultVect[name]['counts'][:100]
                # if var == 'lr':
                #     y = resultVect[name][perf][:51]/resultVect[name]['counts'][:51]
                # if var == 'lambada':
                #     y = resultVect[name][perf][:51]/resultVect[name]['counts'][:51]
                # if var == 'nb_states':
                y = resultVect[name][perf]/resultVect[name]['counts']
                print(name)
                print(x[where])
                print(y[where])
                plt.plot(x[where], y[where], linestyle=c, label=r''+ name, linewidth=2)

    # plt.xscale('log')
    # plt.ylabel(r'performance', fontsize=13)
    if environment == 'chain':
        plt.ylabel(r'time to reach $\overline{\mathcal{J}}_\pi=0.5$', fontsize=13)
    elif environment == 'cliff':
        plt.ylabel(r'time to reach $\overline{\mathcal{J}}_\pi=0.5$', fontsize=13)
    else:
        plt.ylabel(r'time to reach $\overline{\mathcal{J}}_\pi=0.95$', fontsize=13)
    # plt.ylim(0.25, 0.6)
    # plt.ylim(-3, 1)
    # plt.ylim(-1, 1)
    # plt.ylim(-2.5, 1)
    # plt.xlim(10, 10**4)
    # plt.xlim(3, 40)
    plt.title(environment)
    plt.ylim(0, 10000)
    plt.legend(frameon=False, prop={'size': 13})
    plt.tight_layout()
    filename = path + "curves/results.pdf"
    plt.savefig(filename)
    print('plot saved at : ' + filename)
    # plt.clf()
    plt.close(fig)  


def load_stats(name):
    filename = "curves/" + name + "/stats_of_interest.pkl"
    print("\nLoading stats of interest from file {}".format(filename), flush=True)
    with open(filename, "rb") as f:
        stats = pickle.load(f)
        print("Stats of interest loaded.")
        print(stats)
    return stats


def curves_by_N_min(name, path, stats, setting, scale):
    curve_types = [
                    {'mean': 1},
                    # {'median': 2},
                    {'decile': 10},
                    # {'percentile': 100},
                    # {'permille': 1000},
                    # {'mean': 1, 'percentile': 100},
                    # {'mean': 1, 'decile': 10, 'percentile': 100}
                  ]
    for curve_type in curve_types:
        saveCurveWithStats(name, path, stats, curve_type, setting, scale)



def saveCurveWithStats(name, path, stats, curve_type_names_dic, setting, scale):
    fig = plt.figure(figsize=(6, 4))
    mpl.rcParams['xtick.labelsize'] = 11 
    mpl.rcParams['ytick.labelsize'] = 11
    ax = fig.add_subplot(111)
    x = np.arange(stats['baselines']['pstar'][list(curve_type_names_dic.keys())[0]].shape[0])
    if len(x) % 10 == 0:
        x += 1
    x = scale*x
    last_percentile = {}

    for curve_type_name in curve_type_names_dic.keys():
        for algo in stats.keys():
            if False:
            # if 'perf_jekyll' in stats[algo].keys():
                plt.plot(x, stats[algo]['perf_jekyll'][curve_type_name], label=algo)
            else:
                for perf in stats[algo].keys():
                    c = 'solid'
                    if algo.startswith('PG'):
                        c = (0, (3.0, 3.0))
                    if algo.startswith('undis'):
                        c = (3, (3.0, 3.0))
                    if (not algo.startswith('J')) or perf == 'perf_jekyll':
                    # if (not algo.startswith('J')) or perf == 'perf_glob':
                    # if True:
                        if algo.startswith('baselines'):
                            plt.plot(x, stats[algo][perf][curve_type_name], linestyle = ':', color = 'black', linewidth=1)
                        else:
                            plt.plot(x, stats[algo][perf][curve_type_name], linestyle = c, label=r''+ algo, linewidth=2,alpha=0.75)
                        print(algo + ': ' + str(stats[algo][perf][curve_type_name][-1]))

    # plt.xscale('log')
    if setting == 'sample':
        plt.xlabel('number of trajectories', fontsize=13)
        plt.ylabel(r'normalized expected return $\overline{\mathcal{J}}_\pi$', fontsize=13)
    else:
        plt.xlabel('number of updates', fontsize=13)
        plt.ylabel(r'normalized expected return $\overline{\mathcal{J}}_\pi$', fontsize=13)
    # plt.ylim(0.25, 0.6)
    # plt.ylim(-3, 1)
    # plt.ylim(-1, 1)
    # plt.ylim(-2.5, 1)
    # plt.xlim(10, 10**4)
    plt.xlim(x[0], x[-1])
    # plt.xlim(0, 10000)
    plt.ylim(-0.05, 1.001)
    # plt.ylim(0.98, 1.001)
    plt.locator_params(axis='y', nbins=3)
    # plt.ylim(stats['baselines']['pstar'][list(curve_type_names_dic.keys())[0]][0]*0.95-0.0001, stats['baselines']['pstar'][list(curve_type_names_dic.keys())[0]][0]+0.0001)
    plt.legend(frameon=False, prop={'size': 13})
    plt.tight_layout()
    filename = path + "curves/results_abs_" + str(list(curve_type_names_dic.keys())).replace(" ", "") + ".pdf"
    plt.savefig(filename)
    print('plot saved at : ' + filename)
    # plt.clf()
    plt.close(fig)



# names = ['results/sample-direct-garnets3/expes/']
# names = ['results/sample-softmax-garnets/expes/']
# names = ['results/chain-sample-softmax-exprep/']
# names = ['results/garnets-sample-softmax-criticlr/']
# names = ['results/garnets-sample-softmax-epsilon/']
# names = ['results/garnets-sample-softmax-epsilon-jek-eval/']
# names = ['results/garnets-sample-softmax-epsilon-jek-eval-099/']
# names = ['results/chain-sample-softmax-epsilon-jek-eval/']
# names = ['results/garnets-sample-softmax-learningrate/']
# names = ['results/garnets-sample-softmax-offpol/']
# names = ['results/garnets-sample-softmax-qinit/']
# names = ['results/garnets-sample-softmax/']
# names = ['results/garnets-sample-softmax-eta=10/']
# names = ['results/exprep2/']
# names = ['results/exprep2-ucb/']
# names = ['results/exprep2-ucb2/']
# names = ['results/exprep-long/']
# names = ['expes/chain-sample-softmax-exprep-ucb/']
# names = ['expes/chain-sample-softmax-exprep-prio/']
# names = ['expes/chain-sample-softmax-exprep-criticlr/']
# names = ['expes/chain-sample-softmax-exprep-epsilon/']
# names = ['expes/chain-sample-softmax-exprep-learningrate/']
# names = ['expes/chain-sample-softmax-exprep-offpol/']
# names = ['expes/chain-sample-softmax-exprep-qinit/']
# names = ['expes/chain-sample-softmax-exprep-ratio/']
# names = ['expes/chain-sample-softmax-exprep-states/']
# names = ['expes/chain_exact-direct-ratio/']
# names = ['expes/chain_exact-direct-learningrate/']
# names = ['expes/chain_exact-direct-nb_states/']
# names = ['expes/chain_exact-direct-softmax-nb_states/']
# names = ['expes/cliff_exact-direct-softmax-nb_states/']
# names = ['expes/chain_exact-direct/']
# names = ['expes/chain_exact-softmax-ratio/']
# names = ['expes/chain_exact-softmax-learningrate/']
# names = ['expes/chain_exact-softmax-lambda/']
# names = ['expes/chain_exact-softmax-nb_states/']
# names = ['expes/chain_exact-softmax/']
# names = ['expes/garnets_exact-direct/']
# names = ['expes/fig-8ab-direct/']
# names = ['expes/fig-11a-direct-pg-clr=1/']
# names = ['expes/fig-11a-hyb/']
names = ['expes/fig-actions-hi/']
# names = ['expes/fig-11a-direct-sqrt/']
# names = ['expes/fig-11b-pg-vbigclr/']
# names = ['expes/fig-11b-pg-vlowclr/']
# names = ['expes/fig-11b-hyb-lo/']
# names = ['expes/fig-cliff-hi/']
# names = ['expes/fig-cliff-states-hi/']
# names = ['expes/fig-11b-low/','expes/fig-11b-hi/','expes/fig-11b-no/']
# names = ['expes/fig-11a-low/','expes/fig-11a-hi/','expes/fig-11a-no/']
# names = ['expes/fig-14a-no/']
# ,'expes/fig-14a-hi/','expes/fig-14a-no/']
# names = ['expes/fig-11b-direct-vlowclr/']
# names = ['expes/garnets_exact-softmax/']
# names = ['expes/fourrooms-sample-softmax-exprep/']
# names = ['expes/fourrooms-sample-softmax-exprep-15/']
# names = ['expes/fourrooms-sample-softmax-exprep-20/']
# names = ['expes/fourrooms-sample-softmax-exprep-15--0.1/']
# names = ['expes/test/']
prefix = ''
# prefix = '//gcrstor03/saferl/PG/FiniteJH/'

for name in names:
    path = name

    # stats, setting, scale = compute_stats_of_interest(path)
    # curves_by_N_min(name, path, stats, setting, scale)

    # print_curve_chain_exact(path, 'clr')
    # print_curve_chain_exact(path, 'epsilon')
    # print_curve_chain_exact(path, 'lr', prefix=prefix)
    print_curve_chain_exact(path, 'nb_actions', prefix=prefix)
    # print_curve_chain_exact(path, 'offpol')
    # print_curve_chain_exact(path, 'qinit')
    # print_curve_chain_exact(path, 'vr')
    # print_curve_chain_exact(path, 'nb_states')

    # print_curve_chain_exact(path, 'lambada')
    
    # print_curve_chain_exact(path, 'cucblr')

