from utils.enums import *

import tensorflow as tf
import tensorflow.keras.backend as KB
from tensorflow.keras.losses import Loss

class ContrastiveLossV1(Loss):  # the customized contrastive loss
    def __init__(self, margin = 0.5):
        super(ContrastiveLossV1, self).__init__()
        self.margin = margin

    def call(self, output, truth):  # truth = (Y, extra things)
        Y = truth[:, 0]
        output = tf.reshape(output, [-1])
        return (1.0 - Y) * 0.5 * KB.square(output) + Y * 0.5 * KB.square(KB.maximum(0.0, self.margin - output))


class KerasLossWrapper(object):  # the loss wrapper that maps from enum to the corresponding loss implementation -- ease the loss specification while configuring the model
    def __init__(self, loss: Losses):
        if loss == Losses.ContrastiveLossV1:
            self.loss: Loss = ContrastiveLossV1(margin = 0.7)
        elif loss == Losses.BinaryCrossEntropy:
            self.loss: Loss = tf.keras.losses.BinaryCrossentropy()
        else:
            raise ValueError('Loss not supported')
