# kernel_dependence_network

Developed on Linux Mint, 18.2 Sonya, Mate-64 bit
Python 3.7.2 
[GCC 7.3.0] :: Anaconda, Inc. on linux



Assuming that you have python in your linux environment, run

./knet.py

The results will show up in the results folder.
To run a different dataset, go into knet.py and uncomment 
the appropriate dataset you want to run.


Important Note : 	The code uses a lot of non-conventional symbols, e.g., ɕ, σᒾ, ℓ.
					This is by design, and Yes, the code still works with these symbols.
