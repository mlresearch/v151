from lnets.models.utils.selections import select_activation_function
from lnets.models.utils.selections import select_linear_layer
