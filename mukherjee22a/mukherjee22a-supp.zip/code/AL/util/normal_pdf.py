
import numpy as np

def normal_pdf(mu, sig, val):
    return np.exp(-0.5 * np.square((val - mu)/sig)) / (np.sqrt(2*np.pi) * sig)