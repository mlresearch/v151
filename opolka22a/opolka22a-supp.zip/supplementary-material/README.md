# Adaptive Gaussian Processes on Graphs via Spectral Graph Wavelets 

* Data sets come without a license and are widely available, for example through PyTorch geometric. Running the code will automatically download and pre-process the data sets.
* Requirements:
	* Python 3.8
	* GPflow 2.1.4
	* tensorflow 2.1.4
	* pygsp 0.5.1
	* scikit-learn 0.24.1
	* networkx 2.5
	* torch-geometric 1.6.3 (for data loading)
	* torch 1.7.1 (for data loading)
* Use `wavelet_gp.py` to run the WGGP model on Cora and Citeseer.
* Use `approx_wavelet_gp.py` to run the WGGP model on PubMed.
* Use `adaptive_multiscale_wgp.py` to run the WGGP model on synthetic data.
* Use `figure_scripts/overview_figure.py` to reproduce the main figure of the paper.
* Use `training_environment.py` to specify hyperparameters.