semilogx([4,16,49,64,121], 2*[4e5, 7e5, 1e6,13e5, 14e5],'s', 'MarkerSize',8);hold on
semilogx([4,16,49,64,121], 2*[5e5, 9e5, 14e5,16e5, 19e5],'*', 'MarkerSize',8);

format long
y = @(b,x) b(1)*log(x)+b(2) ;
opts = statset('Display','iter','TolFun',1e-8);
mdl = fitnlm([4,16,49,64,121], 2*[4e5, 7e5, 1e6,13e5, 14e5], y,[70000,1270]);
semilogx([4,16,49,64,121], mdl.feval([4,16,49,64,121]),'k--', 'Linewidth',2);
b = mdl.Coefficients.Estimate;

format long
y = @(b,x) b(1)*log(x)+b(2) ;
opts = statset('Display','iter','TolFun',1e-8);
mdl = fitnlm([4,16,49,64,121], 2*[5e5, 9e5, 14e5,16e5, 19e5], y,[70000,1270]);
semilogx([4,16,49,64,121], mdl.feval([4,16,49,64,121]),'k-.', 'Linewidth',2);
c = mdl.Coefficients.Estimate;

xlim([3,170])
xlabel('$p$','interpreter','latex', 'FontSize', 13)
xticks([ 4,16,60,140])
ylim([3e5,50e5])
ylabel('$n_{min}$','interpreter','latex', 'FontSize', 13)
yticks(1e5*[3:5:45])
grid on
legend('$i.i.d,~\delta^{-1}=0.89$', '$correlated, ~\delta^{-1}=0.89$', '$ n \approx 10^5[ 6.05\log p -1.37] $','$ n \approx 10^5[8.25 \log p - 2.86] $','Interpreter','latex')

legend('$i.i.d ,~\delta^{-1}=0.89$', '$correlated, ~\delta^{-1}=0.89$', '$ n \approx 10^5[ 3.02\log p -0.68] $','$ n \approx 10^5[4.13 \log p - 1.43] $','Interpreter','latex')


