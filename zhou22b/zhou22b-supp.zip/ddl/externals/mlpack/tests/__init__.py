"""Init for mlpack tests."""
