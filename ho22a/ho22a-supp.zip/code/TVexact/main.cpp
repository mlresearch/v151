#include <iostream>
 
int main()
{
    int i;
    i=sizeof(int);
  std::cout << "Hello World!" <<i<< std::endl;
  return 0;
}