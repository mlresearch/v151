# Heavy_ball_cycling_step_sizes

File benchmarks.ipynb contains the code to generate Figure 4 and Figure 1 the paper.

File cyclical_landscape.ipynb contains code to generate Figure 2 in the paper.

File Tools.compute_optimal_polynomial.py contains a code to efficiently compute the optimal polynomial given the degree and a list of eigenvalues.

File find_best_tuning.py contains a grid search over parameters to optimize the cyclical heavy-ball algorithm.

File polynomial_figures.py contains the code to generate Figure 3.
