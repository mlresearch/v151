import gpflow
from gpflow import Parameter
from gpflow.inducing_variables.inducing_variables import InducingPointsBase, \
    InducingVariables
from gpflow.utilities import positive, triangular

from utils import sample_random_edges, normalize_adj_dense
import numpy as np
import tensorflow as tf
import tensorflow_probability as tfp


class NodeInducingPoints(InducingPointsBase):
    """
    Set of real-valued inducing points. See parent-class for details.
    """
    pass


class BipartiteGraphInducingPoints(InducingVariables):
    """
    Inducing points on the domain of a bipartite graph.
    """

    def __init__(self, Z1, Z2, name=None):
        """
        :param Z1: Initial positions of the inducing points for origin nodes
        of the inducing graph. Shape [M, D], where M is the number of inducing
        edges.
        :param Z2: Initial positions of the inducing points for destination
        nodes of the inducing graph. Shape [M, D], where M is the number of
        inducing edges.
        """
        super().__init__(name=name)
        self.Z1 = Parameter(Z1, dtype=Z1.dtype)
        self.Z2 = Parameter(Z2, dtype=Z2.dtype)

    def __len__(self):
        return self.Z1.shape[0]


class GraphInducingPoints(InducingVariables):
    """
    Inducing points on the domain of an undirected graph.
    """

    def __init__(self, Z, num_edges, seed=None, name=None):
        """
        :param Z: Initial positions of the inducing points for the nodes of
        the inducing graph. Shape [Mn, D], where Mn is the number of inducing
        nodes.
        :param num_edges: Number of edges the inducing graph should have.
        """
        super().__init__(name=name)
        self.Z = Parameter(Z, dtype=Z.dtype)
        # sample random edges between the nodes
        rstate = np.random.RandomState(seed) if seed else None
        self.edge_indices = sample_random_edges(Z.shape[0], num_edges, rstate)
        self.edge_indices = tf.constant(self.edge_indices)

    def __len__(self):
        return self.edge_indices.shape[0]


class ConvolvingGraphInducingPoints(InducingVariables):
    """
    Inducing points on the domain of an undirected graph where graph
    convolutions are performed to compute inducing points.
    """

    def __init__(self, Z, num_edges, name=None):
        """
        :param Z: Initial positions of the inducing points for the nodes of
        the inducing graph. Shape [Mn, D], where Mn is the number of inducing
        nodes.
        :param num_edges: Number of edges the inducing graph should have.
        """
        super().__init__(name=name)
        self.Z = Parameter(Z, dtype=Z.dtype)
        num_nodes = self.Z.shape[0]

        # sample random edges between the nodes
        # self.edge_indices = sample_random_edges(Z.shape[0], num_edges)
        self.edge_indices = np.array([[(x, y) for y in range(num_nodes)] for x in range(num_nodes)]).reshape(-1, 2)
        self.edge_indices = tf.constant(self.edge_indices)

        # adj_matrix = np.zeros((num_nodes, num_nodes), dtype=Z.dtype)
        # pos_edges = self.edge_indices[:len(self.edge_indices)//2]
        # adj_matrix[pos_edges[:, 0], pos_edges[:, 1]] = 1.0
        # adj_matrix[pos_edges[:, 1], pos_edges[:, 0]] = 1.0
        # adj_matrix[np.diag_indices(adj_matrix.shape[0])] = 1.0
        # adj_matrix = normalize_adj_dense(adj_matrix)

        laplacian_sqrt = np.random.uniform(low=0.0, high=1.0,
                                           size=[num_nodes, num_nodes]).astype(Z.dtype)
        self.laplacian_sqrt = Parameter(laplacian_sqrt, dtype=laplacian_sqrt.dtype,
                                        transform=triangular())
        # self.conv_mat = tf.constant(adj_matrix)

    def conv_matrix(self):
        adj_mat = tf.matmul(self.laplacian_sqrt, self.laplacian_sqrt, adjoint_b=True)
        degree_mat = tf.reduce_sum(adj_mat, axis=0)
        norm_mat = tf.reshape(tf.pow(degree_mat, -0.5), -1)
        norm_mat = tf.linalg.diag(norm_mat)
        return tf.matmul(norm_mat, tf.matmul(adj_mat, norm_mat))

    def __len__(self):
        return self.edge_indices.shape[0]
