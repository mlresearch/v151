import argparse
import math
import os

import torch
import torch.nn as nn
import yaml

from src import get_module_logger
from src.data.dataloader4txt import BatchfiedPTB, build_vocab
from src.models.predict_model4txt import evaluate
from src.utils.model_rnnlm import prepare_trained_rnnlm


def main():
    logger = get_module_logger("predict")
    logger.debug("Begin...")
    parser = argparse.ArgumentParser()
    parser.add_argument("--wts_path", type=str, default="model/best_wts/state_dict.pth", help="")
    args = parser.parse_args()

    # Evaluation preparations
    wts_path = args.wts_path
    logger.info("Model to be evaluated = %s" % wts_path)
    # Load configure yaml
    cfg = os.path.join(*wts_path.split("/")[:-2], "config.yaml")
    with open(cfg, "r") as f:
        data = yaml.load(f, Loader=yaml.SafeLoader)
    for key in data:
        args.__setattr__(key, data[key])
    logger.debug(args)

    # Model parameters
    # hidden_size = args.hidden_size
    # embedding_size = args.embedding_size
    # hidden_size = args.hidden_size
    m_CS = args.m_CS if hasattr(args, "m_CS") else None
    dropout = args.dropout
    # irnn = args.irnn
    tie_weights = args.tie_weights

    # Learning parameters
    eval_batch_size = args.eval_batch_size
    bptt = args.bptt

    # Dataset parameters
    data_dir = args.data_dir

    # Prepare dataloader
    vocab = build_vocab(data_dir)
    test_ds = BatchfiedPTB(data_dir, "test", vocab, eval_batch_size, bptt)
    test_dl = torch.utils.data.DataLoader(test_ds, batch_size=bptt, shuffle=False)
    logger.debug("Datasets are loaded.")

    # Check device
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    if torch.cuda.is_available():
        torch.backends.cudnn.benchmark = True
    logger.debug("GPU or CPU: %s" % device)

    # Evaluate accuracy of RNN classifier
    model = prepare_trained_rnnlm(
        torch.load(wts_path, map_location=device),
        dropout=dropout,
        tie_weights=tie_weights,
        requires_grad=False,
        m_sharp=m_CS,
    )
    #     model.load_state_dict(torch.load(wts_path, map_location=device))
    if hasattr(model, "removed"):
        model.remove_mask_()
    criterion = nn.CrossEntropyLoss()
    logger.debug("--Begin Evaluation--")
    loss = evaluate(model, criterion, test_dl, device=device)
    logger.info("Test Loss: {:5.2f} ppl: {:8.2f}".format(loss, math.exp(loss)))
    logger.debug("--Finished Evaluation--")

    logger.debug("Done!!")


if __name__ == "__main__":
    main()
