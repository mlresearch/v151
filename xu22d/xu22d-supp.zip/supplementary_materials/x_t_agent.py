import numpy as np
def strategic_agent(Xh, vh, indh, t, normbound_xt):
    d = Xh.shape[1]
    icount = 0
    x_t = np.zeros(d)
    if t == 0:
        x_t = np.random.random(d)
        x_t = x_t * min(1, normbound_xt / np.linalg.norm(x_t))
        return x_t
    for i in range(t):
        if indh[i] != 1:
            icount += 1
            x_t += Xh[i]
    if icount >= 1:
        x_t = (x_t+np.random.random(d))/(icount+1)
    else:
        x_t = np.random.random(d)
    x_t = x_t*min(1,normbound_xt/np.linalg.norm(x_t))
    return x_t

def super_strategic_agent(d , k_epoch=0):
    x_t = np.zeros(d)
    i_k = k_epoch % d
    x_t[i_k] += 1
    return x_t

def random_agent(d,normbound_xt=1):
    """randomly initialize distribution D"""
    identity_number = 10
    gen_D = np.random.rand(d, d)
    Sigma_D = np.dot(gen_D.T, gen_D) + identity_number * np.identity(d)
    Mu_D = identity_number * np.ones(d)
    x_t = np.random.multivariate_normal(Mu_D, Sigma_D / identity_number)
    norm_xt = np.linalg.norm(x_t)
    x_t = x_t*min(1, normbound_xt/norm_xt)
    return x_t


