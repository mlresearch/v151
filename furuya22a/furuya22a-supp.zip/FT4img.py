import argparse
import os

import torch
import torch.nn as nn
import yaml

from src import get_module_logger
from src.data.dataloader4img import mydataloader
from src.models.train_model4img import train
from src.utils.model_rnn import prepare_trained_rnn


def main():
    artifacts = {}

    logger = get_module_logger("FT")
    logger.debug("Begin...")
    parser = argparse.ArgumentParser()
    parser.add_argument("--wts_path", type=str, required=True, help="Path for weight parameter.")
    parser.add_argument("--m", type=int, default=None, help="Compressed hidden_size.")
    parser.add_argument("--lr_decay", type=float, default=1.0, help="Begin with `lr = lr_original / lr_decay`.")
    parser.add_argument(
        "--non_structured_pruned", type=bool, default=False, help="Whether non-structured pruning was applied or not."
    )
    parser.add_argument("--epochs", type=int, default=None, help="")
    parser.add_argument("--experiment", type=str, default=None, help="Experimental name.")
    parser.add_argument("--tags", type=dict, default=None, help="Experimental tags to be converted to dictionary type.")
    parser.add_argument("--id", type=str, default=None, help="ID of the model to be finetuned.")
    args = parser.parse_args()

    # Weights to be finetuned
    wts_path = args.wts_path
    m_sharp = args.m
    non_structured_pruned = args.non_structured_pruned
    epochs = args.epochs
    experiment = args.experiment
    # Load configure yaml
    cfg = os.path.join(*wts_path.split("/")[:-2], "config.yaml")
    with open(cfg, "r") as f:
        data = yaml.load(f, Loader=yaml.SafeLoader)
    for key in data:
        args.__setattr__(key, data[key])
    logger.debug(args)

    # Model parameters
    # non_structured_pruned = args.non_structured_pruned
    hidden_size = args.hidden_size
    # output_size = args.output_size
    irnn = args.irnn

    # Learning parameters
    batch_size = args.batch_size
    lr = args.lr / args.lr_decay
    lr_step = args.lr_step
    gamma = args.lr_gamma
    # epochs = args.epochs
    # semi_epoch = epochs // 2
    # clip_value = args.clip_value
    clip_value = None
    clip_norm = args.clip_norm

    # Dataset parameters
    dataset = args.dataset
    task = args.task
    data_dir = args.data_dir
    # _, input_size = calc_input_sizes(dataset, task)
    # Log path
    tags = args.tags
    log_dir = os.path.join('models/logs', experiment, 'model')
    logger.info("log_dir = %s" % log_dir)
    # Overwrite configures
    data["epochs"] = epochs
    data["lr"] = lr
    # Make log directory and save configure yaml file
    if not os.path.isdir(log_dir):
        os.makedirs(os.path.join(log_dir, 'best_acc_wts'))
        os.makedirs(os.path.join(log_dir, 'best_loss_wts'))
    cfg_path = os.path.join(log_dir, "config.yaml")
    with open(cfg_path, "w") as cfg:
        yaml.dump(data, cfg)    # Save configure yaml file
    logger.info("Saved configure yaml.")

    # Prepare dataloader
    train_dl, test_dl = mydataloader(dataset=dataset, task=task, data_dir=data_dir, batch_size=batch_size)
    logger.debug("Datasets are loaded.")

    # Check device
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    if torch.cuda.is_available():
        torch.backends.cudnn.benchmark = True
    logger.debug("GPU or CPU: %s" % device)

    # Finetune RNN classifier
    if non_structured_pruned:
        model = prepare_trained_rnn(
            torch.load(wts_path, map_location=device),
            irnn=irnn,
            requires_grad=True,
            ft=True,
        )
        mask_key = "rnn.weight_hh_l0"
        mask = torch.zeros_like(model.state_dict()[mask_key])
        mask[model.state_dict()[mask_key] != 0] = 1
        mask = mask.to(device)
        model.set_mask(mask, [mask_key])
    else:
        model = prepare_trained_rnn(torch.load(wts_path, map_location=device), irnn=irnn, requires_grad=True)

    criterion = nn.CrossEntropyLoss(reduction="sum")
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    if gamma is not None:
        scheduler = torch.optim.lr_scheduler.StepLR(optimizer, lr_step, gamma=gamma)
    else:
        scheduler = None
    logger.debug("--Begin Finetuning--")
    train(
        model,
        criterion,
        optimizer,
        train_dl,
        test_dl,
        epochs=epochs,
        device=device,
        scheduler=scheduler,
        clip_value=clip_value,
        clip_norm=clip_norm,
        tags=tags,
        artifacts=artifacts,
        experiment=experiment,
    )
    logger.debug("--Finished Finetuning--")

    logger.debug("Done!!")


if __name__ == "__main__":
    main()
