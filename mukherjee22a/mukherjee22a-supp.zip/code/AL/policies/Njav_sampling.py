

import sys
sys.path.append("..")
from util.check_stop_time import check_stop_time
from util.chernoff_sampling import chernoff_sampling
from util.global_opt_sampling import global_opt_sampling
from util.update_log_L import update_log_L
from util.sample_source import sample_source
from util.bayes_rule import new_prob_bayes_rule

#from environment.Discrete_env import Discrete_env

import numpy as np

class Njav_Sampling(object):
    
    '''
    classdocs
    '''
    
    num_sources = 0
    num_hypo = 0
    mu = None
    
    def __init__(self, env):
        '''
        Constructor
        '''
        self.num_hypo = env.num_hypo
        self.num_sources = env.num_sources
        self.mu = env.mu
        self.sig = env.sig
        self.env = env
        self.trials = env.trials
        self.T = env.T
        self.jstar = env.jstar
        self.best_arm = env.best_arm
        
        
        self.njav_err = []
        self.njav_num = []
        #pre calculate chernoff sampling proportions
        self.calculated_probability = np.zeros((self.num_sources, self.num_hypo))

        for idx in range(self.num_hypo):
            probability = chernoff_sampling(self.mu, self.sig, idx)
            self.calculated_probability[:,idx] = probability 


        self.njav_sample_complexity = np.zeros((self.trials, self.num_sources))
        self.global_OPT_proportion = global_opt_sampling(self.mu, self.sig, self.num_hypo)[0]
        #print(self.global_OPT_proportion)

        
        
    
    def run_Njav_Sampling(self):
        
        
        
        print("\n Njav")
        for tr in range(self.trials): 
    
            self.njav_L = np.zeros(self.num_hypo)
            self.tr_njav_err = np.zeros(self.T)
    
            np.random.seed(tr)
    
            self.tr_njav_num = np.zeros(self.num_sources)
            
            njav_posterior = np.ones(self.num_hypo)/self.num_hypo
            
            
            for t in range(self.T):
                
                if check_stop_time(self.njav_L, self.num_hypo) == False:
                          
                    if max(njav_posterior) > 0.5:
                        probability = self.calculated_probability[:, np.argmax(njav_posterior)]
                        idx = np.random.choice(self.num_sources, p=probability/sum(probability))
                    else:
                        probability = self.global_OPT_proportion
                        idx = np.random.choice(self.num_sources, p=probability/sum(probability))
                        self.tr_njav_num[idx] += 1
                
                        val = sample_source(idx, self.mu, self.sig, self.jstar)
                        njav_posterior = new_prob_bayes_rule(njav_posterior, self.mu, self.sig, idx, val)
                          
                        update_log_L(self.njav_L, self.mu, self.sig, idx, val)
                
                        njav_hypo_hat = np.random.choice([h for h in range(self.num_hypo) if njav_posterior[h]==max(njav_posterior)])
                        #tr_njav_err[t] += int(njav_hypo_hat != jstar)
                        njav_best_arm_hat = np.argmax(np.array(self.mu[:,njav_hypo_hat]))
                        self.tr_njav_err[t] += int(njav_best_arm_hat != self.best_arm)
                
                        self.njav_sample_complexity[tr][idx] += 1
            
            
            self.njav_err.append(self.tr_njav_err)
        
            self.njav_num.append(self.tr_njav_num)
            
            print(tr, end=', ')
            if tr % 100 == 0:
                print()