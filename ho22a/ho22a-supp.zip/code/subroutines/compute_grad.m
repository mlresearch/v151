function grad = compute_grad(D, L, k, y, u)
    grad    = Times_S(D, L, k, Times_ST(D, L, k, u) - y);
end

