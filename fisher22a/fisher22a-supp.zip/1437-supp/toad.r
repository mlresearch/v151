

check_args <- function(p, a){
	### Error checks
	stopifnot(length(a)==length(p))
	stopifnot(all(a>0, na.rm=TRUE))
	stopifnot(sum(a, na.rm=TRUE)<=1 + 10^-10)
	stopifnot(all(diff(is.na(a)) >= 0)) # check if there are intermediate missing parameter values
	stopifnot(all(is.na(p) == is.na(a))) # check if there are intermediate missing parameter values
	### 
}

toad_step <- function(p=NULL, a=NULL, w = p/a, alpha, 
	past_rej = c(),
	stage=length(p),
	candidates = 1:stage){

	stopifnot(stage <= length(w))
	stopifnot(length(w)>0)


	old_rej <- setdiff(past_rej, candidates)

	w_cand <- w[candidates]
	w_sort <- sort(w_cand)
	len_old <- length(old_rej)
	len_cand <- length(candidates)
	st <- max(0, 
		which(w_sort < (1:len_cand + len_old) * alpha)
		)

	if(st == 0){
		rej <- past_rej
	} else {
		rej <- c(old_rej, candidates[w_cand <= w_sort[st]])
	}

	### Error checks
	rej_candidates <- intersect(candidates, rej)
	stopifnot(length(rej) == st + len_old)
	test_all <- (all(w[rej] <= 
		alpha * max(1,length(rej)) )) #condition used in proof/paper #tagOrderCond
	if(!test_all) warning('All tests do not meet required conditions, possibly due to improper "past_rej" input.')

	return(rej)
}


toad_loop <- function(p, a, alpha, deadlines, progress_bar = FALSE){
	t_g <- unique(deadlines) ## stages where we need to run toad_step
	tmax <- length(p)
	stopifnot(length(a) == tmax)
	stopifnot(length(deadlines) == tmax)
	stopifnot(length(alpha) == 1)
	check_args(p,a)
	w <- p/a

	check_inds <- c(1, sample(length(t_g), min(5,length(t_g))), length(t_g))
	check_inds <- unique(check_inds)

	rej_i <- c()
	cand_i <- 1:t_g[1]
	if(progress_bar) pb <- txtProgressBar(0, length(t_g))
	for(i in 1:length(t_g)){
		if(progress_bar) setTxtProgressBar(pb, i)
		
		# Fast, sequential definition of cand_i
		stage_i <- t_g[i]
		stage_im1 <- ifelse(i==1, 1, t_g[i-1])	
	 	cand_old <- cand_i
	 	cand_i <- union(cand_old, stage_im1:stage_i) #add newly observed hypotheses as potential candidates
	 	expired <- deadlines[cand_i] < stage_i
	 	cand_i <- cand_i[!expired]
		stopifnot(length(cand_i)>0)
		if(i %in% check_inds){
			test_i <- which((1:tmax <= stage_i) & (deadlines >= stage_i))
			stopifnot(setequal(test_i, cand_i))
		}
		
		rej_im1 <- rej_i
		rej_i <- toad_step(w=w, alpha=alpha, 
			past_rej = rej_im1,
			stage = stage_i,
			candidates = cand_i)
	}
	n_obs <- sum(!is.na(p))
	stopifnot(all(rej_i <= n_obs))


	rej_i
}


bh <- function(p, alpha){
	if(alpha == 0) return(c())
	p_sort <- sort(p)
	m <- length(p)

	### for workchecks
		# we show in paper that toad reduces to BH in certain cases.
		rej2 <- toad_step(p=p, a=rep(1/m,m), alpha=alpha, 
				past_rej = c(),
				stage = m,
				candidates = 1:m)
	###

	max_set <- (p_sort <= (1:m) * alpha / m)
	if(!any(max_set)){
		stopifnot(length(rej2)==0)
		return(c()) #no valid rejections
	} else {
		p_thresh <- max(p_sort[ max_set ] )
	}
	rej <- which(p <= p_thresh) #rejected indices
	
	stopifnot(setequal(rej, rej2))
	return(rej)
}


naive_bh <- function(p, alpha, batch_ends){
	K <- length(p)
	G <- length(batch_ends)
	groups <- sapply(1:K, function(k){
		min(batch_ends[batch_ends >= k])
	})

	rej_list <- list()
	for(g in 1:G){
		p_g <- p[groups == batch_ends[g]]
		start_at <- 0
		if(g>1) start_at <- batch_ends[g-1]
		rej_list[[g]] <- bh(
			p = p_g, 
			alpha =  alpha/G) + start_at
	}
	
	unlist(rej_list)
}



batch_prds_bh <- function(p, alpha, a_batch, batch_ends, check_theory = FALSE){
	K <- length(p)
	G <- length(batch_ends)
	stopifnot(length(a_batch) == G)
	stopifnot(K > G)

	groups <- sapply(1:K, function(k){
		min(batch_ends[batch_ends >= k])
	})

	rej_list <- list()
	for(g in 1:G){
		p_g <- p[groups == batch_ends[g]]
		start_at <- 0
		if(g>1) start_at <- batch_ends[g-1]

		Rgm1 <- length(unlist(rej_list))
		n_g <- length(p_g)
		bh_a <- alpha * (a_batch[g] / n_g) * (n_g + Rgm1)
		rej_list[[g]] <- bh(
			p = p_g, 
			alpha =  bh_a) + start_at
	}
	rej_vec <- unlist(rej_list)

	### Error check #tag-batch-included
	if(check_theory){
		tgroups <- c(table(groups))
		a_list <- 
		dead_list <- list()
		for(g in 1:G){
			n_g <- sum(groups == batch_ends[g])
			a_list[[g]] <- rep(a_batch[g] / n_g, n_g)
			dead_list[[g]] <- rep(batch_ends[g], n_g)
		}
		a_toad2 <- unlist(a_list)
		stopifnot(abs(sum(a_toad) - 1) <= 10^-10)
		a_toad2 <- a_toad2 / sum(a_toad2)
		deadlines2 <- unlist(dead_list)
		toad_rej <- toad_loop(p=p, a = a_toad2, 
			alpha = alpha, deadlines = deadlines2)
		stopifnot(all(rej_vec %in% toad_rej))
	}
	###
	
	return(rej_vec)
}


batch_bh <- function(p, alpha, gamma_seq, batch_ends){
	K <- length(p)
	G <- length(batch_ends)
	groups <- sapply(1:K, function(k){
		min(batch_ends[batch_ends >= k])
	})
	stopifnot(length(gamma_seq) == G)
	stopifnot(sum(gamma_seq) == 1)

	r_num <- 
	r_plus <- 
	beta_sum_elements <- 
	bh_alpha_seq <- rep(NA, G)
	bh_alpha_seq[1] <- alpha * gamma_seq[1]
	rej_list <- list()
	for(g in 1:G){
		if(bh_alpha_seq[g] == 0 & length(unlist(rej_list))==0) break # we have failed to reject anything and have used up all of our alpha
		p_g <- p[groups == batch_ends[g]]
		start_at <- 0
		if(g>1) start_at <- batch_ends[g-1]
		rej_list[[g]] <- bh(
			p = p_g, 
			alpha =  bh_alpha_seq[g]) + start_at
		if(g==G) break


		r_num[g] <- length(rej_list[[g]])
		p_plus <- p_g
		p_plus[which.max(p_plus)] <- 0
		r_plus[g] <- length(bh(
			p = p_plus, 
			alpha =  bh_alpha_seq[g]))
		beta_tp1 <-
			sum(sapply(1:g, function(s){
				sum2 <- sum(r_num[setdiff(1:g,s)])
				bh_alpha_seq[s] * (r_plus[s]/(r_plus[s] + sum2)) 
					#Note, order of operations here matters for avoiding machine precision errors if sum2==0
					# compute fraction before multiplying!
			}))
		ntp1 <- sum(groups == batch_ends[g+1])
		bh_alpha_seq[g+1] <- (sum(alpha*gamma_seq[1:G <= g+1]) - beta_tp1) *
			(ntp1 + sum(r_num, na.rm=TRUE))/ntp1

		stopifnot(!is.nan(bh_alpha_seq[g+1]))
	}
	
	unlist(rej_list)
}






