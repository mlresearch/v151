
clear;
warning('off','all')

%%%  grid size is n^2
n_grid =  [128 64];
kappa_grid = [ 1 2];

%%%%% penalty tuning parameter
lambda_grid = [ 0.01 0.1 1 10 100];

NMC =  50;

hausdorff_dist =  zeros(length(n_grid), length(kappa_grid),4,NMC);
hausdorff_dist_l0 =  zeros(length(n_grid), length(kappa_grid),4,NMC);


hausdorff_dist_average =  zeros(length(n_grid), length(kappa_grid),4);
hausdorff_dist_l0_average =  zeros(length(n_grid), length(kappa_grid),4);


hausdorff_dist_sd =  zeros(length(n_grid), length(kappa_grid),4);
hausdorff_dist_l0_sd =  zeros(length(n_grid), length(kappa_grid),4);

for ind_n = 1:length(n_grid)
    
    n =  n_grid(ind_n);
    m = n;
    display('n')
    display(n)
    %%%% Construct graph grid 
    I_ind = [];
    J_ind = [];
    for j = 1:m
       I_ind = [ I_ind   ((j-1)*n + 1 ):((j-1)*n + n-1)];
       J_ind = [ J_ind   ((j-1)*n + 2 ):((j-1)*n + n)];
    end

    for j = 1:n
       I_ind = [ I_ind    (n*(0:(m-2))+j) ];
       J_ind = [ J_ind    (n*(1:(m-1))+j) ];
    end
     %%%%%%%%%
     for ind_kappa = 1:length(kappa_grid)
         kappa = kappa_grid(ind_kappa);
         display('kappa')
         display(n)
         
         for scenario = 1:4
             %%%%%%%%%%%%%%%%%%%%
             if scenario == 1
                 theta0 =  zeros(n,n);
                 for i = 1:n
                     for j = 1:m
                        if  (i-n/4)^2 + (j-n/4)^2< (n/5)^2
                            theta0(i,j) = kappa;
                        end
                     end
                 end
             end
             %%%%%%%%%%%%%%%%%%%%
             if scenario == 2
                 theta0 =  zeros(n,n);
                 for i = 1:n
                     for j = 1:m
                        if  (i-n/4)^2 + (j-n/4)^2< (n/5)^2
                            theta0(i,j) = kappa;
                        end
                         if  (i-3*n/4)^2 + (j-3*n/4)^2< (n/5)^2
                            theta0(i,j) = kappa;
                        end
                     end
                 end                 
             end            
             %%%%%%%%%%%%%%%%%%%%
              if scenario == 3
                 theta0 =  zeros(n,n);

                 for i = 1:n
                     for j = 1:m
                         r1 = (i-n/4)^2 + (j-n/4)^2;
                         %r2 = (i-3*n/4)^2 + (j-3*n/4)^2;
                         if  abs(i-n/2)<n/4 && abs(j-n/2)<n/8
                             %r1<  abs(cos(10*pi*i/n))*(n/5)^2
                            theta0(i,j) = kappa;
                         end
                     end
                 end      
              end             
             %%%%%%%%%%%%%%%%%%%%
              if scenario == 4
                 theta0 =  zeros(n,n);

                 for i = 1:n
                     for j = 1:m
                         r1 = (i-n/4)^2 + (j-n/4)^2;
                         %r2 = (i-3*n/4)^2 + (j-3*n/4)^2;
                         if  r1<  abs(cos(10*pi*i/n))*(n/5)^2
                            theta0(i,j) = kappa;
                         end
                     end
                 end  
                      
                 for i = 1:n
                     for j = 1:m
                         r1 = (i-3*n/4)^2 + (j-3*n/4)^2;
                         %r2 = (i-3*n/4)^2 + (j-3*n/4)^2;
                         if  r1<  abs(cos(10*pi*i/n))*(n/5)^2
                            theta0(i,j) = kappa;
                         end
                     end
                 end  
              end             
             %%%%%%%%%%%%%%%%%%%%
              for iter = 1:NMC
                  
                  display(append('iter = ',num2str(iter)))
                
                  y = theta0 + normrnd(0,1,n,n);
                  
                  aux = append('/Users/oscar/Desktop/CodePlayground-main/ComputerVision/simulations/y_ind_n_',num2str(ind_n),'ind_kappa',num2str(ind_kappa));
                  aux = append(aux, 'scenario',num2str(scenario),'iter',num2str(iter),'.txt');                  
                  name = aux;

                  y =  dlmread(name);
                  %dlmwrite(name,y);
                  aux = append('/Users/oscar/Desktop/CodePlayground-main/ComputerVision/simulations/theta0_ind_n_',num2str(ind_n),'ind_kappa',num2str(ind_kappa));
                  aux = append(aux, 'scenario',num2str(scenario),'iter',num2str(iter),'.txt');                  
                  name = aux;

                  %dlmwrite(name,theta0);
                  theta0 =  dlmread(name);
                  
                  c_l =  quantile(reshape(y,n*m,1),0.1);%min(min(y));
                  c_u =  quantile(reshape(y,n*m,1),0.9);%max(max(y));
                  c_grid =  c_l:( (c_u-c_l)/39 ):c_u;
                  
                  %%%%%%%%%%%%%%%%
                   theta_hat_path =  zeros(length(lambda_grid),n,m);
                   RSS = zeros(1,length(lambda_grid));
                   BIC = zeros(1,length(lambda_grid));
                   sigma_hat2 = sqrt(sum((diff(reshape(y,1,n*n))).^2)/(n^2 - 1));

                   for ind = 1:length(lambda_grid)
                      lamb = lambda_grid(ind);
                      theta_hat_path(ind,:,:) = reshape(cp_estimator_l0(y,lamb,c_grid, I_ind, J_ind),n,m);
                      aux = squeeze(theta_hat_path(ind,:,:));
                      RSS(ind) = sum(sum((aux-y).^2 ));
                      idx = find(abs(aux(I_ind)-aux(J_ind)) < 1e-1); 
                      G_conn = graph(I_ind(idx), J_ind(idx));
                      [bin, binsize] = conncomp(G_conn);
                      v = sum(binsize >= 1);
                      BIC(ind) = RSS(ind)+ v*sigma_hat2*log(n^2);
                   end
                   best_ind = find(BIC== min(BIC),1);
                   theta_hat =  squeeze(theta_hat_path(best_ind,:,:));
                   hausdorff_dist(ind_n,ind_kappa,scenario,iter) = hausdorff(theta0,theta_hat); 
                   %hausdorff(theta0,theta_hat)
                   
                   %heatmap(theta_hat)
                   %sum(sum(theta0 - theta_hat).^2)/(n^2)
                   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
              end%%  iter
              
              
              hausdorff_dist_average(ind_n,ind_kappa,scenario) =  median(hausdorff_dist(ind_n,ind_kappa,scenario,:));
              hausdorff_dist_sd(ind_n,ind_kappa,scenario) =  std(hausdorff_dist(ind_n,ind_kappa,scenario,:));

              hausdorff_dist_l0_average(ind_n,ind_kappa,scenario) =  median(hausdorff_dist_l0(ind_n,ind_kappa,scenario,:));
              hausdorff_dist_l0_sd(ind_n,ind_kappa,scenario) =  std(hausdorff_dist_l0(ind_n,ind_kappa,scenario,:));
              
              display(append('proposed = ',num2str( hausdorff_dist_average(ind_n,ind_kappa,scenario) ),' var=',num2str(hausdorff_dist_sd(ind_n,ind_kappa,scenario))))
              display(append('full = ',num2str( hausdorff_dist_l0_average(ind_n,ind_kappa,scenario) ), num2str(  hausdorff_dist_l0_sd(ind_n,ind_kappa,scenario))  ))
         end%%%% scenario
     end
 end
%     
% dlmwrite('hausdorff_dist.txt', hausdorff_dist)
% dlmwrite('hausdorff_dist_l0.txt', hausdorff_dist_l0)
% 
% dlmwrite('hausdorff_dist_average.txt', hausdorff_dist_average)
% dlmwrite('hausdorff_dist_l0_average.txt', hausdorff_dist_l0_average)
