import torch.nn.functional as F
from decomp_gen.models.mlp import Mlp
from decomp_gen.models.decomp_tree_encoder import *



class IncompleteTreeExtender(nn.Module):
    def __init__(self, hidden_size, MaskLen, mlp_sizes=[400]):
        nn.Module.__init__(self)
        print("************MaskLen: ", MaskLen)
        print("************hidden_size: ", hidden_size)
        self.MaskLen = MaskLen
        self.treeEncoder = TreeEncoder(hidden_size)
        self.mlp = Mlp(input_size=2 * hidden_size + MaskLen, output_size=MaskLen, hidden_sizes=mlp_sizes)

    def forward(self, trees, extendingNodes_ids, Mask):
        Mask = Mask.to(device)
        treeEncode, _ = self.treeEncoder(trees, extendingNodes_ids)
        mlpInput = torch.cat([treeEncode, Mask], 1).type(torch.FloatTensor)
        output = self.mlp(mlpInput)

        output = F.softmax(output, dim=1)
        output = output * Mask
        normalizer = torch.sum(output, axis=1)
        output = output / normalizer.view(-1, 1)

        return output


class incompleteTreeExtenderWithDLogistics(nn.Module):
    def __init__(self, hidden_size, MaskLen, k, mlp_sizes=[400]):
        '''
        k: number of mixture of DLogistics distributions
        '''
        nn.Module.__init__(self)
        self.MaskLen = MaskLen
        self.k = k
        self.treeEncoder = DecompTreeEncoder(hidden_size)
        self.mlp = Mlp(input_size=2 * hidden_size + MaskLen, output_size=3 * k, hidden_sizes=mlp_sizes)

    def forward(self, trees, extendingNodes_ids, Mask):
        Mask = Mask.to(device)
        treeEncode = self.treeEncoder(trees, extendingNodes_ids)
        mlpInput = torch.cat([treeEncode, Mask], 1).type(torch.FloatTensor)
        output = self.mlp(mlpInput)
        alpha = output[:, 0:self.k]
        alpha = F.softmax(alpha, dim=1)
        mu = output[:, self.k:2 * self.k]
        mu = F.softplus(mu)
        sigma = output[:, 2 * self.k:]
        sigma = F.softplus(sigma)
        # output=F.softplus(output)

        indices = torch.arange(start=0.0, end=self.MaskLen, step=1.0, device=device).type(torch.FloatTensor)
        indices = indices.repeat(1, output.shape[0]).view(-1, self.MaskLen)
        p = torch.zeros([output.shape[0], self.MaskLen]).to(device)
        for i in range(self.k):
            alpha_i = alpha[:, i]
            alpha_i = alpha_i.view(-1, 1)
            mu_i = mu[:, i]
            mu_i = mu_i.view(-1, 1)
            sigma_i = sigma[:, i]
            sigma_i = sigma_i.view(-1, 1)
            # print(alpha_i.shape)
            # print(indices.shape)
            p_i = torch.sigmoid((indices + 1.0 - mu_i) / sigma_i) - torch.sigmoid(
                (indices - mu_i) / sigma_i)
            p_i = alpha_i * p_i
            p = p + p_i

        p = p * Mask
        normalizer = torch.sum(p, axis=1)
        output = p / normalizer.view(-1, 1)

        return output
