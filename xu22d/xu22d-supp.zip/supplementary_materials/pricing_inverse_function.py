import scipy.stats as stats
# from pricing_function import pricing
def phi(w, sigma):
    return sigma*(1-stats.norm.cdf(w/sigma))/stats.norm.pdf(w/sigma)

def pricing_inverse(v, sigma, precision = 0.0001, B=1):
    if sigma <= precision:
        return v
    lb = -v-3*B
    ub = max(1/v, 3*B)
    w = 0
    while ub-lb >= precision:
        p_w = phi(w, sigma)
        if p_w == v:
            return v-w
        elif p_w > v:
            lb = w
        else:
            ub = w
        # print("[", lb, ", ", ub, "]")
        w = (lb+ub)/2
    return v-w
