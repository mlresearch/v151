"""Compute the Frechet Inception Distance (FID) for CIFAR-10 given a numpy file of GAN samples.

Example
-------
CUDA_VISIBLE_DEVICES=0 python compute_fid_from_samples.py \
    --load=/scratch/gobi2/pvicol/complex_momentum/samples_np/BigGAN_C10_seed0_Gch64_Dch64_bs50_nDs4_Glr2.0e-04_Dlr2.0e-04_GB10.000_GB1p16.000_GB20.999_GB2p16.000_DB10.000_DB1p16.000_DB20.999_DB2p16.000_Gnlrelu_Dnlrelu_GinitN02_DinitN02_ema_cg_cd/12000/samples.np
"""
import ipdb
import argparse
import numpy as np

import tensorflow as tf
from torchvision import datasets

import fid

parser = argparse.ArgumentParser()
parser.add_argument('--load', type=str,
                    help='Path to numpy file containing samples to load')
args = parser.parse_args()

# Paths
stats_path = 'fid-stats/fid_stats_cifar10_train.npz' # training set statistics
inception_path = fid.check_or_download_inception(None) # download inception network

# load precalculated training set statistics
f = np.load(stats_path)
mu_real, sigma_real = f['mu'][:], f['sigma'][:]
f.close()

samples = np.load(args.load)

fid.create_inception_graph(inception_path)  # load the graph into the current TF graph
print('Computing activation statistics...')
with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())
    mu_gen, sigma_gen = fid.calculate_activation_statistics(samples, sess, batch_size=100)

print('Computing Frechet Inception Distance...')
fid_value = fid.calculate_frechet_distance(mu_gen, sigma_gen, mu_real, sigma_real)
print('FID: {}'.format(fid_value))
