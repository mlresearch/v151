import numpy as np
import pandas as pd

from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.gaussian_process import GaussianProcessClassifier
from sklearn.gaussian_process.kernels import RBF, WhiteKernel
import choix as chx
from sklearn.cluster import KMeans


class Pairwise_LogisticRegression(object):
    """
    Run Pairwise Logistic Regression: By intrinsic design it is
    skew symmetric and has some kind of low rank assumption.
    """

    def __init__(self, choix_ls, y_ls, X):
        super().__init__()
        self.X = X
        self.choix_ls = choix_ls
        self.y_ls = y_ls
        self.log_reg = LogisticRegression()

    def fit(self):
        # Create features
        win_ind = np.array(self.choix_ls)[:, 0]
        loss_ind = np.array(self.choix_ls)[:, 1]
        win_X = np.array(pd.DataFrame(self.X).iloc[win_ind, :])
        loss_X = np.array(pd.DataFrame(self.X).iloc[loss_ind, :])

        # Combine them
        win_pair_X = np.hstack([win_X, loss_X])
        loss_pair_X = np.hstack([loss_X, win_X])
        pair_X = np.vstack([win_pair_X, loss_pair_X])

        # Create outcome
        pair_y = np.array(self.y_ls + [-1 for i in range(len(self.y_ls))])

        # Train the algo
        self.log_reg.fit(pair_X, pair_y)

    def predict(self, choix_ls, predict_proba=True):
        left_ind = np.array(choix_ls)[:, 0]
        right_ind = np.array(choix_ls)[:, 1]

        left_X = np.array(pd.DataFrame(self.X).iloc[left_ind, :])
        right_X = np.array(pd.DataFrame(self.X).iloc[right_ind, :])

        pair_X = np.hstack([left_X, right_X])

        if predict_proba:
            return self.log_reg.predict_proba(pair_X)
        else:
            return self.log_reg.predict(pair_X)


class Pairwise_RandomForest(object):
    """
    Pairwise Random Forest Algorithm
    -

    """

    def __init__(self, choix_ls, y_ls, X):
        super().__init__()
        self.X = X
        self.choix_ls = choix_ls
        self.y_ls = y_ls
        self.rf = RandomForestClassifier()

    def fit(self):
        # Create features
        win_ind = np.array(self.choix_ls)[:, 0]
        loss_ind = np.array(self.choix_ls)[:, 1]
        win_X = np.array(pd.DataFrame(self.X).iloc[win_ind, :])
        loss_X = np.array(pd.DataFrame(self.X).iloc[loss_ind, :])

        # Combine them
        win_pair_X = np.hstack([win_X, loss_X])
        loss_pair_X = np.hstack([loss_X, win_X])
        pair_X = np.vstack([win_pair_X, loss_pair_X])

        # Create outcome
        pair_y = np.array(self.y_ls + [-1 for i in range(len(self.y_ls))])

        # Train the algo
        self.rf.fit(pair_X, pair_y)

    def predict(self, choix_ls, predict_proba=True):
        left_ind = np.array(choix_ls)[:, 0]
        right_ind = np.array(choix_ls)[:, 1]

        left_X = np.array(pd.DataFrame(self.X).iloc[left_ind, :])
        right_X = np.array(pd.DataFrame(self.X).iloc[right_ind, :])

        pair_X_ij = np.hstack([left_X, right_X])
        pair_X_ji = np.hstack([right_X, left_X])

        choix_ls_nega = np.array(choix_ls)[:, [1, 0]]

        # Yij ls
        ij_ls1 = self.rf.predict_proba(pair_X_ij)
        ij_ls2 = self.rf.predict_proba(pair_X_ji)[:, [1, 0]]

        proba_ls = (ij_ls1 + ij_ls2) / 2
        prediction = pd.DataFrame(proba_ls).apply(np.argmax, axis=1) * 2 - 1

        if predict_proba:
            return proba_ls
        else:
            return prediction


class Pairwise_GP(object):

    def __init__(self, choix_ls, y_ls, X):
        super().__init__()
        self.X = X
        self.choix_ls = choix_ls
        self.y_ls = y_ls
        self.kernel = kernel = 1.0 * RBF(length_scale=10.0, length_scale_bounds=(1e-2, 1e3)) \
                               + WhiteKernel(noise_level=1, noise_level_bounds=(1e-10, 1e+1))
        self.gp = GaussianProcessClassifier()

    def fit(self):
        win_ind = np.array(self.choix_ls)[:, 0]
        loss_ind = np.array(self.choix_ls)[:, 1]
        win_X = np.array(pd.DataFrame(self.X).iloc[win_ind, :])
        loss_X = np.array(pd.DataFrame(self.X).iloc[loss_ind, :])

        # Combine them
        win_pair_X = np.hstack([win_X, loss_X])
        loss_pair_X = np.hstack([loss_X, win_X])
        pair_X = np.vstack([win_pair_X, loss_pair_X])

        # Create outcome
        pair_y = np.array(self.y_ls + [-1 for i in range(len(self.y_ls))])

        # Train the algorithm
        self.gp.fit(pair_X, pair_y)

    def predict(self, choix_ls, predict_proba=True):

        left_ind = np.array(choix_ls)[:, 0]
        right_ind = np.array(choix_ls)[:, 1]

        left_X = np.array(pd.DataFrame(self.X).iloc[left_ind, :])
        right_X = np.array(pd.DataFrame(self.X).iloc[right_ind, :])

        pair_X = np.hstack([left_X, right_X])

        if predict_proba:
            return self.gp.predict_proba(pair_X)
        else:
            return self.gp.predict(pair_X)

"""
CLustering Mehtods
"""


def PR_Clustering(n, choix_train, choix_test, num_bootstrap, n_clus):
    # Parameter Setup
    T = choix_train
    D = choix_test
    k = num_bootstrap

    # Algorithm Start
    R = np.zeros((n, n))
    # Generate K bootstrap samples
    bootstrap_ranking_ls = []
    for rd in range(k):
        bootstrap_index = np.random.choice(len(choix_train), len(choix_train))
        bootstrap_ranking = chx.ilsr_pairwise(n, np.array(T)[bootstrap_index], alpha=0.01)
        bootstrap_ranking_ls.append(bootstrap_ranking)

    for r in bootstrap_ranking_ls:
        for ls in D:
            win, lose = ls
            if r[win] > r[lose]:
                R[win, lose] += 1 / k
            else:
                R[lose, win] += 1 / k

    for rd in range(10):
        for i in range(n):
            for j in range(n):
                R[i, j] = np.max([R[i, j], np.max([np.min([R[i, q], R[q, j]]) for q in range(n)])])

    alpha_ls = []
    for i in range(n):
        for j in range(n):
            alpha_ls.append(np.min([R[i, j], R[j, i]]))

    alpha = np.max(alpha_ls)

    for i in range(n):
        for j in range(n):
            if R[i, j] > alpha:
                R[i, j] = 1
            else:
                R[i, j] = 0

    new_C = np.zeros_like(R)
    for i in range(n):
        for j in range(n):
            if R[i, j] == 1:
                new_C[i, j] = 1
                new_C[j, i] = -1

    u, d, vh = np.linalg.svd(new_C)

    km = KMeans(n_clusters=n_clus)
    km.fit(u[:, :n_clus * 2])

    return km.labels_
