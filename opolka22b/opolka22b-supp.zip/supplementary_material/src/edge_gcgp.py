import os
import pathlib
import random
import sys

import numpy as np
import gpflow
import tensorflow as tf
from gpflow.mean_functions import Constant, Zero
from gpflow.models import SVGP
from scipy.cluster.vq import kmeans2

from inducing_points import GraphInducingPoints
from kernels.edge_gc_kernel import EdgeGraphConvolutional
from data_loading.link_prediction_dataset import LinkPredictionDataset
from metrics import compute_binary_accuracy, compute_auc, compute_mean, compute_ap
from training_environment import PerformanceLogger, OutputLogger, \
    checkpoint_filepath, print_parameters
from training_environment import TrainingSettings as ts
from utils import save_tf_module_weights, load_tf_module_weights

devices = tf.config.list_physical_devices('GPU')
if len(devices) > 0:
    tf.config.experimental.set_memory_growth(devices[0], True)


def training_step(train_loader, gprocess, kernel, optimizer, logger):
    for batch in train_loader:
        # Obtain minibatch data in right format.
        if len(batch) > 2:
            X_batch, y_batch, conv_matrix, subgraph_nodes, _ = batch
            kernel.set_subgraph_information(conv_matrix, subgraph_nodes)
        else:
            X_batch, y_batch = batch
            X_batch = tf.cast(X_batch, tf.float32)
        # Perform update step.
        with tf.GradientTape(watch_accessed_variables=False) as tape:
            tape.watch(gprocess.trainable_variables)
            objective = -gprocess.elbo((X_batch, y_batch))
            gradients = tape.gradient(objective, gprocess.trainable_variables)
        optimizer.apply_gradients(zip(gradients, gprocess.trainable_variables))
        logger.add_values({"nELBO": objective.numpy()})


def evaluate(data_loader, gprocess, kernel, logger):
    for batch in data_loader:
        # Obtain minibatch data in right format.
        if len(batch) > 2:
            X_batch, y_batch, conv_matrix, subgraph_nodes, _ = batch
            kernel.set_subgraph_information(conv_matrix, subgraph_nodes)
        else:
            X_batch, y_batch = batch
            X_batch = tf.cast(X_batch, tf.float32)
        # Evaluate model.
        pred_y, pred_y_var = gprocess.predict_y(X_batch)
        likelihood = gprocess.predict_log_density((X_batch, y_batch))
        logger.add_values({
            "test_labels": y_batch.numpy(),
            "test_predictions": pred_y.numpy(),
            "test_variances": pred_y_var.numpy(),
            "test_likelihood": likelihood.numpy(),
        })


def setup_training_env():
    cp_folder = pathlib.Path(ts.cp_folder)
    if not cp_folder.exists():
        cp_folder.mkdir(parents=True, exist_ok=True)
    # Set up performance logger
    log_filepath = checkpoint_filepath(cp_folder, "log", __file__,
                                       file_ending=".pk")
    metric_funcs = {
        "nELBO": (lambda m: np.mean(m["nELBO"])),
        "test_acc": (lambda m: compute_binary_accuracy(m["test_predictions"], m["test_labels"])),
        "test_auc": (lambda m: compute_auc(m["test_predictions"], m["test_labels"])),
        "test_ap": (lambda m: compute_ap(m["test_predictions"], m["test_labels"])),
        "test_likelihood": (lambda m: compute_mean(m["test_likelihood"])),
    }
    logger = PerformanceLogger(
        metric_funcs, "nELBO", log_filepath, write_every=ts.write_log_every,
        final_test_metrics=["test_acc", "test_auc", "test_ap",
                            "test_likelihood"])
    # Set up model checkpointing
    weights_filepath = checkpoint_filepath(cp_folder, "weights", __file__,
                                           file_ending=".pk")
    # Set up writing stdout to file
    output_filepath = checkpoint_filepath(cp_folder, "output", __file__,
                                          file_ending=".txt")
    output_logger = OutputLogger(output_filepath)
    sys.stdout = output_logger
    results_filepath = checkpoint_filepath(cp_folder, "results", __file__,
                                                file_ending=".pk")
    summary_filepath = checkpoint_filepath(cp_folder, "summary", __file__,
                                           file_ending=".txt")
    # Write hyperparameters to file
    ts.write_summary_file(checkpoint_filepath(cp_folder, "hyperparams",
                                              __file__, file_ending=".txt"))
    print(ts.settings_description())
    return (log_filepath, logger, weights_filepath, output_logger,
            summary_filepath, results_filepath)


def run_training():
    (log_filepath, logger, weights_filepath, output_logger,
     summary_filepath, results_filepath) = setup_training_env()

    # Set random seed
    random.seed(ts.seed)
    np.random.seed(ts.seed)
    tf.random.set_seed(ts.seed)
    # Set float type
    gpflow.config.set_default_float(ts.float_type)

    # Load data set
    ds = LinkPredictionDataset(ts.dataset_path, ts.dataset_name,
                               ts.dataset_folder, split_seed=ts.seed,
                               train_batch_size=ts.batch_size,
                               test_batch_size=ts.test_batch_size,
                               subsample_sizes=ts.num_node_samples,
                               float_type=ts.float_type, extract_subgraphs=True,
                               node2vec_embeddings=ts.node2vec_embeddings,
                               test_fraction=ts.test_fraction,
                               train_set_frac=ts.train_set_frac,
                               missing_frac=ts.missing_frac,
                               pert_frac=ts.perturb_frac)

    # Init kernel
    base_kernel = gpflow.kernels.RBF(
        lengthscales=ts.initial_lengthscale * np.ones(ds.node_features.shape[1]))
    # base_kernel = gpflow.kernels.Polynomial()
    kernel = EdgeGraphConvolutional(base_kernel, ds.get_conv_matrix(),
                                    ds.node_features, ts.num_convs)
    # hyperparams = kernel.trainable_variables

    # Init inducing points
    # num_nodes = 1900
    # inducing_points = kmeans2(ds.node_features, num_nodes, minit='points')[0]
    # inducing_points = BipartiteGraphInducingPoints(
    #     inducing_points[:num_nodes // 2],
    #     inducing_points[num_nodes // 2:(2 * (num_nodes // 2))])
    num_inducing_nodes = ds.num_nodes // 8 if ts.num_inducing_nodes is None else ts.num_inducing_nodes
    num_inducing_edges = num_inducing_nodes * 2 if ts.num_inducing_edges is None else ts.num_inducing_edges
    inducing_points = kmeans2(ds.node_features, num_inducing_nodes, minit='points')[0]
    inducing_points = GraphInducingPoints(inducing_points, num_inducing_edges)

    # Init GP model
    mean_function = Constant()
    gprocess = SVGP(kernel, gpflow.likelihoods.Bernoulli(), inducing_points,
                    mean_function=mean_function, whiten=True, q_diag=False,
                    num_data=ds.num_train_samples)

    # Init optimizer
    optimizer = tf.optimizers.Adam(learning_rate=ts.lr)

    for epoch in range(ts.num_epochs):
        # training step
        training_step(ds.train_loader, gprocess, kernel, optimizer, logger)
        # test step
        evaluate(ds.test_loader, gprocess, kernel, logger)

        logger.complete_epoch(lambda: save_tf_module_weights(gprocess,
                                                             weights_filepath))
        print(logger.epoch_summary())
        # if epoch % ts.print_hparams_every == 0:
        #     print_parameters(hyperparams)
        #     print(f"\t- {kernel.weights}")
        # early stopping in case of convergence
        if logger.has_converged(last_improvement=ts.convergence_stop_epoch):
            break

    # Evaluate on test set with the best model
    load_tf_module_weights(gprocess, weights_filepath)
    evaluate(ds.test_loader, gprocess, kernel, logger)
    logger.write_epoch_metrics(results_filepath)
    logger.complete_epoch()
    print(logger.epoch_summary())

    # Cleanup after training
    output_logger.close()
    sys.stdout = sys.__stdout__
    logger.write(log_filepath)
    logger.write_summary(summary_filepath, ts.settings_description())
    return logger


if __name__ == '__main__':
    run_training()