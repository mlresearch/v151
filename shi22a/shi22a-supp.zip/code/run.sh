python3 LTT-cnn-mnist.py
python3 train.py
