########################################################################
## Simulation Module: 
## (1) Generate data for all scenarios and repetitions.
## (2) Benchmark all the methods on each dataset.
# 
#
# There are 5 methods to compare:
# (1) CPDI-linear: Complete Probability Dose Interval with linear kernel. 
# (2) CPDI-kernel: Complete Probability Dose Interval with Gaussian kernel. 
# (11) Logistic-clas: indirect classification method using penalized logistic regression.  
# (12) SVM-clas: indirect classification method using SVM.   
# (13) RF-clas: indirect classification method RandomForecast.    

# The function simulation() calls all 16 methods for a single task, say, a certain repetition of one Scenario.
# Due to the randomness of algorithms, certain methods sometimes fail.
# This function continueously load measurement from disk in 'output/Measure.Rdata' and update it with newest results.
# If there are failed tasks, rerun the failed seed corresponding to the task.
########################################################################
setwd("~/Downloads/dose_interval/")
library(kernlab)
library(e1071)
library(truncnorm)
library(WeightIt)
library(ggplot2)
#source("functions.r")
#source("pdi_new.r")
#source("main_distance_functions_08-15-20.R")
#source("scenarios.r")
#source("indirect.R")
library(glmnet)
library(randomForest)


#Scenario=c('Scenario1.continuous','Scenario2.continuous','Scenario1.continuous.prognostic','Scenario2.continuous.prognostic')
#Scenario=c('Scenario1.continuous.prognostic','Scenario2.continuous.prognostic')
#Scenario=c('Scenario1.continuous')
#Scenario=c('Scenario2.continuous')
Scenario=c('Scenario1.continuous.prognostic')
#Scenario=c('Scenario2.continuous.prognostic')
#Scenario=c('Scenario2.prognostic.hn')
N=c(400) # please use smaller sample size for code test. 
P=c(10,50)
rpt=1:100  # please use fewer repetitions for code test. 
alpha=c(0.5,0.5)

methodNames=c('CPDI-linear','CPDI-kernel','Logistic-clas','SVM-clas','RF-clas')
measureNames=c('misclass','bestPara','MSE','correlation','percentage','time')
tasks=methodNames

Grid.cv=expand.grid(N=N,P=P,Scenario=Scenario,rpt=rpt)  # all combinations.
Grid.cv=cbind(Grid.cv,rep(FALSE,dim(Grid.cv)[1]),matrix(NA,nrow=dim(Grid.cv)[1],ncol=5))
names(Grid.cv)[5]='check'
names(Grid.cv)[-c(1:5)]=methodNames
Measure=array(data = NA, dim = c(dim(Grid.cv)[1],5,9), dimnames = list(1:dim(Grid.cv)[1],methodNames,c(names(Grid.cv)[1:3],measureNames)))
save(Measure,file = '~/Measure.Rdata')

#########
simulation<-function(seed,tasks){
  print(seed)
  #library(devtools)
  source('functions.r')
  source('scenarios.r')
  source('indirect.r')
  source('pdi_new.r')
  source('main_distance_functions_08-15-20.r')
  set.seed(seed+24601)
  n=Grid.cv$N[seed]
  p=Grid.cv$P[seed]
  
  #Eps=0.3
  
  dataGen=Grid.cv$Scenario[seed]
  two.sided=FALSE
  
  train=eval(parse(text=paste0(dataGen,'(',n,',',p,',',seed,')')))
  test=eval(parse(text=paste0(dataGen,'(',10000,',',p,',',seed,',test = TRUE)')))
  

  
  #####################################################
  ## Classification Based Methods
  ####################################################
  
  # logistic regression method
  if ('Logistic-clas'%in%tasks){
    before=Sys.time()
    tmp=NULL
    cvLogist=cv.logist(train=train,test=test,nfolds=5,two.sided=two.sided)
    after=Sys.time()
    load('Measure.Rdata')
    tmp=cvLogist
    Measure[seed,"Logistic-clas",]=c(n,p,dataGen,tmp$measures$misclass,tmp$bestPara,tmp$measures$Rsquare,tmp$measures$correlation,tmp$measures$percentage,as.numeric(after-before))
    save(Measure,file = 'Measure.Rdata')
  }
  # SVM
  if ('SVM-clas'%in%tasks){
    before=Sys.time()
    tmp=NULL
    cvSVM=cv.SVM(train=train,test=test,nfolds=5,two.sided=two.sided)
    after=Sys.time()
    load('Measure.Rdata')
    tmp=cvSVM
    Measure[seed,"SVM-clas",]=c(n,p,dataGen,tmp$measures$misclass,tmp$bestPara,tmp$measures$Rsquare,tmp$measures$correlation,tmp$measures$percentage,as.numeric(after-before))
    save(Measure,file = 'Measure.Rdata')
  }
  # randomForest
  if ('RF-clas'%in%tasks){
    before=Sys.time()
    tmp=NULL
    cvRF=cv.forest(train=train,test=test,nfolds=5,two.sided=two.sided)
    after=Sys.time()
    load('Measure.Rdata')
    tmp=cvRF
    Measure[seed,"RF-clas",]=c(n,p,dataGen,tmp$measures$misclass,tmp$bestPara,tmp$measures$Rsquare,tmp$measures$correlation,tmp$measures$percentage,as.numeric(after-before))
    save(Measure,file = 'Measure.Rdata') 
  }
  
  ####################################################
  ## Quadratic Programming (based on 'quadprogpp')
  ####################################################
  # search_train=searchInterval(cvRF$fitted,train,two.sided=two.sided)
 
  if ('CPDI-linear'%in%tasks){
    # CPDI-linear
    before=Sys.time()
    CPDI.linear= cv.doseInt(train,test=test,method="L-O-Learning",pred_old =  NULL)
    after=Sys.time()
    load('Measure.Rdata')
    tmp=CPDI.linear
    plot(log(tmp$Rec$Para),tmp$Rec$Misclass,'l')
    Measure[seed,"CPDI-linear",]=c(n,p,dataGen,tmp$measures$misclass,tmp$bestPara,tmp$measures$Rsquare,tmp$measures$correlation,tmp$measures$percentage,as.numeric(after-before))
    save(Measure,file = 'Measure.Rdata')
  }
  
  if ('CPDI-kernel'%in%tasks){
    # CPDI-kernel
    before=Sys.time()
    CPDI.kernel= cv.doseInt(train,test=test,method="G-O-Learning",pred_old =  NULL)
    #CPDI.kernel= cv.doseInt(train,test=test,method="G-O-Learning")
    after=Sys.time()
    load('Measure.Rdata')
    tmp=CPDI.kernel
    plot(log(tmp$Rec$Para),tmp$Rec$Misclass,'l')
    Measure[seed,"CPDI-kernel",]=c(n,p,dataGen,tmp$measures$misclass,tmp$bestPara,tmp$measures$Rsquare,tmp$measures$correlation,tmp$measures$percentage,as.numeric(after-before))
    save(Measure,file = 'Measure.Rdata')
  }
  

  #searchInterval(fitted=cvRF$fitted,test=train,two.sided=two.sided,lower=TRUE)
  return(Measure[seed,,])
}

library(parallel)
library(snowfall)

sfInit(parallel=TRUE, cpus=detectCores()-2, type="SOCK")


#library(cobalt)
sfLibrary(WeightIt)
sfLibrary(ggplot2)

sfLibrary(glmnet)
sfLibrary(quantreg)
sfLibrary(truncnorm)
sfLibrary(kernlab)
sfLibrary(mgcv)
sfLibrary(e1071)
sfLibrary(randomForest)
sfLibrary(osqp)


sfExportAll()

res <- sfClusterApplyLB((1:dim(Grid.cv)[1]), simulation,tasks=tasks)
sfStop() 


#misclassNames=c('CPDI-linear','CPDI-kernel','Logistic-clas','SVM-clas','RF-clas')
#costNames=c('EDI-linear','EDI-kernel','EDI-RLT','CEDI-linear','CEDI-kernel','Lasso-regr','SVR-regr','RF-regr')

#summarized = (res[[1]] + res[[2]] + res[[3]] + res[[4]]  + res[[5]] + res[[6]] + res[[7]] + res[[8]] )/8

