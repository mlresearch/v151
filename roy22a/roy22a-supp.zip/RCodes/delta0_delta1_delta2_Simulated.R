rm(list = ls())
start.time <- proc.time()
set.seed(1)
library(parallel)
library(RcppArmadillo)
library(RcppXPtrUtils)
library(parallelDist)
source('dissim_sine.R')
source('dissim_sine_comp.R')

no.cores = round(detectCores() * 0.75)
ITER = 100
d <- c(50,100,250,500,1000)
n <- 20 #training size of class 1
m <- 20 #training size of class 2
ns <- 100 #test size of class 1
ms <- 100 #test size of class 2

#------------dissimilarity computation--------------------------
out1 = NULL
for(i in 1:length(d)){
  out = NULL
  for(
    u in 1:ITER){
    
    X <-
      matrix(
        rnorm(n = (n + ns) * d[i], mean = 1, sd = 1), # for gaussian scale problem
        
        # rnorm(n = (n + ns) * d[i], mean = 1, sd = sqrt(3)), # for gaussian vs t3 shape problem
        
        # rcauchy(n = (n + ns)*d[i], location = 0, scale = 1), # for cauchy location problem
        # (1 - runif((n+ns)*d[i]))^(-1), #pareto with support [1,infinity] and scale 1
        
        nrow = n + ns,
        ncol = d[i],
        byrow = TRUE
      )
    Y <-
      matrix(
        rnorm(n = (m + ms) * d[i], mean = 1, sd = sqrt(2)), # for gaussian scale problem
        # rt(n = (m + ms) * d[i], df = 3), #for gaussian vs t3 shape problem 
        # rcauchy(n = (m + ms)*d[i], location = 1, scale = 1), # for cauchy location problem 
        # rcauchy(n = (m + ms)*d[i], location = 0, scale = 2), # for cauchy scale problem
        # 1.25*(1 - runif((m + ms)*d[i]))^(-1), #pareto with support [1.25,infinity] and scale 1
        nrow = m + ms,
        ncol = d[i],
        byrow = TRUE
      )
    
    TFG.sin.mat = as.matrix(dissim.sin(train.set = rbind(X, Y), no.cores = no.cores))
    TFG.sincomp.mat = as.matrix(dissim.sin.comp(train.set = rbind(X, Y), no.cores = no.cores))
    
    Z <-
      rbind(X[(n + 1):(n + ns), ], Y[(m + 1):(m + ms), ])     ## Test Observations
    
    X <- X[1:n, ]
    Y <- Y[1:m, ]
    Q <- rbind(X, Y)
    
    
    ground.label <- c(rep(1, ns), rep(2, ms))
    
    t1 = c(1:n, n + ns + (1:m))
    t2 = c(n + (1:ns), n + ns + m + (1:ms))
    
    #---------------------- delta0 classifier -----------------------
    S.Train.sin = TFG.sin.mat[t1, t1] #(i,j)th element corresponds to rho-index between i-th and j-th training observations
    TFF.sin = sum(S.Train.sin[1:n, 1:n]) / (n * (n - 1))
    TGG.sin = sum(S.Train.sin[n + (1:m), n + (1:m)]) / (m * (m - 1))
    
    S.Test.sin = TFG.sin.mat[t1, t2]#(i,j)th element corresponds to rho-index between i-th training and j-th test observations
    TFZ.sin = colMeans(S.Test.sin[1:n,])
    TGZ.sin = colMeans(S.Test.sin[n + (1:m),])
    
    LFZ.sin = rep(TFF.sin, ns + ms) / 2 - TFZ.sin
    LGZ.sin = rep(TGG.sin, ns + ms) / 2 - TGZ.sin
    
    lbl0.sin = lbl1.sin = lbl2.sin = rep(2, ns + ms)
    lbl0.sin[LGZ.sin - LFZ.sin > 0] = 1 # classifier delta0
    e0.sin = mean(lbl0.sin != ground.label)
    
    #-------------------- projection ensemble classifier: component-wise----------
    S.Train.sin.comp = TFG.sincomp.mat[t1, t1]#(i,j)th element corresponds to rho-index between i-th and j-th training observations
    TFF.sin.comp = sum(S.Train.sin.comp[1:n, 1:n]) / (n * (n - 1))
    TFG.sin.comp = sum(S.Train.sin.comp[1:n, n + (1:m)]) / (n * m)
    TGG.sin.comp = sum(S.Train.sin.comp[n + (1:m), n + (1:m)]) / (m * (m -
                                                                         1))
    
    en.sin.comp = TFF.sin.comp + TGG.sin.comp - 2 * TFG.sin.comp
    SFG.Sin.Comp = TFF.sin.comp - TGG.sin.comp
    
    S.Test.sin.comp = TFG.sincomp.mat[t1, t2]#(i,j)th element corresponds to rho-index between i-th training and j-th test observations
    TFZ.sin.comp = colMeans(S.Test.sin.comp[1:n,])
    TGZ.sin.comp = colMeans(S.Test.sin.comp[n + (1:m),])
    
    LFZ.sin.comp = rep(TFF.sin.comp, ns + ms) / 2 - TFZ.sin.comp
    LGZ.sin.comp = rep(TGG.sin.comp, ns + ms) / 2 - TGZ.sin.comp
    SZ.sin.comp = -rep(TFG.sin.comp, ns + ms) - (LFZ.sin.comp + LGZ.sin.comp)
    
    lbl0.sin.comp = lbl1.sin.comp = lbl2.sin.comp = rep(2, ns + ms)
    lbl0.sin.comp[LGZ.sin.comp - LFZ.sin.comp > 0] = 1
    e0.sin.comp = mean(lbl0.sin.comp != ground.label) # classifier delta 1
    
    
    lbl2.sin.comp[en.sin.comp * (LGZ.sin.comp - LFZ.sin.comp) + SFG.Sin.Comp * SZ.sin.comp >0] = 1 #classifier delta2
    e2.sin.comp = mean(lbl2.sin.comp != ground.label)
    #-----------------------------------------------------------------------------
    
    
    out[[u]] = c(d[i],
      e0.sin,
      e0.sin.comp,
      e2.sin.comp
    )
    
    print(u)
  }
  out = do.call('rbind', out)
  colnames(out) = c(
    'dim',
    'delta0',
    'delta1',
    'delta2'
  )
  
  out1[[i]] = out
  print(i)
  print(colMeans(out[,-1]))
}
names(out1) = paste('d=',d[1:i],sep='')
do.call('rbind', lapply(out1, colMeans))