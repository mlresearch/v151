from utils.enums import *

class SIMSDefaults:
    """
    Defaults to be used by SIMS models
    """
    DEFAULT_MAX_ITEM = 30000
    DEFAULT_MAX_USER = 30000
    DEFAULT_HIDDEN_DIM = 100
    DEFAULT_ID_DIM = 30
    DEFAULT_FEATURE_CHANNEL_DIM = {}
    EARLY_STOPPING = True
    DEFAULT_NUM_EPOCHS = 500
    DEFAULT_LOSS = Losses.ContrastiveLossV1
    DEFAULT_OPTIMIZER = Optimizers.adam
    DEFAULT_LEARNING_RATE = 1e-4

class SPEDefaults:
    """
    Defaults to be used by SPE models
    """
    DEFAULT_MAX_ITEM = 30000
    DEFAULT_MAX_USER = 30000
    DEFAULT_HIDDEN_DIM = 100
    DEFAULT_ID_DIM = 30
    DEFAULT_FEATURE_CHANNEL_DIM = {}
    EARLY_STOPPING = True
    DEFAULT_NUM_EPOCHS = 500
    DEFAULT_LOSS = Losses.BinaryCrossEntropy
    DEFAULT_OPTIMIZER = Optimizers.adam
    DEFAULT_LEARNING_RATE = 1e-4