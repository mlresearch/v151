import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import time

mpl.rcParams["figure.figsize"] = [5, 3]

mpl.rcParams["axes.linewidth"] = 0.75
mpl.rcParams["figure.facecolor"] = "w"
mpl.rcParams["grid.linewidth"] = 0.75
mpl.rcParams["lines.linewidth"] = 0.75
mpl.rcParams["patch.linewidth"] = 0.75
mpl.rcParams["xtick.major.size"] = 3
mpl.rcParams["ytick.major.size"] = 3

mpl.rcParams["pdf.fonttype"] = 42
mpl.rcParams["ps.fonttype"] = 42
mpl.rcParams["font.size"] = 7
mpl.rcParams["axes.titlesize"] = "medium"
mpl.rcParams["legend.fontsize"] = "medium"
mpl.rcParams["font.weight"] = "bold"


#%%
class SpikeEnv:
  """Environment where the examination probabilities and
     attractiveness/relevance probabilities are uniform except for a single
     item. The first item in the slate has higher probability of examination
     than the rest, and only one item in the set of all items has
     higher probability of being attractive/relevant.
  """
  def __init__(self, K = 4, L = 16, baseu = 0.5, gapu = 0.4, basev = 0.5, gapv = 0.4):
    self.K = K  # Slate size
    self.L = L  # Total number of items

    self.ubar = baseu * np.ones(K)  # examination probs for slate items
    self.ubar[0] += gapu  # first item more likely to be examined
    self.vbar = basev * np.ones(L)  # attraction/relevance probs for all items
    self.vbar[L // 2] += gapv  # the middle item is more likely to be relevant
    self.best_action = np.argsort(self.vbar)[: : -1][: self.K]  # the optimal action is to choose the K most attractive items

    self.ut = np.zeros(K)  # actual attraction/relevance (binary)
    self.vt = np.zeros(L)  # actual examination (binary)

  def name():
    return 'Spike'

  def randomize(self):
    # sample random variables
    self.ut = np.array(np.random.rand(self.K) < self.ubar, dtype = np.int)  
    self.vt = np.array(np.random.rand(self.L) < self.vbar, dtype = np.int)

  def reward(self, action):
    # reward of action (chosen items)
    return np.multiply(self.ut, self.vt[action])

  def reward_scalar(self, action):
    return np.dot(self.ut, self.vt[action])

  def regret(self, action):
    # regret of action (chosen items)
    return self.reward_scalar(self.best_action) - self.reward_scalar(action)

  def expected_reward(self, action):
    # expected regret of action (chosen items)
    return np.dot(self.ubar, self.vbar[action])

  def pregret(self, action):
    # expected regret of action (chosen items)
    return self.expected_reward(self.best_action) - self.expected_reward(action)

  def plot(self):
    # plot model parameters
    fig, (left, right) = plt.subplots(ncols = 2, figsize = (10, 3))
    left.plot(self.ubar)
    right.plot(self.vbar)
    plt.show()

class PBMEnv(SpikeEnv):
  def __init__(self):
    self.K = 5
    self.L = 10

    self.ubar = np.random.rand(self.K)  # random examination probs
    self.vbar = np.random.rand(self.L)  # random attraction/relevance probs
    self.best_action = np.argsort(self.vbar)[: : -1][: self.K]

    self.ut = np.zeros(self.K)
    self.vt = np.zeros(self.L)

  def name():
    return 'PBM'

class CMEnv:
  def __init__(self):
    self.K = 5
    self.L = 10

    self.vbar = np.random.rand(self.L)  # random attraction/relevance
    self.best_action = np.argsort(self.vbar)[: : -1][: self.K]

    self.vt = np.zeros(self.L)

  def name():
    return 'CM'

  def randomize(self):
    # sample random variables
    self.vt = np.array(np.random.rand(self.L) < self.vbar, dtype = np.int)  # realize attraction/relevance

  def reward(self, action):
    # reward of action (chosen items)
    r = self.vt[action]
    if r.sum() > 0:
      first_click = np.flatnonzero(r)[0]
      r[first_click + 1 :] = 0
    return r

  def reward_scalar(self, action):
    return 1 - np.prod(1 - self.reward(action))

  def regret(self, action):
    # regret of action (chosen items)
    return self.reward_scalar(self.best_action) - self.reward_scalar(action)

  def expected_reward(self, action):
    return 1 - np.prod(1 - self.vbar[action])

  def pregret(self, action):
    # expected regret of action (chosen items)
    return self.expected_reward(self.best_action) - self.expected_reward(action)


class DCMEnv:
  def __init__(self, K, L, beta_a, beta_b):
    self.K = K  # Slate size
    self.L = L  # Total number of items

    if (len(beta_a) != self.L  or
        len(beta_b) != self.L):
      raise ValueError("Prior params dimension mismatch.")
    self.beta_a = beta_a
    self.beta_b = beta_b

    # Sample problem instance from prior
    self.vbar = np.random.beta(self.beta_a, self.beta_b)
    self.best_action = np.argsort(self.vbar)[: : -1][: self.K]
    self.p_exit_given_click = 0.5 * np.ones(self.K)  # exit probabilities

    self.vt = np.zeros(self.L)
    self.et = np.zeros(self.K)

  def name():
    return 'DCM'

  def get_prior(self):
    return (self.beta_a, self.beta_b)

  def randomize(self):
    # sample random variables
    self.vt = np.array(np.random.rand(self.L) < self.vbar, dtype = np.int)  # realize attraction/relevance
    self.et = np.array(np.random.rand(self.K) < self.p_exit_given_click, dtype = np.int)

  def reward(self, action):
    # reward of action (chosen items)
    r = self.vt[action]
    if (r * self.et).sum() > 0:
      # noting after click that is exiting
      first_click = np.flatnonzero(r * self.et)[0]
      r[first_click + 1 :] = 0
    return r

  def reward_scalar(self, action):
    return 1 - np.prod(1 - (self.reward(action) * self.et))

  def regret(self, action):
    # regret of action (chosen items)
    return self.reward_scalar(self.best_action) - self.reward_scalar(action)

  def expected_reward(self, action):
    return 1 - np.prod(1 - self.vbar[action] * self.p_exit_given_click)

  def pregret(self, action):
    # expected regret of action (chosen items)
    return self.expected_reward(self.best_action) - self.expected_reward(action)


#%% Envoronment with Prior
class PriorCMEnv(CMEnv):
  """Environment defined by a Beta prior for each item (arm). Using a cascade
     model for examination.
  """
  def __init__(self, K, L, beta_a, beta_b):
    self.K = K  # Slate size
    self.L = L  # Total number of items

    if (len(beta_a) != self.L  or
        len(beta_b) != self.L):
      raise ValueError("Prior params dimension mismatch.")
    self.beta_a = beta_a
    self.beta_b = beta_b

    # Sample problem instance from prior
    self.vbar = np.random.beta(self.beta_a, self.beta_b)
    self.best_action = np.argsort(self.vbar)[: : -1][: self.K]

    self.vt = np.zeros(self.L)

  def name():
    return 'CM'

  def get_prior(self):
    return (self.beta_a, self.beta_b)


#%%
class PriorDCTREnv(PriorCMEnv):
  def name():
    return 'DCTR'

  def reward(self, action):
    # reward of action (chosen items)
    r = self.vt[action]
    return r

  def reward_scalar(self, action):
    return np.sum(self.reward(action))

  def expected_reward(self, action):
    return np.sum(self.vbar[action])


#%%
def misspecify(beta_a, beta_b, misspecification):
  return beta_a + misspecification, beta_b - misspecification


#%%
def evaluate_one(Bandit, env, T, period_size, random_seed, misspecification=0):
  bandit = Bandit(env.L, T)
  np.random.seed(random_seed)

  if isinstance(bandit, BayesianBeta):
    prior_func = getattr(env, "get_prior", None)
    if callable(prior_func):
      beta_a, beta_b = prior_func()
      if misspecification:
        beta_a, beta_b = misspecify(beta_a, beta_b, misspecification)
      bandit.set_prior(beta_a, beta_b)
    else:
      raise ValueError("Can only use Thompson Sampling with environments that "
                       "have a prior.")

  regret = np.zeros(T // period_size)
  for t in range(T):
    # generate state
    env.randomize()

    # take action
    action = bandit.get_action(t, env.K)

    # update model and regret
    bandit.update(t, action, env.reward(action))
    regret[t // period_size] += env.regret(action)

  return (regret, bandit)

def evaluate(Bandit, env, num_exps = 5, T = 1000, period_size = 1, display = True, misspecification=0):
  if display:
    print("Simulation with %s positions and %s items" % (env.K, env.L))

  seeds = np.random.randint(2 ** 15 - 1, size = num_exps)
  output = [evaluate_one(Bandit, env, T, period_size, seeds[ex], misspecification) for ex in range(num_exps)]
  regret = np.vstack([item[0] for item in output]).T
  bandit = output[-1][1]

  if display:
    regretT = np.sum(regret, axis = 0)
    print("Regret: %.2f \\pm %.2f, " % (np.mean(regretT), np.std(regretT) / np.sqrt(num_exps)))

  return (regret, bandit)


#%%
class BayesianBeta:
  def __init__(self, L, T):
    self.L = L

    self.pulls = np.zeros(L)
    self.reward = np.zeros(L)

    # Need to call set_prior to set these:
    self.beta_a = np.zeros(L)
    self.beta_b = np.zeros(L)

  def name():
    raise NotImplementedError()

  def set_prior(self, beta_a, beta_b):
    if (len(beta_a) != len(self.beta_a)  or
        len(beta_b) != len(self.beta_b)):
      raise ValueError("Prior params dimension should match.")
    self.beta_a = beta_a
    self.beta_b = beta_b

  def update(self, t, action, r):
    if r.sum() > 0:
      last_click = np.flatnonzero(r)[-1]
      action = action[: last_click + 1]
      r = r[: last_click + 1]

    self.pulls[action] += 1
    self.reward[action] += r

  def posterior_params(self):
    a = self.beta_a + self.reward
    b = self.beta_b + (self.pulls - self.reward)
    return a, b


class ThompsonSampling(BayesianBeta):
  def name():
    return "ThompsonSampling"

  def posterior_sample(self):
    a, b = self.posterior_params()
    return np.random.beta(a, b)

  def get_action(self, t, K):
    posterior_sample = self.posterior_sample()
    action = np.argsort(posterior_sample)[: : -1][: K]
    return action


from scipy.stats import beta

class BayesUCB(BayesianBeta):
  def name():
    return "BayesUCB"

  def get_action(self, t, K):
    # Compute posterior
    a, b = self.posterior_params()
    q = 1. - 1. / (t+1)  # quantile
    ucbs = beta.ppf(q, a, b)
    action = np.argsort(ucbs)[: : -1][: K]
    return action


#%%
class ThompsonSamplingPriorOnly(ThompsonSampling):
  def name():
    return "ThompsonSampling (prior only)"

  def posterior_params(self):
    return self.beta_a, self.beta_b

class BayesUCBPriorOnly(BayesUCB):
  def name():
    return "BayesUCB (prior only)"

  def posterior_params(self):
    return self.beta_a, self.beta_b


#%%
class Greedy():
  def __init__(self, L, T):
    self.L = L

    self.pulls = np.zeros(L)
    self.reward = np.zeros(L)

  def name():
    return "Greedy"

  def update(self, t, action, r):
    if r.sum() > 0:
      last_click = np.flatnonzero(r)[-1]
      action = action[: last_click + 1]
      r = r[: last_click + 1]

    self.pulls[action] += 1
    self.reward[action] += r

  def get_action(self, t, K):
    posterior_means = self.reward / (self.pulls + 1)  # prevent dividsion by 0
    action = np.argsort(posterior_means)[: : -1][: K]
    return action


#%%
class CascadeUCB1:
  def __init__(self, K, T):
    self.K = K

    self.pulls = 1e-6 * np.ones(K) # number of pulls
    self.reward = 1e-6 * np.random.rand(K) # cumulative reward
    self.tiebreak = 1e-6 * np.random.rand(K) # tie breaking

    self.ucb = np.zeros(K)

  def name():
    return "CascadeUCB1"

  def update(self, t, action, r):
    if r.sum() > 0:
      last_click = np.flatnonzero(r)[-1]
      action = action[: last_click + 1]
      r = r[: last_click + 1]

    self.pulls[action] += 1
    self.reward[action] += r

    # UCBs
    t += 1 # time starts at one
    ct = np.maximum(np.sqrt(2 * np.log(t)), 2)
    self.ucb = self.reward / self.pulls + ct * np.sqrt(1 / self.pulls)

  def get_action(self, t, num_pulls):
    action = np.argsort(self.ucb + self.tiebreak)[: : -1][: num_pulls]
    return action

class CascadeKLUCB:
  def __init__(self, K, T):
    self.K = K

    self.pulls = 1e-6 * np.ones(K) # number of pulls
    self.reward = 1e-6 * np.random.rand(K) # cumulative reward
    self.tiebreak = 1e-6 * np.random.rand(K) # tie breaking

    self.ucb = (1 - 1e-6) * np.ones(K)

  def name():
    return "CascadeKLUCB"

  def UCB(self, p, N, t):
    C = (np.log(t) + 3 * np.log(np.log(t) + 1)) / N
    tol = 1e-5

    kl = p * np.log(p / self.ucb) + (1 - p) * np.log((1 - p) / (1 - self.ucb))
    for k in np.flatnonzero(np.abs(kl - C) > tol):
      ql = min(max(p[k], 1e-6), 1 - 1e-6)
      qu = 1 - 1e-6
      while qu - ql > tol:
        q = (ql + qu) / 2
        f = p[k] * np.log(p[k] / q) + (1 - p[k]) * np.log((1 - p[k]) / (1 - q))
        if f < C[k]:
          ql = q
        else:
          qu = q
      self.ucb[k] = qu

  def update(self, t, action, r):
    if r.sum() > 0:
      last_click = np.flatnonzero(r)[-1]
      action = action[: last_click + 1]
      r = r[: last_click + 1]

    self.pulls[action] += 1
    self.reward[action] += r

    # UCBs
    t += 1 # time starts at one
    self.UCB(self.reward / self.pulls, self.pulls, t)

  def get_action(self, t, num_pulls):
    action = np.argsort(self.ucb + self.tiebreak)[: : -1][: num_pulls]
    return action

class TopRank:
  def __init__(self, K, T):
    self.K = K
    self.T = T

    self.pulls = np.ones((K, K)) # number of pulls
    self.reward = np.zeros((K, K)) # cumulative reward

    self.G = np.ones((K, K), dtype = bool)
    self.P = np.zeros(K)
    self.P2 = np.ones((K, K))

  def name():
    return "TopRank"

  def rerank(self):
    Gt = (self.reward / self.pulls - 2 * np.sqrt(np.log(self.T) / self.pulls)) > 0
    if not np.array_equal(Gt, self.G):
      self.G = np.copy(Gt)

      Pid = 0
      self.P = - np.ones(self.K)
      while (self.P == -1).sum() > 0:
        items = np.flatnonzero(Gt.sum(axis = 0) == 0)
        self.P[items] = Pid
        Gt[items, :] = 0
        Gt[:, items] = 1
        Pid += 1

      self.P2 = \
        (np.tile(self.P[np.newaxis], (self.K, 1)) == np.tile(self.P[np.newaxis].T, (1, self.K))).astype(float)

  def update(self, t, action, r):
    clicks = np.zeros(self.K)
    clicks[action] = r

    M = np.outer(clicks, 1 - clicks) * self.P2
    self.pulls += M + M.T
    self.reward += M - M.T

    self.rerank()

  def get_action(self, t, num_pulls):
    action = np.argsort(self.P + 1e-6 * np.random.rand(self.K))[: num_pulls]
    return action


#%%
# cascade model
T = 2000
num_runs = 50
L = 30
K = 3
beta_a = np.random.randint(low=1, high=10, size=[L])
beta_b = 10 * np.ones([L])
env = PriorCMEnv(K, L, beta_a, beta_b)

steps = range(T)

def eval_and_plot(alg, color, linestyle='-'):
  regret, _ = evaluate(alg, env, num_runs, T)
  cum_regret = np.cumsum(regret, axis=0)
  mean_vals = cum_regret.mean(axis=1)  # size: [T]
  se_vals = cum_regret.std(axis=1) / np.sqrt(num_runs)  # size: [T]
  plt.fill_between(steps, mean_vals+se_vals, mean_vals-se_vals,
                   alpha = 0.1, edgecolor = "none", facecolor = color)
  plt.plot(mean_vals, color=color, label=alg.name(), linestyle=linestyle)

eval_and_plot(BayesUCB, "orange")
#eval_and_plot(BayesUCBPriorOnly, "orange", '--')
eval_and_plot(ThompsonSampling, "green")
eval_and_plot(ThompsonSamplingPriorOnly, "green", '--')
eval_and_plot(CascadeUCB1, "gray")
eval_and_plot(CascadeKLUCB, "blue")
eval_and_plot(TopRank, "red")

plt.legend(loc='upper left')
plt.xlabel("Step n1")
plt.ylabel("Regret")
plt.title("L={}, K={}".format(L, K))
plt.show()


#%%
# Resample Beta prior
def eval_and_plot(regret, color, linestyle='-'):
  cum_regret = np.cumsum(regret, axis=1)
  mean_vals = cum_regret.mean(axis=0)  # size: [T]
  se_vals = cum_regret.std(axis=0) / np.sqrt(np.shape(regret)[0])  # size: [T]
  plt.fill_between(steps, mean_vals+se_vals, mean_vals-se_vals,
                   alpha = 0.1, edgecolor = "none", facecolor = color)
  plt.plot(mean_vals, color=color, label=alg.name(), linestyle=linestyle)

T = 2000
num_trials = 20
runs_per_trial = 20
L = 30
K = 3
envs = [PriorCMEnv, PriorDCTREnv, DCMEnv]
algs = [BayesUCB, ThompsonSampling, CascadeUCB1, CascadeKLUCB, TopRank, Greedy]
alg_colors = {
    BayesUCB.name(): "orange",
    ThompsonSampling.name(): "green",
    Greedy.name(): "purple",
    CascadeUCB1.name(): "gray",
    CascadeKLUCB.name(): "blue",
    TopRank.name(): "red",
}
env_regrets = {}
for env_type in envs:
  print("Envirnoment:", env_type.name())
  regrets = {}
  for alg in algs:
    regrets[alg.name()] = np.array([])
  beta_b = 10 * np.ones([L])
  for i in range(num_trials):
    print("Trial:", i, "out of", num_trials)
    beta_a = np.random.randint(low=1, high=10, size=[L])
    env = env_type(K, L, beta_a, beta_b)

    for alg in algs:
      regret, _ = evaluate(alg, env, runs_per_trial, T)  # [T, runs_per_trial]
      regret = np.transpose(regret)  # [runs_per_trial, T]
      if len(regrets[alg.name()]):
        regrets[alg.name()] = np.concatenate((regrets[alg.name()], regret), axis=0)
      else:
        regrets[alg.name()] = regret
  env_regrets[env_type.name()] = regrets

  # regrets[alg] size: [num_trials * runs_per_trial, T]

steps = range(T)
for env_type in envs:
  plt.figure()
  regrets = env_regrets[env_type.name()]
  for alg in algs:
    eval_and_plot(regrets[alg.name()], alg_colors[alg.name()])

  plt.legend(loc='upper left', prop={'weight':'bold', 'size':10})
  plt.xlabel("Round n", fontweight='bold', fontsize=12)
  plt.ylabel("Regret", fontweight='bold', fontsize=12)
  plt.xticks(fontsize=10)
  plt.yticks(fontsize=10)
  plt.title(env_type.name(), fontweight='bold', fontsize=14)
  # Save fig
  figs_dir = '/tmp/'
  fig_file = figs_dir + env_type.name() + '.pdf'
  plt.savefig(fig_file, format = "pdf", bbox_inches = 0)
  plt.show()


#%%
# Save a copy
import copy
env_regrets_keep = copy.copy(env_regrets)


#%%
for env_type in envs:
  print("Env:", env_type.name())
  regrets = env_regrets[env_type.name()]
  print("toprank mean:", np.mean(np.sum(regrets[TopRank.name()], axis=1)))
  print("greedy mean:", np.mean(np.sum(regrets[Greedy.name()], axis=1)))


#%%
alg_colors = {
    BayesUCB.name(): "orange",
    ThompsonSampling.name(): "green",
    Greedy.name(): "purple",
    CascadeUCB1.name(): "gray",
    CascadeKLUCB.name(): "blue",
    TopRank.name(): "red",
}
alg_labels = {
    BayesUCB.name(): "BayesUCB",
    ThompsonSampling.name(): "TS",
    CascadeUCB1.name(): "CascadeUCB1",
    CascadeKLUCB.name(): "CascadeKL-UCB",
    TopRank.name(): "TopRank",
    Greedy.name(): "Greedy"
}


#%% Plot only
def eval_and_plot(regret, color, linestyle='-'):
  cum_regret = np.cumsum(regret, axis=1)
  mean_vals = cum_regret.mean(axis=0)  # size: [T]
  se_vals = cum_regret.std(axis=0) #/ np.sqrt(np.shape(regret)[0])  # size: [T]
  plt.fill_between(steps, mean_vals+se_vals, mean_vals-se_vals,
                   alpha = 0.1, edgecolor = "none", facecolor = color)
  plt.plot(mean_vals, color=color, label=alg_labels[alg.name()], linestyle=linestyle)

for env_type in envs:
  plt.figure()
  regrets = env_regrets[env_type.name()]
  for alg in algs:
    eval_and_plot(regrets[alg.name()], alg_colors[alg.name()])

  plt.legend(loc='upper left', prop={'weight':'bold', 'size':10}, frameon=False)
  plt.xlabel("Round n", fontweight='bold', fontsize=12)
  plt.ylabel("Regret", fontweight='bold', fontsize=12)
  plt.locator_params(axis='x', nbins=5)
  plt.locator_params(axis='y', nbins=5)
  plt.xticks(fontsize=10)
  plt.yticks(fontsize=10)
  plt.title(env_type.name(), fontweight='bold', fontsize=14)
  plt.gcf().subplots_adjust(bottom=0.15, left=0.15)
  # Save fig
  figs_dir = '/tmp/'
  fig_file = figs_dir + env_type.name() + '.pdf'
  plt.savefig(fig_file, format = "pdf", bbox_inches = 0)
  plt.show()


#%%
env_styles = {
  PriorCMEnv.name(): '-',
  PriorDCTREnv.name(): '--',
  DCMEnv.name(): ':'
}


#%% Bound vs Regret
T = 500
L = 30
K = 3

def get_final_regret(regret):
  cum_regret = np.cumsum(regret, axis=0)  # size: [T, num_runs]
  mean_cum_regret = np.mean(cum_regret, axis=1)
  stdev_cum_regret = np.std(cum_regret, axis=1) / np.sqrt(np.shape(regret)[1])
  return mean_cum_regret[-1], stdev_cum_regret[-1]

envs = [PriorCMEnv, PriorDCTREnv]
bandit_algs = [BayesUCB, ThompsonSampling]
alg_colors = {
    BayesUCB.name(): "orange",
    ThompsonSampling.name(): "green",
    CascadeUCB1.name(): "gray",
    CascadeKLUCB.name(): "blue",
    TopRank.name(): "red",
}
ab_vals = np.array([1, 10, 20, 50, 100, 200, 500, 1000])
b_factor = 10
num_runs = 500
env_alg_ab_regrets = {}
for env_type in envs:
  env_name = env_type.name()
  env_alg_ab_regrets[env_name] = {}
  for alg in bandit_algs:
    alg_name = alg.name()
    env_alg_ab_regrets[env_name][alg_name] = np.zeros((len(ab_vals)))

for i, ab_val in enumerate(ab_vals):
  print("Gamma =", ab_val)
  beta_a = ab_val * np.ones([L])
  beta_b = b_factor * ab_val * np.ones([L])
  for env_type in envs:
    env = env_type(K, L, beta_a, beta_b)
    for bandit_alg in bandit_algs:
      regret, _ = evaluate(bandit_alg, env, num_runs, T)  # [num_runs, T]
      last_regret, _ = get_final_regret(regret)
      env_alg_ab_regrets[env_type.name()][bandit_alg.name()][i] = last_regret

bound1 = np.sqrt(K*L*T*np.log(T))/2 * np.sqrt(np.log(1 + T * 1.0/((b_factor+1)*ab_vals)))
bound2 = np.sqrt(L) * np.log(T) * np.sqrt(T*K + L*(b_factor+1)*ab_vals) - L*np.log(T)*np.sqrt((b_factor+1)*ab_vals)

for env_type in envs:
  env_name = env_type.name()
  for alg in bandit_algs:
    alg_name = alg.name()
    label = env_name + ":" + alg_name
    plt.semilogy(ab_vals, env_alg_ab_regrets[env_name][alg_name],
                 linewidth=2, linestyle=env_styles[env_name],
                 color=alg_colors[alg_name], label=label)
plt.semilogy(ab_vals, bound1, linewidth=2, color='red', label='Bound')
#plt.semilogy(ab_vals, bound2, linewidth=2, color='blue', label='Bound2')

plt.xlabel("Gamma", fontweight='bold', fontsize=12)
plt.ylabel("Regret", fontweight='bold', fontsize=12)
plt.legend(loc='upper right', prop={'weight':'bold', 'size':10})
plt.xticks(fontsize=10)
plt.yticks(fontsize=10)
plt.title("Bound and Actual Regret", fontweight='bold', fontsize=14)
plt.gcf().subplots_adjust(bottom=0.15)
# Save fig
fig_file = '/tmp/compare_regret_and_bound.pdf'
plt.savefig(fig_file, format = "pdf", bbox_inches = 0)
plt.show()


#%% Plot only
bound1 = np.sqrt(K*L*T*np.log(T))/2 * np.sqrt(np.log(1 + T * 1.0/((b_factor+1)*ab_vals)))
bound2 = np.sqrt(L) * np.log(T) * np.sqrt(T*K + L*(b_factor+1)*ab_vals) - L*np.log(T)*np.sqrt((b_factor+1)*ab_vals)

for env_type in envs:
  env_name = env_type.name()
  for alg in bandit_algs:
    alg_name = alg.name()
    label = env_name + ":" + alg_name
    plt.semilogy(ab_vals, env_alg_ab_regrets[env_name][alg_name],
                 linewidth=2, linestyle=env_styles[env_name],
                 color=alg_colors[alg_name], label=label)
plt.semilogy(ab_vals, bound1, linewidth=2, color='red', label='Bound')
#plt.semilogy(ab_vals, bound2, linewidth=2, color='blue', label='Bound2')

plt.xlabel("Gamma", fontweight='bold', fontsize=12)
plt.ylabel("Regret", fontweight='bold', fontsize=12)
plt.legend(loc='upper right', prop={'weight':'bold', 'size':10})
plt.xticks(fontsize=10)
plt.yticks(fontsize=10)
plt.title("Bound and Actual Regret", fontweight='bold', fontsize=14)
plt.gcf().subplots_adjust(bottom=0.15)
# Save fig
fig_file = '/tmp/compare_regret_and_bound.pdf'
plt.savefig(fig_file, format = "pdf", bbox_inches = 0)
plt.show()


#%% Bound vs Regret: high attractions
T = 500
L = 30
K = 3

def get_final_regret(regret):
  cum_regret = np.cumsum(regret, axis=0)  # size: [T, num_runs]
  mean_cum_regret = np.mean(cum_regret, axis=1)
  stdev_cum_regret = np.std(cum_regret, axis=1) / np.sqrt(np.shape(regret)[1])
  return mean_cum_regret[-1], stdev_cum_regret[-1]

envs = [PriorCMEnv, PriorDCTREnv]
bandit_algs = [BayesUCB, ThompsonSampling]
alg_colors = {
    BayesUCB.name(): "orange",
    ThompsonSampling.name(): "green",
    CascadeUCB1.name(): "gray",
    CascadeKLUCB.name(): "blue",
    TopRank.name(): "red",
}
gammas = np.arange(0,10)
num_runs = 500
env_alg_ab_regrets = {}
for env_type in envs:
  env_name = env_type.name()
  env_alg_ab_regrets[env_name] = {}
  for alg in bandit_algs:
    alg_name = alg.name()
    env_alg_ab_regrets[env_name][alg_name] = np.zeros((len(gammas)))

for i, gamma in enumerate(gammas):
  print("Gamma =", gamma)
  beta_a = (1+gamma) * np.ones([L])
  beta_b = (10-gamma) * np.ones([L])
  for env_type in envs:
    env = env_type(K, L, beta_a, beta_b)
    for bandit_alg in bandit_algs:
      regret, _ = evaluate(bandit_alg, env, num_runs, T)  # [num_runs, T]
      last_regret, _ = get_final_regret(regret)
      env_alg_ab_regrets[env_type.name()][bandit_alg.name()][i] = last_regret

bound = np.sqrt(K*L*T*np.log(T))/2 * np.sqrt(np.log(1 + T * 1.0/(1+gammas+10-gammas)))
#bound2 = np.sqrt(L) * np.log(T) * np.sqrt(T*K + L*(b_factor+1)*ab_vals) - L*np.log(T)*np.sqrt((b_factor+1)*ab_vals)

for env_type in envs:
  env_name = env_type.name()
  for alg in bandit_algs:
    alg_name = alg.name()
    label = env_name + ":" + alg_name
    plt.semilogy(gammas, env_alg_ab_regrets[env_name][alg_name],
                 linewidth=2, linestyle=env_styles[env_name],
                 color=alg_colors[alg_name], label=label)
plt.semilogy(gammas, bound, linewidth=2, color='red', label='Bound')
#plt.semilogy(ab_vals, bound2, linewidth=2, color='blue', label='Bound2')

plt.xlabel("Gamma", fontweight='bold', fontsize=12)
plt.ylabel("Regret", fontweight='bold', fontsize=12)
plt.legend(loc='lower left', prop={'weight':'bold', 'size':10})
plt.xticks(fontsize=10)
plt.yticks(fontsize=10)
plt.title("Bound and Actual Regret", fontweight='bold', fontsize=14)
plt.gcf().subplots_adjust(bottom=0.15,left=0.15)
# Save fig
fig_file = '/tmp/compare_regret_and_bound_high_attractions.pdf'
plt.savefig(fig_file, format = "pdf", bbox_inches = 0)
plt.show()


#%% Plot only
for env_type in envs:
  env_name = env_type.name()
  for alg in bandit_algs:
    alg_name = alg.name()
    label = env_name + ":" + alg_name
    plt.semilogy(gammas, env_alg_ab_regrets[env_name][alg_name],
                 linewidth=2, linestyle=env_styles[env_name],
                 color=alg_colors[alg_name], label=label)
plt.semilogy(gammas, bound, linewidth=2, color='red', label='Bound')
#plt.semilogy(ab_vals, bound2, linewidth=2, color='blue', label='Bound2')

plt.xlabel("Gamma", fontweight='bold', fontsize=12)
plt.ylabel("Regret", fontweight='bold', fontsize=12)
plt.legend(loc='lower left', prop={'weight':'bold', 'size':10}, frameon=False)
plt.xticks(fontsize=10)
plt.yticks(fontsize=10)
plt.title("Bound and Actual Regret", fontweight='bold', fontsize=14)
plt.gcf().subplots_adjust(bottom=0.15,left=0.15)
# Save fig
fig_file = '/tmp/compare_regret_and_bound_high_attractions.pdf'
plt.savefig(fig_file, format = "pdf", bbox_inches = 0)
plt.show()


#%% Misspecified Prior
# cascade model
T = 2000
num_runs = 50
L = 30
K = 3
beta_a = 1 * np.ones([L])
beta_b = 10 * np.ones([L])
env = PriorCMEnv(K, L, beta_a, beta_b)

steps = range(T)

def get_final_regret(regret):
  cum_regret = np.cumsum(regret, axis=0)  # size: [T, num_runs]
  mean_cum_regret = np.mean(cum_regret, axis=1)
  stdev_cum_regret = np.std(cum_regret, axis=1) / np.sqrt(np.shape(regret)[1])
  return mean_cum_regret[-1], stdev_cum_regret[-1]

algs = [BayesUCB, ThompsonSampling]
misspecifications = range(0,10)
alg_misspec_regrets = {}
for alg in algs:
  alg_name = alg.name()
  alg_misspec_regrets[alg_name] = np.zeros((len(misspecifications)))
  for misspec in misspecifications:
    print("Misspecification:", misspec)
    regret, _ = evaluate(alg, env, num_runs, T, misspecification=misspec)  # [num_runs, T]
    last_regret, _ = get_final_regret(regret)
    alg_misspec_regrets[alg_name][misspec] = last_regret


#%%
# Plot
for alg in algs:
  alg_name = alg.name()
  plt.plot(misspecifications, alg_misspec_regrets[alg_name],
               linewidth=2, color=alg_colors[alg_name], label=alg_labels[alg_name])

plt.xlabel('Misspecification', fontweight='bold', fontsize=12)
plt.ylabel("Regret", fontweight='bold', fontsize=12)
plt.legend(loc='upper left', prop={'weight':'bold', 'size':10}, frameon=False)
plt.xticks(fontsize=10)
plt.yticks(fontsize=10)
plt.title("Regret vs Prior Misspecification", fontweight='bold', fontsize=14)
plt.gcf().subplots_adjust(bottom=0.2)
# Save fig
fig_file = '/tmp/misspec_regret.pdf'
plt.savefig(fig_file, format = "pdf", bbox_inches = 0)
plt.show()


#%%
# cascade model
T = 3000
num_runs = 50
L = 30
K = 3
beta_a = 1 * np.ones([L])
beta_b = 10 * np.ones([L])
env = PriorCMEnv(K, L, beta_a, beta_b)

steps = range(T)

def eval_and_plot(alg, color, linestyle='-', misspecification=0, label=None):
  regret, _ = evaluate(alg, env, num_runs, T, misspecification=misspecification)
  cum_regret = np.cumsum(regret, axis=0)
  mean_vals = cum_regret.mean(axis=1)  # size: [T]
  se_vals = cum_regret.std(axis=1) / np.sqrt(num_runs)  # size: [T]
  plt.fill_between(steps, mean_vals+se_vals, mean_vals-se_vals,
                   alpha = 0.1, edgecolor = "none", facecolor = color)
  if not label:
    label = "c=" + str(misspecification)
  plt.plot(mean_vals, color=color, label=label, linestyle=linestyle,
           linewidth=2)

#eval_and_plot(BayesUCB, "orange")
eval_and_plot(CascadeKLUCB, "blue", label=alg_labels[CascadeKLUCB.name()])
eval_and_plot(CascadeUCB1, "gray", label=alg_labels[CascadeUCB1.name()])
eval_and_plot(ThompsonSampling, "green", linestyle='-', misspecification=0)
eval_and_plot(ThompsonSampling, "green", linestyle='--', misspecification=4)
eval_and_plot(ThompsonSampling, "green", linestyle=':', misspecification=9)

plt.legend(loc='upper left', prop={'weight':'bold', 'size':10}, frameon=False)
plt.xlabel("Round n", fontweight='bold', fontsize=12)
plt.ylabel("Regret", fontweight='bold', fontsize=12)
plt.title('Prior Misspecification', fontweight='bold', fontsize=14)
plt.locator_params(axis='x', nbins=5)
plt.locator_params(axis='y', nbins=5)
plt.xticks(fontsize=10)
plt.yticks(fontsize=10)
plt.gcf().subplots_adjust(bottom=0.15, left=0.15)
# Save fig
fig_file = '/tmp/misspec_cum_regret_baseline.pdf'
plt.savefig(fig_file, format = "pdf", bbox_inches = 0)
plt.show()
