function Sx = Times_S(D, L, k, x)
    Sx = x;
    if ~mod(k, 2)
        for i = 1:(k/2)
            Sx = L*Sx;
        end
        Sx = D*Sx;
    else
        Sx = x;
        for i = 1:(k+1)/2
            Sx = L*Sx;
        end
    end  
end
