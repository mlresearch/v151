import os
import time
import torch
import random
import numpy as np
import torch.optim as optim
import matplotlib.pyplot as plt

from sklearn.manifold import TSNE
from utils.cuda import cuda_var
from model.linear_classifier import LinearClassifier
from utils.beautify_time import beautify


class DownstreamClassificationTask:

    def __init__(self, config, constants, fine_tune_encoding=False):

        self.config = config
        self.save_path = self.config["save_path"]
        self.num_classes = self.config["num_classes"]
        self.fine_tune_encoding = fine_tune_encoding

        self.constants = constants
        self.max_epoch = constants["downstream_max_epoch"]
        self.lr = constants["lr"]
        self.mean_classifier_sample_size = constants["mean_classifier_sample_size"]
        self.batch_size = constants["batch_size"]
        self.patience = constants["patience"]
        self.grad_clip = constants["grad_clip"]

    def calc_loss(self, model, batch, encoder_model):

        # Dataset consists x_token, x_count, label
        x_token = cuda_var(torch.cat([torch.from_numpy(point[0]).view(1, -1) for point in batch], dim=0)).long()
        x_count = cuda_var(torch.cat([torch.from_numpy(point[1]).view(1, -1) for point in batch], dim=0)).float()
        labels = cuda_var(torch.from_numpy(np.array([point[2] for point in batch])).view(-1, 1)).long()

        encoded = encoder_model.encode_input(x_token, x_count).detach()         # Batch x input_dim
        if not self.fine_tune_encoding:
            encoded = encoded.detach()
        log_prob = model.gen_log_prob(encoded)                                  # Batch x num_classes

        selected_log_prob = torch.gather(log_prob, 1, labels)                   # Batch x 1
        loss = - selected_log_prob.mean()

        info_dict = {"loss": loss}

        return loss, info_dict

    @staticmethod
    def eval_model(model, test_batch, encoder_model):

        model_state = model.training
        model.eval()

        x_token = cuda_var(torch.cat([torch.from_numpy(point[0]).view(1, -1) for point in test_batch], dim=0)).long()
        x_count = cuda_var(torch.cat([torch.from_numpy(point[1]).view(1, -1) for point in test_batch], dim=0)).float()
        labels = cuda_var(torch.from_numpy(np.array([point[2] for point in test_batch])).view(-1, 1)).long()

        encoded = encoder_model.encode_input(x_token, x_count).detach()         # Batch x input_dim
        log_prob = model.gen_log_prob(encoded)                                  # Batch x num_classes

        predicted_labels = torch.max(log_prob, dim=1)[1]                        # Batch
        accuracy = (predicted_labels == labels[:, 0]).float().mean() * 100.0

        selected_log_prob = torch.gather(log_prob, 1, labels)                   # Batch x 1
        loss = - selected_log_prob.mean()

        info_dict = {"loss": loss, "class_acc": accuracy}

        if model_state:
            model.train()

        return loss, info_dict

    def save_tsne_fig(self, class_ids, tensors, plot_fname, logger):

        colors = 'r', 'g', 'b', 'c', 'm', 'y', 'k', 'w', 'orange', 'purple'
        if self.num_classes > len(colors):
            logger.log("Can only visualize upto %d classes" % (len(colors)))
            return

        samples_embedding = TSNE(n_components=2).fit_transform(tensors)

        plt.clf()
        plt.figure(figsize=(6, 5))

        for i, class_id in enumerate(class_ids):
            plt.scatter(samples_embedding[i, 0], samples_embedding[i, 1], c=colors[class_id])

        base_folder = "./%s/data_visualization/" % self.save_path
        if not os.path.isdir(base_folder):
            os.makedirs(base_folder)
        plt.savefig("./%s/%s" % (base_folder, plot_fname))

    def mean_classifier_performance(self, task, encoder_model, test_batches, logger, plot_fname=None):

        class_ids = []
        tensors = []

        # Find mean class encoding for every class
        class_representations = []
        for class_id in range(0, self.num_classes):

            class_dataset = task.get_dataset_for_class("sup_train", class_id)[:self.mean_classifier_sample_size]
            batches = [class_dataset[i: i + self.batch_size]
                       for i in range(0, len(class_dataset), self.batch_size)]
            class_tensors = []

            for batch in batches:

                x_token = cuda_var(torch.cat([torch.from_numpy(point[0]).view(1, -1) for point in batch], dim=0)).long()
                x_count = cuda_var(
                    torch.cat([torch.from_numpy(point[1]).view(1, -1) for point in batch], dim=0)).float()

                # with torch.no_grad:
                batch_tensor = encoder_model.encode_input(x_token, x_count)  # batch x dim
                # sum_tensor += batch_tensor.sum(0)  # dim

                class_ids.append(class_id)
                tensors.append(batch_tensor[0].cpu().data.numpy())
                class_tensors.append(batch_tensor.detach())

            class_tensors = torch.cat(class_tensors, dim=0)        # Num examples x dim
            mean_class_rep = class_tensors.mean(0)          # dim
            intra_class_distance = ((class_tensors - mean_class_rep[None, :]) ** 2).sum(1).sqrt().mean(0)
            # mean_class_rep = sum_tensor / float(max(1, len(class_dataset)))  # dim
            class_representations.append(mean_class_rep.detach().view(-1, 1))

            logger.log("Class Id %d: Intra class distance %f" % (class_id, float(intra_class_distance)))

        class_representations = torch.cat(class_representations, dim=1)     # dim x num_class

        if plot_fname is not None:
            self.save_tsne_fig(class_ids, tensors, plot_fname, logger)

        accuracy = 0.0
        loss = 0.0
        num_dp = 0

        for test_batch in test_batches:

            x_token = cuda_var(torch.cat([torch.from_numpy(point[0]).view(1, -1) for point in test_batch], dim=0)).long()
            x_count = cuda_var(
                torch.cat([torch.from_numpy(point[1]).view(1, -1) for point in test_batch], dim=0)).float()
            labels = cuda_var(torch.from_numpy(np.array([point[2] for point in test_batch])).view(-1, 1)).long()

            encoded = encoder_model.encode_input(x_token, x_count).detach()  # Batch x dim

            # For each test dataset, we compute the score of log prob with
            #   p(c | x) \propto class(c)^\top \phi(x)
            scores = torch.matmul(encoded, class_representations)    # Batch x num_class

            # Loss = - \sum_{i} { scores[i, label[i]] - log(\sum_{j} exp(scores[i, j])) }
            loss -= (torch.gather(scores, 1, labels).view(-1) - torch.logsumexp(scores, dim=1)).sum()

            predicted_labels = torch.max(scores, dim=1)[1]  # Batch
            accuracy += (predicted_labels == labels[:, 0]).float().sum() * 100.0
            num_dp += x_token.size(0)

        accuracy /= float(max(1, num_dp))
        loss /= float(max(1, num_dp))

        return float(accuracy), float(loss)

    def get_mean_classifier_acc(self, task, encoder_model, logger, plot_fname):

        time_start = time.time()
        logger.log("Performing Downstream Evaluation with Noise Contrastive Estimation")

        test_dataset = task.get_dataset("sup_test")
        dataset_size = len(test_dataset)
        random.shuffle(test_dataset)

        test_batches = [test_dataset[i:i + self.batch_size] for i in range(0, dataset_size, self.batch_size)]

        mean_classifier_acc, mean_class_loss = self.mean_classifier_performance(task, encoder_model, test_batches,
                                                                                logger, plot_fname)
        logger.log("Mean classifier has a classification accuracy of %f %% and test loss of %f. Time taken %s." %
                   (mean_classifier_acc, mean_class_loss, beautify(time.time() - time_start)))

        return {"downstream_mean_classifier_acc": mean_classifier_acc,
                "downstream_mean_classifier_loss": mean_class_loss}

    def test(self, best_model, test_batches, encoder_model, epoch, logger):

        # Evaluate on test batches
        test_loss, test_class_acc, num_test_examples = 0.0, 0.0, 0
        for test_batch in test_batches:
            _, info_dict = self.eval_model(best_model, test_batch, encoder_model)

            batch_size = len(test_batch)
            test_loss = test_loss + float(info_dict["loss"]) * batch_size
            test_class_acc = test_class_acc + float(info_dict["class_acc"]) * batch_size
            num_test_examples = num_test_examples + batch_size

        test_loss = test_loss / float(max(1, num_test_examples))
        test_class_acc = test_class_acc / float(max(1, num_test_examples))

        logger.log("Downstream Classification Task: Epoch %d, Test Loss %f, Test classification accuracy %f %%" %
                   (epoch, test_loss, test_class_acc))

    def train(self, task, encoder_model, logger, tensorboard):

        logger.log("Performing Downstream Evaluation with Noise Contrastive Estimation")

        train_dataset = task.get_dataset("sup_train")
        train_dataset_size = len(train_dataset)
        test_dataset = task.get_dataset("sup_test")
        test_dataset_size = len(test_dataset)
        logger.log("Train dataset size %d, Test dataset size %d" % (train_dataset_size, test_dataset_size))

        # Current model
        model = LinearClassifier(self.config, self.constants, input_dim=encoder_model.dim)

        # Model for storing the best model as measured by performance on the test set
        best_model = LinearClassifier(self.config, self.constants, input_dim=encoder_model.dim)

        param_with_grad = filter(lambda p: p.requires_grad, model.parameters())
        optimizer = optim.Adam(params=param_with_grad, lr=self.lr)

        random.shuffle(train_dataset)
        random.shuffle(test_dataset)

        train_batches = [train_dataset[i:i + self.batch_size] for i in range(0, train_dataset_size, self.batch_size)]
        test_batches = [test_dataset[i:i + self.batch_size] for i in range(0, test_dataset_size, self.batch_size)]

        mean_classifier_acc, mean_class_loss = self.mean_classifier_performance(
            task, encoder_model, test_batches, logger, plot_fname="./seed_%d_trained_plot.png" % (self.config["seed"]))
        logger.log("Mean classifier has a classification accuracy of %f %% and test loss of %f" %
                   (mean_classifier_acc, mean_class_loss))

        best_train_loss, best_epoch = float('inf'), -1

        for epoch_ in range(1, self.max_epoch + 1):

            train_loss, num_train_examples = 0.0, 0

            for train_batch in train_batches:

                loss, info_dict = self.calc_loss(model, train_batch, encoder_model)

                optimizer.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), self.grad_clip)
                optimizer.step()

                loss = float(loss)
                tensorboard.log_scalar("Downtream Loss ", loss)

                for key in info_dict:
                    tensorboard.log_scalar(key, info_dict[key])

                batch_size = len(train_batch)
                train_loss = train_loss + loss * batch_size
                num_train_examples = num_train_examples + batch_size

            train_loss = train_loss / float(max(1, num_train_examples))

            if train_loss < best_train_loss:
                best_train_loss = train_loss
                best_epoch = epoch_
                best_model.load_state_dict(model.state_dict())

            logger.debug("Downstream Classification Task: Train Loss after epoch %r is %f, Best train loss is %f" %
                         (epoch_, train_loss, best_train_loss))

            if epoch_ % 10 == 0:
                self.test(best_model, test_batches, encoder_model, epoch_, logger)

        logger.log("Downtream Classification Task: Training over. Testing model with lowest training error.")

        # Evaluate on test batches
        test_loss, test_class_acc, num_test_examples = 0.0, 0.0, 0
        for test_batch in test_batches:
            _, info_dict = self.eval_model(best_model, test_batch, encoder_model)

            batch_size = len(test_batch)
            test_loss = test_loss + float(info_dict["loss"]) * batch_size
            test_class_acc = test_class_acc + float(info_dict["class_acc"]) * batch_size
            num_test_examples = num_test_examples + batch_size

        test_loss = test_loss / float(max(1, num_test_examples))
        test_class_acc = test_class_acc / float(max(1, num_test_examples))

        logger.log("Downstream Classification Task: Best Train Loss %f at Epoch %r, "
                    "Test Loss %f, Test classification accuracy %f %%" %
                    (best_train_loss, best_epoch, test_loss, test_class_acc))

        return {"downstream_best_train_loss": best_train_loss,
                "downstream_best_train_epoch": best_epoch,
                "downstream_test_loss": test_loss,
                "downstream_test_acc": test_class_acc,
                "downstream_mean_classifier_acc": mean_classifier_acc,
                "downstream_mean_classifier_loss": mean_class_loss}
