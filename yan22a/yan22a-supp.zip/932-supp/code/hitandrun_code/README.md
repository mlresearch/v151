# Hit and Run
Python 3.6 implementation of the Hit-and-Run algorithm to uniformly sample convex polytopes.

## Contact
Francesc Font-Clos
https://github.com/fontclos
francesc.font@gmail.com
