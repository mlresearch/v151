from models import SMALL_CNN, PreActResNet8, PreActResNet18
from attacks import fgsm, pgd, dat_pgd
from utils import save, pprint

import torchvision.transforms as transforms
import torch.nn.functional as F
import torch.optim as optim
import torch.nn as nn
import numpy as np

import torchvision
import torch
import time

def run(model, trainset, testset, n_epochs, batch_size, test_batch_size, lr, eps, n_steps, p_iter, trial, dataset, pgd_step_size, dynamic_epoch):
    
    # Load data
    train_loader = torch.utils.data.DataLoader(trainset, batch_size=batch_size, shuffle=False, num_workers=4, drop_last=True)
    test_loader = torch.utils.data.DataLoader(testset, batch_size=test_batch_size, shuffle=True, num_workers=4, drop_last=False)

    n_train = trainset.data.shape[0]
    n_test = testset.data.shape[0]
    n_batches = len(train_loader)
    
    # Define model
    model = model().cuda()
    opt = torch.optim.SGD(model.parameters(), lr=lr(0), momentum=0.9)
    
    # Statistics
    comput_time = 0
    pgd_50_10_test_acc = None
    
    stats = []

    for epoch in range(n_epochs):
        fosc = fosc_max - fosc_max * (epoch * 1.0 / dynamic_epoch)
        fosc = np.max([fosc, 0.0])

        for i, (X, y) in enumerate(train_loader):
            X, y = X.cuda(), y.cuda()
            iteration = epoch * n_batches + i + 1
            opt.param_groups[0].update(lr=lr(iteration / len(train_loader)))

            model.train()
            
            start = time.time()

            d = dat_pgd(model, X, y, eps, pgd_step_size * eps / n_steps, n_steps, fosc)
            adv_output = model(X + d)
            loss = F.cross_entropy(adv_output, y)
            opt.zero_grad()
            loss.backward()
            opt.step()
            
            end = time.time()
            comput_time += (end - start)
            
            if iteration % p_iter == 0:
                model.eval()

                natural_test_acc = 0.
                fgsm_test_acc = 0.
                pgd_20_test_acc = 0.

                eval_pgd_50_10 = (iteration == n_epochs * n_batches) or (iteration == int(n_epochs / 2) * n_batches)
                if eval_pgd_50_10:
                    pgd_50_10_test_acc = 0.

                for (X,y) in test_loader:
                    X, y = X.cuda(), y.cuda()

                    output = model(X)
                    fgsm_output = model(X + fgsm(model, X, y, eps))
                    pgd_20_output = model(X + pgd(model, X, y, eps, 2.5 * eps / 20, 20))

                    natural_test_acc += (output.max(1)[1] == y).sum().item() / n_test
                    fgsm_test_acc += (fgsm_output.max(1)[1] == y).sum().item() / n_test
                    pgd_20_test_acc += (pgd_20_output.max(1)[1] == y).sum().item() / n_test

                    if eval_pgd_50_10:
                        pgd_50_10_output = model(X + pgd(model, X, y, eps, 2.5 * eps / 50, 50, 10))
                        pgd_50_10_test_acc += (pgd_50_10_output.max(1)[1] == y).sum().item() / n_test

                stat = {
                    'Method': 'DAT',
                    'Dataset': dataset,
                    'eps': eps,
                    'J': n_steps,
                    'Trial': trial,
                    'Iteration': iteration,
                    'Time': comput_time,
                    'Test Acc.': natural_test_acc,
                    'FGSM Test Acc.': fgsm_test_acc,
                    'PGD-20 Test Acc.': pgd_20_test_acc,
                    'PGD-50-10 Test Acc.': pgd_50_10_test_acc,
                    'Learning Rate': opt.param_groups[0]['lr'],
                    'PGD Step Size': pgd_step_size
                }
                stats.append(stat)
                pprint(stat)

                yield stats


def main():
    if dataset == 'MNIST':
        transform = transforms.Compose([transforms.ToTensor()])
        model = SMALL_CNN
        n_epochs = 50
        batch_size = 150
        test_batch_size = 5000
        eps = (0.4,)
        trainset = torchvision.datasets.MNIST(root='./data', train=True, download=True, transform=transform)
        testset = torchvision.datasets.MNIST(root='./data', train=False, download=True, transform=transform)
        lr = lambda epoch : 0.01
        p_iter = 400
        dynamic_epoch = 40
        pgd_step_sizes = (2.5,)
        Js = (10,)
    elif dataset == 'CIFAR-10':
        transform_train = transforms.Compose([
            transforms.RandomCrop(32, padding=4),
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
        ])
        transform_test = transforms.Compose([
            transforms.ToTensor(),
        ])
        model = PreActResNet18
        n_epochs = 15
        batch_size = 100
        test_batch_size = 500
        eps = (8./255,)
        trainset = torchvision.datasets.CIFAR10(root='./data', train=True, download=True, transform=transform_train)
        testset = torchvision.datasets.CIFAR10(root='./data', train=False, download=True, transform=transform_test)
        lr = lambda epoch : np.interp([epoch], [0, 5, 15, 20, 30], [0, 0.2, 0, 0.02, 0])[0]
        p_iter = 125
        dynamic_epoch = 12
        pgd_step_sizes = (2.5,)
        Js = (10,)
    elif dataset == 'SVHN':
        transform_train = transforms.Compose([
            transforms.RandomCrop(32, padding=4),
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
        ])
        transform_test = transforms.Compose([
            transforms.ToTensor(),
        ])
        model = PreActResNet8
        n_epochs = 15
        batch_size = 100
        test_batch_size = 500
        eps = (4./255,)
        trainset = torchvision.datasets.SVHN(root='./data', split='train', download=True, transform=transform_train)
        testset = torchvision.datasets.SVHN(root='./data', split='test', download=True, transform=transform_test)
        lr = lambda epoch : np.interp([epoch], [0, 5, 15], [0, 0.2, 0])[0]
        p_iter = 183
        dynamic_epoch = 12
        pgd_step_sizes = (2.5,)
        Js = (10,)

    for trial in range(5):
        for eps_ in eps:
            for pgd_step_size in pgd_step_sizes:
                for J in Js:
                    for stats in run(model, trainset, testset, n_epochs, batch_size, test_batch_size,
                                    lr, eps=eps_, n_steps=J, p_iter=p_iter, trial=trial + 1, dataset=dataset,
                                    pgd_step_size=pgd_step_size, dynamic_epoch=dynamic_epoch) : pass
                    save(stats, 'results/%s_eps-%s_dat_pgdstepsize-%s_trial-%s_J-%s.pickle' % (dataset, eps_, pgd_step_size, trial + 1, J))


if __name__ == '__main__':
    fosc_max = 0.5
    
    dataset = 'MNIST'
    main()

    dataset = 'CIFAR-10'
    main()

    dataset = 'SVHN'
    main()

