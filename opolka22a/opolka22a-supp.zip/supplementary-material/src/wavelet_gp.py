import argparse
import pathlib
import random
import sys

import pygsp.graphs.graph
import tensorflow as tf
import numpy as np
import gpflow
from scipy.sparse.csgraph import laplacian

from data_loading.node_prediction_dataset import NodePredictionDataset
from kernels.chebyshev_kernel import Chebyshev
from kernels.ggp_kernel import GraphGP

from kernels.wavelet_kernel import AdaptiveApproximateWavelet, Wavelet
from metrics import compute_multiclass_accuracy
from training_environment import Trainer, PerformanceLogger
from wavelet_utils import low_pass_filter_from_string, band_pass_filter_from_string

parser = argparse.ArgumentParser('Dynamic Graph Differential Gaussian Processes')
parser.add_argument('--data_dir', type=str, default="../../data/", help='Path at which to store PyTorch Geometric datasets and look for precomputed files.')
parser.add_argument('--dataset', type=str, default="Cora", help='Name of the PyTorch Geometric dataset to evaluate on.')
parser.add_argument('--proj_mat_path', type=str, default="proj_mat.npy", help='Path of the pre-computed AdaptiveWaveletKernel projection matrix if available.')
parser.add_argument('--proj_mat_base', type=str, default="proj_mat", help='Path of the pre-computed AdaptiveWaveletKernel projection matrix up to the same, which allows adding `datasetname.npy`.')
parser.add_argument('--split_seed', type=int, default=None, help='If not None, a random train/val/test split is generated.')
parser.add_argument('--split_idx', type=int, default=0, help='If the dataset comes with multiple pre-selected split indices, it can be selected with this parameter.')
parser.add_argument('--all_splits', type=bool, default=False, help='If True, the script runs the training multiple times, for all predefined splits from 0 to 9 inclusive.')
parser.add_argument('--train_on_val', type=bool, default=False, help='If True, the training and validation set are concatenated to form the new training set.')
parser.add_argument('--train_frac', type=float, default=None, help='If not None, the model is only trained on a fraction of the original training data.')

parser.add_argument('--validate', type=bool, default=False, help='If True, we perform early-stopping on the validation set.')
parser.add_argument('--optimizer', type=str, default="adam", help='Indicates the optimizer to use (either `adam` or `scipy`)')
parser.add_argument('--lr', type=float, default=0.01, help='Learning rate')
parser.add_argument('--num_epochs', type=int, default=300, help='Number of epochs')

parser.add_argument('--seed', type=int, default=0, help='Random seed')
parser.add_argument('--float_type', type=np.dtype, default="float64", help='Floating point type used for all models')
parser.add_argument('--jitter', type=float, default=1e-6, help='Amount of jitter added to the covariance matrix to guarantee invertibility')
parser.add_argument('--kernel', type=str, default="wavelet_approx", help='Name of the GP kernel to use (options `wavelet`, `wavelet_approx`, `chebyshev`)')
parser.add_argument('--poly_degree', type=int, default=5, help='Degree of the polynomial used to approximate the wavelet filters (only relevant if kernel is set to `wavelet_approx` or `chebyshev`)')
parser.add_argument('--low_filter', type=str, default="low", help='Name of the low-pass filter to use (only `none` or `low` supported)')
parser.add_argument('--band_filter', type=str, default="mexican_hat_normalized", help='Name of the band-pass filter to use (only `mexican_hat`, `mexican_hat_normalized`, `morlet` supported)')
parser.add_argument('--low_pass_scale', type=float, default=5.0, help='Parameter of the low-pass filter')
parser.add_argument('--band_pass_scale1', type=float, default=0.4, help='Parameter of the first band-pass filter')
parser.add_argument('--band_pass_scale2', type=float, default=None, help='Parameter of the second band-pass filter')
parser.add_argument('--sd_steps_divider', type=int, default=64, help='')
parser.add_argument('--sd_degree', type=int, default=10, help='')
parser.add_argument('--sd_samples', type=int, default=100, help='')

try:
    args = parser.parse_args()
except:
    parser.print_help()
    sys.exit(0)


def training_step(model, optimizer, logger):
    with tf.GradientTape(watch_accessed_variables=False) as tape:
        tape.watch(model.trainable_variables)
        loss = -model.elbo()
        gradients = tape.gradient(loss, model.trainable_variables)
    optimizer.apply_gradients(zip(gradients, model.trainable_variables))
    logger.add_values({"nELBO": loss.numpy()})
    logger.compute_metrics("train")


def evaluation_step(node_idcs, labels, model, logger, test):
    prefix = "test" if test is True else "val"
    if logger.current_epoch % 20 == 0:
        gpflow.utilities.print_summary(model)
    X = tf.cast(tf.reshape(node_idcs, (-1, 1)), tf.float64)
    pred_y, pred_y_var = model.predict_y(X)
    likelihood = model.predict_log_density((X, labels))
    logger.add_values({f"{prefix}_preds": pred_y.numpy(),
                       f"{prefix}_pred_vars": pred_y_var.numpy(),
                       f"{prefix}_likelihood": likelihood.numpy(),
                       f"{prefix}_labels": labels,
                       f"{prefix}_inputs": X.numpy()})
    logger.compute_metrics(prefix)


def setup_training_env(args):
    metric_funcs = {
        "train": {
            "nELBO": lambda m: np.mean(m["nELBO"]),
            # "train_acc": lambda m: compute_multiclass_accuracy(m["train_predictions"], m["train_labels"])
        },
        "val": {
            "val_acc": lambda m: compute_multiclass_accuracy(m["val_preds"], m["val_labels"]),
            "neg_val_acc": lambda m: -compute_multiclass_accuracy(m["val_preds"], m["val_labels"])
        } if args.validate is True else {
            "val_acc": lambda m: compute_multiclass_accuracy(m["test_preds"], m["test_labels"])
        },
        "test": {
            "test_acc": lambda m: compute_multiclass_accuracy(m["test_preds"], m["test_labels"])
        },
    }
    log_dir_path = pathlib.Path("./log/")
    log_filepath = log_dir_path / "log.pk"
    results_filepath = log_dir_path / "results.pk"
    logger = PerformanceLogger(metric_funcs=metric_funcs,
                               minimizer="neg_val_acc" if args.validate is True else "nELBO",
                               log_filepath=log_filepath, results_filepath=results_filepath,
                               tf_log_dir=log_dir_path, summary_prefix="-> ",
                               minimizer_phases=["train", "val"], one_time_phases=["test"])
    trainer = Trainer(config=args, logger=logger)

    # Set random seed
    random.seed(trainer.conf.seed)
    np.random.seed(trainer.conf.seed)
    tf.random.set_seed(trainer.conf.seed)
    # Set float type
    gpflow.config.set_default_float(trainer.conf.float_type)
    gpflow.config.set_default_jitter(trainer.conf.jitter)

    return trainer


def get_kernel(kernel_name, L_normalized, adj_matrix, poly_degree, base_kernel, node_feats, low_filter_name,
               band_filter_name, low_scale, band_scale1, band_scale2, proj_mat_path=None,
               sd_steps_divider=64, sd_degree=10, sd_samples=100):
    node_feats = node_feats.astype(np.float64) if node_feats is not None else None
    band_scales = (band_scale1, band_scale2) if band_scale2 is not None else (band_scale1, )
    if kernel_name == "wavelet":
        low_f = low_pass_filter_from_string(low_filter_name)
        band_f = band_pass_filter_from_string(band_filter_name)
        kernel = Wavelet(L_normalized, base_kernel=base_kernel,
                         node_feats=node_feats, low_filter=low_f,
                         band_filter=band_f, low_pass=low_scale, scales=band_scales)
    elif kernel_name == "wavelet_approx":
        low_f = low_pass_filter_from_string(low_filter_name)
        band_f = band_pass_filter_from_string(band_filter_name)
        kernel = AdaptiveApproximateWavelet(L_normalized, base_kernel=base_kernel, poly_degree=poly_degree,
                                            node_feats=node_feats, low_filter=low_f,
                                            band_filter=band_f, low_pass=low_scale,
                                            scales=band_scales,
                                            proj_mat_path=proj_mat_path,
                                            sd_steps_divider=sd_steps_divider, sd_degree=sd_degree,
                                            sd_samples=sd_samples)
    elif kernel_name == "chebyshev":
        kernel = Chebyshev(L_normalized, poly_degree=poly_degree, base_kernel=base_kernel,
                           node_feats=node_feats)
    elif kernel_name == "ggp":
        kernel = GraphGP(adj_matrix, base_kernel=base_kernel, node_feats=node_feats)
    else:
        raise NotImplementedError(f"Kernel named {kernel_name} not implemented.")
    return kernel


def run_training(split_idx=None):
    trainer = setup_training_env(args)

    # Dataset definition
    split_idx = trainer.conf.split_idx if split_idx is None else split_idx
    ds = NodePredictionDataset(trainer.conf.dataset, trainer.conf.data_dir,
                               split_seed=trainer.conf.split_seed, train_frac=trainer.conf.train_frac)
    adj_matrix, node_feats, node_labels, idx_train, idx_val, idx_test = ds.get_full_training_data()
    if trainer.conf.train_on_val:
        idx_train = np.concatenate([idx_train, idx_val], axis=0)
    num_classes = len(np.unique(node_labels))
    y_class = node_labels[idx_train]
    adj_matrix = adj_matrix.toarray()
    if np.abs(adj_matrix - adj_matrix.T).sum() > 1e-3:    # PyGSP does not support computing normalized Laplacian for directed graphs
        L = laplacian(adj_matrix, normed=True)
    else:
        graph = pygsp.graphs.graph.Graph(adj_matrix)
        graph.compute_laplacian("normalized")
        L = graph.L.todense()

    # Projection matrix path
    if trainer.conf.proj_mat_base is not None:
        proj_mat_path = trainer.conf.proj_mat_base + f"_{trainer.conf.dataset.lower()}.npy"
    else:
        proj_mat_path = trainer.conf.proj_mat_path

    # Kernel and likelihood definition
    base_kernel = gpflow.kernels.Polynomial()
    kernel = get_kernel(trainer.conf.kernel, L, adj_matrix=adj_matrix,
                        poly_degree=trainer.conf.poly_degree, base_kernel=base_kernel,
                        node_feats=node_feats, low_filter_name=trainer.conf.low_filter,
                        band_filter_name=trainer.conf.band_filter,
                        low_scale=trainer.conf.low_pass_scale,
                        band_scale1=trainer.conf.band_pass_scale1,
                        band_scale2=trainer.conf.band_pass_scale2,
                        proj_mat_path=proj_mat_path, sd_steps_divider=trainer.conf.sd_steps_divider,
                        sd_degree=trainer.conf.sd_degree, sd_samples=trainer.conf.sd_samples)
    data = (tf.cast(tf.reshape(idx_train, (-1, 1)), tf.float64), tf.cast(y_class, dtype=tf.float64))
    invlink = gpflow.likelihoods.RobustMax(num_classes)  # Robustmax inverse link function
    likelihood = gpflow.likelihoods.MultiClass(num_classes, invlink=invlink)  # Multiclass likelihood

    model = gpflow.models.VGP(data, likelihood=likelihood, kernel=kernel, num_latent_gps=num_classes)

    opt = tf.optimizers.Adam(lr=trainer.conf.lr)
    trainer.train_model(model, trainer.conf.num_epochs,
                        eval_every=1 if trainer.conf.validate is True else 20,
                        train_step_f=lambda model: training_step(model, opt, trainer.logger),
                        val_step_f=lambda model: evaluation_step(idx_val, node_labels[idx_val], model, trainer.logger, test=False) if trainer.conf.validate is True
                            else evaluation_step(idx_test, node_labels[idx_test], model, trainer.logger, test=True),
                        test_step_f=lambda model: evaluation_step(idx_test, node_labels[idx_test], model, trainer.logger, test=True))
    return trainer.logger.get_best_metrics(minimizer_phases=["train"], one_time_phases=["test"])["test_acc"]


if __name__ == '__main__':
    if args.all_splits is True:
        accs = []
        for split_idx in range(10):
            accs.append(run_training(split_idx))
        print("mean_test_acc:", np.mean(accs))
        print("std_test_acc:", np.std(accs))
    else:
        run_training()