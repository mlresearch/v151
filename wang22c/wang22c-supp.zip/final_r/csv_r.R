table = read.csv(file = "/Users/apple/Desktop/PHD Project/final_csv/random_Gaussian_matrix_2_2_4_1.csv", 
                 header = T, sep = " ") 
table = as.matrix(table)
index = c(3, 6, 9, 12)
table[index, ] = abs(table[index, ] - 9)
apply(table, 1, mean)
apply(table, 1, sd)

table = read.csv(file = "/Users/apple/Desktop/PHD Project/final_csv/random_Gaussian_matrix_2_3_4.csv", 
                 header = T, sep = " ") 
table = as.matrix(table)
index = c(3, 6, 9, 12)
table[index, ] = abs(table[index, ] - 9)
apply(table, 1, mean)
apply(table, 1, sd)

table = read.csv(file = "/Users/apple/Desktop/PHD Project/final_csv/random_Gaussian_matrix_2_3_5.csv", 
                 header = T, sep = " ") 
table = as.matrix(table)
index = c(3, 6, 9, 12)
table[index, ] = abs(table[index, ] - 9)
apply(table, 1, mean, na.rm = T)
apply(table, 1, sd, na.rm = T)

table = read.csv(file = "/Users/apple/Desktop/PHD Project/final_csv/random_Gaussian_matrix_2_3_6.csv", 
                 header = T, sep = " ") 
table = as.matrix(table)
index = c(3, 6, 9, 12)
table[index, ] = abs(table[index, ] - 9)
apply(table, 1, mean, na.rm = T)
apply(table, 1, sd, na.rm = T)

table = read.csv(file = "/Users/apple/Desktop/PHD Project/final_csv/random_Gaussian_matrix_2_3_7.csv", 
                 header = T, sep = " ") 
table = as.matrix(table)
index = c(3, 6, 9, 12)
table[index, ] = abs(table[index, ] - 9)
apply(table, 1, mean, na.rm = T)
apply(table, 1, sd, na.rm = T)

table = read.csv(file = "/Users/apple/Desktop/PHD Project/final_csv/random_Gaussian_matrix_2_3_8.csv", 
                 header = T, sep = " ") 
table = as.matrix(table)
index = c(3, 6, 9, 12)
table[index, ] = abs(table[index, ] - 9)
apply(table, 1, mean, na.rm = T)
apply(table, 1, sd, na.rm = T)

table = read.csv(file = "/Users/apple/Desktop/PHD Project/final_csv/random_Gaussian_matrix_2_3_9.csv", 
                 header = T, sep = " ") 
table = as.matrix(table)
index = c(3, 6, 9, 12)
table[index, ] = abs(table[index, ] - 9)
apply(table, 1, mean, na.rm = T)
apply(table, 1, sd, na.rm = T)