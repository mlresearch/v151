from models.nets.simsnet import *
import tqdm, time

from utils.params import SIMSHyperParams
from utils.defaults import *
from utils.utilities import *


def compute_batch_acc(output, truth):
    Y_pred, Y_true = tf.reshape(tf.cast((output >= 0.5), tf.float32), [-1]), truth[:, 0]
    err = KB.sum(KB.abs(Y_pred - Y_true))
    n_pair = Y_pred.shape[0]
    return err, n_pair


class SIMS:  # load SIMS parameters, build SIMS metric network, support load/save the metric network, generate recommendation given features
    def __init__(self, params, md_name):
        self.params = SIMSHyperParams(params)  # SIMS parameters
        self.network = None
        self.md_name = md_name

    def compute_acc(self, dataset):
        err, n_pairs = 0.0, 0
        for i in tqdm.tqdm(range(len(dataset))):
            batch = dataset[i]
            inputs, truth = batch[0], batch[1]
            output = self.network.model(inputs)  # probability that Y = 1
            batch_err, batch_size = compute_batch_acc(output, truth)
            err += batch_err
            n_pairs += batch_size
        return err, n_pairs

    def compute_training_loss(self, inputs, truth):
        output = self.network.model(inputs)  # batch_size by 1
        return output, self.network.loss.loss(output, truth)

    def fit(self, train_dataset, validate_dataset, MODEL_PATH, max_num_epoch = SIMSDefaults.DEFAULT_NUM_EPOCHS):
        self.network.compile_network(verbal = False)
        valid_acc = 0.
        for epoch in range(max_num_epoch):
            print("Epoch {}".format(epoch + 1))
            counter = tqdm.trange(len(train_dataset))
            for i in counter:
                batch = train_dataset[i]
                inputs, truth = batch[0], batch[1]
                with tf.GradientTape() as tape:
                    output, L = self.compute_training_loss(inputs, truth)
                err, batch_size = compute_batch_acc(output, truth)
                batch_acc = 1.0 - (err * 1.0 / batch_size)
                counter.set_postfix_str("Loss = {:.4f} and Batch Acc = {:.4f}".format(L, batch_acc))
                gradient = tape.gradient(L, self.network.model.trainable_weights)
                self.network.optimizer.optimizer.apply_gradients(zip(gradient, self.network.model.trainable_weights))

            err, n_pairs = self.compute_acc(validate_dataset)
            acc = 1.0 - (err * 1.0 / n_pairs)
            print("Validation Acc = {:.4f}".format(acc))

            self.network.model.save(MODEL_PATH + "/{}.last.hdf5".format(self.md_name))
            if acc > valid_acc:
                print("Validation improved from {} to {}. Saving model to {} ...".format(valid_acc, acc, MODEL_PATH + "/{}.best.hdf5".format(self.md_name)))
                self.network.model.save(MODEL_PATH + "/{}.best.hdf5".format(self.md_name))
                valid_acc = acc

    def load(self, MODEL_PATH, option = 'best'):  # available options are 'best' and 'last' with 'best' means the best checkpoint in terms of validation
        pass

    def save(self, MODEL_PATH):  # save the model
        filepath = MODEL_PATH + "/{}.last.hdf5".format(self.md_name)  # this is called at the end of training so it is going to be the last model (could be different from the best model so far)
        self.network.model.save(filepath)

    def eval(self, test_dataset):  # evaluate the sims metric on a binary classification task: (item_A, item_B) -> similar or not?
        err, n_pairs = self.compute_acc(test_dataset)
        acc = 1.0 - (err * 1.0 / n_pairs)
        print("Test Acc = {:.4f}".format(acc))

    def get_single_recommendation(self, item, candidates, item_embeddings, candidate_embeddings, interaction_data_loader = None, K = 25):
        scores = 1.0 - self.network.aggregator([item_embeddings, candidate_embeddings])
        scores = scores.numpy()
        ratings = []
        for i in range(len(candidates)):
            ratings.append(scores[i, 0])
        ratings = np.asarray(ratings)
        indices = (-ratings).argsort()[:(K + 1)]
        res = []
        for pos in indices:
            if candidates[pos] != item and len(res) < K:
                res.append(candidates[pos])
        return res

    def get_recommendation(self, items, candidates, featurizer, interaction_data_loader = None, K = 25, verbal = False):  # generate the top-K items for a given item from a pool of candidates
        candidate_features, candidate_ids = featurizer.featurize(candidates)
        item_features, item_ids = featurizer.featurize(items)
        candidate_embeddings = self.network.compute_item_embedding([candidate_ids, candidate_features])
        item_embeddings = self.network.compute_item_embedding([item_ids, item_features])
        if len(list(item_features.keys())) == 0:
            item_embeddings = [item_embeddings]
            candidate_embeddings = [candidate_embeddings]
        res = {}
        for i in range(len(items)):
            announce("Evaluating Item No {} with ID = {}".format(i + 1, items[i]), verbal = verbal)
            embeddings = []
            for component in item_embeddings:
                embeddings.append(tf.repeat([component[i, :]], repeats = [len(candidates)], axis = 0))
            res[items[i]] = self.get_single_recommendation(items[i], candidates, embeddings, candidate_embeddings,
                                                           interaction_data_loader = interaction_data_loader, K = K)
        return res


class SIMSV1(SIMS):  # load SIMS parameters, build SIMS metric network, support load/save the metric network, generate recommendation given features
    def __init__(self, params, md_name):
        super().__init__(params, md_name)
        self.network = SIMSMetricNetV1(self.params)  # create a network with respect to the above parameters
        self.network.loss = KerasLossWrapper(Losses.ContrastiveLossV1)

    def load(self, MODEL_PATH, option = 'best'):  # available options are 'best' and 'last' with 'best' means the best checkpoint in terms of validation
        filepath = MODEL_PATH + "/{}.{}.hdf5".format(self.md_name, option)
        self.network = SIMSMetricNetV1(self.params)  # the params here need to be consistent with those used to create and train the saved model
        self.network.model.load_weights(filepath)
        self.network.compile_network(verbal = False)  # so, after we load the model with custom objects, we need to re-compile it to enable prediction


class SIMSV2(SIMS):  # load SIMS parameters, build SIMS metric network, support load/save the metric network, generate recommendation given features
    def __init__(self, params, md_name):
        super().__init__(params, md_name)
        self.network = SIMSMetricNetV2(self.params)  # create a network with respect to the above parameters
        self.network.loss = KerasLossWrapper(Losses.ContrastiveLossV1)

    def load(self, MODEL_PATH, option = 'best'):  # available options are 'best' and 'last' with 'best' means the best checkpoint in terms of validation
        filepath = MODEL_PATH + "/{}.{}.hdf5".format(self.md_name, option)
        self.network = SIMSMetricNetV2(self.params)  # the params here need to be consistent with those used to create and train the saved model
        self.network.model.load_weights(filepath)
        self.network.compile_network(verbal = False)  # so, after we load the model with custom objects, we need to re-compile it to enable prediction


class SIMSV3(SIMS):  # load SIMS parameters, build SIMS metric network, support load/save the metric network, generate recommendation given features
    def __init__(self, params, md_name):
        super().__init__(params, md_name)
        self.network = SIMSMetricNetV3(self.params)  # create a network with respect to the above parameters
        self.network.loss = KerasLossWrapper(Losses.ContrastiveLossV1)

    def load(self, MODEL_PATH, option = 'best'):  # available options are 'best' and 'last' with 'best' means the best checkpoint in terms of validation
        filepath = MODEL_PATH + "/{}.{}.hdf5".format(self.md_name, option)
        self.network = SIMSMetricNetV3(self.params)  # the params here need to be consistent with those used to create and train the saved model
        self.network.model.load_weights(filepath)
        self.network.compile_network(verbal = False)  # so, after we load the model with custom objects, we need to re-compile it to enable prediction


class SIMSV4(SIMS):  # load SIMS parameters, build SIMS metric network, support load/save the metric network, generate recommendation given features
    def __init__(self, params, md_name):
        super().__init__(params, md_name)
        self.network = SIMSMetricNetV4(self.params)  # create a network with respect to the above parameters
        self.network.loss = KerasLossWrapper(Losses.ContrastiveLossV1)

    def load(self, MODEL_PATH, option = 'best'):  # available options are 'best' and 'last' with 'best' means the best checkpoint in terms of validation
        filepath = MODEL_PATH + "/{}.{}.hdf5".format(self.md_name, option)
        self.network = SIMSMetricNetV4(self.params)  # the params here need to be consistent with those used to create and train the saved model
        self.network.model.load_weights(filepath)
        self.network.compile_network(verbal = False)  # so, after we load the model with custom objects, we need to re-compile it to enable prediction

class SIMSV5(SIMS):  # load SIMS parameters, build SIMS metric network, support load/save the metric network, generate recommendation given features
    def __init__(self, params, md_name):
        super().__init__(params, md_name)
        self.network = SIMSMetricNetV5(self.params)  # create a network with respect to the above parameters
        self.network.loss = KerasLossWrapper(Losses.ContrastiveLossV1)

    def load(self, MODEL_PATH, option = 'best'):  # available options are 'best' and 'last' with 'best' means the best checkpoint in terms of validation
        filepath = MODEL_PATH + "/{}.{}.hdf5".format(self.md_name, option)
        self.network = SIMSMetricNetV5(self.params)  # the params here need to be consistent with those used to create and train the saved model
        self.network.model.load_weights(filepath)
        self.network.compile_network(verbal = False)  # so, after we load the model with custom objects, we need to re-compile it to enable prediction
