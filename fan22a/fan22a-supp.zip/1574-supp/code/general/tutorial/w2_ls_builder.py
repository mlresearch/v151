import numpy as np
import cbp.utils.np_utils as npu
from cbp.builder.base_builder import BaseBuilder
from cbp.node import FactorNode

# * We writes this class for Sinkhorn because Sinkhorn doesn't need cluster concepts.


class BuildMOTLsPotential:
    def __init__(self, num_dim, locs):
        tensor_shape = (num_dim, num_dim, num_dim)
        self.inter_point = npu.nd_expand(locs, tensor_shape, 1)
        self.start_point = npu.nd_expand(locs, tensor_shape, 0)
        self.end_point = npu.nd_expand(locs, tensor_shape, 2)

    def tri_potential(self, per_start):
        diff = self.inter_point - per_start * self.start_point - \
            (1 - per_start) * self.end_point
        return np.power(diff, 2)

    def bi_potential(self):
        start_point = self.start_point[:, :, 0]
        end_point = self.end_point[0, :, :]
        return np.power(start_point - end_point, 2)


class W2LsBuilder(BaseBuilder):
    def __init__(self, m, node_dim, policy, rand_seed=1):
        self.num_sample = m
        self.locs = np.linspace(0, 1.0, node_dim)
        self.potential_maker = BuildMOTLsPotential(node_dim, self.locs)
        super().__init__(node_dim, policy, rand_seed)

    def add_factor(self, name_list, cost, inverse_eta=5000):
        factor_p = np.exp(-inverse_eta * cost)
        factornode = FactorNode(name_list, factor_p)
        self.graph.add_factornode(factornode)
        return factornode

    def deterministic_cost(self, i) -> np.ndarray:
        cost = self.potential_maker.tri_potential(
            1 - i / (self.num_sample - 1)) + 10 * self.potential_maker.bi_potential() / (self.num_sample - 2)
        # *promises the largest cost is 1
        cost /= cost.max()
        return cost

    def init_graph(self):
        head_node = self.add_trivial_node()  # 000
        for _ in range(1, self.num_sample - 1):
            self.add_constrained_node()  # fixed node
        tail_node = self.add_trivial_node()  # tail node
        inv_eta = 2 * (self.num_sample) * \
            np.log(self.node_dim) / self.graph.cfg.itsbp_outer_tolerance
        self.graph.inv_eta = inv_eta
        for idx in range(1, self.num_sample - 1):
            cost = self.deterministic_cost(idx)
            name_list = [head_node.name, f"VarNode_{idx:03d}", tail_node.name]
            self.add_factor(name_list, cost, inv_eta)
