#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Dec 15 18:45:51 2020

@author: wenkaix
"""


from abc import ABCMeta, abstractmethod
import scipy.stats as stats
import bdksd
import bdksd.data as data

import torch.autograd as autograd
import torch
import numpy as np
import math

import warnings
import logging

class UnnormalizedDensity(object):
    """
    An abstract class of an unnormalized probability density function. This is 
    intended to be used to represent a model of the data for goodness-of-fit 
    testing. 
    Subclasses implement log_den(..) and grad_log(...) will be implemented 
    automatically with torch.autograd functions. 
    """

    @abstractmethod
    def log_den(self, X):
        """
        Evaluate log of the unnormalized density on the n points in X
        i.e., log p(x_i) (up to the normalizer) for i = 1,..., n.
        X: n x dx Torch tensor
        Return a one-dimensional Torch array of length n.
        The returned array A should be such that A[i] depends on only X[i].
        """
        expect_dx = self.dx()
        if X.shape[1] != expect_dx:
            raise ValueError('X must have dimension dx={}. Found {}.'.format(expect_dx, X.shape[1]))

    def log_normalized_den(self, X):
        """
        Evaluate the exact normalized log density. The difference to log_den()
        is that this method adds the normalizer. This method is not
        compulsory. Subclasses do not need to override.
        """
        raise NotImplementedError()

    def get_datasource(self):
        """
        Return a Datasource that allows sampling from this density.
        """
        return None

    def grad_log(self, X):
        """
        Evaluate the gradients (with respect to Y) of the conditional log density at
        each of the n points in X. That is, compute 
        
        grad_xi log p(x_i) at each dimensions
        
        Given an implementation of log_den(), this method will automatically work.
        Subclasses may override this if a more efficient implementation is
        available.
        X: n x dx Torch tensor
        Return an n x dx Torch array of gradients.
        """        
        # Default implementation with torch.autograd
        X.requires_grad = True
        logprob = self.log_den(X)
        # sum
        slogprob = torch.sum(logprob)
        Gs = torch.autograd.grad(slogprob, X, retain_graph=True, only_inputs=True)
#        Gs = torch.autograd.grad(slogprob, X, retain_graph=False, only_inputs=True)
        G = Gs[0]

        n, dx = X.shape
        assert G.shape[0] == n
        assert G.shape[1] == dx
        return G

    @abstractmethod
    def dx(self):
        """
        Return the dimension of X.
        """
        raise NotImplementedError()

# end UnnormalizedCondDensity


class Normal(UnnormalizedDensity):
    """
    A multivariate normal distribution.
    """
    def __init__(self, mean, cov):
        """
        mean: a numpy array of length d.
        cov: d x d numpy array for the covariance.
        """
        self.mean = mean
        self.cov = cov
        assert mean.shape[0] == cov.shape[0]
        assert cov.shape[0] == cov.shape[1]
        E, V = np.linalg.eigh(cov.to("cpu"))
        if np.any(np.abs(E) <= 1e-7):
            raise ValueError('covariance matrix is not full rank.')
        # The precision matrix
        prec = np.dot(np.dot(V, np.diag((1.0/(E)))), V.T)
        self.prec = torch.from_numpy(prec).to(cov.device)
        #print self.prec

    def log_den(self, X):
        mean = self.mean.to(X.device)
        X0 = (X - mean).to(self.prec.device)
        X0prec = (X0.float().matmul(self.prec))
        unden = (-torch.sum(X0prec*X0, 1)/2.0)
        return unden

    def get_datasource(self):
        return data.DSNormal(self.mean, self.cov)

    def dim(self):
        return len(self.mean)


# end Normal
    


class MixtureGaussian(UnnormalizedDensity):
    """
    p(x) is a mixture density of Gaussian components
    p(x) = \sum_{i=1}^K  \pi_i N(x | \mu_i, cov_i)
    for some \pi, mu, cov.
    """
    def __init__(self, means, precs, pi):
        """
        Let X be an n x d torch tensor.
        """
#        self.n_comps = n_comps
        self.pi = pi
        self.means = means
        self.precs = precs


    def log_den(self, X):
        # unnormalized density
        return self.log_normalized_den(X)

    def log_normalized_den(self, X):
        n, d = X.shape

        # Pi: n x K 
        Pi = self.pi
        K = len(Pi)
        
        # Mu: 1 x K x d 
        Mu = self.means.view(1,K,d)#.repeat(n,1,1)
        assert len(Mu.shape) == 3
#        assert Mu.shape[0] == 1 
#        assert Mu.shape[1] == d
#        assert Mu.shape[2] == K

        
        # Precs: K x d x d 
        Precs = self.precs.to(X.device, X.dtype)
        if torch.any(torch.isnan(Precs)):
            warnings.warn('Var contains nan.')
#        S = torch.sqrt(Precs)


        # print('S.shape: {}'.format(S.shape))
        # print('Mu.shape: {}'.format(Mu.shape))
        # print('Y.shape: {}'.format(Y.shape))
        # broadcasting
        Z = (X.view(n, 1, d)- Mu) # n x  K x d
        if torch.any(torch.isnan(Z)):
            warnings.warn('Z contains nan.')
#        squared = torch.sum(Z**2, dim=2) # n x K 
            
#        import pdb; pdb.set_trace()
        squared = torch.einsum("nki, kij, nkj -> nk", Z, Precs, Z) # n x  K 
        assert squared.shape[0] == n
        assert squared.shape[1] == K
        const = 1.0/math.sqrt(2.0*math.pi)**d
        S = torch.det(Precs).view(1, K)
        if torch.any(torch.isnan(S)):
            warnings.warn('S contains nan.')
#        Sig_prod = torch.prod(S, dim=2) # n x K
        Sig_prod = S.repeat(n, 1) # n x K
        # TODO: make the computation robust to numerical errors. Perhaps use
        # logsumexp trick.
        E = torch.exp(-0.5*squared) * const * Pi * Sig_prod
        # sum over the K dimension
        log_prob = torch.log(torch.sum(E, dim=1))
        assert len(log_prob) == n
        return log_prob

    def dim(self):
        k, d = self.means.shape
        return d
    
    def get_datasource(self):
        return data.DSMixtureGaussian(self.means, self.precs, self.pi)





class Dirichlet(UnnormalizedDensity):
    """
    UnnormalizedDensity of a Dirichlet distribution in \rm S^{d-1} 
    """
    def __init__(self, alphas=None):
        """
        alphas: a one-dimensional length-k array of concentration parameters
        """
        self.alphas = alphas


    def log_den(self, X):
        alphas1 = self.alphas.to(X.device) - 1
        unden_d = torch.einsum('j,ij->ij',alphas1, torch.log(X))
        unden = unden_d.sum(axis=1)
        return unden

    def get_datasource(self):
        return data.DSDirichlet(self.alphas)

    def dim(self):
        d = len(self.alphas)
        return d

# end GaussianMixture
        