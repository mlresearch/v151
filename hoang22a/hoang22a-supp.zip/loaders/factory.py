from loaders.dataloader import *
from loaders.pairloader import *

from utils.enums import *
from utils.metric import *

def metric_report(results, n_test_so_far):  # reporting the averaged metrics over the set of processed test items so far
    message = "Reporting Metrics "
    for name in results:
        message += "| {} = {} ".format(name, results[name] / n_test_so_far)
    return message + "|"

class DataFactory:  # to be revised
    def __init__(self, interaction, channels, batch_size = 10000, no_test_item = 10000, window = 4, n_pair_per_user = 10,
                 min_cold_interaction = 1, max_cold_interaction = 5, timecut = -1):  # interaction: path to the interaction frame; meta_channels: dict: channel_name -> file path

        self.interaction_data_loader: InteractionDataLoader = InteractionDataLoader(interaction, timecut = timecut)  # create the loader for interaction data

        self.interaction_data_loader.user_random_partition()  # partition the set of users into train (80%), validation (10%) and test (10%)
        self.interaction_data_loader.top_items, self.interaction_data_loader.interaction_counts = self.interaction_data_loader.extract_top_items()
        self.interaction_data_loader.extract_stats()

        self.featurizer = self.create_feature_data(channels)  # create the featurizer (comprising multiple channels for each items)

        self.train_pairs, self.train_labels = self.interaction_data_loader.pairing_data(reserve = DataMode.train.name, window = window, pair_per_user = n_pair_per_user)
        self.validate_pairs, self.validate_labels = self.interaction_data_loader.pairing_data(reserve = DataMode.validate.name, window = window, pair_per_user = n_pair_per_user)
        self.test_pairs, self.test_labels = self.interaction_data_loader.pairing_data(reserve = DataMode.test.name, window = window, pair_per_user = n_pair_per_user)

        self.train_dataset = PairDataLoader(self.train_pairs, self.train_labels, self.featurizer, self.interaction_data_loader.interaction_counts,
                                            self.interaction_data_loader.n_consecutive_pair, batch_size = batch_size)

        self.validate_dataset = PairDataLoader(self.validate_pairs, self.validate_labels, self.featurizer, self.interaction_data_loader.interaction_counts,
                                               self.interaction_data_loader.n_consecutive_pair, batch_size = batch_size)

        self.test_dataset = PairDataLoader(self.test_pairs, self.test_labels, self.featurizer, self.interaction_data_loader.interaction_counts,
                                           self.interaction_data_loader.n_consecutive_pair, batch_size=batch_size)

        self.seen_items = self.create_item_test_set(test_size = no_test_item, min_interaction = min_cold_interaction,
                                                    max_interaction = max_cold_interaction)  # this is a list of seen items
        self.unseen_items = self.create_item_test_set(test_size = no_test_item, unseen = True)  # this is a list of unseen items

        self.logging_messages = []  # always clear logging messages before a new evaluation
        self.eval_result = None  # caching the result of the last evaluation

    def reset_feature_channel(self, channels, batch_size = 10000):
        self.featurizer = self.create_feature_data(channels)
        self.reset_batch_size(batch_size = batch_size)

    def reset_stats(self):
        self.interaction_data_loader.extract_stats()

    def reset_batch_size(self, batch_size = 10000):  # re-create new pair data loader for newly requested batch_size
        self.train_dataset = PairDataLoader(self.train_pairs, self.train_labels, self.featurizer,
                                            self.interaction_data_loader.interaction_counts,
                                            self.interaction_data_loader.n_consecutive_pair, batch_size = batch_size)
        self.validate_dataset = PairDataLoader(self.validate_pairs, self.validate_labels, self.featurizer,
                                               self.interaction_data_loader.interaction_counts,
                                               self.interaction_data_loader.n_consecutive_pair, batch_size = batch_size)
        self.test_dataset = PairDataLoader(self.test_pairs, self.test_labels, self.featurizer,
                                           self.interaction_data_loader.interaction_counts,
                                           self.interaction_data_loader.n_consecutive_pair, batch_size = batch_size)

    def reset_test_size(self, no_test_item = 10000, min_cold_interaction = 1, max_cold_interaction = 5):  # re-create new test set with newly requested size
        self.seen_items = self.create_item_test_set(test_size = no_test_item, min_interaction = min_cold_interaction,
                                                    max_interaction = max_cold_interaction)  # this is a list of seen items
        self.unseen_items = self.create_item_test_set(test_size=no_test_item, unseen = True)  # this is a list of unseen items

    def create_feature_data(self, channels):  # loading multiple feature channels
        features, feature_dims = {}, {}
        for channel in channels.keys():  # for each included channel
            buffer: np.ndarray = np.load(channels[channel])['arr_0']  # load the corresponding numpy matrix (one item per row)
            features[channel], feature_dims[channel] = {}, buffer.shape[1] - 1
            for i in range(buffer.shape[0]):  # for each item in this channel
                item_id = buffer[i, 0]   # first column is the item_id
                features[channel][item_id] = buffer[i, 1:]  # the rest is its embedding vector
                if item_id not in self.interaction_data_loader.item2code:  # if the item_id is not already in the item2code dictionary (e.g., not seen in interaction data)
                    self.interaction_data_loader.item2code[item_id] = self.interaction_data_loader.num_items  # update the item2code dictionary
                    self.interaction_data_loader.num_items += 1  # update the no. of unique items
        return FeatureDataLoader(features, feature_dims, self.interaction_data_loader.item2code)  # create the featurizer

    def create_item_test_set(self, test_size = 10000, min_interaction = 0, max_interaction = 1000000000, unseen = False):  # create a set of test_size items from the list of users reserved for testing
        buffer = []
        res = set()
        for user_id in self.interaction_data_loader.users:  # for each user
            h = self.interaction_data_loader.users[user_id]  # access his/her transaction history
            if h.reserve == DataMode.test.name:   # if he/she is reserved for testing
                for i in range(len(h.interactions) - 1):  # put all his/her purchased items (except for the last) into the list
                    buffer.append(h.interactions[i][0])
        np.random.shuffle(buffer)  # randomly shuffle the list
        for i in range(len(buffer)):
            if unseen is True:
                if self.interaction_data_loader.release_dates[buffer[i]] > self.interaction_data_loader.timecut:
                    res.add(buffer[i])
            else:
                if self.interaction_data_loader.release_dates[buffer[i]] <= self.interaction_data_loader.timecut:
                    if min_interaction <= self.interaction_data_loader.interaction_counts[buffer[i]] <= max_interaction:
                        res.add(buffer[i])
            if len(res) >= test_size:
                break
        return list(res)  # extract the first test_size items for testing

    def rs(self, item, item_list, metrics, forward = True, hop = -1):
        relevant_set = self.create_test_ground_truth(item, forward = forward, hop = hop)  # extract the set of items relevant to the test item
        r = [int(item_list[i] in relevant_set) for i in range(len(item_list))]
        res = {}
        for name in metrics.keys():  # for each metric that needs to be evaluated
            res[name] = metrics[name](r, k = len(item_list))  # compute it -- this calls the pre-defined functions in utils/metric.py
        return res

    def rs_at_user(self, item, item_list, metrics, user_id, forward = True, hop = -1):
        res = {}
        for name in metrics.keys():
            res[name] = 0.0
        relevant_set = self.create_test_ground_truth_per_user(item, user_id, forward = True, hop = hop)  # extract the set of items relevant to the test item
        r = [int(item_list[i] in relevant_set) for i in range(len(item_list))]
        for name in metrics.keys():  # for each metric that needs to be evaluated
            res[name] += metrics[name](r, k = len(item_list))  # compute it -- this calls the pre-defined functions in utils/metric.py
        return res

    def create_test_ground_truth(self, item_id, forward = True, hop = -1):  # ground-truth over all test users
        res = set()  # extract a set of items that would be co-purchased with the test item by at least one test user
        for user_id in self.interaction_data_loader.items[item_id]:  # for every user who bought the test item
            h = self.interaction_data_loader.users[user_id]  # access his/her transaction history
            #if h.reserve != DataMode.test.name:
            #    continue
            pos, end = 0, len(h.interactions)
            if forward:  # if we only consider items that were bought after the test item had been purchased to be ground-truth
                pos = min(h.item2pos[item_id])  # mark the earliest position where the test item appears in the transaction history
                if hop > 0:
                    end = min(pos + hop + 1, len(h.interactions))
            for i in range(pos + 1, end):  # add all items the user purchased starting from pos to the relevant list
                if h.interactions[i][0] != item_id:  # do not consider the test item itself
                    res.add(h.interactions[i][0])
        return res

    def create_test_ground_truth_per_user(self, item_id, user_id, forward = True, hop = -1):  # ground-truth w.r.t user_id
        res = set()  # extract a set of items that would be co-purchased with the test item by at least one test user
        h = self.interaction_data_loader.users[user_id]  # access his/her transaction history
        pos, end = 0, len(h.interactions)
        if forward:
            pos = min(h.item2pos[item_id])  # mark the earliest position where the test item appears in the transaction history
            if hop > 0:
                end = min(pos + hop + 1, len(h.interactions))
        for i in range(pos + 1, end):  # add all items the user purchased starting from pos to the relevant list
            if h.interactions[i][0] != item_id:
                res.add(h.interactions[i][0])
        return res

    def metric_eval_unpersonalized(self, outputs, metrics, tests, K = 25, verbal = False, forward = True, hop = -1):
        results = {}  # global dict that holds the metric results
        for name in metrics:
            results[name] = 0.0  # one entry per metric
        self.logging_messages = ['Evaluating unpersonalized metric ...']
        n_test = len(tests)  # the no. of test items
        for i in range(n_test):  # for each test
            item = tests[i]
            similar_items = outputs[item]
            self.logging_messages.append("Evaluating Item No {} with ID = {}".format(i + 1, item))
            announce(self.logging_messages[-1], verbal = verbal)
            m = self.rs(item, similar_items, metrics, forward = forward, hop = hop)  # compute the relevance score for this top-K
            for name in m:  # aggregate them into the global metric set
                results[name] += m[name]
            self.logging_messages.append(metric_report(results, i + 1))
            announce(self.logging_messages[-1], verbal = verbal)

        message = metric_report(results, n_test)  # this is the final metric evaluation
        self.logging_messages.append(message)

        for name in results:  # finalize the final metric evaluation
            results[name] /= n_test
        self.eval_result = results  # save the results

        return message, results

    def metric_eval_streamline_unpersonalized(self, recommender, metrics, tests, K = 25, verbal = False, forward = True, hop = -1):
        candidates = list(self.interaction_data_loader.items.keys())  # this is the set of all items
        outputs = recommender.get_recommendation(tests, candidates, self.featurizer, self.interaction_data_loader, K = K)
        return self.metric_eval_unpersonalized(outputs, metrics, tests, K = K, verbal = verbal, forward = forward, hop = hop)

    def metric_eval_streamline_personalized(self, recommender, user_id, metrics, tests, K = 25, verbal = False, forward = True, hop = -1):
        candidates = list(self.interaction_data_loader.items.keys())  # this is the set of all items
        filtered = [item_id for item_id in tests if user_id in self.interaction_data_loader.items[item_id]]
        if len(filtered) == 0:
            return None
        outputs = recommender.get_recommendation(filtered, candidates, self.featurizer, self.interaction_data_loader, K = K)
        return self.metric_eval_personalized(outputs, metrics, filtered, user_id, K = K, verbal = verbal, forward = forward, hop = hop)

    def metric_eval_personalized(self, outputs, metrics, tests, user_id, K = 25, verbal = False, forward = True, hop = -1):
        results = {}  # global dict that holds the metric results
        for name in metrics:
            results[name] = 0.0  # one entry per metric
        self.logging_messages = ['Evaluating personalized metric ...']
        n_test = len(tests)  # the no. of test items
        for i in range(n_test):  # for each test
            item = tests[i]
            similar_items = outputs[item]
            self.logging_messages.append("Evaluating Item No {} with ID = {}".format(i + 1, item))
            announce(self.logging_messages[-1], verbal = verbal)
            m = self.rs_at_user(item, similar_items, metrics, user_id, forward = forward, hop = hop)
            for name in m:  # aggregate them into the global metric set
                results[name] += m[name]
            self.logging_messages.append(metric_report(results, i + 1))
            announce(self.logging_messages[-1], verbal = verbal)

        message = metric_report(results, n_test)  # this is the final metric evaluation
        self.logging_messages.append(message)

        for name in results:  # finalize the final metric evaluation
            results[name] /= n_test
        self.eval_result = results  # save the results

        return message, results

