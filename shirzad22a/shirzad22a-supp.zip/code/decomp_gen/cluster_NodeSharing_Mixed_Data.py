import numpy as np
import pickle
import random
from tqdm import tqdm
import networkx as nx
import copy
from pathlib import Path

filePath = (Path("__file__").resolve().parent)


def makeClusterGeneratingDataSet(graphs):
    data = []
    sharedCnt = 0
    totalCnt = 0
    maxtw = 0
    firstClusterSizes = []
    clusterSizes = []
    newNodesSizes = []

    for g in tqdm(graphs):
        T = g.getDecompositionTree()
        super_nodes = T.getNodes()
        order = T.BFSOrder()
        Tsimple = T.getSimpleTree()
        maxtw = max(maxtw, g.getTW())

        G = g.getGraph()
        Gi_nodes = set()
        Gi = nx.Graph()
        size1 = len(list(super_nodes[order[0]].getNodes()))
        firstClusterSizes.append(size1)
        clusterSizes.append(size1)

        mapping = {}
        reverseMapping = []

        for i in range(len(super_nodes)):
            id = order[i]
            superNode = super_nodes[id]
            parent = superNode.getParent()
            nodes = superNode.getNodes()
            pNodes = set() if parent == None else parent.getNodes()

            clusterSizes.append(len(nodes))

            Gi = nx.relabel_nodes(Gi, mapping)

            shared = []
            newNodes = []

            for v in sorted(nodes):
                if v in pNodes:
                    shared.append(mapping[v])
                else:
                    mapping[v] = len(reverseMapping)
                    reverseMapping.append(v)
                    newNodes.append(mapping[v])

            totalCnt += len(pNodes)
            sharedCnt += len(shared)
            newNodesSizes.append(len(newNodes))

            edges = np.array(list(Gi.edges))

            clusterNodesMapped = shared + newNodes
            clusterNodes = []
            for i in range(len(clusterNodesMapped)):
                clusterNodes.append(reverseMapping[clusterNodesMapped[i]])

            Ci = copy.deepcopy(G.subgraph(clusterNodes))
            Ci = nx.relabel_nodes(Ci, mapping)

            shared_with_child = {}
            children = superNode.getChildren()
            for child in children:
                chNodes = child.getNodes()
                chLabel = child.getLabel()
                shared_with_child[chLabel] = {}
                for v in clusterNodes:
                    if v in chNodes:
                        shared_with_child[chLabel][mapping[v]] = 1
                    else:
                        shared_with_child[chLabel][mapping[v]] = 0

            sample = {'T': copy.deepcopy(Tsimple),
                      'label': superNode.getLabel(),
                      'parent': -1 if parent == None else parent.getLabel(),
                      'generatedGraph': copy.deepcopy(Gi),
                      'Ci': copy.deepcopy(Ci),
                      'edges': copy.copy(edges),
                      'shared': copy.copy(shared),
                      'newNodes': copy.copy(newNodes),
                      'mapping': copy.copy(mapping),
                      'reverseMapping': copy.copy(reverseMapping),
                      'shared_with_child': copy.copy(shared_with_child)
                      }

            data.append(sample)

            Gi_nodes = Gi_nodes.union(nodes)
            Gi = G.subgraph(list(Gi_nodes))

    print("Ratio of shared nodes: ", sharedCnt / totalCnt)

    stats = {'sharedCnt': sharedCnt,
             'totalCnt': totalCnt,
             'ratio': sharedCnt / totalCnt,
             'maxtw': maxtw,
             'firstClusterSizes': firstClusterSizes,
             'clusterSizes': clusterSizes,
             'newNodesSizes': newNodesSizes}

    return data, stats


def getClusterNodeSharingGeneratingDataSet(graphs, name=None):
    if name != None:
        relative_path = "data/Datasets/clusterGeneratorData/" + name + ".dat"
        namePath = (filePath / relative_path).resolve()
        print('searching for cluster generating data in: ', namePath)
        try:
            with open(namePath, "rb") as f:
                data = pickle.load(f)
            print('loaded')
            # print(len(data))
            return data[0], data[1], data[2], data[3]
        except:
            print("Dataset not found in saved cluster generating data, generating dataset:")

    if name == None:
        name = "tmp"

    relative_path = "data/Datasets/clusterGeneratorData/" + name + ".dat"
    namePath = (filePath / relative_path).resolve()

    random.shuffle(graphs)
    testPercent = 0.15
    evalPercent = 0.1
    testEnd = int(testPercent * len(graphs))
    evalEnd = testEnd + int(evalPercent * len(graphs))
    test_initial_graphs = graphs[0:testEnd]
    eval_initial_graphs = graphs[testEnd:evalEnd]
    train_initial_graphs = graphs[evalEnd:]

    trainData, trainStats = makeClusterGeneratingDataSet(train_initial_graphs)
    evalData, evalStats = makeClusterGeneratingDataSet(eval_initial_graphs)
    testData, testStats = makeClusterGeneratingDataSet(test_initial_graphs)

    sharedCnt = trainStats['sharedCnt'] + evalStats['sharedCnt'] + testStats['sharedCnt']
    totalCnt = trainStats['totalCnt'] + evalStats['totalCnt'] + testStats['totalCnt']
    stats = {'sharedCnt': sharedCnt,
             'totalCnt': totalCnt,
             'ratio': sharedCnt / totalCnt,
             'maxtw': max(trainStats['maxtw'], evalStats['maxtw'], testStats['maxtw']),
             'firstClusterSizes': trainStats['firstClusterSizes'] + evalStats['firstClusterSizes'] +
                                  testStats['firstClusterSizes'],
             'clusterSizes': trainStats['clusterSizes'] + evalStats['clusterSizes'] + testStats[
                 'clusterSizes'],
             'newNodesSizes': trainStats['newNodesSizes'] + evalStats['newNodesSizes'] + testStats[
                 'newNodesSizes']}

    data = [trainData, evalData, testData, stats]
    with open(namePath, "wb") as f:
        pickle.dump(data, f)

    return trainData, evalData, testData, stats
