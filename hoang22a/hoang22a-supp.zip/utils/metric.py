"""Information Retrieval metrics

Useful Resources:
http://www.cs.utexas.edu/~mooney/ir-course/slides/Evaluation.ppt
http://www.nii.ac.jp/TechReports/05-014E.pdf
http://www.stanford.edu/class/cs276/handouts/EvaluationNew-handout-6-per.pdf
http://hal.archives-ouvertes.fr/docs/00/72/67/60/PDF/07-busa-fekete.pdf
Learning to Rank for Information Retrieval (Tie-Yan Liu)
"""
import numpy as np

# this is the exact set of ranking/recommendation metric implementations used by the team

def mean_reciprocal_rank(rs, k = None):
    """Score is reciprocal of the rank of the first relevant item
    First element is 'rank 1'.  Relevance is binary (nonzero is relevant).
    Example from http://en.wikipedia.org/wiki/Mean_reciprocal_rank
    Args:
        rs: Iterator of relevance scores (list or numpy) in rank order
            (first element is the first item)
        k: The size of the recommendation list
    Returns:
        Mean reciprocal rank  -- e.g. k = 3, [0 0 1] -- 1/3
    """
    assert np.ndim(rs) < 2, "generate one score for one set of recommendations at a time"
    rs = rs[:k]
    if np.sum(rs)>0:
        rank = 1+np.argmax(np.asarray(rs)>0)
        return 1./rank
    else:
        return 0.


def precision_at_k(r, k):
    """Score is precision @ k
    Relevance is binary (nonzero is relevant).
    Args:
        r: Relevance scores (list or numpy) in rank order
            (first element is the first item)
    Returns:
        Precision @ k
    Raises:
        ValueError: len(r) must be >= k
    """
    assert k >= 1
    r = [x != 0 for x in r[:k]]
    if np.size(r) != k:
        raise ValueError('Relevance score length < k')
    return np.mean(r)


def recall_at_k(r, t, k):
    """Score is recall @ k
    Relevance is binary (nonzero is relevant).
    """
    assert k >= 1
    r = [x!=0 for x in r[:k]]
    if np.size(r) != k:
        raise ValueError('Relevance score length < k')
    return np.sum(r).astype('float32') / t


def average_precision(r):
    """Score is average precision (area under PR curve)
    Args:
        r: Relevance scores (list or numpy) in rank order
            (first element is the first item)
    Returns:
        Average precision
    """
    r = [b != 0 for b in r]
    out=np.zeros(np.size(r))-1
    for k in range(np.size(out)):
        if r[k]:
            out[k]=precision_at_k(r, k + 1)
    out = out[out >= 0]
    if len(out) == 0:
        return 0.
    return np.mean(out)


def mean_average_precision(rs):
    """Score is mean average precision
    Args:
        rs: Iterator of relevance scores (list or numpy) in rank order
            (first element is the first item)
    Returns:
        Mean average precision
    """
    return np.mean([average_precision(r) for r in rs])


def dcg_at_k(r, k, method=0):
    """Score is discounted cumulative gain (dcg)
    Relevance is positive real values.  Can use binary
    as the previous methods.
    Args:
        r: Relevance scores (list or numpy) in rank order
            (first element is the first item)
        k: Number of results to consider
        method: If 0 then weights are [1.0, 1.0, 0.6309, 0.5, 0.4307, ...]
                If 1 then weights are [1.0, 0.6309, 0.5, 0.4307, ...]
    Returns:
        Discounted cumulative gain
    """
    r = np.asfarray(r)[:k]
    if np.size(r):
        if method == 0:
            return r[0] + np.sum(r[1:] / np.log2(np.arange(2, np.size(r) + 1)))
        elif method == 1:
            return np.sum(r / np.log2(np.arange(2, np.size(r) + 2)))
        else:
            raise ValueError('method must be 0 or 1.')
    return 0.


def ndcg_at_k(r, k, method=0):
    """Score is normalized discounted cumulative gain (ndcg)
    Args:
        r: Relevance scores (list or numpy) in rank order
            (first element is the first item)
        k: Number of results to consider
        method: If 0 then weights are [1.0, 1.0, 0.6309, 0.5, 0.4307, ...]
                If 1 then weights are [1.0, 0.6309, 0.5, 0.4307, ...]
    Returns:
        Normalized discounted cumulative gain
    """
    dcg_max = dcg_at_k(sorted(r, reverse = True), k, method)
    if not dcg_max:
        return 0.
    return dcg_at_k(r, k, method) / dcg_max