import argparse
import pathlib
import random
import sys

import numpy as np
import gpflow
import tensorflow as tf
from gpflow.likelihoods import MultiClass
from gpflow.mean_functions import Constant
from gpflow.models import SVGP
from scipy.cluster.vq import kmeans2

from data_loading.node_prediction_dataset import NodePredictionDataset
from graph_svgp import GraphSVGP
from inducing_points import NodeInducingPoints
from kernels.gc_kernel import GraphConvolutional
from metrics import compute_multiclass_accuracy
from training_environment import PerformanceLogger, Trainer

parser = argparse.ArgumentParser('Dynamic Graph Differential Gaussian Processes')
parser.add_argument('--seed', type=int, default=0, help='Random seed')
parser.add_argument('--float_type', type=str, default=np.float32, help='Default float type for all Tensors')

parser.add_argument('--dataset_name', type=str, default="Cora", help='Name of the dataset used for training. Can be either Cora, Citeseer, or Pubmed')
parser.add_argument('--dataset_folder', type=str, default="../../data", help='Relative filepath at which to store downloaded datasets')

parser.add_argument('--lr', type=float, default=1e-3, help='Learning rate')
parser.add_argument('--num_epochs', type=int, default=200, help='Number of epochs')
parser.add_argument('--train_batch_size', type=int, default=2000, help='Number of samples in a minibatch during training')
parser.add_argument('--val_batch_size', type=int, default=2000, help='Number of samples in a minibatch during validation')
parser.add_argument('--test_batch_size', type=int, default=2000, help='Number of samples in a minibatch during testing')

parser.add_argument('--sparse', type=bool, default=True,
                    help='If True, the model uses a sparse adjacency matrix. This is faster when '
                         'the adjacency matrix is fairly large. When using subgraphs, setting '
                         'sparse=False can be faster.')
parser.add_argument('--num_convs', type=int, default=2, help='Number of times the Gaussian process is convolved')
parser.add_argument('--jitter', type=float, default=1e-5, help='Default jitter for all Gaussian processes')
parser.add_argument('--initial_lengthscale', type=float, default=2.0, help='Initial lenthscale of the RBF kernels')
parser.add_argument('--num_samples', type=int, default=1, help='Number of samples to draw from variational posterior'
                                                               'to approximate the log-likelihood term of the ELBO.')
parser.add_argument('--num_inducing', type=int, default=100, help='Number of inducing points')

try:
    args = parser.parse_args()
except:
    parser.print_help()
    sys.exit(0)


def training_step(train_loader, model, optimizer, logger):
    for node_feats, labels, conv_mat, center_idcs in train_loader:
        model.kernel.set_subgraph(conv_mat, center_idcs)
        with tf.GradientTape(watch_accessed_variables=False) as tape:
            tape.watch(model.trainable_variables)
            elbo, pred_y, pred_y_var = model.elbo_and_predict((node_feats, labels))
            objective = -elbo
            gradients = tape.gradient(objective, model.trainable_variables)
            logger.add_values({"nELBO": objective.numpy(),
                               "train_predictions": pred_y,
                               "train_labels": labels})
        optimizer.apply_gradients(zip(gradients, model.trainable_variables))
    logger.compute_metrics("train")


def evaluation_step(data_loader, model, logger, test=False):
    prefix = "test" if test else "val"
    for node_feats, labels, conv_mat, center_idcs in data_loader:
        model.kernel.set_subgraph(conv_mat, center_idcs)
        pred_y, pred_y_var = model.predict_y(node_feats)
        likelihood = model.predict_log_density((node_feats, labels)).numpy()
        labels = labels.numpy().reshape(-1)
        predictions = pred_y.numpy()
        logger.add_values({f"{prefix}_predictions": predictions,
                           f"{prefix}_labels": labels,
                           f"{prefix}_likelihood": likelihood})
    logger.compute_metrics(prefix)


def setup_training_env():
    metric_funcs = {
        "train": {
            "nELBO": lambda m: np.mean(m["nELBO"]),
            "train_acc": lambda m: compute_multiclass_accuracy(m["train_predictions"], m["train_labels"])
        },
        "val": {
            "val_acc": lambda m: compute_multiclass_accuracy(m["val_predictions"], m["val_labels"])
        },
        "test": {
            "test_acc": lambda m: compute_multiclass_accuracy(m["test_predictions"], m["test_labels"])
        },
    }
    log_dir_path = pathlib.Path("./log/")
    log_filepath = log_dir_path / "log.pk"
    results_filepath = log_dir_path / "results.pk"
    logger = PerformanceLogger(metric_funcs=metric_funcs, minimizer="nELBO",
                               log_filepath=log_filepath, results_filepath=results_filepath,
                               tf_log_dir=log_dir_path)
    trainer = Trainer(config=args, logger=logger)

    # Set random seed
    random.seed(trainer.conf.seed)
    np.random.seed(trainer.conf.seed)
    tf.random.set_seed(trainer.conf.seed)
    # Set float type
    gpflow.config.set_default_float(trainer.conf.float_type)
    gpflow.config.set_default_jitter(trainer.conf.jitter)

    return trainer


def run_training():
    trainer = setup_training_env()

    # Load data set
    ds = NodePredictionDataset(trainer.conf.dataset_name, trainer.conf.dataset_folder,
                               split_seed=None, tfidf_transform=True,
                               float_type=trainer.conf.float_type)
    adj_matrix, node_feats, node_labels, idx_train, _, idx_test = ds.get_full_training_data()
    num_data = idx_train.shape[0]
    idx_train = tf.constant(idx_train)
    idx_test = tf.constant(idx_test)
    num_classes = len(np.unique(node_labels))
    train_loader, val_loader, test_loader = ds.get_data_loaders(
        num_hops=trainer.conf.num_convs, train_batch_size=trainer.conf.train_batch_size,
        val_batch_size=trainer.conf.val_batch_size, test_batch_size=trainer.conf.test_batch_size)

    # Init kernel
    # base_kernel = gpflow.kernels.RBF(lengthscales=ts.initial_lengthscale)
    base_kernel = gpflow.kernels.Polynomial()
    kernel = GraphConvolutional(base_kernel, trainer.conf.sparse, trainer.conf.num_convs)

    # Init inducing points
    inducing_points = kmeans2(node_feats, len(idx_train), minit='points')[0]    # use as many inducing points as training samples
    inducing_points = NodeInducingPoints(inducing_points)

    # Init GP model
    mean_function = Constant()
    # gprocess = GraphSVGP(kernel, gpflow.likelihoods.MultiClass(num_classes), inducing_points,
    #                      mean_function=mean_function, num_latent_gps=num_classes, whiten=True,
    #                      q_diag=False)
    gprocess = GraphSVGP(kernel, MultiClass(num_classes), inducing_points,
                         mean_function=mean_function, num_latent_gps=num_classes, whiten=True,
                         q_diag=False, num_data=num_data)

    # Init optimizer
    optimizer = tf.optimizers.Adam(learning_rate=trainer.conf.lr)

    trainer.train_model(gprocess, trainer.conf.num_epochs,
                        train_step_f=lambda model: training_step(train_loader, model, optimizer, trainer.logger),
                        val_step_f=lambda model: evaluation_step(val_loader, model, trainer.logger, test=False),
                        test_step_f=lambda model: evaluation_step(test_loader, model, trainer.logger, test=True))


if __name__ == '__main__':
    run_training()