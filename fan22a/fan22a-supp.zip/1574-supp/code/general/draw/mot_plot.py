import numpy as np
import matplotlib.pyplot as plt


def draw_stats(dims, _means, _ints, ax, color, label=None, legend_position='best'):
    ax.plot(dims, _means, color=color, label=label)
    ax.fill_between(
        dims,
        (_means - _ints),
        (_means + _ints), color=color, alpha=.1)
    if label != None:
        ax.legend(loc=legend_position)


#!w2 least square m change
file_name = '_m_change.npy'
file = np.log(np.load('draw/' + 'bp' + file_name))
bp_mean_log = file.mean(axis=1)
bp_std_log = file.std(axis=1)

file = np.log(np.load('draw/' + 'Sinkhorn' + file_name))
bf_mean_log = file.mean(axis=1)
bf_std_log = file.std(axis=1)

bary_m_axis = np.array([3, 4, 5, 6]) + 2
fig, ax = plt.subplots(figsize=(4, 3), dpi=80)
ax.set_xlabel(r'$m$', fontsize=12)
plt.plot(bary_m_axis, 1.5 + np.log(bary_m_axis**3 * 10**bary_m_axis / 5e7), '--',
         color='blue')
plt.plot(bary_m_axis, 1.5 + np.log(
    bary_m_axis *
    10**2 / 1e4), '--', color='magenta')
draw_stats(bary_m_axis, (bp_mean_log), (bp_std_log),
           ax, 'magenta')
draw_stats(bary_m_axis, (bf_mean_log), (bf_std_log),
           ax, 'blue')
plt.grid(which='major')
plt.minorticks_on()
plt.tight_layout()
fig.savefig(f"./draw/w2_ls_fix_n_eps2e1.png",
            bbox_inches='tight', dpi=200)


#!w2 least square n change
file_name = '_n_change.npy'
file = np.log(np.load('draw/' + 'bp' + file_name))
bp_mean_log = file.mean(axis=1)
bp_std_log = file.std(axis=1)

file = np.log(np.load('draw/' + 'Sinkhorn' + file_name))
bf_mean_log = file.mean(axis=1)
bf_std_log = file.std(axis=1)

w2ls_n_axis = np.array([20, 30, 40, 50])
fig, ax = plt.subplots(figsize=(4, 3), dpi=80)
ax.set_xlabel(r'$n$', fontsize=12)
ax.set_ylabel('logarithm of run time', fontsize=12)
plt.plot(w2ls_n_axis, 1.5 + np.log(w2ls_n_axis**5 / 4e5), '--',
         color='blue')
plt.plot(w2ls_n_axis, 0.5 + np.log(
    w2ls_n_axis**3 / 1e5), '--', color='magenta', label=r'reference $\tilde O (d( \mathcal{T}~)m n^{w(G)+1})$')
draw_stats(w2ls_n_axis, (bp_mean_log), (bp_std_log),
           ax, 'magenta')
draw_stats(w2ls_n_axis, (bf_mean_log), (bf_std_log),
           ax, 'blue')
ax.legend(loc='upper left')
plt.grid(which='major')
plt.minorticks_on()
plt.tight_layout()
fig.savefig(f"./draw/w2_ls_fix_m_eps2e1.png",
            bbox_inches='tight', dpi=200)
