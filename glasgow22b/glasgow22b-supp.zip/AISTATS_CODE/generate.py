import numpy as np
import os
import sys


def file_suffix(name, alg, m, n_block, d, block):
    return "%s_%s_%s_machines_%s_%s_block_%s" % (name, alg, m, n_block, d, block)


def generate(n_block, d, sigma, invert=True):
    x_true = np.random.normal(size=d)
    data = np.random.normal(size=(n_block, d))
    labels = np.dot(data, x_true) + np.random.normal(scale=sigma, size=n_block)
    # np.savetxt("data_%s_%s_%s.txt" % (n_block, d, sigma), data, delimiter=' ')
    # np.savetxt("labels_%s_%s_%s.txt" % (n_block, d, sigma), labels, delimiter=' ')
    np.save("data_%s_%s_%s.npy" % (n_block, d, sigma), data)
    np.save("labels_%s_%s_%s.npy" % (n_block, d, sigma), labels)
    if invert:
        x_hat, res, rank, s = np.linalg.lstsq(data, labels)
        #np.savetxt("xhat_%s_%s_%s.txt" % (n_block, d, sigma), x_hat, delimiter=' ')
        np.save("xhat_%s_%s_%s.txt" % (n_block, d, sigma), x_hat)
    #np.savetxt("xground_%s_%s_%s.txt" % (n_block, d, sigma), x_true, delimiter=' ')
    np.save("xground_%s_%s_%s.txt" % (n_block, d, sigma), x_true)
    return data, labels

def partition(data, labels, n_block, d, sigma, num_partitions):
    n_block = len(data)
    len_partition = int(n_block/num_partitions)
    if n_block % num_partitions != 0:
        print("Not partitioning by %s because filesize not divisible" % num_partitions)
        return
    for i in range(num_partitions):
        data_i = data[i*(len_partition):(i + 1)*len_partition]
        labels_i = labels[i*(len_partition):(i + 1)*len_partition]
        # np.savetxt("data_%s_%s_%s_chunk_%s_of_%s.txt" % (n_block, d, sigma, i, num_partitions), data_i, delimiter=' ')
        # np.savetxt("labels_%s_%s_%s_chunk_%s_of_%s.txt" % (n_block, d, sigma, i, num_partitions), labels_i, delimiter=' ')
        np.save("data_%s_%s_%s_chunk_%s_of_%s.txt" % (n_block, d, sigma, i, num_partitions), data_i)
        np.save("labels_%s_%s_%s_chunk_%s_of_%s.txt" % (n_block, d, sigma, i, num_partitions), labels_i)

#Usage: python3 generate.py <n_block> <d> <sigma> <invert> <num_partitions...>
n_block = int(sys.argv[1])
d = int(sys.argv[2])
sigma = int(sys.argv[3])
inv_text = sys.argv[4]
invert = False
if inv_text == 'True':
    invert = True
data, labels = generate(n_block, d, sigma, invert=invert)
num_ps = len(sys.argv) - 5
for i in range(num_ps):
    num_partitions = int(sys.argv[5 + i])
    partition(data, labels, n_block, d, sigma, num_partitions)