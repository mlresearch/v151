# Usage

Use fairseq_impl as the user directory of fairseq. For example:

```
fairseq-train \
		--task translation_with_partitioned_model \
		data-bin/iwslt14.tokenized.de-en \
		--arch transformer_with_partitioned_linear \
		--optimizer adam_for_partitioned_model   \
		--max-tokens 12000   \
		--partition   \
		--save-interval 2 \
		--user-dir fairseq_impl/ \
		--save-dir experiment-1  \
		--lr 5e-4  \
		--lr-scheduler inverse_sqrt \
		--adam-betas "(0.9, 0.98)" \
		--adam-eps 1e-9 \
		--warmup-updates 4000 \
		--encoder-ffn-embed-dim 1024 \
		--encoder-attention-heads 4 \
		--decoder-attention-heads 4 \
		--dropout 0.3 \
		--share-decoder-input-output-embed  \
		--weight-decay 0.0001  \
		--criterion label_smoothed_cross_entropy \
		--label-smoothing 0.1 \
		--max-epoch 30  \
		--small-ratio 0.25 \
		--partitioned-linear-module-name PartitionedRankLinear

```
