import json
import numpy as np
import os
from os.path import isfile, join
import pdb


def topics2supdata(path, out_path=None):

    all_sents = []
    all_topics = []
    for fn in os.listdir(path):
        if isfile(join(path, fn)):
            with open(join(path, fn), 'rb') as f:
                data = json.load(f)
            sents = [sent for section in data['data'].values()
                              for para in section.values()
                              for sent in para.split('\t')]
            all_topics.append(fn[:-5])
            all_sents.append(sents)

    if not out_path is None:
        for topic, sents in zip(all_topics, all_sents):
            with open(join(out_path, topic+'.txt'), 'w') as f:
                for sent in sents:
                    f.write(sent+'\n')

    return all_topics, all_sents


def filter(path, out_path=None, sent_len=100, num_sent=50):

    all_sents = {}
    for fn in os.listdir(path):
        if isfile(join(path, fn)):
            with open(join(path, fn), 'r') as f:
                all_sents[fn[:-4]] = list(f)

    # Filter
    filtered_sents = {topic: [sent for sent in sents if len(sent) >= sent_len]
                         for topic, sents in all_sents.items()}
    filtered_sents = {topic: np.random.choice(sents, num_sent, replace=False)
                         for topic, sents in filtered_sents.items()
                             if len(sents) >= num_sent}

    if not out_path is None:
        for topic, sents in filtered_sents.items():
            with open(join(out_path, topic+'.txt'), 'w') as f:
                for sent in sents:
                    f.write(sent)

    return filtered_sents


if __name__ == '__main__':

    ORIG = '.data/wn'
    RAW = '.data/wn/raw/'
    FILTERED = '.data/wn/filtered/'

    if not os.path.exists(RAW):
        os.makedirs(RAW)

    if not os.path.exists(FILTERED):
        os.makedirs(FILTERED)

    x, y = topics2supdata(ORIG, out_path=RAW)
    print(len(x))
    sents = filter(RAW, out_path=FILTERED, sent_len=20, num_sent=200)
