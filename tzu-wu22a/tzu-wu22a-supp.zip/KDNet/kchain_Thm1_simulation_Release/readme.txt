
Developed on Linux Mint, 18.2 Sonya, Mate-64 bit
Python 3.7.2 
[GCC 7.3.0] :: Anaconda, Inc. on linux


run int linux machine
./thm1_simulation.py

This runs the adversairal dataset. If you want to run the random dataset
go into the file thm1_simulation.py, and comment out adversarial


Important Note : 	The code uses a lot of non-conventional symbols, e.g., ɕ, σᒾ, ℓ.
					This is by design, and Yes, the code still works with these symbols.
