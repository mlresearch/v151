class Ocim(object):

    def __init__(self):
        pass

    def build_graph(self):
        '''Process graph data'''
        pass

    def cal_inf(self, G, S_A, tb_AB=0):
        '''Calculate influence spread given graph G and seed set S_A'''

    def RR(self, G):
        '''Greedily select seed set using RR set'''

    def IMM(self, G, weight, tb_AB=0):
        '''Greedily select seed set using IMM'''

    def cucb(self, explore_ratio=1., ep_greedy=0., etc=0, log_ind=0):
        '''CUCB algorithm'''


