import numpy as np
from sklearn.datasets.samples_generator import make_blobs
from matplotlib import pyplot
import matplotlib.pyplot as plt
from sklearn_extra.cluster import KMedoids
from learners import *

from mmd_critic.mmd import greedy_select_protos, select_criticism_regularized
from sklearn.metrics.pairwise import rbf_kernel
from sklearn.preprocessing import normalize

'''
Finds the margin points (only negative points)
'''

def separate(X, y):
    neg_X = X[y == 0]
    pos_X = X[y == 1]
    return neg_X, pos_X

def combine(neg_X, pos_X):
    new_X = np.vstack([neg_X, pos_X])
    new_y = np.concatenate([np.zeros(len(neg_X)), np.ones(len(pos_X))])
    rand_idx = np.random.permutation(len(new_X))
    return new_X[rand_idx], new_y[rand_idx]

'''
Augment data
'''

def augment(X, y, radius=0.1, num_copy=5, seed=5):
    def gen_noise(X, r):
        np.random.seed(seed)
        return r * normalize(np.random.randn(*X.shape), axis=1)
    aug_X = np.vstack([X + gen_noise(X, radius) for i in range(num_copy)])
    aug_Y = np.concatenate([y for i in range(num_copy)])
    rand_idx = np.random.permutation(len(aug_X))
    return aug_X[rand_idx], aug_Y[rand_idx]

'''
Finds the margin points
'''
def find_linear_margin(full_X, w, r=1e-2):
    margin_dist = compute_linear_margin(full_X, w)
    neg_margin_idx = np.where((np.abs(margin_dist) < r) & (margin_dist <= 0))[0]
    pos_margin_idx = np.where((np.abs(margin_dist) < r) & (margin_dist > 0))[0]
    return neg_margin_idx, pos_margin_idx

def find_mlp_margin(X, mlp, r=0.02):
    score = mlp.predict_proba(X)[:,1] - 0.5
    neg_margin_idx = np.where((np.abs(score) < r) & (score <= 0))[0]
    pos_margin_idx = np.where((np.abs(score) < r) & (score > 0))[0]
    return neg_margin_idx, pos_margin_idx

def compute_linear_margin(X, w):
    return X @ w / np.linalg.norm(w)

def percentile_cutoff(X, w, pct):
    margin_dist = np.abs(compute_linear_margin(X, w))
    return np.percentile(margin_dist, pct)    

def allowed(X, w, pct):
    cutoff = percentile_cutoff(X, w, pct)
    margin_dist = np.abs(compute_linear_margin(X, w))
    idx = np.where(margin_dist >= cutoff)[0]
    return X[idx]

def allowed_mlp(X, mlp, pct):
    margin_dist = mlp.predict_proba(X)[:,1] - 0.5
    cutoff = np.percentile(margin_dist, pct)
    idx = np.where(margin_dist >= cutoff)[0]
    not_idx = np.where(margin_dist < cutoff)[0]
    return idx, not_idx

'''
Filter policy
'''

def linear_explanation_policy(X, y, w, cutoff_percentile=50):
    neg_X, pos_X = separate(X, y)
    return combine(allowed(neg_X, w, cutoff_percentile), allowed(pos_X, w, cutoff_percentile))

def mlp_explanation_policy(X, y, mlp, cutoff_percentile=50):
    neg_X, pos_X = separate(X, y)
    neg_idx, neg_not_idx = allowed_mlp(neg_X, mlp, cutoff_percentile)
    pos_idx, pos_not_idx = allowed_mlp(pos_X, mlp, cutoff_percentile)
    return combine(neg_X[neg_idx], pos_X[pos_idx]), combine(neg_X[neg_not_idx], pos_X[pos_not_idx])

'''
Data Summarization: KMedoid
'''

def fit_kmedoid(X, num_samples):
    kmedoids = KMedoids(n_clusters=num_samples, init='heuristic', random_state=0).fit(X) #deterministic
    return kmedoids.cluster_centers_ 

def kmedoid_summary(X, y, per_cluster=50):
    neg_X, pos_X = separate(X, y)
    neg_centers = fit_kmedoid(neg_X, int(len(neg_X) /per_cluster))
    pos_centers = fit_kmedoid(pos_X, int(len(pos_X) /per_cluster))
    return combine(neg_centers, pos_centers)

'''
MMD critic
'''
def kernelize(X, gamma=0.1):
    return rbf_kernel(X, gamma=gamma)

def one_mmd_critic(X, num_prototype, num_crit, gamma=0.1):
    K = kernelize(X, gamma=gamma)
    selected = greedy_select_protos(K, np.arange(len(X)), num_prototype)
    critselected = select_criticism_regularized(K, selected, num_crit, is_K_sparse=False, reg='logdet')
    return np.concatenate([selected, critselected])

def run_mmd(X, y, num_prototype, num_crit, gamma=0.1):
    neg_X, pos_X = separate(X, y)
    frac = float(len(neg_X) / len(X))
    
    neg_num_prot = int(frac * num_prototype)
    neg_num_crit = int(frac * num_crit)
    pos_num_prot = int((1 - frac) * num_prototype)
    pos_num_crit = int((1 - frac) * num_crit)
    
    neg_exp = neg_X[one_mmd_critic(neg_X, neg_num_prot, neg_num_crit)]
    pos_exp = pos_X[one_mmd_critic(pos_X, pos_num_prot, pos_num_crit)]
    
    return combine(neg_exp, pos_exp)
