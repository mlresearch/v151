%% This code computes the covraiabnce of [X_i^r, X_{\bar{i}}^r]

function [T] = Covaraiance_IID(n,E_factor,N,h,f)
samples = [];  
Nnodes = size(h,1);
T = zeros(Nnodes);

initial = zeros(Nnodes,1);
parfor cnt = 1:n
E = E_factor*randn(Nnodes,N);
[temp] = DataGenerator(N,h,E, initial);
temp = 1/sqrt(N)*temp*transpose(exp(-1j*f*(0:(N-1))));
samples = [samples,temp];
T = T +conj(temp)*transpose(temp);
end
T = T/2/n;

end

