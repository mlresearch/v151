"""
Examples
--------
python train_cifar10_jax.py
"""
import os
import sys
import ipdb
import math
import datetime
import argparse
from tqdm import tqdm

# YAML setup
from ruamel.yaml import YAML
yaml = YAML()
yaml.preserve_quotes = True
yaml.boolean_representation = ['False', 'True']

import numpy as onp

import jax
import jax.numpy as jnp
from jax import flatten_util
from jax.tree_util import tree_flatten, tree_unflatten

import haiku as hk

import torch
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms, datasets

import matplotlib.pyplot as plt

# Local imports
import gan_models
from csv_logger import CSVLogger, plot_csv


parser = argparse.ArgumentParser()
parser.add_argument('--dataset', type=str, default='cifar10', choices=['mnist', 'cifar10'],
                    help='Dataset')
parser.add_argument('--batch_size', type=int, default=128,
                    help='Batch size')
parser.add_argument('--z_dim', type=int, default=100,
                    help='Noise dimension')

# Generator hyperparams
parser.add_argument('--G_lr', type=float, default=1e-4,
                    help='Generator LR')
parser.add_argument('--G_b1', type=float, default=0.5,
                    help='Generator beta1 for Adam')
parser.add_argument('--G_b2', type=float, default=0.99,
                    help='Generator beta2 for Adam')
parser.add_argument('--G_b1_phase', type=float, default=16.0,
                    help='Generator beta1 phase for Adam')
parser.add_argument('--G_b2_phase', type=float, default=16.0,
                    help='Generator beta2 phase for Adam')
parser.add_argument('--complex_G', action='store_true', default=False,
                    help='Whether to use complex momentum for the generator')

# Discriminator hyperparams
parser.add_argument('--D_lr', type=float, default=5e-5,
                    help='Discriminator LR')
parser.add_argument('--D_b1', type=float, default=0.5,
                    help='Discriminator beta1 for Adam')
parser.add_argument('--D_b2', type=float, default=0.99,
                    help='Discriminator beta2 for Adam')
parser.add_argument('--D_b1_phase', type=float, default=16.0,
                    help='Discriminator beta1 phase for Adam')
parser.add_argument('--D_b2_phase', type=float, default=16.0,
                    help='Discriminator beta2 phase for Adam')
parser.add_argument('--complex_D', action='store_true', default=False,
                    help='Whether to use complex momentum for the discriminator')

parser.add_argument('--log_every', type=int, default=200,
                    help='Print NLL every _ minibatches')
parser.add_argument('--save_dir', type=str, default='saves',
                    help='Directory for log / saving')
parser.add_argument('--seed', type=int, default=3,
                    help='Random seed')
args = parser.parse_args()


timestamp = '{:%Y-%m-%d}'.format(datetime.datetime.now())
exp_name = '{}-d:{}-zdim:{}-glr:{}-cg:{}-gb1:{}-gb2:{}-gb1p:{}-gb2p:{}-dlr:{}-cd:{}-db1:{}-db2:{}-db1p:{}-db2p:{}'.format(
            timestamp, args.dataset, args.z_dim,
            args.G_lr, int(args.complex_G), args.G_b1, args.G_b2, args.G_b1_phase, args.G_b2_phase,
            args.D_lr, int(args.complex_D), args.D_b1, args.D_b2, args.D_b1_phase, args.D_b2_phase)

save_dir = os.path.join(args.save_dir, exp_name)
if not os.path.exists(save_dir):
    os.makedirs(save_dir)
    os.makedirs(os.path.join(save_dir, 'samples'))

# Save command-line arguments
with open(os.path.join(save_dir, 'args.yaml'), 'w') as f:
    yaml.dump(vars(args), f)

# Set up logging
iteration_logger = CSVLogger(fieldnames=['global_iteration', 'G_loss', 'D_loss'],
                             filename=os.path.join(save_dir, 'iteration_log.csv'))


def count_params(params):
    value_flat, value_tree = tree_flatten(params)
    return sum([v.size for v in value_flat])


if args.dataset == 'mnist':
    NUM_TRAIN = 50000
    batch_size = 128
    num_channels = 1

    transform = transforms.Compose([transforms.Resize(32),
                                    transforms.ToTensor(),
                                    lambda x: x * 2 - 1])

    trainset = datasets.MNIST(root='./data', train=True, download=True, transform=transform)
    trainset.data = trainset.data[:NUM_TRAIN]
    trainset.targets = trainset.targets[:NUM_TRAIN]

    valset = datasets.MNIST(root='./data', train=True, download=True, transform=transform)
    valset.data = valset.data[NUM_TRAIN:]
    valset.targets = valset.targets[NUM_TRAIN:]

    train_loader = DataLoader(trainset, batch_size=batch_size, shuffle=True, pin_memory=True, drop_last=True)
    val_loader = DataLoader(valset, batch_size=batch_size, shuffle=True, pin_memory=True, drop_last=True)

elif args.dataset == 'cifar10':
    NUM_TRAIN = 45000
    batch_size = 128
    num_channels = 3

    transform = transforms.Compose([transforms.ToTensor(),
                                    lambda x: x * 2 - 1])

    trainset = datasets.CIFAR10(root='./data', train=True, download=True, transform=transform)
    trainset.data = trainset.data[:NUM_TRAIN]
    trainset.targets = trainset.targets[:NUM_TRAIN]

    valset = datasets.CIFAR10(root='./data', train=True, download=True, transform=transform)
    valset.data = valset.data[NUM_TRAIN:]
    valset.targets = valset.targets[NUM_TRAIN:]

    train_loader = DataLoader(trainset, batch_size=batch_size, shuffle=True, pin_memory=True, drop_last=True)
    val_loader = DataLoader(valset, batch_size=batch_size, shuffle=True, pin_memory=True, drop_last=True)


def generator_fn(x, is_training):
    if args.dataset == 'cifar10':
        model = gan_models.Generator(channels=num_channels)
        # model = gan_models.Generator_BN(channels=num_channels)
    elif args.dataset == 'mnist':
        model = gan_models.Generator_BN(channels=num_channels)
    return model(x, is_training)

def discriminator_fn(x, is_training):
    if args.dataset == 'cifar10':
        model = gan_models.Discriminator()
        # model = gan_models.Discriminator_BN()
        # model = gan_models.Discriminator_SN()
    elif args.dataset == 'mnist':
        model = gan_models.Discriminator_BN()
    return model(x, is_training)

@jax.jit
def bce_with_logits(logits, x):
    x = jnp.reshape(x, (x.shape[0], -1))
    logits = jnp.reshape(logits, (logits.shape[0], -1))
    return -jnp.mean(x * logits - jnp.logaddexp(0.0, logits))

def D_loss_fn(key, G_params, G_state, D_params, D_state, images):
    z = jax.random.normal(key, (batch_size, args.z_dim))
    fake_images, G_state = G.apply(G_params, G_state, None, z, is_training=True)

    if args.dataset == 'mnist':
        fake_images = fake_images.reshape(fake_images.shape[0], 1, 32, 32)

    D_real_output, D_state = D.apply(D_params, D_state, None, images, is_training=True)
    D_fake_output, D_state = D.apply(D_params, D_state, None, fake_images, is_training=True)  # does jnp.array do something like detach() ?? Important question

    D_real_loss = bce_with_logits(D_real_output, jnp.ones((images.shape[0], 1)))
    D_fake_loss = bce_with_logits(D_fake_output, jnp.zeros((images.shape[0], 1)))
    D_loss = D_real_loss + D_fake_loss

    return D_loss, D_state

def G_loss_fn(key, G_params, G_state, D_params, D_state):
    z = jax.random.normal(key, (batch_size, args.z_dim))
    fake_images, G_state = G.apply(G_params, G_state, None, z, is_training=True)

    if args.dataset == 'mnist':
        fake_images = fake_images.reshape(fake_images.shape[0], 1, 32, 32)

    D_fake_output, D_state = D.apply(D_params, D_state, None, fake_images, is_training=True)
    G_loss = bce_with_logits(D_fake_output, jnp.ones((images.shape[0], 1)))
    return G_loss, G_state

D_loss_grad = jax.jit(jax.value_and_grad(D_loss_fn, argnums=3, has_aux=True))
G_loss_grad = jax.jit(jax.value_and_grad(G_loss_fn, argnums=1, has_aux=True))

# Init parameters
# --------------------------
G = hk.transform_with_state(generator_fn)
D = hk.transform_with_state(discriminator_fn)

key = jax.random.PRNGKey(42)

# Initialize generator network parameters
images, labels = iter(train_loader).next()
images, labels = jnp.array(images), jnp.array(labels)
D_params, D_state = D.init(key, images, is_training=True)

z = jax.random.normal(key, (batch_size, args.z_dim))

if args.dataset == 'cifar10':
    z = z.reshape(z.shape[0], z.shape[1], 1, 1)

G_params, G_state = G.init(jax.random.PRNGKey(42), z, is_training=True)

G_vector, G_unravel_pytree = flatten_util.ravel_pytree(G_params)
D_vector, D_unravel_pytree = flatten_util.ravel_pytree(D_params)

print('Num G params: {} | G_params norm: {}'.format(count_params(G_params), jnp.linalg.norm(G_vector)))
print('Num D params: {} | D_params norm: {}'.format(count_params(D_params), jnp.linalg.norm(D_vector)))
sys.stdout.flush()
# --------------------------

G_optim_params = {
    'lr': args.G_lr,
    'b1': args.G_b1 * jnp.exp(1j*(jnp.pi / args.G_b1_phase)) if args.complex_G else args.G_b1,
    'b2': args.G_b2 * jnp.exp(1j*(jnp.pi / args.G_b2_phase)) if args.complex_G else args.G_b2,
    'eps': 1e-8,
    'm': jax.tree_map(lambda x: jnp.zeros(x.shape), G_params),
    'v': jax.tree_map(lambda x: jnp.zeros(x.shape), G_params),
}

D_optim_params = {
    'lr': args.D_lr,
    'b1': args.D_b1 * jnp.exp(1j*(jnp.pi / args.D_b1_phase)) if args.complex_D else args.D_b1,
    'b2': args.D_b2 * jnp.exp(1j*(jnp.pi / args.D_b2_phase)) if args.complex_D else args.D_b2,
    'eps': 1e-8,
    'm': jax.tree_map(lambda x: jnp.zeros(x.shape), D_params),
    'v': jax.tree_map(lambda x: jnp.zeros(x.shape), D_params),
}

# b1 was 0.99, but instead set it to 0.99*np.exp(1j*(np.pi / 16.0))

def optimizer_step(params, grads, optim_params, t):
    lr = optim_params['lr']
    b1 = optim_params['b1']
    b2 = optim_params['b2']
    eps = optim_params['eps']

    optim_params['m'] = jax.tree_multimap(lambda g, m: (1 - b1) * g + b1 * m, grads, optim_params['m'])
    optim_params['v'] = jax.tree_multimap(lambda g, v: (1 - b2) * g**2 + b2 * v, grads, optim_params['v'])

    mhat = jax.tree_map(lambda m: m / (1 - b1**(t+1)), optim_params['m'])
    vhat = jax.tree_map(lambda v: v / (1 - b2**(t+1)), optim_params['v'])

    updated_params = jax.tree_multimap(lambda p, m, v: p - jnp.real(lr * m / (jnp.sqrt(v) + eps)), params, mhat, vhat)
    return updated_params, optim_params

def make_grid(batch, ncols=5):
    """batch has dimension (batch_size, 3, 32, 32)

    The number of rows is dynamically adjusted based on the batch size and number of cols
    """
    if isinstance(batch, torch.Tensor):
        batch = batch.numpy()

    if args.dataset == 'cifar10':
        batch = [img.transpose(1, 2, 0) for img in batch]

    row_list = []
    row = []
    i = 0
    while i < len(batch):
        row.append(batch[i])
        i += 1
        if i % ncols == 0:
            row_list.append(onp.concatenate(row, axis=1))
            row = []

    if row:
        while len(row) != ncols:
            row.append(onp.zeros(batch[0].shape))
        row_list.append(onp.concatenate(row, axis=1))

    return onp.concatenate(row_list, axis=0)

def save_samples(key, G_params, G_state, fname):
    z = jax.random.normal(key, (batch_size, args.z_dim))
    fake_images, G_state = G.apply(G_params, G_state, None, z, is_training=True)
    fake_images = (fake_images + 1) / 2.0  # Transforms from [-1, 1] to [0, 1]

    with open(os.path.join(save_dir, 'samples', '{}.npy'.format(fname)), 'wb') as f:
        onp.save(f, [onp.array(img) * 255 for img in fake_images])

    if args.dataset == 'mnist':
        fake_images = fake_images.reshape(fake_images.shape[0], 32, 32)

    grid = make_grid(fake_images, ncols=16)

    fig = plt.figure(figsize=(10,10))

    if args.dataset == 'mnist':
        plt.imshow(grid, cmap='gray')
    else:
        plt.imshow(grid)

    plt.axis('off')
    plt.savefig(os.path.join(save_dir, 'samples', '{}.png'.format(fname)))
    plt.close(fig)


global_iteration = 0  # global iteration counter (for optimizers like Adam)

for epoch in range(100):
    for i, (images, labels) in enumerate(train_loader):
        key, key_G, key_D = jax.random.split(key, 3)
        images, labels = jnp.array(images), jnp.array(labels)

        (D_loss, D_state), D_gradient = D_loss_grad(key_D, G_params, G_state, D_params, D_state, images)
        D_params, D_optim_params = optimizer_step(D_params, D_gradient, D_optim_params, global_iteration)

        (G_loss, G_state), G_gradient = G_loss_grad(key_G, G_params, G_state, D_params, D_state)
        G_params, G_optim_params = optimizer_step(G_params, G_gradient, G_optim_params, global_iteration)

        if i % 100 == 0:
            print('Epoch {:4d} | Iter {:6d} | G_loss: {:6.4f} | D_loss: {:6.4f}'.format(epoch, global_iteration, G_loss, D_loss))
            save_samples(key_G, G_params, G_state, 'it_{}'.format(global_iteration))
            sys.stdout.flush()

        global_iteration += 1
