import torch

torch.multiprocessing.set_sharing_strategy('file_system')

import wandb
import argparse
import pickle
import gc
import copy

from decomp_gen.models.node_adding import NodeAdding, NodeAdding_wo_tree_for_edge, NodeAdding_Without_Tree_Encoding, NodeAdding_Simple
from decomp_gen.data_structures.dataset import NodeAddingDataset, GraphDataset
from decomp_gen.graph_generator import dist_stats

from decomp_gen.models.nnutils import *
from decomp_gen import configs

import numpy as np
import math

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

SEED = 1234
TRAIN_RATIO = 0.7
VAL_RATIO = 0.15
TEST_RATIO = 1.0 - TRAIN_RATIO - VAL_RATIO

EVAL_EPOCHS = 50

K = 5
EARLY_STOP_EPOCHS = 50

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', default='train', type=str)
    parser.add_argument('--continue-training', default=False, type=bool)
    parser.add_argument('--model-name', default='node_adding_tmp', type=str)
    parser.add_argument('--optimizer', default='Adam', type=str)
    parser.add_argument('--lr', default=0.001, type=float)
    parser.add_argument('--loss-function', default='BCE', type=str)
    parser.add_argument('--data-name', default='grid', type=str)
    parser.add_argument('--epochs', default=3000, type=int)
    parser.add_argument('--tree-hidden-dim', default=64, type=int)
    parser.add_argument('--gnn-input-dim', default=128, type=int)
    parser.add_argument('--gnn-hidden-dim', default=128, type=int)
    parser.add_argument('--gnn-num-layers', default=7, type=int)
    parser.add_argument('--mlp-hidden-dim', default=64, type=int)
    parser.add_argument('--reorder-epochs', default=1, type=int)
    parser.add_argument('--num-workers', default=0, type=int)
    parser.add_argument('--use-wandb', default=False, type=bool)
    parser.add_argument('--batch-size', default=4, type=int)
    parser.add_argument('--sample-per-graph', default=64, type=int)
    parser.add_argument('--tree-generator', default='none', type=str)
    parser.add_argument('--node-sharing', default='none', type=str)
    args = parser.parse_args()

    return args


args = parse_args()

BATCH_SIZE = args.batch_size
data = NodeAddingDataset(args.data_name, '{}.dat'.format(args.data_name), reorder_epochs=args.reorder_epochs)
data.sample_per_graph = args.sample_per_graph


def collate(samples):
    batch = {
        'partial_graphs': list(),  # list of dgl graphs

        # data for nodes:
        'node_graph_idx': list(),  # np.array
        'node_super_node_idx': list(),  # np.array
        'node_tree_idx': list(),
        'node_target': list(),  # torch.tensor

        # data for edges:
        'edges': list(),  # np.array
        'edge_graph_idx': list(),  # np.array
        'edge_super_node_idx': list(),  # np.array
        'edge_tree_idx': list(),
        'masked_edges': list(),  # torch.tensor
        'edge_target': list(),  # torch.tensor

        # size = 1
        'trees': list()
    }
    graphs_offset = 0
    tree_super_node_offset = 0
    graph_total_node_offset = 0
    for i, sample in enumerate(samples):
        batch['partial_graphs'] = batch['partial_graphs'] + sample['partial_graphs']
        batch['trees'].append(sample['tree'])

        batch['node_graph_idx'].append(sample['node_graph_idx'] + graphs_offset)
        batch['node_tree_idx'] += ([i] * sample['node_target'].shape[0])
        batch['node_super_node_idx'].append(sample['node_super_node_idx'] + tree_super_node_offset)
        batch['node_target'].append(sample['node_target'])

        batch['edges'].append(sample['edges'] + graph_total_node_offset)
        batch['edge_graph_idx'].append(sample['edge_graph_idx'] + graphs_offset)
        batch['edge_super_node_idx'].append(sample['edge_super_node_idx'] + tree_super_node_offset)
        batch['edge_tree_idx'] += ([i] * sample['edge_target'].shape[0])
        batch['masked_edges'].append(sample['masked_edges'])
        batch['edge_target'].append(sample['edge_target'])

        graphs_offset += len(sample['partial_graphs'])
        tree_super_node_offset += sample['tree'].number_of_nodes()
        graph_total_node_offset += sample['total_number_of_nodes']

    batch['node_target'] = torch.cat(batch['node_target'])
    batch['edge_target'] = torch.cat(batch['edge_target'])
    batch['masked_edges'] = torch.cat(batch['masked_edges'], dim=0)

    batch['node_graph_idx'] = np.concatenate(batch['node_graph_idx'])
    batch['edge_graph_idx'] = np.concatenate(batch['edge_graph_idx'])
    batch['node_super_node_idx'] = np.concatenate(batch['node_super_node_idx'])
    batch['edge_super_node_idx'] = np.concatenate(batch['edge_super_node_idx'])

    batch['edges'] = np.concatenate(batch['edges'], axis=0)

    batch['node_tree_idx'] = np.array(batch['node_tree_idx'])
    batch['edge_tree_idx'] = np.array(batch['edge_tree_idx'])

    return batch


def evaluate_loss(model, eval_data, kk=K):
    model.eval()
    # data.mode = 'eval'

    data_loader = torch.utils.data.DataLoader(eval_data,
                                              batch_size=BATCH_SIZE, shuffle=True,
                                              num_workers=args.num_workers, collate_fn=collate)
    eval_loss_node = torch.tensor([0.0], device=device)
    eval_loss_edge = torch.tensor([0.0], device=device)

    loss_fn = nn.BCELoss()

    Acc_Node = BinaryClassificationMeter()
    Acc_Edge = BinaryClassificationMeter()

    with torch.no_grad():
        Acc_Node.reset()
        Acc_Edge.reset()
        cnt_node = 0
        cnt_edge = 0

        for jj in range(kk):
            for i, batch in enumerate(data_loader):
                output_node, output_edge = model(
                    batch['partial_graphs'],
                    batch['trees'],
                    batch['node_graph_idx'],
                    batch['node_super_node_idx'],
                    batch['node_tree_idx'],
                    batch['edges'],
                    batch['edge_super_node_idx'],
                    batch['edge_tree_idx'],
                    batch['masked_edges'],
                    batch['edge_graph_idx'])

                batch['node_target'] = batch['node_target'].view(-1, 1).to(device)
                batch['edge_target'] = batch['edge_target'].view(-1, 1).to(device)

                batch_loss_node = loss_fn(output_node, batch['node_target'])
                batch_loss_edge = loss_fn(output_edge, batch['edge_target'])
                eval_loss_node += batch_loss_node.data.detach() * batch['node_target'].shape[0]
                eval_loss_edge += batch_loss_edge.data.detach() * batch['edge_target'].shape[0]
                cnt_node += batch['node_target'].shape[0]
                cnt_edge += batch['edge_target'].shape[0]

                Acc_Node.update(output_node, batch['node_target'])
                Acc_Edge.update(output_edge, batch['edge_target'])

    # print('evaluation nll average per graph: ', eval_loss_node/kk, eval_loss_edge/kk, len(eval_data), (eval_loss_node + eval_loss_edge)/(kk*len(eval_data)))
    # print('cnts: ', cnt_node, cnt_edge)
    return eval_loss_node / cnt_node, Acc_Node, eval_loss_edge / cnt_edge, Acc_Edge, (eval_loss_node + eval_loss_edge)/(kk*len(eval_data))


def evaluate_stats(current_model, test_ref_graphs):
    adr = os.path.join(configs.root_dir, 'saved_models')

    if args.tree_generator == 'none':
        args.tree_generator = 'tree_generator_{}'.format(args.data_name)

    if args.node_sharing == 'none':
        args.node_sharing = 'node_sharing_{}'.format(args.data_name)

    adr_tree = os.path.join(adr, args.tree_generator)
    adr_sharing = os.path.join(adr, args.node_sharing)
    # adr_adding = os.path.join(adr, args.model_name)

    try:
        tree_model = torch.load(adr_tree, map_location=device)
        node_sharing_model = torch.load(adr_sharing, map_location=device)
        node_adding_model = current_model
    except:
        print('one of the models is not available ... \n aborting evaluation')
        return

    stats = dist_stats(tree_model=tree_model, node_sharing_model=node_sharing_model,
                       node_adding_model=node_adding_model, ref_test_graphs=test_ref_graphs)

    return stats
    # snapshot = {
    #     "model": node_adding_model.state_dict(),
    #     "optimizer": optimizer.state_dict(),
    #     "scheduler": scheduler.state_dict(),
    #     "step": step,
    #     "stats": stats
    # }
    #
    # snapshot_adr = os.path.join(adr, 'snapshots')
    # snapshot_adr = os.path.join(snapshot_adr, '{}_{}'.format(args.model_name, step))
    #
    # with open(snapshot_adr, "wb") as f:
    #     pickle.dump(snapshot, f)


def train_node_adding(model, train_data, eval_data, test_ref_graphs, model_name, checkpoint=None):
    best_loss = torch.tensor(1000000.0, device=device)
    best_loss_node_accuracy = torch.tensor(0.0, device=device)
    best_loss_edge_accuracy = torch.tensor(0.0, device=device)

    data_loader = torch.utils.data.DataLoader(train_data,
                                              batch_size=BATCH_SIZE, shuffle=True,
                                              num_workers=args.num_workers, collate_fn=collate)

    adr = os.path.join(configs.root_dir, 'saved_models', model_name)
    adr_state_dict = os.path.join(configs.root_dir, 'saved_models', model_name + '_state_dict')
    adr_state_dict_best = os.path.join(configs.root_dir, 'saved_models', model_name + '_state_dict_best')
    print("Saving model to: ", adr)

    if args.optimizer == 'Adam':
        optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, betas=(0.9, 0.999), eps=1e-08,
                                     weight_decay=0, amsgrad=False)
    elif args.optimizer == 'SGD':
        optimizer = torch.optim.SGD(model.parameters(), lr=args.lr, momentum=0.9)
    else:
        raise Exception('optimizer is not in options')

    loss_fn = nn.BCELoss()

    Acc_Node = BinaryClassificationMeter()
    Acc_Edge = BinaryClassificationMeter()

    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=25,
                                                           threshold=0.01,
                                                           threshold_mode='rel', cooldown=0, min_lr=0.0002, eps=1e-08,
                                                           verbose=True)

    start_epoch = 0
    if checkpoint is not None:
        optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        scheduler.load_state_dict(checkpoint['scheduler_state_dict'])
        start_epoch = checkpoint['epoch'] + 1
        best_loss = checkpoint['best_loss']
        best_loss_node_accuracy = checkpoint['best_loss_node_accuracy']
        best_loss_edge_accuracy = checkpoint['best_loss_edge_accuracy']

        print(optimizer.param_groups[0]['lr'])
        print(scheduler.state_dict()['patience'])

    early_stop_counter = 0

    for epoch in range(start_epoch, args.epochs):
        data.mode = 'train'
        model.train()
        print("\nepoch: ", epoch)
        data.epoch_cnt += 1

        epoch_loss_node = torch.tensor([0.0], device=device)
        epoch_loss_edge = torch.tensor([0.0], device=device)
        cnt_node = 0
        cnt_edge = 0
        Acc_Node.reset()
        Acc_Edge.reset()

        for i, batch in enumerate(data_loader):
            optimizer.zero_grad()

            # print('before going into the model')
            # breakpoint()

            output_node, output_edge = model(
                batch['partial_graphs'],
                batch['trees'],
                batch['node_graph_idx'],
                batch['node_super_node_idx'],
                batch['node_tree_idx'],
                batch['edges'],
                batch['edge_super_node_idx'],
                batch['edge_tree_idx'],
                batch['masked_edges'],
                batch['edge_graph_idx'])

            del batch['partial_graphs'], batch['trees']

            batch['node_target'] = batch['node_target'].view(-1, 1).to(device)
            batch['edge_target'] = batch['edge_target'].view(-1, 1).to(device)

            batch_loss_node = loss_fn(output_node, batch['node_target'])
            batch_loss_edge = loss_fn(output_edge, batch['edge_target'])
            # batch_loss = batch_loss_node * batch['node_target'].shape[0] \
            #              + batch_loss_edge * batch['edge_target'].shape[0]
            batch_loss = batch_loss_node + batch_loss_edge
            #batch_loss = batch_loss_node

            epoch_loss_node += batch_loss_node.data.detach() * batch['node_target'].shape[0]
            epoch_loss_edge += batch_loss_edge.data.detach() * batch['edge_target'].shape[0]
            cnt_node += batch['node_target'].shape[0]
            cnt_edge += batch['edge_target'].shape[0]

            Acc_Node.update(output_node.data.detach(), batch['node_target'])
            Acc_Edge.update(output_edge.data.detach(), batch['edge_target'])

            batch_loss.backward()
            optimizer.step()

            # for obj in gc.get_objects():
            #     try:
            #         if torch.is_tensor(obj) or (hasattr(obj, 'data') and torch.is_tensor(obj.data)):
            #             print(type(obj), obj.size())
            #     except:
            #         pass

            if i % 4 == 0:
                print('batch {}: average node loss = {}, average edge loss = {}'.format(i,
                                                                                        epoch_loss_node / cnt_node,
                                                                                        epoch_loss_edge / cnt_edge))

        print("epoch node loss: ", epoch_loss_node / cnt_node)
        print("train node accuracy: ", Acc_Node.acc)
        print("epoch edge loss: ", epoch_loss_edge / cnt_edge)
        print("train edge accuracy: ", Acc_Edge.acc)

        # epoch_avg_loss = (epoch_loss_node + epoch_loss_edge) / (cnt_node + cnt_edge)
        epoch_avg_loss = ((epoch_loss_node / cnt_node) + (epoch_loss_edge / cnt_edge)) * 0.5

        epoch_avg_loss_per_graph = (epoch_loss_node + epoch_loss_edge)/len(train_data)
        print('train nll average per graph: ', epoch_avg_loss_per_graph)

        eval_node_loss, eval_node_acc, eval_edge_loss, eval_edge_acc, _ = evaluate_loss(model, eval_data=eval_data)
        print("evaluation node loss: %.4f and node accuracy: %.3f " % (eval_node_loss.item(), eval_node_acc.acc.item()))
        print("evaluation edge loss: %.4f and edge accuracy: %.3f " % (eval_edge_loss.item(), eval_edge_acc.acc.item()))
        eval_loss = eval_node_loss + eval_edge_loss

        early_stop_counter += 1

        if eval_loss < best_loss:
            print('saving model ... ')
            best_loss = eval_loss.data.detach()
            best_loss_node_accuracy = copy.deepcopy(eval_node_acc)
            best_loss_edge_accuracy = copy.deepcopy(eval_edge_acc)
            torch.save(model, adr)
            torch.save({
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'scheduler_state_dict': scheduler.state_dict(),
                'best_loss': best_loss,
                'best_loss_node_accuracy': best_loss_node_accuracy,
                'best_loss_edge_accuracy': best_loss_edge_accuracy
            }, adr_state_dict_best)
            early_stop_counter = 0

        torch.save({
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'scheduler_state_dict': scheduler.state_dict(),
                'best_loss': best_loss,
                'best_loss_node_accuracy': best_loss_node_accuracy,
                'best_loss_edge_accuracy': best_loss_edge_accuracy
            }, adr_state_dict)

        print('best evaluation loss: ', best_loss)
        print('best evaluation accuracy node:%.3f, edge:%.3f ' % (best_loss_node_accuracy.acc.item(),
                                                                  best_loss_edge_accuracy.acc.item()))

        scheduler.step(epoch_avg_loss)

        # if (epoch+1) % EVAL_EPOCHS == 0:
        #     evaluate_stats(model, optimizer, scheduler, epoch+1, test_ref_graphs)

        if wandb.run is not None:  # is initialized
            wandb.log(
                {'train_node/loss': epoch_loss_node.cpu() / cnt_node,
                 'train_node/acc': Acc_Node.acc.cpu(),
                 'train_edge/loss': epoch_loss_edge.cpu() / cnt_edge,
                 'train_edge/acc': Acc_Edge.acc.cpu(),
                 'eval_node/loss': eval_node_loss.cpu(),
                 'eval_node/acc': eval_node_acc.acc.cpu(),
                 'eval_edge/loss': eval_edge_loss.cpu(),
                 'eval_edge/acc': eval_edge_acc.acc.cpu(),
                 'best_loss/loss': best_loss.cpu(),
                 'best_loss_node/acc': best_loss_node_accuracy.acc.cpu(),
                 'best_loss_edge/acc': best_loss_edge_accuracy.acc.cpu()
                 },
                step=epoch
            )
        if early_stop_counter >= EARLY_STOP_EPOCHS:
            return


def main():
    print(f'root_dir={configs.root_dir}')
    if args.use_wandb:
        wandb.init(project='decomp_gen_node_adding', config=args)

    # making indices for train/test
    train_last_idx = int(float(len(data)) * TRAIN_RATIO)
    test_last_idx = int(float(len(data)) * TEST_RATIO) + train_last_idx

    indices = list(range(len(data)))

    train_idxs = indices[0:train_last_idx]
    test_idxs = indices[train_last_idx:test_last_idx]
    eval_idxs = indices[test_last_idx:]

    train_data = torch.utils.data.Subset(data, train_idxs)
    eval_data = torch.utils.data.Subset(data, eval_idxs)
    test_data = torch.utils.data.Subset(data, test_idxs)

    test_ref_graphs = []
    for idx in test_idxs:
        test_ref_graphs.append(data.graphs[idx].G)
    # test_data = torch.utils.data.Subset(data, test_idxs)

    model = NodeAdding(max_cluster_size=data.C,
                       max_graph_size=data.N,
                       tree_hidden_dim=args.tree_hidden_dim,
                       gat_hidden_dim=args.gnn_hidden_dim,
                       gat_num_layers=args.gnn_num_layers,
                       node_feat_dim=args.gnn_input_dim,
                       mlp_hidden_dim=args.mlp_hidden_dim)

    checkpoint = None

    if args.continue_training:
        print('loading model to continue training ....')
        adr = os.path.join(configs.root_dir, 'saved_models', args.model_name + '_state_dict')
        # model = torch.load(adr, map_location=device)
        try:
            checkpoint = torch.load(adr)
            model.load_state_dict(checkpoint['model_state_dict'])
        except:
            print('state dict not found trying to load model . . .')
            adr = os.path.join(configs.root_dir, 'saved_models', args.model_name)
            model = torch.load(adr, map_location=device)

    model = model.to(device)

    try:
        train_node_adding(model, train_data, eval_data, test_ref_graphs, args.model_name, checkpoint)
    except:
        print('\ntrain finished')

    adr = os.path.join(configs.root_dir, 'saved_models', args.model_name)
    best_model = torch.load(adr, map_location=device)

    print('test data:')

    test_nlls = list()
    has_converged = False

    while not has_converged:
        _, _, _, _, nll_per_graph = evaluate_loss(best_model, test_data, kk=1)
        test_nlls.append(nll_per_graph)
        mean = np.mean(np.array(test_nlls))
        std = np.std(np.array(test_nlls))

        print('mean: ', mean)
        print('std: ', std)

        if len(test_nlls) > 5 and std / (math.sqrt(len(test_nlls))) < 0.01 * mean:
            has_converged = True

    print('train data:')
    evaluate_loss(best_model, train_data, kk=100)

    # Run this section, only when you have trained tree generator
    # and node sharing models properly and saved in saved models.
    # Give the name of these models as the arg of this code.
    # evaluate_stats(best_model, test_ref_graphs)





if __name__ == "__main__":
    main()
