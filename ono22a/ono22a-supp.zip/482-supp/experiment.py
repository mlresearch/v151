import numpy as np
import scipy.optimize as optimize


"""
Building Blocks
"""
def bit_flip(v, epsilon, n, cu, cl):
    e = np.exp(epsilon)
    c = (e + 1.) / (e - 1.)
    r = np.random.random(size=n)
    threshold = 0.5 + (v - (cu+cl)/2) / (c*(cu-cl))
    out = np.ones(n)
    out[r > threshold] = 0

    return out


def unpackbits(x, num_bits):
    """
    This function is cited from
    https://stackoverflow.com/questions/18296035/how-to-extract-the-bits-of-larger-numeric-numpy-data-types
    """
    if np.issubdtype(x.dtype, np.floating):
        raise ValueError("numpy data type needs to be int-like")
    xshape = list(x.shape)
    x = x.reshape([-1, 1])
    mask = 2**np.arange(num_bits, dtype=x.dtype).reshape([1, num_bits])
    
    return (x & mask).astype(bool).astype(int).reshape(xshape + [num_bits])


"""
Functions for the public X scenario
"""


def psi(theta, sigma, alpha, epsilon, cu, cl):
    out = np.zeros(len(theta))
    out[theta <= cl] = psi1(theta[theta <= cl], sigma, alpha, epsilon, cu, cl)
    out[(cl<theta)*(theta<cu)] = psi2(theta[(cl<theta)*(theta<cu)], sigma, alpha, epsilon, cu, cl)
    out[theta >= cu] = psi3(theta[theta >= cu], sigma, alpha, epsilon, cu, cl)
    
    return out
    

def psi1(theta, sigma, alpha, epsilon, cu, cl):
    c = (np.exp(epsilon) + 1.) / (np.exp(epsilon) - 1.)
    fz1 = 0.5 - 1/(2*c)
    fz2 = (1-alpha) * sigma / alpha / (c*(cu-cl)) * (np.exp(- alpha / sigma * (cl-theta)) - np.exp(-alpha/sigma*(cu-theta)))
    
    return fz1 + fz2


def psi2(theta, sigma, alpha, epsilon, cu, cl):
    e = np.exp(epsilon)
    c = (e + 1.) / (e - 1.)
    A = np.exp((1-alpha)/sigma*(cl-theta))
    B = np.exp(-alpha/sigma*(cu-theta))
    fz1 = 0.5 + (-alpha/(1-alpha)+(1-alpha)/alpha)*sigma / (c*(cu-cl))
    fz2 = alpha/(1-alpha)*sigma/(c*(cu-cl))*A
    fz3 = -(1-alpha)/alpha*sigma/(c*(cu-cl))*B
    fz4 = theta/(c*(cu-cl)) - (cu+cl)/(2*c*(cu-cl))
    
    return fz1 + fz2 + fz3 + fz4


def psi3(theta, sigma, alpha, epsilon, cu, cl):
    c = (np.exp(epsilon) + 1.) / (np.exp(epsilon) - 1.)
    fz1 = 0.5 + 1/(2*c)
    fz2 = alpha * sigma / (1-alpha) / (c*(cu-cl)) * (np.exp((1-alpha)/sigma*(cl-theta))-np.exp((1-alpha)/sigma*(cu-theta)))
    
    return fz1 + fz2


def psi_dash(theta, sigma, alpha, epsilon, cu, cl):
    out = np.zeros(len(theta))
    out[theta <= cl] = psi_dash1(theta[theta <= cl], sigma, alpha, epsilon, cu, cl)
    out[(cl<theta)*(theta<cu)] = psi_dash2(theta[(cl<theta)*(theta<cu)], sigma, alpha, epsilon, cu, cl)
    out[theta >= cu] = psi_dash3(theta[theta >= cu], sigma, alpha, epsilon, cu, cl)

    return out


def psi_dash1(theta, sigma, alpha, epsilon, cu, cl):
    e = np.exp(epsilon)
    c = (e + 1.) / (e - 1.)
    
    return (1-alpha)/(c*(cu-cl))*(np.exp(-alpha/sigma*(cl-theta))-np.exp(-alpha/sigma*(cu-theta)))


def psi_dash2(theta, sigma, alpha, epsilon, cu, cl):
    e = np.exp(epsilon)
    c = (e + 1.) / (e - 1.)
    A = np.exp(-(alpha-1)/sigma*(cl-theta))
    B = np.exp(-alpha/sigma*(cu-theta))
    
    return (1. - alpha*A - (1-alpha)*B)/(c*(cu-cl))


def psi_dash3(theta, sigma, alpha, epsilon, cu, cl):
    e = np.exp(epsilon)
    c = (e + 1.) / (e - 1.)
    
    return alpha/(c*(cu-cl))*(-np.exp((1-alpha)/sigma*(cl-theta))+np.exp((1-alpha)/sigma*(cu-theta)))


def neg_log_likelihood(beta, x, y, sigma, alpha, epsilon, cu, cl):
    loc = np.matmul(x, beta).squeeze()
    psi_ = psi(loc,sigma,alpha,epsilon,cu,cl)

    return -np.average(y * np.log(psi_)+(1-y) * np.log(1.-psi_))


def neg_log_likelihood_der(beta, x, y, sigma, alpha, epsilon, cu, cl):
    loc = np.matmul(x, beta).squeeze()
    psi_ = psi(loc,sigma,alpha,epsilon,cu,cl)
    psi_dash_ = psi_dash(loc,sigma,alpha,epsilon,cu,cl)
    
    return - np.matmul(psi_dash_ / psi_ * y - (1-y) * psi_dash_ / (1.-psi_), x)/len(y)


def experiment(n_dash, x, y, sigma, alpha, epsilon, cu, cl):
    n, d = np.shape(x)
    ind = np.random.choice(n, n_dash, replace=False)
    y_sample = y[ind]
    x_sample = x[ind]
    
    # truncate Y
    bar_y = np.copy(y_sample)
    bar_y[bar_y < cl] = cl
    bar_y[bar_y > cu] = cu

    zy = bit_flip(bar_y, epsilon, n_dash, cu, cl)
        
    beta = np.zeros(d)
    pri_res = optimize.minimize(neg_log_likelihood,beta,args=(x_sample,zy,sigma,alpha,epsilon,cu,cl),method='BFGS',
                               jac=neg_log_likelihood_der, options={'gtol': 1e-6})
    
    return pri_res.x


"""
Functions for the Private X scenario
"""
def neg_log_likelihood_private(beta, zx, zy, sigma, alpha, epsilon, cuy, cly, dummy_x):
    n, d = np.shape(zx)
    loc_ = np.matmul(dummy_x, beta).squeeze()
    psi_vec = psi(loc_,sigma,alpha,epsilon,cuy,cly) # this value does not depend on z
    phi_ = np.array([phi(zx[i], epsilon, psi_vec, dummy_x) for i in range(n)])
    # phi_ = phi(zx, epsilon, psi_vec, dummy_x)
    
    return -np.average(zy * np.log(phi_)+(1-zy) * np.log(1.-phi_))


def phi(single_zx, epsilon, psi_vec, dummy_x):
    d = len(single_zx)
    eps_dash_ = epsilon/(d+1)
    p_ = np.exp(eps_dash_ * np.count_nonzero(dummy_x==single_zx, axis=1)-d * np.log(np.exp(eps_dash_)+1)-0.000001)
    out_ = np.matmul(psi_vec.transpose(), p_)
    
    return out_


def neg_log_likelihood_private_der(beta, zx, zy, sigma, alpha, epsilon, cuy, cly, dummy_x):
    n, d = np.shape(zx)
    # dummy_x = unpackbits(np.arange(2**d), d)
    loc_ = np.matmul(dummy_x, beta).squeeze()
    psi_vec = psi(loc_,sigma,alpha,epsilon,cuy,cly) # this value does not depend on z
    phi_ = np.array([phi(zx[i], epsilon, psi_vec, dummy_x) for i in range(n)])
    psi_der_vec = psi_dash(loc_,sigma,alpha,epsilon,cuy,cly) # this value does not depend on z
    phi_der_ = np.array([phi_dash(zx[i], epsilon, psi_der_vec, dummy_x) for i in range(n)])
    
    return -np.matmul(zy / phi_ - (1-zy) / (1.-phi_), phi_der_) / n


def phi_dash(single_zx, epsilon, psi_der_vec, dummy_x):
    d = len(single_zx)
    eps_dash_ = epsilon/(d+1)
    p_ = np.exp(eps_dash_ * np.count_nonzero(dummy_x==single_zx, axis=1)-d * np.log(np.exp(eps_dash_)))
    out_ = np.matmul(psi_der_vec*p_, dummy_x).transpose()
    
    return out_


def qx(x, epsilon, cux, clx):
    """
    cux and clx must d-dmensional vectors
    """
    n, d = x.shape
    e = np.exp(epsilon/(d+1))
    c = (e + 1.) / (e - 1.)
    r = np.random.random(size=n*d).reshape((n, d))
    threshold = 0.5 + (x - (cux+clx)/2) / (c*(cux-clx))
    # threshold_ex = np.repeat(threshold, n, axis=0).reshape((d, n)).transpose()
    out = np.ones((n, d))
    out[r > threshold] = 0
    
    return out


def experiment_private(n_dash, x, y, sigma, alpha, epsilon, cuy, cly, cux, clx):
    n, d = np.shape(x)
    ind = np.random.choice(n, n_dash, replace=False)
    y_copy = (y[ind]).copy()
    x_copy = (x[ind]).copy()
    
    cux_n = np.repeat(cux, n_dash, axis=0).reshape((d, n_dash)).transpose()
    clx_n = np.repeat(clx, n_dash, axis=0).reshape((d, n_dash)).transpose()

    x_copy[x_copy<clx_n] = clx_n[x_copy<clx_n]
    x_copy[x_copy>cux_n] = cux_n[x_copy>cux_n]
    y_copy[y_copy<cly] = cly
    y_copy[y_copy>cuy] = cuy

    zx = qx(x_copy, epsilon, cux, clx)
    zx_ind = zx == 0
    zx[zx_ind] = clx_n[zx_ind]
    zx[~zx_ind] = cux_n[~zx_ind]
    zy = bit_flip(y_copy, epsilon/(d+1), n_dash, cuy, cly)

    dummy_x = unpackbits(np.arange(2**d), d)
    dummy_ind = dummy_x==0
    dummy_x[dummy_ind] = (np.repeat(clx, 2**d, axis=0).reshape((d, 2**d)).transpose())[dummy_ind]
    dummy_x[~dummy_ind] = (np.repeat(cux, 2**d, axis=0).reshape((d, 2**d)).transpose())[~dummy_ind]

    beta = np.zeros(d)
    pri_res = optimize.minimize(neg_log_likelihood_private,beta,args=(zx,zy,sigma,alpha,epsilon,cuy,cly,dummy_x),
                                method='BFGS', jac=neg_log_likelihood_private_der, options={'gtol': 1e-6})

    return pri_res.x


"""
Functions for Non-private scenario
"""

def non_private_experiment(n_dash, x, y, alpha):
    n, d = np.shape(x)
    ind = np.random.choice(n, n_dash, replace=False)
    y_sample = y[ind]
    x_sample = x[ind]
    
    beta = np.zeros(d)
    
    # res = optimize.minimize(rho,beta,args=(x_sample,y_sample,alpha),method='BFGS',
    #                            jac=rho_der, options={'gtol': 1e-6})
    res = optimize.minimize(rho,beta,args=(x_sample,y_sample,alpha),method='Powell')
    
    return res.x

def rho(beta, x, y, alpha):
    loc = np.matmul(x, beta)
    out = y-loc
    ind = out<=0
    out[ind] *= alpha - 1
    out[~ind] *= alpha
    
    return np.average(out)


def rho_der(beta, x, y, alpha):
    loc = np.matmul(x, beta)
    out = y-loc
    ind = out<=0
    
    res = np.ones(len(ind))
    res[ind] *= alpha - 1
    res[~ind] *= alpha
    
    return np.matmul(res, x)/len(ind)