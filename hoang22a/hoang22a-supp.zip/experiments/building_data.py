import sys
import os
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"
from os.path import dirname
sys.path.append(dirname("/home/user/neurips21/"))  # this is to add the project's path to PYTHONPATH so python can tell where to load the relevant parts of the code

# importing our utils function
from utils.utilities import *
# importing bits for our metric implementations
from utils.metric import *

# importing keras
from tensorflow.keras import backend as KB
import tensorflow as tf

# importing bits for our recommenders
from models.nets.simsnet import *
from models.nets.spenet import *
from models.recommenders.sims import *
from models.recommenders.spe import *
from models.recommenders.simsssl import *

# importing bits for our personalizers
from models.personalizer.kernel import *
from models.personalizer.simsgp import *
from models.personalizer.simspersonalizer import *
from models.personalizer.simssparsegp import *

# importing bits for our data loaders
from loaders.dataloader import *
from loaders.pairloader import *
from loaders.featureloader import *
from loaders.factory import *

# set random seed
fix_seed()

# set the GPU -- which one to be used for training -- later: figure out how to do multi-GPU training
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

INPUT_PATH = "/home/user/data/movielens/20M"  # base path for data
OUTPUT_PATH = "/home/user/neurips21_cache"  # base path for model + data saves

if not os.path.exists(OUTPUT_PATH):
    os.mkdir(OUTPUT_PATH)

DATA_VERSION = "movielens-data"  # specific name for data loader cache

INTERACTION = os.path.sep.join([INPUT_PATH, "user-item-interactions.csv"])  # interaction data goes here
DATA_CACHE = os.path.sep.join([OUTPUT_PATH, DATA_VERSION])  # path to DATA CACHE -- where to save our data objects

if not os.path.exists(DATA_CACHE):  # check if the folder exists already
    os.makedirs(DATA_CACHE)  # if not, create it

META_CHANNELS = ['Plot']
channels = {}
for CHANNEL in META_CHANNELS:
    channels[CHANNEL] = os.path.sep.join([INPUT_PATH, "{}.npz".format(CHANNEL)])

print("Building Data ...")
n_pair_per_user, window, timecut = 10, 10, 1365957431  # this timecut is for MovieLen data
DataBuilder = DataFactory(INTERACTION, channels, batch_size = 10000, n_pair_per_user = n_pair_per_user,
                          window = window, timecut = timecut)

print("Saving Data")
save_object(DataBuilder, DATA_CACHE + "/data-pair-per-user-{}-window-{}-timecut-{}.dat".format(n_pair_per_user, window, timecut))

print("Loading Data")
DataBuilder : DataFactory = load_object(DATA_CACHE + "/data-pair-per-user-{}-window-{}-timecut-{}.dat".format(n_pair_per_user, window, timecut))

print("Checking Data")
train_items = set()
for i in range(len(DataBuilder.train_pairs)):
    train_items.add(DataBuilder.train_pairs[i][0])
    train_items.add(DataBuilder.train_pairs[i][1])
seen = 0
for item in DataBuilder.unseen_items:
    if item in train_items:
        seen += 1

if seen > 0:
    print("Data Leak: {} train items were seen in test set!".format(seen))
else:
    print("Data OK!")