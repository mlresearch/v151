REQUIRED_CONFIG_KEYS = ["dim", "num_classes", "feature_type"]

REQUIRED_CONSTANT_KEYS = ["sample_size",
                          "eval_sample_size",
                          "mean_classifier_sample_size",
                          "max_epoch",
                          "downstream_max_epoch",
                          "patience",
                          "lr",
                          "batch_size",
                          "n_hidden",
                          "grad_clip"]


def validate(config, constants):

    for key in REQUIRED_CONFIG_KEYS:
        assert key in config, "Did not find the key %r in config in dictionary" % key

    for key in REQUIRED_CONSTANT_KEYS:
        assert key in constants, "Did not find the key %r in constants dictionary" % key

    return True
