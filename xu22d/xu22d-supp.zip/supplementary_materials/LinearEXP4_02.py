from linear_exp4 import linearExp4
import numpy as np
import pickle as pk
"""
    This program implements the experiments in our paper.
    For the plot shown as Figure 2., please run 'plotting.py' after finishing running this 'LinearEXP4_02.py'.
"""
# Algorithm starts from T_0 = start_point,
# with each epoch k length T_k = start_point ** (k/3) for k < epoches.
epoches = 22
geometrical_factor = 2**(1/3)
start_point = 512
rounds = 20  # time of repeat
d = 2  # dimension
regret_list = np.zeros((epoches, rounds))
for tau in range(epoches):
    print("Epoch ", tau)
    T_tau = int(start_point*(geometrical_factor**tau))
    regret_tau = linearExp4(T=T_tau, d=d,
                            gamma=0.11, rounds=rounds, mode_indicator=1, sigma=0.25, bound_theta=1, bound_x=1,
                            start_point=start_point, ifregression=0, ifplot=0, ifsave=1, ifprint=0)
    regret_list[tau] = regret_tau
with open("linearExp4_d=%d, epoch=%d, start=%d,"
          " geometrical_factor=%f, rounds=%d"
          % (d, epoches, start_point, geometrical_factor, rounds), "wb") as linear_exp4_rec:
    pk.dump(regret_list, linear_exp4_rec)


