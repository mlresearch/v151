import numpy as np

def load_synth_data(general_type):
    np.random.seed(41)
    size = 11100

    points = np.random.beta(0.5,1,10*size//10)*5+10*np.sin(np.linspace(0,3*np.pi,num=10*size//10))/2.+0.5
    points2 = - np.random.beta(0.5,1,10*size//10)*5+10*np.sin(np.linspace(np.pi,4*np.pi,num=10*size//10))/2.+0.5


    points = np.concatenate((points.reshape(-1,1),points2.reshape(-1,1)),axis=1).reshape(-1)

    y_train_synthetic = np.array(points).reshape(-1,1)
    y_train_synthetic = y_train_synthetic/y_train_synthetic.max()
    x_train_synthetic = np.arange(y_train_synthetic.shape[0]).reshape(-1,1)
    x_train_synthetic = x_train_synthetic/x_train_synthetic.max()

    disord = np.arange(y_train_synthetic.shape[0])
    np.random.shuffle(disord)

    x_train_synthetic = x_train_synthetic[disord]
    y_train_synthetic = y_train_synthetic[disord]

    x_test_synthetic = x_train_synthetic[:x_train_synthetic.shape[0]//2].astype(general_type)
    y_test_synthetic = y_train_synthetic[:x_train_synthetic.shape[0]//2].astype(general_type)
    y_train_synthetic = y_train_synthetic[x_train_synthetic.shape[0]//2:].astype(general_type)
    x_train_synthetic = x_train_synthetic[x_train_synthetic.shape[0]//2:].astype(general_type)

    x_valid_synthetic = x_train_synthetic[:x_train_synthetic.shape[0]//10].astype(general_type)
    y_valid_synthetic = y_train_synthetic[:x_train_synthetic.shape[0]//10].astype(general_type)
    y_train_synthetic = y_train_synthetic[x_train_synthetic.shape[0]//10:].astype(general_type)
    x_train_synthetic = x_train_synthetic[x_train_synthetic.shape[0]//10:].astype(general_type)

    return x_train_synthetic, y_train_synthetic, x_valid_synthetic, y_valid_synthetic, x_test_synthetic, y_test_synthetic