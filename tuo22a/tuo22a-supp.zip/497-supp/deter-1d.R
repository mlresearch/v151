library(RandomFields)
#library(deldir) 
library(randtoolbox)
library(GPfit)
library(geoR)
library(lhs)
library(flexclust)
library(mlegp)
library(mvtnorm)
library(randtoolbox)

mytest <- function(s){
  # term1 <- sin(2*pi*s/10)
  term1 <- 1.5*sin(2*pi*s/2)
  term2 <- -0.2 * sin(2*pi*s/2.5)
  y <- (term1 + term2) - (s-1)^2/120
  # y <- ((term1 + term2) - sin((s-1)^2)/sqrt(30))
  return(y)
}

pointeval = function(x,X){
  for(i in 1:length(X)){
    if((x - X[i])^2<0.01){
      return(i)
    }
  }
}

findY = function(y,Y){
  for(i in 1:length(Y)){
    if(Y[i] == y){
      return(i)
    }
  }
}

desnum = 30
itmax = 30
itnum = seq(5, itmax, by = 5)
itnumlen = length(itnum)

n1=5001

myPreX <- seq(0, 8, length.out = n1)
myX <- seq(0, 8, length.out = desnum)
desnum=length(myX)
myY <- 1:desnum

mynu = 1.5
myphi = 1/(2*sqrt(mynu))
sigma2 = 1
# mynu <- c(1.5,2.5,3.5)
A0D <- 5

myscalenu = function(nu,p){
  D = sqrt(p)
  return((p*4*sqrt(nu)*gamma(nu + 1/2)*D/(sqrt(pi) * (2*nu - 1)*gamma(nu)))/A0D)
}

# Mtheta <- myscalenu(mynu,1)
# myphi = Mtheta/(sqrt(mynu))
# 
# myDist=as.matrix(dist(myPreX,diag=TRUE,upper=TRUE))
# PhiEval <- matern(u = myDist, phi = myphi, kappa = mynu)
GPdraw <- myPreX

A0Dcan <- seq(0.01, 10, length.out = 100)

myDistXX=as.matrix(dist(myX,diag=TRUE,upper=TRUE))

mymle = function(y){
  y1 = -100000
  tt = 1
  for(i in 1:100){
    A0 = A0Dcan[i]
    scnu = (4*sqrt(mynu)*gamma(mynu + 1/2)/(sqrt(pi) * (2*mynu - 1)*gamma(mynu)))/A0
    myphi1 = scnu/(sqrt(mynu))
    K <- matern(u = myDistXX, phi = myphi1, kappa = mynu)
    sigma22 = sqrt(t(as.matrix(GPdraw[inipos]))%*%solve(K + 1e-11* diag(desnum),as.matrix(GPdraw[inipos]),tol = 0)/desnum)
    for(j in 1:desnum){
      for(k in 1:desnum){
        K[j,k] <- sigma22^2 *K[j,k]
      }
    }
    y2 <- dmvnorm(y, mean = 0*y, sigma = K, log =TRUE)
    # print(y2)
    if(y2>y1){
      tt = i
      y1 = y2
    }
  }
  return(tt)
}


for(k in 1:n1){
  GPdraw[k] = mytest(myPreX[k])
}

inipos <- 1:desnum
for(k in 1:desnum){
  inipos[k] <- pointeval(myX[k],myPreX)
}

for(k in 1:desnum){
  myY[k] <- mytest(myX[k])
}

A0D=A0Dcan[mymle(myY)]
Mtheta <- myscalenu(mynu,1)
myphi = Mtheta/(sqrt(mynu))

myDist=as.matrix(dist(myPreX,diag=TRUE,upper=TRUE))
PhiEval <- matern(u = myDist, phi = myphi, kappa = mynu)

mycover <- seq(0.2,1.5,by = 0.1)
myclen <- length(mycover)
mycoverrate95 <- matrix(data = 0,nrow = myclen, ncol = itnumlen)
mycoverrate50 <- matrix(data = 0,nrow = myclen, ncol = itnumlen)
trocoverrate95 <- matrix(data = 0,nrow = itnumlen, ncol = 1)
trocoverrate50 <- matrix(data = 0,nrow = itnumlen, ncol = 1)

Ciwidth5 <- matrix(data = 0,nrow = myclen, ncol = 1)
Ciupper5 <- matrix(data = 0,nrow = myclen, ncol = 1)

Ciwidth10 <- matrix(data = 0,nrow = myclen, ncol = 1)
Ciupper10 <- matrix(data = 0,nrow = myclen, ncol = 1)

Ciwidth15 <- matrix(data = 0,nrow = myclen, ncol = 1)
Ciupper15 <- matrix(data = 0,nrow = myclen, ncol = 1)

Ciwidth20 <- matrix(data = 0,nrow = myclen, ncol = 1)
Ciupper20 <- matrix(data = 0,nrow = myclen, ncol = 1)

Ciwidth25 <- matrix(data = 0,nrow = myclen, ncol = 1)
Ciupper25 <- matrix(data = 0,nrow = myclen, ncol = 1)

Ciwidth30 <- matrix(data = 0,nrow = myclen, ncol = 1)
Ciupper30 <- matrix(data = 0,nrow = myclen, ncol = 1)

Ciwidthtr <- matrix(data = 0,nrow = itnumlen, ncol = 1)
Ciuppertr <- matrix(data = 0,nrow = itnumlen, ncol = 1)

Ciwidthtr50 <- matrix(data = 0,nrow = itnumlen, ncol = 1)

Ci50width5 <- matrix(data = 0,nrow = myclen, ncol = 1)
Ci50upper5 <- matrix(data = 0,nrow = myclen, ncol = 1)

Ci50width10 <- matrix(data = 0,nrow = myclen, ncol = 1)
Ci50upper10 <- matrix(data = 0,nrow = myclen, ncol = 1)

Ci50width15 <- matrix(data = 0,nrow = myclen, ncol = 1)
Ci50upper15 <- matrix(data = 0,nrow = myclen, ncol = 1)

Ci50width20 <- matrix(data = 0,nrow = myclen, ncol = 1)
Ci50upper20 <- matrix(data = 0,nrow = myclen, ncol = 1)

Ci50width25 <- matrix(data = 0,nrow = myclen, ncol = 1)
Ci50upper25 <- matrix(data = 0,nrow = myclen, ncol = 1)

Ci50width30 <- matrix(data = 0,nrow = myclen, ncol = 1)
Ci50upper30 <- matrix(data = 0,nrow = myclen, ncol = 1)

posnow <- inipos
mypoints <- myX

sigma2 = sqrt(t(as.matrix(GPdraw[inipos]))%*%solve(PhiEval[inipos,inipos]+ 1e-11* diag(desnum),as.matrix(GPdraw[inipos]),tol = 0)/desnum)


for(j in 1:itmax){
  fHat <- as.matrix(PhiEval[,posnow])%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum-1+j),myY,tol = 0)
  curmaxf <- max(fHat)
  sigmax <- matrix(1:n1,ncol = 1)

  for(xnum in 1:n1){
    sigmax[xnum] <- sigma2 * sqrt(1 - PhiEval[xnum,posnow]%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum-1+j),PhiEval[posnow,xnum],tol = 0))
  }
  ## calculate GPUCB
  fei <- 1:n1
  for(p in 1:n1){
    myttt <- sqrt(log(16/0.05))
    temp <- sqrt(2 * log(j^2*2*pi^2/(3*0.05)) + 4*log(j^2*2*myttt))
    fei[p] <- fHat[p] + sigmax[p]*temp
  }
  curmpos <- which.max(fei)
  mypoints <- c(mypoints,myPreX[curmpos])
  myY <- c(myY,GPdraw[curmpos])
  posnow <- c(posnow,curmpos)
  print(j)
  ## save data j=5
  if(j == 5){
    ## last calculation
    fHat <- as.matrix(PhiEval[,posnow])%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),myY,tol = 0)
    curmaxf <- max(fHat)
    sigmax <- matrix(1:n1,ncol = 1)
    for(xnum in 1:n1){
      sigmax[xnum] <- sigma2 * sqrt(1 - PhiEval[xnum,posnow]%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),PhiEval[posnow,xnum],tol = 0))
    }
    
    ## cover?
    gpmaxpos <- which.max(GPdraw)
    temp4 <- max(fHat + sigmax* 1.64)
    Ciwidthtr[1] <- temp4 - max(myY)
    Ciuppertr[1] <- temp4
    Ciwidthtr50[1] <- max(fHat) - max(myY)
    if(GPdraw[gpmaxpos] < temp4){
      trocoverrate95[1] <- trocoverrate95[1] + 1
    }
    temp5 <- max(fHat)
    if(GPdraw[gpmaxpos] < temp5){
      trocoverrate50[1] <- trocoverrate50[1] + 1
    }
    for(k in 1:myclen){
      temp1 <- max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.5)*2)))
      temp2 <- max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.05)*2)))
      Ciwidth5[k] <- temp2 - max(myY)
      Ciupper5[k] <- temp2
      Ci50width5[k] <- temp1 - max(myY)
      Ci50upper5[k] <- temp1
      if(GPdraw[gpmaxpos] < temp1){
        mycoverrate50[k,1] <- mycoverrate50[k,1] + 1
      }
      if(GPdraw[gpmaxpos] < temp2){
        mycoverrate95[k,1] <- mycoverrate95[k,1] + 1
      }
      # print(temp1 - max(fHat))
      # print(temp4 - max(fHat))
      # print(temp1-temp4)
    }
    
  }
  ## save data j=10
  if(j == 10){
    ## last calculation
    fHat <- as.matrix(PhiEval[,posnow])%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),myY,tol = 0)
    curmaxf <- max(fHat)
    sigmax <- matrix(1:n1,ncol = 1)
    for(xnum in 1:n1){
      sigmax[xnum] <- sigma2 * sqrt(1 - PhiEval[xnum,posnow]%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),PhiEval[posnow,xnum],tol = 0))
    }
    
    ## cover?
    gpmaxpos <- which.max(GPdraw)
    temp4 <- max(fHat + sigmax* 1.64)
    Ciwidthtr[2] <- temp4 - max(myY)
    Ciuppertr[2] <- temp4
    Ciwidthtr50[2] <- max(fHat) - max(myY)
    if(GPdraw[gpmaxpos] < temp4){
      trocoverrate95[2] <- trocoverrate95[2] + 1
    }
    temp5 <- max(fHat)
    if(GPdraw[gpmaxpos] < temp5){
      trocoverrate50[2] <- trocoverrate50[2] + 1
    }
    for(k in 1:myclen){
      temp1 <- max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.5)*2)))
      temp2 <- max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.05)*2)))
      Ciwidth10[k] <- temp2 - max(myY)
      Ciupper10[k] <- temp2
      Ci50width10[k] <- temp1 - max(myY)
      Ci50upper10[k] <- temp1
      if(GPdraw[gpmaxpos] < temp1){
        mycoverrate50[k,2] <- mycoverrate50[k,2] + 1
      }
      if(GPdraw[gpmaxpos] < temp2){
        mycoverrate95[k,2] <- mycoverrate95[k,2] + 1
      }
      # print(temp1 - max(fHat))
      # print(temp4 - max(fHat))
      # print(temp1-temp4)
    }
    
  }
  ## save data j=15
  if(j == 15){
    ## last calculation
    fHat <- as.matrix(PhiEval[,posnow])%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),myY,tol = 0)
    curmaxf <- max(fHat)
    sigmax <- matrix(1:n1,ncol = 1)
    for(xnum in 1:n1){
      sigmax[xnum] <- sigma2 * sqrt(1 - PhiEval[xnum,posnow]%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),PhiEval[posnow,xnum],tol = 0))
    }
    
    ## cover?
    gpmaxpos <- which.max(GPdraw)
    temp4 <- max(fHat + sigmax* 1.64)
    Ciwidthtr[3] <- temp4 - max(myY)
    Ciuppertr[3] <- temp4
    Ciwidthtr50[3] <- max(fHat) - max(myY)
    if(GPdraw[gpmaxpos] < temp4){
      trocoverrate95[3] <- trocoverrate95[3] + 1
    }
    temp5 <- max(fHat)
    if(GPdraw[gpmaxpos] < temp5){
      trocoverrate50[3] <- trocoverrate50[3] + 1
    }
    for(k in 1:myclen){
      temp1 <- max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.5)*2)))
      temp2 <- max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.05)*2)))
      Ciwidth15[k] <- temp2 - max(myY)
      Ciupper15[k] <- temp2
      Ci50width15[k] <- temp1 - max(myY)
      Ci50upper15[k] <- temp1
      if(GPdraw[gpmaxpos] < temp1){
        mycoverrate50[k,3] <- mycoverrate50[k,3] + 1
      }
      if(GPdraw[gpmaxpos] < temp2){
        mycoverrate95[k,3] <- mycoverrate95[k,3] + 1
      }
      # print(temp1 - max(fHat))
      # print(temp4 - max(fHat))
      # print(temp1-temp4)
    }
    
  }
  ## save data j=20
  if(j == 20){
    ## last calculation
    fHat <- as.matrix(PhiEval[,posnow])%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),myY,tol = 0)
    curmaxf <- max(fHat)
    sigmax <- matrix(1:n1,ncol = 1)
    for(xnum in 1:n1){
      sigmax[xnum] <- sigma2 * sqrt(1 - PhiEval[xnum,posnow]%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),PhiEval[posnow,xnum],tol = 0))
    }
    
    ## cover?
    gpmaxpos <- which.max(GPdraw)
    temp4 <- max(fHat + sigmax* 1.64)
    Ciwidthtr[4] <- temp4 - max(myY)
    Ciuppertr[4] <- temp4
    Ciwidthtr50[4] <- max(fHat) - max(myY)
    if(GPdraw[gpmaxpos] < temp4){
      trocoverrate95[4] <- trocoverrate95[4] + 1
    }
    temp5 <- max(fHat)
    if(GPdraw[gpmaxpos] < temp5){
      trocoverrate50[4] <- trocoverrate50[4] + 1
    }
    for(k in 1:myclen){
      temp1 <- max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.5)*2)))
      temp2 <- max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.05)*2)))
      Ciwidth20[k] <- temp2 - max(myY)
      Ciupper20[k] <- temp2
      Ci50width20[k] <- temp1 - max(myY)
      Ci50upper20[k] <- temp1
      if(GPdraw[gpmaxpos] < temp1){
        mycoverrate50[k,4] <- mycoverrate50[k,4] + 1
      }
      if(GPdraw[gpmaxpos] < temp2){
        mycoverrate95[k,4] <- mycoverrate95[k,4] + 1
      }
      # print(temp1 - max(fHat))
      # print(temp4 - max(fHat))
      # print(temp1-temp4)
    }
    
  }
  ## save data j=25
  if(j == 25){
    ## last calculation
    fHat <- as.matrix(PhiEval[,posnow])%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),myY,tol = 0)
    curmaxf <- max(fHat)
    sigmax <- matrix(1:n1,ncol = 1)
    for(xnum in 1:n1){
      sigmax[xnum] <- sigma2 * sqrt(1 - PhiEval[xnum,posnow]%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),PhiEval[posnow,xnum],tol = 0))
    }
    
    ## cover?
    gpmaxpos <- which.max(GPdraw)
    temp4 <- max(fHat + sigmax* 1.64)
    Ciwidthtr[5] <- temp4 - max(myY)
    Ciuppertr[5] <- temp4
    Ciwidthtr50[5] <- max(fHat) - max(myY)
    if(GPdraw[gpmaxpos] < temp4){
      trocoverrate95[5] <- trocoverrate95[5] + 1
    }
    temp5 <- max(fHat)
    if(GPdraw[gpmaxpos] < temp5){
      trocoverrate50[5] <- trocoverrate50[5] + 1
    }
    for(k in 1:myclen){
      temp1 <- max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.5)*2)))
      temp2 <- max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.05)*2)))
      Ciwidth25[k] <- temp2 - max(myY)
      Ciupper25[k] <- temp2
      Ci50width25[k] <- temp1 - max(myY)
      Ci50upper25[k] <- temp1
      if(GPdraw[gpmaxpos] < temp1){
        mycoverrate50[k,5] <- mycoverrate50[k,5] + 1
      }
      if(GPdraw[gpmaxpos] < temp2){
        mycoverrate95[k,5] <- mycoverrate95[k,5] + 1
      }
      # print(temp1 - max(fHat))
      # print(temp4 - max(fHat))
      # print(temp1-temp4)
    }
    
  }
  ## save data j=30
  if(j == 30){
    ## last calculation
    fHat <- as.matrix(PhiEval[,posnow])%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),myY,tol = 0)
    curmaxf <- max(fHat)
    sigmax <- matrix(1:n1,ncol = 1)
    for(xnum in 1:n1){
      sigmax[xnum] <- sigma2 * sqrt(1 - PhiEval[xnum,posnow]%*%solve(PhiEval[posnow,posnow]+ 1e-11* diag(desnum+j),PhiEval[posnow,xnum],tol = 0))
    }
    
    ## cover?
    gpmaxpos <- which.max(GPdraw)
    temp4 <- max(fHat + sigmax* 1.64)
    Ciwidthtr[6] <- temp4 - max(myY)
    Ciuppertr[6] <- temp4
    Ciwidthtr50[6] <- max(fHat) - max(myY)
    if(GPdraw[gpmaxpos] < temp4){
      trocoverrate95[6] <- trocoverrate95[6] + 1
    }
    temp5 <- max(fHat)
    if(GPdraw[gpmaxpos] < temp5){
      trocoverrate50[6] <- trocoverrate50[6] + 1
    }
    for(k in 1:myclen){
      temp1 <- max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.5)*2)))
      temp2 <- max(fHat + sigmax * sqrt(log(exp(1)/sigmax)) * (mycover[k]*sqrt(2) * sqrt(max(1,log(A0D))) + sqrt(-log(0.05)*2)))
      Ciwidth30[k] <- temp2 - max(myY)
      Ciupper30[k] <- temp2
      Ci50width30[k] <- temp1 - max(myY)
      Ci50upper30[k] <- temp1
      if(GPdraw[gpmaxpos] < temp1){
        mycoverrate50[k,6] <- mycoverrate50[k,6] + 1
      }
      if(GPdraw[gpmaxpos] < temp2){
        mycoverrate95[k,6] <- mycoverrate95[k,6] + 1
      }
      # print(temp1 - max(fHat))
      # print(temp4 - max(fHat))
      # print(temp1-temp4)
    }
    
  }
}

print(mycoverrate95)
print(trocoverrate95)
print(Ciuppertr)

plot(myPreX,GPdraw,col=2,type = "l")
points(myPreX[posnow],GPdraw[posnow])

