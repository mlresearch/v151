import numpy as np
import matplotlib
matplotlib.rcParams['pdf.fonttype'] = 42
matplotlib.rcParams['ps.fonttype'] = 42
import matplotlib.pyplot as plt
import pickle as pk
import scipy.stats as stats
"""parameters"""
epoches = 22
geometrical_factor = 2**(1/3)
start_point = 512
rounds = 20
d = 2
linewidth = 2
linewidth_asymptote = 1
linecolor = "m"
linecolor_asymptote = "gray"
linestyle = "-"
linestyle_asymptote = "dotted"
marker = "."
capsize = 3
font_size_label = 20
font_size_legend = 10  # originally 15
font_size_caption = 15
transparency = 0.1


"""open the file"""
with open("linearExp4_d=%d, epoch=%d, start=%d, geometrical_factor=%f, rounds=%d"
          % (d, epoches, start_point, geometrical_factor, rounds), "rb") as data_to_be_plot:
    data_linearexp4 = pk.load(data_to_be_plot)
"""create index list"""
index_list = [int(start_point* (geometrical_factor**i_epoch)) for i_epoch in range(epoches)]
"""create average list"""
average_list = np.sum(data_linearexp4, axis=1)/rounds
"""create error bar"""
error_bar_exp4 = np.zeros((2, epoches))
for i_epoch in range(epoches):
    error_bar_exp4[0, i_epoch] = average_list[i_epoch] - min(iy for iy in np.ndarray.tolist(data_linearexp4[i_epoch, :]))
    error_bar_exp4[1, i_epoch] = -average_list[i_epoch]+ max(iy for iy in np.ndarray.tolist(data_linearexp4[i_epoch, :]))
error_bar_exp4 = error_bar_exp4 *1.96/np.sqrt(rounds)
"""log-log linear regression"""
log_index_list = [np.log2(x) for x in index_list]
log_regret_list = [np.log2(y) for y in average_list]
slope_le, intercept_le, r_value_le, p_value_le, std_err_le = stats.linregress(log_index_list, log_regret_list)
asymptote_array_le = np.array([2 ** (slope_le * np.log2(x) + intercept_le) for x in range(start_point, int(start_point* (geometrical_factor**epoches)))])



"""plotting the curve"""
plt.plot(index_list, average_list, color=linecolor,
         linestyle=linestyle, marker=marker, linewidth=linewidth)
"""plotting the errorbar"""
plt.errorbar(index_list, average_list, yerr=error_bar_exp4, color=linecolor, linestyle=linestyle,
             marker=marker, linewidth=linewidth, mec=linecolor, mfc=linecolor, capsize=capsize)
"""linear regression and plotting the linear fit"""
plt.plot(np.arange(start_point, int(start_point* (geometrical_factor**epoches))), asymptote_array_le, color=linecolor_asymptote,
         linestyle=linestyle_asymptote, linewidth=linewidth_asymptote)
print("Linear-EXP4 log-linear regression (stochastic): log_2(y) = ", slope_le, "log_2(x)+", intercept_le, " .")
print("Linear-EXP4 sto R^2 = ", r_value_le ** 2, " .")
"""output diagram"""
label=["Linear-EXP4", "linear fit, slope=%f" % slope_le]
plt.xscale('log', base=2)
plt.yscale('log', base=2)
plt.grid(True)
plt.xlabel('T', fontsize=font_size_label)
plt.ylabel('regret', fontsize=font_size_label)
plt.legend(label, loc='upper left', fontsize = font_size_legend)
plt.savefig("./ linearExp4_d=%d, epoch=%d, start=%d, geometrical_factor=%f, rounds=%d .pdf"
            % (d, epoches, start_point, geometrical_factor, rounds), bbox_inches='tight')
plt.show()


