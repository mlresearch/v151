from PreferentialGP.skew_symmetric_kernel import SkewKernel
import sys
sys.path.append("../spektrankle/src/")

import Experiments as EXP
import torch

if __name__ == '__main__':
    C_train, comp_ls, C_test, features, K = EXP.NFL(1., 3.)

    sk = SkewKernel(comp_ls, torch.tensor(features), 'rbf')
    T = sk.fit_kernel()

    # set up random noise
    w = torch.randn(T.shape[0])
    v = torch.randn(T.shape[0])

    loss_fn = torch.nn.MSELoss()
    opt = torch.optim.Adam(sk.kernel.parameters(), lr=1e-1)

    epoch = 5
    for rd in range(epoch):
        T = sk.fit_kernel()
        embedding = T @ w
        loss = loss_fn(v, embedding)
        print(loss)

        loss.backward(retain_graph=True)
        opt.step()
        opt.zero_grad()
