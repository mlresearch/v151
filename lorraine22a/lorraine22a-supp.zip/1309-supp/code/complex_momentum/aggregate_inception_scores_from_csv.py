"""
Example
-------
python aggregate_inception_scores_from_csv.py
"""
import os
import csv
import ipdb
import numpy as np
import pickle as pkl

import matplotlib.pyplot as plt
import seaborn as sns
sns.set_style('whitegrid')
sns.set_palette('bright')

base_dir = 'samples_np'

exp_folders = os.listdir(base_dir)
for exp_folder in exp_folders:
    print('='*80)
    print('Processing {}...'.format(exp_folder))
    print('='*80)

    performance_dict = {}
    num_folders_with_inception_scores = 0  # Keeps track of how many subfolders have the inception_score.csv file

    exp_path = os.path.join(base_dir, exp_folder)
    numbered_subfolders = os.listdir(exp_path)  # Gives us a list of numbered subfolders like [2000, 4000, 6000, ...]
    for subfolder in numbered_subfolders:
        subfolder_path = os.path.join(base_dir, exp_folder, subfolder)

        if not os.path.isdir(subfolder_path):  # Skip any paths that are not actually numbered subfolders (like .pkl files in and such)
            continue

        print('Processing SUBFOLDER {}'.format(subfolder_path))

        iteration = int(subfolder)  # Converts the folder name '20000' to an integer
        if 'inception_score.csv' in os.listdir(subfolder_path):
            num_folders_with_inception_scores += 1
            with open(os.path.join(subfolder_path, 'inception_score.csv'), newline='') as csvfile:
                reader = csv.DictReader(csvfile)
                for row in reader:
                    performance_dict[iteration] = float(row['inception_score'])
                    break

    # if num_folders_with_inception_scores == 0
    #     print('There were no inception_score.csv files found in exp_dir {}'.format(exp_dir))
    #     continue

    if num_folders_with_inception_scores > 0:
        performance_list = sorted(list(performance_dict.items()), key=lambda x: x[0])
        iterations, inception_scores = zip(*performance_list)  # Unzips the entries from [(5000, 5.6), (10000, 7.11)] to [5000, 7000], [5.6, 7.11]

        with open(os.path.join(exp_path, 'inception_scores_aggregated.pkl'), 'wb') as f:
            pkl.dump({'iterations': iterations, 'inception_scores': inception_scores}, f)

        fig = plt.figure(figsize=(8,6))
        plt.plot(iterations, inception_scores, linewidth=2)
        plt.xticks(fontsize=18)
        plt.yticks(fontsize=18)
        plt.xlabel('Iteration', fontsize=20)
        plt.ylabel('Inception Score', fontsize=20)
        plt.tight_layout()
        plt.savefig(os.path.join(exp_path, 'inception_scores.pdf'), bbox_inches='tight', pad_inches=0)
        plt.savefig(os.path.join(exp_path, 'inception_scores.png'), bbox_inches='tight', pad_inches=0)
        plt.close(fig)
    else:
        print('*'*80)
        print('SKIPPING {}'.format(subfolder_path))
        print('*'*80)
