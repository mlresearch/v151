%% Generating Speed Comparisons
% 1: ProjNewton vs. ADMM on k=1
% 2: ADMM2 vs. ADMM 1 on k=2

FLAG=1;% for exp 1
%FLAG=0; % uncomment this for exp2


%% Test script for general graph
img = imresize(imread('TVexact/lena.bmp'), 0.25);

figure(1)
imshow(img);

img1 = double(img)/255 + 0.1*randn(size(img));

figure(2)
imshow(img1);

%%

[ht, wt]    = size(img1(:, :, 1));
n           = ht * wt;
m           = 2 * n - (ht + wt);
edges1      = zeros(m, 1);
edges2      = zeros(m, 1);

%%
count         = 0;
idx           = sub2ind([ht wt], kron(ones(wt-1,1), (1:ht)'), kron((1:(wt-1))', ones(ht,1)));
sz            = length(idx);
count         = count + sz;
edges1(1: sz) = idx;

%
idx           = sub2ind([ht wt], kron(ones(wt-1, 1), (1:ht)'), kron((2:(wt))', ones(ht,1)));
edges2(1: sz) = idx;

%
idx           = sub2ind([ht wt], kron(ones(wt, 1), (1:(ht-1))'), kron((1:wt)', ones(ht-1,1)));
sz            = length(idx);
edges1(count+1: count+sz) = idx;
idx           = sub2ind([ht wt], kron(ones(wt, 1), (2:ht)'), kron((1:wt)', ones(ht-1,1)));
edges2(count+1: count+sz) = idx;

%% Setting
D = sparse((1:m)', edges1, 1, m, n, 10*m);
D = D + sparse((1:m)', edges2, -1, m, n);

lambda = 0.2;

img2   = img1;
y      = img1(:, :, 1);
y      = y(:);

k       = 5;
rho     = lambda;
w       = ones(m, 1);
mask    = rand(n, 1) > 0.9;

%% Algorithm
[~, history1, time1]  = gradbb(y, [edges1, edges2], k-1, lambda);
[~, history2, time2]  = proj_newton(y, [edges1, edges2], k-1, lambda);
[~, history3, time3]  = admm_v2(y, [edges1, edges2], k-1, lambda, rho);
[~, history4, time4]  = admm_v1(y, [edges1, edges2], k-1, lambda, rho);
        
        
% img2(:, :, 1)   = reshape(x2, [ht, wt]);

%%
h                   = figure;
cal_blue            = [0, 50, 98]/255;
cal_skyblue         = [135, 206, 235]/255;
cal_gold            = [253, 181, 21]/255;
cal_yellow          = [188, 155, 106]/255; 

hold on;
semilogy(time1', history1', 'color', cal_blue, 'linewidth', 1.5, 'markersize', 15)
semilogy(time2', history2', 'color', cal_skyblue, 'linewidth', 1.5, 'markersize', 15)
semilogy(time3', history3', 'color', cal_gold, 'linewidth', 1.5, 'markersize', 15)
semilogy(time4', history4', 'color', cal_yellow, 'linewidth', 1.5, 'markersize', 15)
    
l = legend('Specialized ProjDGA', 'ProjNewton', 'Specialized ADMM', 'ADMM');
set(l, 'fontsize', 14, 'location', 'best')
title('GTF with $k=1$')
xlabel('Clock time in second', 'fontsize', 14)
ylabel('Objective function value', 'fontsize', 14)
xlim([0, 30])
ylim([100, 200])
grid on
hold off;


