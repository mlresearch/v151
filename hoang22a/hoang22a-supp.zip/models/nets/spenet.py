from tensorflow.keras.layers import Layer
from tensorflow.keras import Input

from loaders.pairloader import *
from utils.loss import KerasLossWrapper
from utils.optimizer import *

import tensorflow.keras.backend as KB

class SPENet:
    def __init__(self, params, content_name, side_name):
        self.loss = KerasLossWrapper(params.loss)  # here goes the loss
        self.optimizer = KerasOptimizerWrapper(params.optimizer, params.learning_rate)  # here goes the optimizer
        self.learning_rate = params.learning_rate  # here goes the learning rate
        self.content_name, self.side_name = content_name, side_name

        self.id_embedding_dim = params.id_embedding_dim  # here is the dimension of the id embedding -- 1 int value -> "id_embedding_dim"-dim vector
        self.content_dim = params.feature_channels_dim[content_name]
        self.side_dim = params.feature_channels_dim[side_name]

        self.feature_channel_dims = params.feature_channels_dim  # here is the map from channel name to feature-dim of that channel
        self.hidden_dim = params.hidden_dim  # here is the hidden dim used in the feature embedding network segment: feature-dim --> 2 * hidden-dim --> hidden-dim

        self.no_item, self.no_user = params.no_item, params.no_user  # no. of unique items and users
        self.encoder = self.build_encoder()
        self.tower = self.build_tower()
        self.model = self.build_network()

    def build_encoder(self):
        content = Input(shape = self.content_dim)
        enc = K.Sequential([K.layers.Dense(4 * self.id_embedding_dim, activation = "relu", kernel_regularizer = K.regularizers.l2(0.01),
                                           bias_regularizer = K.regularizers.l2(0.01)),
                            K.layers.Dense(2 * self.id_embedding_dim, activation = "relu",
                                           kernel_regularizer = K.regularizers.l2(0.01), bias_regularizer = K.regularizers.l2(0.01)),
                            K.layers.Dense(self.id_embedding_dim, activation = 'sigmoid', kernel_regularizer = K.regularizers.l2(0.01),
                                           bias_regularizer = K.regularizers.l2(0.01))])
        output = enc(content)
        return K.Model(inputs = content, outputs = output)

    def build_tower(self):
        item, content, side = Input(shape = (1,)), Input(shape = self.content_dim), Input(shape = self.side_dim)
        id_embed = K.Sequential([K.layers.Embedding(input_dim = self.no_item, output_dim = self.id_embedding_dim,
                                                    input_length = 1, embeddings_regularizer = K.regularizers.l2(0.01)), K.layers.Flatten()])
        delta = K.Sequential([K.layers.Dense(1, activation = "sigmoid")])
        Z, E, w = id_embed(item), self.encoder(content), delta(side)
        V = w * Z + (1.0 - w) * E
        return K.Model(inputs = [item, content, side], outputs = V)

    def build_network(self):
        item_A, item_B = Input(shape = (1,)), Input(shape = (1,))  # here are the placeholders of the item ids
        content_A, content_B = Input(shape = self.content_dim), Input(shape = self.content_dim)
        side_A, side_B = Input(shape = self.side_dim), Input(shape = self.side_dim)

        Va, Vb = self.tower([item_A, content_A, side_A]), self.tower([item_B, content_B, side_B])
        output = 1.0 / (1.0 + KB.exp(-1.0 * KB.sum(Va * Vb, axis = 1)))
        return K.Model(inputs = [item_A, content_A, side_A, item_B, content_B, side_B], outputs = output)

    def compile_network(self, verbal = True):  # compile the created model
        if self.model is not None:
            self.model.compile(loss = self.loss.loss, optimizer = self.optimizer.optimizer, metrics = ['accuracy'])
            if verbal:
                self.model.summary()  # print out a summary of model architecture
        else:
            print("ERROR: Model has NOT been constructed.")
