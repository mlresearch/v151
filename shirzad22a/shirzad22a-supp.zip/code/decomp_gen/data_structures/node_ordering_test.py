import numpy as np
import networkx as nx
import matplotlib.pyplot as plt
import os
import pickle

from decomp_gen.data_structures.graph import superNode, DecompositionTree, Graph
from decomp_gen.data_structures.dataset import GraphDataset
from decomp_gen import configs

def hash_tree(bags):
    #bags is a list of sets, set of nodes for each cluster consequtively

    hashed_bags = []
    for bag in bags:
        hashed_bags.append(hash(frozenset(bag)))

    return hash(tuple(hashed_bags))

def random_reorder(G):
    p = np.random.permutation(G.number_of_nodes())
    Gp = nx.from_numpy_array(nx.to_numpy_matrix(G, nodelist=p))

    mapping = {}
    for i, pi in enumerate(p):
        mapping[pi] = i

    return Gp, p, mapping

def change_back_mapping(bags, mapping):
    new_bags = []

    for bag in bags:
        new_bag = set()
        for node in bag:
            new_bag.add(mapping[node])
        new_bags.append(new_bag)

    return new_bags

def check_equality_of_clusters(sub_graphs1, sub_graphs2):
    if len(sub_graphs1) != len(sub_graphs2):
        return False

    for i in range(len(sub_graphs1)):
        if not nx.is_isomorphic(sub_graphs1[i], sub_graphs2[i]):
            return False

    return True

def main():

    #hashing tests:
    # test = [set([1,2,3]), set([3,4,5])]
    # print(hash_tree(test))


    data_name = 'community_small'

    data = GraphDataset(data_name, data_name+'.dat')

    # data = GraphDataset('citeseer_small', 'citeseer_small.dat')

    graph = data[3]
    G = graph.G

    Gp, p, mapping = random_reorder(G)

    print('is isomorphic: ', nx.is_isomorphic(G, Gp))


    # nx.draw(G, with_labels=True)
    # plt.show()
    #
    # G, p, mapping = random_reorder(G)
    # nx.draw(G, with_labels=True)
    # plt.show()



    # dt = set()
    # T = 5
    # for ii in range(T):
    #     Gp, p, mapping = random_reorder(G)
    #     GpGraph = Graph(nxGraph=Gp)
    #     bags = GpGraph.super_node_initial_nodes()
    #     print('bags: ', bags)
    #     original_label_bags = change_back_mapping(bags, mapping)
    #     print('original_label_bags: ', original_label_bags)
    #     h = hash_tree(original_label_bags)
    #     if h not in dt:
    #         # print('len of bags: ', len(bags))
    #         dt.add(h)
    #
    #
    # print('number of nodes of G:', G.number_of_nodes())
    # print('len set:', len(dt))


    diff_perms_stats = []


    for gg in data:
        G = gg.G
        different_clusterings = []
        cnt = [1]
        different_clusterings.append(graph.get_cluster_subgraphs())
        T = 1000
        for ii in range(T):
            Gp, p, mapping = random_reorder(G)
            GpGraph = Graph(nxGraph=Gp)
            sub_graphs = GpGraph.get_cluster_subgraphs()
            is_unique = True
            for jj, unique_sub_graphs in enumerate(different_clusterings):
                if check_equality_of_clusters(sub_graphs, unique_sub_graphs):
                    is_unique = False
                    cnt[jj] += 1
                    break
            if is_unique:
                different_clusterings.append(sub_graphs)
                cnt.append(1)

        # print('number of nodes of G:', G.number_of_nodes())
        print('len set:', len(different_clusterings))
        # print('cnt: ', cnt)

        diff_perms_stats.append(len(different_clusterings))

    dir = os.path.join(configs.root_dir, 'data', 'stats')
    os.makedirs(dir, exist_ok=True)
    dir = os.path.join(dir, data_name + '_perm_stats')

    with open(dir, "wb") as f:
        pickle.dump(diff_perms_stats, f)



if __name__ == "__main__":
    main()