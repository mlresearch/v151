from ocim import Ocim

import numpy as np
import networkx as nx
import matplotlib.pyplot as plt
from datetime import date
import os
import concurrent.futures
import time
from scipy.special import comb
from igraph import *

import time
from cProfile import Profile
from pstats import Stats

import matplotlib
#
# matplotlib.use('TkAgg')

matplotlib.rcParams['text.usetex'] = True
matplotlib.rcParams['font.size'] = 13
matplotlib.rcParams['font.serif'] = 'Helvetica'

matplotlib.rcParams['font.weight'] = 'bold'

matplotlib.rcParams['axes.labelweight'] = 'bold'
matplotlib.rcParams['axes.labelsize'] = 'large'

matplotlib.rcParams['legend.fontsize'] = 'large'

matplotlib.rcParams['axes.titleweight'] = 'bold'
matplotlib.rcParams['text.latex.preamble'] = [r'\usepackage{sfmath} \boldmath']

matplotlib.rcParams['xtick.labelsize'] = 'large'
matplotlib.rcParams['ytick.labelsize'] = 'large'

matplotlib.rcParams['lines.markersize'] = 10.0

plt.ticklabel_format(style='sci', axis='y', scilimits=(0, 3))
plt.ticklabel_format(style='sci', axis='x')

print(matplotlib.rcParams.keys())

# for debug
# np.random.seed(0)


class GeneralGraphExp(Ocim):

    def __init__(self, t_MC=1000, k_A=10, k_B=10, epsilon=0.5, l=1, S_B_type='max', T=1000,
                 oracle='IMM', G_type='real', tb_AB=1, lcb=True, exp_id=0):
        super(GeneralGraphExp, self).__init__()
        self.build_graph()
        self.T = T
        self.k_A = k_A
        self.k_B = k_B
        self.t_MC = t_MC
        self.oracle = oracle
        self.G_type = G_type
        self.tb_AB = tb_AB
        self.lcb = lcb
        self.dir = f'result/{date.today().isoformat()}'
        if not os.path.isdir(self.dir):
            os.mkdir(self.dir)
        self.log_file = f'{self.dir}/{self.oracle}_{self.G_type}_{self.n}_{self.m}_{self.T}'

        # IMM parameters
        self.epsilon = epsilon
        self.l = l
        self.epsilon_1 = np.sqrt(2) * self.epsilon
        self.c1 = self.n * (2 + 2 / 3 * self.epsilon_1) * \
             (np.log(comb(self.n, k_A)) + l * np.log(self.n) + np.log(2) + np.log(np.log2(self.n))) / (self.epsilon_1 ** 2)
        self.c2 = np.sqrt(l * np.log(self.n) + np.log(4)) * (1 - 1 / np.e) + np.sqrt(
            (1 - 1 / np.e) * (np.log(comb(self.n, k_A)) + l * np.log(self.n) + np.log(4)))

        # generate S_B
        if S_B_type == 'max':
            self.S_B_type = S_B_type
            self.S_B = []
            self.S_B, _ = self.IMM(self.G, self.weight, self.tb_AB)
        elif S_B_type == 'uniform':
            self.S_B_type = S_B_type
            self.S_B = list(np.random.choice(self.n, k_B, replace=False))
        self.E_B_out = []
        for node in self.S_B:
            out_e = self.G.incident(node, mode=OUT)
            self.E_B_out.extend(out_e)
        self.E_B_out = np.asarray(self.E_B_out)
        print("S_B: {}".format(self.S_B))


    def build_graph(self):
        # load graph
        self.G = Graph(n=679, directed=True)
        self.edge_list = np.loadtxt('dm_real.txt')
        self.weight = np.zeros(len(self.edge_list))
        # prior Q
        self.Q = np.zeros((len(self.edge_list), 2))
        for i in range(len(self.edge_list)):
            u = int(self.edge_list[i][0]) - 1
            v = int(self.edge_list[i][1]) - 1
            self.G.add_edge(u, v)
            self.weight[i] = self.edge_list[i][2]
            # set priors Q and regenerate weights
            self.Q[i, 0] = 5 * self.weight[i] + 0.001
            self.Q[i, 1] = 5 * (1-self.weight[i]) + 0.001
            self.weight[i] = np.random.beta(self.Q[i, 0], self.Q[i, 1])
        # Graph parameters
        self.n = len(self.G.vs)
        self.m = len(self.G.es)


    def IMM(self, G, weight, tb_AB=1):
        start_time = time.time()
        theta_j = np.zeros(int(np.log2(self.n)))
        R_save = np.empty((0, self.n))
        for j in range(int(np.log2(self.n)) - 1):
            x_j = self.n / (2 ** (j + 1))
            theta_j[j + 1] = np.ceil(self.c1 / x_j)
            theta = int(theta_j[j + 1] - theta_j[j])
            # generate theta RR sets
            S_A = np.zeros(self.k_A, dtype=np.int16)
            R = np.zeros((theta, self.n))
            for i in range(theta):
                r = np.random.randint(self.n)
                if r in self.S_B:
                    R[i, r] = tb_AB
                    continue
                R[i, r] = 1
                state = np.zeros(self.n)
                state[self.S_B] = -1
                state[r] = 1
                new_A = [r]
                reach_B = False
                while len(new_A) != 0:
                    if reach_B:
                        break
                    new_active = []
                    for node in new_A:
                        in_e = G.incident(node, mode=IN)
                        in_n = np.asarray(G.neighbors(node, mode=IN))
                        X = np.random.rand(len(in_e)) < weight[in_e]
                        new_node = in_n[X]
                        if reach_B == False and -1 in state[new_node]:
                            reach_B = True
                            if tb_AB == 0:
                                new_active = []
                                break
                        new_node = new_node[state[new_node] == 0]
                        state[new_node] = 1
                        new_active.extend(new_node)
                    new_A = new_active
                    R[i, new_A] = 1

            R_save = np.append(R_save, R, axis=0)
            n_covered = 0
            for i in range(self.k_A):
                i_max = np.argmax(np.sum(R, axis=0))
                while i_max in S_A:
                    i_max = np.random.randint(self.n)
                R_del = (R[:, i_max] == 1)
                n_covered += np.count_nonzero(R_del)
                R[R_del] = 0
                S_A[i] = i_max
            spread = n_covered / theta * self.n

            if spread >= (1 + self.epsilon_1) * x_j:
                LB = spread / (1 + self.epsilon_1)
                break

        theta_t = int(np.ceil(2 * self.n * (self.c2 ** 2) / (self.epsilon ** 2) / LB))
        theta_new = int(theta_t - R_save.shape[0])
        if theta_new > 0:
            R = np.zeros((theta_new, self.n))
            for i in range(theta_new):
                r = np.random.randint(self.n)
                if r in self.S_B:
                    R[i, r] = 0
                    continue
                R[i, r] = 1
                state = np.zeros(self.n)
                state[self.S_B] = -1
                state[r] = 1
                new_A = [r]
                reach_B = False
                while len(new_A) != 0:
                    if reach_B:
                        break
                    new_active = []
                    for node in new_A:
                        in_e = G.incident(node, mode=IN)
                        in_n = np.asarray(G.neighbors(node, mode=IN))
                        X = np.random.rand(len(in_e)) < weight[in_e]
                        new_node = in_n[X]
                        if reach_B == False and -1 in state[new_node]:
                            reach_B = True
                            if tb_AB == 0:
                                new_active = []
                                break
                        new_node = new_node[state[new_node] == 0]
                        state[new_node] = 1
                        new_active.extend(new_node)
                    new_A = new_active
                    R[i, new_A] = 1
            R_save = np.append(R_save, R, axis=0)

        R_save = R_save[0:theta_t]
        S_A = np.zeros(self.k_A, dtype=np.int16)
        n_covered = 0
        for i in range(self.k_A):
            i_max = np.argmax(np.sum(R_save, axis=0))
            while i_max in S_A:
                i_max = np.random.randint(self.n)
            R_del = (R_save[:, i_max] == 1)
            n_covered += np.count_nonzero(R_del)
            R_save[R_del] = 0
            S_A[i] = i_max
        spread = n_covered / theta_t * self.n
        print("TIME: IMM(): %s seconds" % (time.time() - start_time))
        return S_A, spread

    def cal_inf(self, G, S_A, tb_AB=1):
        start_time = time.time()
        spread = []
        for i in range(self.t_MC):
            state = np.zeros(self.n)
            state[self.S_B] = -1
            state[S_A] = 1
            inf_A = len(S_A)
            new_A = S_A
            new_B = self.S_B
            if tb_AB == 1:
                while len(new_A) != 0:
                    new_active = []
                    for node in new_A:
                        out_e = G.incident(node, mode=OUT)
                        out_n = G.neighbors(node, mode=OUT)
                        X = np.random.rand(len(out_e)) < self.weight[out_e]
                        new_node = np.extract(X, out_n)
                        new_node = new_node[state[new_node] == 0]
                        state[new_node] = 1
                        new_active.extend(new_node)
                    new_A = new_active
                    inf_A += len(new_A)

                    new_active = []
                    for node in new_B:
                        out_e = G.incident(node, mode=OUT)
                        out_n = G.neighbors(node, mode=OUT)
                        X = np.random.rand(len(out_e)) < self.weight[out_e]
                        new_node = np.extract(X, out_n)
                        new_node = new_node[state[new_node] == 0]
                        state[new_node] = -1
                        new_active.extend(new_node)
                    new_B = new_active
                spread.append(inf_A)
            else:
                while len(new_A) != 0:
                    new_active = []
                    for node in new_B:
                        out_e = G.incident(node, mode=OUT)
                        out_n = G.neighbors(node, mode=OUT)
                        X = np.random.rand(len(out_e)) < self.weight[out_e]
                        new_node = np.extract(X, out_n)
                        new_node = new_node[state[new_node] == 0]
                        state[new_node] = -1
                        new_active.extend(new_node)
                    new_B = new_active

                    new_active = []
                    for node in new_A:
                        out_e = G.incident(node, mode=OUT)
                        out_n = G.neighbors(node, mode=OUT)
                        X = np.random.rand(len(out_e)) < self.weight[out_e]
                        new_node = np.extract(X, out_n)
                        new_node = new_node[state[new_node] == 0]
                        state[new_node] = 1
                        new_active.extend(new_node)
                    new_A = new_active
                    inf_A += len(new_A)
                spread.append(inf_A)
        print("TIME: cal_inf(): %s seconds" % (time.time() - start_time))
        return np.mean(spread)

    def TS(self, log_ind=0, write_per_step=1):
        start_time = time.time()


        # generate random seed
        np.random.seed(log_ind)
        cum_reg = 0.0
        f_write = open(f'{self.log_file}_Bayes_ep_0.0_er_ts_tb_{self.tb_AB}_lcb_{self.lcb}_{self.S_B_type}_{log_ind}', 'w')

        Q_beta = self.Q

        inf_t = np.zeros(self.T)
        state = np.zeros(self.n)
        X_i = np.zeros(self.m)
        trig_i = np.zeros(self.m, dtype=bool)

        S_A_opt, opt_IMM = self.IMM(self.G, self.weight, self.tb_AB)
        opt_cal = self.cal_inf(self.G, S_A_opt, self.tb_AB)
        print("optiaml S_A: {}".format(S_A_opt))
        print("optiaml reward: {}".format(opt_cal))

        for t in range(self.T):
            start_round = time.time()

            print('----- round {} -----'.format(t))
            t0 = time.time()
            inf_max = 0

            # find S_A
            mu_t = np.random.beta(Q_beta[:, 0], Q_beta[:, 1])
            S_A, _ = self.IMM(self.G, mu_t, self.tb_AB)

            print(f'S_A: {S_A}')
            # IC
            X_i[:] = 0
            trig_i[:] = False
            state[:] = 0
            state[self.S_B] = -1
            state[S_A] = 1
            new_A = S_A
            new_B = self.S_B
            if self.tb_AB == 0:
                while len(new_A) != 0 or len(new_B) != 0:
                    new_active = []
                    for node in new_B:
                        out_e = self.G.incident(node, mode=OUT)
                        out_n = np.asarray(self.G.neighbors(node, mode=OUT))
                        X = np.random.rand(len(out_e)) < self.weight[out_e]
                        trig_i[out_e] = True
                        X_i[out_e] = X
                        new_node = out_n[X]
                        new_node = new_node[state[new_node] == 0]
                        state[new_node] = -1
                        new_active.extend(new_node)
                    new_B = new_active

                    new_active = []
                    for node in new_A:
                        out_e = self.G.incident(node, mode=OUT)
                        out_n = np.asarray(self.G.neighbors(node, mode=OUT))
                        X = np.random.rand(len(out_e)) < self.weight[out_e]
                        trig_i[out_e] = True
                        X_i[out_e] = X
                        new_node = out_n[X]
                        new_node = new_node[state[new_node] == 0]
                        state[new_node] = 1
                        new_active.extend(new_node)
                    new_A = new_active
            else:
                while len(new_A) != 0 or len(new_B) != 0:
                    new_active = []
                    for node in new_A:
                        out_e = self.G.incident(node, mode=OUT)
                        out_n = np.asarray(self.G.neighbors(node, mode=OUT))
                        X = np.random.rand(len(out_e)) < self.weight[out_e]
                        trig_i[out_e] = True
                        X_i[out_e] = X
                        new_node = out_n[X]
                        new_node = new_node[state[new_node] == 0]
                        state[new_node] = 1
                        new_active.extend(new_node)
                    new_A = new_active

                    new_active = []
                    for node in new_B:
                        out_e = self.G.incident(node, mode=OUT)
                        out_n = np.asarray(self.G.neighbors(node, mode=OUT))
                        X = np.random.rand(len(out_e)) < self.weight[out_e]
                        trig_i[out_e] = True
                        X_i[out_e] = X
                        new_node = out_n[X]
                        new_node = new_node[state[new_node] == 0]
                        state[new_node] = -1
                        new_active.extend(new_node)
                    new_B = new_active

            Q_beta[trig_i, 0] = Q_beta[trig_i, 0] + X_i[trig_i]
            Q_beta[trig_i, 1] = Q_beta[trig_i, 1] + 1 - X_i[trig_i]

            # # not sure the reason of self.t_MC *= 10. I just assume etc=0, so keep self.t_MC *= 10
            # if t == etc:
            #     self.t_MC *= 10

            inf_t[t] = self.cal_inf(self.G, S_A)
            # record reward for etc
            reward_continue = inf_t[t]
            print('round {}: {} seconds'.format(t, time.time() - t0, inf_t[t]))
            print('expected reward: {}'.format(inf_t[t]))
            cum_reg += opt_cal - inf_t[t]
            if t % write_per_step == 0:
                f_write.write(f'{t} {inf_t[t]} {opt_cal - inf_t[t]} {cum_reg}\n')
            end_round = time.time()
            print(f"time: {end_round-start_round}")
        end_time = time.time()
        print(f"total time: {end_time-start_time}, avg_time: {(end_time-start_time)/self.T}")
        reg_t = opt_cal - inf_t
        return reg_t

    def cucb(self, explore_ratio=1., ep_greedy=0., etc=0, log_ind=0, write_per_step=1):
        start_time = time.time()

        # generate random seed
        np.random.seed(log_ind)
        cum_reg = 0.0
        if etc == 0:
            f_write = open(f'{self.log_file}_Bayes_ep_{ep_greedy}_er_{explore_ratio}_tb_{self.tb_AB}_lcb_{self.lcb}_{self.S_B_type}_{log_ind}', 'w')
        else:
            f_write = open(f'{self.log_file}_ep_{ep_greedy}_er_{explore_ratio}_etc_{etc}_tb_{self.tb_AB}_lcb_{self.lcb}_{self.S_B_type}_{log_ind}', 'w')

        er = explore_ratio  # coefficient of rho
        ep = ep_greedy  # epsilon greedy

        mu_hat = np.ones(self.m)
        mu_hat[self.E_B_out] = 0
        rho = np.ones(self.m)
        T_i = np.zeros(self.m)
        inf_t = np.zeros(self.T)
        state = np.zeros(self.n)
        X_i = np.zeros(self.m)
        trig_i = np.zeros(self.m, dtype=bool)

        S_A_opt, opt_IMM = self.IMM(self.G, self.weight, self.tb_AB)
        opt_cal = self.cal_inf(self.G, S_A_opt, self.tb_AB)
        print("optiaml S_A: {}".format(S_A_opt))
        print("optiaml reward: {}".format(opt_cal))

        for t in range(self.T):
            start_round = time.time()

            print('----- round {} -----'.format(t))
            t0 = time.time()
            inf_max = 0

            # find S_A

            if etc == 0:
                if np.random.rand() > ep:
                    mu_t = np.clip(mu_hat + er * rho, a_min=0, a_max=1)  # UCB
                    if self.lcb:
                        mu_t[self.E_B_out] = np.clip(mu_hat[self.E_B_out] - er * rho[self.E_B_out], a_min=0, a_max=1)  # LCB
                    S_A, _ = self.IMM(self.G, mu_t, self.tb_AB)
                else:
                    S_A = np.random.choice(self.n, self.k_A, replace=False)
            else:
                if t < etc:
                    S_A = np.array([(t * self.k_A + a) % self.n for a in range(self.k_A)])
                    # S_A = np.random.choice(self.n, self.k_A, replace=False)
                elif t == etc:
                    mu_t = np.clip(mu_hat + er * rho, a_min=0, a_max=1)  # UCB
                    if self.lcb:
                        mu_t[self.E_B_out] = np.clip(mu_hat[self.E_B_out] - er * rho[self.E_B_out], a_min=0, a_max=1)  # LCB
                    S_A_continue, _ = self.IMM(self.G, mu_t, self.tb_AB)
                    S_A = S_A_continue
                else:
                    S_A = S_A_continue
                    inf_t[t] = reward_continue
                    print('round {}: {} seconds'.format(t, time.time() - t0, inf_t[t]))
                    print('expected reward: {}'.format(inf_t[t]))
                    cum_reg += opt_cal - inf_t[t]
                    f_write.write(f'{t} {inf_t[t]} {opt_cal - inf_t[t]} {cum_reg}\n')
                    continue
            print(f'S_A: {S_A}')
            # IC
            X_i[:] = 0
            trig_i[:] = False
            state[:] = 0
            state[self.S_B] = -1
            state[S_A] = 1
            new_A = S_A
            new_B = self.S_B
            if self.tb_AB == 0:
                while len(new_A) != 0 or len(new_B) != 0:
                    new_active = []
                    for node in new_B:
                        out_e = self.G.incident(node, mode=OUT)
                        out_n = np.asarray(self.G.neighbors(node, mode=OUT))
                        X = np.random.rand(len(out_e)) < self.weight[out_e]
                        trig_i[out_e] = True
                        X_i[out_e] = X
                        new_node = out_n[X]
                        new_node = new_node[state[new_node] == 0]
                        state[new_node] = -1
                        new_active.extend(new_node)
                    new_B = new_active

                    new_active = []
                    for node in new_A:
                        out_e = self.G.incident(node, mode=OUT)
                        out_n = np.asarray(self.G.neighbors(node, mode=OUT))
                        X = np.random.rand(len(out_e)) < self.weight[out_e]
                        trig_i[out_e] = True
                        X_i[out_e] = X
                        new_node = out_n[X]
                        new_node = new_node[state[new_node] == 0]
                        state[new_node] = 1
                        new_active.extend(new_node)
                    new_A = new_active
            else:
                while len(new_A) != 0 or len(new_B) != 0:
                    new_active = []
                    for node in new_A:
                        out_e = self.G.incident(node, mode=OUT)
                        out_n = np.asarray(self.G.neighbors(node, mode=OUT))
                        X = np.random.rand(len(out_e)) < self.weight[out_e]
                        trig_i[out_e] = True
                        X_i[out_e] = X
                        new_node = out_n[X]
                        new_node = new_node[state[new_node] == 0]
                        state[new_node] = 1
                        new_active.extend(new_node)
                    new_A = new_active

                    new_active = []
                    for node in new_B:
                        out_e = self.G.incident(node, mode=OUT)
                        out_n = np.asarray(self.G.neighbors(node, mode=OUT))
                        X = np.random.rand(len(out_e)) < self.weight[out_e]
                        trig_i[out_e] = True
                        X_i[out_e] = X
                        new_node = out_n[X]
                        new_node = new_node[state[new_node] == 0]
                        state[new_node] = -1
                        new_active.extend(new_node)
                    new_B = new_active

            T_i[trig_i] += 1
            mu_hat[trig_i] = mu_hat[trig_i] + (X_i[trig_i] - mu_hat[trig_i]) / T_i[trig_i]
            T_i_nonzero = (T_i != 0)
            rho[T_i_nonzero] = np.sqrt(3 * np.log(t + 1) / (2 * T_i[T_i_nonzero]))

            if t == etc:
                self.t_MC *= 10
            
            inf_t[t] = self.cal_inf(self.G, S_A)
            # record reward for etc
            reward_continue = inf_t[t]
            print('round {}: {} seconds'.format(t, time.time() - t0, inf_t[t]))
            print('expected reward: {}'.format(inf_t[t]))
            cum_reg += opt_cal - inf_t[t]
            if t%write_per_step == 0:
                f_write.write(f'{t} {inf_t[t]} {opt_cal - inf_t[t]} {cum_reg}\n')
            end_round = time.time()
            print(f"time: {end_round-start_round}")
        end_time = time.time()
        print(f"total time: {end_time - start_time}, avg_time: {(end_time - start_time) / self.T}")

        reg_t = opt_cal - inf_t
        return reg_t

    def plot(self, explore_ratio=1., ep_greedy=0., etc=0, plot_range_low=0,
             plot_range_high=1, present_round=2000, color='b', marker='d-', S_B_type='max'):
        line_id = 0
        step = 200
        n_trials = plot_range_high - plot_range_low
        round = [i for i in range(present_round)]
        regret = np.zeros((n_trials, present_round))
        S_type = S_B_type
        if explore_ratio == 'ts':
            f_name_prefix = f'result/2021-02-05/IMM_real_679_3374_2000_Bayes_ep_{ep_greedy}_er_{explore_ratio}_tb_{self.tb_AB}_lcb_{self.lcb}_{self.S_B_type}'
        elif etc == 0:
            # f_name_prefix = f'result/2020-06-02/IMM_real_679_3374_2000_ep_{ep_greedy}_er_{explore_ratio}_tb_{self.tb_AB}_lcb_{self.lcb}_{S_type}'
            # f_name_prefix = f'result/2020-06-10/IMM_real_679_3374_1500_ep_{ep_greedy}_er_{explore_ratio}_tb_{self.tb_AB}_lcb_{self.lcb}_{self.S_B_type}'
            f_name_prefix = f'result/2021-02-05/IMM_real_679_3374_2000_Bayes_ep_{ep_greedy}_er_{explore_ratio}_tb_{self.tb_AB}_lcb_{self.lcb}_{self.S_B_type}'
        else:
            # f_name_prefix = f'result/2020-06-05/IMM_real_679_3374_2000_ep_{ep_greedy}_er_{explore_ratio}_etc_{etc}_{S_type}'
            f_name_prefix = f'result/2020-06-11/IMM_real_679_3374_40000_ep_{ep_greedy}_er_{explore_ratio}_etc_{etc}_tb_{self.tb_AB}_lcb_{self.lcb}_{self.S_B_type}'

        for id in range(plot_range_low, plot_range_high):
            # with open(f'{self.log_file}_ep_{ep_greedy}_er_{explore_ratio}_{self.edge_prob_type}_{i}', 'r') as f:
            # with open(f'result/2020-05-27/2020-05-27/RR_powerlaw_200_500_1000_ep_{ep_greedy}_er_{explore_ratio}_{i}', 'r') as f:
            # with open(f'result/2020-05-27/2020-05-27/RR_powerlaw_100_1000_3000_ep_{ep_greedy}_er_{explore_ratio}_indegree_{i}', 'r') as f:
            # with open(f'result/2020-05-28/greedy_powerlaw_300_1000_3000_ep_{ep_greedy}_er_{explore_ratio}_indegree_{i}', 'r') as f:
            # with open(f'result/2020-05-31/IMM_real_679_3374_2000_ep_{ep_greedy}_er_{explore_ratio}_max_{i}', 'r') as f:
            # with open(f'result/2020-05-30/IMM_real_679_3374_1000_ep_{ep_greedy}_er_{explore_ratio}_uniform_{i}', 'r') as f:
            with open(f'{f_name_prefix}_{id}', 'r') as f:
                i = id - plot_range_low
                for line in f:
                    if line_id == present_round - 1:
                        line_id = 0
                        break
                    r = int(line.split()[0])
                    # if r % 10 != 0:
                    #     continue
                    reg = float(line.split()[3])
                    if i == 0:
                        round[line_id] = r
                    regret[i, line_id] = reg
                    line_id += 1
        round = np.array(round)
        regret_mean = np.array([np.mean(regret[:, round_id]) for round_id in range(present_round)])
        regret_std = np.array([np.std(regret[:, round_id]) for round_id in range(present_round)])

        regret_mean = np.append(regret_mean[:step:int(step/4)], regret_mean[step::step-1])
        regret_std = np.append(regret_std[:step:int(step/4)], regret_std[step::step-1])
        round = np.append(round[:step:int(step/4)], round[step::step-1])

        # names
        if explore_ratio == 'ts':
            name = 'OCIM-TS'
        elif etc == 0:
            if explore_ratio == 0 and ep_greedy == 0:
                name = 'EMP'
            if ep_greedy > 0:
                name = r"$\epsilon$-Greedy ($\epsilon={}$)".format(ep_greedy)
            if explore_ratio > 0:
                name = r"OCIM-OFU ($\alpha_{{\rho}} = {}$)".format(explore_ratio)
        else:
            name = r"OCIM-ETC ($ETC = {}$)".format(etc)

        plt.plot(round, regret_mean, f'{color}{marker}', label=name)
        plt.fill_between(round, regret_mean - 1.96 * regret_std/np.sqrt(n_trials),
                         regret_mean + 1.96 * regret_std/np.sqrt(n_trials), color=color, alpha=0.1)

    def profile_prog(self):
        # for optimization
        profiler = Profile()
        profiler.runcall(self.cucb)
        stats = Stats(profiler)
        stats.strip_dirs()
        stats.sort_stats('cumulative')
        stats.print_stats()


if __name__ == "__main__":
    # n_low = 0
    n_exps = 1
    n_trials = 1
    n_start = 3
    t = 2000
    cut = 10
    lcb = False
    S_B_type = 'max'
    tb_AB = 0
    write_per_step = 1
    #n_etc = [int(t/cut * (i+1)) for i in range(8)]
    n_etc = [20000]
    # print(n_etc)
    exp = GeneralGraphExp(t_MC=50, T=t,
                          k_B=10, k_A=10, oracle='IMM', G_type='real', S_B_type=S_B_type, tb_AB=tb_AB, lcb=lcb)
    with concurrent.futures.ProcessPoolExecutor(max_workers=1) as executor:
        for exp_id in range(n_exps):
            n_low = n_start + n_trials * exp_id
            exp = GeneralGraphExp(t_MC=50, T=t,
                               k_B=10, k_A=10, oracle='IMM', G_type='real', S_B_type=S_B_type, tb_AB=tb_AB, lcb=lcb, exp_id=exp_id)
            for i in range(n_low,  n_low + n_trials):
        #         # for j in n_etc:
        #         #     executor.submit(exp.cucb, explore_ratio=0.0, ep_greedy=0.0, etc=j, log_ind=i, write_per_step=write_per_step)
        #
                # TS
                #executor.submit(exp.TS, log_ind=i)

                # cucb
                # executor.submit(exp.cucb, explore_ratio=1.0, ep_greedy=0.0, log_ind=i)
                # exp.cucb(explore_ratio=1.0, ep_greedy=0.0, log_ind=i)

                # ep_greedy 0.05
                # executor.submit(exp.cucb, explore_ratio=0.0, ep_greedy=0.05, log_ind=i)
                # # exp.cucb(explore_ratio=0.0, ep_greedy=0.05)

                # ep_greedy 0.01
        #        executor.submit(exp.cucb, explore_ratio=0.0, ep_greedy=0.01, log_ind=i)
                # exp.cucb(explore_ratio=0.0, ep_greedy=0.01)

                # empirical_mean
        #        executor.submit(exp.cucb, explore_ratio=0.0, ep_greedy=0.0, log_ind=i)
                # exp.cucb(explore_ratio=0.0, ep_greedy=0.0)
        #
        #         # gamma 0.1
        #         # executor.submit(exp.cucb, explore_ratio=0.1, ep_greedy=0.0, log_ind=i)
        #         #
                # gamma 0.2
        #        executor.submit(exp.cucb, explore_ratio=0.2, ep_greedy=0.0, log_ind=i)
        #
                # gamma 0.05
                executor.submit(exp.cucb, explore_ratio=0.05, ep_greedy=0.0, log_ind=i)
        #
        #         # gamma 0.01
        #         # executor.submit(exp.cucb, explore_ratio=0.01, ep_greedy=0.0, log_ind=i)
        #
        # #         # # etc 60
        # #         # executor.submit(exp.cucb, explore_ratio=0.0, ep_greedy=0.0, etc=60, log_ind=i)
        # #         #
        # #         # # etc 120
        # #         # executor.submit(exp.cucb, explore_ratio=0.0, ep_greedy=0.0, etc=120, log_ind=i)
        # #         #
        # #         # # etc 180
        # #         # executor.submit(exp.cucb, explore_ratio=0.0, ep_greedy=0.0, etc=180, log_ind=i)




    # # # #exp = Bi_graph_exp(n_s=100, n_t=1000, theta=10000, t_MC=1000, T=5,
    # # # #                    k_B=4, k_A=5, oracle='RR', G_type='powerlaw', log_ind=0)
    # # # # # reg_t = exp.cucb(ep_greedy=0.0, explore_ratio=0.0)
    # colors = ["r", "b", "g", "y", "m", "c", "b"]
    # markers = ["s--", "^--", "*--", "d:", "o-", "P-", "x-"]
    # # for i in range(5):
    # #     etc = 10*i + 110
    # #     exp.plot(ep_greedy=0.0, explore_ratio=0.0, plot_range_low=0, etc=etc, plot_range_high=n_trials, color=colors[i],
    # #              marker=markers[i])
    # exp.plot(ep_greedy=0.0, explore_ratio=0.05, plot_range_low=n_start, plot_range_high=n_start+n_trials*n_exps, color=colors[0],
    #          marker=markers[0], S_B_type=S_B_type)
    # # exp.plot(ep_greedy=0.0, explore_ratio=0.1, plot_range_low=n_start, plot_range_high=n_start+n_trials*n_exps, color=colors[1],
    # #          marker=markers[1], S_B_type=S_B_type)
    # exp.plot(ep_greedy=0.0, explore_ratio=0.2, plot_range_low=n_start, plot_range_high=n_start+n_trials*n_exps, color=colors[2],
    #          marker=markers[2], S_B_type=S_B_type)
    # exp.plot(ep_greedy=0.0, explore_ratio='ts', plot_range_low=n_start, plot_range_high=n_start + n_trials * n_exps,
    #          color=colors[6],
    #          marker=markers[6], S_B_type=S_B_type)
    # # exp.plot(ep_greedy=0.05, explore_ratio=0.0, plot_range_low=n_start, plot_range_high=n_start+n_trials*n_exps, color=colors[3],
    # #          marker=markers[3], S_B_type=S_B_type)
    # exp.plot(ep_greedy=0.01, explore_ratio=0.0, plot_range_low=n_start, plot_range_high=n_start+n_trials*n_exps, color=colors[4],
    #          marker=markers[4], S_B_type=S_B_type)
    # exp.plot(ep_greedy=0.0, explore_ratio=0.0, plot_range_low=n_start, plot_range_high=n_start+n_trials*n_exps, color=colors[5],
    #          marker=markers[5], S_B_type=S_B_type)
    # #
    # plt.xlabel("Round T")
    # plt.ylabel("Bayesian regret")
    # plt.legend()
    # # plt.show()
    # # # plt.savefig('figure/100_1000_powerlaw_RR')
    # # plt.savefig('figure/200_500_powerlaw_random_RR')
    # # plt.savefig('figure/300_1000_powerlaw_random_greedy')
    # # plt.savefig('figure/2020-06-01_679_3374_2000_real_indegree_max_IMM')
    # plt.savefig(f'figure/new_figures/Bayes_679_3374_1000_real_indegree_{S_B_type}_IMM_{lcb}_{tb_AB}_{n_start}')
    # # # # # print(exp.S_B)
    # # # # # # print(opt)
    # # # # # # plt.plot(np.cumsum(reg_t))
    # # # # # plt.show()








