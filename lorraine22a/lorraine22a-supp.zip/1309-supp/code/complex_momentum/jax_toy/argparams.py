import argparse
import os, datetime


def collect_params():
    parser = argparse.ArgumentParser()

    parser.add_argument('--z_dim', type=int, default=4,
                        help='The dimensionality of the latent space')
    parser.add_argument('--batch_size', type=int, default=1000,
                        help='Batch size')

    parser.add_argument('--G_lr', type=complex, default=1e-3 + 0.j,  # 1e-3,
                        help='Generator learning rate')
    parser.add_argument('--D_lr', type=complex, default=1e-3 + 0.j,  # 1e-3,
                        help='Discriminator learning rate')
    parser.add_argument('--zero_game', action='store_true', default=False)

    parser.add_argument('--n_epochs', type=int, default=100000,  # 200000,
                        help='Number of epochs to train')

    parser.add_argument('--momentum_mass', type=float, default=0.5,
                        help='momentum parameter')
    parser.add_argument('--momentum_mass_complex', type=complex, default=0.3j,
                        help='momentum parameter')
    parser.add_argument('--complex_lr', action='store_false', default=True)

    parser.add_argument('--out_dir', type=str, default='./out_dir',
                        help='outdir')
    parser.add_argument('--toy_version', type=str, choices=['spirals', 'gaussians'], default='gaussians')
    parser.add_argument('--net_version', type=str, choices=['very_toy', 'neg_momentum_paper'],
                        default='neg_momentum_paper')

    parser.add_argument('--opt', type=str, choices=['gd', 'momentum', 'complex_momentum'], default='complex_momentum')
    parser.add_argument('--compute_batch_nll', action='store_true', default=True)

    parser.add_argument('--no_improvement_after', type=int, default=-1)
    parser.add_argument('--singleton', action='store_true', default=False)
    parser.add_argument('--eid', type=str, default='default')
    parser.add_argument('--grid_up', type=float, default=-3.5)
    parser.add_argument('--grid_low', type=float, default=-5.0)
    parser.add_argument('--grid_size', type=int, default=10)
    parser.add_argument('--args_B_LR', type=str, default='')
    parser.add_argument('--args_LR_multiplier', type=str, default='')

    args = parser.parse_args()

    timestamp = '{:%Y-%m-%d}'.format(datetime.datetime.now())

    out_dir = args.out_dir

    if args.singleton is True:
        out_dir = os.path.join(out_dir, args.eid, timestamp + '_toy_gan_scale',
                               f'step_sizes_g_lr_{args.G_lr:.4}_d_lr_{args.D_lr:.4}_momentum_{args.momentum_mass:.4}_{args.momentum_mass_complex:.4}')

        if not os.path.isdir(out_dir):
            os.makedirs(out_dir)
        args.out_dir = out_dir
        open(os.path.join(args.out_dir, 'exp_params.txt'), 'w').write(str(vars(args)) + '\n')

    # print(args)

    return args
