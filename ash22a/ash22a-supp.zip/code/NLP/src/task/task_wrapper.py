from task.wiki3029_task import Wiki3029Task


class TaskWrapper:

    def __init__(self):
        pass

    @staticmethod
    def make_task(config, task_name, logger):

        if task_name == "wiki-3029":
            return Wiki3029Task(dataset_name="Wiki-3029",
                                config=config,
                                logger=logger,
                                ngram=1,
                                threshold=50)

        else:
            raise AssertionError("Unhandled task %r" % task_name)
