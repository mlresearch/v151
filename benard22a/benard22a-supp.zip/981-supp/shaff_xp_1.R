

# load packages
library(shaff)
library(ranger)
library(mvtnorm)
library(MASS)
library(Matrix)
library(CombMSC)
library(nnls)
library(ggplot2)
library(parallel)


p <- 11

sample_distr <- function(){
  
  # coef
  beta <- 10*runif(p)
  beta[p-0:4] <- 0
  
  # Cov
  Covmat <- matrix(rnorm(p*p, sd = 20), ncol = p)
  Covmat <- t(Covmat) %*% Covmat
  
  return(list(beta = beta, Covmat = Covmat))
  
}

sample_data <- function(beta, Covmat, r = 0, nsample, redundant = FALSE, j, k){
  
  # inputs
  X <- mvrnorm(n = nsample, mu = rep(0,p), Sigma = Covmat)
  Xnoise <- sapply(1:2, rnorm, n = nsample)
  if (redundant){
    X <- cbind(X, sapply(1:k, function(s){X[, j]}))
    beta <- c(beta, rep(0, k))
  }
  
  # outputs
  Y <- X %*% beta
  Y <- Y + rnorm(nsample, sd = sqrt(r/(1-r)*var(Y)))
  
  # data
  data <- as.data.frame(cbind(X, Xnoise, Y)) #
  colnames(data) <- c(paste('X', 1:(ncol(data)-1), sep=''), 'Y')
  
  return(data)
  
}

get_theoretical_shapley <- function(beta, Covmat, r = 0){
  
  sig2 = as.numeric(t(beta) %*% Covmat %*% beta)/(1-r)
  phi <- lapply(0:(p-1), function(k){
    if (k > 0){
      apply(subsets(p, k, 1:p), 1, function(U){
        UC <- setdiff(1:p, U)
        cov11 <- Covmat[UC, UC, drop = F]
        cov12 <- Covmat[UC, U, drop = F]
        cov21 <- Covmat[U, UC, drop = F]
        cov22 <- Covmat[U, U, drop = F]
        if (nrow(cov22) == 1){
          inv22 <- 1/cov22
        }else{
          inv22 <- solve(cov22)
        }
        covCond <- cov11 - cov12 %*% inv22 %*% cov21
        V <- rep(0, p)
        V[UC] <- (covCond %*% beta[UC])^2 / diag(covCond)
        return(V)
      }) / (p * choose(p - 1, k))
    } else{
      (Covmat %*% beta)^2 / (p * diag(Covmat))
    }
  })
  phi <- cbind(rep(1, p) / p, do.call('cbind', phi))
  shapTh <- apply(phi, 1, sum)/sig2
  shapTh <- c(shapTh, rep(0, 2))
  # shapTh[1] <- shapTh[1]/5
  # shapTh <- c(shapTh, rep(shapTh[1], 4))
  return(shapTh)
  
}

get_theoretical_shapley_redundant <- function(beta, Covmat, r = 0, j, k){
  
  # k copies of variable j are added to the data
  sig2 <- as.numeric(t(beta) %*% Covmat %*% beta)/(1-r)
  phi <- lapply(0:(p-1), function(u){
    if (u > 0){
      Cj <- 1 / ((p + k) * choose(p + k - 1, u))
      Ck <- 1 / (p + k) * (sum(sapply(0:k, function(l){choose(k, l) / choose(p + k - 1, u + l)})) + 
                           sum(sapply(1:k, function(l){choose(k, l) / choose(p + k - 1, u + l - 1)})))
      Usets <- subsets(p, u, 1:p)
      res <- apply(Usets, 1, function(U){
        UC <- setdiff(1:p, U)
        cov11 <- Covmat[UC, UC, drop = F]
        cov12 <- Covmat[UC, U, drop = F]
        cov21 <- Covmat[U, UC, drop = F]
        cov22 <- Covmat[U, U, drop = F]
        if (nrow(cov22) == 1){
          inv22 <- 1/cov22
        }else{
          inv22 <- solve(cov22)
        }
        covCond <- cov11 - cov12 %*% inv22 %*% cov21
        V <- rep(0, p)
        V[UC] <- (covCond %*% beta[UC])^2 / diag(covCond)
        return(V)
      })
      res[j, ] <- Cj * res[j, ]
      indh <- apply(Usets, 1, function(x){j %in% x})
      res[-j, !indh] <- Cj * res[-j, !indh]
      res[-j, indh] <- Ck * res[-j, indh]
    } else{
      res <- (Covmat %*% beta)^2 / ((p + k) * diag(Covmat))
    }
    return(res)
  })
  phi <- cbind(rep(1, p) / p, do.call('cbind', phi))
  shapTh <- apply(phi, 1, sum)/sig2
  shapTh <- c(shapTh, rep(shapTh[j], k))
  shapTh <- c(shapTh, rep(0, 2))

  return(shapTh)
  
}

get_theoretical_shapley_MC <- function(nMC, beta, Covmat, r = 0){
  
  sig2 = as.numeric(t(beta) %*% Covmat %*% beta)/(1-r)
  Uall <- sapply(1:nMC, function(u){
    d <- sample(0:(p-1), 1)
    U <- sample(1:p, d)
    return(U)
  })
  
  
  phi <- lapply(Uall, function(U){
      k <- length(U)
      if (k > 0){
        UC <- setdiff(1:p, U)
        cov11 <- Covmat[UC, UC, drop = F]
        cov12 <- Covmat[UC, U, drop = F]
        cov21 <- Covmat[U, UC, drop = F]
        cov22 <- Covmat[U, U, drop = F]
        if (nrow(cov22) == 1){
          inv22 <- 1/cov22
        }else{
          inv22 <- solve(cov22)
        }
        covCond <- cov11 - cov12 %*% inv22 %*% cov21
        V <- rep(0, p)
        V[UC] <- (covCond %*% beta[UC])^2 / diag(covCond)
        # V / (p * choose(p - 1, k))
        V <- V * p / (p - k)
        return(V)
      } else{
      # (Covmat %*% beta)^2 / (p * diag(Covmat))
        (Covmat %*% beta)^2 / diag(Covmat)
    }
  })
  phi <- do.call('cbind', phi)
  shapTh <- apply(phi, 1, mean)/sig2

  return(shapTh)
  
}


# shap forest parameters
num.trees <- 500
num_varU <- 500
nX <- 15
nsample <- 3000
r <- 0.05
# redundant variables
redundant <- T
k <- 2
j <- 2
nrep <- 30
nclust <- detectCores() - 1

set.seed(10)
distr <- sample_distr()
beta <- distr$beta
Covmat <- distr$Covmat

if (redundant){
  shapTh <- get_theoretical_shapley_redundant(beta, Covmat, r, j, k)
}else{
  shapTh <- get_theoretical_shapley(beta, Covmat, r)
}
print(shapTh)




### make cluster
cl <- makeCluster(getOption("cl.cores", nclust))
clusterExport(cl, c("sample_data", "shaff", "ranger",
                    "nnls", "p", "nX", "beta", "Covmat", "r", "nsample", "redundant",
                    "j", "k", "num.trees", "num_varU", "mvrnorm"))


res <- parLapply(cl, 1:nrep, function(iter){
  data <- sample_data(beta, Covmat, r, nsample, redundant, j, k)
  shap_temp <- shaff(data)
  return(shap_temp)
})
data <- sample_data(beta, Covmat, r, nsample, redundant, j, k)
forest <- ranger(Y ~., data = data)
print(forest$r.square)
Variable <- factor(colnames(data)[-(nX+1)], levels = colnames(data)[-(nX+1)])
dfTh <- cbind(as.data.frame(shapTh), Variable, rep("Theory", nX))
colnames(dfTh) <- c("Shapley", "Variable", "Algo")
resSHAFF <- cbind(as.data.frame(unlist(res)), rep(Variable, nrep), rep(rep("SHAFF", nX), nrep))
colnames(resSHAFF) <- c("Shapley", "Variable", "Algo")
df <- resSHAFF


### Williamson
res <- parLapply(cl, 1:nrep, function(iter){
  data <- sample_data(beta, Covmat, r, nsample, redundant, j, k)
  clock <- Sys.time()
  forest <- ranger(Y ~., data = data, num.trees = num.trees)
  v <- forest$r.squared
  Uall <- sapply(1:num_varU, function(u){
    d <- sample(1:(nX-1), 1)
    U <- sample(1:nX, d)
    return(U)
  })
  V <- sapply(Uall, function(U){
    dataU <- data[, c(U, nX + 1)]
    if (length(U) <= 2){
      max.depth <- 6
    }else{
      max.depth <- NULL
    }
    forestU <- ranger(Y ~., data = dataU, num.trees = num.trees,
                      max.depth = max.depth)
    return(forestU$r.squared)
  })
  Z <- t(sapply(Uall, function(S){
    z <- rep(0, nX)
    z[S] <- 1
    z
  }))
  w <- apply(Z, 1, function(z){
    k <- sum(z)
    (nX - 1)/(choose(nX, k) * k * (nX - k))
  })
  Z <- rbind(rep(0, nX), rep(1, nX), Z)
  Vall <- c(0, v, V)
  w <- c(1000, 1000, w)
  W <- diag(sqrt(w))
  shap_williamson <- nnls(A = W %*% Z, b = W %*% Vall)
  print(Sys.time() - clock)
  return(shap_williamson$x)
})
resWil <- cbind(as.data.frame(unlist(res)), rep(Variable, nrep), rep(rep("Williamson", nX), nrep))
colnames(resWil) <- c("Shapley", "Variable", "Algo")
df <- rbind(df, resWil)


### SAGE
res <- parLapply(cl, 1:nrep, function(iter){
  
  data <- sample_data(beta, Covmat, r, nsample, redundant, j, k)
  
  clock <- Sys.time()
  forest <- ranger(Y ~., data = data, num.trees = num.trees)
  sage <- rep(0, nX)
  ymean <- mean(predict(forest, data[,-(nX+1)])$predictions)
  sig <- var(data$Y)
  m <- 30
  for (iter in 1:nsample){
    i <- sample(1:nsample, 1)
    x <- data[i, -(nX+1)]
    y <- data[i, nX+1]
    lossPrev <- (y - ymean)^2/sig
    S <- sample(1:nX, nX, replace = F)
    s <- c()
    for (j in 1:nX){
      s <- c(s, S[j])
      ik <- sample(1:nsample, m, replace = T)
      xk <- data[ik, -(nX+1)]
      xk[, s] <- x[, s]
      ypred <- mean(predict(forest, xk)$predictions)
      loss <- (y - ypred)^2/sig
      delta <- lossPrev - loss
      sage[S[j]] <- sage[S[j]] + delta
      lossPrev <- loss
    }
  }
  sage <- sage/nsample
  print(Sys.time() - clock)
  return(sage)
  
})
resSAGE <- cbind(as.data.frame(unlist(res)), rep(Variable, nrep), rep(rep("SAGE", nX), nrep))
colnames(resSAGE) <- c("Shapley", "Variable", "Algo")
df <- rbind(df, resSAGE)



## plot results
df$Algo <- factor(df$Algo, levels = c("Theory", "SHAFF", "Williamson", "SAGE"))
shap_plot <- ggplot() + 
  geom_boxplot(data = df, aes(x=Variable, y=Shapley, fill = Algo),
               position=position_dodge(0.5)) +
  geom_point(data = dfTh, aes(x = Variable, y = Shapley), 
             size = 8, color = 'red', shape = 3, stroke = 2) +
  xlab('Variables') +
  ylab('Shapley Effects') +
  theme_classic() +
  theme(axis.line.x = element_line(colour = 'black'),
        axis.line.y = element_line(colour = 'black'),
        text = element_text(size=15),
        plot.title = element_text(hjust = 0.5, size=12, face="italic"))

shap_plot

# save plot
time.end <- gsub(':', '', Sys.time())
time.end <- gsub(' ', '-', time.end)
ggsave(paste0(time.end, '_SHAFF_xp_1.png'), plot = shap_plot, width = 9, height = 6)

