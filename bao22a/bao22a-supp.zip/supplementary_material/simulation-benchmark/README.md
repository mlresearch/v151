# Similarity Learning Can Elicit Binary Classifiers

This repository is the official implementation of "Similarity Learning Can Elicit Binary Classifiers".

## Requirements
All experiments were conducted with `Python 3.7`.  
To install requirements:

```setup
pip install -r requirements.txt
```

## Experiments for Clustering Error Minimization
### Train and Evaluation
To reproduce clustering error minimization experiments in the paper, run these command:
```train
# if results directory does not exist
mkdir results

# experiments for sample complexity
python exp_complexity.py

# experiments for class proportions
python exp_priors.py

# experiments on tabular datasets
python exp_tabular.py
```

### How to show results
The obtained results are aggregated and converted into figures and tables with
[`notebooks/aggregate_results.ipynb`](notebooks/aggregate_results.ipynb).

#### Sample Complexity in Clustering Error Minimization
![consistency-mnist](notebooks/img/consistency_mnist.png)
![consistency-fashion](notebooks/img/consistency_fashion.png)
![consistency-kmnist](notebooks/img/consistency_kmnist.png)

#### Effect of Class Proportions in Clustering Error Minimization

![prior-mnist](notebooks/img/prior_mnist.png)
![prior-fashion](notebooks/img/prior_fashion.png)
![prior-kmnist](notebooks/img/prior_kmnist.png)

#### Mean Clustering Error and Standard Error on Tabular Datasets
|      dataset       | CIPS(Ours) |    MCL     |     SD     |    OVPC    |    SSP     |    CKM     |     KM     |    (SV)    |
| :----------------: | :--------: | :--------: | :--------: | :--------: | :--------: | :--------: | :--------: | :--------: |
|   ('adult', 100)   | 39.8 (1.6) | 38.4 (2.1) | 30.8 (0.9) | 45.0 (0.9) | 24.7 (0.3) | 28.9 (0.8) | 24.9 (0.5) | 21.9 (0.4) |
|   ('adult', 500)   | 21.5 (1.0) | 19.3 (0.4) | 23.2 (0.4) | 44.7 (0.9) | 24.3 (0.3) | 28.2 (0.4) | 27.5 (0.5) | 16.9 (0.3) |
|  ('adult', 1000)   | 17.6 (0.3) | 17.2 (0.3) | 20.5 (0.3) | 45.5 (0.7) | 24.2 (0.3) | 27.9 (0.4) | 27.9 (0.5) | 15.9 (0.3) |
|  ('banana', 100)   | 43.6 (0.6) | 44.5 (0.6) | 45.3 (0.6) | 46.0 (0.7) | 43.0 (1.0) | 46.4 (0.7) | 45.8 (0.7) | 44.6 (0.6) |
|  ('banana', 500)   | 43.1 (0.8) | 43.3 (0.6) | 45.1 (0.7) | 46.0 (0.7) | 14.3 (0.7) | 45.5 (0.6) | 44.4 (0.4) | 45.1 (0.6) |
|  ('banana', 1000)  | 44.4 (0.6) | 44.3 (0.7) | 44.4 (0.5) | 46.2 (0.5) | 11.0 (0.2) | 45.0 (0.7) | 44.0 (0.3) | 45.1 (0.7) |
|  ('codrna', 100)   | 24.7 (1.8) | 32.3 (1.4) | 28.0 (1.3) | 32.0 (2.0) | 45.5 (1.5) | 46.7 (0.6) | 42.5 (1.0) | 11.0 (0.6) |
|  ('codrna', 500)   | 6.4 (0.2)  | 10.6 (0.3) | 12.0 (0.6) | 28.0 (2.1) | 48.6 (0.3) | 46.2 (0.3) | 44.0 (0.7) | 6.6 (0.2)  |
|  ('codrna', 1000)  | 6.3 (0.2)  | 6.5 (0.2)  | 8.8 (0.4)  | 28.3 (2.0) | 44.8 (1.6) | 46.1 (0.4) | 45.4 (0.6) | 6.3 (0.2)  |
|  ('ijcnn1', 100)   | 16.6 (2.3) | 24.9 (2.9) | 10.7 (0.3) | 41.1 (1.1) | 31.6 (2.0) | 40.0 (1.3) | 31.9 (2.4) | 9.1 (0.2)  |
|  ('ijcnn1', 500)   | 7.7 (0.2)  | 8.2 (0.2)  | 8.3 (0.2)  | 41.6 (1.3) | 33.0 (2.5) | 45.4 (0.8) | 41.7 (0.7) | 7.9 (0.2)  |
|  ('ijcnn1', 1000)  | 7.7 (0.2)  | 7.9 (0.2)  | 8.1 (0.2)  | 42.0 (1.4) | 34.9 (1.7) | 45.9 (0.8) | 43.4 (0.7) | 7.6 (0.2)  |
|   ('magic', 100)   | 24.9 (1.3) | 28.7 (1.8) | 30.7 (1.3) | 41.9 (1.0) | 47.1 (0.5) | 45.5 (1.2) | 44.0 (1.2) | 21.8 (0.4) |
|   ('magic', 500)   | 21.5 (0.3) | 21.3 (0.3) | 25.5 (0.8) | 39.6 (1.5) | 46.8 (0.5) | 46.8 (0.4) | 44.4 (0.4) | 20.8 (0.3) |
|  ('magic', 1000)   | 21.3 (0.3) | 20.9 (0.3) | 23.8 (0.4) | 39.5 (1.7) | 43.6 (0.9) | 46.8 (0.3) | 44.6 (0.4) | 20.7 (0.3) |
| ('phishing', 100)  | 12.7 (2.3) | 12.8 (2.3) | 34.6 (1.8) | 41.7 (1.0) | 46.6 (0.5) | 24.4 (3.4) | 47.0 (0.5) | 7.6 (0.2)  |
| ('phishing', 500)  | 7.2 (0.2)  | 6.6 (0.1)  | 26.9 (1.4) | 42.9 (0.8) | 46.0 (0.5) | 16.9 (2.6) | 46.4 (0.5) | 6.5 (0.2)  |
| ('phishing', 1000) | 6.5 (0.2)  | 6.3 (0.2)  | 22.0 (1.0) | 43.8 (1.1) | 45.5 (0.5) | 15.2 (2.7) | 46.4 (0.5) | 6.3 (0.2)  |
|  ('phoneme', 100)  | 28.2 (1.2) | 33.1 (1.9) | 29.1 (1.2) | 38.4 (1.3) | 31.0 (1.3) | 28.0 (1.0) | 32.9 (1.2) | 25.7 (0.4) |
|  ('phoneme', 500)  | 25.0 (0.4) | 24.2 (0.5) | 26.1 (0.6) | 38.6 (1.9) | 25.5 (0.5) | 28.0 (0.8) | 32.7 (0.3) | 25.0 (0.3) |
| ('phoneme', 1000)  | 25.2 (0.4) | 25.0 (0.4) | 26.0 (0.4) | 39.8 (1.5) | 24.5 (0.5) | 30.2 (0.6) | 32.7 (0.3) | 25.3 (0.2) |
| ('spambase', 100)  | 13.8 (1.0) | 13.3 (1.3) | 31.6 (1.5) | 39.7 (1.3) | 40.5 (0.4) | 15.9 (2.0) | 39.7 (1.3) | 10.5 (0.3) |
| ('spambase', 500)  | 9.4 (0.2)  | 8.6 (0.2)  | 22.6 (0.9) | 38.0 (1.6) | 40.8 (0.3) | 11.5 (0.2) | 37.4 (2.3) | 8.5 (0.2)  |
| ('spambase', 1000) | 8.3 (0.2)  | 7.6 (0.1)  | 19.7 (0.8) | 39.3 (1.2) | 40.2 (0.4) | 11.5 (0.2) | 39.7 (1.3) | 7.8 (0.2)  |
|    ('w8a', 100)    | 31.5 (1.9) | 31.4 (2.1) | 11.8 (0.3) | 39.7 (1.4) | 5.3 (1.2)  | 6.8 (1.9)  | 5.5 (1.3)  | 10.3 (0.4) |
|    ('w8a', 500)    | 5.6 (0.7)  | 4.2 (0.5)  | 3.2 (0.1)  | 38.3 (1.3) | 3.5 (0.1)  | 14.0 (3.1) | 5.5 (1.1)  | 2.6 (0.1)  |
|   ('w8a', 1000)    | 2.6 (0.2)  | 2.2 (0.1)  | 2.6 (0.2)  | 43.1 (0.8) | 3.0 (0.1)  | 8.9 (2.6)  | 3.7 (0.5)  | 2.0 (0.1)  |
| ('waveform', 100)  | 18.2 (0.3) | 17.7 (0.3) | 26.4 (0.9) | 41.9 (1.6) | 44.1 (0.6) | 41.0 (1.3) | 45.1 (0.6) | 16.2 (0.2) |
| ('waveform', 500)  | 15.8 (0.2) | 15.1 (0.2) | 20.2 (0.5) | 38.9 (1.3) | 44.9 (0.7) | 45.1 (0.6) | 47.1 (0.4) | 14.8 (0.2) |
| ('waveform', 1000) | 14.9 (0.2) | 14.7 (0.2) | 18.4 (0.3) | 37.0 (1.7) | 45.5 (0.5) | 44.9 (0.5) | 47.8 (0.4) | 14.4 (0.2) |


## Experiments for Class Assingment
To reproduce class assignment experiments in the paper, please check [`notebooks/exp_class_assignment.ipynb`](notebooks/exp_class_assignment.ipynb).

## Error Probability of Class Assignment on Synthetic Datasets
![class-assignment-01](notebooks/img/class_assinment_01.png)
![class-assignment-04](notebooks/img/class_assinment_04.png)
![class-assignment-04](notebooks/img/class_assinment_07.png)
