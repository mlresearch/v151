import argparse
import math
import os

import torch
import torch.nn as nn
import yaml

from src import get_module_logger
from src import spectralpruning as spec
from src.data.dataloader4txt import BatchfiedPTB, build_vocab
from src.models.predict_model4txt import evaluate
from src.utils.model_rnnlm import prepare_trained_rnnlm


def main():
    logger = get_module_logger("SP")
    logger.debug("Begin...")
    parser = argparse.ArgumentParser()
    parser.add_argument("--wts_path", type=str, required=True, help="Path for weight parameter.")
    parser.add_argument("--m", type=int, default=None, help="Compressed hidden_size.")
    args = parser.parse_args()

    # Pruning preparations
    wts_path = args.wts_path
    m_sharp = args.m
    # Load configure yaml
    cfg = os.path.join(*wts_path.split("/")[:-2], "config.yaml")
    with open(cfg, "r") as f:
        data = yaml.load(f, Loader=yaml.SafeLoader)
    for key in data:
        args.__setattr__(key, data[key])
    logger.debug(args)

    # Model parameters
    dropout = args.dropout
    # tie_weights = args.tie_weights
    tie_weights = False  # Can turn on True ??

    # Learning parameters
    batch_size = args.batch_size
    eval_batch_size = args.eval_batch_size
    bptt = args.bptt

    # Dataset parameters
    # dataset = args.dataset
    data_dir = args.data_dir

    # Prepare dataloader
    vocab = build_vocab(data_dir)
    train_ds = BatchfiedPTB(data_dir, "train", vocab, batch_size, bptt)
    train_dl = torch.utils.data.DataLoader(train_ds, batch_size=bptt, shuffle=False)
    test_ds = BatchfiedPTB(data_dir, "test", vocab, eval_batch_size, bptt)
    test_dl = torch.utils.data.DataLoader(test_ds, batch_size=bptt, shuffle=False)
    logger.debug("Datasets are loaded.")

    # Check device
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    if torch.cuda.is_available():
        torch.backends.cudnn.benchmark = True
    logger.debug("GPU or CPU: %s" % device)

    # Calculate covariance matrix
    cov_path = os.path.join(os.path.dirname(wts_path), "cov.pkl")
    if not os.path.exists(cov_path):
        logger.debug("Calculating covariance matrix...")
        spec.save_cov4rnnlm(wts_path, dropout, tie_weights, train_dl, device, save_name="cov.pkl")
    else:
        logger.debug("Skip calculation of covariance matrix.")
    cov = spec.load_cov(cov_path)
    # spec.figure_eigen_distribution(cov, dataset, task, save_path=os.path.dirname(wts_path))
    # logger.info("Saved image of eigenvalue distribution.")

    # Greedy algorithm and Spectral Pruning
    logger.debug("Spectral Pruning...")
    sub = None
    sub_F = spec.calc_non_zero_rows_idx(cov)
    NZR = spec.calc_non_zero_rows_n(cov)
    if m_sharp is None:
        m_sharp = NZR
        # sub = sub_F
        logger.info("  for m_sharp = %d (NZR)" % NZR)
    else:
        logger.info("  for m_sharp = %d (NZR)" % NZR)
        logger.info("  for m_sharp = %d (user)" % m_sharp)
    wts_pruned, sub_all = spec.prune_rnn_by_cov(
        torch.load(wts_path, map_location="cpu"), cov, m_sharp, sub=sub, sub_F=sub_F, quiet=True, pinv=False
    )
    torch.save(wts_pruned, os.path.join(os.path.dirname(wts_path), "wts_pruned.pth"))
    logger.info("Saved pruned weight.")
    # spec.figure_information_loss(cov, sub_all, dataset, task, save_path=os.path.dirname(wts_path))
    # logger.info("Saved image of information loss function.")

    # Compare models before/after Spectral Pruning
    logger.info("Compare accuracy before/after Spectral Pruning:")
    logger.info("Before:")
    criterion = nn.CrossEntropyLoss()
    model_org = prepare_trained_rnnlm(
        torch.load(wts_path, map_location=device), dropout=dropout, tie_weights=tie_weights
    )
    loss = evaluate(model_org, criterion, test_dl, device=device)
    logger.info("Test Loss: {:5.2f} ppl: {:8.2f}".format(loss, math.exp(loss)))
    logger.info("After:")
    model_pruned = prepare_trained_rnnlm(wts_pruned, dropout=dropout, tie_weights=tie_weights)
    loss = evaluate(model_pruned, criterion, test_dl, device=device)
    logger.info("Test Loss: {:5.2f} ppl: {:8.2f}".format(loss, math.exp(loss)))

    logger.debug("Done!!")


if __name__ == "__main__":
    main()
