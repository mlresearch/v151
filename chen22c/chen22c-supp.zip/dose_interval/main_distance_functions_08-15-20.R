
library(osqp)
library(fields)
library(locfit)


## gamma is the multiplication factor of the energy dist components in the objective function.
## larger values emphasis preservation of marginal distributions more and smaller values emphasize
## preservation less.
## lambda is a ridge penalty on the weights. 
## if preserve_means = TRUE, then the marginal means of X and A will be preserved
total_distance_balance <- function(A, X, 
                                   gamma = 0.001, 
                                   kernel = c("distance", "gaussian"),
                                   lambda = 0, preserve_means = FALSE,
                                   dimension_adj = FALSE)
{
    kernel <- match.arg(kernel)
    Xdist  <- as.matrix(dist(X))
    Adist  <- as.matrix(dist(A))
    
    
    if (kernel == "gaussian")
    {
        Xdist <- -exp(-0.5*Xdist^2/median(Xdist^2))
        Adist <- -exp(-0.5*Adist^2/median(Adist^2))
    }
    
    
    weights <- rep(1, NROW(A))
    
    n <- NROW(A)
    p <- NCOL(X)
    
    ## terms for energy-dist(Wtd A, A)
    Q_energy_A  <- -Adist / n ^ 2
    aa_energy_A <- 1 * as.vector(rowSums(Adist)) / (n ^ 2)
    
    ## terms for energy-dist(Wtd X, X)
    Q_energy_X  <- -Xdist / n ^ 2
    aa_energy_X <- 1 * as.vector(rowSums(Xdist)) / (n ^ 2)
    
    
    mean_Adist <- mean(Adist)
    mean_Xdist <- mean(Xdist)
    
    
    Xmeans <- colMeans(Xdist)
    Xgrand_mean <- mean(Xmeans)
    XA <- Xdist + Xgrand_mean - outer(Xmeans, Xmeans, "+")
    
    
    Ameans <- colMeans(Adist)
    Agrand_mean <- mean(Ameans)
    AA <- Adist + Agrand_mean - outer(Ameans, Ameans, "+")
    
    ## quadratic term for weighted total distance covariance
    P <- XA * AA / n ^ 2
    
    
    #Constraints: positive weights, weights sum to n
    if (preserve_means)
    {
        Amat <- rbind(diag(n), rep(1, n), t(X), A)
        lvec <- c(rep(0, n), n, colMeans(X), mean(A))
        uvec <- c(rep(Inf, n), n, colMeans(X), mean(A))
    } else 
    {
        Amat <- rbind(diag(n), rep(1, n))
        lvec <- c(rep(0, n), n)
        uvec <- c(rep(Inf, n), n)
    }
    
    
    if (dimension_adj)
    {
        Q_energy_A_adj <- 1 / sqrt(p)
        Q_energy_X_adj <- 1
        
        sum_adj <- 0.5*(Q_energy_A_adj + Q_energy_X_adj)
        
        Q_energy_A_adj <- Q_energy_A_adj / sum_adj
        Q_energy_X_adj <- Q_energy_X_adj / sum_adj
        
    } else
    {
        Q_energy_A_adj <- Q_energy_X_adj <- 1
    }
    
    #Optimize
    opt.out <- osqp::solve_osqp(2 * (P + gamma * (Q_energy_A * Q_energy_A_adj + Q_energy_X * Q_energy_X_adj) + lambda * diag(n) ),
                                q = 2 * gamma * (aa_energy_A * Q_energy_A_adj + aa_energy_X * Q_energy_X_adj),
                                A = Amat, l = lvec, u = uvec,
                                pars = osqp::osqpSettings(max_iter = 2e5,
                                                          eps_abs = 1e-8,
                                                          eps_rel = 1e-8,
                                                          verbose = FALSE))
    weights <- opt.out$x
    weights[weights < 0] <- 0 #due to numerical imprecision
    
    dist_history <- weighted_pure_distance_covariance(Adist, Xdist, weights)
    
    ## quadratic part of the overall objective function
    QM <- (P + gamma * (Q_energy_A * Q_energy_A_adj + Q_energy_X * Q_energy_X_adj) + lambda * diag(n) )
    quadpart <- drop(t(weights) %*% QM %*% weights)
    
    ## linear part of the overall objective function
    qvec <- 2 * gamma * (aa_energy_A * Q_energy_A_adj + aa_energy_X * Q_energy_X_adj)
    linpart  <- drop(weights %*% qvec)
    
    ## objective function
    objective_history <- quadpart + linpart + gamma*(-1*mean_Xdist * Q_energy_X_adj - mean_Adist * Q_energy_A_adj)
    
    
    
    qvec_full <- 2 * (aa_energy_A * Q_energy_A_adj + aa_energy_X * Q_energy_X_adj)
    
    #quadpart_energy <- drop(t(weights) %*% ((Q_energy_A + Q_energy_X)) %*% weights)
    
    quadpart_energy_A <- drop(t(weights) %*% ((Q_energy_A)) %*% weights) * Q_energy_A_adj
    quadpart_energy_X <- drop(t(weights) %*% ((Q_energy_X)) %*% weights) * Q_energy_X_adj
    
    quadpart_energy <- quadpart_energy_A * Q_energy_A_adj + quadpart_energy_X * Q_energy_X_adj
    
    
    distcov_history <- drop(t(weights) %*% P %*% weights)
    
    
    
    linpart_energy   <- drop(weights %*% qvec_full)
    linpart_energy_A <- 2 * drop(weights %*% (aa_energy_A)) * Q_energy_A_adj
    linpart_energy_X <- 2 * drop(weights %*% (aa_energy_X)) * Q_energy_X_adj
    
    
    ## sum of energy-dist(wtd A, A)+energy-dist(wtd X, X)
    energy_history <- quadpart_energy + linpart_energy - mean_Xdist * Q_energy_X_adj - mean_Adist * Q_energy_A_adj
    
    ## energy-dist(wtd A, A)
    energy_A <- quadpart_energy_A + linpart_energy_A - mean_Adist * Q_energy_A_adj
    
    ## energy-dist(wtd X, X)
    energy_X <- quadpart_energy_X + linpart_energy_X - mean_Xdist * Q_energy_X_adj
    
    rand_wts_energy <- numeric(100)
    for (i in 1:100)
    {
        wts_rand <- rgamma(n, shape = 1, rate = 0.05) #runif(n)
        wts_rand <- wts_rand / mean(wts_rand)
        
        rand_wts_energy[i] <- drop(t(wts_rand) %*% ((Q_energy_A * Q_energy_A_adj + Q_energy_X * Q_energy_X_adj)) %*% wts_rand) + 
            drop(wts_rand %*% qvec_full) - mean_Xdist * Q_energy_X_adj - mean_Adist * Q_energy_A_adj
        
    }
    
    
    dist_history      <- dist_history
    objective_history <- objective_history
    energy_history    <- energy_history
    
    return(list(weights = weights, 
                opt = opt.out, 
                distcov_extracat = dist_history,   ### the weighted extracat distance
                rand_wts_energy = rand_wts_energy, ### energy distance with random weights
                objective = objective_history,     ### the actual objective function value
                distcov = distcov_history,         ### the weighted total distance covariance
                energy = energy_history,           ### sum of weighted energy distances
                energy_A = energy_A,               ### Energy(Wtd Treatment, Treatment)
                energy_X = energy_X))              ### Energy(Wtd X, X)
}




## Adist is an nxn pairwise euclidean distance matrix for the treatment
## Xdist is an nxn pairwise euclidean distance matrix for the covariates
weighted_pure_distance_covariance <- function(Adist, Xdist, w) 
{
    
    w <- w/mean(w)
    
    n <- NROW(Adist)
    
    Xmeans <- apply(Xdist, 2, weighted.mean, w)
    Xgrand_mean <- weighted.mean(Xmeans, w)
    XA <- Xdist + Xgrand_mean - outer(Xmeans, Xmeans, "+")
    
    Ameans <- apply(Adist, 2, weighted.mean, w)
    Agrand_mean <- weighted.mean(Ameans, w)
    AA <- Adist + Agrand_mean - outer(Ameans, Ameans, "+")
    
    drop(1/(n^2) * t(w) %*% (XA * AA) %*% w)
}

## weighted correlation
wcor <- function (x, y, wxy = NULL, wx = NULL, wy = NULL, method = c("Pearson", "Spearman"))
{
    method <- match.arg(method)
    if (!is.numeric(x)) {
        x <- as.numeric(x)
    }
    if (!is.numeric(y)) {
        y <- as.numeric(y)
    }
    
    
    if (is.null(wx)) wx   <- rep(1, NROW(x))
    if (is.null(wy)) wy   <- rep(1, NROW(y))
    if (is.null(wxy)) wxy <- rep(1, NROW(x))
    
    
    #wx <- wy <- wxy
    
    
    if (!is.numeric(wx)) {
        wx <- as.numeric(wx)
    }
    
    if (!is.numeric(wy)) {
        wy <- as.numeric(wy)
    }
    
    pm <- pmatch(tolower(method[[1]]), tolower(c("Pearson", "Spearman")))
    if (pm == 2) {
        x <- wrank(x, rep(1, NROW(y)))
        y <- wrank(y, rep(1, NROW(y)))
    }
    xb <- sum(wx * x)/sum(wx)
    yb <- sum(wy * y)/sum(wy)
    numerator <- sum(wxy * (x - xb) * (y - yb))
    denom <- sqrt(sum(wx * (x - xb)^2) * sum(wy * (y - yb)^2))
    numerator/denom
}

## weighted energy distance
weighted_energy_dist <- function(x, y, wts.x = NULL, wts.y = NULL, gamma = -1)
{
    x   <- as.matrix(x)
    y   <- as.matrix(y)
    n.x <- NROW(x)
    n.y <- NROW(y)
    
    if (is.null(wts.x))
    {
        wts.x <- rep(1, n.x)
    }
    if (is.null(wts.y))
    {
        wts.y <- rep(1, n.y)
    }
    
    weights.x <- wts.x / mean(wts.x)
    weights.y <- wts.y / mean(wts.y)
    
    ( -2 *  rbf_dist(x, y, weights.x, weights.y, gamma = gamma) +
            rbf_dist(x, x, weights.x, weights.x, gamma = gamma) +
            rbf_dist(y, y, weights.y, weights.y, gamma = gamma)
    ) / gamma[1]
}

## requires the fields package
rbf_dist <- function(x, y, weights.x = NULL, weights.y = NULL, gamma = -1)
{
    x   <- as.matrix(x)
    y   <- as.matrix(y)
    n.x <- NROW(x)
    n.y <- NROW(y)
    
    if (is.null(weights.x))
    {
        weights.x <- rep(1, n.x)
    }
    if (is.null(weights.y))
    {
        weights.y <- rep(1, n.y)
    }
    
    weights.x <- weights.x / mean(weights.x)
    weights.y <- weights.y / mean(weights.y)
    
    if (gamma < 0)
    {
        rd <- rdist(x, y)
    } else
    {
        rd <- exp(-gamma * rdist(x, y) ^ 2)
    }
    
    sum(weights.x * t(weights.y * t(rd))) / (n.x * n.y)
}


## A: treatment
## y: response
## weights: weights
## Aseq: new points to obtain estimates of E(Y(A))
kernel_est <- function(A, y, weights, Aseq)
{
    require(locfit)
    
    
    dfx <- data.frame(Y = y, TRT = A)
    locpoly_fit <- locfit(y ~ lp(A), weights = weights, data = dfx)
    
    estimated <- unname(locfit:::predict.locfit(locpoly_fit, 
                                                newdata = Aseq,
                                                where = "fitp"))
    estimated
}


wls_est <- function(A, y, weights)
{
    wls_fit <- lm(y ~ A, weights = weights)
    wls_fit
}


#######
####### Kennedy, et al (2017) method

kennedy_etal <- function(Y, A, X, Aseq, treat_mod = c("Normal", "Gamma"))
{
    treat_mod <- match.arg(treat_mod)
    data <- data.frame(Y = Y, A = A, X = X)
    trt_data <- data.frame(A = A, X = X)
    formula_t <- as.formula("A ~ .")
    if (treat_mod == "Normal") {
        result <- lm(formula = formula_t, data = trt_data)
        gps_fun_Normal <- function(tt) {
            dnorm(tt, mean = result$fitted, sd = summary(result)$sigma)
        }
        avg_density_fun <- function(tt) {
            dnorm(tt, mean = mean(result$fitted), sd = summary(result)$sigma)
        }
        gps_fun <- gps_fun_Normal
    } else if (treat_mod == "Gamma") {
        result <- glm(formula = formula_t, family = Gamma(link = "log"), 
                      data = trt_data)
        est_treat <- result$fitted
        shape_gamma <- as.numeric(MASS::gamma.shape(result)[1])
        theta_given_X <- result$fitted.values/shape_gamma
        theta_treat_X <- trt_data$A / shape_gamma
        gps_fun_Gamma <- function(t) {
            dgamma(t, shape = shape_gamma, scale = theta_given_X)
        }
        avg_density_fun <- function(tt) {
            sapply(tt, function(t) mean(dgamma(t, shape = shape_gamma, scale = theta_given_X)) )
        }
        gps_fun <- gps_fun_Gamma
    }
    
    y_formula <- as.formula("Y ~ A + .")
    
    outcome_mod <- lm(y_formula, data = data)
    
    mu_x_a <- unname(outcome_mod$fitted)
    
    cmx <- colMeans(X)
    xm <- matrix(rep(cmx, nrow(data)), ncol = length(cmx), byrow = TRUE)
    
    pred_data <- data.frame(Y = Y, A = A, xm)
    colnames(pred_data) <- colnames(data)
    
    mean_over_X <- function(t)
    {
        unname(drop(predict(outcome_mod, newdata = pred_data)))
    }
    
    pseudo_outcome <- drop(unname(avg_density_fun(A) * (Y - mu_x_a) / gps_fun(A) + mean_over_X(A)))
    
    
    dfx <- data.frame(Y = pseudo_outcome, TRT = A)
    locpoly_fit <- locfit(Y ~ lp(A), data = dfx)
    
    estimated <- unname(locfit:::predict.locfit(locpoly_fit, 
                                                newdata = Aseq,
                                                where = "fitp"))
    
    list(fit = locpoly_fit, estimated = estimated)
}
