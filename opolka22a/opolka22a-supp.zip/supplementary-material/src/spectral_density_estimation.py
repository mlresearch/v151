import numpy as np
from pygsp import graphs
import networkx as nx
from scipy.interpolate import PchipInterpolator
import matplotlib.pyplot as plt

from multiscale_stochastic_block_model import sample_multiscale_graph


def gamma(j, a, b):
    if j == 0:
        return 1.0 / np.pi * (np.arccos(a) - np.arccos(b))
    return 2.0 / np.pi * ((np.sin(j * np.arccos(a)) - np.sin(j * np.arccos(b))) / j)


def g(j, p):
    alpha_p = np.pi / (p + 2.0)
    g_j_p = ((1.0 - (j / (p + 2))) * np.sin(alpha_p) * np.cos(j * alpha_p) + 1.0 / (p + 2) * np.cos(alpha_p) * np.sin(j * alpha_p)) / np.sin(alpha_p)
    return g_j_p


def chebyshev(degree, adj_mat):
    if degree == 0:
        return np.eye(len(adj_mat))
    if degree == 1:
        return adj_mat
    mat = 2 * np.matmul(adj_mat, chebyshev(degree-1, adj_mat)) - chebyshev(degree-2, adj_mat)
    return mat


def recursive_w(matrix, vec, w_j, w_jj):
    if w_j is None:
        return vec              # j = 0
    if w_jj is None:
        return matrix @ vec     # j = 1
    return 2.0 * matrix @ w_j - w_jj


def estimate_number_eigenvals(matrix, degree, num_samples, a, b):
    vals = []
    for _ in range(num_samples):
        vec = np.random.normal(0.0, 1.0, size=len(matrix))
        w_j = None
        w_jj = None
        val = 0.0
        for j in range(degree):
            # Compute recursive w
            w = recursive_w(matrix, vec, w_j, w_jj)
            w_jj = w_j
            w_j = w
            # Compute value for current degree
            g_j_p = g(j, degree)
            gamma_j = gamma(j, a, b)
            val += g_j_p * gamma_j * vec.T @ w
        vals.append(val)
    return np.mean(vals)


def estimate_spectral_density(matrix, num_steps, degree, num_samples, plot=False):
    steps = np.linspace(-1.0, 1.0, num_steps)
    # print(steps)
    mus = []
    for b in steps:
        mu = estimate_number_eigenvals(matrix, degree, num_samples, -1.0, b)
        mus.append(mu)
        print(b, mu)

    inter = PchipInterpolator(steps, np.array(mus))
    spectral_density = inter.derivative()

    if plot:
        plt.xlabel("eigenvalue")
        plt.ylabel("cumulative spectral density")
        plt.title("Estimated cumulative spectral density")
        plt.plot(steps, inter(steps))
        plt.show()
    return spectral_density


def get_approximation_projection_matrix(matrix, degree, num_steps, sd_steps, sd_degree, sd_samples,
                                        plot=False):
    """
    We aim to compute the polynomial approximation of the filter function at linearly spaced
    points on the real line with higher weights where there are more eigenvalues on that
    line. This can be done by projecting the unapproximated filter function values y at the
    linearly spaced points using the weighted projection matrix to get polynomial coefficients
        c = [V^T W V]^-1 V^T y = P y,
    where V is the Vandermonde matrix, i.e.
        [[1     x1      x1^2        x1^3        ...]
         [1     x2      x2^2        x2^3        ...]
         [1     x3      x3^2        x3^3        ...]]
    and W is a diagonal matrix with the weights of the points on the real line.
    """
    ls = np.linspace(-1.0, 1.0, num_steps)
    V = np.vander(ls, N=degree+1, increasing=True)
    spectral_density = estimate_spectral_density(matrix, sd_steps, sd_degree, sd_samples, plot)
    W = spectral_density(ls)
    W = np.diag(W / np.sum(W))
    P = np.linalg.inv(V.T @ W @ V) @ V.T @ W
    return P


if __name__ == '__main__':
    graph = sample_multiscale_graph()
    graph = graphs.Graph(nx.adj_matrix(graph, nodelist=sorted(list(graph))).todense())

    graph.compute_laplacian("normalized")
    L = graph.L.toarray()
    L = L - np.eye(len(L))
    eigvals, eigvecs = np.linalg.eig(L)
    eigvals = np.real(eigvals)

    # estimate_spectral_density(L, 15, degree=30, num_samples=500)
    print(get_approximation_projection_matrix(L, 5, len(L) // 8, len(L) // 2, 30, 500).shape)