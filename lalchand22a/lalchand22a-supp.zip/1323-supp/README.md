# Generalised-GPLVM 

Generalised GPLVM with SVI

Code Organisation:

  * `models/` contains model classes 
  * `experiments/` contains experiment scripts for each dataset
  * `utils/` contains helpers for configs, visualisation and data loading
  * `data/` contains data files


Functionality:

-Demonstrating Point, MAP models on high-dimensional datasets \
-Demonstrating bGPLVM-SVI on high-dimensional datasets \
-Demonstrating AE-bGPLVM-SVI (Auto-encoded bGPLVM) on high-dimensional datasets \
-Demonstrating bGPLVM-SVI on massively missing data \

