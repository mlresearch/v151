import pandas as pd
import tqdm

from utils.enums import *
from utils.utilities import *
from queue import PriorityQueue

class UserHistory(object):  # this organizes the transaction history of a user in increasing temporal order
    def __init__(self, interactions):
        self.interactions = interactions  # each element is a pair (item, time) -- remove duplicates
        self.interactions.sort(key = lambda x: x[1])  # sort them in temporal order
        self.item2pos = {}
        self.reserve = DataMode.train.name  # by default: all users belong to the train set -- we will re-partition later into train, validate and test
        for i in range(len(self.interactions)):  # create the map from item to a set of positions in the history
            if self.interactions[i][0] not in self.item2pos:
                self.item2pos[self.interactions[i][0]] = {i}
            self.item2pos[self.interactions[i][0]].add(i)

    def similar_to_item(self, item, window = 5):  # generate co-purchased items to a given item within a window-hop
        if item not in self.item2pos:
            return None
        positions = list(self.item2pos[item])  # the position of the item in the history
        if len(positions) <= 1 and positions[0] == 0:
            return None
        pos = 0
        while pos == 0:
            pos = positions[np.random.choice(np.arange(0, len(positions)))]
        choice = np.random.choice(np.arange(max(0, pos - window), pos))  # look backward window hops, pick one at random
        return self.interactions[choice][0]  # return the corresponding item ID


class InteractionDataLoader(object):
    def __init__(self, interaction_data, n_pair_per_item = 10, batch_size = 1000, K = 25, timecut = -1, verbal = True):
        self.verbal = verbal
        self.timecut = timecut
        self.K = K

        announce("Loading Interaction Data ...", verbal = self.verbal)
        self.user_item_data = pd.read_csv(interaction_data, index_col = 0)  # (item_id, user_id, timestamp) in excel file, read into a data frame

        self.num_items = self.user_item_data.ITEM_ID.unique().shape[0]
        self.num_users = self.user_item_data.USER_ID.unique().shape[0]

        announce("Building User2Item, Item2User and Item2Code Mappings ...", verbal = self.verbal)
        self.users, self.items, self.item2code, self.release_dates, self.milestones = self.build_item_user_dict()  # item2code mapping is built on the entire interaction set

        if self.timecut < 0:
            self.timecut = self.milestones[-1] + 10

        self.top_items, self.interaction_counts = [], {}
        self.C = {}  # store the co-occurrence count
        self.n_consecutive_pair = 0
        self.positive = set()

    def build_item_user_dict(self):  # item2code: item_id -> unique code; items: item_id -> set of unique users who bought it, users: user_id -> history of transaction
        users, items, item2code = dict(), dict(), dict()
        release, milestones = dict(), []
        n_item = 0
        for i, row in enumerate(tqdm.tqdm(self.user_item_data.itertuples())):
            user_id, item_id, time = int(row[1]), int(row[2]), int(row[3])
            if item_id not in release:
                release[item_id] = time
            release[item_id] = min(time, release[item_id])
            record(users, user_id, (item_id, time))
            record(items, item_id, user_id)
            if item_id not in item2code:
                item2code[item_id] = n_item
                n_item += 1
        for item_id in release:
            milestones.append(release[item_id])
        milestones.sort()
        organized_user = dict()
        for user_id in tqdm.tqdm(users.keys()):
            organized_user[user_id] = UserHistory(list(users[user_id]))
        return organized_user, items, item2code, release, milestones

    def user_random_partition(self, train = 0.8, validate = 0.1, test = 0.1):  # partition the set of users into train, validate and test partitions
        for user_id in self.users.keys():
            bias = np.random.random()
            if train + validate >= bias > train:
                self.users[user_id].reserve = DataMode.validate.name
            elif bias > train + validate:
                self.users[user_id].reserve = DataMode.test.name
            else:
                self.users[user_id].reserve = DataMode.train.name

    def extract_stats_per_item(self, item_id):  # count consecutive pairs (u,v) for which u = item_id or v = item_id
        for user_id in self.items[item_id]:  # for each user who interacted with item_id
            h = self.users[user_id]
            if h.reserve == DataMode.test.name:  # if the user is reserved for training & validation
                continue
            positions = h.item2pos[item_id]  # get the positions that the item appears in his/her history
            for pos in positions: # for each item
                if pos + 1 < len(h.interactions):  # if there is a next item
                    (u, v) = (min(item_id, h.interactions[pos + 1][0]), max(item_id, h.interactions[pos + 1][0]))  # re-order the pair so that u < v
                    if self.release_dates[u] <= self.timecut and self.release_dates[v] <= self.timecut:  # if both items appear before a certain time
                        self.n_consecutive_pair += 1  # increase the no. of consecutive pairs
                        count(self.C, (u, v))

    def extract_stats(self):
        self.C = {}  # C[(u, v)] is the no. of (train) users who interacted with u and v consecutively (u < v)
        self.n_consecutive_pair = 0  # we will also compute the total no. of consecutive pairs (u, v) across all users
        item_list = list(self.items.keys())  # get the item catalogue
        for i in tqdm.tqdm(range(len(item_list))):  # for each item in the catalogue
            item_id = item_list[i]
            if self.release_dates[item_id] <= self.timecut: # only extract stats for items that appear before a certain time
                self.extract_stats_per_item(item_id)  # count for it

    def extract_top_items(self, K = 25):  # getting the top K items with most interactions coming from users reserved for training
        q = PriorityQueue()
        interaction_counts = {}  # interaction count is over the entire dataset (not just trained users) -- this statistics does not participate in ranking the items
        for item_id in self.items:
            n_interaction = 0
            interaction_counts[item_id] = 0
            if self.release_dates[item_id] > self.timecut:  # only count within a given time threshold
                continue
            for user_id in self.items[item_id]:  # for each user who interacted with the item
                h = self.users[user_id]  # access the his/her history of interaction
                interaction_counts[item_id] += 1  # update the overall count
                if h.reserve != DataMode.test.name:
                    n_interaction += 1  # increase the count used for top-K ranking only if the user is not reserved for testing
            if len(q.queue) < K:  # if the queue still has room
                q.put((n_interaction, item_id))  # put the candidate in
            elif q.queue[0][0] < n_interaction:  # if this candidate is better than the worst candidate in the rec list
                _ = q.get()  # pop it
                q.put((n_interaction, item_id))  # then, put the better one in
        res = []
        while not q.empty():  # now, we flush the queue one item at a time
            (_, candidate) = q.get()
            res.append(candidate)  # add them to the list -- this list will start with the worst at the left most position
        return res[::-1], interaction_counts  # reverse the list so it starts with the best at the left most position

    def sample(self, user_id, item_list, pair_per_user = 10, window = 4):  # sample a pair of items co-bought by user_id, and a random pair
        pair_ids, pair_sims = [], []
        h = self.users[user_id]

        candidate = []  # here are the set of candidate for positive pairs of items
        for i in range(1, len(h.interactions)):
            if self.release_dates[h.interactions[i][0]] <= self.timecut: # none of which should happen after time-cut
                candidate.append(i)
        if len(candidate) < 2:
            return pair_ids, pair_sims
        candidate = np.asarray(candidate)

        for i in range(pair_per_user):
            pos = np.random.choice(candidate)  # pick any to be the anchor item
            item = h.interactions[pos][0]  # here is the anchor item ID
            pos_item = item
            n_attempt = 0
            while pos_item == item or self.release_dates[pos_item] > self.timecut:
                pos_item = h.similar_to_item(item, window = window)  # sample a positive item w.r.t the above anchor item
                n_attempt += 1
                if n_attempt > 10:
                    break
            if pos_item == item or self.release_dates[pos_item] > self.timecut:
                continue
            pair_ids.append([item, pos_item])  # here is the positive pair
            pair_sims.append(0)  # Y = 0 means this is a similar pair
            self.positive.add((item, pos_item))
            self.positive.add((pos_item, item))
            neg_item = pos_item
            while (item, neg_item) in self.positive or (neg_item, item) in self.positive:
                neg_item = np.random.choice(item_list)  # sample a random item from the full item list
            pair_ids.append([item, neg_item])  # here is the negative pair
            pair_sims.append(1)  # Y = 1 means this is a random pair
        return pair_ids, pair_sims

    def pairing_data(self, reserve = DataMode.train.name, pair_per_user = 10, window = 4):  # generate pair data, 10 positive + 10 negative pairs per user
        self.positive = set()
        pair_items, pair_labels = [], []
        item_list = []
        for item_id in self.items:
            if self.release_dates[item_id] <= self.timecut:
                item_list.append(item_id)
        sampled_user = list(self.users.keys())
        for i, user_id in enumerate(tqdm.tqdm(sampled_user)):  # for each user_id
            if self.users[user_id].reserve == reserve and len(self.users[user_id].interactions) > 1:  # if the user is in the corresponding partition (train/validate/test)
                pair_ids, pair_sims = self.sample(user_id, item_list, pair_per_user = pair_per_user, window = window)  # sample pairs
                pair_items += pair_ids  # put those in the global pair dataset for "reserve" partition
                pair_labels += pair_sims
        return pair_items, pair_labels  # return the pair dataset as well the list of triplets