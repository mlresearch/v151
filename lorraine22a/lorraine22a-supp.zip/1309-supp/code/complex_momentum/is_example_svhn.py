"""Check that the Inception Score (IS) is high for the "true" data distribution (the SVHN training set).

Example
-------
python is_example_svhn.py
"""
import os
import sys
sys.path.insert(0, 'wgan_stuff/wgan-gp')
import ipdb

from torchvision import datasets

# Local imports
from tflib import inception_score

svhn_trainset = datasets.SVHN(root='data', split='train', download=True, transform=None)
train_images = svhn_trainset.data  # This is a numpy array of type uint8, with min value 0, max value 255
train_images = train_images.transpose(0, 2, 3, 1)  # Switches from (73257, 3, 32, 32) to (73256, 32, 32, 3)

svhn_testset = datasets.SVHN(root='data', split='test', download=True, transform=None)
test_images = svhn_testset.data  # This is a numpy array of type uint8, with min value 0, max value 255
test_images = test_images.transpose(0, 2, 3, 1)  # Switches from (73257, 3, 32, 32) to (73256, 32, 32, 3)

print('Running Inception on the SVHN training set...')
train_is = inception_score.get_inception_score(list(train_images))
print('Inception Score (SHVN Trainset): {}'.format(train_is))

print('Running Inception on the SVHN test set...')
test_is = inception_score.get_inception_score(list(test_images))
print('Inception Score (SVHN Testset): {}'.format(test_is))
