from models.patch_gan.patch_gan import PatchGAN, PatchGANFC
