import os

os.environ['XLA_PYTHON_CLIENT_PREALLOCATE'] = 'false'
import sys
from train_gan_scale import main as run_experiment
from argparams import collect_params
import numpy as np
import cmath
import GPUtil as GPU
import copy


def create_grid(args):
    grid_up = args.grid_up
    grid_low = args.grid_low
    grid_size = args.grid_size
    if args.args_B_LR == '':
        args_B_LR_list = [np.pi / 8., 0.0]
    else:
        args_B_LR_list = eval(args.args_B_LR)
    argss = []
    for args_B_LR in args_B_LR_list:  # [np.pi / 8., 0.0]:
        # for mag_lr in np.exp(np.linspace(-5.0, -3.5, num=grid_size)):  # grid_size):
        for i, mag_lr in enumerate(np.exp(np.linspace(grid_low, grid_up, num=grid_size))):  # grid_size):
            # print(f'{np.log(mag_lr)} - {mag_lr}')
            for mag_B in np.linspace(0, 1.0, num=grid_size):  # grid_size):
                lr = cmath.rect(mag_lr, args_B_LR)
                complex_momentum = cmath.rect(mag_B, args_B_LR)
                args.G_lr = np.round(lr, decimals=6)
                args.D_lr = np.round(lr, decimals=6)
                args.momentum_mass = np.round(np.real(complex_momentum), decimals=6)
                args.momentum_mass_complex = np.round(np.imag(complex_momentum), decimals=6) * 1.j
                argss.append(copy.deepcopy(args))
    return argss


def command_line(argss):
    for arg in argss:
        string = f'python {sys.argv[0]}'
        for k, v in vars(arg).items():
            if k == 'args_B_LR' or k == 'grid_up' or k == 'grid_size' or k == 'args_LR_multiplier':
                # these are not global ignoring...
                continue

            if isinstance(v, bool):
                if v is True:
                    string = f'{string} --{k} '
            else:
                if isinstance(v, complex):
                    string = f'{string} --{k}={np.real(v)}+{np.imag(v)}j'
                else:
                    string = f'{string} --{k}={v}'

        string = f'{string}  --singleton'
        print(string)


# HOW TO USE:
# install gnu parallel
# conda install -c conda-forge parallel
# parallel --citation [then write will cite].
# ---
# python run_grid.py | parallel --results --eta  --jobs 10 --keep-order --line-buffer "eval {}"
# debug
# python run_grid.py | parallel --eta  --jobs 10 --keep-order --line-buffer --dryrun "eval {}"


####Example...
# python run_grid.py --eid=grid_low_-10_up-4 --grid_low=-10.0 --grid_up=-4 --no_improvement_after=10 --n_epochs=85000  | parallel --eta  --jobs 10 --keep-order --line-buffer "eval {}"

def main():
    args = collect_params()
    if args.singleton is False:
        from signal import signal, SIGPIPE, SIG_DFL
        # Ignore SIG_PIPE and don't throw exceptions on it... (http://docs.python.org/library/signal.html)
        signal(SIGPIPE, SIG_DFL)
        argss = create_grid(args)
        command_line(argss)
    else:
        print('Running singleton...')
        print('---GPU---')
        print(GPU.showUtilization())
        print('---GPU---')
        npr = np.random.RandomState(0)
        z_test = npr.normal(size=(100000, args.z_dim))
        run_experiment(args, z_test)


if __name__ == "__main__":
    main()
