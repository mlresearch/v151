# Code



## Set Up on Unix

1. Download conda at https://docs.conda.io/en/latest/
2. run `conda create -n harmonic python=3.8` in the `jhi_calculator` package
3. run `conda activate harmonic` to enter the conda env



## Experiments

Smaller experiments can be found in jupyter notebooks in the `notebooks` folder. 

Larger CELBA experiments are run using `celeba_high_res.py`

  

## Lipschitz estimation 

All notebooks and python scripts save models in the required `.mat` format for the LipSDP tool (https://github.com/arobey1/LipSDP). 

The tool in that package can then just be pointed to the saved encoder and decoder `.mat` files. 

**For instance:**   

`python solve_sdp.py --form neuron --weight-path examples/saved_weights/decoder_weights.mat`

