

import numpy as np
import cvxpy as cp

from environment.LinBandit_env import LinBandit_env

import sys
sys.path.append("..")

class LinGapE_Sampling(object):
    
    '''
    d = num_dims
    sigma = sig
    K = num_arms
    # S = np.linalg.norm(theta_star)
    reg = 1.0                   # ridge regression param
    #epsilon = 2*(1-np.cos(0.01))
    #epsilon = 0.003          # for environment 5, 10 arms, dim 2, classical 3 arms
    #epsilon = 0.05          # for environment 5, 20 arms, dim 2, classical 3 arms
    #epsilon = 0.05          # for environment 6, dim 4
    #epsilon = 0.09           # for environment 7, dim 6
    #epsilon = 0.1             # for environment 8, dim 8
    #epsilon = 0.3             # for environment 8, dim 8
    epsilon = 0.4             # for environment 9, dim 12
    #delta = 0.05   
    #print(delta)             # with error probab at most delta
    #theta = theta_star
    #best_arm_set = [best_arm]    # include all epsilon-good arms
    '''
    
    def __init__(self, env, epsilon):
        '''
        Constructor
        '''
        self.T = env.T
        self.num_trials = env.num_trials
        self.num_dims = env.num_dims
        self.num_arms = env.num_arms
        self.reg = 1.0
        
        
        
        self.sigma = env.sigma
        self.theta_star = env.theta_star
        self.best_arm = env.best_arm
        self.X = env.X
        self.delta = env.delta
        
        
        #self.epsilon = env.epsilon*0.5  #half of environment's epsilon
        #0.8 gives desiredrsult
        
        #self.epsilon = env.epsilon*0.5
        self.epsilon = env.epsilon*0.8
        #self.epsilon = 0.0
        #self.epsilon = epsilon  #custom epsilon
        self.env = env
        
    
    def init_LinGapE_Sampling(self, env):
            
        self.theta_star = env.theta_star
        self.best_arm = env.best_arm
        self.X = env.X
        #self.epsilon = env.epsilon*0.5
        




    def confidence_bound(self, x, A, t):
        L = 1
        tmp = np.sqrt(x.dot(np.linalg.inv(A)).dot(x))
        return tmp * (self.sigma * np.sqrt(self.num_dims * np.log(self.num_arms * self.num_arms * (1 + t * L * L) / self.reg / self.delta)) + np.sqrt(self.reg) * 2)
    
    
    def decide_arm(self, y, A):
        tmp = [y.dot(np.linalg.inv(A + self.matrix_dot(x))).dot(y)
               for x in self.X]
        # print tmp
        return np.argmin(tmp)
    
    
    def matrix_dot(self, a):
        return np.expand_dims(a, axis=1).dot(np.expand_dims(a, axis=0))

    def run_LinGAPe(self):
        
        error_LinGapE = np.zeros(self.T)       # recording if bestarm identified
        error_estLinGapE = np.zeros(self.T)
    
        A = np.eye(self.num_dims) * self.reg               # design matrix
        b = np.zeros(self.num_dims)                   # arm pulled scaled by reward recvd
        arm_selections = np.ones(self.num_arms)       # record number of pulls
        t = self.num_arms
    
        for i in range(self.num_arms):
            A += self.matrix_dot(self.X[i])
            r = (self.theta_star.dot(self.X[i]) + np.random.randn() * self.sigma)
            b += self.X[i] * r
    
        error_LinGapE[:t] = 1.0
    
        theta_hat = np.linalg.solve(A, b)
        est_reward = self.X.dot(theta_hat)
        it = np.argmax(est_reward)
        jt = np.argmax(est_reward - est_reward[it] +
                    np.array([self.confidence_bound(x - self.X[it], A, t) for x in self.X]))
        B = est_reward[jt] - est_reward[it] + self.confidence_bound(self.X[it] - self.X[jt], A, t)
        #p_star = lingapE_opt(it, jt, X, K)
    
        while B > self.epsilon:
    
            # Greedy Way
            a = self.decide_arm(self.X[it] - self.X[jt], A)
    
            # Optimization way
            # if t%20 == 0:
            #   p_star = lingapE_opt(it, jt, X, K)
            # a = np.argmin(arm_selections/p_star)
    
            A += self.matrix_dot(self.X[a])
            r_t = self.theta_star.dot(self.X[a]) + np.random.randn() * self.sigma
            b += self.X[a] * r_t
            arm_selections[a] += 1
            t += 1
            
            #if t%20 == 0:
            theta_hat = np.linalg.solve(A, b)
            est_reward = self.X.dot(theta_hat)
            increasing = np.argsort(est_reward)
            it = np.argmax(est_reward)
            jt = np.argmax(est_reward - np.max(est_reward) +
                        np.array([self.confidence_bound(x - self.X[it], A, t) for x in self.X]))
            B = est_reward[jt] - est_reward[it] + self.confidence_bound(self.X[it] - self.X[jt], A, t)
    
            if it not in self.env.best_arm_set:
                error_LinGapE[t-1] = 1 #calculate error
            
            error_estLinGapE[t-1] = np.linalg.norm(theta_hat - self.theta_star, ord=1)
    
            if t%1000 == 0:
                print(t, B, increasing[-5:], np.linalg.norm(theta_hat - self.theta_star, ord=1))
    
            if t>= self.T:
                break
        return error_LinGapE, arm_selections, error_estLinGapE

    
    def run_LinGapE_Sampling(self):
    
        self.total_error_LinGapE = []
        self.total_arm_selection = []
        self.total_error_est_LnGapE = []

        
        for tr in range(self.num_trials):
            np.random.seed(tr)
            
            '''
            env = self.env.LinBandit_env1(tr, self.num_dims, self.num_arms)
            self.init_LinGapE_Sampling(env)
            '''
            trial_error, arm_selection_trial, est_trial = self.run_LinGAPe()
            self.total_error_LinGapE.append(trial_error)
            self.total_arm_selection.append(arm_selection_trial)
            self.total_error_est_LnGapE.append(est_trial)
        
            print(tr, end=', ')
            if tr % 25 == 0:
                print()


'''
if __name__ == "__main__":
    
    total_error_LinGapE = []
    total_arm_selection = []
    total_error_est_LnGapE = []

    trials = num_trials
    
    for tr in range(trials):
        np.random.seed(tr)
        trial_error, arm_selection_trial, est_trial = run_LinGAPe()
        total_error_LinGapE.append(trial_error)
        total_arm_selection.append(arm_selection_trial)
        total_error_est_LnGapE.append(est_trial)

        print(tr, end=', ')
        if tr % 25 == 0:
            print()
'''