from itertools import chain

import torch
from fairseq.logging import metrics
from fairseq.models import register_model_architecture, register_model
from fairseq.models.transformer import TransformerEncoder, TransformerEncoderLayer, \
    TransformerDecoder, TransformerDecoderLayer, TransformerModel, base_architecture
from fairseq.modules import LayerNorm
from fairseq.optim import register_optimizer, FairseqOptimizer
from fairseq.optim.adam import FairseqAdamConfig, FairseqAdam
from fairseq.tasks import register_task
from fairseq.tasks.translation import TranslationTask
from torch.optim import Adam

from multihead_attention import MultiheadAttention
from partitioned_linear import PartitionedLinear, PartitionedModel, PartitionedLayerNorm, PartitionedRankLinear, \
    PartitionedOrthogonalRankLinear, PartitionedRedundantLinear, PartitionedScaledRankLinear


class MultiheadAttentionWithCorrectParameters(MultiheadAttention):
    def forward(
            self,
            query,
            key,
            value,
            key_padding_mask = None,
            incremental_state = None,
            need_weights = True,
            static_kv = False,
            attn_mask = None,
            before_softmax = False,
            need_head_weights = False
    ):
        assert not before_softmax
        x, attn = super().forward(
            query,
            key,
            value,
            key_padding_mask=key_padding_mask,
            incremental_state=incremental_state,
            need_weights=need_weights,
            static_kv=static_kv,
            attn_mask=attn_mask,
            need_head_weights=need_head_weights
        )
        if need_head_weights:
            attn = attn.transpose(0, 1)
        return x, attn


class TransformerEncoderLayerWithPartitionedLinear(TransformerEncoderLayer):
    def __init__(self, args):
        self.ratios = args.ratios
        self.args = args
        super().__init__(args)
        if args.partition_layer_norm:
            self.self_attn_layer_norm = PartitionedLayerNorm(LayerNorm, self.embed_dim, ratios=self.ratios)
            self.final_layer_norm = PartitionedLayerNorm(LayerNorm, self.embed_dim, ratios=self.ratios)

    def build_self_attention(self, embed_dim, args):
        return MultiheadAttentionWithCorrectParameters(
            args,
            embed_dim,
            args.encoder_attention_heads,
            dropout=args.attention_dropout,
        )

    def build_fc1(self, input_dim, output_dim, q_noise, qn_block_size):
        if self.args.partition_both:
            return self.args.partitioned_linear_module(input_dim, output_dim, in_ratios=self.ratios, ratios=self.ratios)
        elif self.args.partition_input:
            return self.args.partitioned_linear_module(input_dim, output_dim, in_ratios=self.ratios)
        else:
            return self.args.partitioned_linear_module(input_dim, output_dim, ratios=self.ratios)

    def build_fc2(self, input_dim, output_dim, q_noise, qn_block_size):
        if self.args.partition_both:
            return self.args.partitioned_linear_module(input_dim, output_dim, in_ratios=self.ratios, ratios=self.ratios)
        else:
            return self.args.partitioned_linear_module(input_dim, output_dim, in_ratios=self.ratios)


class TransformerDecoderLayerWithPartitionedLinear(TransformerDecoderLayer):
    def __init__(self, args, no_encoder_attn=False, add_bias_kv=False, add_zero_attn=False ):
        assert no_encoder_attn is False
        assert add_zero_attn is False
        assert add_bias_kv is False
        self.ratios = args.ratios
        self.args = args
        super().__init__(args, no_encoder_attn=no_encoder_attn, add_bias_kv=add_bias_kv, add_zero_attn=add_zero_attn)
        if args.partition_layer_norm:
            export = getattr(args, "char_inputs", False)
            self.encoder_attn_layer_norm = PartitionedLayerNorm(LayerNorm, self.embed_dim, export=export, ratios=self.ratios)
            self.self_attn_layer_norm = PartitionedLayerNorm(LayerNorm, self.embed_dim, export=export, ratios=self.ratios)
            self.final_layer_norm = PartitionedLayerNorm(LayerNorm, self.embed_dim, export=export, ratios=self.ratios)

    def build_self_attention(
        self, embed_dim, args, add_bias_kv=False, add_zero_attn=False
    ):
        return MultiheadAttentionWithCorrectParameters(
            args,
            embed_dim,
            args.decoder_attention_heads,
            dropout=args.attention_dropout,
        )

    def build_encoder_attention(self, embed_dim, args):
        return MultiheadAttentionWithCorrectParameters(
            args,
            embed_dim,
            args.decoder_attention_heads,
            dropout=args.attention_dropout,
        )

    def build_fc1(self, input_dim, output_dim, q_noise, qn_block_size):
        if self.args.partition_both:
            return self.args.partitioned_linear_module(input_dim, output_dim, in_ratios=self.ratios, ratios=self.ratios)
        elif self.args.partition_input:
            return self.args.partitioned_linear_module(input_dim, output_dim, in_ratios=self.ratios)
        else:
            return self.args.partitioned_linear_module(input_dim, output_dim, ratios=self.ratios)

    def build_fc2(self, input_dim, output_dim, q_noise, qn_block_size):
        if self.args.partition_both:
            return self.args.partitioned_linear_module(input_dim, output_dim, in_ratios=self.ratios, ratios=self.ratios)
        else:
            return self.args.partitioned_linear_module(input_dim, output_dim, in_ratios=self.ratios)


class TransformerDecoderWithPartitionedLinear(TransformerDecoder):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        assert self.project_in_dim is None
        assert self.project_out_dim is None
        if self.output_projection is not None and self.args.partition_final_proj:
            assert self.share_input_output_embed is not True
            self.output_projection = self.args.partitioned_linear_module(
                self.output_embed_dim, len(self.dictionary), bias=False,
                in_ratios=self.args.ratios
            )

    def build_decoder_layer(self, args, no_encoder_attn=False):
        return TransformerDecoderLayerWithPartitionedLinear(args, no_encoder_attn)


class TransformerEncoderWithPartitionedLinear(TransformerEncoder):

    def build_encoder_layer(self, args):
        return TransformerEncoderLayerWithPartitionedLinear(args)


@register_model("transformer_with_partitioned_linear")
class TransformerModelWithPartitionedLinear(TransformerModel):
    @classmethod
    def build_model(cls, args, task):
        transformer_with_partitioned_linear(args)
        model = super().build_model(args, task)
        model.max_level = len(args.ratios) + 1
        if args.max_level is not None:
            assert args.max_level <= model.max_level
            model.max_level = args.max_level
        PartitionedModel.set_class_active_level(model, model.max_level, args.min_level)
        return model


    @classmethod
    def build_encoder(cls, args, src_dict, embed_tokens):
        return TransformerEncoderWithPartitionedLinear(args, src_dict, embed_tokens)

    @staticmethod
    def add_args(parser):
        TransformerModel.add_args(parser)
        parser.add_argument("--partition", action="store_true", default=False)
        parser.add_argument("--max-level", type=int, default=None)
        parser.add_argument("--min-level", type=int, default=1)
        parser.add_argument("--small-ratio", type=float, default=0.5)
        parser.add_argument("--partition-heads", action="store_true", default=False)
        parser.add_argument("--partition-input", action="store_true", default=False)
        parser.add_argument("--partition-both", action="store_true", default=False)
        parser.add_argument("--partition-layer-norm", action="store_true", default=False)
        parser.add_argument("--partition-v", action="store_true", default=False)
        parser.add_argument("--partition-out-proj", action="store_true", default=False)
        parser.add_argument("--partition-final-proj", action="store_true", default=False)
        parser.add_argument("--disable-decoder-partition", action="store_true", default=False)
        parser.add_argument("--partitioned-linear-module-name", type=str, default="PartitionedLinear")

    @classmethod
    def build_decoder(cls, args, tgt_dict, embed_tokens):
        if not args.disable_decoder_partition:
            return TransformerDecoderWithPartitionedLinear(
                args,
                tgt_dict,
                embed_tokens,
                no_encoder_attn=getattr(args, "no_cross_attention", False),
            )
        else:
            return super().build_decoder(args, tgt_dict, embed_tokens)


@register_model_architecture("transformer_with_partitioned_linear", "transformer_with_partitioned_linear")
def transformer_with_partitioned_linear(args):
    base_architecture(args)
    if getattr(args, "partition", False):
        args.ratios = [getattr(args, "small_ratio", 0.5)]
    else:
        args.ratios = []
    args.max_level = getattr(args, "max_level", None)
    args.min_level = getattr(args, "min_level", 1)
    args.partition_heads = getattr(args, "partition_heads", False)
    args.partition_input = getattr(args, "partition_input", False)
    args.partition_both = getattr(args, "partition_both", False)
    args.partition_layer_norm = getattr(args, "partition_layer_norm", False)
    args.partition_v = getattr(args, "partition_v", False)
    args.partition_out_proj = getattr(args, "partition_out_proj", False)
    args.partition_final_proj = getattr(args, "partition_final_proj", False)
    args.disable_decoder_partition = getattr(args, "disable_decoder_partition", False)
    if args.partition_both:
        assert not args.partition_input

    args.partitioned_linear_module_name = getattr(args, "partitioned_linear_module_name", "PartitionedLinear")
    partitioned_linear_modules = {
        "PartitionedLinear": PartitionedLinear,
        "PartitionedRankLinear": PartitionedRankLinear,
        "PartitionedScaledRankLinear": PartitionedScaledRankLinear,
        "PartitionedOrthogonalRankLinear": PartitionedOrthogonalRankLinear,
        "PartitionedRedundantLinear": PartitionedRedundantLinear
    }
    args.partitioned_linear_module = partitioned_linear_modules[args.partitioned_linear_module_name]


@register_optimizer("adam_for_partitioned_model", dataclass=FairseqAdamConfig)
class FairseqAdamForPartitionedModel(FairseqAdam):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.level = 0
        self.min_level = 1
        self.additional_optimizers = []
        self.lr_factor = 1

    def add_parameter_set(self, params):
        self.additional_optimizers.append(Adam(params, **self.optimizer_config))
        self.level += 1
        assert self.level == len(self.additional_optimizers)

    def set_level(self, level, min_level=1):
        self.level = level
        self.min_level = min_level

    def set_lr_factor(self, lr_factor):
        self.lr_factor *= lr_factor

    def step(self, *args, **kwargs):
        for param_group in self.param_groups:
            param_group['lr'] *= self.lr_factor
        super().step(*args, **kwargs)
        for i in range(self.min_level - 1, self.level):
            self.additional_optimizers[i].step(*args, **kwargs)
        for param_group in self.param_groups:
            param_group['lr'] /= self.lr_factor

    @property
    def param_groups(self):
        return list(chain(super().param_groups, *[opt.param_groups for opt in self.additional_optimizers]))


@register_task('translation_with_partitioned_model')
class TranslationTaskWithPartitionedModel(TranslationTask):


    @staticmethod
    def add_args(parser):
        TranslationTask.add_args(parser)
        parser.add_argument("--alternate", action="store_true", default=False)
        parser.add_argument("--alternate-auto", action="store_true", default=False)
        parser.add_argument("--measure-additional", action="store_true", default=False)
        parser.add_argument("--measure-additional-small", action="store_true", default=False)
        parser.add_argument("--alternate-lr-coef", type=float, default=0.5)
        parser.add_argument("--alternate-large-ratio", type=int, default=1)
        parser.add_argument("--alternate-small-ratio", type=int, default=1)
        parser.add_argument("--alternate-mask", action="store_true", default=False)
        parser.add_argument("--alternate-until", type=int, default=None)

    def train_step(
        self, sample, model, criterion, optimizer, update_num, ignore_grad=False
    ):
        if not getattr(self, "partition_initialized", False):
            print("Initializing Additional Levels")
            for i in range(1, model.max_level + 1):
                optimizer.add_parameter_set(params=PartitionedModel.get_class_level_parameters(model, i))
                print("Added Level {}/{}".format(i, model.max_level))
            self.last_weight_buffer = getattr(self, "last_weight_buffer", {})
            self.last_grad_buffer = getattr(self, "last_grad_buffer", {})
            self.last_grad_small_buffer = getattr(self, "last_grad_small_buffer", {})
            self.last_time_go_small = getattr(self, "last_time_go_small", False)
            self.last_time_first_mask = getattr(self, "last_time_first_mask", False)
            self.disable_alternate = getattr(self, "disable_alternate", False)
            self.partition_initialized = True


        def update_optimizer_lr(opt, coef):
            #for param_group in opt.param_groups:
            #    param_group['lr'] *= coef
            opt.set_lr_factor(coef)

        lr_reduced = self.args.alternate_lr_coef

        if self.last_time_go_small:
            update_optimizer_lr(optimizer, 1 / lr_reduced)
            optimizer.set_level(model.max_level)
            self.last_time_go_small = False

        if not self.disable_alternate and self.args.alternate and \
                update_num % (self.args.alternate_small_ratio + self.args.alternate_large_ratio) >= \
                self.args.alternate_large_ratio:
            go_small = True
        elif self.args.alternate_auto and getattr(self, "last_grad_weight_ratio", 0) > 1 / optimizer.param_groups[0]["lr"]:
            go_small = True
        else:
            go_small = False
        if go_small:
            if self.args.alternate_mask and self.last_time_first_mask:
                PartitionedModel.set_class_active_level(model, model.max_level, 2)
                optimizer.set_level(model.max_level, 2)
                self.last_time_first_mask = False
            else:
                PartitionedModel.set_class_active_level(model, 1)
                optimizer.set_level(1)
                self.last_time_first_mask = True
            update_optimizer_lr(optimizer, lr_reduced)
            self.last_time_go_small = True

        if self.args.measure_additional_small and (update_num + 1) % 50 == 0:
            if not go_small:
                PartitionedModel.set_class_active_level(model, 1)
            for gp in optimizer.param_groups:
                for p in gp['params']:
                    assert p.grad is None or (p.grad == 0).all()
            criterion(model, sample)[0].backward()
            for gp in optimizer.param_groups:
                for p in gp['params']:
                    if p.grad is  None:
                        continue
                    if p not in self.last_grad_small_buffer:
                        self.last_grad_small_buffer[p] = torch.clone(p.grad).detach()
                    else:
                        self.last_grad_small_buffer[p].copy_(p.grad)
            if not go_small:
                PartitionedModel.set_class_active_level(model, model.max_level)
            optimizer.zero_grad()

        if (self.args.measure_additional_small or self.args.alternate_auto) and update_num % 50 == 0:
            if not go_small:
                PartitionedModel.set_class_active_level(model, 1)
            for gp in optimizer.param_groups:
                for p in gp['params']:
                    assert p.grad is None or (p.grad == 0).all()
            small_grad_norm = 0
            criterion(model, sample)[0].backward()
            small_grad_copy = {}
            for p in optimizer.additional_optimizers[0].param_groups[0]['params']:
                if p.grad is not None:
                    small_grad_norm = small_grad_norm + p.grad.norm().item() ** 2
                    small_grad_copy[p] = torch.clone(p.grad).detach()

            if len(self.last_grad_small_buffer) > 0:
                diff_grad_norm_small = 0
                diff_weight_norm_small = 0
                for gp in optimizer.param_groups:
                    for p in gp['params']:
                        if p.grad is None:
                            continue
                        assert not (p.grad == 0).all()
                        diff_grad_norm_small += ((p.grad - self.last_grad_small_buffer[p]).norm() ** 2).item()
                        diff_weight_norm_small += ((p - self.last_weight_buffer[p]).norm() ** 2).item()

            if not go_small:
                PartitionedModel.set_class_active_level(model, model.max_level)
            optimizer.zero_grad()

        out = super().train_step(sample, model, criterion, optimizer, update_num, ignore_grad=ignore_grad)
        out[2]["go_small"] = 1 if go_small else 0

        if (self.args.measure_additional_small or self.args.alternate_auto) and update_num % 50 == 0:
            masked_weight_norm = 0
            for p in optimizer.additional_optimizers[1].param_groups[0]['params']:
                masked_weight_norm = masked_weight_norm + p.norm().item() ** 2

            out[2]["small_grad_over_masked_weight"] = small_grad_norm / masked_weight_norm
            if len(self.last_grad_small_buffer) > 0:
                out[2]["diff_grad_small_over_diff_weight_small"] = diff_grad_norm_small / diff_weight_norm_small
            self.last_grad_weight_ratio = small_grad_norm / masked_weight_norm

            if not go_small:
                grad_norm = 0
                small_grad_dot_masked_grad = 0
                for p in optimizer.additional_optimizers[0].param_groups[0]['params']:
                    if p.grad is not None:
                        grad_norm = grad_norm + p.grad.norm().item() ** 2
                        small_grad_dot_masked_grad = small_grad_dot_masked_grad + torch.dot(p.grad, small_grad_copy[p])

                out[2]["masked_grad_over_small_grad"] = grad_norm / small_grad_norm
                out[2]["small_dot_masked_over_masked"] = small_grad_dot_masked_grad / grad_norm

                grad_norm = 0
                for opt in optimizer.additional_optimizers:
                    for p in opt.param_groups[0]['params']:
                        if p.grad is not None:
                            grad_norm = grad_norm + p.grad.norm().item() ** 2
                out[2]["small_grad_over_full_grad"] = small_grad_norm / grad_norm

        if self.args.measure_additional and update_num % 50 == 0:
            assert not go_small
            if len(self.last_weight_buffer) > 0:
                diff_weight_norm = 0
                diff_grad_norm = 0
                for gp in optimizer.param_groups:
                    for p in gp['params']:
                        if p.grad is None:
                            continue
                        assert p in self.last_weight_buffer
                        diff_grad_norm += ((p.grad - self.last_grad_buffer[p]).norm() ** 2).item()
                        diff_weight_norm += ((p - self.last_weight_buffer[p]).norm() ** 2).item()
                out[2]["diff_grad_over_diff_weight"] = diff_grad_norm / diff_weight_norm

            small_grad_norm = 0
            for p in optimizer.additional_optimizers[0].param_groups[0]['params']:
                if p.grad is not None:
                    small_grad_norm = small_grad_norm + p.grad.norm().item() ** 2

            grad_norm = 0
            for opt in optimizer.additional_optimizers:
                for p in opt.param_groups[0]['params']:
                    if p.grad is not None:
                        grad_norm = grad_norm + p.grad.norm().item() ** 2
            out[2]["masked_grad_over_full_grad"] = small_grad_norm / grad_norm

        if go_small:
            PartitionedModel.set_class_active_level(model, model.max_level)

        if self.args.measure_additional or self.args.measure_additional_small or self.args.alternate_auto:
            for gp in optimizer.param_groups:
                for p in gp['params']:
                    if p not in self.last_weight_buffer:
                        self.last_weight_buffer[p] = torch.clone(p.data).detach()
                        if p.grad is not None:
                            self.last_grad_buffer[p] = torch.clone(p.grad).detach()
                    else:
                        self.last_weight_buffer[p].copy_(p.data)
                        if p.grad is not None:
                            self.last_grad_buffer[p].copy_(p.grad)

        return out

    def reduce_metrics(self, logging_outputs, criterion):
        lasts = {}
        for log in logging_outputs:
            for log_key in [
                "small_grad_over_masked_weight",
                "diff_grad_over_grad",
                "diff_grad_over_diff_weight",
                "diff_grad_small_over_diff_weight_small",
                "small_grad_over_full_grad",
                "masked_grad_over_full_grad",
                "masked_grad_over_small_grad",
                "small_dot_masked_over_masked"
            ]:
                if log_key in log:
                    lasts[log_key] = log[log_key]
        for log_key in lasts:
            metrics.log_scalar(log_key, lasts[log_key], priority=360)
        metrics.log_scalar("go_small", sum(log["go_small"] for log in logging_outputs if "go_small" in log), priority=360)
        super().reduce_metrics(logging_outputs, criterion)

    def begin_epoch(self, epoch, model):
        if self.args.alternate_until is not None and epoch >= self.args.alternate_until:
            self.disable_alternate = True
        else:
            self.disable_alternate = False


@register_task('translation_with_partial_layer_training')
class TranslationTaskWithPartialLayerTraining(TranslationTask):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.last_time_disabled_parameters = []

    @staticmethod
    def add_args(parser):
        TranslationTask.add_args(parser)
        parser.add_argument("--alternate", action="store_true", default=False)
        parser.add_argument("--full-from-epoch", type=int, default=None)
        parser.add_argument("--warmup", type=int, default=None)
        parser.add_argument("--cut-from-layer", type=str, default="encoder.layers.5")

    def begin_epoch(self, epoch, model):
        should_be_disabled = True
        if self.args.full_from_epoch is not None:
            if epoch > self.args.full_from_epoch:
                should_be_disabled = False
        if self.args.alternate:
            if epoch % 2 == 0:
                should_be_disabled = False
        if self.args.warmup and epoch < self.args.warmup:
            should_be_disabled = False
        if should_be_disabled:
            if not self.last_time_disabled_parameters:
                for parameter_name, parameter in model.named_parameters():
                    if parameter_name.startswith(self.args.cut_from_layer):
                        break
                    print("Disabled {}".format(parameter_name))
                    self.last_time_disabled_parameters.append(parameter)
                    parameter.requires_grad = False
        else:
            for p in self.last_time_disabled_parameters:
                p.requires_grad = True
            self.last_time_disabled_parameters = []

