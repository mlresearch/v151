from models.cycle_gan.resnet.resnet import ResNet
