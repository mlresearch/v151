

import sys
sys.path.append("..")

from environment.LinBandit_env import LinBandit_env
from policies.MaxMin_Sampling import MaxMin_Sampling
from policies.Uniform_Sampling import Uniform_Sampling
from policies.LinGapE_Sampling import LinGapE_Sampling
from policies.XY_Static_Sampling import XY_Static_Sampling
from policies.XY_Adaptive_Sampling import XY_Adaptive_Sampling
from policies.XY_Oracle_Sampling import XY_Oracle_Sampling


from plots.plot_sample_complexity import plot_sample_complexity0
from plots.plot_sample_complexity import plot_sample_complexity1
from plots.plot_error_rate import plot_error_rate1

from plots.plot_sample_complexity import plot_sample_complexity2
from plots.plot_error_rate import plot_error_rate2

from util.file_IO import file_IO0
from util.file_IO import file_IO1
from util.file_IO import file_IO2

import pickle
import numpy as np

from multiprocessing import Process
from threading import *

import multiprocessing as mp


def start_process1(env, type, epsilon):
    
    if type == 0:
        maxmin = MaxMin_Sampling(env)
        maxmin.run_MaxMin_Sampling()
        
    if type == 1:
        unif = Uniform_Sampling(env)
        unif.run_Uniform_Sampling()
        
    if type == 2:
        
        lingape = LinGapE_Sampling(env, epsilon)
        lingape.run_LinGapE_Sampling()
        
    if type == 3:
        xy_static = XY_Static_Sampling(env)
        xy_static.run_XY_Static_Sampling()
        
    if type == 4:
        xy_adaptive = XY_Adaptive_Sampling(env)
        xy_adaptive.run_XY_Adaptive_Sampling()

def start_process(seed, dim, arms, epsilon):
    
    env = LinBandit_env()
    env.LinBandit_env2(seed,dim,arms)
    
    #pool = mp.Pool(5)
    #res_list = pool.starmap(start_process1, [(env, i, epsilon) for i in range(0,5)])
    
    maxmin = MaxMin_Sampling(env)
    unif = Uniform_Sampling(env)
    lingape = LinGapE_Sampling(env, epsilon)
    #xy_static = XY_Static_Sampling(env)
    #xy_adaptive = XY_Adaptive_Sampling(env)
    xy_oracle = XY_Oracle_Sampling(env)
    
    
    
    t1 = Thread(target=maxmin.run_MaxMin_Sampling(), args=())
    t2 = Thread(target=unif.run_Uniform_Sampling(), args=())
    t3 = Thread(target=lingape.run_LinGapE_Sampling(), args=())
    #t4 = Thread(target=xy_static.run_XY_Static_Sampling(), args=())
    #t5 = Thread(target=xy_adaptive.run_XY_Adaptive_Sampling(), args=())
    t6 = Thread(target=xy_oracle.run_XY_Oracle_Sampling(), args=())
    
    #thread = Thread(target=self.process(), args=(satellite, time, )) 
    
    t1.daemon = True
    t2.daemon = True
    t3.daemon = True
    #t4.daemon = True
    #t5.daemon = True
    t6.daemon = True
    
    
    t1.start()
    t2.start()
    t3.start()
    #t4.start()
    #t5.start()
    t6.start()
    
    t1.join()
    t2.join()
    t3.join()
    #t4.join()
    #t5.join()
    t6.join()
        
    #top2_err, rand_err, chern_err, njav_err, top2_sample_complexity, rand_sample_complexity, chern_sample_complexity, njav_sample_complexity = file_IO()
        
        
    file = open('linbandit_dim'+str(dim), 'wb')
    # dump information to that file
    
    pickle.dump([[maxmin.mm_armerr, unif.u_armerr, lingape.total_error_LinGapE],[maxmin.mm_T, unif.u_T, np.sum(lingape.total_arm_selection,axis = 1)]],file)
    
    #pickle.dump([[maxmin.mm_armerr, unif.u_armerr, lingape.total_error_LinGapE, xy_oracle.total_error_XY_Oracle],[maxmin.mm_T, unif.u_T, np.sum(lingape.total_arm_selection,axis = 1), np.sum(xy_oracle.total_arm_selection,axis = 1)]],file)
    
    
    
    #pickle.dump([[maxmin.mm_armerr, unif.u_armerr, lingape.total_error_LinGapE, xy_static.total_error_XY_Static, xy_adaptive.total_error_XY_Adaptive],[maxmin.mm_T, unif.u_T, np.sum(lingape.total_arm_selection,axis = 1), np.sum(xy_static.total_arm_selection,axis = 1), np.sum(xy_adaptive.total_arm_selection,axis = 1)]],file)
   
    # close the file
    file.close()
        
    mm_armerr, u_armerr, total_error_LinGapE, mm_T, u_T, total_arm_selection = file_IO0('linBandit_dim'+str(dim))
    
    #mm_armerr, u_armerr, total_error_LinGapE, total_error_XY_Oracle, mm_T, u_T, total_arm_selection, total_arm_selection_xy_oracle = file_IO1('linBandit_dim'+str(dim))
    
    #mm_armerr, u_armerr, total_error_LinGapE, total_error_XY_Static, total_error_XY_Adaptive, mm_T, u_T, total_arm_selection, total_arm_selection_xys, total_arm_selection_xya = file_IO2('linBandit_dim'+str(dim))
    
    #plot_sample_complexity1(mm_T, u_T, total_arm_selection, env.num_arms, env.num_dims, total_arm_selection_xy_oracle, "linBandit_dim"+str(dim))
    #plot_sample_complexity0(mm_T, u_T, total_arm_selection, env.num_arms, env.num_dims, "linBandit_dim"+str(dim))
    
    
    file = open("../main/linBandit_xy_oracle_dim" + str(dim), 'rb')
    data = pickle.load(file)
    file.close()
    total_arm_selection_XY_Oracle = data[1][0]
    plot_sample_complexity1(mm_T, u_T, total_arm_selection, total_arm_selection_XY_Oracle, arms, dim, "linBandit_dim" + str(dim))
    plot_error_rate1(mm_armerr, u_armerr, total_error_LinGapE, env.num_arms, env.num_dims, env.T, "linBandit_dim"+str(dim))
    

        
    #plot_sample_complexity2(mm_T, u_T, total_arm_selection, total_arm_selection_xys, total_arm_selection_xya, env.num_arms, env.num_dims, "linBandit_dim"+str(dim))
    #plot_error_rate2(mm_armerr, u_armerr, total_error_LinGapE, total_error_XY_Static, total_error_XY_Adaptive, env.num_arms, env.num_dims, env.T, "linBandit_dim"+str(dim))

if __name__ == "__main__":
    
    '''
    4 env
    dim = [4, 6, 8, 12]
    seed = [1, 9, 6, 40]
    epsilon = [0.005, 0.09, 0.3, 0.4]
    '''
    
    
    #5 env
    '''
    dim = [4, 6, 8, 10, 12]
    seed = [1, 9, 6, 0, 40]
    epsilon = [0.005, 0.09, 0.3, 0.3, 0.4]
    arms = 20
    '''
    
    # dim 2, seed 55, arms 12
    # dim 10, seed 10, arms 12
    
    '''
    dim = [2, 10]
    seed = [55, 10]
    epsilon = [0.005, 0.4]
    arms = 12
    '''
    
    
    dim = [2, 4, 6, 8, 10, 12]
    seed = [55, 9, 19, 16, 10, 3]
    epsilon = [0.005, 0.09, 0.3, 0.3, 0.4, 0.4]
    arms = 12
    
    '''
    dim = [6, 8, 12]
    seed = [19, 16, 3]
    epsilon = [0.005, 0.09, 0.3]
    arms = 12
    '''
    '''
    dim = [6]
    seed = [40]
    epsilon = [0.005]
    arms = 12
    '''
    p1 = Process(target=start_process, args=(seed[0], dim[0], arms ,epsilon[0]))
    p2 = Process(target=start_process, args=(seed[1], dim[1], arms ,epsilon[1]))
    p3 = Process(target=start_process, args=(seed[2], dim[2], arms, epsilon[2]))
    p4 = Process(target=start_process, args=(seed[3], dim[3], arms, epsilon[3]))
    p5 = Process(target=start_process, args=(seed[4], dim[4], arms, epsilon[4]))
    p6 = Process(target=start_process, args=(seed[5], dim[5], arms, epsilon[5]))
    
    p1.start()
    p2.start()
    p3.start()
    p4.start()
    p5.start()
    p6.start()
    
    
    p1.join()
    p2.join()
    p3.join()
    p4.join()
    p5.join()
    p6.join()
    
    