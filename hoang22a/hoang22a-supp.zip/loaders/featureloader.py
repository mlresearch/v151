import numpy as np

class FeatureDataLoader(object):  # load and organize multiple feature channels over a set of items
    def __init__(self, feature_channels, feature_dims, item2code, verbal = True):
        self.verbal = verbal
        self.feature_channels = feature_channels  # feature_channels: channel_name --> (ID -> feature vector)
        self.feature_dims = feature_dims  # feature_dims: channel_name -> dim
        self.item2code = item2code  # item2code: item_id -> code

    def get_batch(self, channel, item_ids):  # compute the feature matrix for channel with respect to the items in item_ids
        res = []
        for item_id in item_ids:  # for each item_id
            feature = [0.0] * self.feature_dims[channel]  # by default, it is a zero vector (in case it does not have this channel of feature)
            if item_id in self.feature_channels[channel]:  # but if it does:
                feature = list(self.feature_channels[channel][item_id])  # we replace it with the corresponding feature vector
            res.append(feature)  # append it to the feature matrix as a new row
        return np.asarray(res).astype(np.float32)  # convert it to numpy matrix

    def featurize(self, item_ids):  # create one feature matrix for the list of item_ids per channel -- so 5 channels will result in a dictionary with 5 entries
        res = {}  # channel feature dictionary: channel-name -> feature_matrix (one item per row)
        id = np.asarray([self.item2code[item_ids[i]] for i in range(len(item_ids))])  # additionally, there is a id channel -- a matrix of no_item x 1
        for channel in self.feature_dims.keys():  # for each channel
            res[channel] = self.get_batch(channel, item_ids)  # get the feature matrix for that channel and put it in the dictionary
        return res, id  # return the id channel and the dictionary of feature channels

    def get_feature_list(self):  # return the list of channel names
        return list(self.feature_dims.keys())

    def get_dim(self, feature_name):  # get the feature dim for a given feature channel
        if feature_name in self.feature_dims:
            return self.feature_dims[feature_name]
        return None