

from .path_tools import *

def write_train_results(ʆ, fname):
	fin = open(fname, 'w')
	fin.write(ʆ + '\n')
	fin.close()

