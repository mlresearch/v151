

import numpy as np
from multiprocessing import Process
from itertools import combinations

import matplotlib.pyplot as plt


class LinBandit_env(object):
    '''
    classdocs
    '''

    
    # Global init
    num_dims = 0
    num_arms = 0
    sigma = 1.0
    num_trials = 100
    T = 100000
    delta = 0.1
    
    def LinBandit_env1(self, seed, num_dims, num_arms):

        # Good seperation/problem
        #np.random.seed(1)
        
        
        # Uniform and MM is good
        np.random.seed(seed)
        self.num_dims = num_dims
        self.num_arms = num_arms
        
        
        arm_angles = np.random.randint(0,360, self.num_arms - self.num_dims)
        arm_angles = np.concatenate((arm_angles, [0], [90]))
        arm_angles = np.sort(arm_angles)
        #print(arm_angles)
        arm_angle_diff = np.diff(arm_angles)
        #print(np.diff(arm_angles))
        min_angle_index = np.argmin(arm_angle_diff)
        #print(min_angle_index)
        
        self.X = []

        #print(X)
        for i in range(0, self.num_arms):
        
            tmp = np.random.randn(self.num_dims)
            norm = np.linalg.norm(tmp)
            tmp = tmp/norm
            #X = np.r_[X,np.expand_dims(tmp,0)]
            self.X.append(tmp)
          
        self.X = np.array(self.X)
        
        self.theta_star = self.X[min_angle_index] + 0.01*self.X[min_angle_index+1]
        
        print(self.X,self.theta_star,len(self.X))
        print(self.X.dot(self.theta_star))
        
        self.best_arm = np.argmax(self.X@self.theta_star)
        #print(best_arm)
        
        Y2 = self.X@self.theta_star
        self.epsilon = np.abs(Y2[min_angle_index] - Y2[min_angle_index+1])
        print(arm_angle_diff,min_angle_index)
        print(self.epsilon)
        
        self.best_arm_set = [self.best_arm]

        return self

    
    def LinBandit_env2(self, seed, num_dims, num_arms):
        
        
        np.random.seed(seed)
        self.num_dims = num_dims
        self.num_arms = num_arms
        
        arm_index = [i for i in range(self.num_arms)]
        
        arm_index_comb = list(combinations(arm_index, 2))
        #print(arm_index_comb)
        
        '''
        #print(arm_angles)
        arm_diff = np.diff(arm_angles)
        #print(np.diff(arm_angles))
        min_angle_index = np.argmin(arm_angle_diff)
        #print(min_angle_index)
        '''
        self.X = []

        #print(X)
        for i in range(0, self.num_arms):
        
            tmp = np.random.randn(self.num_dims)
            norm = np.linalg.norm(tmp)
            tmp = tmp/norm
            #X = np.r_[X,np.expand_dims(tmp,0)]
            self.X.append(tmp)
          
        self.X = np.array(self.X)
        
        arm_diff = []
        for a in arm_index_comb:
            #print(a)
            arm_diff.append(np.linalg.norm(self.X[a[0]] - self.X[a[1]]))
        
        #print(arm_diff, np.argmin(arm_diff))
        
        
        min_arm_index = np.argmin(arm_diff)
        #print(min_arm_index, arm_index_comb[min_arm_index])
        
        best_X = self.X[arm_index_comb[min_arm_index][0]]
        second_best_X = self.X[arm_index_comb[min_arm_index][1]]
        
        self.theta_star = best_X + 0.01*(best_X - second_best_X)
        #print(self.theta_star)
        
        #print("means:" + str(self.X.dot(self.theta_star)))
        
        self.best_arm = np.argmax(self.X@self.theta_star)
        self.best_arm_set = [self.best_arm]
        
        #print(self.best_arm)
        
        Y2 = self.X@self.theta_star
        #print(Y2)
        
        Y2 = np.sort(Y2)
        #print(Y2)
        
        self.epsilon = (Y2[len(Y2)-1] - Y2[len(Y2)-2])*0.5
        #print(self.epsilon)
        
        self.min_seperation = np.linalg.norm(best_X - second_best_X)
        #print("best X" + str(best_X))
        #print("second_best X" + str(second_best_X))
        for i in range(0,len(self.X)):
            print(','.join([str(self.X[i][j]) for j in range(len(self.X[0]))]))
            print()
            #for j in range(0,len(self.X[0])):
            #    print(self.X[i][j], sep=", ")
        
        
        print("min_seperation " + str(self.min_seperation))
        print(self.theta_star)
        print(self.num_dims*(3*self.num_dims),self.num_dims*(12.0/self.min_seperation),self.num_dims*((12.0*self.num_dims)/self.min_seperation))
        print(np.log(self.num_dims*(3*self.num_dims)),np.log(self.num_dims*(12.0/self.min_seperation)),np.log(self.num_dims*((12.0*self.num_dims)/self.min_seperation)))
        t = 1
        print("threshold:", str(np.log(4 * (t+1)**2/self.delta)+ self.num_dims * np.log(12.0/self.min_seperation)))
        return self
    
    
    
    
    def plot_2d_env(self):
        
        plt.style.use('ggplot')
        plt.figure(dpi=100)
        
        V = np.array(self.X)
        origin = [0], [0] # origin point
        
        print(self.X)
        print(self.epsilon)
        print(self.theta_star)
        
        plt.quiver(*origin, *self.theta_star, color=['r'], scale=4, label = "$\\theta^*$")
        
        
        #plt.quiver(*origin, V[0,0], V[0,1], color=['g'], linewidth = 10, scale=4, label = "Optimal Arm [1,0]")
        #plt.quiver(*origin, V[0,0], V[0,1], color=['b'], scale=5, label = "Arm Vector")
        for i in range(0,len(V)):
            plt.quiver(*origin, V[i,0], V[i,1], color=['b'], scale=5)
        
        
        plt.legend()
        plt.xticks(size = 5)
        plt.yticks(size = 5)
        
        plt.show()



if __name__ == "__main__":
    obj = LinBandit_env()
    #seed 1 for dim 2, 10 arms
    #obj.LinBandit_env2(55, 2, 12)
    obj.LinBandit_env2(16, 8, 12)
    #obj.plot_2d_env()
    
    
  
    
    
