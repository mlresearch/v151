This code is based on https://github.com/chingyaoc/DCL. The entry point is main.py, which allows the user to specify the number of negatives (k), batch size, dataset, and whether to use real or augmented samples. An example run might be

python main.py --k 32 --batch_size 256 --useReal 1 --data svhn

which will perform NCE on SVHN data using 32 negative samples per point, a batch size of 256, and using real positive samples from the same class. To instead use augmentation, set useReal to 0.
