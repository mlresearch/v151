python3.7 src/experiments/train_supervised.py --num_classes 200 --hidden_dim 400 --name wiki3029_supervised --task wiki-3029 --seed 1234 --data_path ./cache

