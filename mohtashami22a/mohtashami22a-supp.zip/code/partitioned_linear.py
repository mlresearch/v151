from torch import nn
import torch


class PartitionedModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.first_active_level = 1
    def get_sizes(self, total, ratios):
        if ratios is None:
            return [total]
        assert sum(ratios) < 1
        sizes = [int(ratio * total) for ratio in ratios]
        sizes.append(total - sum(sizes))
        return sizes

    def set_active_level(self, active_level, first_active_level=1):
        assert 1 <= first_active_level <= active_level <= self.max_level
        self.active_parts = active_level
        self.first_active_level = first_active_level

    @classmethod
    def set_class_active_level(cls, model, active_level, first_active_level=1):
        def f(model):
            if isinstance(model, cls):
                model.set_active_level(active_level, first_active_level=first_active_level)
        model.apply(f)

    def get_level_parameters(self, level):
        raise NotImplementedError

    @classmethod
    def get_class_level_parameters(cls, model, level):
        for submodel in model.modules():
            if not isinstance(submodel, cls):
                continue
            for elem in submodel.get_level_parameters(level):
                yield elem

    def named_modules(self, memo=None, prefix=''):
        if memo is None:
            memo = set()
        if self not in memo:
            memo.add(self)
            yield prefix, self


class SwitchableBatchNorm2d(PartitionedModel):

    def __init__(self, ratios, num_features, *args, **kwargs):
        super().__init__()
        self.max_level = len(ratios) + 1 if ratios is not None else 1
        sizes = self.get_sizes(num_features, ratios)
        psums = [sizes[0]]
        for size in sizes[1:]:
            psums.append(psums[-1] + size)
        self.batch_norms = nn.ModuleList([
            nn.BatchNorm2d(psum, *args, **kwargs) for psum in psums
        ])
        self.active_parts = self.max_level


    def forward(self, x):
        return self.batch_norms[self.active_parts - 1](x)


class PartitionedLayerNorm(PartitionedModel):
    def get_level_parameters(self, level):
        return self.parts[level - 1].parameters()

    def __init__(self, layer_norm_cls, embed_dim, *args, ratios=None, **kwargs):
        super().__init__()
        self.embed_dim = embed_dim
        self.sizes = self.get_sizes(embed_dim, ratios)
        self.parts = nn.ModuleList()
        self.max_level = len(self.sizes)
        for i in range(self.max_level):
            self.parts.append(layer_norm_cls(self.sizes[i], *args, **kwargs))

        self.active_parts = self.max_level

    def forward(self, x):
        sum_in = self.sizes[0]
        out = self.parts[0](x[...,:sum_in])
        for idx in range(1, self.active_parts):
            out = torch.cat((out, self.parts[idx](x[..., sum_in:sum_in + self.sizes[idx]])), dim=-1)
            sum_in += self.sizes[idx]
        if sum_in < self.embed_dim:
            out = torch.cat((out, out.new_zeros((*out.shape[:-1], self.embed_dim - sum_in), requires_grad=False)), dim=-1)
        return out


class PartitionedWeightModel(PartitionedModel):
    def __init__(self, model_class, in_features, out_features, ratios=None, in_ratios=None,
                 pad_if_not_fully_active=True, **kwargs):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.out_sizes = self.get_sizes(out_features, ratios)
        self.in_sizes = self.get_sizes(in_features, in_ratios)
        self.parts = nn.ModuleList()
        sum_in = 0
        sum_out = 0
        self.max_level = max(len(self.in_sizes), len(self.out_sizes))
        kwargs_without_bias = dict(kwargs)
        kwargs_without_bias["bias"] = False
        for i in range(self.max_level):
            if i < len(self.in_sizes):
                sum_in += self.in_sizes[i]
                if i > 0:
                    self.parts.append(model_class(self.in_sizes[i], sum_out, **kwargs_without_bias))
            if i < len(self.out_sizes):
                self.parts.append(model_class(sum_in, self.out_sizes[i], **kwargs))
                sum_out += self.out_sizes[i]

        self.active_parts = self.max_level
        self.pad_if_not_fully_active = pad_if_not_fully_active

    @property
    def partition_dim(self):
        return -1

    def get_part(self, x, chosen_slice):
        if self.partition_dim == -1:
            return x[..., chosen_slice]
        elif self.partition_dim == 1:
            return x[:, chosen_slice]
        else:
            raise NotImplementedError

    def forward(self, x):
        sum_in = self.in_sizes[0]
        out = self.parts[0](self.get_part(x, slice(None, sum_in)))
        idx = 1
        for i in range(1, self.active_parts):
            if i < len(self.in_sizes):
                out.add_(self.parts[idx](self.get_part(x, slice(sum_in, sum_in + self.in_sizes[i]))))
                sum_in += self.in_sizes[i]
                idx += 1
            if i < len(self.out_sizes):
                out = torch.cat((out, self.parts[idx](self.get_part(x, slice(None, sum_in)))),
                                dim=self.partition_dim)
                idx += 1
        if self.pad_if_not_fully_active:
            self.get_part(out, slice(None, sum(self.out_sizes[:self.first_active_level - 1]))).zero_()
            out_pad_dim = list(out.shape)
            out_pad_dim[self.partition_dim] = self.out_features - out.shape[self.partition_dim]
            out = torch.cat((out, out.new_zeros(out_pad_dim, requires_grad=False)), dim=self.partition_dim)
        else:
            out = self.get_part(out, slice(sum(self.out_sizes[:self.first_active_level - 1]), None))
        return out

    def get_level_parameters(self, level):
        min_idx = max(0, min(level - 1, len(self.in_sizes)) + min(level - 1, len(self.out_sizes)) - 1)
        max_idx = min(level, len(self.in_sizes)) + min(level, len(self.out_sizes)) - 1
        for model in self.parts[min_idx:max_idx]:
            for elem in model.parameters():
                yield elem


class PartitionedLinear(PartitionedWeightModel):
    def __init__(self, in_features, out_features, ratios=None, in_ratios=None, **kwargs):
        super().__init__(nn.Linear, in_features, out_features, ratios=ratios, in_ratios=in_ratios, **kwargs)


class PartitionedConv2d(PartitionedWeightModel):
    def __init__(self, in_features, out_features, kernel_size, ratios=None, in_ratios=None, **kwargs):
        super().__init__(nn.Conv2d, in_features, out_features, ratios=ratios, in_ratios=in_ratios,
                         kernel_size=kernel_size,
                         **kwargs)

    @property
    def partition_dim(self):
        return 1


class PartitionedRankLinear(PartitionedModel):
    def __init__(self, in_features, out_features, ratios=None, in_ratios=None,
                 pad_if_not_fully_active=True, **kwargs):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        features = min(out_features, in_features)
        out_sizes = self.get_sizes(features, ratios)
        in_sizes = self.get_sizes(features, in_ratios)
        if in_features > features:
            in_sizes[-1] += in_features - features
        if out_features > features:
            out_sizes[-1] += out_features - features

        self.sizes = in_sizes[:-1] if len(in_sizes) > len(out_sizes) else out_sizes[:-1]
        self.parts = nn.ModuleList()
        kwargs_without_bias = dict(kwargs)
        kwargs_without_bias["bias"] = False
        sum_size = 0
        for i in range(len(self.sizes)):
            assert i >= len(in_sizes) - 1 or in_sizes[i] == self.sizes[i]
            assert i >= len(out_sizes) - 1 or out_sizes[i] == self.sizes[i]
            sum_size += self.sizes[i]

            self.parts.append(nn.Sequential(
                nn.Linear(self.in_features, sum_size, bias=False),
                nn.Linear(sum_size, self.out_features, **(kwargs if i == 0 else kwargs_without_bias))
            ))
        self.parts.append(nn.Linear(self.in_features, self.out_features,
                                    **(kwargs if len(self.parts) == 0 else kwargs_without_bias)))

        self.max_level = len(self.sizes) + 1

        self.active_parts = self.max_level

    def forward(self, x):
        out = self.parts[0](x)
        for i in range(1, self.active_parts):
            out += self.parts[i](x)
        return out

    def get_level_parameters(self, level):
        for elem in self.parts[level - 1].parameters():
            yield elem


class PartitionedScaledRankLinear(PartitionedRankLinear):
    def forward(self, x):
        return super().forward(x) / self.active_parts


class PartitionedOrthogonalRankLinear(PartitionedRankLinear):
    def forward(self, x):
        if len(self.parts[0]) > 1:
            full_weight = self.parts[0][1].weight.data @ self.parts[0][0].weight.data
            coef = torch.dot(self.parts[1].weight.data.view(-1), full_weight.view(-1)) / torch.dot(full_weight.view(-1), full_weight.view(-1))
            self.parts[1].weight.data.add_(-coef, full_weight)
        return super().forward(x)


class PartitionedRedundantLinear(PartitionedModel):
    def __init__(self, in_features, out_features, ratios=None, in_ratios=None,
                 pad_if_not_fully_active=True, **kwargs):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.out_sizes = self.get_sizes(out_features, ratios)
        self.in_sizes = self.get_sizes(in_features, in_ratios)
        self.parts = nn.ModuleList()
        sum_in = 0
        sum_out = 0
        self.max_level = max(len(self.in_sizes), len(self.out_sizes))
        kwargs_without_bias = dict(kwargs)
        kwargs_without_bias["bias"] = False
        for i in range(self.max_level):
            if i < len(self.in_sizes):
                sum_in += self.in_sizes[i]
            if i < len(self.out_sizes):
                sum_out += self.out_sizes[i]
            self.parts.append(nn.Linear(sum_in, sum_out, **(kwargs_without_bias if i + 1 < self.max_level else kwargs)))

        self.active_parts = self.max_level
        self.pad_if_not_fully_active = pad_if_not_fully_active

    @property
    def partition_dim(self):
        return -1

    def get_part(self, x, chosen_slice):
        if self.partition_dim == -1:
            return x[..., chosen_slice]
        elif self.partition_dim == 1:
            return x[:, chosen_slice]
        else:
            raise NotImplementedError

    def forward(self, x):
        sum_in = sum(self.in_sizes[:self.first_active_level])
        sum_out = sum(self.out_sizes[:self.first_active_level])
        out = self.parts[self.first_active_level - 1](self.get_part(x, slice(None, sum_in)))
        for i in range(self.first_active_level, self.active_parts):
            if i < len(self.out_sizes):
                sum_out += self.out_sizes[i]
                out_pad_dim = list(x.shape)
                out_pad_dim[self.partition_dim] = sum_out - out.shape[self.partition_dim]
                out = torch.cat((out, out.new_zeros(out_pad_dim, requires_grad=False)), dim=self.partition_dim)
            if i < len(self.in_sizes):
                sum_in += self.in_sizes[i]
            out.add_(self.parts[i](self.get_part(x, slice(None, sum_in))))

        if self.pad_if_not_fully_active:
            out_pad_dim = list(x.shape)
            out_pad_dim[self.partition_dim] = self.out_features - out.shape[self.partition_dim]
            out = torch.cat((out, out.new_zeros(out_pad_dim, requires_grad=False)), dim=self.partition_dim)
        return out

    def get_level_parameters(self, level):
        for elem in self.parts[level - 1].parameters():
            yield elem
