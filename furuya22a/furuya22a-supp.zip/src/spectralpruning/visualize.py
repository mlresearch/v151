import os

import matplotlib.pyplot as plt
import numpy as np
import numpy.linalg as LA

from .core import calc_obj_a


def figure_eigen_distribution(cov, dataset: str, task: str, save_path: str):
    r"""Calcurate the eigenvalue distribution and save the resultant figure.

    Args:
        cov (2-dim tensor): Empirical covariance matrix :math:`\hat{\Sigma}`.
        dataset (str): "MNIST", "FashionMNIST" or "CIFAR10".
        task (str): "pix", "seq" or "whole".
        save_path (str): Path to directory to save figure.
    """
    title = task + "-" + dataset
    mu = LA.eigvals(cov)
    mu = np.sort(mu / mu.max())[::-1]
    plt.plot(mu)
    plt.yscale("log")
    plt.ylim(1e-13)
    plt.xlabel("Index")
    plt.ylabel("Eigenvalue")
    plt.title("Eigenvalue distribution for %s" % title)
    plt.savefig(os.path.join(save_path, "eigen_%s.png" % title))
    plt.close()


def figure_information_loss(cov, sub_all, dataset: str, task: str, save_path: str):
    r"""Calcurate the information loss function and save the resultant figure.

    Args:
        cov (2-dim tensor): Empirical covariance matrix :math:`\hat{\Sigma}`.
        sub_all ([[int]]): Sequence of index sets given by greedy algorithm.
        dataset (str): "MNIST", "FashionMNIST" or "CIFAR10".
        task (str): "pix", "seq" or "whole".
        save_path (str): Path to directory to save figure.
    """
    title = task + "-" + dataset
    tau = np.zeros_like(cov[0])
    loss = [calc_obj_a(cov, sub, tau) for sub in sub_all]
    loss_max = max(loss)
    loss = loss / loss_max
    plt.plot(loss)
    plt.xlim(0, len(cov[0]))
    plt.ylim(1e-13)
    plt.yscale("log")
    plt.xlabel(r"$m_\#$ ($\#$ of parameters)")
    plt.ylabel("Information Loss (ratio)")
    plt.title("compression ratio vs. Loss for %s" % title)
    plt.savefig(os.path.join(save_path, "loss_%s.png" % title))
    plt.close()
