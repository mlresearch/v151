import numpy as np
from scipy.stats import mode
from sklearn.metrics import roc_auc_score, precision_score, average_precision_score


def compute_binary_accuracy(predictions, labels):
    if len(predictions) == 0:
        return np.nan
    predictions = np.stack(predictions, axis=0).reshape(-1)
    labels = np.stack(labels, axis=0).reshape(-1)
    pred_classes = np.round(predictions)
    acc = np.mean(pred_classes == labels)
    return acc


def compute_multiclass_accuracy(predictions, labels):
    if len(predictions) == 0:
        return np.nan
    predictions = np.concatenate(predictions, axis=0)
    labels = np.concatenate(labels, axis=0)
    pred_classes = np.argmax(predictions, axis=-1)
    acc = np.mean(pred_classes == labels)
    return acc


def compute_gp_multiclass_accuracy(predictions, labels):
    """
    :param predictions: List of arrays of shape (S, N, C) where S is the number
    of samples, N is the batch size and C is the number of classes.
    :param labels: List of arrays of shape (N).
    """
    if len(predictions) == 0:
        return np.nan
    predictions = np.concatenate(predictions, axis=1).squeeze()
    labels = np.concatenate(labels, axis=0).squeeze()
    pred_classes = np.argmax(predictions, axis=-1)  # Shape (S, N)
    pred_classes = mode(pred_classes, axis=0)[0]    # Shape (N)
    acc = np.mean(pred_classes.astype(np.int) == labels.astype(np.int))
    return acc


def compute_dgp_binary_accuracy(predictions, labels):
    """
    :param predictions: List of arrays of shape (S, N, 1) where S is the number
    of samples and N is the batch size.
    :param labels: List of arrays of shape (N).
    """
    if len(predictions) == 0:
        return np.nan
    predictions = np.concatenate(predictions, axis=1).squeeze()
    labels = np.concatenate(labels, axis=0).squeeze()
    pred_classes = np.round(predictions)  # Shape (S, N)
    pred_classes = mode(pred_classes, axis=0)[0]    # Shape (N)
    acc = np.mean(pred_classes.astype(np.int) == labels.astype(np.int))
    return acc


def compute_mean(values):
    if len(values) == 0:
        return np.nan
    if not isinstance(values[0], np.ndarray):
        return np.nanmean(values)
    return np.mean(np.concatenate(values).reshape(-1), axis=0)


def compute_max(values):
    if len(values) == 0:
        return np.nan
    if not isinstance(values[0], np.ndarray):
        return np.nanmax(values)
    return np.max(np.concatenate(values).reshape(-1), axis=0)


def compute_dgp_auc(predictions, labels):
    """
    :param predictions: List of arrays of shape (S, N, 1) where S is the number
    of samples and N is the batch size.
    :param labels: List of arrays of shape (N).
    """
    if len(predictions) == 0:
        return np.nan
    predictions = np.concatenate(predictions, axis=1).squeeze()
    predictions = np.mean(predictions, axis=0)
    labels = np.concatenate(labels, axis=0).squeeze()
    return roc_auc_score(labels, predictions)


def compute_auc(predictions, labels):
    if len(predictions) == 0:
        return np.nan
    predictions = np.stack(predictions, axis=0).reshape(-1)
    labels = np.stack(labels, axis=0).reshape(-1)
    return roc_auc_score(labels, predictions)


def compute_ap(predictions, labels):
    if len(predictions) == 0:
        return np.nan
    predictions = np.stack(predictions, axis=0).reshape(-1)
    labels = np.stack(labels, axis=0).reshape(-1)
    return average_precision_score(labels, predictions)


def compute_dgp_precision(predictions, labels):
    """
    :param predictions: List of arrays of shape (S, N, 1) where S is the number
    of samples and N is the batch size.
    :param labels: List of arrays of shape (N).
    """
    if len(predictions) == 0:
        return np.nan
    predictions = np.concatenate(predictions, axis=1).squeeze()
    labels = np.stack(labels, axis=0).reshape(-1)
    pred_classes = np.round(predictions)            # Shape (S, N)
    pred_classes = mode(pred_classes, axis=0)[0]
    pred_classes = pred_classes.reshape(-1)         # Shape (N)
    precision = precision_score(labels, pred_classes)
    return precision


def compute_dgp_ap(predictions, labels):
    if len(predictions) == 0:
        return np.nan
    predictions = np.concatenate(predictions, axis=1).squeeze()
    predictions = np.mean(predictions, axis=0)
    labels = np.stack(labels, axis=0).reshape(-1)
    ap = average_precision_score(labels, predictions)
    return ap


def compute_precision(predictions, labels):
    if len(predictions) == 0:
        return np.nan
    predictions = np.stack(predictions, axis=0).reshape(-1)
    labels = np.stack(labels, axis=0).reshape(-1)
    pred_classes = np.round(predictions)
    precision = precision_score(labels, pred_classes)
    return precision
