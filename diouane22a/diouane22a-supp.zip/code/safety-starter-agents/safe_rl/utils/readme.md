# Utils

The various utilities here are copied over from [Spinning Up in Deep RL](https://github.com/openai/spinningup/tree/master/spinup/utils). We prefer to copy/paste here, instead of import, to minimize installation hassle (you don't have to install Spinning Up to use this repo).