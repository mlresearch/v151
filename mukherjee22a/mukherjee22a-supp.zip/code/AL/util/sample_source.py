
import numpy as np

def sample_source(source_idx, mu, sig, jstar):
    return mu[source_idx, jstar] + sig * np.random.randn()