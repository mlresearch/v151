import os
import pickle

import numpy as np
import torch
from src.utils.model_rnn import prepare_trained_rnn
from src.utils.model_rnnlm import prepare_trained_rnnlm


def sample_covariance4rnn(h, dl, device):
    r"""Calculate the empirical covariance matrix :math:`\hat{\Sigma}`. (For RNN hidden)

    Args:
        h: model.rnn.
        dl: Dataloader (especially for training).
        device: `torch.device('cuda')` or `torch.device('cpu')`.

    Returns:
        2-dim tensor: Empirical covariance matrix :math:`\hat{\Sigma}`.
    """
    h = h.to(device, non_blocking=True)
    cov = 0
    for x, _ in dl:
        x = x.to(device, non_blocking=True)
        hx = torch.unsqueeze(h(x)[0], -1)
        cov += (hx @ hx.transpose(2, 3)).sum((0, 1))
    sample_size = len(dl.dataset)
    time_length = x.shape[1]
    return cov / (sample_size * time_length)


def sample_covariance4rnnlm(h, dl, device):
    r"""Calculate the empirical covariance matrix :math:`\hat{\Sigma}`. (For RNNLM hidden)

    Args:
        h: model.forward_to_hidden
        dl: Dataloader (especially for training).
        device: `torch.device('cuda')` or `torch.device('cpu')`.

    Returns:
        2-dim tensor: Empirical covariance matrix :math:`\hat{\Sigma}`.
    """
    hidden = None
    cov = 0
    for x, _ in dl:
        x = x.to(device, non_blocking=True)
        outputs, hidden = h(x, hidden)
        hx = torch.unsqueeze(outputs, -1)
        cov += (hx @ hx.transpose(2, 3)).sum((0, 1))
    seq_size = dl.dataset.datanum
    batch_size = dl.dataset.dataset.size(1)
    return cov / (seq_size * batch_size)


def save_cov4rnn(wts_path, irnn, dl, device, save_name="cov.pkl"):
    """Calculate the empirical covariance matrix and save it at the same directory as weight parameters exist."""
    # Original trained model
    model = prepare_trained_rnn(torch.load(wts_path, map_location=device), irnn, requires_grad=False)
    # Calculate empirical covariance matrix
    model.to(device)
    cov = sample_covariance4rnn(model.rnn, dl, device=device)
    cov = cov.cpu().detach().numpy()
    # Save empirical covariance matrix
    save_path = os.path.join(os.path.dirname(wts_path), save_name)
    with open(save_path, "wb") as pkl:
        pickle.dump(cov, pkl)
    print("saved: ", save_path)


def save_cov4rnnlm(wts_path, dropout, tie_weights, dl, device, save_name="cov.pkl"):
    """Calculate the empirical covariance matrix and save it at the same directory as weight parameters exist."""
    # Original trained model
    model = prepare_trained_rnnlm(torch.load(wts_path, map_location=device), dropout=dropout, tie_weights=tie_weights)
    # Calculate empirical covariance matrix
    model.to(device)
    h = model.forward_to_hidden
    cov = sample_covariance4rnnlm(h, dl, device=device)
    cov = cov.cpu().detach().numpy()
    # Save empirical covariance matrix
    save_path = os.path.join(os.path.dirname(wts_path), save_name)
    with open(save_path, "wb") as pkl:
        pickle.dump(cov, pkl)
    print("saved: ", save_path)


def load_cov(cov_path):
    """Load the empirical covariance matrix already calculated."""
    with open(cov_path, "rb") as cov_pkl:
        cov = pickle.load(cov_pkl)
    return cov


def calc_non_zero_rows_idx(cov):
    """Return index set which correspods to non-zero-rows of covariance matrix."""
    return np.where(abs(cov).max(axis=0) != 0)[0]


def calc_non_zero_rows_n(cov):
    """Return the size of index set which correspods to non-zero-rows of covariance matrix."""
    return (abs(cov).max(axis=0) != 0).sum()
