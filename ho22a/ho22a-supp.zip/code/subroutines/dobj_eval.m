function fx = obj_eval(D, L, k, y, u)  
    STu     = Times_ST(D, L, k, u); 
    fx      = 0.5*(STu'*STu) - STu'*y;
end

