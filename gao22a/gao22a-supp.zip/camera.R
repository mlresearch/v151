source('utils.R')

### experiments
N = 100
ns = 80 * (1:7)
ps = (2:9) * 10
qs = c(2,3,4)

pc = 0.1
type = 'chain'

p = ps[as.integer(args[1])]
q = qs[as.integer(args[2])]

for (p in ps) {
  for(q in qs) {
    res = matrix(NA, N, length(ns))
    for (i in 1:N) {
      dag = simu_DAG(p,q,pc,type)
      X = simu_data(max(ns),p,'gaussian',dag)$X
      for (j in 1:length(ns)) {
        cat(p,q,i,j,'\n')
        n = ns[j]
        Xt = X[1:max(n,p+1),]
        To = getOrdering(Xt, q)
        est = find.parents(Xt,To,q)
        res[i,j] = as.numeric(sum(abs(est - dag$truth)) == 0)
      }
    }
    write.csv(res, paste0('Grec_', p, '_', q, '.csv'), row.names = FALSE)
  }
}

### higher dimension
ns = 80 * (7:11)
ps = c(200,300,500)
q = 2

pc = 0.1
type = 'chain'

for (p in ps) {
  res = matrix(NA, 30, length(ns))
  for (i in 1:30) {
    dag = simu_DAG(p,q,pc,type)
    X = simu_data(max(ns),p,'gaussian',dag)$X
    for (j in 1:length(ns)) {
      cat(p,q,i,j,'\n')
      n = ns[j]
      Xt = X[1:n,]
      To = getOrdering(Xt, q)
      est = find.parents(Xt,To,q)
      res[i,j] = as.numeric(sum(abs(est - dag$truth)) == 0)
    }
  }
  write.csv(res, paste0("HD_Grec_", p, ".csv"), row.names = FALSE)
}


### GGM
library(glasso)
library(flare)

clime.func = function(X){
  out1 = sugm(X, method = "clime", nlambda=50, verbose = FALSE)
  out1.select2 = sugm.select(out1, criterion = "stars", verbose = FALSE)
  as.matrix(out1.select2$refit)
}

glasso.func = function(X) {
  aa = glasso(var(X), rho=0.02)
  (aa$wi!=0) - diag(1,p)
}

N = 100
ns = 80 * (1:7)
pc = 0.1
type = 'chain'

p = 5
q = 2

res.clime = matrix(NA, N, length(ns))
res.glasso = matrix(NA, N, length(ns))
for (i in 1:N) {
  dag = simu_DAG(p,q,pc,type)
  simu = simu_data(max(ns),p,'gaussian',dag)
  X = simu$X
  B = simu$B
  U = (t(diag(1,p) - B)%*%(diag(1,p) - B)!=0) - diag(1,p)
  for (j in 1:length(ns)) {
    cat(p,q,i,j,'\n')
    n = ns[j]
    Xt = X[1:n,]
    est.clime = clime.func(Xt)
    est.glasso = glasso.func(Xt)
    res.clime[i,j] = SHD(est.clime, U)
    res.glasso[i,j] = SHD(est.glasso, U)
  }
}

write.csv(res.clime, paste0('SHD_clime_', p, '_', q, '.csv'), row.names = FALSE)
write.csv(res.glasso, paste0('SHD_glasso_', p, '_', q, '.csv'), row.names = FALSE)
