from decomp_gen.models.mlp import Mlp
from decomp_gen.models.decomp_tree_encoder import *
from decomp_gen.models.gat import *
import networkx as nx
import dgl

if torch.cuda.is_available():
    torch.backends.cudnn.deterministic = True
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


class RNN_Cluster_Generator_Node_Sharing_Mixed(nn.Module):
    def __init__(self, tree_hidden_size=64,
                 GNN_hidden_size=128,
                 LSTM_hidden_dim=128,
                 node_mlp_dims=[128, 64],
                 edge_mlp_dims=[32, 16],
                 edge_NLL_weigth=0.2,
                 MaxClusterSize=50,
                 MaxNumberOfNodes=500):
        super(RNN_Cluster_Generator_Node_Sharing_Mixed, self).__init__()
        self.LSTM_hidden_dim = LSTM_hidden_dim
        self.tree_hidden_size = tree_hidden_size
        self.GNN_hidden_size = GNN_hidden_size
        self.C = MaxClusterSize
        self.N = MaxNumberOfNodes
        self.edge_NLL_weigth = edge_NLL_weigth

        self.treeEncoder = DecompTreeEncoder(tree_hidden_size)
        self.GNN = GNN(
            msg_dim=GNN_hidden_size,
            node_state_dim=GNN_hidden_size,
            edge_feat_dim=0,
            num_prop=1,
            num_layer=5,
            has_attention=True,
            att_hidden_dim=GNN_hidden_size,
            has_residual=False,
            has_graph_output=True,
            output_hidden_dim=GNN_hidden_size,
            graph_output_dim=GNN_hidden_size)

        self.rnn_input = nn.Sequential(
            nn.Linear(GNN_hidden_size + 2 * tree_hidden_size, self.LSTM_hidden_dim))

        self.nodeLSTM = nn.LSTM(2, self.LSTM_hidden_dim)
        self.nodeMLP = Mlp(input_size=self.LSTM_hidden_dim, output_size=1,
                           hidden_sizes=node_mlp_dims)
        self.edgeLSTM = nn.LSTM(2, self.LSTM_hidden_dim)
        self.edgeMLP = Mlp(input_size=self.LSTM_hidden_dim, output_size=1,
                           hidden_sizes=edge_mlp_dims)

        self.clusterLSTM = nn.LSTM(2 + self.tree_hidden_size, self.LSTM_hidden_dim)
        self.clusterMLP = Mlp(input_size=self.LSTM_hidden_dim, output_size=1,
                              hidden_sizes=node_mlp_dims)

        self.decoder_input = nn.Sequential(
            nn.Linear(self.N, self.GNN_hidden_size - self.C))

    def _inference(self, trees, clusterSuperNodes, Gi, Ci, sharedNodes, newNodes, childClusters,
                   shared):

        # print("child Clusters: ",childClusters)
        # print("shared with child clusters: ",shared)

        R_tree, tree_embds = self.treeEncoder(trees, clusterSuperNodes)
        # print("R_tree cuda: ",R_tree.is_cuda) -> False! Should fix this
        R_tree.squeeze()
        R_tree = cuda(R_tree)
        #         print("R_tree: ",R_tree.shape)
        # R_Gi = self.GNN(Gi['node_feat'], Gi['edge'], Gi['edge_feat'], Gi['graph_idx'])

        adjmat = nx.to_numpy_matrix(Gi)
        adjmat = cuda(torch.from_numpy(adjmat))
        adjmat = cuda(torch.tril(adjmat, diagonal=-1))
        padSize = (0, self.N - Gi.number_of_nodes())
        adjmat = cuda(F.pad(adjmat, padSize, 'constant', 0))
        adjmat = cuda(adjmat.type(torch.FloatTensor))
        node_feat = self.decoder_input(adjmat)
        node_feat = cuda(F.pad(node_feat, (0, self.C), 'constant', 0).type(torch.FloatTensor))
        node_feat.detach()

        for i, v in enumerate(sharedNodes):
            node_feat[v, i] = 1.0
        edge = np.array(list(Gi.edges))
        edge = cuda(torch.from_numpy(edge))
        edge.detach()

        graph_idx = cuda(torch.tensor([0] * Gi.number_of_nodes()))
        #         graph_idx = graph_idx.view(-1,1)
        graph_idx.detach()

        if Gi.number_of_nodes() > 0:
            R_Gi = self.GNN(node_feat=node_feat, edge=edge, edge_feat=None, graph_idx=graph_idx)
        else:
            R_Gi = cuda(torch.zeros(1, self.GNN_hidden_size))
        R_Gi.squeeze()
        R_Gi = R_Gi[0, :]
        R_Gi = R_Gi.view(1, -1)
        #         print("graph_idx: ",graph_idx)
        #         print("R_Gi: ",R_Gi.shape)

        # print("R_tree cuda: ",R_tree.is_cuda)
        # print("R_Gi cuda: ",R_Gi.is_cuda)
        h = torch.cat([R_tree, R_Gi], 1)
        h = self.rnn_input(h)
        h = h.view(1, 1, -1)
        c = cuda(torch.zeros(self.LSTM_hidden_dim))
        c = c.view(1, 1, -1)
        h.detach()
        c.detach()

        NLLNode = cuda(torch.tensor([0.0]))
        NLLEdge = cuda(torch.tensor([0.0]))
        NLLShare = cuda(torch.tensor([0.0]))

        CiNodes = list(Ci.nodes())
        CAdj = nx.to_numpy_matrix(Ci)
        CAdj = cuda(torch.from_numpy(CAdj).type(torch.FloatTensor))

        CAdj.detach()

        newNodesStart = len(sharedNodes)

        inn = cuda(torch.zeros(2))
        inn = inn.view(1, 1, -1)

        inn.detach()

        for i in range(CAdj.shape[0]):
            out, (h, c) = self.nodeLSTM(inn, (h, c))
            out = out.squeeze()
            p = self.nodeMLP(out)
            p = torch.sigmoid(p)

            if i >= newNodesStart:
                NLLNode -= torch.log(p)

            inn = cuda(torch.tensor([1.0, 0.0]))
            inn = inn.view(1, 1, -1)

            for j in range(i):
                out, (h, c) = self.edgeLSTM(inn, (h, c))
                out = out.squeeze()
                p = self.edgeMLP(out)
                p = torch.sigmoid(p)
                if CAdj[i, j] == 0:
                    p = 1.0 - p
                    inn = cuda(torch.tensor([0.0, 1.0]))
                else:
                    inn = cuda(torch.tensor([1.0, 0.0]))
                inn = inn.view(1, 1, -1)

                if i >= newNodesStart:
                    NLLEdge -= torch.log(p)

            innCluster = cuda(torch.zeros(2))

            for cluster in childClusters:
                # R_tree = self.treeEncoder(trees, [cluster])
                # R_cluster = cuda(R_tree[0,self.tree_hidden_size:])
                R_cluster = tree_embds.nodes[cluster].data['h']

                R_cluster = R_cluster.squeeze()
                innCluster = innCluster.squeeze()
                innCluster = torch.cat([innCluster, R_cluster], dim=0)
                innCluster = cuda(innCluster.view(1, 1, -1))
                out, (h, c) = self.clusterLSTM(innCluster, (h, c))
                p = self.clusterMLP(out.squeeze())
                p = torch.sigmoid(p)

                # print("cluster: ",cluster)
                # print("node Number: ",i)

                if shared[cluster][CiNodes[i]]:
                    innCluster = cuda(torch.tensor([0.0, 1.0]))
                    innCluster[1] = 1.0
                else:
                    p = 1.0 - p
                    innCluster = cuda(torch.tensor([1.0, 0.0]))
                    innCluster[0] = 1.0

                NLLShare -= torch.log(p)

        # The last step we decide to add no more nodes:
        out, (h, c) = self.nodeLSTM(inn, (h, c))
        out = out.squeeze()
        p = self.nodeMLP(out)
        p = torch.sigmoid(p)

        NLLNode -= torch.log(1.0 - p)

        return NLLNode, NLLEdge, NLLShare

    def _sample(self, trees, clusterSuperNodes, Gi, sharedNodes):

        R_tree, tree_embds = self.treeEncoder(trees, clusterSuperNodes)
        R_tree.squeeze()
        R_tree = cuda(R_tree)

        adjmat = nx.to_numpy_matrix(Gi)
        adjmat = cuda(torch.from_numpy(adjmat))
        adjmat = cuda(torch.tril(adjmat, diagonal=-1))
        padSize = (0, self.N - Gi.number_of_nodes())
        adjmat = cuda(F.pad(adjmat, padSize, 'constant', 0))
        adjmat = cuda(adjmat.type(torch.FloatTensor))
        node_feat = self.decoder_input(adjmat)
        node_feat = cuda(F.pad(node_feat, (0, self.C), 'constant', 0).type(torch.FloatTensor))
        node_feat.detach()

        for i, v in enumerate(sharedNodes):
            node_feat[v, i] = 1.0
        edge = np.array(list(Gi.edges))
        edge = cuda(torch.from_numpy(edge))
        edge.detach()

        graph_idx = cuda(torch.tensor([0] * Gi.number_of_nodes()))
        #         graph_idx = graph_idx.view(-1,1)
        graph_idx.detach()

        if Gi.number_of_nodes() > 0:
            R_Gi = self.GNN(node_feat=node_feat, edge=edge, edge_feat=None, graph_idx=graph_idx)
        else:
            R_Gi = cuda(torch.zeros(1, self.GNN_hidden_size))

        R_Gi.squeeze()
        R_Gi = R_Gi[0, :]
        R_Gi = R_Gi.view(1, -1)

        h = torch.cat([R_tree, R_Gi], 1)
        h = self.rnn_input(h)
        h = h.view(1, 1, -1)
        c = cuda(torch.zeros(self.LSTM_hidden_dim))
        c = c.view(1, 1, -1)
        h.detach()
        c.detach()

        NLL = cuda(torch.tensor([0.0]))

        #         print("Gi frozen? : ",nx.is_frozen(Gi))
        Ci = Gi.subgraph(sharedNodes).copy()
        #         print("Ci frozen? : ",nx.is_frozen(Ci))
        CAdj = nx.to_numpy_matrix(Ci)
        CAdj = cuda(torch.from_numpy(CAdj).type(torch.FloatTensor))
        CAdj.detach()

        inn = cuda(torch.zeros(2))
        inn = inn.view(1, 1, -1)
        inn.detach()

        new_node_id = np.max(Gi.nodes) + 1

        shared = {}
        for cluster in childClusters:
            shared[cluster] = {}

        for i in range(CAdj.shape[0]):
            out, (h, c) = self.nodeLSTM(inn, (h, c))
            out = out.squeeze()

            inn = cuda(torch.tensor([1.0, 0.0]))
            inn = inn.view(1, 1, -1)

            for j in range(i):
                out, (h, c) = self.edgeLSTM(inn, (h, c))
                out = out.squeeze()

                if CAdj[i, j] == 0:
                    inn = cuda(torch.tensor([0.0, 1.0]))
                else:
                    inn = cuda(torch.tensor([1.0, 0.0]))
                inn = inn.view(1, 1, -1)

            innCluster = cuda(torch.zeros(2 + self.tree_hidden_size))
            for cluster in childClusters:
                R_tree = self.treeEncoder(trees, [cluster])
                R_cluster = cuda(R_tree[0, self.tree_hidden_size:])
                R_cluster = R_cluster.squeeze()
                innCluster = innCluster.squeeze()
                innCluster[2:] = R_cluster
                innCluster = cuda(innCluster.view(1, 1, -1))

                out, (h, c) = self.clusterLSTM(innCluster, (h, c))
                p = self.clusterMLP(out.squeeze())
                p = torch.sigmoid(p)
                res = torch.distributions.bernoulli.Bernoulli(p).sample()
                if res:
                    shared[cluster][i] = 1
                    innCluster[0, 0, 0:2] = cuda(torch.tensor([0.0, 1.0]))
                else:
                    shared[cluster][i] = 0
                    innCluster[0, 0, 0:2] = cuda(torch.tensor([1.0, 0.0]))

        stopped = False
        while not stopped:
            out, (h, c) = self.nodeLSTM(inn, (h, c))
            out = out.squeeze()
            p = self.nodeMLP(out)
            p = torch.sigmoid(p)
            #             print("p for node " , p)
            res = torch.distributions.bernoulli.Bernoulli(p).sample()
            #             print("res for node" , res)
            if res == 1:
                inn = cuda(torch.tensor([1.0, 0.0]))
                inn = inn.view(1, 1, -1)
                Gi.add_node(new_node_id)
            else:
                stopped = True
                break

            V = list(Ci.nodes)
            #             print("V: ",V)
            V.reverse()
            #             print("V reverse: ",V)
            for v in V:
                out, (h, c) = self.edgeLSTM(inn, (h, c))
                out = out.squeeze()

                p = self.edgeMLP(out)
                p = torch.sigmoid(p)
                #                 print("p for edge " , p)
                res = torch.distributions.bernoulli.Bernoulli(p).sample()
                #                 print("res for edge" , res)
                if res == 1:
                    inn = cuda(torch.tensor([1.0, 0.0]))
                    inn = inn.view(1, 1, -1)
                    Gi.add_edge(new_node_id, v)
                else:
                    inn = cuda(torch.tensor([0.0, 1.0]))
                    inn = inn.view(1, 1, -1)

            i = new_node_id
            Ci.add_node(new_node_id)
            new_node_id += 1

            innCluster = cuda(torch.zeros(2 + self.tree_hidden_size))
            for cluster in childClusters:
                R_tree = self.treeEncoder(trees, [cluster])
                R_cluster = cuda(R_tree[0, self.tree_hidden_size:])
                R_cluster = R_cluster.squeeze()
                innCluster = innCluster.squeeze()
                innCluster[2:] = R_cluster
                innCluster = cuda(innCluster.view(1, 1, -1))

                out, (h, c) = self.clusterLSTM(innCluster, (h, c))
                p = self.clusterMLP(out.squeeze())
                p = torch.sigmoid(p)
                res = torch.distributions.bernoulli.Bernoulli(p).sample()
                if res:
                    shared[cluster][i] = 1
                    innCluster[0, 0, 0:2] = cuda(torch.tensor([0.0, 1.0]))
                else:
                    shared[cluster][i] = 0
                    innCluster[0, 0, 0:2] = cuda(torch.tensor([1.0, 0.0]))

        return Gi, shared

    def forward(self, idx, sn, Gi, Ci, T, type='inference'):
        trees = [dgl.DGLGraph(T)]
        snNodes = sn.getNewAndSharedNodes()
        sharedNodes = sorted(snNodes['shared'])
        newNodes = sorted(snNodes['newNodes'])
        clusterSuperNodes = [idx]

        childClusters = sn.sortedChildrenList()
        childClustersLabels = []

        shared_with_child = {}
        for ch in childClusters:
            childClustersLabels.append(ch.label)
            shared_with_child[ch.label] = {}
            nodes = ch.getNewAndSharedNodes()
            for v in nodes['shared']:
                shared_with_child[ch.label][v] = 1

            for v in nodes['newNodes']:
                shared_with_child[ch.label][v] = 0

        if type == 'inference':
            return self._inference(trees, clusterSuperNodes, Gi, Ci, sharedNodes, newNodes,
                                   childClustersLabels, shared_with_child)
        else:
            return self._sample(trees, clusterSuperNodes, Gi, sharedNodes, childClustersLabels)
