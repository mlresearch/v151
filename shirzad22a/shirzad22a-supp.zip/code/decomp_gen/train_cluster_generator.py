import wandb
import argparse
import dgl
from decomp_gen.data_structures.dataSetGetter import *
from decomp_gen.models.mixed_cluster_node_sharing_rnn import *
from decomp_gen.cluster_NodeSharing_Mixed_Data import *
from decomp_gen.data_structures.dataset import *

from decomp_gen.models.nnutils import *
from decomp_gen import configs
import gc

import random

data_name = 'grid'
sampleCnt = 100
start = -1
epochs = 100


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data-name', default='grid', type=str)
    parser.add_argument('--tree-hidden-size', default=64, type=int)
    parser.add_argument('--gnn-hidden-size', default=128, type=int)
    parser.add_argument('--lstm-hidden-dim', default=128, type=int)
    parser.add_argument('--node-mlp-dims', default=64, type=int)
    parser.add_argument('--edge-mlp-dims', default=32, type=int)
    parser.add_argument('--edge-nll-weight', default=0.5, type=int)
    parser.add_argument('--max-cluster-size', default=50, type=int)
    parser.add_argument('--max-num-nodes', default=400, type=int)
    args = parser.parse_args()

    if not isinstance(args.node_mlp_dims, list):
        args.node_mlp_dims = [args.node_mlp_dims]
    if not isinstance(args.edge_mlp_dims, list):
        args.edge_mlp_dims = [args.edge_mlp_dims]

    return args

    # tree_hidden_size = 64,
    # GNN_hidden_size = 128,
    # LSTM_hidden_dim = 128,
    # node_mlp_dims = [64],
    # edge_mlp_dims = [32],
    # edge_NLL_weigth = 0.5,
    # MaxClusterSize = 50,
    # MaxNumberOfNodes = 400)


def evaluate(model, evalData):
    totalNLL = cuda(torch.tensor([0.0]))
    totalCnt = 0
    for i in range(len(evalData)):
        sample = evalData[i]

        Gi = sample['generatedGraph']
        Ci = sample['Ci']
        sharedNodes = sample['shared']
        newNodes = sample['newNodes']

        T = dgl.DGLGraph(sample['T'])
        T = [T]
        extendingNode = sample['label']
        extendingNode = [extendingNode]

        childClusters = list(sample['shared_with_child'].keys())
        shared_with_child = sample['shared_with_child']

        nllNode, nllEdge, nllShare = model(trees=T, clusterSuperNodes=extendingNode,
                                           Gi=Gi, Ci=Ci, sharedNodes=sharedNodes,
                                           childClusters=childClusters,
                                           shared=shared_with_child, newNodes=newNodes,
                                           type='inference')
        nll = nllNode.data.detach() + nllEdge.data.detach() * 0.5 + nllShare.data.detach()

        totalNLL += nll.data.detach()
        totalCnt += 1

        del sample, Gi, Ci, sharedNodes, newNodes, T, extendingNode
        # gc.collect()

    return totalNLL, totalNLL / totalCnt


def trainClusterGeneratingModel(model, train_data, evalData, modelName=None, batchPrintCounter=100):
    bestValNLL = cuda(torch.tensor(100000.0))

    data_loader = torch.utils.data.DataLoader(train_data,
                                                 batch_size=1, shuffle=True,
                                                 num_workers=1)

    if modelName == None:
        modelName = "clusterGeneratorTmp"
    adr = (Path("__file__").resolve().parent)
    relative_path = "saved_models/" + modelName
    adr = (adr / relative_path).resolve()
    print("Saving model to: ", adr)

    optimizer = torch.optim.Adam(model.parameters(), lr=0.0005, betas=(0.9, 0.999), eps=1e-08,
                                 weight_decay=0, amsgrad=False)

    for param in model.parameters():
        param.require_grad = False

    for epoch in range(epochs):
        print("epoch: ", epoch)
        epochNLL = cuda(torch.tensor([0.0]))
        epochCnt = 0
        for graphs in data_loader:
            g = graphs[0]
            for i in range(g.getNumberofClusters()):

                sn , Gi, Ci = g.getClusterData(i)

                # Gi = sample['generatedGraph']
                # Ci = sample['Ci']
                # sharedNodes = sample['shared']
                # newNodes = sample['newNodes']
                #
                # T = dgl.DGLGraph(sample['T'])
                # T = [T]
                # extendingNode = sample['label']
                # extendingNode = [extendingNode]



                # childClusters = list(sample['shared_with_child'].keys())
                # shared_with_child = sample['shared_with_child']

                # T = [dgl.DGLGraph(g.T.getSimpleTreee())]
                # sn , Gi, Ci = g.getClusterData()
                # snNodes = sn.getNewAndSharedNodes()
                # sharedNodes = snNodes['shared']
                # newNodes = snNodes['newNodes']
                # extendingNode = [i]

                optimizer.zero_grad()
                nllNode, nllEdge, nllShare = model(i, sn, Gi, Ci, g.T.getSimpleTree(),
                                                   type='inference')
                nll = nllNode + nllEdge + nllShare
                epochNLL += nll.data.detach()
                epochCnt += 1

                if i % batchPrintCounter == 0:
                    print("Average NLL till batch ", i, "=", epochNLL.item() / epochCnt)

                nll.backward()
                optimizer.step()

        print("Epoch Total NLL: ", epochNLL.item() / epochCnt)
        evalTotalNLL, evalAvgNLL = evaluate(model, evalData=evalData)
        wandb.log(
            {'train/nll': epochNLL,
             'eval/nll_total': evalTotalNLL,
             'eval/nll_avg': evalAvgNLL
             },
            step=epoch
        )

        if evalAvgNLL < bestValNLL:
            torch.save(model, adr)

        print("Validation Average NLL: ", evalAvgNLL.item())


def main():
    print(f'root_dir={configs.root_dir}')
    args = parse_args()
    wandb.init(project='decomp_gen', config=args)

    gc.enable()
    # name = "{}_{}".format(data_name, sampleCnt)
    # graphs, _ = getGraphDataset(data_name=data_name, graph_type='simple', numberOfSamples=sampleCnt,
    #                             start=start, name=name)

    # random.shuffle(graphs)
    # trainData = graphs[0:int(0.75 * len(graphs))]
    # evalData = graphs[int(0.75 * len(graphs)):int(0.85 * len(graphs))]
    # testData = graphs[int(0.85 * len(graphs)):]

    # Prepare data
    # trainData, validationData, testData, stats = \
    #     getClusterNodeSharingGeneratingDataSet(graphs, name=name)
    # print(len(trainData))

    data = GraphDataset(args.data_name, '{}.dat'.format(args.data_name))
    train_len = int(0.75*len(data))
    test_len = int(0.15*len(data))
    eval_len = len(data) - train_len - test_len
    train_data, eval_data, test_data = torch.utils.data.random_split(data, [train_len, eval_len, test_len])

    model = RNN_Cluster_Generator_Node_Sharing_Mixed(tree_hidden_size=args.tree_hidden_size,
                                                     GNN_hidden_size=args.gnn_hidden_size,
                                                     LSTM_hidden_dim=args.lstm_hidden_dim,
                                                     node_mlp_dims=args.node_mlp_dims,
                                                     edge_mlp_dims=args.edge_mlp_dims,
                                                     edge_NLL_weigth=args.edge_nll_weight,
                                                     MaxClusterSize=data.max_treewidth() + 10,
                                                     MaxNumberOfNodes=data.max_graph_size() + 50)
    model = model.to(device)

    trainClusterGeneratingModel(model, train_data, eval_data, "clusterGenerator_{}".format(args.data_name))


if __name__ == "__main__":
    main()
