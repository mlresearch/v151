library(RandomFields)
#library(deldir) 
library(randtoolbox)
library(GPfit)
library(geoR)
library(lhs)
library(flexclust)
library(mlegp)
library(mvtnorm)

set.seed(43)
mynuset <- c(1.5,2.5,3.5)

for(mynu in mynuset){
  n1 = 101
  myPreX <- seq(0, 1, length.out = n1)
  myPreY <- seq(0, 1, length.out = n1) # prediction points
  myd <- expand.grid(x = myPreX, y = myPreY) # gridpoints
  d1 <- myd
  d1[,1] <- myd[,2]
  d1[,2] <- myd[,1]
  
  sigma2 = 1
  
  pointeval = function(x,X){
    for(i in 1:dim(X)[1]){
      if(x[1] == X[i,1] & x[2] == X[i,2]){
        return(i)
      }
    }
  }
  
  findY = function(y,Y){
    for(i in 1:length(Y)){
      if(Y[i] == y){
        return(i)
      }
    }
  }
  
  desnum = 5
  itmax = 30
  itnum = seq(5, itmax, by = 5)
  itnumlen = length(itnum)
  
  myX = optimumLHS(n=desnum, k=2) # ini design
  myXX = round(myX/(1/(n1-1)))*(1/(n1-1)) # LHS on grids
  
  gpva <- matrix(data = 1,nrow = 100, ncol = n1^2)
  
  numtemp <- 0
  n1 = n1^2
  
  EIdata <- matrix(data = 1,nrow = 100,ncol = 1) 
  
  # mynu = 3.5
  # myphi = 1/(2*sqrt(mynu))
  # mynu <- c(1.5,2.5,3.5)
  A0D <- 25
  
  myscalenu = function(nu,p){
    D = sqrt(p)
    return((p*4*sqrt(nu)*gamma(nu + 1/2)*D/(sqrt(pi) * (2*nu - 1)*gamma(nu)))/A0D)
  }
  
  Mtheta <- myscalenu(mynu,2)
  myphi = Mtheta/(2*sqrt(mynu))
  
  gpdrawsimu = function(n,A){
    bdr = as.matrix(rnorm(n))
    return(A %*% bdr)
  }
  
  myDist=as.matrix(dist(myPreX,diag=TRUE,upper=TRUE))
  PhiEval1 <- matern(u = myDist, phi = myphi, kappa = mynu)
  A1 <- t(cholx(PhiEval1))
  PhiEval <- kronecker(PhiEval1,PhiEval1)
  # myDistx=as.matrix(dist(matrix(as.matrix(d1[,1]),ncol = 1),diag=TRUE,upper=TRUE))
  # myDisty=as.matrix(dist(matrix(as.matrix(d1[,2]),ncol = 1),diag=TRUE,upper=TRUE))
  # PhiEval22 <- matern(u = myDistx, phi = myphi, kappa = mynu) *
  #   matern(u = myDisty, phi = myphi, kappa = mynu)
  
  # GPdraw = sigma2 * gpdrawsimu(n1,kronecker(A1,A1))
  for(i in 1:100){
    print(c(i,mynu))
    # GPdraw = rmvnorm(n=1,sigma = PhiEval)
    GPdraw = sigma2 * gpdrawsimu(n1,kronecker(A1,A1))
    gpva[i,] <- GPdraw
  }
     rm(d1,metadata,myDistw,myDistx,myDisty,myDistz,otu_table,PhiEval,PhiEval22)
    save.image(...)
}


