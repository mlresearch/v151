import sys
import os
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"
from os.path import dirname
sys.path.append(dirname("/home/user/neurips21/"))  # this is to add the project's path to PYTHONPATH so python can tell where to load the relevant parts of the code

import matplotlib.pyplot as plt
import seaborn as sns
#sns.set_theme()

import logging
logging.getLogger('tensorflow').disabled = True

# importing our utils function
from utils.utilities import *
# importing bits for our metric implementations
from utils.metric import *

# importing keras
from tensorflow.keras import backend as KB
import tensorflow as tf

# importing bits for our recommenders
from models.nets.simsnet import *
from models.nets.spenet import *
from models.recommenders.sims import *
from models.recommenders.spe import *
from models.recommenders.simsssl import *

# importing bits for our personalizers
from models.personalizer.kernel import *
from models.personalizer.simsgp import *
from models.personalizer.simspersonalizer import *
from models.personalizer.simssparsegp import *

# importing bits for our data loaders
from loaders.dataloader import *
from loaders.pairloader import *
from loaders.featureloader import *
from loaders.factory import *

# set random seed
seed = 1234
fix_seed(seed)

# set the GPU -- which one to be used for training -- later: figure out how to do multi-GPU training
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

INPUT_PATH = "/home/user/data/movielens/20M"  # base path for data
OUTPUT_PATH = "/home/user/neurips21_cache"  # base path for model + data saves
PLOT_PATH = "/home/user/neurips21/plots"

if not os.path.exists(OUTPUT_PATH):
    os.mkdir(OUTPUT_PATH)

if not os.path.exists(PLOT_PATH):
    os.mkdir(PLOT_PATH)

RATINGS = os.path.sep.join([INPUT_PATH, "ratings.csv"])  # raw rating data

DATA_VERSION = "movielens-data"  # this is where we store our data pre-processed artifacts
DATA_CACHE = os.path.sep.join([OUTPUT_PATH, DATA_VERSION])  # path to DATA CACHE -- where to save our data objects

if not os.path.exists(DATA_CACHE):  # check if the folder exists already
    os.makedirs(DATA_CACHE)  # if not, create it

MODEL_VERSION_SIAMESE_BASE = "siamese-base-model"  # this is where we stored the SSL-tuned model artifacts
MODEL_VERSION_SSL_BASE = "siamese-SSL-model"  # this is where we stored the SSL-tuned model artifacts
MODEL_VERSION_TUNE = "siamese-personalized-model"  # this is where we will store the meta-tuned + personalized model artifacts

MODEL_TUNE = os.path.sep.join([OUTPUT_PATH, MODEL_VERSION_TUNE])  # path to MODEL CACHE -- where to save our model artifacts
MODEL_SSL_BASE = os.path.sep.join([OUTPUT_PATH, MODEL_VERSION_SSL_BASE])  # path to MODEL CACHE -- where to save our model artifacts
MODEL_SIAMESE_BASE = os.path.sep.join([OUTPUT_PATH, MODEL_VERSION_SIAMESE_BASE])  # path to MODEL CACHE -- where to save our model artifacts

if not os.path.exists(MODEL_TUNE):  # check if the folder exists already
    os.makedirs(MODEL_TUNE)  # if not, create it

META_CHANNELS = ['Plot', 'AveRating']  # set up meta data channels
channels = {}
for CHANNEL in META_CHANNELS:
    channels[CHANNEL] = os.path.sep.join([INPUT_PATH, "{}.npz".format(CHANNEL)])

n_pair_per_user, window, timecut, version = 10, 10, 1365957431, 4  # set up identifications of the base model and data artifacts

print("Loading Data")
DataBuilder : DataFactory = load_object(DATA_CACHE + "/data-pair-per-user-{}-window-{}-timecut-{}.dat".format(n_pair_per_user, window, timecut))
DataBuilder.reset_feature_channel(channels)

print("Loading Parameters ...")  # this is the user-provided parameters needed to build our metric net
hyper_params = {'max_no_item' : 26801, 'feature_channels_dim' : DataBuilder.featurizer.feature_dims,  # {"Title" : 50, "Poster" : 512}
                'loss' : Losses.ContrastiveLossV1, 'hidden_dim' : 50, 'id_embedding_dim' : 30, 'learning_rate' : 5 * 1e-4}

print("Loading User Ratings ...")
ratings = pd.read_csv(RATINGS, index_col = 0)
cache = dict()
for i, row in tqdm.tqdm(enumerate(ratings.itertuples())):
    user_id, item_id, rating = int(row[1]), int(row[2]), int(row[3])
    cache[(user_id, item_id)] = rating

print("Fetching Test Users ...")
test_users = []
for user_id in DataBuilder.interaction_data_loader.users:
    if DataBuilder.interaction_data_loader.users[user_id].reserve == DataMode.test.name:  # only consider test users
        h = DataBuilder.interaction_data_loader.users[user_id]
        if 20 <= len(h.interactions) <= 200:
            test_users.append(user_id)
    if len(test_users) == 20:
        break

print("Fetching SSL Data ...")
[X, Y, p] = load_object(DATA_CACHE + "/SSL-data.dat")
n_support, n_test_user = 100, len(test_users)
Xs = np.random.choice(X, n_support, p = p, replace = False)

featurizer = DataBuilder.featurizer
epoch, L = 100, 10
alpha, beta = 5 * 1e-4, 1.0
# this is the name of the siamese-base model -- we will be picking up existing models from SSL repo as base
md_siamese_base = "siamese-version-{}-pair-per-user-{}-window-{}-timecut-{}-epoch-{}-seed-{}".format(version, n_pair_per_user, window, timecut, 50, seed)
# this is the name of the ssl-base model -- we will be picking up existing models from SSL repo as base
md_ssl_base = "SSL-siamese-version-{}-pair-per-user-{}-window-{}-timecut-{}-epoch-{}-support-{}-seed-{}-iter-15".\
    format(version, n_pair_per_user, window, timecut, 30, 100, seed)
# this is the name of the meta-tuned model (with ssl-base) -- a vantage point from which we could rapidly tune to fit any users
md_ssl_name = "SSL-personalize-siamese-version-{}-pair-per-user-{}-window-{}-timecut-{}-epoch-{}-support-{}".\
    format(version, n_pair_per_user, window, timecut, epoch, n_support)
# this is the name of the meta-tuned model (with siamese-base) -- a vantage point from which we could rapidly tune to fit any users
md_siamese_name = "personalize-siamese-version-{}-pair-per-user-{}-window-{}-timecut-{}-epoch-{}".\
    format(version, n_pair_per_user, window, timecut, epoch)

# choose base here: ssl or siamese
md_base, md_name= md_ssl_base, md_ssl_name
MODEL_BASE = MODEL_SSL_BASE

PLOT_CACHE = os.path.sep.join([PLOT_PATH, md_name])  # this is where we will store our plots and plotting data
if not os.path.exists(PLOT_CACHE):  # check if the folder exists already
    os.makedirs(PLOT_CACHE)  # if not, create it
md_name += "-seed-{}".format(seed)

# set up metric functions
metrics = {'mrr': mean_reciprocal_rank, 'precision_at_{}'.format(L): precision_at_k, 'ndcg_at_{}'.format(L): ndcg_at_k}

# fetching the base
SIMSEngineBase = SIMSV4(hyper_params, md_base)  # load these parameters and create a metric net
SIMSEngineBase.load(MODEL_BASE, option = 'last')  # load the model
SIMSEngineBase.md_name = md_name  # from now on, save it under a different name reflecting the SSL prefix
optimizer = SIMSEngineBase.network.optimizer

# setting up the adapter
M = SIMSSparseGP(SIMSCovV2(SIMSEngineBase, featurizer), SIMSMean(c = 2.5), noise = np.log(0.5))  # L(w)
print("Using GPU {} ...".format(os.environ["CUDA_VISIBLE_DEVICES"]))

# meta fine-tuning process below
for i in range(epoch):
    print("Fitting iteration {} ...".format(i + 1))
    with tf.GradientTape(watch_accessed_variables = False) as tape:
        tape.watch(M.cov.aggregator.trainable_weights)
        F = (1 - beta) * M.NLL(X, Y, Xs)
        F_grad = tape.gradient(F, M.cov.aggregator.trainable_weights)

    for u in range(0, n_test_user):
        # extract personal user data
        user_id = test_users[u]
        h = DataBuilder.interaction_data_loader.users[user_id]
        Xu = [h.interactions[i][0] for i in range(len(h.interactions))]
        Yu = [cache[(user_id, Xu[i])] * 1.0 for i in range(len(Xu))]
        tests = [h.interactions[i][0] for i in range(len(h.interactions) - 1)]
        Y_mean = 0.0
        for i in range(len(Yu)):
            Y_mean += Yu[i]
        Y_mean = Y_mean * 1.0 / len(Yu)
        # create Lu(w)
        Ku = SIMSCov(SIMSEngineBase.network.tower, SIMSEngineBase.network.aggregator, featurizer)
        Mu = SIMSGP(Ku, SIMSMean(c = Y_mean), noise = np.log(0.5))  # Lu(w)
        # back up old weight
        w_backup = Mu.cov.aggregator.get_weights()
        # compute Lu'(w)
        with tf.GradientTape(watch_accessed_variables = False) as tape:
            tape.watch(Mu.cov.aggregator.trainable_weights)
            Fu = Mu.NLL(Xu, Yu)
            Fu_grad = tape.gradient(Fu, Mu.cov.aggregator.trainable_weights)
            optimizer.optimizer.apply_gradients(zip(Fu_grad, Mu.cov.aggregator.trainable_weights))
        # compute Lu'(wu)
        with tf.GradientTape(watch_accessed_variables = False) as tape:
            tape.watch(Mu.cov.aggregator.trainable_weights)
            Fu_next = Mu.NLL(Xu, Yu)
            Fu_next_grad = tape.gradient(Fu_next, Mu.cov.aggregator.trainable_weights)
        # revert the weight
        Mu.cov.aggregator.set_weights(w_backup)
        for v in range(len(F_grad)):
            if len(F_grad[v].shape) == 1:
                F_grad[v] += (beta / n_test_user) * (1 - alpha * Fu_grad[v] ** 2.0) * Fu_next_grad[v]
            else:
                F_grad[v] += (beta / n_test_user) * tf.matmul((tf.eye(F_grad[v].shape[0]) - alpha * tf.matmul(tf.transpose(Fu_grad[v]), Fu_grad[v])), Fu_next_grad[v])

    optimizer.optimizer.apply_gradients(zip(F_grad, M.cov.aggregator.trainable_weights))

SIMSEngineBase.save(MODEL_TUNE)  # save the fine-tuned base
KB.clear_session()
# at this point, we have a base already -- next is asynchronous fitting

preadapt, posadapt, partadapt = {}, {}, {}
for pos in range(0, len(test_users)):
    partadapt[test_users[pos]] = []

for u in range(n_test_user):
    user_id = test_users[u]
    h = DataBuilder.interaction_data_loader.users[user_id]
    Xu = [h.interactions[i][0] for i in range(len(h.interactions))]
    Yu = [cache[(user_id, Xu[i])] * 1.0 for i in range(len(Xu))]
    tests = [h.interactions[i][0] for i in range(len(h.interactions) - 1)]
    Y_mean = 0.0
    for i in range(len(Yu)):
        Y_mean += Yu[i]
    Y_mean = Y_mean * 1.0 / len(Yu)

    SIMSEngineClone = SIMSV4(hyper_params, md_name)  # load these parameters and create a metric net
    SIMSEngineClone.load(MODEL_TUNE, option = 'last')  # load the tuned ssl base model
    SIMSEngineClone.md_name += "-user-{}".format(user_id)

    tower, aggregator = SIMSEngineClone.network.tower, SIMSEngineClone.network.aggregator
    personalizer = SIMSGP(SIMSCov(tower, aggregator, featurizer), SIMSMean(c = Y_mean), noise = np.log(0.5))
    optimizer = SIMSEngineClone.network.optimizer
    SIMSAdapter = SIMSPersonalize(personalizer, optimizer, user_id)

    pre_message, results = DataBuilder.metric_eval_streamline_personalized(SIMSAdapter, user_id, metrics, tests,
                                                                           K = L, verbal = False, forward = False)
    preadapt[user_id] = results

    print("Adapting for User {} with ID = {} ...".format(u, user_id))
    for i in range(20):
        SIMSAdapter.fit(Xu, Yu, max_num_epoch = 100, checkpoint = 50)
        message, results = DataBuilder.metric_eval_streamline_personalized(SIMSAdapter, user_id, metrics, tests,
                                                                           K = L, verbal = False, forward = False)
        partadapt[user_id].append(results)

    print("Saving Personalized Model for User {} with ID = {} ...".format(u, user_id))
    SIMSEngineClone.save(MODEL_TUNE)

    print("Pre-Adaptation {} ".format(pre_message))
    message, results = DataBuilder.metric_eval_streamline_personalized(SIMSAdapter, user_id, metrics, tests,
                                                                       K = L, verbal = False, forward = False)
    print("Post-Adaptation {} ".format(message))
    posadapt[user_id] = results

    KB.clear_session()

save_object([preadapt, posadapt, partadapt], PLOT_CACHE + "/personalized-plotting-data-seed-{}.dat".format(seed))
print("Check out saved results at {}".format(PLOT_CACHE))

# F(w) = L(w) + sum_u NLL_u(w - alpha L'_u(w))
# F'(w) = L'(w) + sum_u (I - alpha L''_u(w)) * L'_u(w_u) where w_u = w - alpha L'_u(w)
# Now, L''_u is approximated with L'_u^T L'_u
# So, F'(w) = L'(w) + sum_u (I - alpha L'_u(w)^T L'_u(w)) L'_u(w_u)
#           = L'(w) + sum_u (L'_u(w_u) - alpha L'_u(w)^T L'_u(w) L'_u(w_u))
# Let G(w) = L(w) + sum_u L_u(w) -- so we get L'(w) and L'_u(w) -- we need L'_u(w_u)