from torch import nn


class LinearClassifier(nn.Module):
    def __init__(self, input_dim):
        super(LinearClassifier, self).__init__()
        self.l1 = nn.Linear(input_dim, 1)

    def forward(self, x):
        return self.l1(x)[:, 0]
