import numpy as np
import networkx as nx
import copy
import pickle
from pathlib import Path
from tqdm import tqdm

from decomp_gen.data_structures.graph import Graph, DecompositionTree

def n_community(c_sizes, seed, p=0.3, p_inter=0.05):
    graphs = [nx.gnp_random_graph(c_sizes[i], p, seed=seed + i) for i in range(len(c_sizes))]
    G = nx.disjoint_union_all(graphs)
    communities = [G.subgraph(cc) for cc in nx.connected_components(G)]
    for i in range(len(communities)):
        subG1 = communities[i]
        nodes1 = list(subG1.nodes())
        for j in range(i + 1, len(communities)):
            subG2 = communities[j]
            nodes2 = list(subG2.nodes())
            has_inter_edge = False
            for n1 in nodes1:
                for n2 in nodes2:
                    if np.random.rand() < p_inter:
                        G.add_edge(n1, n2)
                        has_inter_edge = True
            if not has_inter_edge:
                G.add_edge(nodes1[0], nodes2[0])
    # print('connected comp: ', len(list(nx.connected_component_subgraphs(G))))
    return G


def create_graphs(data_name, num_graphs=100, seed=1234):
    print('creating synthetic {} data'.format(data_name))
    npr = np.random.RandomState(seed)
    ### load datasets
    graphs = []
    # synthetic graphs
    MaxLen = 0
    if data_name == 'grid':
        graphs = []
        for i in tqdm(range(10, 20)):
            for j in range(10, 20):
                graph = Graph(AdjMatrix=None, nxGraph=nx.grid_2d_graph(i, j))
                graphs.append(copy.deepcopy(graph))
                d = int((graph.getDTdiameter() + 1) / 2)
                # print("d: ",d)
                MaxLen = max(MaxLen, d)
    elif data_name == 'lobster':
        graphs = []
        p1 = 0.7
        p2 = 0.7
        count = 0
        min_node = 10
        max_node = 100
        MaxLen = int(max_node / 2)
        max_edge = 0
        mean_node = 80
        num_graphs = 100

        MaxLen = 0
        seed_tmp = seed
        while count < num_graphs:
            G = nx.random_lobster(mean_node, p1, p2, seed=seed_tmp)
            if len(G.nodes()) >= min_node and len(G.nodes()) <= max_node:
                # graph = Graph(nxGraph=G)
                T = DecompositionTree(G, 2)
                graphs.append(copy.deepcopy(T))
                if G.number_of_edges() > max_edge:
                    max_edge = G.number_of_edges()

                count += 1

            seed_tmp += 1
    elif data_name == 'community':
        print("creating 500 two community networks, p=0.3, p_inter = 0.05")
        C = np.random.randint(51, size=500)
        C = C + 30
        # print(C)
        seed = 1375
        graphs = []
        MaxLen = 0
        for c in C:
            g = n_community([c, c], seed=seed, p=0.3, p_inter=0.1 / c)
            graph = Graph(AdjMatrix=None, nxGraph=g)
            graphs.append(graph)
            d = int((graph.getDTdiameter() + 1) / 2)
            MaxLen = max(MaxLen, d)
            seed += 24

    # num_nodes = [gg.getGraph().number_of_nodes() for gg in graphs]
    # num_edges = [gg.getGraph().number_of_edges() for gg in graphs]
    # tree_widthes = [gg.getTW() for gg in graphs]
    # print('max # nodes = {} || mean # nodes = {}'.format(max(num_nodes), np.mean(num_nodes)))
    # print('max # edges = {} || mean # edges = {}'.format(max(num_edges), np.mean(num_edges)))
    # print('max # treewidth = {} || mean # treewidth = {}'.format(max(tree_widthes),
    #                                                              np.mean(tree_widthes)))

    namePath = (Path("__file__").absolute().parent)
    relative_path = "data/Datasets/Graphs/" + data_name + "_" + str(len(graphs)) + ".dat"
    namePath = (namePath / relative_path).absolute()

    with open(namePath, "wb") as f:
        pickle.dump([graphs, MaxLen], f)

    return graphs, MaxLen


