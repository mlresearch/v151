import torch


def evaluate(model, criterion, test_dl, device=torch.device("cuda:0")):
    """Algorithm for evaluation."""
    loss = float("inf")

    model = model.to(device)
    model.eval()
    dataloader = test_dl
    n_iters = (dataloader.dataset.datanum + 1) // dataloader.batch_size

    ntoken = model.ntoken
    running_loss = 0.0
    hidden = None

    for inputs, labels in dataloader:
        inputs = inputs.to(device, non_blocking=True)
        labels = labels.to(device, non_blocking=True)

        with torch.no_grad():
            outputs, hidden = model(inputs, hidden)
            loss = criterion(outputs.view(-1, ntoken), labels.view(-1))
        # statistics
        running_loss += loss.item() / n_iters
    loss = running_loss
    return loss
