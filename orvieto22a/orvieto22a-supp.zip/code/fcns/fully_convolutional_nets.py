#######################################
#### Run experiments for Fig 4,14 #####
#######################################

# tensorboard needs to be installed for visualization of the results

#######################################
#######################################
#######################################


import torch
import numpy as np
from matplotlib import pyplot as plt
import IPython
from tensorboardX import SummaryWriter
import torchvision
import torchvision.transforms as transforms

class CNN(torch.nn.Module):
    def __init__(self,num_layers,d, kernel,mode,relu,residual_connections,batch_norm):
        super(CNN, self).__init__()
        act=torch.nn.ReLU() if relu else torch.nn.Sequential()
        layers=[]
        self.num_layers=num_layers
        self.residual_connections=residual_connections

        self.Win=torch.nn.Conv2d(3, d, kernel,padding=1,padding_mode=mode,bias=False)
        self.Wout=torch.nn.Conv2d(d, 3, kernel,padding=1,padding_mode=mode,bias=False)

        for i in range(num_layers):
            if batch_norm:
              layers+=[torch.nn.Conv2d(d, d, kernel,padding=1,padding_mode=mode,bias=False),torch.nn.BatchNorm2d(d),act] 
            else:
              layers+=[torch.nn.Conv2d(d, d, kernel,padding=1,padding_mode=mode,bias=False),act] 
        self.layers=torch.nn.Sequential(*layers)
     
        for m in self.modules():
          if isinstance(m, torch.nn.Conv2d):
              torch.nn.init.kaiming_uniform_(m.weight, nonlinearity='relu') if relu else torch.nn.init.xavier_uniform_(m.weight,gain=1)
        
  
    def forward(self, x):
      if self.residual_connections:
        x=self.Win(x)
        if self.num_layers<8:
          for i in range(self.num_layers):
              x=self.layers[i](x)+x
        else:
          for i in range(self.num_layers):
              if i==0:
                _x=x.clone()
              if i%3==0:
                x=self.layers[i](x)+_x
                _x=x.clone()
              else:
                x=self.layers[i](x)

          x=self.Wout(x)
          return x
      else:
          return self.Wout(self.layers(self.Win(x)))

def flat_gradient(net):
    grad_dict  = {k:v.grad for k, v in zip(net.state_dict(), net.parameters())}
    return torch.cat([g.contiguous().view(-1) for k,g in grad_dict.items()])

def H_exact(model, loss):
  
    layer_subset=np.random.choice(np.arange(0,model.num_layers), min(model.num_layers,45), replace=False) # pick some layers
    grad_dict = torch.autograd.grad(loss, list(np.array(list(model.parameters()))[layer_subset]), create_graph=True,allow_unused=True)

    grad_vec=[]
    for i,g in enumerate(grad_dict):
        if g is not None:
          grad_vec.append(g.contiguous().view(-1))

    grad_vec=torch.cat(grad_vec)
    neuron_subset=torch.randperm(len(grad_vec))[:450]
    grad_vec = grad_vec[neuron_subset] # pick some neurons in these layers

    H = torch.ones((grad_vec.size(0), grad_vec.size(0))).double()
    del grad_dict
    for i, grad in enumerate(grad_vec):
        H_i_dict = torch.autograd.grad(grad, list(np.array(list(model.parameters()))[layer_subset]), retain_graph=True,allow_unused=True)
        H_i_vec = torch.cat([g.contiguous().view(-1) for g in H_i_dict if g is not None])
        H[:, i] = H_i_vec[neuron_subset]
        del H_i_vec,H_i_dict

    return H,grad_vec

def run(L,d,image,padding,relu,residual_connections,batch_norm):
  model=CNN(L,d,3,padding,relu,residual_connections,batch_norm).double().to(device)
  model.train()
  model.zero_grad()

  no_H=False
  image_hat=model.forward(image)
  my_loss=loss(image_hat,image)

  if no_H:
    my_loss.backward()
    grad=flat_gradient(model)
  else:
    H,grad=H_exact(model,my_loss)
    grad_norm=torch.mean(torch.abs(grad)).detach().item()
    h_diag=(torch.sum(torch.abs(torch.diag(H)))/H.shape[0]).detach().item() #new
    h_offdiag=(torch.sum(torch.abs(H-torch.diag(H)))/(H.shape[0]**2-H.shape[0])).detach().item() #new

  return grad_norm, h_diag,h_offdiag


######################################
loss=torch.nn.MSELoss(reduction='mean')
depths=[2,4,8,16,32,64,92,128,256]
runs=1

global device
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
myint=np.random.randint(500, size=1)

transform = transforms.Compose([transforms.Resize((7,7)),transforms.ToTensor()])

trainset = torchvision.datasets.CIFAR10(root='./data', train=True,download=True, transform=transform)
trainloader = torch.utils.data.DataLoader(trainset, batch_size=32,shuffle=True,pin_memory=True)
for i,batch in enumerate(trainloader):
  img,_=batch
  if i>1:
    break

residual_connections,batch_norm=False,False

for img_size in [7,32]:
    for padding in ['zeros']:
        for i,relu in enumerate([True,False]):
          grad,grad_sqrt,h_diag,h_diag_sqrt,h_offdiag,h_offdiag_sqrt=[],[],[],[],[],[]

          writer_1 = SummaryWriter(f'logs/CNN_CIFAR/img_size_{img_size}/padding_{padding}/relu_{relu}_sqrt_{myint}')
          writer_2 = SummaryWriter(f'logs/CNN_CIFAR/img_size_{img_size}/padding_{padding}/relu_{relu}_{myint}')

          for L in depths:
              d=max(1,int(np.sqrt(L)/9))
              grad_magnitude,h_diag_magnitude,h_offdiag_magnitude=run(L,d,img.double().to(device),padding,relu,residual_connections,batch_norm) 
              grad_sqrt.append(grad_magnitude),h_diag_sqrt.append(h_diag_magnitude),h_offdiag_sqrt.append(h_offdiag_magnitude)
              
              writer_1.add_scalar('grad_norm',grad_magnitude,L)  
              writer_1.add_scalar('h_diag_magnitude',h_diag_magnitude,L)  
              writer_1.add_scalar('h_offdiag_magnitude',h_offdiag_magnitude,L)  


              d=max(1,int(L/9))
              grad_magnitude,h_diag_magnitude,h_offdiag_magnitude=run(L,d,img.double().to(device),padding,relu,residual_connections,batch_norm)
              grad.append(grad_magnitude), h_diag.append(h_diag_magnitude),h_offdiag.append(h_offdiag_magnitude)
              
              writer_2.add_scalar('grad_norm',grad_magnitude,L)  
              writer_2.add_scalar('h_diag_magnitude',h_diag_magnitude,L)  
              writer_2.add_scalar('h_offdiag_magnitude',h_offdiag_magnitude,L)  
             
