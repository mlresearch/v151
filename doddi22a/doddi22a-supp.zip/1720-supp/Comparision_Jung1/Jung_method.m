
%% f = 0
load('Batch1_f0_4000.mat')
C1 = Shat;

%% f = 0.25 *pi
load('Batch1_f1_4000.mat')
C2 = Shat;

%% f = 0.5 *pi
load('Batch1_f2_4000.mat')
C3 = Shat;

%% f = 0.75*pi
load('Batch1_f3_4000.mat')
C4 = Shat;

num_trial=50;
error = 500*ones(num_trial,1);

for trial = 16:num_trial

    
    
S_hat = zeros(16,16,4);    
    
S_hat(:,:,1)=  C1(:,:,trial) ;  
S_hat(:,:,2)=  C2(:,:,trial) ; 
S_hat(:,:,3)=  C3(:,:,trial) ;  
S_hat(:,:,4)=  C4(:,:,trial) ; 
    
cvx_begin 
variable X1(Nnodes,Nnodes) complex hermitian;
variable X2(Nnodes,Nnodes) complex hermitian;
variable X3(Nnodes,Nnodes) complex hermitian ;
variable X4(Nnodes,Nnodes) complex hermitian ;
lambda = 0.0522;
A = 1/4*( log_det(X1)+log_det(X2)+log_det(X3)+log_det(X4) );
B = 1/4*(  trace(S_hat(:,:,1)*X1)+trace(S_hat(:,:,2)*X2)+trace(S_hat(:,:,3)*X3)+trace(S_hat(:,:,4)*X4)   );
r_term = 0;
for i=1:16
   for j = 1:16
    r_term = r_term +(1/4*pow_abs(X1(i,j),1)+1/4*pow_abs(X2(i,j),1)+1/4*pow_abs(X3(i,j),1)+1/4*pow_abs(X4(i,j),1) ); 
   end
end

minimize -real(A)+ real(B) + lambda*real(r_term) ;
subject to
    X1 == hermitian_semidefinite(16)
    (eye(16) +1j*zeros(16))-X1 == hermitian_semidefinite(16)
    
    X2 == hermitian_semidefinite(16)
    (eye(16) +1j*zeros(16))-X2 == hermitian_semidefinite(16)
    
    X3 == hermitian_semidefinite(16)
    (eye(16) +1j*zeros(16))-X3 == hermitian_semidefinite(16)
    
    X4 == hermitian_semidefinite(16)
    (eye(16) +1j*zeros(16))-X4 == hermitian_semidefinite(16)
    cvx_end

 tol = 8e-2;

 X_ij_norm= zeros(Nnodes,Nnodes);
Recon_Jung= zeros(Nnodes,Nnodes);
for i=1:15
   for j = i+1:16
    X_ij_norm(i,j) =sqrt(1/4*pow_abs(X1(i,j),1)+1/4*pow_abs(X2(i,j),1)+1/4*pow_abs(X3(i,j),1)+1/4*pow_abs(X4(i,j),1) ); 
    if X_ij_norm(i,j)>tol
        Recon_Jung(i,j)=1;
        Recon_Jung(j,i)=1;        
    end
   end
   
end



error(trial) = sum(sum(abs(Recon_Jung-Adj)))/sum(sum(Adj));

    
end
