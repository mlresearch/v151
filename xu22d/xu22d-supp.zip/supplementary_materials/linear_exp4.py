import numpy as np
from pricing_function import pricing
from pricing_inverse_function import pricing_inverse
import scipy.stats as stats
from number2theta import number_2_theta, theta_mat
import pickle as pk
import matplotlib.pyplot as plt

"""
    This is an implementation of Linear-EXP4 algorithm as a function.
    For the experiment and plot shown in our paper, please run "LinearEXP4_02.py".  
"""


def linearExp4(T=4096, d=2, gamma=0.11, rounds=1, mode_indicator=0, sigma=0.25, bound_theta=1, bound_x=1,
               start_point=16, ifregression=1, ifplot=1, ifsave=1, ifprint=1):
    """ Mode Selection """
    # mode_indicator = 1  # 1 for stochastic x_t's, and 0 for adversarial
    """initialize model parameters"""
    # T = 4096  # period number, < 70000
    # d = 2  # feature dimension
    # sigma = 0.25  # noise standard deviation
    # rounds = 5  # repeat, rounds <= 20
    # bound_theta = 1  # Euclidean norm upper bound of theta_star
    # bound_x = 1  # Euclidean norm upper bound of x_t
    # start_point = 16  # ploting from start_point
    # (this tentative regret plot does not indicate the regret of Linear-EXP4 since it is not an any-time algorithm).
    # ifregression = 1  # whether compute a linear fit of the tentative cumulative regret
    # ifplot = 1  # whether plot or not
    # ifsave = 1  # whether save the tentative regret list; otherwise the function only returns the total cumulative regret at t = T
    # ifprint = 1  # whether print the theta and the current round index
    """Initialize EXP4 parameter"""
    # gamma = 0.11  # balance the exploration-exploitation of EXP-4
    """load x_t"""
    if mode_indicator:
        with open("xtrandom.pkl", 'rb') as pkf:
            xt_file = pk.load(pkf)
    else:
        with open("xtadversarial.pkl", 'rb') as pkg:
            xt_file = pk.load(pkg)
    """regret_list"""
    regret_original = np.zeros((T, rounds))
    """rounds start"""
    for iround in range(rounds):
        print("round  ", iround)
        """load x_t for this round"""
        xt_this_round = xt_file[:, :, iround]
        """(not necessarily happen) initialize theta_star"""
        theta_star = bound_theta * np.random.rand(d)  # for convenience, we assume theta_star is all positive
        theta_star = theta_star / max(1, np.linalg.norm(theta_star, 2))
        if ifprint == 1:
            print("theta_star = ", theta_star)
        """initialize regret as zero"""
        regret = 0
        """set up T and discretize"""
        delta = T ** (-1 / 3) * d ** (-1 / 6)  # discretizator of policy theta
        discrete_factor = T ** (-1 / 3) * d ** (1 / 3)  # gamma in Auer's paper
        """theta discretization"""
        M = int(np.floor(bound_theta / delta))  # discretization of price (action)
        N = (M + 1) ** d  # number of policies
        """action discretization"""
        K_action = int(np.ceil((2 * sigma + bound_x * bound_theta) / discrete_factor))
        list_selected_actions = np.zeros(T)
        counter = np.zeros(d)
        price_upper_bound = 2 * sigma + bound_x * bound_theta
        """We construct the theta vectors"""
        theta_matrix = theta_mat(d, M, N, delta)
        weight_of_experts = np.ones(N)
        """            period start                  """
        for t in range(T):
            x_t = xt_this_round[t]
            """update pricing probability"""
            W_t = sum(weight_of_experts)
            price_prob = np.ones(K_action) * gamma / K_action
            list_policy_2_price = np.zeros(N)
            for i_policy in range(N):
                theta_i_t = theta_matrix[i_policy]  # theta_i_t = number_2_theta(i_policy, d, M, delta)
                index_target_price = int(np.dot(theta_i_t, x_t) / discrete_factor)
                target_price = index_target_price * discrete_factor  # target_price = pricing(np.dot(theta_i_t, x_t), sigma)
                list_policy_2_price[i_policy] = index_target_price
                target_price_discrete = discrete_factor * index_target_price
                """add weight to probability"""
                if 0 <= index_target_price < K_action:
                    price_prob[index_target_price] += (1 - gamma) * weight_of_experts[i_policy] / W_t
                elif index_target_price < 0:
                    price_prob[0] += (1 - gamma) * weight_of_experts[i_policy] / W_t
                else:
                    price_prob[K_action - 1] += (1 - gamma) * weight_of_experts[i_policy] / W_t
            """generate cumulative distribution from probabilistic distribution"""
            price_cumulative = np.zeros(K_action)
            price_cumulative[0] = price_prob[0]
            for j_action in range(1, K_action):
                price_cumulative[j_action] = price_cumulative[j_action - 1] + price_prob[j_action]
            """randomly propose a price"""
            val = np.random.rand()
            select_index = 0
            for j in range(K_action):
                if val < price_cumulative[j]:
                    select_index = j
                    list_selected_actions[t] = select_index
                    break
            v_t = discrete_factor * select_index  # price v_t
            """generate customers' valuation"""
            price_star = np.inner(x_t, theta_star)
            N_t = sigma * np.random.randn()  # create a gaussian noise ~ N(0,sigma)
            u_t = pricing_inverse(price_star, sigma)
            y_t = u_t + N_t
            # u_t = np.inner(x_t, theta_star)
            # y_t = u_t + N_t  # generate customer's valuation
            # price_star = np.inner(x_t, theta_star)  # price_star = pricing(np.inner(x_t, theta_star), sigma)
            """compare are decide"""
            ind = 0
            if v_t <= y_t:
                ind = 1
            """calculate cumulative regret and record regret_over_T^{2/3}"""
            expected_revenue_t = v_t * (1 - stats.norm.cdf((v_t - u_t) / sigma))
            largest_expected_revenue = price_star * (1 - stats.norm.cdf((price_star - u_t) / sigma))
            regret = regret + largest_expected_revenue - expected_revenue_t
            regret_original[t, iround] = regret
            """update weights"""
            hat_x_j_t = ind * v_t / price_prob[
                select_index]  # (price_upper_bound*price_prob[select_index])  # rewards in [0,1]
            for i in range(N):
                if list_policy_2_price[i] == select_index:
                    weight_of_experts[i] *= np.exp(gamma * hat_x_j_t / K_action)
            """monitor the process, as it is really time consuming"""
            if t % 100 == 0 and ifprint == 1:
                print("round = ", iround, ", t = ", t)
                """
                    Since it is a price rather than a theta that the agent choose,
                    we do not have such a theta here. Therefore, we do not print
                    a theta corresponding to each printed t.
                """
    """save the regret list"""
    if ifsave == 1:
        with open("linear_exp4_T=%d.pkl" % T, "wb") as exp4_rec:
            pk.dump(regret_original, exp4_rec)
    """plot regret curve"""
    # taking average
    average_linear_exp4 = np.zeros(T)
    for i_round in range(rounds):
        average_linear_exp4 += 1 / rounds * regret_original[:, i_round]
    # a simple linear regression
    if ifregression==1:
        log_index_list = [np.log2(ix) for ix in range(start_point, T)]
        log_regret_list = [np.log2(iy) for iy in np.ndarray.tolist(average_linear_exp4[start_point:])]
        slope_le, intercept_le, r_value_le, p_value_le, std_err_le = stats.linregress(log_index_list, log_regret_list)
        asymptote_array_le = np.array([2 ** (slope_le * np.log2(x) + intercept_le) for x in range(start_point, T)])
        plt.plot(np.arange(start_point, T), asymptote_array_le, color="gray", linestyle="dotted", linewidth=1)
        print("Linear-EXP4 log-linear regression (stochastic): log_2(y) = ", slope_le, "log_2(x)+", intercept_le, " .")
        print("Linear-EXP4 sto R^2 = ", r_value_le ** 2, " .")
    # ploting
    if ifplot == 1:
        regret_average = np.sum(regret_original, axis=1) / rounds
        plt.plot(np.arange(start_point, T), regret_average[start_point:])
        plt.xscale("log", base=2)
        plt.yscale("log", base=2)
        plt.grid(True)
        plt.xlabel('round', fontsize=18)
        plt.ylabel('regret', fontsize=18)
        plt.title('Average cumulative regret for Linear-EXP4')
        plt.savefig('./plot_linear_exp4_demo.pdf', bbox_inches='tight')
        plt.show()

    return regret_original[-1, :]



