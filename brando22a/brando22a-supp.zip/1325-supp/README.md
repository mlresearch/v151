# Deep Non-Crossing Quantiles through the Partial Derivative
Implementation of a deep learning model to estimate the partial derivative of a quantile function (using Tensorflow and Keras).

Given that the partial derivative of a quantile function is modeled, it can be used as a solution for the crossing quantile phenomenon as described in the paper: 

> ***Axel Brando, Joan Gimeno, Jose A. Rodriguez-Serrano, Jordi Vitria. "[Deep Non-Crossing Quantiles through the Partial Derivative](https://arxiv.org/abs/2201.12848)." International Conference on Artificial Intelligence and Statistics (AISTATS). 2022.***

###### where the presented model is used to predict an arbitrary number of quantiles that ensures the quantile monotonicity constraint up to the machine precision and maintains its modelling performance with respect to alternative models.

------------

This repository is an official collection of Python scripts and a [Jupyter](https://jupyter.org/) notebook to show the model implementation of the aforementioned article.

![Synthetic data set showing that our proposed method (with the above architecture) avoids crossing quantiles (right), unlike IQN (left).](Summary.png)

<p align="center">
<em>Synthetic data set showing that our proposed method (with the above architecture) avoids crossing quantiles (right), unlike IQN (left).</em>
</p>

## What is implemented

> - The proposed model, <img src="https://latex.codecogs.com/svg.image?Ours-q_0" title="Ours-q_0" />, considering the minimum as the constant of integration.
> - The proposed model, <img src="https://latex.codecogs.com/svg.image?Ours-Mean" title="Ours-Mean" />, considering the mean as the constant of integration.
> - Quantile Regression loss function adapted to forecast several quantiles simultaneously.
> - Approximating the partial derivative with respect to the quantile input variable using a conditional Truncated Chebyshev polynomial.
> - The emphirical verification of the non-crossing quantiles property.
> - Visualization of the predicted conditional quantiles and QR performance.

## Summary of the Notebook and scripts
(Currently tested on TensorFlow (2.3.0)).

#### [Experimental Notebook for the Mean model](Mean-Experiment.ipynb)
#### [Experimental Notebook for the q0 model](q0-Experiment.ipynb)
#### [General model class](Model.py)
#### [Utils class](Utils.py)


## Contact  

Feel free to contact us to discuss any issues, questions or comments.

Axel Brando ([Twitter](https://twitter.com/axelbrando_)-[Linkedin](https://www.linkedin.com/in/axelbrando/)), Joan Gimeno ([arXiv](https://arxiv.org/search/?searchtype=author&query=Gimeno%2C+J)), Jose A. Rodríguez-Serrano ([Twitter](https://twitter.com/qupixel)-[Linkedin](https://es.linkedin.com/in/jose-a-rodriguez-serrano-46505653)) and Jordi Vitrà ([Twitter](https://twitter.com/bitenmascarado)-[Linkedin](https://es.linkedin.com/in/jordivitria)).


## License

The content developed is distributed under the following license:

    Copyright 2022

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
