Similarity Learning Can Elicit Binary Classifiers
====

This repository is the official implementation of "Similarity Learning Can Elicit Binary Classifiers" with pubmed-diabetes dataset.

## Requirements

All experiments were conducted with `Python 3.7`.
To install requirements:

```
pip install -r requirements.txt
```

## How to run

To reproduce the experimental results, execute the following step:

```
python main.py --data pubmed --name [ID-of-experiment] --method [standard|cips|mcl|dml] --reg 1e-2 1e-4 1e-6
```

To aggregate the experimental results (recorded with `mlflow`) into a table, execute the following step:

```
python summary.py --latex --name [ID-of-experiment]
```
