from lnets.models.architectures.hard_coded.lenet import LeNet
from lnets.models.architectures.hard_coded.resnet import ResNet, BasicBlock
from lnets.models.architectures.hard_coded.parseval_infogan_discriminator import ParsevalInfoGanDiscriminator
