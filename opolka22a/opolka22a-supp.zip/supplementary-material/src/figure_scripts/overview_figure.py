import random

import numpy as np
import tensorflow as tf
import pygsp
from pygsp.plotting import plot_graph, plot_signal
import matplotlib.pyplot as plt

from kernels.wavelet_kernel import Wavelet
from multiscale_wgp import sample_signal_from_prior
from utils import plot_cumulative_spectral_density
from wavelet_utils import mexican_hat_normalized, low, plot_spectral_filters

if __name__ == '__main__':
    # Set random seed
    seed = 0
    random.seed(seed)
    np.random.seed(seed)
    tf.random.set_seed(seed)


    adj_mat = np.zeros([32, 32])

    # All rectangles
    for start_node in range(0, adj_mat.shape[0], 4):
        adj_mat[start_node, start_node+1] = 1.0
        adj_mat[start_node+1, start_node+3] = 1.0
        adj_mat[start_node+2, start_node+3] = 1.0
        adj_mat[start_node, start_node+2] = 1.0
        # optional diagonals
        adj_mat[start_node, start_node+3] = 1.0
        adj_mat[start_node+1, start_node+2] = 1.0
    # Within cluster 1
    adj_mat[1, 4] = 1.0
    adj_mat[3, 6] = 1.0
    adj_mat[2, 5] = 1.0

    # Within cluster 2
    adj_mat[9, 12] = 1.0
    adj_mat[11, 14] = 1.0
    adj_mat[8, 15] = 1.0

    # Within cluster 3
    adj_mat[17, 20] = 1.0
    adj_mat[19, 22] = 1.0
    adj_mat[16, 23] = 1.0

    # Within cluster 4
    adj_mat[25, 28] = 1.0
    adj_mat[27, 30] = 1.0
    adj_mat[26, 29] = 1.0

    # Connecting cluster 1 and 2
    adj_mat[2, 8] = 1.0
    # Connecting cluster 1 and 3
    adj_mat[5, 16] = 1.0
    # Connecting cluster 2 and 4
    adj_mat[15, 24] = 1.0
    # Connecting cluster 4 and 4
    adj_mat[23, 29] = 1.0

    # Make undirected
    adj_mat += adj_mat.T

    graph = pygsp.graphs.Graph(adj_mat)
    base_coordinates = [[0.0, 0.0], [1.0, 0.0], [0.0, 1.0], [1.0, 1.0]]
    base_coordinates = np.concatenate([base_coordinates, base_coordinates+np.array([3.0, 0.0])])
    coordinates = [base_coordinates]
    for x_shift, y_shift in [(0.0, 2.0), (7.0, 0.0), (7.0, 2.0)]:
        coordinates.append(base_coordinates+np.array([x_shift, y_shift]))
    coordinates = np.concatenate(coordinates)
    graph.set_coordinates(coordinates)
    plot_graph(graph)

    graph.compute_laplacian("normalized")
    L = graph.L.toarray()

    eigvals, eigvecs = plot_cumulative_spectral_density(adj_mat, "Multiscale Graph", plot_eigvals=True)

    # Sample signal from kernel
    low_scale = 10.0
    band_scales = [0.8, 3.5]
    low_f = low
    low_unshifted_f = lambda l, s: low_f(l, s, shift=0.0)
    band_f = mexican_hat_normalized
    band_unshifted_f = lambda l, s: band_f(l, s, shift=0.0)
    store_files = True

    # Plot filter
    plot_spectral_filters(low_scale=low_scale, band_scales=band_scales, low_filter=low_unshifted_f,
                          band_filter=band_unshifted_f, eigvals=eigvals, eigvals_bottom=True,
                          save_pdf=True, figsize=(8, 4))

    prior_kernel = Wavelet(L, low_pass=low_scale, scales=band_scales, low_filter=low_f, band_filter=band_f)
    wave_signal = sample_signal_from_prior(prior_kernel)
    vmin = wave_signal.min()
    vmax = wave_signal.max()
    plt.figure()
    fig, ax = plt.subplots(figsize=(6, 3))
    ax.axis("off")
    plot_signal(graph, wave_signal, ax=ax, plot_name="full signal", save_as="full_signal" if store_files else None)
    plt.title("")
    fig.savefig("full_signal.pdf")

    fourier_coeffs = eigvecs.T @ wave_signal

    low_pass_coeffs = fourier_coeffs.copy()
    low_pass_coeffs[4:] = 0.0
    low_pass_signal = eigvecs @ low_pass_coeffs
    plt.figure()
    fig, ax = plt.subplots(figsize=(6, 3))
    ax.axis("off")
    plot_signal(graph, low_pass_signal, ax=ax, plot_name="low-pass signal", save_as="low_pass_signal" if store_files else None)
    plt.title("")
    fig.savefig("low_pass_signal.pdf")

    band_pass1_coeffs = fourier_coeffs.copy()
    band_pass1_coeffs[0:4] = 0.0
    band_pass1_coeffs[8:] = 0.0
    band_pass1_signal = eigvecs @ band_pass1_coeffs
    plt.figure()
    fig, ax = plt.subplots(figsize=(6, 3))
    ax.axis("off")
    plot_signal(graph, band_pass1_signal, ax=ax, plot_name="band-pass 1 signal", save_as="band_pass1_signal" if store_files else None)
    plt.title("")
    fig.savefig("band_pass1_signal.pdf")

    band_pass2_coeffs = fourier_coeffs.copy()
    band_pass2_coeffs[:8] = 0.0
    band_pass2_signal = eigvecs @ band_pass2_coeffs
    plt.figure()
    fig, ax = plt.subplots(figsize=(6, 3))
    ax.axis("off")
    plot_signal(graph, band_pass2_signal, ax=ax, plot_name="band-pass 2 signal", save_as="band_pass2_signal" if store_files else None)
    plt.title("")
    fig.savefig("band_pass2_signal.pdf")
