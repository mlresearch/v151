# from jax import numpy as np
import numpy as np
import matplotlib.pyplot as plt
from jax import grad, vmap

GD = True


def f(x_, y_):
    r = x_.reshape(-1, 1) * y_.reshape(-1, 1)
    if r.shape[0] == 1:  # jax bug
        r = np.reshape(r, ())
    return r


if GD:
    x0 = np.array([[1.0], [1.0]])
    steps = 300
    alpha = 0.1
    x_k = []
    y_k = []

    x = np.copy(x0)
    y = np.copy(x0)

    for i in range(steps):
        # Alternating
        x = x - alpha * np.array([grad(f, argnums=0)(x[0], x[1]), [0]])
        x = x - alpha * np.array([[0], -grad(f, argnums=1)(x[0], x[1])])

        # Simultaneous
        y = y - alpha * np.array([grad(f, argnums=0)(y[0], y[1]), -grad(f, argnums=1)(y[0], y[1])])

        y_k.append(y)
        x_k.append(x)

    x_k = np.array(x_k)
    y_k = np.array(y_k)

    XX, YY = np.meshgrid(np.linspace(-2, 2, 20), np.linspace(-2, 2, 20))

    dX_dx = vmap(grad(f, argnums=0), in_axes=(0, 0))(XX.reshape(-1, 1), YY.reshape(-1, 1)).reshape(XX.shape)
    dx_dy = vmap(grad(lambda x_, y_: -f(x_, y_), argnums=1), in_axes=(0, 0))(XX.reshape(-1, 1) - dX_dx.reshape(-1, 1),
                                                                             YY.reshape(-1, 1)).reshape(
        YY.shape)

    plt.quiver(XX, YY, XX - dX_dx, YY - dx_dy, angles='xy', scale_units='xy')

    plt.plot(x_k[:, 0, 0], x_k[:, 1, 0])
    plt.xlim(-2, 2)
    plt.ylim(-2, 2)
    plt.plot(0, 0, 'r*', ms=10)
    plt.plot(x_k[0, 0, 0], x_k[0, 1, 0], 'bx', ms=10)
    plt.plot(x_k[10, 0, 0], x_k[10, 1, 0], 'gx', ms=10)

    plt.title('GD Alternating Update')
    plt.show()

    dX_dx = vmap(grad(f, argnums=0), in_axes=(0, 0))(XX.reshape(-1, 1), YY.reshape(-1, 1)).reshape(XX.shape)
    dx_dy = vmap(grad(lambda x_, y_: -f(x_, y_), argnums=1), in_axes=(0, 0))(XX.reshape(-1, 1),
                                                                             YY.reshape(-1, 1)).reshape(YY.shape)

    plt.quiver(XX, YY, XX - dX_dx, YY - dx_dy, angles='xy', scale_units='xy')

    x_k = y_k
    plt.plot(x_k[:, 0, 0], x_k[:, 1, 0])
    plt.xlim(-2, 2)
    plt.ylim(-2, 2)
    plt.plot(0, 0, 'r*', ms=10)
    plt.plot(x_k[0, 0, 0], x_k[0, 1, 0], 'bx', ms=10)
    plt.plot(x_k[10, 0, 0], x_k[10, 1, 0], 'gx', ms=10)
    plt.title('GD Simultaneous Update')
    plt.show()

    print(x_k)

for B in list((-0.1, 0.1)):
    #### --- Polyak's  Momentum

    x0 = np.array([[1.0], [1.0]])
    steps = 1000  # need to increase the number of step
    alpha = 0.25  # need to increase the learning rate.
    x_k = []
    y_k = []

    x = np.copy(x0)
    y = np.copy(x0)
    # B = -0.1  # change B here - or +
    for i in range(steps):
        # Alternating
        m = (x - x_k[- 2]) if len(x_k) >= 2 else np.zeros(2)
        x = x - alpha * np.array([grad(f, argnums=0)(x[0], x[1]), [0]]) + B * m[0]
        x = x - alpha * np.array([[0], -grad(f, argnums=1)(x[0], x[1])]) + B * m[1]

        x_k.append(x)

    # # ---
    x_k = np.array(x_k)

    plt.plot(x_k[:, 0, 0], x_k[:, 1, 0])
    plt.xlim(-2, 2)
    plt.ylim(-2, 2)
    plt.plot(0, 0, 'r*', ms=10)
    plt.plot(x_k[0, 0, 0], x_k[0, 1, 0], 'bx', ms=10)
    plt.plot(x_k[10, 0, 0], x_k[10, 1, 0], 'gx', ms=10)

    plt.plot(x_k[-1, 0, 0], x_k[-1, 1, 0], 'bo', ms=10)

    plt.title(f'Polyaks Momentum B={B} Alternating Update')
    plt.show()

#### --- Polyak's  Momentum

x0 = np.array([[1.0], [1.0]])
steps = 300
alpha = 0.25
x_k = []
y_k = []

x = np.copy(x0)
y = np.copy(x0)

B = -0.1 +0 #0.1j #+ 0.1j

Bprev_xt = B * np.copy(x0)
for i in range(steps):
    # Alternating
    # Bprev_xt=B*Bprev_xt
    m = np.real(0.5 * (np.conj(-Bprev_xt + B * x) + ( -Bprev_xt + B * x)))
    Bprev_xt = B * x
    x = x - alpha * np.array([grad(f, argnums=0)(x[0], x[1]), [0]]) + m
    x = x - alpha * np.array([[0], -grad(f, argnums=1)(x[0], x[1])]) + m

    x_k.append(x)

# # ---
x_k = np.real(np.array(x_k))

plt.plot(x_k[:, 0, 0], x_k[:, 1, 0])
plt.xlim(-2, 2)
plt.ylim(-2, 2)
plt.plot(0, 0, 'r*', ms=10)
plt.plot(x_k[0, 0, 0], x_k[0, 1, 0], 'bx', ms=10)
plt.plot(x_k[10, 0, 0], x_k[10, 1, 0], 'gx', ms=10)

plt.plot(x_k[-1, 0, 0], x_k[-1, 1, 0], 'bo', ms=10)

plt.title(f'Complex Polyaks Momentum B={B} Alternating Update')
plt.show()
