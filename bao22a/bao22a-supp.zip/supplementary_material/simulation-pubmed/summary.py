import argparse

import mlflow
import numpy as np
import pandas as pd
from scipy import stats
from scipy.stats import sem


def hypothesis_testing(results, alpha=.05, lower_is_better=True, exclude=[]):
    n = len(results)
    results = np.array(results)
    for ex in exclude:
        results[ex] = (10000 if lower_is_better else 0) \
                * np.ones_like(results[ex])
    signif = [False] * n

    if lower_is_better:
        i_best = np.argmin([result.mean() for result in results])
    else:
        i_best = np.argmax([result.mean() for result in results])

    for i in range(n):
        if i == i_best:
            signif[i] = True
        else:
            t_stat, p_ = stats.ttest_ind(results[i], results[i_best])
            p = 0.5 * p_  # two-sided p-value -> one-sided p-value
            signif[i] = p > alpha

    return signif


def create_table(runs, metric='clus_acc', lower_is_better=False, latex=False):
    table = {}
    #methods = runs['params.loss'].unique()
    methods = [
        'cips', 'mcl', 'dml', 'standard',
    ]
    exclude = ['standard']
    exclude = [methods.index(m) for m in exclude]
    datasets = np.sort(runs['params.data'].unique())
    for dataset in datasets:
        df = runs.query(f'`params.data` == "{dataset}"')
        results = [df.query(f'`params.method` == "{method}"')[f'metrics.{metric}']
                   for method in methods]
        s = hypothesis_testing(
            results,
            lower_is_better=lower_is_better,
            exclude=exclude,
        )
        table[f'\\textsf{{{dataset}}}' if latex else dataset] = [
            f"\\textbf{{{results[i].mean()*100:.1f} ({sem(results[i]*100):.1f})}}" if latex and s[i] else
            f"{results[i].mean()*100:.1f} ({sem(results[i]*100):.1f})" if latex and not s[i] else
            f"{results[i].mean()*100:.2f} ({sem(results[i]*100):.1f}) {'*' if s[i] else ' '}"
            for i in range(len(results))
        ]
    df = pd.DataFrame(table, index=methods).transpose()

    print(f"========== [{metric}] =========")
    if latex:
        print(df.to_latex(escape=False))
    else:
        print(df)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--latex', action='store_true')
    parser.add_argument('--name', type=str, default="baseline",
                        help="experiment name")
    args = parser.parse_args()

    experiment = mlflow.get_experiment_by_name(args.name)
    runs = mlflow.search_runs(experiment_ids=[experiment.experiment_id])

    create_table(runs, 'clus_acc', lower_is_better=False, latex=args.latex)
