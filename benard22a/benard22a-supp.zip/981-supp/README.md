
1. Go to the folder containing SHAFF code
cd 981-supp

2. Install the required R packages from CRAN, using the following R command:
Rscript -e "install.packages(c('ranger', 'mvtnorm', 'MASS', 'Matrix', 'CombMSC', 'nnls', 'ggplot2', 'parallel'))"

3. Install our implementation of SHAFF with the following R command:
Rscript -e "install.packages('shaff_0.1.0.tar.gz', repos = NULL, type = 'source')"

4. Execute the scripts to reproduce experiments 1 and 2:
Rscript shaff_xp_1.R
Rscript shaff_xp_2.R
