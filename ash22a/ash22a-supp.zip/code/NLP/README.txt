# Add src to root
export PYTHONPATH=$$PYTHONPATH:src

# Get the data

- mkdir .data

- Downwnload the data from https://nlp.cs.princeton.edu/CURL/raw/wn.tar.gz and place it in inside .data

- Run user provided script python3 src/task/wikinet_filter.py

- This will create two folders RAW and FILTERED inside .data/wn/


# Requirements 
Install requirements in requirements.txt

We support use python3. We tested with python3.7 and PyTorch 1.7.1.

# Run the code

## For supervised training
sh local_run_supervised_wiki3029.sh

## For NCE training
sh local_run_wiki3029.sh
