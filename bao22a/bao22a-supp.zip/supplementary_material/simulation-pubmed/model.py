import numpy as np
from skorch import NeuralNetBinaryClassifier
import torch
import torch.nn.functional as F


class LinearClassifier(torch.nn.Module):
    def __init__(self, n_features, *arg, **kwarg):
        super(LinearClassifier, self).__init__()
        self.f = torch.nn.Linear(n_features, 1)

    def forward(self, x):
        return self.f(x)


class MLP(torch.nn.Module):
    def __init__(self, n_features, n_units=100, *arg, **kwarg):
        super(MLP, self).__init__()
        self.f1 = torch.nn.Linear(n_features, n_units)
        self.f2 = torch.nn.Linear(n_units, n_units)
        self.f3 = torch.nn.Linear(n_units, n_units)
        self.f4 = torch.nn.Linear(n_units, 1)
        self.af = F.softplus

    def forward(self, x):
        h = self.embed(x)
        h = self.af(h)
        h = self.f4(h)
        return h

    def embed(self, x):
        h = self.f1(x)
        h = self.af(h)
        h = self.f2(h)
        h = self.af(h)
        h = self.f3(h)
        return h


class SimilarityClassifier(torch.nn.Module):
    def __init__(self,
                 base_module,
                 n_features,
                 n_units=100,
                 use_similarity_labels=False,
                 use_similarity_likelihood=False,
                 train_embedding=False,
    ):
        super(SimilarityClassifier, self).__init__()

        if use_similarity_likelihood and not use_similarity_labels:
            raise ValueError(
                "`use_similarity_likelihood` requires "
                "`use_similarity_labels=True`")

        if train_embedding and not use_similarity_labels:
            raise ValueError(
                "`train_embedding` requires "
                "`use_similarity_labels=True`")

        self.module = base_module(
            n_features=n_features,
            n_units=n_units,
        )
        self.n_features = n_features
        self.use_similarity_labels = use_similarity_labels
        self.use_similarity_likelihood = use_similarity_likelihood
        self.train_embedding = train_embedding

    def forward(self, x):
        if self.n_features * 2 == x.size()[1]:
            assert self.use_similarity_labels

            if not self.train_embedding:
                x0 = x[:, :self.n_features]
                y0 = self.module.forward(x0)
                x1 = x[:, self.n_features:]
                y1 = self.module.forward(x1)

                if self.use_similarity_likelihood:
                    # implementation for MCL
                    sim_inv_logit = torch.sigmoid(y0) * torch.sigmoid(y1) + \
                        (1 - torch.sigmoid(y0)) * (1 - torch.sigmoid(y1))
                    sim_inv_logit = torch.clamp(
                        sim_inv_logit, min=1e-3, max=1-1e-3,
                    )

                    # make output compatible with inverse logit
                    sim_logit = torch.log(sim_inv_logit / (1 - sim_inv_logit))
                    return sim_logit

                else:
                    # implementation for CIPS
                    return y0 * y1

            else:
                # implementation for metric learning (based on L2 distance)
                x0 = x[:, :self.n_features]
                h0 = self.module.embed(x0)
                x1 = x[:, self.n_features:]
                h1 = self.module.embed(x1)

                return torch.linalg.norm(h0 - h1, ord=2, dim=1)

        else:
            return self.module.forward(x)


class MyNeuralNetClassifier(NeuralNetBinaryClassifier):
    @property
    def classes_(self):
        return np.array([0, 1])
