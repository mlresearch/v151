import numpy as np
import os
import pandas as pd
import itertools
import sys
import matplotlib.pyplot as plt

def file_suffix(name, alg, m, n_block, d, block):
    return "%s_%s_%s_machines_%s_%s_block_%s" % (name, alg, m, n_block, d, block)

def collect_results(hp_file, name, n_block, d, reps):
    wallclock_by_alg = {}
    its_by_alg = {}
    df = pd.read_csv(hp_file, sep=' ')
    for index, row in df.iterrows():
        alg = row['alg']
        m = row['machines']
        block = row['blocks']
        #step_index = int(row[3])
        suffix = file_suffix(name, alg, m, n_block, d, block)
        all_stats = []
        all_stats_its = []
        for i in range(reps):
            prefix = "rep_%s-" % i
            filename = name + "/" + suffix +  "/" + prefix + suffix
            try:
                stats = np.genfromtxt("%s/statistics.txt" % filename)
                all_stats.append(stats[-2])
                all_stats_its.append(stats[2])
            except:
                print("Failed to gather statistics from: %s" % filename)
                continue
        mean = np.mean(all_stats)
        stv = np.sqrt(np.mean(np.square(all_stats - mean)))
        mean_its = np.mean(all_stats_its)
        stv_its = np.sqrt(np.mean(np.square(all_stats_its - mean_its)))
        if alg not in wallclock_by_alg:
            wallclock_by_alg[alg] = {}
            its_by_alg[alg] = {}
        wallclock_by_alg[alg][m] = [mean, stv]
        its_by_alg[alg][m] = [mean_its, stv_its]
    return wallclock_by_alg, its_by_alg

def plot_results(results_by_alg, name, ylabel, title):
    markers = {'adsaga': 'X', 'asgd': 'P', 'iag': 'o', 'asaga': 'v', 'sync_adsaga': 'D', 'sync_asgd': 'v', 'adsaga_hetero': 'X'}#itertools.cycle(('X','P','o', 'v', 'D' )) 
    colors =  {'adsaga': 'r', 'asgd': 'g', 'iag': 'orange', 'asaga': 'm', 'sync_adsaga': 'c', 'sync_asgd': 'pink', 'adsaga_hetero': 'c'}#itertools.cycle(('r','g','orange', 'm', 'c'))
    labels = {'adsaga': 'ADSAGA Vanilla: Distributed (this work)', 'asgd': 'SGD: Distributed', 'iag': 'IAG: Distributed', 'asaga': 'ASAGA: Shared', 'sync_adsaga': 'Minibatch SAGA: Synchronous', 'sync_asgd': 'Minibatch SGD', 'adsaga_hetero': 'ADSAGA: Distributed (this work)'}
    styles =  {'adsaga': 'full', 'asgd': 'none', 'iag': 'none', 'asaga': 'none', 'sync_adsaga': 'none', 'sync_asgd': 'none', 'adsaga_hetero': 'full' }
    #ordered_algs = ['adsaga', 'asgd', 'iag', 'asaga', 'sync_adsaga']  
    ordered_algs = ['adsaga', 'iag', 'sync_adsaga', 'adsaga_hetero'] #['adsaga', 'iag', 'asgd', 'sync_adsaga', 'sync_asgd'] 
    label_order = {}
    i = 0
    for alg, value in results_by_alg.items():
        if alg not in ordered_algs:
            continue
        label_order[alg] = i
        i += 1
        xs = []
        means = []
        stvs = []
        for m, data in value.items():
            xs.append(m)
            means.append(data[0])
            stvs.append(data[1])
        plt.errorbar(xs, means, stvs, marker=markers[alg], fillstyle=styles[alg], linestyle='None', color=colors[alg], label=labels[alg])
    plt.xlabel("Number of Machines")
    plt.ylabel(ylabel) # Can change this for other epsilon values
    handles, labels = plt.gca().get_legend_handles_labels()
    plt.legend([handles[label_order[alg]] for alg in ordered_algs],[labels[label_order[alg]] for alg in ordered_algs], loc='upper left')
    plt.legend(loc='upper right')
    plt.xticks([1] + xs)
    #plt.ylim((0, 600))
    plt.savefig('%s/%s.png' % (name, title))
    plt.clf()
    plt.cla()

def select_best_hps(name, n_block, d, algs, ms, blocks, reps=1):
    df_algs = []
    df_ms = []
    df_blocks = []
    df_steps = []
    df_walls = []
    df_epsilon = []
    df_eta = []
    for alg in algs:
        for m in ms:
            best_block = blocks[0]
            best_step_index = 0
            best_eta = np.nan
            min_eps = np.inf
            walltime = np.inf
            for block in blocks:
                suffix = file_suffix(name, alg, m, n_block, d, block)
                for i in range(reps):
                    prefix = "rep_%s-" % i
                    filename = name + "/" + suffix +  "/" + prefix + suffix
                    try:
                        stats = np.genfromtxt("%s/statistics.txt" % filename, delimiter=' ')
                    except:
                        print("Failed to gather statistics from: %s" % filename)
                        continue
                    epsilons = stats.T[-4]
                    wallclocks = stats.T[-2]
                    etas = stats.T[-5]
                    best_eps = np.min(epsilons)
                    # print(best_eps)
                    # print(len(epsilons))
                    j = np.argmin(epsilons)
                    # print(j)
                    wall_clock = wallclocks[j]
                    eta = etas[j]
                    if best_eps < min_eps:
                        min_eps = best_eps
                        best_block = block
                        best_step_index = j
                        walltime = wall_clock
                        best_eta = eta
            df_eta.append(best_eta)
            df_algs.append(alg)
            df_ms.append(m)
            df_blocks.append(best_block)
            df_steps.append(best_step_index)
            df_walls.append(walltime)
            df_epsilon.append(min_eps)
    d = {'alg': df_algs, 'machines': df_ms, 'blocks' : df_blocks, 'stepindex': df_steps, 'eta': df_eta, 'walltime': df_walls, 'epsilon': df_epsilon}
    df = pd.DataFrame(data=d)
    df.to_csv('%s/best_hps.csv' % name, sep=' ')

# Usage: 
# python3 analyze.py <n_block> <d> <name> select <num_workers...>
# python3 analyze.py <n_block> <d> <name> collect <hpfile> <reps>
n_block = int(sys.argv[1])
d = int(sys.argv[2])
name = sys.argv[3]
opt = sys.argv[4]
algs = ['sync_asgd', 'adsaga', 'iag', 'asgd', 'sync_adsaga', 'adsaga_hetero', 'dummy']
blocks = [200]
if opt == 'select':
    print("Select")
    num_ms = len(sys.argv) - 5
    ms = [int(sys.argv[5 + i]) for i in range(num_ms)]
    select_best_hps(name, n_block, d, algs, ms, blocks)
elif opt == 'collect':
    wallclock_by_alg, its_by_alg = collect_results(sys.argv[5], name, n_block, d, int(sys.argv[6]))
    ywall = "Wallclock time (sec) to convergence threshold of " + r'$10^{-10}$'
    plot_results(wallclock_by_alg, name, ywall, "wallclocks")
    yits = "Iterations to convergence threshold of " + r'$10^{-10}$'
    plot_results(its_by_alg, name, yits, "iteration_complexity")
