Experiments, including random seeds, are in jupyter notebook files with self-explanatory filenames. Saved model parameters and training data are in corresponding directories.

The main portion of the code is in `double_net`.
