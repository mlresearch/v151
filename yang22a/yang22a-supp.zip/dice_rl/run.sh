
#!/bin/bash

python3 scripts.run_env --load_dir=$HOME/tmp
