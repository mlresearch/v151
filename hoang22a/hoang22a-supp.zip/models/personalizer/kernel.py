from models.nets.simsnet import *


class SIMSCov:
    def __init__(self, tower, aggregator, featurizer):
        self.tower = tower
        self.aggregator = aggregator
        self.featurizer = featurizer

    def cov(self, U, V = None):  # U and V are item lists
        if V is None:
            V = U

        [U_features, U_ids] = self.featurizer.featurize(U)
        [V_features, V_ids] = self.featurizer.featurize(V)

        U_embed, V_embed = self.tower([U_ids, U_features]), self.tower([V_ids, V_features])
        distances = []

        for i in range(len(U)):
            embeddings = []
            for component in U_embed:
                embeddings.append(tf.repeat([component[i, :]], repeats = [len(V)], axis = 0))
            distances.append(tf.transpose(self.aggregator([embeddings, V_embed])))

        output = K.layers.Concatenate(axis = 0)(distances)
        res, nudge = KB.exp(-0.5 * output), None

        if res.shape[0] == res.shape[1]:
            eig_min = KB.min(tf.cast(tf.linalg.eigvals(res), tf.float32)).numpy()
            if eig_min < 0:
                nudge = tf.cast((0.1 - eig_min) * KB.eye(len(U)), tf.float32)

        if nudge is not None:
            return res + nudge

        return KB.exp(-0.5 * output)


class SIMSCovV2:
    def __init__(self, simsengine, featurizer):
        self.simsengine = simsengine
        self.tower = self.simsengine.network.tower
        self.aggregator = self.simsengine.network.aggregator
        self.featurizer = featurizer

    def cov(self, U, V = None):  # U and V are item lists
        nudge = None
        if V is None:
            V = U

        [U_features, U_ids] = self.featurizer.featurize(U)
        [V_features, V_ids] = self.featurizer.featurize(V)

        U_embed, V_embed = self.tower([U_ids, U_features]), self.tower([V_ids, V_features])
        distances = []
        for i in range(len(U)):
            embeddings = []
            for component in U_embed:
                embeddings.append(tf.repeat([component[i, :]], repeats = [len(V)], axis = 0))
            distances.append(tf.transpose(self.aggregator([embeddings, V_embed])))

        output = K.layers.Concatenate(axis = 0)(distances)
        res = KB.exp(-0.5 * output)

        if res.shape[0] == res.shape[1]:
            eig_min = KB.min(tf.cast(tf.linalg.eigvals(res), tf.float32)).numpy()
            if eig_min < 0:
                nudge = tf.cast((0.1 - eig_min) * KB.eye(len(U)), tf.float32)

        if nudge is not None:
            return res + nudge
        return res


class SIMSMean:  # simply a constant mean function
    def __init__(self, c = 0.0):
        self.mean = tf.Variable([c], dtype = tf.float32)

    def m(self, U):  # simply the constant mean function; input form: (_, x_dim)
        return tf.ones((len(U), 1)) * self.mean