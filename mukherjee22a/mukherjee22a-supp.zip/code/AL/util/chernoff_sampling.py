

import cvxpy as cp
import numpy as np

from environment.Discrete_env import Discrete_env

import sys
sys.path.append("..")

    
def chernoff_sampling(mu, sig, hypo_idx):
    p = cp.Variable(mu.shape[0], nonneg=True)
    lower_bound = cp.Variable(1, nonneg=True)
        
    KL_matrix = np.zeros(mu.shape)
    for j in range(mu.shape[1]):
        KL_matrix[:,j] = np.square((mu[:, j] - mu[:, hypo_idx]) / sig)
    KL_matrix = np.delete(KL_matrix, hypo_idx, 1)
        
    prob = cp.Problem(
        cp.Maximize(lower_bound),
        [p.T @ KL_matrix >= lower_bound,
         cp.sum(p) == 1]
    )
        
    try:
        obj_value = prob.solve(solver='CVXOPT', kktsolver=cp.ROBUST_KKTSOLVER)
            
    except BaseException:
        return False
        
    return p.value

if __name__ == "__main__":
    #obj = Chernoff_Prop()
    env = Discrete_env()
    env.discrete_env1()
    print(np.around(chernoff_sampling(env.mu, 1.0, 1),3))



