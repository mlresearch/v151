This repository contains the PyTorch code for the paper "Stochastic Gaussian PAC-Bayes".
There are a few examples about how to run the code in the `main.py` script.
