
d= 8; %% maximum number of one-hop and two-hop neighbors of a node in the graph. For a 2D grid, d=8
epsilon = 0.5; %% accuracy of reconstruction
num_trial = 10; %% number of trials 
Nnodes =16;
C1=zeros(Nnodes,Nnodes,num_trial);
load(strcat('p',num2str(Nnodes),'.mat'));
f= ((1:4) -1)/4;
N = 5000;
lag=3;
initial = zeros(Nnodes,lag);
E = E_factor*randn(Nnodes,N+lag);
[temp] = DataGenerator(N+lag,h,E, initial,lag);
data = temp(:,lag+1:end);

S_hat=zeros(Nnodes,Nnodes,4);
for m = 0:N-1
    Rhat = 0;
    for n = m+1:N
        x_n = data(:,n);
        x_n_m = data(:,n-m);
        Rhat = Rhat+ x_n*x_n_m';
    end
    Rhat = Rhat/N;

    for l = 1:4
        S_hat(:,:,l) = S_hat(:,:,l)+ exp(-m*m)*Rhat*exp(-1j*2*m*f(l));       
    end
end

cvx_begin 
variable X1(Nnodes,Nnodes) complex hermitian;
variable X2(Nnodes,Nnodes) complex hermitian;
variable X3(Nnodes,Nnodes) complex hermitian ;
variable X4(Nnodes,Nnodes) complex hermitian ;
lambda = 0;
A = 1/4*( log_det(X1)+log_det(X2)+log_det(X3)+log_det(X4) );
B = 1/4*(  trace(S_hat(:,:,1)*X1)+trace(S_hat(:,:,2)*X2)+trace(S_hat(:,:,3)*X3)+trace(S_hat(:,:,4)*X4)   );
r_term = 0;
for i=1:16
   for j = 1:16
    r_term = r_term +(1/4*pow_abs(X1(i,j),1)+1/4*pow_abs(X2(i,j),1)+1/4*pow_abs(X3(i,j),1)+1/4*pow_abs(X4(i,j),1) ); 
   end
end

minimize -real(A)+ real(B) + lambda*real(r_term) ;
subject to
    X1 == hermitian_semidefinite(16)
    (eye(16) +1j*zeros(16))-X1 == hermitian_semidefinite(16)
    
    X2 == hermitian_semidefinite(16)
    (eye(16) +1j*zeros(16))-X2 == hermitian_semidefinite(16)
    
    X3 == hermitian_semidefinite(16)
    (eye(16) +1j*zeros(16))-X3 == hermitian_semidefinite(16)
    
    X4 == hermitian_semidefinite(16)
    (eye(16) +1j*zeros(16))-X4 == hermitian_semidefinite(16)
    cvx_end

X_ij_norm= zeros(Nnodes,Nnodes);
Recon_Jung= zeros(Nnodes,Nnodes);
for i=1:16
   for j = i:16
    X_ij_norm(i,j) =sqrt(1/4*pow_abs(X1(i,j),1)+1/4*pow_abs(X2(i,j),1)+1/4*pow_abs(X3(i,j),1)+1/4*pow_abs(X4(i,j),1) ); 
    if X_ij_norm(i,j)>2e-1
        Recon_Jung(i,j)=1;
        Recon_Jung(j,i)=1;        
    end
   end
   
end
 G = graph(Recon_Jung); figure; plot(G)
