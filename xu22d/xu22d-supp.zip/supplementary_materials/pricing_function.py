import scipy.stats as stats
def pricing(u, sigma, precision = 0.0001, B=1):
    # B = 1
    lb = u-2*sigma
    ub = u+2*sigma
    v = u
    while -lb+ub >= precision:
        h = 1 - stats.norm.cdf((v-u)/sigma)-v*1/sigma*stats.norm.pdf((v-u)/sigma)
        if h >= 0:
            lb = v
        else:
            ub = v
        v = (lb+ub)/2
    return v


# print(pricing(2,1))