

import sys
sys.path.append("..")

import numpy as np
from util.normal_pdf import normal_pdf

def new_prob_bayes_rule(posterior, mu, sig, source_idx, source_val):
    pdfs_at_observed_val = normal_pdf(mu[source_idx, :], sig, source_val)
    denom = np.sum(posterior * pdfs_at_observed_val)
    numer = posterior * pdfs_at_observed_val
    posterior = numer / denom
    return posterior



