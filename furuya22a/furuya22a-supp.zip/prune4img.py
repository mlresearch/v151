import argparse
import os

import numpy as np
import torch
import yaml

from src import get_module_logger
from src import spectralpruning as spec
from src.data.dataloader4img import mydataloader
from src.models.predict_model4img import evaluate
from src.models.prune_model import magnitude_weight_prune, random_weight_prune
from src.utils.model_rnn import prepare_trained_rnn


def main():
    logger = get_module_logger("prune")
    logger.debug("Begin...")
    parser = argparse.ArgumentParser()
    parser.add_argument("--wts_path", type=str, required=True, help="Path for weight parameter.")
    parser.add_argument("--m", type=int, default=None, help="Compressed hidden_size.")
    args = parser.parse_args()

    # Pruning preparations
    wts_path = args.wts_path
    m_sharp = args.m
    # Load configure yaml
    cfg = os.path.join(*wts_path.split("/")[:-2], "config.yaml")
    with open(cfg, "r") as f:
        data = yaml.load(f, Loader=yaml.SafeLoader)
    for key in data:
        args.__setattr__(key, data[key])
    logger.debug(args)

    # Model parameters
    hidden_size = args.hidden_size
    # output_size = args.output_size
    irnn = args.irnn

    # Learning parameters
    batch_size = args.batch_size

    # Dataset parameters
    dataset = args.dataset
    task = args.task
    data_dir = args.data_dir
    # _, input_size = calc_input_sizes(dataset, task)

    # Prepare dataloader
    train_dl, test_dl = mydataloader(dataset=dataset, task=task, data_dir=data_dir, batch_size=batch_size)
    logger.debug("Datasets are loaded.")

    # Check device
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    if torch.cuda.is_available():
        torch.backends.cudnn.benchmark = True
    logger.debug("GPU or CPU: %s" % device)

    # Calculate covariance matrix
    cov_path = os.path.join(os.path.dirname(wts_path), "cov.pkl")
    if not os.path.exists(cov_path):
        logger.debug("Calculating covariance matrix...")
        spec.save_cov4rnn(wts_path, irnn, train_dl, device)
    else:
        logger.debug("Skip calculation of covariance matrix.")
    cov = spec.load_cov(cov_path)

    # Greedy algorithm and Spectral Pruning
    logger.debug("Spectral Pruning...")
    sub = None
    sub_F = spec.calc_non_zero_rows_idx(cov)
    NZR = spec.calc_non_zero_rows_n(cov)
    if m_sharp is None:
        m_sharp = NZR
        # sub = sub_F
        logger.info("  for m_sharp = %d (NZR)" % NZR)
    else:
        logger.info("  for m_sharp = %d (NZR)" % NZR)
        logger.info("  for m_sharp = %d (user)" % m_sharp)
    n_prune = hidden_size ** 2 - m_sharp ** 2
    logger.info("  for n_prune = %d" % n_prune)

    # Compare models before/after Spectral Pruning
    logger.info("Compare some Pruning Methods:")
    n_sample = 5  # sampling for n-times
    logger.info("Original:")
    model = prepare_trained_rnn(torch.load(wts_path, map_location=device), irnn=irnn, requires_grad=False)
    acc = evaluate(model, test_dl, device=device)
    logger.info("Acc: {:.4f}".format(acc))

    logger.info("Spectral Pruning:")
    wts_pruned, _ = spec.prune_rnn_by_cov(
        torch.load(wts_path, map_location="cpu"), cov, m_sharp, sub=sub, sub_F=sub_F, pinv=False
    )
    model = prepare_trained_rnn(wts_pruned, irnn=irnn, requires_grad=False)
    acc = evaluate(model, test_dl, device=device)
    logger.info("Acc: {:.4f}".format(acc))

    logger.info("Spectral Pruning w/o reconstruction matrix:")
    wts_pruned, _ = spec.prune_rnn_by_cov_wo_reconstruction(
        torch.load(wts_path, map_location="cpu"), cov, m_sharp, sub=sub, sub_F=sub_F, pinv=False
    )
    model = prepare_trained_rnn(wts_pruned, irnn=irnn, requires_grad=False)
    acc = evaluate(model, test_dl, device=device)
    logger.info("Acc: {:.4f}".format(acc))
    torch.save(wts_pruned, os.path.join(os.path.dirname(wts_path), "wts_pruned_wo.pth"))
    logger.info("Saved pruned weight w/o reconstruction.")

    logger.info("Random Pruning w/  reconstruction matrix:")
    accs = []
    for i in range(n_sample):
        sub_random = np.sort(np.random.permutation(sub_F)[:m_sharp])
        wts_pruned, _ = spec.prune_rnn_by_cov(
            torch.load(wts_path, map_location="cpu"), cov, m_sharp, sub=sub_random, sub_F=sub_F, pinv=False
        )
        model = prepare_trained_rnn(wts_pruned, irnn=irnn, requires_grad=False)
        acc = evaluate(model, test_dl, device=device)
        accs.append(acc)
        torch.save(wts_pruned, os.path.join(os.path.dirname(wts_path), "wts_random_pruned%d.pth" % i))
        logger.info("Saved random pruned weight w/  reconstruction.")
    logger.info("Acc: %.4f (mean)" % np.mean(accs))

    logger.info("Random Pruning w/o reconstruction matrix:")
    accs = []
    for i in range(n_sample):
        sub_random = np.sort(np.random.permutation(sub_F)[:m_sharp])
        wts_pruned, _ = spec.prune_rnn_by_cov_wo_reconstruction(
            torch.load(wts_path, map_location="cpu"), cov, m_sharp, sub=sub_random, sub_F=sub_F, pinv=False
        )
        model = prepare_trained_rnn(wts_pruned, irnn=irnn, requires_grad=False)
        acc = evaluate(model, test_dl, device=device)
        accs.append(acc)
        torch.save(wts_pruned, os.path.join(os.path.dirname(wts_path), "wts_random_pruned_wo%d.pth" % i))
        logger.info("Saved random pruned weight w/o reconstruction.")
    logger.info("Acc: %.4f (mean)" % np.mean(accs))

    logger.info("Random Weight Pruning:")
    accs = []
    for i in range(n_sample):
        wts_pruned = random_weight_prune(torch.load(wts_path, map_location=device), n_prune)
        model = prepare_trained_rnn(wts_pruned, irnn=irnn, requires_grad=False)
        acc = evaluate(model, test_dl, device=device)
        accs.append(acc)
        torch.save(wts_pruned, os.path.join(os.path.dirname(wts_path), "wts_random_weight_pruned%d.pth" % i))
        logger.info("Saved random non-structured pruned weight.")
    logger.info("Acc: %.4f (mean)" % np.mean(accs))

    logger.info("Magnitude-based Weight Pruning:")
    wts_pruned = magnitude_weight_prune(torch.load(wts_path, map_location=device), n_prune)
    model = prepare_trained_rnn(wts_pruned, irnn=irnn, requires_grad=False)
    acc = evaluate(model, test_dl, device=device)
    logger.info("Acc: {:.4f}".format(acc))
    torch.save(wts_pruned, os.path.join(os.path.dirname(wts_path), "wts_magnitude_weight_pruned.pth"))
    logger.info("Saved magnitude non-structured pruned weight.")

    logger.debug("Done!!")


if __name__ == "__main__":
    main()
