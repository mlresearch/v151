function diff_norm = compute_diff_norm(weight_1, weight_2, sample_points,l,kernel_index)
diff_norm_square = 0;
[~,num_points] = size(sample_points);
diff_weight = weight_1 - weight_2;
for i = 1:num_points
    x_i = sample_points(i);
    w_i = diff_weight(i);
    for j = 1:num_points
        x_j = sample_points(j);
        w_j = diff_weight(j);
        diff_norm_square = diff_norm_square + w_i*w_j*kernel_function(x_i,x_j,l,kernel_index);
    end
end

diff_norm =sqrt(diff_norm_square);


