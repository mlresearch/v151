import argparse

from decomp_gen.models.incompleteTreeExtender import *
from decomp_gen.treeDataGenerator import *
from decomp_gen import configs

from decomp_gen.data_structures.dataset import GraphDataset, TreeGeneratorDataset

from decomp_gen.train_tree_generator import trainTreeModel, evaluate
from tqdm import tqdm

from decomp_gen.utils.eval_helper import (
    spectral_stats, orbit_stats_all, clustering_stats, degree_stats
)

SEED = 1234
TRAIN_RATIO = 0.7
VAL_RATIO = 0.1
TEST_RATIO = 1.0 - TRAIN_RATIO - VAL_RATIO

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

wrongGs = []

def parse():
    parser = argparse.ArgumentParser(description='')
    parser.add_argument('-f')
    parser.add_argument('--continue-training', type=bool, default=False)
    parser.add_argument('--model-name', type=str, default='tree_generator_tmp')
    parser.add_argument('--data-name', type=str, default='lobster',
                        help='dataset to be built')
    parser.add_argument('--epochs', type=int, default=5000,
                        help='number of epochs for training')
    parser.add_argument('--batch-size', type=int, default=64,
                        help='size of the batches')
    parser.add_argument('--tree-hidden-size', type=int, default=64,
                        help='hidden size of tree nodes representations')
    parser.add_argument('--mlp-hidden-size', type=int, default=64)
    parser.add_argument('--num-mlp-hidden-layers', type=int, default=2)
    parser.add_argument('--num-workers', default=0, type=int)

    args = parser.parse_args()

    return args


args = parse()
data_name = args.data_name
epochs = args.epochs
batch_size = args.batch_size
hidden_size = args.tree_hidden_size
data = GraphDataset(args.data_name, '{}.dat'.format(args.data_name))
mlp_sizes = [args.mlp_hidden_size] * args.num_mlp_hidden_layers


def negative_log_likelihood(output, y):
    y = torch.tensor(y).to(device)
    tmp = -(torch.log(output.gather(1, y.view(-1, 1))))
    if torch.isnan(tmp).any():
        print('in loss: ')
        breakpoint()

    tmp = tmp.sum()

    return tmp


def generateTree(model, MaskLenForData, seed=12345):
    np.random.seed(seed)
    GT = GeneratingTree()
    NLL = torch.tensor([0.0])
    count = 0
    TPLR = []
    while not GT.isFinished():
        T = GT.getSimpleTree()
        limits = GT.nextStepLimit()

        DGLT = dgl.DGLGraph(T)


        # p = nx.shortest_path_length(T, source=0)
        # for ii, v in enumerate(DGLT.nodes()):
        #     vv = int(v.item())
        #     d = torch.zeros((1, 4)).type(torch.FloatTensor)
        #     if vv == 0:
        #         d[0, 0] = 1.0
        #     else:
        #         d[0, 1] = 1.0
        #     d[0, 2] = float(T.degree[vv])
        #     d[0, 3] = float(p[vv])
        #     DGLT.nodes[[v]].data['d'] = d

        DGLT = [DGLT]

        mask = [0.0] * MaskLenForData
        if limits[1] == -1:
            limits[1] = MaskLenForData
        for i in range(limits[0], limits[1]):
            mask[i] = 1.0

        extendingNodes = [GT.currentNode().getLabel()]
        Masks = [mask]

        Masks = torch.tensor(Masks)
        Masks = cuda(Masks)

        if limits[1] - limits[0] > 1:
            output = model(DGLT, extendingNodes, Masks)
            probs = [i.item() for i in output[0]]
            l = np.random.multinomial(1, probs / np.sum(probs), size=1)
            l = np.argmax(l)
            y = [l]
            nll = negative_log_likelihood(output, y)
            NLL += nll
        else:
            l = limits[0]

        GT.makeStep(l)
        TPLR.append(l)

    return GT.getSimpleTree(), GT, NLL


def eval_acc_lobster_graph(G_list):
    G_list = [copy.deepcopy(gg) for gg in G_list]

    count = 0
    for gg in G_list:
        if is_lobster_graph(gg):
            count += 1
    #     else:
    #         break

    return count / float(len(G_list))


wrongGs = []


def is_lobster_graph(G):
    GG = copy.deepcopy(G)
    """
      Check a given graph is a lobster graph or not
  
      Removing leaf nodes twice:
  
      lobster -> caterpillar -> path
  
    """
    ### Check if G is a tree
    if nx.is_tree(G):
        # import pdb; pdb.set_trace()
        ### Check if G is a path after removing leaves twice
        leaves = [n for n, d in G.degree() if d == 1]
        G.remove_nodes_from(leaves)

        leaves = [n for n, d in G.degree() if d == 1]
        G.remove_nodes_from(leaves)

        num_nodes = len(G.nodes())
        num_degree_one = [d for n, d in G.degree() if d == 1]
        num_degree_two = [d for n, d in G.degree() if d == 2]

        if sum(num_degree_one) == 2 and sum(num_degree_two) == 2 * (num_nodes - 2):
            return True
        elif sum(num_degree_one) == 0 and sum(num_degree_two) == 0:
            return True
        else:
            print("Tree but not lobster")
            wrongGs.append([GG, G])
            #       nx.draw(G)
            #       draw_graph_list([G],1,1)
            return False
    else:
        print("Not tree")
        #     nx.draw(GG)
        #     draw_graph_list([G],1,1)
        return False


def generate_lobster_ref():
    graphs = []
    p1 = 0.7
    p2 = 0.7
    count = 0
    min_node = 10
    max_node = 100
    max_edge = 0
    mean_node = 80
    num_graphs = 100

    MaxLen = 0
    seed_tmp = 123456
    while count < num_graphs:
        G = nx.random_lobster(mean_node, p1, p2, seed=seed_tmp)
        if min_node <= len(G.nodes()) <= max_node:
            graphs.append(G)
            count += 1

        seed_tmp += 1

    return graphs

def eval_acc_random_tree(gen_graphs):
    correct_cnt = 0
    for g in gen_graphs:
        if nx.is_tree(g):
            correct_cnt += 1

    return correct_cnt/float(len(gen_graphs))


def main():
    name = "{}_tree_generator".format(data_name)

    graphs = data.graphs
    MaxLen = data.max_tree_diam

    print("MaxLen: ", MaxLen)
    trainData, validationData, testData, MaskLenForData = getTreeDataSet(graphs=graphs, samplePerGraph=1,
                                                                         MaxLen=MaxLen, name=name,
                                                                         makeFromTree=True)

    model = incompleteTreeExtender(hidden_size, MaskLen=MaskLenForData, mlp_sizes=mlp_sizes, max_node_size=data.N)

    checkpoint = None

    train_dataset = TreeGeneratorDataset(trainData)
    eval_dataset = TreeGeneratorDataset(validationData)
    test_dataset = TreeGeneratorDataset(testData)



    if args.continue_training:
        print('loading model to continue training ....')
        adr = os.path.join(configs.root_dir, 'saved_models', args.model_name + '_state_dict')
        # model = torch.load(adr, map_location=device)
        try:
            checkpoint = torch.load(adr)
            model.load_state_dict(checkpoint['model_state_dict'])
        except:
            print('state dict not found trying to load model . . .')
            adr = os.path.join(configs.root_dir, 'saved_models', args.model_name)
            model = torch.load(adr, map_location=device)


    model = model.to(device)

    num_train_graphs = int(len(data) * TRAIN_RATIO)
    num_validation_graphs = int(len(data) * VAL_RATIO)
    num_test_graphs = int(len(data) * TEST_RATIO)

    try:
        trainTreeModel(model, train_dataset, eval_dataset, args.model_name,
                       num_train_graphs, num_validation_graphs, checkpoint)
    except:
        print("train finished")

    total_nll, avg_nll = evaluate(model=model, validation=test_dataset)
    print("test average nll: ", avg_nll)
    print("test average per graph nll: ", total_nll / num_test_graphs)
    print("test total nll: ", total_nll)


    seed = 1375
    gen_graphs = []
    i=0
    while i < 100:
        try:
            g, _, _ = generateTree(model=model, MaskLenForData=model.MaskLen, seed=seed)
            if 10 <= len(g.nodes()) <= 100:
                gen_graphs.append(copy.deepcopy(g))
                i += 1

        except:
            print('out of bound, generating again')
        seed += 1

    if data_name == 'lobster':
        print("Evaluation accuracy: ", eval_acc_lobster_graph(gen_graphs))
    elif data_name == 'random_tree':
        print("Evaluation accuracy: ", eval_acc_random_tree(gen_graphs))

    test_trees = graphs[int(len(graphs)*(1.0 - TEST_RATIO)):]
    # ref_test_graphs = [x.getSimpleTree() for x in test_trees]
    ref_test_graphs = generate_lobster_ref()
    deg_stats = degree_stats(ref_test_graphs, gen_graphs)
    spec_stats = spectral_stats(ref_test_graphs, gen_graphs)
    clus_stats = clustering_stats(ref_test_graphs, gen_graphs)
    mmd_dist = orbit_stats_all(ref_test_graphs, gen_graphs)

    print('degree_stats: ', deg_stats)
    print('clustering_stats: ', clus_stats)
    print('orbit_stats_all: ', mmd_dist)
    print('spectral_stats: ', spec_stats)




if __name__ == "__main__":
    main()
