import networkx as nx
import copy
from decomp_gen.data_structures.incomplete_dt import InCompleteDT


class GeneratingTree:

    def __init__(self):
        # self.id = id
        T = nx.Graph()
        T.add_node(0)
        self.IDT = InCompleteDT(T)
        self.IDT2 = None
        self.SecondPathStarted = False
        self.root = self.IDT.getRoot()

        self.step = 0
        self.diam = -1
        self.Stack = [self.root]
        self.centerRootConditionSatisfied = False

    @staticmethod
    def checkCanonicalNameValidity(cname):
        # Test:
        # print("Passed parantheses check test")

        children = []
        val = 0

        if cname[0] == 0 or cname[-1] == 1:
            return False

        cname = cname[1:-1]

        startPoint = 0
        for i in range(len(cname)):
            if cname[i] == '1':
                val = val + 1
            else:
                val = val - 1
            if val < 0:
                return False
            if val == 0:
                children.append(cname[startPoint:i + 1])
                startPoint = i + 1

        if val != 0:
            return False

        for i in range(len(children) - 1):
            if children[i + 1] > children[i]:
                return False

        for child in children:
            res = GeneratingTree.checkCanonicalNameValidity(child)
            if res == False:
                return False
        return True

    def getDiam(self):
        return self.diam

    def getSimpleTree(self):
        return self.IDT.getSimpleTree()

    def showTree(self, printNodes=False):
        self.IDT.showTree(printNodes)

    def showSecondRootTree(self, printNodes=False):
        self.IDT2.showTree(printNodes)

    def isFinished(self):
        if len(self.Stack) == 0:
            return True
        else:
            return False

    def currentNode(self):
        if len(self.Stack) > 0:
            return self.Stack[-1]
        else:
            return None

    def isValid(self):
        res1 = GeneratingTree.checkCanonicalNameValidity(self.IDT.getCanonicalName())
        res2 = True
        if self.SecondPathStarted and not self.centerRootConditionSatisfied:
            name1 = self.IDT.getCanonicalName()
            name2 = self.IDT2.getCanonicalName()
            if name1 >= name2:
                res2 = True
            else:
                res2 = False
        return (res1 and res2)

    def __addPath(self, nodeID, l):
        prevID = nodeID
        for i in range(l):
            newNode = self.IDT.addSuperNode(prevID)
            if self.step > 0:
                self.IDT2.addSuperNode(prevID)
            prevID = newNode.getLabel()
            self.Stack.append(newNode)
        self.Stack.pop()  # Removing leaf from stack

    def makeStep(self, l):
        if self.step == 0:
            self.diam = l
        elif len(self.Stack) > 0:
            if self.Stack[-1] == self.root and len(self.root.getChildren()) == 1:
                self.SecondPathStarted = True
                if l == self.diam:
                    self.centerRootConditionSatisfied = True
        if l == 0:
            self.Stack.pop()
            return
        self.__addPath(self.Stack[-1].getLabel(), l)
        if self.step == 0:
            self.IDT2 = copy.deepcopy(self.IDT)
            self.IDT2.makeRooted(self.IDT2.getNodes()[1])
        self.step += 1

    def nextStepLimit(self):
        if self.step == 0:
            return [0, -1]

        if (len(self.Stack) == 0):
            print("Process Ended")
            return [-1, -1]

        if self.Stack[-1] == self.root and len(self.root.getChildren()) == 1:
            return [self.diam - 1, self.diam + 1]
        else:
            prevID = self.Stack[-1].getLabel()
            t = 0
            while (self.isValid()):
                newNode = self.IDT.addSuperNode(prevID)
                self.IDT2.addSuperNode(prevID)
                prevID = newNode.getLabel()
                t = t + 1
            for i in range(t):
                self.IDT.deleteLastNode()
                self.IDT2.deleteLastNode()
            return [0, t]
