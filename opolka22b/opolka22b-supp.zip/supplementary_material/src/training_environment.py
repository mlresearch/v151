import pathlib
import sys
import time
from datetime import datetime
import numpy as np
import os
import pickle as pk
from collections import defaultdict
from pathlib import Path


class TrainingSettings:
    experiment_name = "test"
    run_module = None

    ### data set ###
    dataset_name = None
    dataset_folder = "../../data/"
    dataset_path = "../data/us_air_lines"
    node2vec_embeddings = True
    test_fraction = 0.1
    missing_frac = None
    train_set_frac = None
    perturb_frac = None

    ### model ###
    jump_gp = True
    float_type = np.float32
    sparse = False
    initial_lengthscale = 1.0
    num_inducing_nodes = None
    num_inducing_edges = None
    num_layers = 2
    num_convs = 2
    hidden_dim = 33
    jitter = 1e-5
    train_num_samples = 1
    test_num_samples = 50
    num_node_samples = (20, 10)

    ### training ###
    cp_folder = "../../checkpoints/"
    starting_seed = 1234
    seed = 1234
    batch_size = 32
    val_batch_size = 32
    test_batch_size = 16
    lr = 0.005
    gradient_clip = 500.0
    lr_schedule = (1500, )
    cold_posterior_period = 50       # Number of epochs during which a cold posterior should be used for optimisation.
    num_epochs = 500
    validate_every = 1
    convergence_stop = 1e-2     # stop once the training loss decreases by less than this amount over the last 3 epochs
    convergence_stop_epoch = 50 # Stop once the validation metrics has not decreased for this many epochs
    write_log_every = 20
    print_hparams_every = 20

    @staticmethod
    def update_setting(**settings):
        for key, value in settings.items():
            if not hasattr(TrainingSettings, key):
                raise ValueError(f"Attribute {key} not a valid hyperparameter.")
            setattr(TrainingSettings, key, value)

    @staticmethod
    def settigns_dict():
        return {attr: getattr(TrainingSettings, attr)
                for attr in dir(TrainingSettings)
                if (not attr.startswith("__")
                    and not callable(getattr(TrainingSettings,
                                             attr)))}


    @staticmethod
    def settings_description():
        settings_dict = TrainingSettings.settigns_dict()
        return parameter_description_from_dict(settings_dict)

    @staticmethod
    def write_summary_file(filepath):
        filepath = (Path(filepath) if not isinstance(filepath, Path)
                    else filepath)
        settings_dict = TrainingSettings.settigns_dict()
        with filepath.with_suffix(".pk").open("wb") as fd:
            pk.dump(settings_dict, fd)
        settings_description = TrainingSettings.settings_description()
        with filepath.open("w") as fd:
            fd.write(settings_description)


class TrainingEnvironment:

    @staticmethod
    def _process_settings(hyperparam_settings):
        """
        Takes a dictionary of lists/scalars and turns it into a list of
        dictionaries of scalars.
        """
        max_length = max([len(l)
                          for l in hyperparam_settings.values()
                          if type(l) is list]+[1])
        hyperparam_settings = {k: (l if type(l) is list else [l]*max_length)
                               for k, l in hyperparam_settings.items()}
        # Go from dictionary of lists to list of dictionaries
        dicts = [dict(zip(hyperparam_settings, x))
                 for x in zip(*hyperparam_settings.values())]
        return dicts

    @staticmethod
    def hyperparameter_search(training_settings, runs, start_experiment_f,
                              start_run=0):
        """
        :param training_settings: Dictionary containing hyperparameters and
        other training settings. Keys may only be attributes of the
        TrainingSettings class. Values may be scalars or lists. Using lists
        allows to specify the search space. All lists must have the same
        length.
        :param runs: Number of runs to perform for each training setting.
        :param start_experiment_f: Method for running an experiment. Must
        return a single measure of performance.
        :param start_run: Index of the first run. Allows to restart training
        at a specific run index.
        :return:
        """
        # If an experiment name is specified in the training settings, create
        # a folder for this experiment where als run checkpoints are stored in.
        if ("experiment_name" in training_settings.keys()
                and "cp_folder" in training_settings.keys()):
            training_settings["cp_folder"] = checkpoint_filepath(
                training_settings["cp_folder"],
                training_settings["experiment_name"],
                start_experiment_f.__module__)

        dicts = TrainingEnvironment._process_settings(training_settings)
        performances = [defaultdict(list) for _ in range(len(dicts))]
        # Make runs outer-loop to ensure initial results for all settings are
        # obtained asap
        for run_idx in range(start_run, runs):
            for settings_idx, settings_dict in enumerate(dicts):
                TrainingSettings.update_setting(**settings_dict)
                TrainingSettings.seed = (TrainingSettings.starting_seed
                                         * 3**run_idx)
                logger = start_experiment_f()
                best_results = logger.get_best_metrics()
                for key, value in best_results.items():
                    performances[settings_idx][key].append([value])
            # Write results (so far) to file
            TrainingEnvironment.write_summary(dicts, performances)

    @staticmethod
    def write_summary(settings_dicts, performances):
        """
        Writes the summary of all runs conducted (so far) for the different
        hyperarameter settings.
        :param settings_dicts:
        :param performances:
        :return:
        """
        summary = ""
        for settings, performances in zip(settings_dicts, performances):
            description = parameter_description_from_dict(settings)
            summary += description + "\n\n"
            num_runs = None
            full_list_string = ""
            for key in sorted(performances.keys()):
                num_runs = (len(performances[key]) if num_runs is None
                            else num_runs)
                mean = np.mean(performances[key], axis=0)
                std = np.std(performances[key], axis=0)
                if isinstance(mean, np.ndarray):
                    summary += f"{key}: {mean} +/- {std}\n"
                else:
                    summary += f"{key}: {mean:.5f} +/- {std:.5f}\n"
                # Add an entry with all individual entries to be appended
                # at the end of this entry
                full_list_string += f"{key}: {performances[key]}\n"
            summary += f"Runs so far: {num_runs}\n\n"
            summary += full_list_string
            summary += "\n\n\n"

        if not os.path.exists(TrainingSettings.cp_folder):
            os.makedirs(TrainingSettings.cp_folder)
        with open(os.path.join(TrainingSettings.cp_folder, "summary.txt"),
                  "w") as fd:
            fd.write(summary)


class PerformanceLogger:
    def __init__(self, metric_funcs, minimizer, log_filepath, write_every=20,
                 final_test_metrics=()):
        """
        :param metric_funcs: Dictionary of metric functions. A metric function
        accepts exactly one argument which is a dictionary of the metrics from
        a single epoch. It returns the corresponding metric.
        :param minimizer: Key of the variable that determines the final value
        stored in the summary. Usually the validation loss.
        :param final_test_metrics: List of strings matching keys in
        metric_funcs of those metrics that are not evaluated continuously
        during training but only at the very end.
        """
        self._metric_funcs = metric_funcs
        self._current_epoch_metrics = defaultdict(list)
        self.logs_dict = defaultdict(list)
        self.minimizer = minimizer
        self.log_filepath = log_filepath
        self.write_every = write_every
        self.final_test_metrics = list(final_test_metrics)
        self._write_countdown = write_every
        self._start_time = time.time()
        self.current_epoch = 0
        self.misc_info = {}

        if "duration" in metric_funcs:
            raise ValueError("Key \"duration\" is a reserved key for internal"
                             "use of PerformanceLogger.")

    def __getitem__(self, key):
        return self.logs_dict[key]

    def __setitem__(self, key, value):
        self.logs_dict[key] = value

    def add_values(self, metric_dict):
        for key, metric_batch in metric_dict.items():
            self._current_epoch_metrics[key].append(metric_batch)

    def complete_epoch(self, save_weights_fn=None):
        """
        Marks the epoch as finished and computes the epoch's metrics.
        """
        for key, metric_func in self._metric_funcs.items():
            metric = metric_func(self._current_epoch_metrics)
            self.logs_dict[key].append(metric)
        # add duration as additional metric
        duration = time.time() - self._start_time
        self.logs_dict["duration"].append(duration)
        self._start_time = time.time()

        self._current_epoch_metrics = defaultdict(list)
        self.current_epoch += 1

        # Save model weights if new minimum reached
        if (save_weights_fn is not None
                and np.argmin(self.logs_dict[self.minimizer])
                == len(self.logs_dict[self.minimizer])-1):
            save_weights_fn()
        # Write log if necessary
        if self.current_epoch % self.write_every == 0:
            self.write(self.log_filepath)

    def has_converged(self, convergence_diff=None, last_improvement=None,
                      earliest_epoch=0, offset=0, window=20):
        if self.current_epoch < earliest_epoch:
            return False
        # convergence based on insufficient difference in the minimizer metric
        if convergence_diff is not None:
            train_measures = self.logs_dict[self.minimizer]
            if len(train_measures) <= window+1: return False
            diff = train_measures[-1] - train_measures[-window]
            converged = (-diff < convergence_diff)
            return converged
        # convergence based on no more improvement for at least K epochs
        if last_improvement is not None:
            min_epoch = np.nanargmin(self.logs_dict[self.minimizer])
            if self.current_epoch - offset - min_epoch > last_improvement:
                return True
        return False

    def reached_relative_reduction(self, metric_key, rel_reduct):
        if len(self.logs_dict[metric_key]) == 0:
            return False
        initial_val = self.logs_dict[metric_key][0]
        current_val = self.logs_dict[metric_key][-1]
        diff = initial_val - current_val
        if diff / initial_val > rel_reduct:
            return True
        return False

    def epoch_summary(self):
        summary = f"{self.current_epoch}:"
        for key in self._metric_funcs.keys():
            vals = self.logs_dict[key]
            if len(vals) == 0 or np.isnan(vals[-1]):
                continue
            summary += f"\t{key}: {vals[-1]:.3f}"
        duration = self.logs_dict["duration"][-1]
        summary += f"\t[{duration:.2f}s]"
        return summary

    def min(self, key):
        if key not in self.logs_dict or len(self.logs_dict[key]) == 0:
            return 10e8     # Find nicer way
        return min(self.logs_dict[key])

    def write(self, filepath):
        with open(filepath, "wb") as fd:
            pk.dump(self.logs_dict, fd)

    def get_best_metrics(self):
        """
        Returns a dictionary of metric values for the epoch that minimizes the
        minimizer metric (e.g. validation loss). Each entry is the metric's
        name and the value at the best epoch. Also considers test metrics,
        which are only computed once at the end.
        """
        metrics = {}
        min_epoch = np.nanargmin(self.logs_dict[self.minimizer])
        metrics["min_epoch"] = min_epoch
        for key, values in self.logs_dict.items():
            # If the metric is only evaluated at the very end, only the last
            # entry contains a valid metric value and it would be nan for
            # the min_epoch.
            if key in self.final_test_metrics: continue
            metrics[key] = values[min_epoch]
        for key in self.final_test_metrics:
            metrics[key] = self.logs_dict[key][-1]
        return metrics

    def write_summary(self, filepath, settings_description=""):
        """
        Writes a text file containing a summary of the run.
        :param filepath: Filepath of the summary.
        """
        best_results = self.get_best_metrics()
        summary = settings_description + "\n\n"
        for key, value in best_results.items():
            summary += f"{key}: {value}\n"
        with open(filepath, "w") as fd:
            fd.write(summary)

    def write_epoch_metrics(self, filepath):
        """
        Writes the current, raw epoch metrics to file, for example to persist
        test predictions and labels.
        """
        with open(filepath, "wb") as fd:
            pk.dump(self._current_epoch_metrics, fd)


class OutputLogger:
    """
    Overrides normal stdout, i.e. `sys.stdout = OutputLogger(...)`. After that,
    print writes all output to stdout *and* the specified log-file.
    """
    def __init__(self, log_filepath):
        self.terminal = sys.stdout
        self.log = open(log_filepath, "a")

    def write(self, message):
        self.terminal.write(message)
        self.log.write(message)

    def flush(self):
        self.terminal.flush()
        self.log.flush()

    def close(self):
        self.log.flush()
        self.log.close()


def parameter_description_from_dict(dict):
    return dict.__str__()[1:-1].replace("\'", "").replace(": ", "=")


def checkpoint_filepath(directory, basename, script_file, parameters=None,
                        file_ending="", add_timestamp=True):
    """
    Automatically creates a checkpoint filepath with the given attributes.
    :param directory: Directory in which the file should be stored.
    :param basename: Base name of the file, which will be appended by some
    extra parameters (see below).
    :param script_file: Name of the script as returned by __file__.
    :param parameters: Dictionary of additional parameters.
    :param file_ending: File ending of the file. If None, the path points to
    a folder.
    :return: Filepath as a string.
    """
    script_name = os.path.basename(script_file)
    script_name = script_name[:script_name.find(".")]

    parameters = {} if parameters is None else parameters
    param_descr = parameter_description_from_dict(parameters)
    param_descr = "_" + param_descr if len(param_descr) > 0 else ""

    file_ending = file_ending if file_ending is not None else ""
    if len(file_ending) > 0 and file_ending[0] != ".":
        file_ending = "." + file_ending

    timestamp = ("_" + datetime.now().strftime("%Y-%m-%d-%H-%M-%S-%f")
                 if add_timestamp else "")

    basename = "_" + basename if basename is not None else ""

    filename = (script_name + param_descr + timestamp + basename + file_ending)

    filepath = os.path.join(directory, filename)
    return filepath


def print_parameters(parameters):
    print("Hyperparams:")
    for param in parameters:
        print(f"\t- {param.name}: {param.numpy()}")


if __name__ == '__main__':
    cp_folder = checkpoint_filepath(TrainingSettings.cp_folder, None, __file__, None, None)
    print(cp_folder)
