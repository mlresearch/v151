import numpy as np
import numpy.linalg as LA

from .greedy import layer_greedy


def calc_reconst_mtx(cov, sub, tau, pinv=False):
    r"""Calculate the reconstruction matrix :math:`\hat{A}_J` which minimizes the information loss function.

    .. math::
        \hat{A}_J
        = \hat{\Sigma}_{F, J} (\hat{\Sigma}_{J, J} + I_\tau)^{-1}.

    Args:
        cov (2-dim tensor): Empirical covariance matrix :math:`\hat{\Sigma}`.
        sub ([int]): Index set :math:`J`.
        tau ([double]): Regularization parameter :math:`\tau`.
        pinv (Bool): Use pseudo inverse matrix in stead of inverse matrix if True.

    Returns:
        2-dim tensor: Reconstruction matrix :math:`\hat{A}_J`.
    """
    if pinv:
        return cov[:, sub] @ LA.pinv(cov[sub][:, sub] + np.diag([tau[i] for i in sub]))
    else:
        return cov[:, sub] @ LA.inv(cov[sub][:, sub] + np.diag([tau[i] for i in sub]))


def calc_obj_a(cov, sub, tau, pinv=False):
    r""" Calculate the input information loss function :math:`L_\tau^{(A)}(J)`.

    .. math::
        L_\tau^{(A)}(J)
        = \min_{A\in{\mathbb{R}}^{m_\ell \times |J|}}
        \hat{E}[\|\phi-A\phi_J\|^2] + \|A\|_\tau^2 \\
        = {\mathrm{Tr}}\left[\hat{\Sigma}_{F, F}
        - \hat{\Sigma}_{F, J}(\hat{\Sigma}_{J, J} + I_\tau)^{-1}\hat{\Sigma}_{J, F}\right].

    Args:
        cov (2-dim tensor): Empirical covariance matrix :math:`\hat{\Sigma}`.
        sub ([int]): Index set :math:`J`.
        tau ([double]): Regularization parameter :math:`\tau`.
        pinv (Bool): Use pseudo inverse matrix in stead of inverse matrix if True.

    Returns:
        double: Input information loss function :math:`L_\tau^{(A)}(J)`.
    """
    # Return `inf` if inverse matrix cannot be obtained
    try:
        reconst = calc_reconst_mtx(cov, sub, tau, pinv)
    except np.linalg.LinAlgError:
        return float("inf")
    mtx = cov - reconst @ cov[sub]
    return np.trace(mtx)


def projection4fc_(weight_compress, weight_org, keys, sub, quiet=False):
    r"""Restrict weight parameters to selected index. (For FC layer)"""
    for k in keys:
        if ("weight" in k) or ("bias" in k):
            weight_compress[k] = weight_org[k][sub]
            if not quiet:
                print("{}: {} -> {}".format(k, weight_org[k].shape, weight_compress[k].shape))


def reconstruction4fc_(weight_compress, keys, cov, sub, tau, pinv=False, quiet=False):
    r"""Multiply weight matrix by reconstruction matrix calculated for selected index. (For FC layer)"""
    for k in keys:
        if "weight" in k:
            shape_before = weight_compress[k].shape
            weight_compress[k] = weight_compress[k] @ calc_reconst_mtx(cov, sub, tau, pinv).astype(np.float32)
            if not quiet:
                print("{}: {} -> {}".format(k, shape_before, weight_compress[k].shape))


def projection4rnn_(weight_compress, weight_org, keys, sub, quiet=False):
    r"""Restrict weight parameters to selected index. (For RNN layer)"""
    for k in keys:
        if ("rnn.weight" in k) or ("rnn.bias" in k):
            weight_compress[k] = weight_org[k][sub]
            if not quiet:
                print("{}: {} -> {}".format(k, weight_org[k].shape, weight_compress[k].shape))
        else:
            weight_compress[k] = weight_org[k]
            if not quiet:
                print("{}: {} -> {}".format(k, weight_org[k].shape, weight_compress[k].shape))


def reconstruction4rnn_(weight_compress, keys, cov, sub, tau, pinv=False, quiet=False):
    r"""Multiply weight matrix by reconstruction matrix calculated for selected index. (For RNN layer)"""
    for k in keys:
        if ("rnn.weight_hh" in k) or ("out.weight" in k) or ("decoder.weight" in k):
            shape_before = weight_compress[k].shape
            weight_compress[k] = weight_compress[k] @ calc_reconst_mtx(cov, sub, tau, pinv).astype(np.float32)
            if not quiet:
                print("{}: {} -> {}".format(k, shape_before, weight_compress[k].shape))


def prune_rnn_by_cov(weight_org, cov, m_sharp, sub=None, sub_F=None, quiet=True, pinv=False):
    """Spectral Pruning procedure for RNN.

    Make pruned weight parameters and optimal index set of original weight parameters and empirical covariance matrix.
    """
    # Do not use regularization parameters
    tau = np.zeros_like(cov[0])
    sub_F = np.arange(len(cov[0])) if (sub_F is None) else sub_F
    # --Optimization phase--
    # Solve minimization problem of information loss function by use of greedy algorithm
    # Skip if index set is given
    sub_all = None
    if sub is None:
        obj = lambda sub_tmp: calc_obj_a(cov, sub_tmp, tau, pinv)
        sub, sub_all = layer_greedy(obj, m_sharp, sub_F, stop_greedy=False)
    # --Pruning phase--
    # Redefine weight parameters by restriction and reconstruction procedure
    keys = list(weight_org.keys())
    weight_compress = {}
    projection4rnn_(weight_compress, weight_org, keys, sub, quiet=quiet)
    reconstruction4rnn_(weight_compress, keys, cov, sub, tau, pinv=pinv, quiet=quiet)
    return weight_compress, sub_all


def prune_rnn_by_cov_wo_reconstruction(weight_org, cov, m_sharp, sub=None, sub_F=None, quiet=True, pinv=False):
    """Spectral Pruning procedure for RNN.

    Make pruned weight parameters and optimal index set of original weight parameters and empirical covariance matrix.
    """
    # Do not use regularization parameters
    tau = np.zeros_like(cov[0])
    sub_F = np.arange(len(cov[0])) if (sub_F is None) else sub_F
    # --Optimization phase--
    # Solve minimization problem of information loss function by use of greedy algorithm
    # Skip if index set is given
    sub_all = None
    if sub is None:
        obj = lambda sub_tmp: calc_obj_a(cov, sub_tmp, tau, pinv)
        sub, sub_all = layer_greedy(obj, m_sharp, sub_F, stop_greedy=False)
    # --Pruning phase--
    # Redefine weight parameters by only restriction procedure
    keys = list(weight_org.keys())
    weight_compress = {}
    projection4rnn_(weight_compress, weight_org, keys, sub, quiet=quiet)
    # Do not conduct reconstruction procedure
    # Just conduct restriction procedure
    for k in keys:
        if ("rnn.weight_hh" in k) or ("out.weight" in k) or ("decoder.weight" in k):
            weight_compress[k] = weight_compress[k][:, sub]
    return weight_compress, sub_all
