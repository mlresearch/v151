%% This code computes the values of L,U,m from the generative model at frequency f

function [L,U,m_i,n_bound,m] = Constants_at_f(IPSD_analytical,WF, epsilon_1,d)
Nnodes = size(WF,1);
%%%%%%%% Getting the constants and upper bounds on n
p = Nnodes -1;

L = min(eig(IPSD_analytical));
U = max(eig(IPSD_analytical));


for i = 1:Nnodes
   temp =abs(imag(WF(i,:)));
   temp(temp<1e-8)=0;
   temp = sort(temp);
   temp(temp==0)= [];
   m_i(i) = temp(1);
   n_bound(i) = max(2*(3456)^2*(U/L+0.5)*log(2*p)*d, 3*6144*6144*U^2/L*d*log(8*p/epsilon_1)/m_i(i)/m_i(i));
end
m = min(m_i);



end

