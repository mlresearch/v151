import argparse
import logging
import random

import mlflow
import numpy as np
from sklearn.cluster import KMeans
from sklearn.metrics import accuracy_score
from sklearn.model_selection import GridSearchCV
from skorch.callbacks import EarlyStopping
from skorch.callbacks import EpochScoring
from skorch.utils import _sigmoid_then_2d
import torch

from baseline import MetricLearningLoss
from data_loader import load_pubmed
from data_loader import load_twonorm
from model import LinearClassifier, MLP
from model import MyNeuralNetClassifier
from model import SimilarityClassifier


MLFLOW_TRACKING_URI = './mlruns'
logger = logging.getLogger(__name__)


class ClusteringAccuracyScoringScoring(EpochScoring):
    def __init__(self, test_data, *arg, **kwarg):
        super(ClusteringAccuracyScoringScoring, self).__init__(
            clustering_accuracy_scorer,
            lower_is_better=False,
            name='test_clus_acc',
            use_caching=False,
        )
        self.test_data = test_data

    def get_test_data(self, dataset_train, dataset_valid):
        x, y = self.test_data
        # TODO(fix): x, y should be writeable
        return x, y, []


def get_mlflow_experiment_id(experiment_name):
    experiment = mlflow.get_experiment_by_name(experiment_name)
    if experiment is None:
        return mlflow.create_experiment(experiment_name)
    else:
        return experiment.experiment_id


def make_dataset(args, similarity_label=True):
    if args.data == 'twonorm':
        data = load_twonorm()
    elif args.data == 'pubmed':
        data = load_pubmed()
        data.set_labels(positive_class=1, negative_class=3)
    else:
        raise ValueError(f'dataset `{args.data}` does not exist')

    data.set_test_ratio(0.2)

    data_tr, data_te = data.generate_train_test_split(
        similarity_label=similarity_label,
    )

    if args.verbose and similarity_label:
        y = data_te[1]
        positive_ratio = len(y[y == 0]) / len(y)
        cm = data.get_summary()
        tn, fp, fn, tp = cm.ravel()
        print(
            f" ======= data summary =======\n"
            f"   positive_ratio : {positive_ratio:.4f}\n"
            f"   observed #S    : {tp + fp}\n"
            f"   observed #D    : {tn + fn}\n"
            f"   rate(S -> S)   : {tp / (tp + fn):.4f}\n"
            f"   rate(S -> D)   : {fn / (tp + fn):.4f}\n"
            f"   rate(D -> S)   : {fp / (tn + fp):.4f}\n"
            f"   rate(D -> D)   : {tn / (tn + fp):.4f}\n"
            f" ============================\n"
        )
    elif args.verbose and not similarity_label:
        x, y = data_tr
        positive_ratio = len(y[y == 0]) / len(y)
        print(
            f" ======= data summary =======\n"
            f"   positive_ratio : {positive_ratio:.4f}\n"
            f"   observed #P    : {len(y[y == 1])}\n"
            f"   observed #N    : {len(y[y == 0])}\n"
            f" ============================\n"
        )

    return data_tr, data_te


def clustering_accuracy(y_true: np.array, y_pred: np.array) -> float:
    acc = accuracy_score(y_true, y_pred)
    return max(acc, 1 - acc)


def clustering_accuracy_scorer(model, x, y):
    if isinstance(model, GridSearchCV) or not model.module_.train_embedding:
        y_pred = model.predict(x)
    else:
        # method == 'dml'
        x = torch.from_numpy(x)
        emb = model.module_.module.embed(x)
        kmeans = KMeans(n_clusters=2)
        y_pred = kmeans.fit_predict(x)

    return clustering_accuracy(y, y_pred)


def check_if_validation(args) -> bool:
    flag = False
    flag |= len(args.lr) > 1
    flag |= len(args.reg) > 1
    return flag


def get_validation_params(args) -> dict:
    params = {}

    if check_if_validation(args):
        params['lr'] = args.lr
        params['optimizer__weight_decay'] = args.reg
    else:
        params['lr'] = args.lr[0]
        params['optimizer__weight_decay'] = args.reg[0]

    return params


def main(args):
    # load dataset
    if args.method == 'standard':
        data_tr, data_te = make_dataset(args, similarity_label=False)
        x, y = data_tr
        dim = x.shape[1]
    else:
        data_tr, data_te = make_dataset(args, similarity_label=True)
        *x, y = data_tr
        x = np.hstack(x)
        dim = x.shape[1] // 2

    # make classifier
    if args.method == 'standard':
        config = {
            "module__use_similarity_labels": False,
            "module__use_similarity_likelihood": False,
            "module__train_embedding": False,
        }
    elif args.method == 'cips':
        config = {
            "module__use_similarity_labels": True,
            "module__use_similarity_likelihood": False,
            "module__train_embedding": False,
        }
    elif args.method == 'mcl':
        config = {
            "module__use_similarity_labels": True,
            "module__use_similarity_likelihood": True,
            "module__train_embedding": False,
        }
    elif args.method == 'dml':
        config = {
            "module__use_similarity_labels": True,
            "module__use_similarity_likelihood": False,
            "module__train_embedding": True,
            "criterion": MetricLearningLoss,
            "predict_nonlinearity": _sigmoid_then_2d,
            "train_split": False,
            "callbacks__stopping_criterion": None,
        }
    else:
        raise ValueError(f'method `{args.method}` is unexpected')

    base_module = MLP
    epoch_scoring = ClusteringAccuracyScoringScoring(data_te)
    stopping_criterion = EarlyStopping(
        monitor='valid_loss',
        patience=10,
        lower_is_better=True,
        threshold=1e-4,
        threshold_mode='rel',
        sink=logger.info,
    )

    clf = MyNeuralNetClassifier(
        module=SimilarityClassifier,
        module__base_module=base_module,
        module__n_features=dim,
        module__n_units=args.hid,
        max_epochs=args.epoch,
        optimizer=torch.optim.Adam,
        iterator_train__batch_size=args.batch_size,
        iterator_train__shuffle=True,
        callbacks=[
            ('epoch_scoring', epoch_scoring),
            ('stopping_criterion', stopping_criterion),
        ],
        verbose=args.verbose,
    )

    clf.set_params(**config)

    # cross validation if needed
    if check_if_validation(args):
        if args.method == "dml":
            raise ValueError("grid search is not available for method='dml'")

        params = get_validation_params(args)
        clf = GridSearchCV(
            clf,
            params,
            refit=True,
            cv=args.n_cv,
            scoring='neg_log_loss',
            n_jobs=args.n_jobs,
        )
    else:
        params = get_validation_params(args)
        clf.set_params(**params)

    # fit
    clf.fit(x, y)

    # evaluate
    acc = clustering_accuracy_scorer(clf, *data_te)

    # logging
    mlflow.set_tracking_uri(MLFLOW_TRACKING_URI)
    experiment_id = get_mlflow_experiment_id(args.name)
    with mlflow.start_run(experiment_id=experiment_id):
        mlflow.log_param('batch_size', args.batch_size)
        mlflow.log_param('data', args.data)
        mlflow.log_param('epoch', args.epoch)
        mlflow.log_param('hidden', args.hid)
        mlflow.log_param('lr', args.lr)
        mlflow.log_param('method', args.method)
        mlflow.log_param('reg', args.reg)
        mlflow.log_param('seed', args.seed)
        mlflow.log_metric("clus_acc", acc)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()

    parser.add_argument('--batch_size', type=int, default=4096,
                        help='training batch size')
    parser.add_argument('--data', type=str, default='twonorm',
                        help='dataset')
    parser.add_argument('--epoch', type=int, default=100,
                        help='number of epochs')
    parser.add_argument('--hid', type=int, default=8,
                        help='number of hidden units')
    parser.add_argument('--lr', type=float, default=[0.001], nargs='*',
                        help='learning rate')
    parser.add_argument('--method', type=str, default='cips',
                        help='method name (standard|cips|mcl|dml)')
    parser.add_argument('--name', type=str, default='simcls',
                        help='mlflow experiment name')
    parser.add_argument('--n_cv', type=int, default=5,
                        help='number of cross validation split')
    parser.add_argument('--n_jobs', type=int, default=-1,
                        help='number of processes')
    parser.add_argument('--reg', type=float, default=[0.005], nargs='*',
                        help='regularizatiton parameter')
    parser.add_argument('--seed', type=int, default=-1,
                        help='random seed')
    parser.add_argument('--verbose', '-v', action='store_true')

    args = parser.parse_args()
    if args.seed >= 0:
        random.seed(args.seed)
        np.random.seed(args.seed)
        torch.manual_seed(args.seed)

    main(args)
