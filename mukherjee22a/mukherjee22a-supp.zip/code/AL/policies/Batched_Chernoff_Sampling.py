
import sys
sys.path.append("..")

from util.check_stop_time import check_stop_time
from util.chernoff_sampling import chernoff_sampling
from util.update_log_L import update_log_L
from util.sample_source import sample_source

from environment.Discrete_env import Discrete_env

import numpy as np

class Batched_Chernoff_Sampling(object):
    
    '''
    classdocs
    '''
    
    num_sources = 0
    num_hypo = 0
    mu = None
    
    def __init__(self, env, B):
        '''
        Constructor
        '''
        self.num_hypo = env.num_hypo
        self.num_sources = env.num_sources
        self.mu = env.mu
        self.sig = env.sig
        self.env = env
        self.trials = env.trials
        self.T = env.T
        self.jstar = env.jstar
        self.best_arm = env.best_arm
        
        self.B = B
        
        
        self.batched_chern_err = []
        self.batched_chern_num = []
        #pre calculate chernoff sampling proportions
        self.calculated_probability = np.zeros((self.num_sources, self.num_hypo))

        for idx in range(self.num_hypo):
            probability = chernoff_sampling(self.mu, self.sig, idx)
            self.calculated_probability[:,idx] = probability 


        self.batched_chern_sample_complexity = np.zeros((self.trials, self.num_sources))



        
        
    
    def run_Batched_Chernoff_Sampling(self):
        
        print("\n Batched Chernoff, Batch: " +str(self.B))
        for tr in range(self.trials): 
    
            self.chern_L = np.zeros(self.num_hypo)
            self.tr_chern_err = np.zeros(self.T)
    
            np.random.seed(tr)
    
            self.tr_chern_num = np.zeros(self.num_sources)
            
            for t in range(self.T):
                
                if check_stop_time(self.chern_L, self.num_hypo) == False:
                      
                    # do chernoff sampling
                    if t%self.B == 0:
                        hypo_idx = np.random.choice([h for h in range(self.num_hypo) if self.chern_L[h]==max(self.chern_L)])
                    #chern_top_hypo.append(hypo_idx)
                    #probability = chernoff_sampling(mu, sig, hypo_idx)
            
                    probability = self.calculated_probability[:,hypo_idx]
            
                    if probability is not False:
                        #print(probability)
                        idx = np.random.choice(self.num_sources, p = probability/sum(probability))
                    else:
                        idx = np.random.choice(self.num_sources)
                    self.tr_chern_num[idx] += 1  # recording number of pulls
                  
                    val = sample_source(idx, self.mu, self.sig, self.jstar)
                    
                    update_log_L(self.chern_L, self.mu, self.sig, idx, val)
                    
                    
                    #if t%self.B == 0:
                    chern_hypo_hat = np.random.choice([h for h in range(self.num_hypo) if self.chern_L[h]==max(self.chern_L)])
                    #tr_chern_err[t] += int(chern_hypo_hat != jstar)
                    chern_best_arm_hat = np.argmax(np.array(self.mu[:,chern_hypo_hat]))
                    self.tr_chern_err[t] += int(chern_best_arm_hat != self.best_arm)
            
                    self.batched_chern_sample_complexity[tr][idx] += 1
            
            self.batched_chern_err.append(self.tr_chern_err)
            
            self.batched_chern_num.append(self.tr_chern_num)
    
            
            print(tr, end=', ')
            if tr % 100 == 0:
                print()
            
            
if __name__ == "__main__":
    obj = Discrete_env()
    obj.discrete_env1()
    
    B = 20 #Batch size
    chern = Batched_Chernoff_Sampling(obj, B)
    chern.run_Batched_Chernoff_Sampling()
    
    #print(np.average(chern.chern_err, axis = 0))
    
