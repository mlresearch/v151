import matplotlib
import matplotlib.pyplot as plt
import numpy as np
from sklearn.model_selection import train_test_split
import time
import argparse

# set random seed
parser = argparse.ArgumentParser(description="set random seed")
parser.add_argument("-s", "--seed", help="integers")
args = parser.parse_args()
if args.seed:
    seed = args.seed
else:
    seed = 1

path = './result_covtype/'

##############################################################
def sigmoid(z):
    return 1/(1+np.exp(-z))

def fLR(w, x, y):
    h = sigmoid(x @ w)
    eps = 1e-4
    return (- y @ np.log(h + eps) - (1 - y) @ np.log(1 - h + eps)) / y.shape[0]

def dfLR(w, x, y):
    h = sigmoid(x @ w)
    return x.T @ (h - y) / y.shape[0]

def d2fLR(w, x, y):
    h = sigmoid(x @ w)
    return (x.T * (h * (1 - h))) @ x / y.shape[0]

def fInner(w, lam, x, y):
    return fLR(w, x, y) + w @ (lam * w)

def dfInner(w, lam, x, y):
    # d/dw
    return dfLR(w, x, y) + 2 * lam * w

def d2fInner(w, lam, x, y):
    # d2/dw2, d2/dwdlam
    return d2fLR(w, x, y) + 2 * np.diag(lam), 2 * np.diag(w)

def fOuter(w, x, y):
    return fLR(w, x, y)

def dfOuter(w, x, y):
    return dfLR(w, x, y)

def my_solve(H, v): 
    c = 0.9/L_g
    w = np.copy(v)
    for _ in range(5):
        v = v - c * H @ v
        w += v    
    return c*w
################################################################
from sklearn.datasets import load_svmlight_file
x, y = load_svmlight_file("covtype.libsvm.binary.scale.bz2")
x = x.toarray()
y = y - 1

#seed = 2021
val_perc = 0.2
np.random.seed(seed)

x_train, x_val, y_train, y_val = train_test_split(x, y, test_size=val_perc)
d = x_train.shape[1]
################################################################
# hyper parameters
epochmax = 10
bs = 50
itermax = x_train.shape[0] // bs
lr_in = 0.1
lr_out = 0.1
tau = 0.1

# initial parameters
#seed = 1234
w0 = np.random.randn(d)
lam0 = np.ones(d) # np.zeros(d) #
H1 = np.identity(d)
H2 = np.zeros((d, d))
L_g = 0.5 * np.linalg.eigvals((x_train.T @ x_train)).max() / x_train.shape[0] + 2# * lam0.max()

# STABLE
record_loss_stable = []
record_s_stable = []
record_t_stable = []
w = w0
lam = lam0
tau = 0.1
H1 = np.identity(d) 
H2 = np.zeros((d, d))

num_s = 0
np.random.seed(seed)
t_start = time.time()
lr_in = 0.1
lr_out = 0.1
for epoch in range(epochmax):
    for i in range(itermax):  
        s = np.random.choice(x_val.shape[0], size=bs)
        num_s += bs
        # outer loop
        lam_p = lam
        lam = lam + lr_out * H2 @ my_solve(H1, dfOuter(w, x_val[s,:], y_val[s]))
        lam -= 1e-4
        lam = lam * (lam > 0.).astype(float)
        lam += 1e-4
        
        # inner loop
        w_p = w
        w = w - lr_in * dfInner(w, lam_p, x_train[s,:], y_train[s]) - my_solve(H1, (H2.T @ (lam - lam_p)))
    
        # update H1, H2
        s = np.random.choice(x_train.shape[0], size=bs)
        num_s += bs
        
        H1, _ = d2fInner(w, lam, x_train[s,:], y_train[s])
        s = np.random.choice(x_train.shape[0], size=bs)
        num_s += bs
        _, H2 = d2fInner(w, lam, x_train[s,:], y_train[s])
        
        record_loss_stable.append(fOuter(w, x_val, y_val))
        record_s_stable.append(num_s)
        record_t_stable.append(time.time()-t_start)

np.savetxt(path+'record_loss_stable_'+str(seed)+'.txt', np.stack(record_loss_stable))
np.savetxt(path+'record_s_stable_'+str(seed)+'.txt', np.stack(record_s_stable))
np.savetxt(path+'record_t_stable_'+str(seed)+'.txt', np.stack(record_t_stable))

# TTSA
record_loss_ttsa = []
record_s_ttsa = []
record_t_ttsa = []
w = w0
lam = lam0
num_s = 0
np.random.seed(seed)
t_start = time.time()
for epoch in range(epochmax):
    for i in range(itermax): 
        # inner loop
        w_p = w
        s = np.random.choice(x_train.shape[0], size=bs)
        num_s += bs
        w = w - (lr_in * (epoch + 1)**(0)) * dfInner(w, lam, x_train[s,:], y_train[s])#-2/5
   
        s = np.random.choice(x_val.shape[0], size=bs)
        num_s += bs
        # outer loop
        lam_p = lam
        t = int(np.log(epoch * itermax + i + 1)) + 1
        p = np.random.randint(t)
        num_s += p * bs
        hg = dfOuter(w, x_val[s,:], y_val[s])
        for j in range(p):
            s = np.random.choice(x_train.shape[0], size=bs)
            h1, _ = d2fInner(w, lam, x_train[s,:], y_train[s])
            hg = hg - 1/L_g * (h1 @ hg)
        hg = hg * (t/L_g)
        s = np.random.choice(x_train.shape[0], size=bs)
        num_s += bs
        _, h2 = d2fInner(w, lam, x_train[s,:], y_train[s])
        
        lam = lam + (lr_out * (epoch + 1)**(0)) * h2 @ hg #-3/5
        
        lam -= 1e-4
        lam = lam * (lam > 0.).astype(float)
        lam += 1e-4
         
        record_s_ttsa.append(num_s)    
        record_loss_ttsa.append(fOuter(w, x_val, y_val))
        record_t_ttsa.append(time.time()-t_start)
        
np.savetxt(path+'record_loss_ttsa_'+str(seed)+'.txt', np.stack(record_loss_ttsa))
np.savetxt(path+'record_s_ttsa_'+str(seed)+'.txt', np.stack(record_s_ttsa))
np.savetxt(path+'record_t_ttsa_'+str(seed)+'.txt', np.stack(record_t_ttsa))
        
# BSA
record_loss_bsa = []
record_s_bsa = []
record_t_bsa = []
w = w0
lam = lam0
num_s = 0

np.random.seed(seed)
t_start = time.time()
for epoch in range(epochmax):
    for i in range(itermax): 
        # inner loop
        for t in range(np.int(np.sqrt(epoch * itermax + i + 1))):
            w_p = w
            s = np.random.choice(x_train.shape[0], size=bs)
            num_s += bs
            w = w - (lr_in * (epoch + 1)**(0)) * dfInner(w, lam, x_train[s,:], y_train[s])#-2/5
        
        s = np.random.choice(x_val.shape[0], size=bs)
        num_s += bs
        # outer loop
        lam_p = lam
        t = np.int((np.log(epoch * itermax + i + 1))) + 1
        p = np.random.randint(t)
        num_s += p * bs
        hg = dfOuter(w, x_val[s,:], y_val[s])
        for j in range(p):
            s = np.random.choice(x_train.shape[0], size=bs)
            h1, _ = d2fInner(w, lam, x_train[s,:], y_train[s])
            hg = hg - 1/L_g * (h1 @ hg)
        hg = hg * (t/L_g)
        s = np.random.choice(x_train.shape[0], size=bs)
        num_s += bs
        _, h2 = d2fInner(w, lam, x_train[s,:], y_train[s])
        
        lam = lam + (lr_out * (epoch + 1)**(0)) * h2 @ hg #-3/5
        
        lam -= 1e-4
        lam = lam * (lam > 0.).astype(float)
        lam += 1e-4
        
        record_s_bsa.append(num_s)    
        record_loss_bsa.append(fOuter(w, x_val, y_val))
        record_t_bsa.append(time.time()-t_start)

np.savetxt(path+'record_loss_bsa_'+str(seed)+'.txt', np.stack(record_loss_bsa))
np.savetxt(path+'record_s_bsa_'+str(seed)+'.txt', np.stack(record_s_bsa))
np.savetxt(path+'record_t_bsa_'+str(seed)+'.txt', np.stack(record_t_bsa))

# stocbio
lr_in = 0.5
lr_out = 0.5
record_loss_stocbio = []
record_s_stocbio = []
record_t_stocbio = []
w = w0
lam = lam0
np.random.seed(seed)
T = 5
bs = 500
itermax = x_train.shape[0] // bs
num_s = 0
t_start = time.time()
for epoch in range(epochmax*5):
    for i in range(itermax):
        # inner loop
        for t in range(T):
            s = np.random.choice(x_train.shape[0], size=bs)
            num_s += bs
            w = w - lr_in * dfInner(w, lam, x_train[s,:], y_train[s])
        # outer loop
        lam_p = lam
        Q = int(np.log(epoch*itermax + i + 1)) + 1
        num_s += Q * bs
        s = np.random.choice(x_val.shape[0], size=bs)
        hg = dfOuter(w, x_val[s,:], y_val[s])
        vQ = np.copy(hg)
        eta = 0.5/L_g
        for j in range(Q):
            s = np.random.choice(x_train.shape[0], size=bs)
            h1, _ = d2fInner(w, lam, x_train[s,:], y_train[s])
            hg = hg - eta * (h1 @ hg)
            vQ += hg
        hg = vQ * eta
        s = np.random.choice(x_train.shape[0], size=bs)
        num_s += bs
        _, h2 = d2fInner(w, lam, x_train[s,:], y_train[s])
        
        lam = lam + (lr_out * (epoch + 1)**(0)) * h2 @ hg
        
        lam -= 1e-4
        lam = lam * (lam > 0.).astype(float)
        lam += 1e-4
    
        record_s_stocbio.append(num_s)    
        record_loss_stocbio.append(fOuter(w, x_val, y_val))
        record_t_stocbio.append(time.time()-t_start)
        
np.savetxt(path+'record_loss_stocbio_'+str(seed)+'.txt', np.stack(record_loss_stocbio))
np.savetxt(path+'record_s_stocbio_'+str(seed)+'.txt', np.stack(record_s_stocbio))
np.savetxt(path+'record_t_stocbio_'+str(seed)+'.txt', np.stack(record_t_stocbio))