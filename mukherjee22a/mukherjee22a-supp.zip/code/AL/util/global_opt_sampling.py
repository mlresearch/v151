
from cvxpy import SolverError
import cvxpy as cp
import numpy as np

import sys
sys.path.append("..")

def global_opt_sampling(mu, sig, num_hypo):
    p = cp.Variable(mu.shape[0], nonneg=True)
    lower_bound = cp.Variable(1, nonneg=True)

    KL_matrices = []
    for hypo_idx in range(num_hypo):
        KL_hypo_idx = np.zeros(mu.shape)
        for j in range(mu.shape[1]):
            KL_hypo_idx[:,j] = np.square((mu[:, j] - mu[:, hypo_idx]) / sig)
        
        KL_hypo_idx = np.delete(KL_hypo_idx, hypo_idx, 1)
        KL_matrices.append(KL_hypo_idx)

    KL_matrix = np.concatenate(KL_matrices, axis=1)

    prob = cp.Problem(
        cp.Maximize(lower_bound),
        [p.T @ KL_matrix >= lower_bound,
         cp.sum(p) == 1]
    )
    
    try:
        obj_value = prob.solve(solver='CVXOPT', kktsolver=cp.ROBUST_KKTSOLVER)
        #obj_value = prob.solve()
    except SolverError:
        return False
    
    return p.value, obj_value