#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Open-Source Python package for Single- and Multi-Players multi-armed Bandits algorithms.

- Homepage: https://SMPyBandits.GitHub.io/
- License: MIT
- Date: October 2019
"""
from __future__ import division, print_function  # Python 2 compatibility



try:
    # from .Arms import *
    from SMPyBandits import Arms
except ImportError:
    pass

try:
    # from .Environment import *
    from SMPyBandits import Environment
except ImportError:
    pass

try:
    # from .Policies import *
    from SMPyBandits import Policies
except ImportError:
    pass

# try:
#     # from .Policies.Posterior import *
#     from SMPyBandits.Policies import Posterior
# except ImportError:
#     pass

