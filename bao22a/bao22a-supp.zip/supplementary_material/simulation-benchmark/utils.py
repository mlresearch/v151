import torch
from ignite.engine import _prepare_batch
from ignite.engine.engine import Engine
from ignite.utils import convert_tensor


def prepare_pair_batch(batch, device=None, non_blocking=False):
    """Prepare batch for training: pass to a device with options."""
    x1, x2, t = batch
    return (
        convert_tensor(x1, device=device, non_blocking=non_blocking),
        convert_tensor(x2, device=device, non_blocking=non_blocking),
        convert_tensor(t, device=device, non_blocking=non_blocking),
    )


def create_trainer(
    model,
    optimizer,
    loss_fn,
    device=None,
    non_blocking=False,
    type=None,
    prior=None,
):
    if type == "sd":
        assert prior and (prior != 1 / 2)

    if device:
        model.to(device)

    def sl_update(engine, batch):
        model.train()
        optimizer.zero_grad()
        x1, x2, t = prepare_pair_batch(batch, device=device)
        y = model(torch.cat((x1, x2), dim=0))
        y_a, y_b = y[: len(y) // 2], y[len(y) // 2 :]
        t_pred = y_a * y_b
        loss = loss_fn(t_pred, t)
        loss.backward()
        optimizer.step()
        return loss.item()

    def mcl_update(engine, batch):
        model.train()
        optimizer.zero_grad()
        x1, x2, t = prepare_pair_batch(batch, device=device)
        p = torch.sigmoid(model(torch.cat((x1, x2), dim=0)))
        p_a, p_b = p[: len(p) // 2], p[len(p) // 2 :]
        g = p_a * p_b + (1 - p_a) * (1 - p_b)
        loss = torch.mean(
            -((t + 1) // 2) * torch.log(g) - ((1 - t) // 2) * torch.log(1 - g)
        )
        loss.backward()
        optimizer.step()
        return loss.item()

    def sd_update(engine, batch):
        def _l(z, t):
            return (prior * loss_fn(z, t) - (1 - prior) * loss_fn(z, -t)) / (
                2 * prior - 1
            )

        model.train()
        optimizer.zero_grad()
        x1, x2, t = prepare_pair_batch(batch, device=device)
        y = model(torch.cat((x1, x2), dim=0))
        t_double = torch.cat((t, t))
        loss = _l(y, t_double)
        loss.backward()
        optimizer.step()
        return loss.item()

    if type == "sl":
        _update = sl_update
    elif type == "sd":
        _update = sd_update
    elif type == "mcl":
        _update = mcl_update
    else:
        raise NotImplementedError

    return Engine(_update)


def create_train_evaluator(
    model,
    metrics=None,
    device=None,
    output_transform=lambda x, y, y_pred: (
        y_pred,
        y,
    ),
):
    metrics = metrics or {}

    if device:
        model.to(device)

    def _inference(engine, batch):
        model.eval()
        with torch.no_grad():
            x1, x2, t = prepare_pair_batch(batch, device=device)
            y = model(torch.cat((x1, x2), dim=0))
            y_a, y_b = y[: len(y) // 2], y[len(y) // 2 :]
            t_pred = y_a * y_b
            return output_transform(None, t, t_pred)

    engine = Engine(_inference)

    for name, metric in metrics.items():
        metric.attach(engine, name)

    return engine


def create_val_evaluator(
    model,
    metrics=None,
    device=None,
    non_blocking=False,
    prepare_batch=_prepare_batch,
    output_transform=lambda x, y, y_pred: (
        y_pred,
        y,
    ),
):
    metrics = metrics or {}

    if device:
        model.to(device)

    def _inference(engine, batch):
        model.eval()
        with torch.no_grad():
            x, y = prepare_batch(
                batch, device=device, non_blocking=non_blocking
            )
            y_pred = model(x)
            return output_transform(x, y, y_pred)

    engine = Engine(_inference)

    for name, metric in metrics.items():
        metric.attach(engine, name)

    return engine
