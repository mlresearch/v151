

import pickle



def file_IO(file_name):
    file = open(file_name, 'rb')
    
    # dump information to that file
    data = pickle.load(file)
    
    # close the file
    file.close()
    


    top2_err = data[0][0]
    rand_err = data[0][1]
    chern_err = data[0][2]
    bchern_err = data[0][3]
    bchern1_err = data[0][4]
    bchern2_err = data[0][5]
    njav_err = data[0][6]
    chern_e_err = data[0][7]
    

    top2_sample_complexity = data[1][0]
    rand_sample_complexity = data[1][1]
    chern_sample_complexity = data[1][2]
    bchern_sample_complexity = data[1][3]
    bchern1_sample_complexity = data[1][4]
    bchern2_sample_complexity = data[1][5]
    njav_sample_complexity = data[1][6]
    chern_e_sample_complexity = data[1][7]
    
    
    return top2_err, rand_err, chern_err, bchern_err, bchern1_err, bchern2_err, njav_err, chern_e_err, top2_sample_complexity, rand_sample_complexity, chern_sample_complexity, bchern_sample_complexity, bchern1_sample_complexity, bchern2_sample_complexity, njav_sample_complexity, chern_e_sample_complexity



def file_IO_1(file_name):
    file = open(file_name, 'rb')
    
    # dump information to that file
    data = pickle.load(file)
    
    # close the file
    file.close()
    


    top2_err = data[0][0]
    rand_err = data[0][1]
    chern_err = data[0][2]
    njav_err = data[0][3]
    chern_e_err = data[0][4]
    

    top2_sample_complexity = data[1][0]
    rand_sample_complexity = data[1][1]
    chern_sample_complexity = data[1][2]
    njav_sample_complexity = data[1][3]
    chern_e_sample_complexity = data[1][4]
    
    
    return top2_err, rand_err, chern_err, njav_err, chern_e_err, top2_sample_complexity, rand_sample_complexity, chern_sample_complexity, njav_sample_complexity, chern_e_sample_complexity




def file_IO0(file_name):
    file = open(file_name, 'rb')
    
    # dump information to that file
    data = pickle.load(file)
    
    # close the file
    file.close()
    


    top2_err = data[0][0]
    rand_err = data[0][1]
    chern_err = data[0][2]
    #njav_err = data[0][3]

    top2_sample_complexity = data[1][0]
    rand_sample_complexity = data[1][1]
    chern_sample_complexity = data[1][2]
    #njav_sample_complexity = data[1][3]
    
    return top2_err, rand_err, chern_err, top2_sample_complexity, rand_sample_complexity, chern_sample_complexity

def file_IO1(file_name):
    file = open(file_name, 'rb')
    
    # dump information to that file
    data = pickle.load(file)
    
    # close the file
    file.close()
    


    mm_armerr = data[0][0]
    u_armerr = data[0][1]
    LinGapE_error = data[0][2]
    xy_oracle_err = data[0][3]
    

    mm_T = data[1][0]
    u_T = data[1][1]
    LinGapE_sample_complexity = data[1][2]
    xy_oracle_sample_complexity = data[1][3]
    
    
    return mm_armerr, u_armerr, LinGapE_error, xy_oracle_err, mm_T, u_T, LinGapE_sample_complexity, xy_oracle_sample_complexity




def file_IO2(file_name):
    
    file = open(file_name, 'rb')
    
    # dump information to that file
    data = pickle.load(file)
    
    # close the file
    file.close()
    


    mm_armerr = data[0][0]
    u_armerr = data[0][1]
    LinGapE_error = data[0][2]
    xy_static_err = data[0][3]
    xy_adaptive_err = data[0][4]

    mm_T = data[1][0]
    u_T = data[1][1]
    LinGapE_sample_complexity = data[1][2]
    xy_static_sample_complexity = data[1][3]
    xy_adaptive_sample_complexity = data[1][4]
    
    return mm_armerr, u_armerr, LinGapE_error, xy_static_err, xy_adaptive_err, mm_T, u_T, LinGapE_sample_complexity, xy_static_sample_complexity, xy_adaptive_sample_complexity




