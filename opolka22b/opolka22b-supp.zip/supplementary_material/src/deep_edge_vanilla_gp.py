import pathlib
import random
import sys
from collections import OrderedDict

import numpy as np
import gpflow
import tensorflow as tf
from gpflow.inducing_variables import InducingPoints
from gpflow.kernels import RBF
from gpflow.likelihoods import Bernoulli
from gpflow.mean_functions import Constant
from scipy.cluster.vq import kmeans2

from data_loading.link_prediction_dataset import LinkPredictionDataset
from deep_edge_gcgp import setup_training_env
from deep_graph_gp.deep_gp import DeepGP
from deep_graph_gp.layers import SVGPLayer
from training_environment import TrainingSettings as ts
from utils import save_tf_module_weights, load_tf_module_weights, \
    compute_kl_scale


def make_dgp(num_layers, feature_mat, num_train_points, inducing_points):
    num_inducing = inducing_points.shape[0]
    input_dim = feature_mat.shape[-1]
    layer_sizes = [ts.hidden_dim for _ in range(num_layers-1)] + [1]

    layers = []
    kernels = []
    layer_input_dim = input_dim
    for layer_size in layer_sizes[:-1]:
        base_kernel = RBF(
            lengthscales=ts.initial_lengthscale * np.ones(layer_input_dim))
        layer = SVGPLayer(base_kernel, num_inducing, layer_size, InducingPoints,
                        white=False)
        kernels.append(base_kernel)
        layers.append(layer)
        layer_input_dim = layer_size
    # last layer
    base_kernel = RBF(
        lengthscales=ts.initial_lengthscale * np.ones(layer_input_dim))
    layers.append(SVGPLayer(base_kernel, num_inducing, layer_sizes[-1],
                            InducingPoints))
    kernels.append(base_kernel)

    model = DeepGP(layers, likelihood=Bernoulli(), X=feature_mat,
                   Z=inducing_points, num_train_samples=num_train_points,
                   num_samples=ts.train_num_samples, mean_function=Constant())

    # init hidden layers to be near deterministic
    for layer in model.layers[:-1]:
        layer.q_sqrt.assign(layer.q_sqrt * 1e-5)
    return model, kernels


def training_step(train_loader, gprocess, optimizer, ds, logger):
    for edge_idcs, labels, conv_mat, subgraph_nodes, node_feats in train_loader:
        node1_feats = tf.gather(node_feats, tf.cast(edge_idcs[:, 0], tf.int32))
        node2_feats = tf.gather(node_feats, tf.cast(edge_idcs[:, 1], tf.int32))
        batch_node_feats = tf.concat((node1_feats, node2_feats), axis=-1)
        # Compute KL-scale
        kl_scale = compute_kl_scale(logger, ts.cold_posterior_period)
        # Gradient update
        with tf.GradientTape(watch_accessed_variables=False) as tape:
            tape.watch(gprocess.trainable_variables)
            objective, l, kl = gprocess.elbo((batch_node_feats, labels), kl_scale)
            objective = -objective
            gradients = tape.gradient(objective, gprocess.trainable_variables)
        # Clip the gradients using the average max gradient of the first 20 epochs
        if logger.current_epoch > 20:
            max_grad_norm = np.mean(logger.logs_dict["max_orig_grad_norm"][:20])
            gradients, orig_grad_norm = tf.clip_by_global_norm(gradients,
                                                               max_grad_norm)
        else:
            orig_grad_norm = tf.linalg.global_norm(gradients)
        optimizer.apply_gradients(zip(gradients, gprocess.trainable_variables))
        logger.add_values({"nELBOc": objective.numpy(),
                           "nELBO": -l.numpy() + kl.numpy(),
                           "train_likelihood": l.numpy(),
                           "kl": kl.numpy(),
                           "grad_norm": tf.linalg.global_norm(gradients).numpy(),
                           "orig_grad_norm": orig_grad_norm})


def evaluate(data_loader, gprocess, logger, num_samples, ds, prefix):
    for edge_idcs, labels, conv_mat, subgraph_nodes, node_feats in data_loader:
        node1_feats = tf.gather(node_feats, tf.cast(edge_idcs[:, 0], tf.int32))
        node2_feats = tf.gather(node_feats, tf.cast(edge_idcs[:, 1], tf.int32))
        batch_node_feats = tf.concat((node1_feats, node2_feats), axis=-1)
        # get prediction and likelihood
        pred_y, pred_y_var = gprocess.predict_y(batch_node_feats, num_samples)
        likelihood = gprocess.predict_log_density((batch_node_feats, labels), num_samples)
        logger.add_values({
            f"{prefix}_labels": labels,
            f"{prefix}_predictions": pred_y.numpy(),
            f"{prefix}_variances": pred_y_var.numpy(),
            f"{prefix}_likelihood": likelihood.numpy(),
        })


def run_training():
    (log_filepath, logger, weights_filepath, output_logger,
     summary_filepath, results_filepath) = setup_training_env()

    # Set up training environment
    # Set random seed
    random.seed(ts.seed)
    np.random.seed(ts.seed)
    tf.random.set_seed(ts.seed)
    # Set float type
    gpflow.config.set_default_float(ts.float_type)
    gpflow.config.set_default_jitter(ts.jitter)

    # Load data set
    ds = LinkPredictionDataset(ts.dataset_path, ts.dataset_name,
                               ts.dataset_folder, split_seed=ts.seed,
                               train_batch_size=ts.batch_size,
                               test_batch_size=ts.test_batch_size,
                               subsample_sizes=ts.num_node_samples,
                               float_type=ts.float_type, extract_subgraphs=True,
                               node2vec_embeddings=ts.node2vec_embeddings,
                               test_fraction=ts.test_fraction,
                               train_set_frac=ts.train_set_frac,
                               missing_frac=ts.missing_frac,
                               pert_frac=ts.perturb_frac)
    train_loader, test_loader = ds.train_loader, ds.test_loader

    # Init inducing points
    num_inducing_nodes = (ds.num_nodes // 8 if ts.num_inducing_nodes is None
                          else ts.num_inducing_nodes)
    # We initialise the inducing points by concatenating node features of
    # training nodes and computing their kmeans.
    edge_features = np.concatenate((
        ds.node_features[ds.pos_train_edges[:, 0]],
        ds.node_features[ds.pos_train_edges[:, 1]]
    ), axis=-1)
    inducing_points = kmeans2(edge_features, num_inducing_nodes,
                              minit='points')[0]    # use as many inducing points as training samples

    # Init GP model
    gprocess, kernels = make_dgp(ts.num_layers, edge_features,
                                 ds.num_train_samples, inducing_points)

    # Init optimizer
    optimizer = tf.optimizers.Adam(learning_rate=ts.lr)

    for epoch in range(ts.num_epochs):
        training_step(train_loader, gprocess, optimizer, ds, logger)
        logger.complete_epoch(lambda: save_tf_module_weights(gprocess,
                                                             weights_filepath))
        print(logger.epoch_summary())
        if ("stop_cold" in logger.misc_info and logger.has_converged(
                last_improvement=ts.convergence_stop_epoch,
                offset=logger.misc_info["stop_cold"])):
            break

    # Evaluate on test set with the best model
    load_tf_module_weights(gprocess, weights_filepath)
    evaluate(test_loader, gprocess, logger, ts.test_num_samples,
             ds, prefix="test")
    logger.write_epoch_metrics(results_filepath)
    logger.complete_epoch()
    print(logger.epoch_summary())

    # Cleanup after training
    output_logger.close()
    sys.stdout = sys.__stdout__
    logger.write(log_filepath)
    logger.write_summary(summary_filepath, ts.settings_description())
    return logger


if __name__ == '__main__':
    run_training()