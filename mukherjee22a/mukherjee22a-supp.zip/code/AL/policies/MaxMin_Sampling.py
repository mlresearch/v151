

import sys
sys.path.append("..")

import numpy as np
import cvxpy as cp

from environment.LinBandit_env import LinBandit_env

class MaxMin_Sampling(object):
    
    def __init__(self, env):
        '''
        Constructor
        '''
        self.T = env.T
        self.num_trials = env.num_trials
        self.num_dims = env.num_dims
        self.num_arms = env.num_arms
        self.rec = 1 # record err every rec samples
        self.mm_sample_complexity = []
        self.sigma = env.sigma
        self.theta_star = env.theta_star
        self.best_arm = env.best_arm
        self.X = env.X
        self.delta = env.delta
        
        self.env = env
        
        self.mm_esterr = np.zeros((self.num_trials, self.T//self.rec))
        self.mm_armerr = np.zeros((self.num_trials, self.T//self.rec))
        self.mm_T = self.T * np.ones(self.num_trials)
        
        self.p_mm, self.v = self.max_kmin_eig(self.X, verbose=True)
        
    
    def init_MaxMin_Sampling(self, env):   
        
        self.theta_star = env.theta_star
        self.best_arm = env.best_arm
        self.X = env.X
        self.p_mm, self.v = self.max_kmin_eig(self.X, verbose=True)
        
        #print(delta)
        
    def max_kmin_eig(self, rows_of_arms, k=1, verbose=False):
        
        p = cp.Variable(rows_of_arms.shape[0], nonneg=True)
        
        prob = cp.Problem(
            cp.Maximize(cp.lambda_sum_smallest(rows_of_arms.T @ cp.diag(p) @ rows_of_arms, k)),
            [cp.sum(p) ==1]
        )
        
        try:
            obj_value = prob.solve(solver='CVXOPT', kktsolver=cp.ROBUST_KKTSOLVER, verbose=verbose)
        except Exception as inst:
            print(inst)
            return False
        
        return p.value, prob.value
    
    
    def stop_or_not(self, design_mat, sum_scaled_arms, rows_of_arms, theta_hat, thresh):
        arms, dims = rows_of_arms.shape
        bestarm = np.argmax(rows_of_arms @ theta_hat)
        onehot_competing = cp.Parameter(arms)
        phi = cp.Variable(dims)
        #print(phi, arms, dims, design_mat, sum_scaled_arms, rows_of_arms, theta_hat, thresh)
        sq_err_obj = cp.quad_form(phi, design_mat) - 2 * sum_scaled_arms @ phi
        phi_has_diff_bestarm = [(onehot_competing@self.X - self.X[bestarm]) @ phi >= 0]
        closest_phi = cp.Problem(
            cp.Minimize(sq_err_obj), constraints=phi_has_diff_bestarm
        )
    
        obj_vals = np.zeros(arms)
        for idx in range(arms):
            onehot_competing.value = np.zeros(arms)
            onehot_competing.value[idx] = 1
            obj_vals[idx] = closest_phi.solve()
    
        # sq_loss_closest_phis = sum_sq_R + obj_vals
        min_loss_1, min_loss_2 = np.sort(obj_vals)[:2]
    
        if min_loss_2 - min_loss_1 > thresh:
            return True, obj_vals
        else:
            return False, obj_vals
        


    
    def run_MaxMin_Sampling(self):

        for tr in range(self.num_trials):
            print(tr, end=' ')
            
            
            '''
            env = self.env.LinBandit_env1(tr, self.num_dims, self.num_arms)
            self.init_MaxMin_Sampling(env)
            '''
            maxmin_A = np.eye(self.num_dims)
            maxmin_b = np.zeros(self.num_dims)
            #print(p_mm,v, num_arms, num_samples)
            np.random.seed(tr)
            maxmin_samples = np.random.choice(self.num_arms, size=self.T, p=self.p_mm/np.sum(self.p_mm))
            maxmin_R = self.X[maxmin_samples] @ self.theta_star + self.sigma * np.random.randn(len(maxmin_samples))
           
            maxmin_rewards = np.zeros((2, self.num_arms))
            maxmin_err = np.zeros((2, self.T//self.rec))
            for s in range(len(maxmin_samples)):
                maxmin_rewards[0, maxmin_samples[s]] += maxmin_R[s]
                maxmin_rewards[1, maxmin_samples[s]] += 1
                maxmin_A += np.outer(self.X[maxmin_samples[s]], self.X[maxmin_samples[s]])
                maxmin_b += maxmin_R[s] * self.X[maxmin_samples[s]]
        
                if s % self.rec == 0 and s > 0:
                    # theta_hat = least_sq_theta(maxmin_rewards, X)[0]
                    theta_hat = np.linalg.solve(maxmin_A, maxmin_b)
                    maxmin_err[0, s//self.rec] = np.linalg.norm(theta_hat - self.theta_star, ord=1)
                    maxmin_err[1, s//self.rec] = not (self.best_arm == np.argmax(self.X @ theta_hat))
                    
                    if s%20 == 0:
                        #if self.stop_or_not(maxmin_A, maxmin_b,self. X, theta_hat, np.log(4 * s**2/self.delta) + self.num_dims * np.log(3*self.num_dims))[0]:
                        if self.stop_or_not(maxmin_A, maxmin_b,self. X, theta_hat, np.log(4 * s**2/self.delta) + self.num_dims * np.log(12.0/self.env.min_seperation))[0]:
                        #if self.stop_or_not(maxmin_A, maxmin_b,self. X, theta_hat, np.log(4 * s**2/self.delta) + self.num_dims * np.log((12.0*self.num_dims)/self.env.min_seperation))[0]:
                        
                        #print(s)
                            self.mm_T[tr] = s
                            break
                if s%1000 == 0:
                    print(s)
                    
            self.mm_esterr[tr] = maxmin_err[0]
            self.mm_armerr[tr] = maxmin_err[1]
            self.mm_sample_complexity.append(maxmin_samples)



if __name__ == "__main__":
    
    env = LinBandit_env()
    env.LinBandit_env2(6,2,5)
    
    maxmin = MaxMin_Sampling(env)
    print(maxmin.p_mm)
    #maxmin.run_MaxMin_Sampling()


