library(genlasso)
library(doParallel)
library(foreach)
library(ITALE)

#form truth

form.truth <- function(jump.mean, jump.location, n){
  
  
  tmp = seq(0,1,length.out=n)
  jump.location2 = sapply(jump.location,function(x){max(min(which(tmp>=x)),1)-1})
  jump.location2[1] = 1
  jump.location2 = sort(jump.location2)
  jump.location3 = c(jump.location2,n)
  jump.location3[1] = 0
  
  rep(jump.mean, times=diff(jump.location3))
}

#enumerate jumps

enumerate.jumps <- function(fit, tol = 1e-4){
  dif = abs(diff(fit))
  idx = which(dif > tol)
  
  idx
}

# Returns a sequence of integers from a to b if a <= b, otherwise nothing.
Seq <- function(a, b, ...) {
  if (a<=b) return(seq(a,b,...))
  else return(numeric(0))
}

#cross validation for fused lasso
cv.fusedlasso <- function(object, D, k=5) {
  
  y = object$y
  X = object$X
  n = length(y)
  
  if(k<2 || round(k)!=k || k>n-2) {
    stop("The number of folds must an integer between 2 and n-2.")
  }
  
  foldid = c(0,rep(Seq(1,k),n-2)[Seq(1,n-2)],0)
  
  lambda = object$lambda
  cvall = matrix(0,k,length(lambda))
  
  for (i in Seq(1,k)) {
    cat(sprintf("Fold %i ... ",i))
    
    otr = which(foldid!=i)
    ntr = length(otr)
    ytr = y[otr]
    Xtr = X[otr, ]  
    
    out = fusedlasso(ytr, Xtr, D, maxsteps = 200, minlam  = 0.001)
    b = coef.genlasso(out, lambda = lambda)$beta  
    
    
    ote = which(foldid==i)
    yte = matrix(y[ote],length(ote),length(lambda))
    Xte = X[ote, ]
    pred = Xte %*% b
    
    cvall[i, ] = colMeans((yte-pred)^2) 
  }
  
  cverr = colMeans(cvall)
  i0 = which.min(cverr)
  lam.min = lambda[i0]
  out.list = list(lambda.min = lam.min, i.min = i0)
  return(out.list)
}

BIC.fusedlasso<- function(object) {
  
  y = object$y
  X = object$X
  n = length(y)
  lambda = object$lambda
  cvall = rep(NA, length(lambda))
  
  for (i in Seq(1,length(lambda))) {
    
    b = coef.genlasso(object, lambda = lambda[i])$beta  
    pred = X %*% b
    
    cvall[i] = n*log(mean((y-pred)^2)) + sum(b>0.000)*log(n)
  }
  i0 = which.min(cvall)
  lam.min = lambda[i0]
  out.list = list(lambda.min = lam.min, i.min = i0)
  return(out.list)
}

#compute Hausdorff distance on-sided or two sided
compute.hausdorff <- function(set1, set2, one.sided = FALSE){
  
  #handle corner cases
  if(length(set1) == 0 | length(set2) == 0) return(NA)
  if(length(set2) == 1) set2 = c(set2, set2)
  if(length(set1) == 1) set1 = c(set1, set1)
  
  dist.mat = sapply(set1, function(i){abs(i-set2)})
  dist.vecx = apply(dist.mat, 2, min)
  
  if(!one.sided) dist.vecy = apply(dist.mat, 1, min) else dist.vecy = 0
  
  max(dist.vecx, dist.vecy)
}

#apply filter
apply.filter <- function(fit, bandwidth, threshold = 0, y = NA, return.type = c("location", "filter")){
  n = length(fit)
  return.type = return.type[1]
  
  jump.loc = enumerate.jumps(fit)
  
  z =  .compute.filter(fit, bandwidth)
  
  if(return.type == "filter") return(z)
  
  jump.remain = .compute.candidatejumps(threshold, z, jump.loc, bandwidth, n)
  if(return.type == "location") return(jump.remain)
}

#computer filter
.compute.filter <- function(fit, bandwidth){
  n = length(fit)
  
  z = sapply(bandwidth:(n-bandwidth), function(x){
    abs(mean(fit[(x+1):(x+bandwidth)]) - mean(fit[(x-bandwidth+1):(x)]))
  })
  
  #pad the z's
  z = c(rep(0, bandwidth-1), z, rep(0, bandwidth))
  
  z
}

#compute candidate jumps
.compute.candidatejumps <- function(threshold, filter.values, jump.location, bandwidth, n){
  jump.loc2 = c(jump.location, jump.location-bandwidth, jump.location+bandwidth)
  jump.loc2 = jump.loc2[which(jump.loc2 >= bandwidth)]
  jump.loc2 = jump.loc2[which(jump.loc2 <= n - bandwidth)]
  jump.loc2 = c(bandwidth, jump.loc2, n-bandwidth)
  jump.loc2 = sort(unique(jump.loc2))
  
  filtered.idx = which(abs(filter.values) >= threshold)
  
  intersect(jump.loc2, filtered.idx)
}

#computer filter threshold 
staircase.threshold <- function(y, X, fit,  filter.bandwidth, lambda, trials = 5, quant = 0.95, tol = 1e-6){
  
  n = length(y)
  
  p = dim(X)[2]
  
  residual = y - X%*%fit
  
  sc.jumps = enumerate.jumps(fit, tol)
  
  sc.jumpNeigh = sapply(sc.jumps, function(x){
    max(1,(x-filter.bandwidth)) : min((x+filter.bandwidth), p)
  })
  
  sc.jumpNeigh = sort(unique(as.numeric(unlist(sc.jumpNeigh))))
  
  
  if(length(sc.jumpNeigh) >= p) return(rep(NA, length(quant)))
  
  custom.func <- function(trial){
    set.seed(10*trial)
    sd_1 = sd(residual)
    y2 = X %*% fit + residual[sample(n)]
    flasso2 = fusedlasso (y2, X, D, maxsteps = 150, minlam = 0.01)
    fit2 = coef(flasso2, lambda = lambda)$beta
    filter.val = apply.filter(fit2, bandwidth = filter.bandwidth, return.type = "filter")
    if (length(sc.jumpNeigh)==0){
      max(abs(filter.val))
    } else{
      max(abs(filter.val[-sc.jumpNeigh]))
    }
  }
  
  threshold.val = foreach(trial = 1:trials) %dopar% custom.func(trial)
  
  quantile(unlist(threshold.val), prob = quant,names = F)
}

#time filter
time.filter <- function(jump,bandwidth){
  if (length(jump)==1 | sum(diff(jump)<=bandwidth)==0){
    return(jump)
  }
  difference = diff(jump)
  i=1
  jump_new = c()
  while(i<=length(difference)){
    location = c(i)
    if (difference[i]<=bandwidth){
      while(difference[i+1]<=bandwidth && i<length(difference) ){
        location = c(location,i+1)
        i = i+1
      }
      jump_1 = floor(mean(jump[c(location,location[length(location)]+1)]))
    }
    
    else if(i==1){  
      while(difference[i+1]>bandwidth && i<length(difference) ){
        location = c(location,i+1)
        i = i+1
      }
      jump_1 =  jump[location]
    }
    
    else if(difference[i+1]<=bandwidth && i<length(difference))
      jump_1 = c()
    
    else{
      jump_1 =  jump[i+1]
    }
    jump_new =  c(jump_new, jump_1)
    i = i+1
    
  }
  return(jump_new)
}

#run tests
run.tests <- function(y, X, D, truth){
  
  p = dim(X)[2]
  
  start_1 = Sys.time()
  
  res = fusedlasso (y, X, D, maxsteps = 100, minlam = 0.001)
  
  cv = cv.fusedlasso(res, D)
  
  fit = coef(res, lambda = cv$lambda.min)$beta
  
  
  
  filter.bandwidth = floor(0.25*(log(p))^2)
  
  true.jumps = enumerate.jumps(truth)
  
  
  jumps.org = enumerate.jumps(fit)
  
  left.org = compute.hausdorff(true.jumps, jumps.org, one.sided = T)
  
  right.org = compute.hausdorff(jumps.org, true.jumps, one.sided = T)
  
  mse.fl = sum((truth-fit)^2)/n
  

  
  
 
  
  ITALE.result = ITALE.1D(y, X)
  
  fit.ITALE = ITALE.result$est[ITALE.result$CV.ind,] 
  
  jumps.ITALE = enumerate.jumps(fit.ITALE)
  
  left.ITALE = compute.hausdorff(true.jumps, jumps.ITALE, one.sided = T)
  
  right.ITALE = compute.hausdorff(jumps.ITALE, true.jumps, one.sided = T)
  
  mse.ITALE = sum((truth-fit.ITALE)^2)/n
  
  
  
  list(
       mse.fl = mse.fl,
       
      
       mse.ITALE = mse.ITALE
       
  )
}



library(mvtnorm)


n = 1000
p = 1000
sigma = 2
gamma = 1
jump.mean = c(0*gamma, 1*gamma, 0*gamma, 1.5*gamma, 0, 2*gamma, 0, 1.75*gamma, 0, 0.75*gamma)
jump.location = c(0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9)
trials = 100

band_matrix = 10



mse.fl = c()
mse.ITALE = c()

for (x in (1:trials)) {
  
  trial = x
  
  print(trial)
  
  truth = form.truth(jump.mean, jump.location, p)
  
  set.seed(413*trial*10)
  
  M = rmvnorm(n, mean = rep(0,band_matrix*2+1), sigma = diag(band_matrix*2+1))
  
  X = bandSparse(n, p, (-band_matrix):band_matrix, M)
  
  X = data.matrix(X)
  
  error = rmvnorm(1, mean = rep(0,n), sigma = sigma*diag(n))
  
  y = as.numeric(as.numeric(X%*%matrix(truth)) + error)
  
  D = getD1d(p)
  
  result = run.tests(y, X, D, truth)
  
  
  mse.fl = c(mse.fl, result$mse.fl)
  
  
  mse.ITALE = c(mse.ITALE, result$mse.ITALE)
}


result_4_2_3 = rbind(mse.fl, mse.ITALE)

write.table (result_4_2_3, file ="random_Gaussian_matrix_4_2_3_mse.csv")  

# result setting 1: vary bandwidth
# result setting 1.4:  band_matrix = 50


n = 1000
p = 1000
sigma = 2
gamma = 1
jump.mean = c(0*gamma, 1*gamma, 0*gamma, 1.5*gamma, 0, 2*gamma, 0, 1.75*gamma, 0, 0.75*gamma)
jump.location = c(0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9)
trials = 100

band_matrix =  50

mse.fl = c()
mse.ITALE = c()

for (x in (1:trials)) {
  
  trial = x
  
  print(trial)
  
  truth = form.truth(jump.mean, jump.location, p)
  
  set.seed(414*trial*10)
  
  M = rmvnorm(n, mean = rep(0,band_matrix*2+1), sigma = diag(band_matrix*2+1))
  
  X = bandSparse(n, p, (-band_matrix):band_matrix, M)
  
  X = data.matrix(X)
  
  error = rmvnorm(1, mean = rep(0,n), sigma = sigma*diag(n))
  
  y = as.numeric(as.numeric(X%*%matrix(truth)) + error)
  
  D = getD1d(p)
  
  result = run.tests(y, X, D, truth)
  
  mse.fl = c(mse.fl, result$mse.fl)
  
  
  mse.ITALE = c(mse.ITALE, result$mse.ITALE)
  
}


result_4_2_4 = rbind(mse.fl, mse.ITALE)

write.table (result_4_2_4, file ="random_Gaussian_matrix_4_2_4_mse.csv")  

