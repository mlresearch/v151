import config
from collections import OrderedDict

import torch.nn as nn
import torch.nn.functional as F


class SmallCNN(nn.Module):
    def __init__(self):
        super(SmallCNN, self).__init__()
        self.conv1 = nn.Conv2d(1, 16, 4, stride=2, padding=1)
        self.layer_one = nn.Sequential(OrderedDict([
            ('conv1', self.conv1),
        ]))

        self.conv1_bn = nn.BatchNorm2d(16)
        self.conv2 = nn.Conv2d(16, 32, 4, stride=2, padding=1)
        self.conv2_bn = nn.BatchNorm2d(32)
        self.conv3 = nn.Conv2d(32, 64, 4, stride=2, padding=1)
        self.conv3_bn = nn.BatchNorm2d(64)
        self.fc1 = nn.Linear(64 * 3 * 3, 10)

        self.other_layers = nn.ModuleList()
        self.other_layers.append(self.conv2)
        self.other_layers.append(self.conv2_bn)
        self.other_layers.append(self.conv3)
        self.other_layers.append(self.conv3_bn)
        self.other_layers.append(self.fc1)

    def forward(self, x):
        x = self.layer_one(x)
        self.layer_one_out = x
        self.layer_one_out.requires_grad_()
        self.layer_one_out.retain_grad()
        x = self.layer_one_out

        x = F.relu(self.conv1_bn(x))
        x = F.relu(self.conv2_bn(self.conv2(x)))
        x = F.relu(self.conv3_bn(self.conv3(x)))
        x = x.view(-1, 64 * 3 * 3)
        x = self.fc1(x)
        return x


def create_network():
    return SmallCNN()
