from model.discriminator_linear import DiscriminatorLinear


class DiscriminatorWrapper:

    def __init__(self):
        pass

    @staticmethod
    def get_wrapper(config, constants, bootstrap_model=None, token_to_id=None):

        if constants["nce_model"] == "linear":
            return DiscriminatorLinear(config, constants, bootstrap_model)
        else:
            raise AssertionError("Unhandled nce model %s" % constants["nce_model"])
