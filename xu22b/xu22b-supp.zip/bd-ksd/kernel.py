#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Dec 15 18:46:08 2020

@author: wenkaix
"""

import numpy as np
import bdksd.util as util
import torch
import torchvision
import torch.autograd as autograd



class KDiagGauss():
    """
    A Gaussian kernel with diagonal covariance structure i.e., one Gaussian
    width for each dimension.
    """
    def __init__(self, sigma):
        """
        sigma: a one-dimensional torch Tensor of length d containing one width
            squared for each of the d dimensions.
        """
        self.sigma = sigma

    def eval(self, X, Y=None):
        """
        Equivalent to dividing each dimension with the corresponding width (not
        width^2) and using the standard Gaussian kernel.
        """
        sigma = self.sigma.to(X.device)
        if Y is None:
            Y = X.clone()
        sumx2 = torch.reshape(torch.sum(X**2, 1), (-1, 1))
        sumy2 = torch.reshape(torch.sum(Y**2, 1), (1, -1))
        D2 = sumx2 - 2*(X@Y.T) + sumy2
        
        K = torch.exp((-D2/(2.0*sigma**2)))
        return K

    def gradX_Y(self, X, Y, dim):
        """
        Compute the gradient with respect to the dimension dim of X in k(X, Y).
        X: nx x d
        Y: ny x d
        Return a numpy array of size nx x ny.
        """
        sigma = self.sigma.to(X.device)
        K = self.eval(X, Y)
        Diff = X[:, [dim]] - Y[:, [dim]].T
        G = -K*Diff/(sigma**2)
        return G

    def gradY_X(self, X, Y, dim):
        """
        Compute the gradient with respect to the dimension dim of Y in k(X, Y).
        X: nx x d
        Y: ny x d
        Return a numpy array of size nx x ny.
        """
        return -self.gradX_Y(Y, X, dim)

    def gradXY_sum(self, X, Y):
        r"""
        Compute \sum_{i=1}^d \frac{\partial^2 k(X, Y)}{\partial x_i \partial y_i}
        evaluated at each x_i in X, and y_i in Y.
        X: nx x d numpy array.
        Y: ny x d numpy array.
        Return a nx x ny numpy array of the derivatives.
        """
        (n1, d1) = X.shape
        (n2, d2) = Y.shape
        assert d1==d2, 'Dimensions of the two inputs must be the same'
        d = d1
        sigma = self.sigma.to(X.device)
        D2 = torch.sum(X**2, 1).view(n1, 1) - 2*(X.float().matmul(Y.float().T)) + torch.sum(Y**2, 1).view(1, n2)
        K = torch.exp((-D2/(2.0*sigma**2)))
        G = K/(sigma**2)*(d - (D2/(sigma**2)))
        return G

    def update_param(self, sigma):
        self.sigma = sigma
        
        
    def __str__(self):
        return "KGauss(%.3f)"%self.sigma**2

# end class KDiagGauss
        

class KDeepGauss():
    """
    A Deep kernel with Gaussian form on top of the deep features phi
    k(x,y) = exp(-\|phi(x) - phi(y)\|^2/(2*sigma))
    """
    def __init__(self, phi, sigma2=1.):
        """
        sigma2s: a one-dimensional array of length d containing one width
            squared for each of the d dimensions.
        """
        self.sigma2 = sigma2
        self.phi = phi
        
    def eval(self, X, Y=None, return_fea=False):
        """
        Equivalent to dividing each dimension with the corresponding width (not
        width^2) and using the standard Gaussian kernel.
        """
        if Y is None:
            Y = X.clone()
        phi = self.phi
        Sx = util.MatConvert(X.detach().cpu().numpy())
        Sy = util.MatConvert(Y.detach().cpu().numpy())
        PhiX = phi(Sx)
        PhiY = phi(Sy)
        sumx2 = torch.reshape(torch.sum(PhiX**2, 1), (-1, 1))
        sumy2 = torch.reshape(torch.sum(PhiY**2, 1), (1, -1))
        D2 = sumx2 - 2*(PhiX@PhiY.T) + sumy2
        K = torch.exp((-D2/(2.0*self.sigma2)))
        if return_fea:
            return K, PhiX, PhiY
        else:
            return K
    
    def grad_phi(self, X, dim):
        n,d = X.shape
        phi = self.phi
        Sx = util.MatConvert(X.detach().numpy())
        Sx.requires_grad = True
        PhiX = phi(Sx)
        G = torch.zeros(n,d).to(X.device)
#        _,d_phi = PhiX.shape
#        for i in range(d):
        grad_sum = torch.sum(PhiX[:,dim])
        Gs = torch.autograd.grad(grad_sum, Sx, retain_graph=True, only_inputs=True)
#        G[:,i] = Gs[0][:,i]
        G = Gs[0]
        return G
    
    def gradX_Y(self, X, Y, dim):
        """
        Compute the gradient with respect to the dimension dim of X in k(X, Y).
        X: nx x d
        Y: ny x d
        Return a numpy array of size nx x ny.
        """
        sigma2 = self.sigma2
        K, PhiX, PhiY = self.eval(X, Y, return_fea=True)
        n,d_phi = PhiX.shape
        G = torch.zeros(n,n).to(PhiX.device)
        for i in range(d_phi):
            Diff = PhiX[:, [i]] - PhiY[:, [i]].T
            Gphi = self.grad_phi(X, i) # an n x d torch tensor 
            G += torch.einsum('i,ij->ij', Gphi[:,dim], Diff.to(Gphi.device))     
        G = -G * K.to(G.device)/sigma2
        return G

    def gradY_X(self, X, Y, dim):
        """
        Compute the gradient with respect to the dimension dim of Y in k(X, Y).
        X: nx x d
        Y: ny x d
        Return a numpy array of size nx x ny.
        """
        return -self.gradX_Y(Y, X, dim)

    def gradXY_sum(self, X, Y):
        r"""
        Compute \sum_{i=1}^d \frac{\partial^2 k(X, Y)}{\partial x_i \partial y_i}
        evaluated at each x_i in X, and y_i in Y.
        X: nx x d numpy array.
        Y: ny x d numpy array.
        Return a nx x ny numpy array of the derivatives.
        """
        (n1, d1) = X.shape
        (n2, d2) = Y.shape
        assert d1==d2, 'Dimensions of the two inputs must be the same'
        d = d1
        sigma2 = self.sigma2
        #compute kernel stats
        K, PhiX, PhiY = self.eval(X, Y, return_fea=True)
        d_phi = PhiX.shape[1]
        DPhi = PhiX - PhiY
        D_full = torch.einsum('ni,mj-> nmij',DPhi, DPhi)
        Gphi = torch.zeros(n1,n2).to(PhiX.device)
        GphiX = torch.zeros(n1,d,d_phi).to(PhiX.device)
        GphiY = torch.zeros(n2,d,d_phi).to(PhiX.device)
        for i in range(d_phi):
            GphiX[:,:,i] =self.grad_phi(X, i).to(Gphi.device)
            GphiY[:,:,i] =self.grad_phi(Y, i).to(Gphi.device)
        for i in range(d_phi):
            for j in range(d_phi):
                D2 = torch.einsum('nm,nl,ml-> nm', D_full[:,:,i,j], GphiX[:,:,i], GphiY[:,:,j])          
                I =  torch.einsum('nl,ml-> nm', GphiX[:,:,i], GphiY[:,:,j]) # * d_phi
                Gphi += (I - (D2/sigma2))
#        D2 = torch.sum(X**2, 1).view(n1, 1) - 2*(X.float().matmul(Y.float().T)) + torch.sum(Y**2, 1).view(1, n2)
#        K = torch.exp((-D2/(2.0*sigma2)))
        G = K/sigma2*Gphi

        return G

    def update_param(self, sigma2):
        self.sigma2 = sigma2
        
        
    def __str__(self):
        return "KDeepGauss(%.3f)"%self.sigma2

# end class KDeepGauss



class KDeepGaussq():
    """
    A Deep kernel with Gaussian form on top of the deep features phi
    k(x,y) = exp(-\|phi(x) - phi(y)\|^2/(2*sigma))
    """
    def __init__(self, phi, sigma2=1., sigmaq2=1.):
        """
        sigma2s: a one-dimensional array of length d containing one width
            squared for each of the d dimensions.
        """
        self.sigma2 = sigma2
        self.sigmaq2 = sigmaq2
        self.phi = phi
        
    def eval(self, X, Y=None, return_fea=False):
        """
        Equivalent to dividing each dimension with the corresponding width (not
        width^2) and using the standard Gaussian kernel.
        """
        if Y is None:
            Y = X.clone()
        phi = self.phi
        Sx = util.MatConvert(X.detach().cpu().numpy())
        Sy = util.MatConvert(Y.detach().cpu().numpy())
        PhiX = phi(Sx)
        PhiY = phi(Sy)
        sumx2 = torch.reshape(torch.sum(PhiX**2, 1), (-1, 1))
        sumy2 = torch.reshape(torch.sum(PhiY**2, 1), (1, -1))
        D2 = sumx2 - 2*(PhiX@PhiY.T) + sumy2
        
        sumx2org = torch.reshape(torch.sum(X**2, 1), (-1, 1))
        sumy2org = torch.reshape(torch.sum(Y**2, 1), (1, -1))
        D2org = sumx2org - 2*(X@Y.T) + sumy2org
        
        
        K = torch.exp(-D2/(2.0*self.sigma2) - D2org.to(D2.device)/(2.0*self.sigmaq2))
        if return_fea:
            return K, PhiX, PhiY
        else:
            return K
    
    def grad_phi(self, X, dim):
        n, d = X.shape
        phi = self.phi
        Sx = util.MatConvert(X.detach().numpy())
        Sx.requires_grad = True
        PhiX = phi(Sx)
        G = torch.zeros(n,d).to(X.device)
        for i in range(d):
            grad_sum = torch.sum(PhiX[:,i])
            Gs = torch.autograd.grad(grad_sum, Sx, retain_graph=True, only_inputs=True)
            G[:,i] = Gs[0][:,dim]
        return G
    
    def gradX_Y(self, X, Y, dim):
        """
        Compute the gradient with respect to the dimension dim of X in k(X, Y).
        X: nx x d
        Y: ny x d
        Return a numpy array of size nx x ny.
        """
        sigma2 = self.sigma2
        n,d = X.shape
        K, PhiX, PhiY = self.eval(X, Y, return_fea=True)
        Gphi = self.grad_phi(X, dim) #an n x d Pytorch tensor 
        for i in range(d):
            Diff = PhiX[:, [i]] - PhiY[:, [i]].T
            G = torch.einsum('i,ij->ij',Gphi[:,i], Diff.to(Gphi.device))     
        
        Diff = X[:, [dim]] - Y[:, [dim]].T
        G = -G * K.to(G.device)/sigma2 -K.to(G.device)*Diff.to(G.device)/(self.sigmaq2)
        return G
    
        
    def gradY_X(self, X, Y, dim):
        """
        Compute the gradient with respect to the dimension dim of Y in k(X, Y).
        X: nx x d
        Y: ny x d
        Return a numpy array of size nx x ny.
        """
        return -self.gradX_Y(Y, X, dim)

    def gradXY_sum(self, X, Y):
        r"""
        Compute \sum_{i=1}^d \frac{\partial^2 k(X, Y)}{\partial x_i \partial y_i}
        evaluated at each x_i in X, and y_i in Y.
        X: nx x d numpy array.
        Y: ny x d numpy array.
        Return a nx x ny numpy array of the derivatives.
        """
        (n1, d1) = X.shape
        (n2, d2) = Y.shape
        assert d1==d2, 'Dimensions of the two inputs must be the same'
        d = d1
        sigma2 = self.sigma2
        #compute kernel stats
        K, PhiX, PhiY = self.eval(X, Y, return_fea=True)
        Gphi = torch.zeros(n1,n2).to(PhiX.device)
        for i in range(d):
            GphiX =self.grad_phi(X, i).to(Gphi.device)
            GphiY =self.grad_phi(Y, i).to(Gphi.device)
            Gphi += torch.einsum('ni,mi->nm', GphiX, GphiY)
        DPhi = PhiX - PhiY
        D2_dim = torch.einsum('ni,mj-> nmij',DPhi, DPhi)
        D2 = torch.einsum('nmij,ij-> nm',D2_dim, Gphi)
        I = torch.ones(n1,n2).to(D2.device) * PhiX.shape[1]
#        D2 = torch.sum(X**2, 1).view(n1, 1) - 2*(X.float().matmul(Y.float().T)) + torch.sum(Y**2, 1).view(1, n2)
#        K = torch.exp((-D2/(2.0*sigma2)))
        G = K/sigma2*(I - (D2/sigma2))
        
        
        sigmaq2 = self.sigmaq2
        D2org = torch.sum(X**2, 1).view(n1, 1) - 2*(X.float().matmul(Y.float().T)) + torch.sum(Y**2, 1).view(1, n2)
        K = torch.exp((-D2org/(2.0*sigmaq2)))
        G += K.to(G.device)/(sigmaq2)*(d - (D2org.to(G.device)/(sigmaq2)))
        return G

    def update_param(self, sigma2):
        self.sigma2 = sigma2
        
        
    def __str__(self):
        return "KDeepGaussq(%.3f)"%self.sigma2
    
    
    
def init_weights(m):
    print(m)
    if type(m) == torch.nn.Linear:
#        torch.nn.init.xavier_uniform_(m.weight)
#        torch.nn.init.normal_(m.bias)
        m.weight.data.fill_(1.0)
        m.bias.data.fill_(0.)
        print(m.weight)

    
class ModelLatentF(torch.nn.Module):
    """Latent space for both domains."""
    def __init__(self, x_in, H, x_out):
        """Init latent features."""
        super(ModelLatentF, self).__init__()
        self.restored = False
        self.latent = torch.nn.Sequential(
            torch.nn.Linear(x_in, H, bias=True),
            torch.nn.Softplus(),
            torch.nn.Linear(H, H, bias=True),
            torch.nn.Softplus(),
            torch.nn.Linear(H, H, bias=True),
            torch.nn.Softplus(),
            torch.nn.Linear(H, x_out, bias=True),
        )
#        self.latent.apply(init_weights)
    def forward(self, input):
        """Forward the LeNet."""
        fealant = self.latent(input)
        return fealant
    

class DeepFeature(torch.nn.Module):
    """Deep feature for Deepkernel class Latent space for both domains."""
    def __init__(self, dim_in, dim_layer, dim_out):
        """Init latent features."""
        super(DeepFeature, self).__init__()
        self.restored = False
        self.phi = torch.nn.Sequential(
            torch.nn.Linear(dim_in, dim_layer, bias=True),
            torch.nn.Softplus(),
            torch.nn.Linear(dim_layer, dim_layer, bias=True),
            torch.nn.Softplus(),
            torch.nn.Linear(dim_layer, dim_layer, bias=True),
            torch.nn.Softplus(),
            torch.nn.Linear(dim_layer, dim_out, bias=True),
        )
        
    def __call__(self, X):
        """Forward the LeNet."""
        fea = self.phi(X)
        return fea
    
    def grad(self, X):
        fea = self.phi(X)
        return fea.gradient(X)
