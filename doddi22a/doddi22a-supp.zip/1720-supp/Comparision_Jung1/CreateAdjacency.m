function [Adj] = CreateAdjacency(p)
x = sqrt(p);
mat = 1:p;                 
reshape(mat,[x,x]); mat = mat';
temp = repmat([ones(x-1, 1); 0], x, 1);  
temp = temp(1:end-1);                
temp1 = ones(x^2-x, 1);                 
Adj = diag(temp, 1)+diag(temp1, x);   
Adj = Adj+Adj';                             
                                          
end

