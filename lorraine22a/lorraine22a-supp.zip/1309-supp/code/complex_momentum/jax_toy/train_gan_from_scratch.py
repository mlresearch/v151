import matplotlib as mpl

mpl.use('Agg')

from jax import numpy as np
from jax import grad, vjp, jvp, vmap, value_and_grad
from jax.nn import log_sigmoid, sigmoid
from toy_data import sample_spirals
import tqdm
from jax import random
import matplotlib.pyplot as plt
import argparse
import os, datetime

# import copy
parser = argparse.ArgumentParser()

parser.add_argument('--z_dim', type=int, default=4,
                    help='The dimensionality of the latent space')
parser.add_argument('--batch_size', type=int, default=1000,
                    help='Batch size')

parser.add_argument('--G_lr', type=float, default=0.1,  # 1e-3,
                    help='Generator learning rate')
parser.add_argument('--D_lr', type=float, default=0.1,  # 1e-3,
                    help='Discriminator learning rate')
parser.add_argument('--zero_game', action='store_true', default=False)

parser.add_argument('--n_epochs', type=int, default=1000000,
                    help='Number of epochs to train')

parser.add_argument('--momentum', type=float, default=0.9,
                    help='momentum parameter')

parser.add_argument('--opt', type=str, choices=['gd', 'polyaks_momentum'], default='gd')  # 'polyaks_momentum')

args = parser.parse_args()
key = random.PRNGKey(0)

negative_slope = 0.1
leaky_rel = lambda x_: np.where(x_ >= 0, x_, negative_slope * x_)


def mlp_forward(ws, x, h=leaky_rel):
    """
    x:input Dx1
    ws:[(w1,b1),(w2,b2),...] where w_i R^ F1xF2, b_i \R^ F2
    h: activation function
    """
    z = x
    for i, (w, b) in enumerate(ws):
        z = np.dot(w.T, z.reshape(-1, 1)) + b
        if h is not None and i < (len(ws) - 1):
            z = h(z)
    return z


#
# def flatten_params(ws):
#     r = []
#     for (w, b) in ws:
#         r.append(np.vstack([w.reshape(-1,1 ), b.reshape(-1,1 )]))
#     return np.array(r).reshape(-1)


def kaiming_init(rngkey, gain, shape):
    """
    kaiming init.
    """
    gain = np.sqrt(2.0 / (1 + np.sqrt(5) ** 2))
    std = gain / np.sqrt(shape[0])
    bound = np.sqrt(3.0) * std  # Calculate uniform bounds from standard deviation
    return random.uniform(rngkey, shape=shape, minval=-bound, maxval=bound)


def generate_weights(rngkey, ws_, init_k=True):
    key_, *subkeys = random.split(rngkey, len(ws_) + 1)
    weights = []
    for ((w, _), skey) in zip(ws_, subkeys):
        w = list(reversed(w))
        b_ = np.zeros((w[1], 1))
        # kaiming...
        if init_k is True:
            w_ = kaiming_init(skey, negative_slope, shape=w)
        else:
            w_ = random.normal(skey, (w[0], w[1]))

        weights.append((w_, b_))
    return key_, weights


# This is the original formulation of GANs eq (1) Goodfellow et al 2014.
def V(rngkey, X_, G_fn_, D_fn_, *params, negative=False, sample_size=None):
    D_w_ = params[0] if len(params) >= 1 else None
    G_w_ = params[1] if len(params) >= 2 else None
    key_, subkey = random.split(rngkey, 2)

    # x ~ p(x)
    Dx = vmap(D_fn_, in_axes=(0, None))(X_, D_w_)

    # v1= int_x p(x) log D(x) dx
    v1 = np.mean(log_sigmoid(Dx))

    # z~ P(z)
    sample_size = X_.shape[0] if sample_size is None else sample_size

    Z = random.normal(key=subkey, shape=(sample_size, G_w_[0][0].shape[0]))

    Gz = vmap(G_fn_, in_axes=(0, None))(Z, G_w_)
    DGz = vmap(D_fn_, in_axes=(0, None))(Gz, D_w_)

    # v1= int_z p(z) log (1-D(G(z))) dz
    v2 = np.mean(np.log(1 - sigmoid(DGz)))

    v_ = v1 + v2

    if negative is True:
        v_ = -v_

    return v_, (key_, (v1, v2, Gz))


def loss_gen(rngkey, X_, G_fn_, D_fn_, *params):
    D_w_ = params[0] if len(params) >= 1 else None
    G_w_ = params[1] if len(params) >= 2 else None
    key_, subkey = random.split(rngkey, 2)

    # z~ P(z)
    Z = random.normal(key=subkey, shape=(X_.shape[0], G_w_[0][0].shape[0]))

    Gz = vmap(G_fn_, in_axes=(0, None))(Z, G_w_)
    DGz = vmap(D_fn_, in_axes=(0, None))(Gz, D_w_)

    # min_G -E[logD(G(z))]
    v_ = -np.mean(log_sigmoid(DGz))

    return v_, (key_, (v_, None, Gz))


print(args)
# Dim....
z_dim = args.z_dim
batch_size = args.batch_size  # 1000
ad_hoc_gen_obj = not args.zero_game

# ----
lr_g = args.G_lr  # 1e-3  # 0.01
lr_d = args.D_lr
epochs = args.n_epochs  # 100000
in_d = z_dim

log_every = 10
in_h = 25
out_d = 2
B = args.momentum
opt = args.opt
timestamp = '{:%Y-%m-%d}'.format(datetime.datetime.now())
out_dir = os.path.join('./out_dir', timestamp + '_' + '_'.join([f'{v}_{k}' for v, k in vars(args).items()]))
if not os.path.isdir(out_dir):
    os.makedirs(out_dir)

# Generator...
key, G_w = generate_weights(key, [((in_h, in_d), None), ((in_h, in_h), None), ((out_d, in_h), None)])

# Discriminator...
key, D_w = generate_weights(key, [((in_h, 2), None), ((in_h, in_h), None), ((1, in_h), None)])

D = lambda x_, D_w_=None: mlp_forward(ws=D_w, x=x_, h=leaky_rel) if D_w_ is None else mlp_forward(ws=D_w_, x=x_,
                                                                                                  h=leaky_rel)
G = lambda x_, G_w_=None: mlp_forward(ws=G_w, x=x_, h=leaky_rel) if G_w_ is None else mlp_forward(ws=G_w_, x=x_,
                                                                                                  h=leaky_rel)


def gd_update(W_, g_W_, lr_, *args):
    # D_w = [(w_ - lr_d * g_w, b_ - lr_d * g_b) for ((w_, b_), (g_w, g_b)) in zip(D_w, g_Dw)]
    W = W_.copy()
    W1 = [(w_ - lr_ * g_w, b_ - lr_ * g_b) for ((w_, b_), (g_w, g_b)) in zip(W_, g_W_)]
    return W1, W


def polyaks_momentum_update(W_, g_W_, lr_, B_, Wk_prev, *args):
    W = W_.copy()
    # debug momentum...
    # Bdebug = [(B_ * (w_ - w_prev), B_ * (b_ - b_prev)) for
    #           ((w_, b_,), (g_w, g_b), (w_prev, b_prev)) in zip(W_, g_W_, Wk_prev)]

    #

    W1 = [(w_ - lr_ * g_w + B_ * (w_ - w_prev), b_ - lr_ * g_b + B_ * (b_ - b_prev)) for
          ((w_, b_,), (g_w, g_b), (w_prev, b_prev)) in zip(W_, g_W_, Wk_prev)]

    return W1, W


optimizer_update = polyaks_momentum_update if opt == 'polyaks_momentum' else gd_update

print(optimizer_update)
pbar = tqdm.tqdm(range(epochs))

prevD_w = D_w.copy()
prevG_w = G_w.copy()

for i in pbar:  # range(epochs):
    X, _ = sample_spirals(batch_size)
    X = np.array(X)  # to jax numpy
    # v, (key, (v1, v2, Gz)) = V(key, X, G, D, D_w, G_w, negative=False)

    # Discriminator Update
    # g_Dw, (key, _) = grad(V, argnums=4, has_aux=True)(key, X, G, D, D_w, G_w, negative=True)
    (val_loss_d, (key, _)), g_Dw = value_and_grad(V, argnums=4, has_aux=True)(key, X, G, D, D_w, G_w, negative=True)
    # GD Update
    # D_w = [(w_ - lr_d * g_w, b_ - lr_d * g_b) for ((w_, b_), (g_w, g_b)) in zip(D_w, g_Dw)]
    D_w, prevD_w = optimizer_update(D_w, g_Dw, lr_d, B, prevD_w)

    # Generator Update
    if ad_hoc_gen_obj is True:
        # g_Gw, (key, _) = grad(loss_gen, argnums=5, has_aux=True)(key, X, G, D, D_w, G_w)
        (val_loss_gen, (key_, _)), g_Gw = value_and_grad(loss_gen, argnums=5, has_aux=True)(key, X, G, D, D_w, G_w)
        # import ipdb;ipdb.set_trace()
        # print('valoss_gen:'+val_loss_gen)

    else:
        # original formulation eq (1) Goodfellow et al 2014.
        g_Gw, (key, _) = grad(V, argnums=5, has_aux=True)(key, X, G, D, D_w, G_w)

    pbar.set_description(f'val_loss_dis: {val_loss_d} ,  val_loss_gen:{val_loss_gen}')
    # G_w = [(w_ - lr_g * g_w, b_ - lr_g * g_b) for ((w_, b_), (g_w, g_b)) in zip(G_w, g_Gw)]
    G_w, prevG_w = optimizer_update(G_w, g_Gw, lr_g, B, prevG_w)
    import ipdb;ipdb.set_trace()
    if (i % log_every) == 0:
        v, (key, (v1, v2, Gz)) = V(key, X, G, D, D_w, G_w)

        # pbar.set_description('D=%.5f, G=%.5f,V=%.5f' % (-v, v2, v))
        if (i % (log_every * 100)) == 0:
            v, (key, (v1, v2, Gz)) = V(key, X, G, D, D_w, G_w, sample_size=100000)
            pbar.set_description('D=%.5f, G=%.5f,V=%.5f' % (-v, v2, v))
            range_lim = 6
            plt.hist2d(Gz[:, 0, 0], Gz[:, 1, 0], range=[[-range_lim, range_lim], [-range_lim, range_lim]],
                       bins=100, cmap=plt.cm.jet)
            plt.tight_layout()
            plt.savefig(os.path.join(out_dir, 'test_%.5i.png' % i))

    pbar.update(1)

del pbar
