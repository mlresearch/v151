import os
import random

from PIL import Image

IMG_EXTENSIONS = ['.jpg', '.JPG', '.jpeg', '.JPEG',
                  '.png', '.PNG', '.ppm', '.PPM', '.bmp', '.BMP']


def get_image_paths(data_dir):
    """Get paths to images in a folder of images."""
    images = []
    assert os.path.isdir(data_dir), '%s is not a valid directory' % data_dir

    def _is_image_file(filename):
        return any(filename.endswith(extension) for extension in IMG_EXTENSIONS)

    for root, _, filenames in sorted(os.walk(data_dir)):
        for filename in filenames:
            if _is_image_file(filename):
                path = os.path.join(root, filename)
                images.append(path)

    return images


def create_paired_image(data_dir, phase, percent, image_type='L'):
    '''
    data_dir(string)    : the directory of the folder stores all data
    phase(string)       : val or test
    percent(float[0,1]  : how many percentage of the data you want to convert to paired dataset
    '''

    def _concatenate_horizontal(im1, im2):
        dst = Image.new(image_type, (im1.width + im2.width, im1.height))
        dst.paste(im1, (0, 0))
        dst.paste(im2, (im1.width, 0))
        return dst

    a_dir = os.path.join(data_dir, phase + 'A')
    b_dir = os.path.join(data_dir, phase + 'B')
    a_paths = sorted(get_image_paths(a_dir))
    b_paths = sorted(get_image_paths(b_dir))
    # print(len(a_paths), len(b_paths))

    pair_folder = 'val' if phase is 'train' else phase
    paired_dir = os.path.join(data_dir, pair_folder)
    os.makedirs(paired_dir, exist_ok=True)
    num_pairs = int(min(len(a_paths), len(b_paths)) * percent)

    for idx in range(num_pairs):
        a_img = Image.open(a_paths[idx]).convert(image_type)
        # os.remove(a_paths[idx])
        b_img = Image.open(b_paths[idx]).convert(image_type)
        # os.remove(b_paths[idx])
        width, height = max(a_img.width, b_img.width), max(a_img.height, b_img.height)
        a_img = a_img.resize((width, height))
        b_img = b_img.resize((width, height))
        paired_img_name = os.path.join(paired_dir, f'paired_{idx}.jpg')
        _concatenate_horizontal(a_img, b_img).save(paired_img_name)


if __name__ == '__main__':

    data_dir = r'../data/MNIST/test'

    # phase = 'cnn'
    # phase = 'eval'
    # phase = 'train'
    # phase = 'demo'
    phase = 'test'

    if phase == 'train':
        percent = 0.1
    else:
        percent = 1
    create_paired_image(data_dir, phase, percent)
