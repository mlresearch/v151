from dataclasses import dataclass
from random import randint


@dataclass
class BaseConfig:
    # *sets this to be total eps instead of eps' for Sinkhorn
    itsbp_outer_tolerance: float = 2e-1

    @staticmethod
    def itsbp_schedule(cnt, leaf_nodes):
        cnt += 1
        return cnt % len(leaf_nodes)

    @staticmethod
    def itsbp_stochastic_schedule(cnt, leaf_nodes):
        old_cnt = cnt
        while cnt == old_cnt:
            cnt = randint(0, len(leaf_nodes) - 1)
        return cnt


baseconfig = BaseConfig()
