import numpy as np
import scipy as sp
import time
from tqdm import tqdm


def SMD(eps, N, MDP, t_mix, checkpoint_iters=100):
    N_s = MDP.n_state
    N_a = MDP.n_action
    
    A_tot = N_s * N_a
    eta_v = eps / 8
    eta_mu = eps / (4 * 9 * (t_mix**2 + 1))
    
    v = np.zeros(N_s)
    mu = np.ones(A_tot)
    mu /= np.sum(mu)
    
    policies = []
    times = []
    start_time = time.time()
    
    for _ in tqdm(range(N)):
        i, a_i = np.unravel_index(np.random.choice(A_tot, p=mu), (N_s, N_a))
        j = MDP.step(i, a_i)
        i_prime, a_i_prime = np.unravel_index(np.random.choice(A_tot), (N_s, N_a))
        j_prime = MDP.step(i_prime, a_i_prime)
        
        joint_index = np.ravel_multi_index((i_prime,a_i_prime), (N_s, N_a))
        mu[joint_index] *= np.exp( -eta_mu * (v[i_prime] - v[j_prime] - MDP.R[a_i_prime,i_prime]))
        mu /= np.sum(mu)
        
        v[j] = np.max([v[j] - eta_v, -6 * t_mix])
        v[i] = np.min([v[i] + eta_v, 6 * t_mix])
        
        if _ % checkpoint_iters == checkpoint_iters - 1:
            mu = mu.reshape((N_s, N_a))
            policies.append((mu.copy() / mu.sum(axis=1)[:, None]).T)
            mu = mu.reshape(-1)
            times.append(time.time() - start_time)
    
    return policies, times