import torch
import torch.nn as nn
import torch.nn.functional as F


class LinearClassifier(nn.Module):
    """ Linear Model for classification """

    NAME = "linearclassifier"

    def __init__(self, config, constants, bootstrap_model=None, input_dim=None):
        super(LinearClassifier, self).__init__()

        input_dim = constants["n_hidden"] if input_dim is None else input_dim

        self.input_encoder = nn.Sequential(
            nn.Linear(input_dim, config["num_classes"])
        )

        if torch.cuda.is_available():
            self.cuda()

        if bootstrap_model is not None:
            self.load_state_dict(bootstrap_model.state_dict())

    def gen_log_prob(self, batch_input):
        return F.log_softmax(self.input_encoder(batch_input), dim=1)        # Batch x num classes

    def save(self, folder_name, model_name=None):

        if model_name is None:
            torch.save(self.state_dict(), folder_name + "nce_k_model")
        else:
            torch.save(self.state_dict(), folder_name + model_name)

    def load(self, folder_name, model_name=None):

        if model_name is None:
            self.load_state_dict(torch.load(folder_name + "nce_k_model"))
        else:
            self.load_state_dict(torch.load(folder_name + model_name))
