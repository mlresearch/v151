import pickle
import torch

RED = "\033[1;31m"
YELLOW = "\033[1;33m"

def init_w_grad_buffer(model):
    return [torch.zeros_like(param).cuda() for param in model.parameters()]

def init_d_grad_buffer(deltas):
    return [torch.zeros_like(delta).cuda() for delta in deltas]

def save(dataset, file):
    with open(file, 'wb') as fo:
        pickle.dump(dataset, fo)

def unpickle(file):
    with open(file, 'rb') as fo:
        dict = pickle.load(fo, encoding='bytes')
    return dict

def pprint(stat):
    for key_idx, key in enumerate(stat.keys()):
        if key_idx + 1 != len(stat.keys()):
            end = ' ||'
        else:
            end = '\n'

        if type(stat[key]) is not float:
            print(RED, key, YELLOW, stat[key], end=end)
        else:
            print(RED, key, YELLOW, "{:.3f}".format(stat[key]), end=end)
