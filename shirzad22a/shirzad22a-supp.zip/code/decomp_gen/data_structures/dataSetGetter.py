"""
Generates the dataset of graphs
Preproces the graph dataset and generates graphs in the structure that we have defined (Graph)
"""

import os
import numpy as np
import pickle
import random
from tqdm import tqdm
from pathlib import Path

from torch.utils.data.dataset import Dataset


from decomp_gen.data_structures.graph import Graph
from decomp_gen.data_structures.synthetic_data import create_graphs
from decomp_gen import configs

dataPath = (Path("__file__").absolute().parent)
relative_path = "../../data/Datasets"
dataPath = (dataPath / relative_path).absolute()


# def parse():
#     parser = argparse.ArgumentParser(description='')
#     parser.add_argument('--data_name', type=str, default='DD',
#                         choices=['DD', 'FIRSTMM_DB','qm9','zinc250k'],
#                         help='dataset to be built')
#     parser.add_argument('--graph_type', type=str, default='simple',
#                         choices=['simple', 'labeled'],
#                         help='Type of the graph, with type of the node and edges or just simple graph')
#     parser.add_argument('--number_of_samples', type=int, default=500000,
#                         help='Type of the graph, with type of the node and edges or just simple graph')
#     args = parser.parse_args()
#     return args
#
# args = parse()
# data_name = args.data_name
# graph_type = args.graph_type

def getIndices(dataLen, numberOfSamples, start):
    if start != -1:
        end = start + numberOfSamples
        if end > dataLen:
            print("[Warning] Number of requested samples out of bound")
            end = dataLen
        return list(np.arange(start, end))

    if numberOfSamples >= dataLen:
        print("[Warning] Number of requested samples exceeds dataset size")
        return list(np.arange(dataLen))

    indices = random.sample(list(np.arange(dataLen)), k=numberOfSamples)
    indices.sort()
    return indices


def getGRANGraphs(data_name, numberOfSamples=500000, start=-1):
    path_graph_indicator = None
    path_A = None
    min_nodes = 0
    max_nodes = 6000
    if data_name == "DD":
        relative_path1 = "GRAN_Datasets/DD/DD_graph_indicator.txt"
        path_graph_indicator = (dataPath / relative_path1).resolve()
        relative_path2 = "GRAN_Datasets/DD/DD_A.txt"
        path_A = (dataPath / relative_path2).absolute()
        min_nodes = 100
        max_nodes = 500
    else:
        relative_path1 = "GRAN_Datasets/FIRSTMM_DB/FIRSTMM_DB_graph_indicator.txt"
        path_graph_indicator = (dataPath / relative_path1).absolute()
        relative_path2 = "GRAN_Datasets/FIRSTMM_DB/FIRSTMM_DB_A.txt"
        path_A = (dataPath / relative_path2).absolute()

    print("Making graphs from: ", path_A)

    gindex = [0]
    gnodes = {}
    maxgraphid = 0
    with open(path_graph_indicator) as f:
        for i, l in enumerate(f):
            g = int(l)
            if (g > maxgraphid):
                maxgraphid = g
            gindex.append(g)
            if g in gnodes:
                gnodes[g].append(i + 1)
            else:
                gnodes[g] = [i + 1]

    # print("max graph id: ",maxgraphid)

    adj = {}
    with open(path_A) as f:
        for i, l in enumerate(f):
            tmp = l.split(',')
            u = int(tmp[0])
            v = int(tmp[1])

            if v in adj:
                adj[v].add(u)
            else:
                adj[v] = {u}

    def adj_matrix(nodes):
        # print(nodes)
        n = len(nodes)
        if n > max_nodes or n < min_nodes:
            return np.zeros((1, 1))
        newidx = {}
        for i, v in enumerate(nodes):
            newidx[v] = i

        adjmat = np.zeros((n, n))
        for v in nodes:
            for u in adj[v]:
                i = newidx[u]
                j = newidx[v]
                adjmat[i, j] = 1
                adjmat[j, i] = 1

        return adjmat

    indices = getIndices(maxgraphid, numberOfSamples, start)
    indices = [indices[i] + 1 for i in
               range(len(indices))]  # because GRAN datasets start with index 1!
    # print("indices: ", indices)

    adjmats = {}
    for index in indices:
        adjmats[index] = adj_matrix(gnodes[index])

    graphs = []
    MaxLen = -1
    print("Making Graph classes from adjacency matrices:")
    for index in tqdm(indices):
        if adjmats[index].shape[0] < 2:
            continue
        G = Graph(adjmats[index])
        G.randomBFSReorderNodes()
        graphs.append(G)
        MaxLen = max(G.getDTdiameter(), MaxLen)

    MaxLen = int((MaxLen + 1) / 2)
    return graphs, MaxLen


def getMoleculeGraphs(data_name, graph_type, numberOfSamples, start):

    relative_path = "Molecule_Datasets/" + data_name + ".npz"
    path = (dataPath / relative_path).absolute()

    try:
        print("loading data from: ", path)
        data = np.load(path)
    except:
        print("Dataset not there, downloading dataset")
        downloadCodePath = Path("__file__").absolute().parent
        relative_path = "download_molecules_data.py"
        downloadCodePath = (downloadCodePath / relative_path).absolute()
        os.system('python3 ' + str(downloadCodePath) + ' --data_name ' + data_name)
        print("Dataset downloaded")
        data = np.load(path)

    atoms = data['arr_0']
    edges = data['arr_1']
    simpleEdges = np.sum(edges, axis=1)

    def numberOfNodes(v):
        t = len(v)
        while (t > 1 and v[t - 1] == 0):
            t -= 1
        # newV = v[0:t].copy()
        # newE = e[0:t,0:t].copy()
        return t

    dataSize = data['arr_0'].shape[0]
    indices = getIndices(dataSize, numberOfSamples, start)

    processedData = []
    for i in indices:
        t = numberOfNodes(atoms[i])
        SE = simpleEdges[i][0:t, 0:t]
        processedData.append(SE)

    graphs = []
    MaxLen = -1
    print("Making Graph classes from adjacency matrices:")
    for i, adjmat in tqdm(enumerate(processedData)):
        G = Graph(adjmat)
        graphs.append(G)
        MaxLen = max(G.getDTdiameter(), MaxLen)

    MaxLen = int((MaxLen + 1) / 2)
    return graphs, MaxLen


def getGraphDataset(data_name='DD', graph_type='simple', numberOfSamples=500000, start=-1,
                    name=None):
    '''
    start=-1 means choose samples randomly
    possible data_names for now are: ['DD', 'FIRSTMM_DB','qm9','zinc250k','grid']
    graph_type can be 'simple' or 'labeled'
    '''

    dataset_dir = os.path.join(configs.root_dir, 'data', 'Datasets')
    graph_dir = os.path.join(dataset_dir, 'Graphs')
    os.makedirs(graph_dir, exist_ok=True)
    os.makedirs(os.path.join(dataset_dir, 'clusterGeneratorData'), exist_ok=True)

    if name == None:
        name = "{}_{}".format(data_name, numberOfSamples)

    namePath = (Path("__file__").absolute().parent)
    relative_path = os.path.join(graph_dir, name) + ".dat"
    namePath = (namePath / relative_path).absolute()
    try:
        with open(namePath, "rb") as f:
            data = pickle.load(f)
        return data[0], data[1]
    except:
        print("Dataset not found in saved graphs, generating dataset:")

    if data_name == 'DD' or data_name == 'FIRSTMM_DB':
        dataGraphs, LL = getGRANGraphs(data_name, numberOfSamples, start)
    elif data_name == 'qm9' or data_name == 'zinc250k':
        dataGraphs, LL = getMoleculeGraphs(data_name, graph_type, numberOfSamples, start)
    elif data_name == 'grid':
        try:
            gridPath = (Path("__file__").absolute().parent)
            relative_path = os.path.join(graph_dir, 'grid_100.dat')
            gridPath = (gridPath / relative_path).absolute()
            with open(gridPath, "rb") as f:
                data = pickle.load(f)
            return data[0], data[1]
        except:
            return create_graphs('grid')
    elif data_name == 'community' or data_name == 'lobster':
        return create_graphs(data_name)
    else:
        raise ValueError("[ERROR] Unexpected value data_name={}".format(data_name))

    with open(namePath, "wb") as f:
        pickle.dump([dataGraphs, LL], f)

    return dataGraphs, LL
