library(ggplot2)

data<-read.csv('data_gaussian.csv')
loessMod05=loess(data$expectation_eps05.1.18.~data$error_eps05.1.18., span=1) 
smoothed05 <- predict(loessMod05)
loessMod1=loess(data$expectation_eps1.1.18.~data$error_eps1.1.18., span=1) 
smoothed1 <- predict(loessMod1)
loessMod2=loess(data$expectation_eps2.1.18.~data$error_eps2.1.18., span=1) 
smoothed2 <- predict(loessMod2)
plot(sort(smoothed05), x=sort(data$error_eps05.1.18.), 'b', pch = 19, xlim=c(2,8), ylim=c(0,70), xlab=expression(paste(log(error^{-1}))),ylab="E[T]")
points(sort(smoothed1),x=sort(data$error_eps1.1.18.),'b',col="red", pch = 19)
points(sort(smoothed2),x=sort(data$error_eps2.1.18.),'b',col="blue", pch = 19)
legend(2,70,bty="n",legend=c(expression(paste(epsilon,"=0.5")),expression(paste(epsilon,"=1")), expression(paste(epsilon,"=2"))),col=c("black","red","blue"),lty=1,cex=1.2)

