import os
import glob
import nltk
import pickle
import random
import itertools
import numpy as np


class Wiki3029Task:

    UNSUP_TRAIN = "unsup_train"
    UNSUP_TEST = "unsup_test"
    UNSUP_TRAIN_PAIR = "unsup_train_pair"
    UNSUP_TEST_PAIR = "unsup_test_pair"
    SUP_TRAIN = "sup_train"
    SUP_TEST = "sup_test"
    MAX_CLASSES = 3029

    def __init__(self, dataset_name, config, logger, ngram, threshold):

        self.ngram = ngram
        self.threshold = threshold
        self.dataset_name = dataset_name
        self.data_path = config["data_path"]
        self.ordered = config["ordered"]
        self.sequential = config["sequential"]

        if config["num_classes"] == -1:
            self.num_classes = Wiki3029Task.MAX_CLASSES
            config["num_classes"] = Wiki3029Task.MAX_CLASSES
        else:
            self.num_classes = config["num_classes"]

        self.class_set = list(range(0, self.num_classes))
        # self.class_prob = float(1.0 / self.num_classes) * np.ones(self.num_classes)
        self.use_class_info = config["use_class_info"]

        logger.log("Created dataset %s with %d many classes and uniform class probability." %
                   (self.dataset_name, self.num_classes))

        self.class_set_except = dict()
        for class_id in range(0, self.num_classes):
            class_ids = list(range(0, self.num_classes))
            class_ids.remove(class_id)                          # Remove class_id from consideration
            self.class_set_except[class_id] = class_ids

        self.dataset = None
        self.suffix = ("" if self.ordered else "_unordered") + ("_sequential" if self.sequential else "")

        if "data_path" in config and os.path.exists("%s/%s%s_dataset.pickle" %
                                                    (config["data_path"], self.dataset_name, self.suffix)):
            logger.log("Loading dataset from file.")
            self.load_dataset(config["data_path"])
            config["vocab_size"] = self.dataset["new_vocab_size"]
            config["max_len"] = self.dataset["max_len"]
        else:
            logger.log("Parsing dataset from scratch")
            self.make_dataset(config, logger)
            self.save_dataset()

        # If num_classes < MAX_CLASS then delete unused classes
        self._trim_data(Wiki3029Task.UNSUP_TRAIN)
        self._trim_data(Wiki3029Task.UNSUP_TEST)
        self._trim_data(Wiki3029Task.UNSUP_TRAIN_PAIR)
        self._trim_data(Wiki3029Task.UNSUP_TEST_PAIR)
        self._trim_data(Wiki3029Task.SUP_TRAIN)
        self._trim_data(Wiki3029Task.SUP_TEST)

        logger.log("Created Wiki-3029 [Ordered: %r, Sequential %r] dataset with %d many classes. "
                   "Vocabulary size: %d and maximum document length: %d." %
                   (self.ordered, self.sequential, self.num_classes, config["vocab_size"], config["max_len"]))

    def make_dataset(self, config, logger):

        if self.sequential:
            self.make_sequential_dataset(config, logger)
        else:
            self.make_bow_dataset(config, logger)

    def make_bow_dataset(self, config, logger):

        fnames = glob.glob("./.data/wn/filtered/*txt")

        try:
            nltk.data.find('tokenizers/punkt')
        except LookupError:
            nltk.download('punkt')

        train_dataset = []
        test_dataset = []

        for class_id, fname in enumerate(fnames):
            lines = open(fname, "r").readlines()
            # Use 20% of the data for testing and remaining for training

            if self.ordered:
                # Train is the first 80% and test is the last 20%
                num_train_lines = int(0.8 * len(lines))
                train_lines, test_lines = lines[:num_train_lines], lines[num_train_lines:]
            else:
                # Train and test are randomly chosen 20%
                num_lines = len(lines)
                all_space = set(range(num_lines))
                train_ixs = set(random.sample(all_space, int(0.8 * num_lines)))
                test_ixs = all_space - train_ixs

                train_lines = [lines[ix] for ix in train_ixs]
                test_lines = [lines[ix] for ix in test_ixs]

            for train_line in train_lines:
                token_seq = nltk.word_tokenize(train_line.strip())
                train_dataset.append((class_id, token_seq))

            for test_line in test_lines:
                token_seq = nltk.word_tokenize(test_line.strip())
                test_dataset.append((class_id, token_seq))

        random.shuffle(train_dataset)
        random.shuffle(test_dataset)

        token_count = dict()
        for dp in train_dataset:
            for token in dp[1]:
                if token not in token_count:
                    token_count[token] = 1
                else:
                    token_count[token] += 1

        old_vocab_size = len(token_count)

        token_to_id_map = dict()
        token_id = 0
        for token, count in token_count.items():

            if count >= self.threshold:
                token_to_id_map[token] = token_id
                token_id += 1

        unk_token_id = token_id
        new_vocab_size = token_id + 1       # + 1 for unk_token_id

        logger.log("Size of original vocabulary is %d, size of filtered vocabulary including only tokens with at least "
                   "%d frequency plus UNK token is %d" % (old_vocab_size, self.threshold, new_vocab_size))

        # Change dataset from old token_ids to new_token_ids
        self.change_to_token_ids(train_dataset, token_to_id_map, unk_token_id)
        self.change_to_token_ids(test_dataset, token_to_id_map, unk_token_id)

        self.print_dataset_stats(train_dataset, test_dataset, logger)

        # Create split data
        train_dataset1, train_dataset2 = self.split_data(train_dataset)

        # Remove duplicate elements and create count values
        filtered_train_dataset1, max_len_train1 = self.remove_duplicates(train_dataset1)
        filtered_train_dataset2, max_len_train2 = self.remove_duplicates(train_dataset2)
        filtered_train_dataset, max_len_train = self.remove_duplicates(train_dataset)
        filtered_test_dataset, max_len_test = self.remove_duplicates(test_dataset)
        max_len = max(max_len_train1, max_len_train2, max_len_train, max_len_test)
        logger.log("Maximum length of a input sequence after removing duplicates is %d" % max_len)

        # Finally, do padding to max_len and update count values
        padded_normalized_train_dataset = self.pad_and_normalize(filtered_train_dataset, max_len)
        padded_normalized_test_dataset = self.pad_and_normalize(filtered_test_dataset, max_len)
        padded_normalized_train_pair_dataset = self.pad_and_normalize_pairs(filtered_train_dataset1,
                                                                            filtered_train_dataset2, max_len)

        # Dataset for NCE
        unsup_train_dataset = dict()
        unsup_test_dataset = dict()

        for class_id, train_data in padded_normalized_train_dataset.items():
            train_data_size = len(train_data)
            nce_train_size = int(0.8 * train_data_size)
            unsup_train_dataset[class_id] = train_data[:nce_train_size]
            unsup_test_dataset[class_id] = train_data[nce_train_size:]

        unsup_train_pair_dataset = dict()
        unsup_test_pair_dataset = dict()

        for class_id, train_data in padded_normalized_train_pair_dataset.items():
            train_data_size = len(train_data)
            nce_train_size = int(0.8 * train_data_size)
            unsup_train_pair_dataset[class_id] = train_data[:nce_train_size]
            unsup_test_pair_dataset[class_id] = train_data[nce_train_size:]

        # Set/Update config files
        config["vocab_size"] = new_vocab_size
        config["max_len"] = max_len

        # TODO: make the save more memory efficient.
        self.dataset = {
            "new_vocab_size": new_vocab_size,
            "max_len": max_len,
            "unsup_train": unsup_train_dataset,
            "unsup_test": unsup_test_dataset,
            "unsup_train_pair": unsup_train_pair_dataset,
            "unsup_test_pair": unsup_test_pair_dataset,
            "sup_train": padded_normalized_train_dataset,
            "sup_test": padded_normalized_test_dataset
        }

    def make_sequential_dataset(self, config, logger):

        fnames = glob.glob("./.data/wn/filtered/*txt")

        try:
            nltk.data.find('tokenizers/punkt')
        except LookupError:
            nltk.download('punkt')

        train_dataset = []
        test_dataset = []

        for class_id, fname in enumerate(fnames):

            lines = open(fname, "r").readlines()
            # Use 20% of the data for testing and remaining for training
            if self.ordered:
                # Train is the first 80% and test is the last 20%
                num_train_lines = int(0.8 * len(lines))
                train_lines, test_lines = lines[:num_train_lines], lines[num_train_lines:]
            else:
                # Train and test are randomly chosen 20%
                num_lines = len(lines)
                all_space = set(range(num_lines))
                train_ixs = set(random.sample(all_space, int(0.8 * num_lines)))
                test_ixs = all_space - train_ixs

                train_lines = [lines[ix] for ix in train_ixs]
                test_lines = [lines[ix] for ix in test_ixs]

            for train_line in train_lines:
                token_seq = nltk.word_tokenize(train_line.strip().lower())
                train_dataset.append((class_id, token_seq))

            for test_line in test_lines:
                token_seq = nltk.word_tokenize(test_line.strip().lower())
                test_dataset.append((class_id, token_seq))

        random.shuffle(train_dataset)
        random.shuffle(test_dataset)

        token_count = dict()
        for dp in train_dataset:
            for token in dp[1]:
                if token not in token_count:
                    token_count[token] = 1
                else:
                    token_count[token] += 1

        old_vocab_size = len(token_count)

        token_to_id_map = dict()
        id_to_token_map = dict()
        token_id = 0
        for token, count in token_count.items():

            if count >= self.threshold:
                token_to_id_map[token] = token_id
                id_to_token_map[token_id] = token
                token_id += 1

        unk_token_id = token_id
        new_vocab_size = token_id + 1       # + 1 for unk_token_id

        logger.log("Size of original vocabulary is %d, size of filtered vocabulary including only tokens with at least "
                   "%d frequency plus UNK token is %d" % (old_vocab_size, self.threshold, new_vocab_size))

        # Change dataset from old token_ids to new_token_ids
        self.change_to_token_ids(train_dataset, token_to_id_map, unk_token_id)
        self.change_to_token_ids(test_dataset, token_to_id_map, unk_token_id)

        self.print_dataset_stats(train_dataset, test_dataset, logger)

        # Create datasets
        sup_train_dataset = {class_id: [] for class_id in range(self.MAX_CLASSES)}
        sup_test_dataset = {class_id: [] for class_id in range(self.MAX_CLASSES)}

        for class_id, token_seq in train_dataset:
            sup_train_dataset[class_id].append(token_seq)

        for class_id, token_seq in test_dataset:
            sup_test_dataset[class_id].append(token_seq)

        max_len = max([len(dp[1]) for dp in itertools.chain(train_dataset, test_dataset)])

        unsup_train_dataset = {class_id: [] for class_id in range(self.MAX_CLASSES)}
        unsup_test_dataset = {class_id: [] for class_id in range(self.MAX_CLASSES)}

        for class_id in sup_train_dataset:
            train_only_size = int(0.8 * len(sup_train_dataset[class_id]))
            unsup_train_dataset[class_id] = sup_train_dataset[class_id][:train_only_size]
            unsup_test_dataset[class_id] = sup_train_dataset[class_id][train_only_size:]

        unsup_train_pair_dataset = {class_id: [] for class_id in range(self.MAX_CLASSES)}
        unsup_test_pair_dataset = {class_id: [] for class_id in range(self.MAX_CLASSES)}

        for class_id, token_seqs in unsup_train_dataset.items():
            for token_seq in token_seqs:
                token_seq_len = len(token_seq)
                if token_seq_len <= 1:
                    continue
                mid = token_seq_len // 2
                unsup_train_pair_dataset[class_id].append((token_seq[:mid], token_seq[mid:]))

        for class_id, token_seqs in unsup_test_dataset.items():
            for token_seq in token_seqs:
                token_seq_len = len(token_seq)
                if token_seq_len <= 1:
                    continue
                mid = token_seq_len // 2
                unsup_test_pair_dataset[class_id].append((token_seq[:mid], token_seq[mid:]))

        # Set/Update config files
        config["vocab_size"] = new_vocab_size
        config["max_len"] = max_len

        # TODO: make the save more memory efficient.
        self.dataset = {
            "new_vocab_size": new_vocab_size,
            "max_len": max_len,
            "id_to_token_map": id_to_token_map,
            "token_to_id_map": token_to_id_map,
            "unsup_train": unsup_train_dataset,
            "unsup_test": unsup_test_dataset,
            "unsup_train_pair": unsup_train_pair_dataset,
            "unsup_test_pair": unsup_test_pair_dataset,
            "sup_train": sup_train_dataset,
            "sup_test": sup_test_dataset
        }

    def _trim_data(self, data_type):

        for class_id in range(self.num_classes, Wiki3029Task.MAX_CLASSES):
            if class_id in self.dataset[data_type]:
                del self.dataset[data_type][class_id]

        assert len(self.dataset[data_type]) == self.num_classes, \
            "Could not guarantee %d many classes after trimming" % self.num_classes

    def get_num_class(self):
        return self.num_classes

    def sample_class(self):
        # TODO generalize to using class probabilities
        return random.choice(self.class_set)

    def sample_class_except(self, class_except):
        return random.choice(self.class_set_except[class_except])

    def sample_from_class(self, latent_class, data_type, return_class=False):
        x = random.choice(self.dataset[data_type][latent_class])

        if data_type == Wiki3029Task.UNSUP_TRAIN_PAIR or data_type == Wiki3029Task.UNSUP_TEST_PAIR:

            i = random.randint(0, 1)

            if return_class and self.sequential:
                return x[i], latent_class

            elif return_class and not self.sequential:
                return x[2 * i], x[2 * i + 1], latent_class

            else:
                return x

        else:
            if return_class and self.sequential:
                return x, latent_class

            elif return_class and not self.sequential:
                return x[0], x[1], latent_class

            else:
                return x

    def sample(self, data_type, return_class=False):
        sampled_class = self.sample_class()
        return self.sample_from_class(sampled_class, data_type, return_class)

    def sample_except(self, class_except, data_type, return_class=False):
        sampled_class = self.sample_class_except(class_except)
        return self.sample_from_class(sampled_class, data_type, return_class)

    def sample_pairs(self, data_type, return_class=False):

        if data_type != Wiki3029Task.UNSUP_TRAIN_PAIR and data_type != Wiki3029Task.UNSUP_TEST_PAIR:
            raise AssertionError("Cannot sample pairwise data from a non-pairwise dataset %s" % data_type)

        latent_class = self.sample_class()
        x = random.choice(self.dataset[data_type][latent_class])

        if return_class and self.sequential:
            return x[0], x[1], latent_class

        elif return_class and not self.sequential:
            return x[0], x[1], x[2], x[3], latent_class

        else:
            return x

    def get_paired_dataset(self, data_types):

        data_types = data_types.split("+")

        all_data = []
        single_data = dict()

        for data_type in data_types:

            for class_id, samples in self.dataset[data_type].items():

                if data_type == "unsup_train_pair" or data_type == "unsup_test_pair":
                    # Already a paired dataset so add to all_data
                    for sample in samples:
                        all_data.append((sample[0], sample[1], sample[2], sample[3], class_id))

                else:

                    if class_id not in single_data:
                        single_data[class_id] = []

                    # Single data item so add to single_data
                    for sample in samples:
                        single_data[class_id].append(sample)

        # Straighten and shuffle all_data
        for class_id, samples in single_data.items():

            # Shuffle it a few times
            for _ in range(10):
                random.shuffle(samples)

            it = zip(samples[0::2], samples[1::2])
            for pair in it:
                if self.sequential:
                    all_data.append(pair)
                else:
                    all_data.append((pair[0][0], pair[0][1], pair[1][0], pair[1][1], class_id))

        # Shuffle it a few times
        for _ in range(10):
            random.shuffle(all_data)

        return all_data

    @staticmethod
    def print_dataset_stats(train_dataset, test_dataset, logger):

        logger.log("Max len is %d" % max([len(dp[1]) for dp in itertools.chain(train_dataset, test_dataset)]))
        logger.log("Max token id is %d" % max([max(dp[1]) for dp in itertools.chain(train_dataset, test_dataset)]))

    @staticmethod
    def remove_duplicates(dataset):

        filtered_data = []
        max_len = 0

        for dp in dataset:
            label, token_seq = dp

            unique_tokens = []
            count = dict()
            size = 0

            for tk in token_seq:

                if tk in count:
                    count[tk] += 1
                else:
                    unique_tokens.append(tk)
                    count[tk] = 1
                    size += 1

            unique_token_counts = [count[tk] for tk in unique_tokens]
            max_len = max(max_len, size)

            filtered_data.append((label, unique_tokens, unique_token_counts))

        return filtered_data, max_len

    @staticmethod
    def split_data(dataset):

        split1, split2 = [], []

        for dp in dataset:
            label, token_seq = dp
            token_seq_len = len(token_seq)

            if token_seq_len <= 1:
                continue

            mid = token_seq_len // 2
            split1.append((label, token_seq[:mid]))
            split2.append((label, token_seq[mid:]))

        return split1, split2

    def pad_and_normalize_pairs(self, filtered_train_data1, filtered_train_data2, max_len):

        dataset_size = len(filtered_train_data1)
        assert dataset_size == len(filtered_train_data2)

        padded_normalized_pair_dataset = dict()
        for class_id in range(0, Wiki3029Task.MAX_CLASSES):
            padded_normalized_pair_dataset[class_id] = []

        for ix in range(0, dataset_size):
            label1, tokens1, counts1 = filtered_train_data1[ix]
            label2, tokens2, counts2 = filtered_train_data2[ix]
            assert label1 == label2

            tokens1, counts1 = self.pad_normalize_tokens_counts(tokens1, counts1, max_len)
            tokens2, counts2 = self.pad_normalize_tokens_counts(tokens2, counts2, max_len)

            padded_normalized_pair_dataset[label1].append((tokens1, counts1, tokens2, counts2))

        return padded_normalized_pair_dataset

    def pad_and_normalize(self, filtered_data, max_len):

        dataset_size = len(filtered_data)
        padded_normalized_dataset = dict()
        for class_id in range(0, Wiki3029Task.MAX_CLASSES):
            padded_normalized_dataset[class_id] = []

        for ix in range(0, dataset_size):

            label, tokens, counts = filtered_data[ix]
            tokens, counts = self.pad_normalize_tokens_counts(tokens, counts, max_len)

            padded_normalized_dataset[label].append((tokens, counts))

        return padded_normalized_dataset

    @staticmethod
    def change_to_token_ids(dataset, token_to_id_map, unk_token_id):

        for dp in dataset:
            _, token_seq = dp

            for ix, tk in enumerate(token_seq):

                if tk in token_to_id_map:
                    token_seq[ix] = token_to_id_map[tk]
                else:
                    token_seq[ix] = unk_token_id

    @staticmethod
    def pad_normalize_tokens_counts(tokens, counts, max_len):

        token_len = len(tokens)
        if token_len < max_len:
            tokens = np.array(tokens + [0] * (max_len - token_len)).astype(np.int32)
            counts = np.array(counts + [0.0] * (max_len - token_len)).astype(np.float32)
        elif token_len == max_len:
            tokens = np.array(tokens).astype(np.int32)
            counts = np.array(counts).astype(np.float32)
        else:
            raise AssertionError("Token length %d is strictly greater than max length %d" % (token_len, max_len))

        counts = counts / max(1.0, counts.sum())

        return tokens, counts

    def get_dataset(self, data_type):

        if data_type != "sup_train" and data_type != "sup_test":
            raise AssertionError("Data type not supported. Has to be sup_train or sup_test")

        chosen_dataset = []

        for class_id, datapoints in self.dataset[data_type].items():

            for datapoint in datapoints:
                if self.sequential:
                    chosen_dataset.append((datapoint, class_id))
                else:
                    chosen_dataset.append((datapoint[0], datapoint[1], class_id))

        return chosen_dataset

    def get_dataset_for_class(self, data_type, class_id):

        if data_type != "sup_train" and data_type != "sup_test":
            raise AssertionError("Data type not supported. Has to be sup_train or sup_test")

        return self.dataset[data_type][class_id]

    def save_dataset(self):

        if not os.path.isdir(self.data_path):
            os.makedirs(self.data_path)

        with open("%s/%s%s_dataset.pickle" % (self.data_path, self.dataset_name, self.suffix), "wb") as f:
            pickle.dump(self.dataset, f)

    def load_dataset(self, data_path):

        with open("%s/%s%s_dataset.pickle" % (data_path, self.dataset_name, self.suffix), "rb") as f:
            self.dataset = pickle.load(f)
