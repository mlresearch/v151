

import matplotlib
import matplotlib.pyplot as plt
import numpy as np

import pickle

import sys
sys.path.append("..")

from util.file_IO import file_IO
from util.file_IO import file_IO0
from util.file_IO import file_IO1
from util.file_IO import file_IO2

def plot_sample_complexity(chern_sample_complexity, bchern_sample_complexity, bchern1_sample_complexity, bchern2_sample_complexity, rand_sample_complexity, top2_sample_complexity, njav_sample_complexity, chern_e_sample_complexity, num_sources, num_hypo, filename):
    


    A = np.sum(chern_sample_complexity,axis = 1)
    B = np.sum(top2_sample_complexity,axis = 1)
    C = np.sum(rand_sample_complexity,axis = 1)
    D = np.sum(njav_sample_complexity,axis = 1)
    
    E = np.sum(bchern_sample_complexity,axis = 1)
    F = np.sum(bchern1_sample_complexity,axis = 1)
    G = np.sum(bchern2_sample_complexity,axis = 1)
    H = np.sum(chern_e_sample_complexity,axis = 1)
    
    data_a = [A]
    data_b = [B]
    data_c = [C]
    data_d = [D]
    
    data_e = [E]
    data_f = [F]
    data_g = [G]
    data_h = [H]
    
    #ticks = ['Chern']
    #ticks = ['Gen-Chern', '   Top2', 'Unif', '      Two-Phase']
    #ticks = ['GC', '   T2', 'U', '      TP']
    ticks = ['CS', 'T2', 'U', 'TP', 'B1', 'B2', 'B3', 'CSE']
    
    def set_box_color(bp, color):
        plt.setp(bp['boxes'], facecolor = color, edgecolor='black', linewidth=1.2)
        plt.setp(bp['whiskers'], color=color)
        plt.setp(bp['caps'], color=color)
        plt.setp(bp['medians'], color='black', linewidth=2)
        plt.setp(bp["fliers"], markerfacecolor = color, markeredgecolor='black')
        plt.setp(bp["means"], markerfacecolor = 'green', markeredgecolor='black', markersize = 15.0)
    
    
    
    plt.style.use('ggplot')
    plt.figure(dpi=600)

    

    plt.figure()
    
    bpa = plt.boxplot(data_a, positions=np.array(range(len(data_a)))*1.0, notch = False, vert = True, patch_artist=True, widths=1.6, showmeans=True, showfliers=True)
    bpb = plt.boxplot(data_b, positions=np.array(range(len(data_b)))*1.0+3.0, notch = False, vert = True, patch_artist=True, widths=1.6, showmeans=True, showfliers=True)
    bpc = plt.boxplot(data_c, positions=np.array(range(len(data_c)))*1.0+6.0, notch = False, vert = True, patch_artist=True, widths=1.6, showmeans=True, showfliers=True)
    bpd = plt.boxplot(data_d, positions=np.array(range(len(data_d)))*1.0+9.0, notch = False, vert = True, patch_artist=True, widths=1.6, showmeans=True, showfliers=True)
    
    bpe = plt.boxplot(data_e, positions=np.array(range(len(data_e)))*1.0+12.0, notch = False, vert = True, patch_artist=True, widths=1.6, showmeans=True, showfliers=True)
    bpf = plt.boxplot(data_f, positions=np.array(range(len(data_f)))*1.0+15.0, notch = False, vert = True, patch_artist=True, widths=1.6, showmeans=True, showfliers=True)
    bpg = plt.boxplot(data_g, positions=np.array(range(len(data_g)))*1.0+18.0, notch = False, vert = True, patch_artist=True, widths=1.6, showmeans=True, showfliers=True)
    bph = plt.boxplot(data_h, positions=np.array(range(len(data_h)))*1.0+21.0, notch = False, vert = True, patch_artist=True, widths=1.6, showmeans=True, showfliers=True)
     
    set_box_color(bpa, '#D55E00') # colors are from http://colorbrewer2.org/
    set_box_color(bpb, '#E69F00')
    set_box_color(bpc, '#0072B2')
    set_box_color(bpd, '#009E73')
      
    set_box_color(bpe, '#3F3512')
    set_box_color(bpf, '#AF3512')
    set_box_color(bpg, '#FCCB16')
    set_box_color(bph, '#CC79A7')
    
    # draw temporary red and blue lines and use them to create a legend
    #plt.plot([], c='#D7191C', label='Apples')
    #plt.plot([], c='#2C7BB6', label='Oranges')
    #plt.legend()
    '''
    plt.title('{0} Arms, {1} Discretized Parameters'.format(num_sources, num_hypo))
    plt.ylabel('Average Sample Complexity')
    plt.xlabel('Algorithms')
    plt.xticks(range(0, len(ticks) * 2, 2), ticks)
    plt.xlim(-2, len(ticks)*2)
    #
    #plt.ylim(0, 150)
    plt.tight_layout()
    plt.savefig('../plots/boxcompare_'+filename+'.png')
    #plt.show()
    '''
    plt.title('{0} Arms, {1} Discretized Parameters'.format(num_sources, num_hypo), size = 20, fontweight='bold', pad=20)
    
    plt.ylabel('Average Sample Complexity', size = 18, fontweight='bold')
    #plt.xlabel('Algorithms', size = 16)
    
    plt.yticks(size = 19, fontweight='bold')
    
    #plt.yticks(range(0, 6), size = 16)
    plt.xticks(range(0, len(ticks) * 3, 3), ticks, size = 18, fontweight='bold')
    #plt.xticks(size = 18, fontweight='bold')
    plt.xlim(-2, len(ticks)*3)
    #plt.ylim(0, 0.8e2)
    #plt.ylim(0, .65e3)
    plt.ylim(0, 0.7e2)
    plt.ticklabel_format(axis='y', style='sci', scilimits=(0,0))
    #plt.yticks(fontsize=24)
    
    ax = plt.gca()
    ax.yaxis.get_offset_text().set_fontsize(18)
    
    plt.tight_layout()
    plt.savefig('../plots/boxcompare_'+filename+'.png', bbox_inches='tight', pad_inches=0)
    
    
def plot_sample_complexity01(mm_T, u_T, total_arm_selection, num_sources, num_dims, filename):
 
    A = total_arm_selection
    #B = np.sum(total_arm_count_XY_static,axis = 1)
    #C = np.sum(mm_sample_complexity,axis = 1)
    #D = np.sum(unif_sample_complexity,axis = 1)
    C = mm_T
    D = u_T
    #E = np.sum(total_arm_selection_A_XY,axis = 1)
    
    #print(mm_T)
    
    #data_a = [A, B, C]
    data_a = [A]
    #data_b = [B]
    data_c = [C]
    data_d = [D]
    #data_e = [E]
    
    #ticks = ['LinGapE', 'XY-static', 'Max-min', 'Unif', 'XY-adaptive']
    ticks = ['LinGapE', 'Gen-Chern', 'Unif']
    
    #ticks = ['LinGapE', 'XY-static', 'Max-min', 'Unif',]
    #ticks = ['Max-min', 'Unif',]
             
    def set_box_color(bp, color):
        plt.setp(bp['boxes'], facecolor = color, edgecolor='black', linewidth=1.2)
        plt.setp(bp['whiskers'], color=color)
        plt.setp(bp['caps'], color=color)
        plt.setp(bp['medians'], color='black', linewidth=2)
        plt.setp(bp["fliers"], markerfacecolor = color, markeredgecolor='black')
        plt.setp(bp["means"], markerfacecolor = 'green', markeredgecolor='black')
    
    #meanprops = dict(color="black")
    
    plt.style.use('ggplot')
    plt.figure(dpi=600)
    
    plt.figure()
    
    
    bpa = plt.boxplot(data_a, positions=np.array(range(len(data_a)))*2.0 , notch = False, vert = True, patch_artist=True, widths=0.6, showmeans=True, showfliers=True)
    #bpb = plt.boxplot(data_b, positions=np.array(range(len(data_b)))*2.0+2.0, sym='', widths=0.6, )
    bpc = plt.boxplot(data_c, positions=np.array(range(len(data_c)))*2.0+2.0, notch = False, vert = True, patch_artist=True, widths=0.6, showmeans=True, showfliers=True)
    bpd = plt.boxplot(data_d, positions=np.array(range(len(data_d)))*2.0+4.0, notch = False,vert = True, patch_artist=True, widths=0.6, showmeans=True, showfliers=True)
    #bpe = plt.boxplot(data_e, positions=np.array(range(len(data_e)))*2.0+8.0, sym='', widths=0.6)
    
    set_box_color(bpa, '#D7191C') # colors are from http://colorbrewer2.org/
    #set_box_color(bpb, '#2C7BB6')
    set_box_color(bpc, '#FB7DD6')
    set_box_color(bpd, '#CB7116')
    #set_box_color(bpe, '#BB1196')
    
    # draw temporary red and blue lines and use them to create a legend
    #plt.plot([], c='#D7191C', label='Apples')
    #plt.plot([], c='#2C7BB6', label='Oranges')
    #plt.legend()
    #lim = (1_000_000, 1_000_010)
    
    #ax = plt.axis([0, 1, 1.0 * np.min(data_a), 1.0 * np.max(data_c)])
    #ax = plt.axes()
    #ax.set_yscale('log')
    
    #ax.get_xaxis().get_major_formatter().set_useOffset(True)
    #plt.rc('font', size=12)
    
    #plt.tick_params(axis='y', labelsize = 'large')
    #plt.tick_params(direction='out', length=6, width=2, colors='r', labelsize = 'large', grid_color='r', grid_alpha=0.5)
    
    
    
    plt.title('{0} Arms, {1} Dimension'.format(num_sources,num_dims), size = 20, fontweight='bold')
    plt.ylabel('Average Sample Complexity', size = 18, fontweight='bold')
    #plt.xlabel('Algorithms', size = 16)
    
    plt.yticks(size = 19, fontweight='bold')
    
    #plt.yticks(range(0, 6), size = 16)
    plt.xticks(range(0, len(ticks) * 2, 2), ticks, size = 18, fontweight='bold')
    #plt.xticks(size = 18, fontweight='bold')
    plt.xlim(-2, len(ticks)*2)
    #plt.ylim(0, 8000)
    plt.ticklabel_format(axis='y', style='sci', scilimits=(0,0))
    #plt.yticks(fontsize=24)
    
    plt.tight_layout()
    plt.savefig('../plots/boxcompare_'+filename+'.png')
    
def plot_sample_complexity0(mm_T, u_T, total_arm_selection, num_sources, num_dims, filename):
 
    A = total_arm_selection
    #B = np.sum(total_arm_count_XY_static,axis = 1)
    #C = np.sum(mm_sample_complexity,axis = 1)
    #D = np.sum(unif_sample_complexity,axis = 1)
    C = mm_T
    D = u_T
    #E = np.sum(total_arm_selection_A_XY,axis = 1)
    
    #print(mm_T)
    
    #data_a = [A, B, C]
    data_a = [A]
    #data_b = [B]
    data_c = [C]
    data_d = [D]
    #data_e = [E]
    
    
    #ticks = ['LinGapE', 'XY-static', 'Max-min', 'Unif', 'XY-adaptive']
    ticks = ['LinGapE', 'Gen-Chern', 'Unif']
    
    #ticks = ['LinGapE', 'XY-static', 'Max-min', 'Unif',]
    #ticks = ['Max-min', 'Unif',]
    
   
     
    def set_box_color(bp, color):
        plt.setp(bp['boxes'], facecolor = color, edgecolor='black', linewidth=1.2)
        plt.setp(bp['whiskers'], color=color)
        plt.setp(bp['caps'], color=color)
        plt.setp(bp['medians'], color='black', linewidth=2)
        plt.setp(bp["fliers"], markerfacecolor = color, markeredgecolor='black')
        plt.setp(bp["means"], markerfacecolor = 'green', markeredgecolor='black')
    
    #meanprops = dict(color="black")
    
    plt.style.use('ggplot')
    plt.figure(dpi=600)
    
    plt.figure()
    
    
    bpa = plt.boxplot(data_a, positions=np.array(range(len(data_a)))*2.0 , notch = False, vert = True, patch_artist=True, widths=0.6, showmeans=True, showfliers=True)
    #bpb = plt.boxplot(data_b, positions=np.array(range(len(data_b)))*2.0+2.0, sym='', widths=0.6, )
    bpc = plt.boxplot(data_c, positions=np.array(range(len(data_c)))*2.0+2.0, notch = False, vert = True, patch_artist=True, widths=0.6, showmeans=True, showfliers=True)
    bpd = plt.boxplot(data_d, positions=np.array(range(len(data_d)))*2.0+4.0, notch = False,vert = True, patch_artist=True, widths=0.6, showmeans=True, showfliers=True)
    #bpe = plt.boxplot(data_e, positions=np.array(range(len(data_e)))*2.0+8.0, sym='', widths=0.6)
    
    set_box_color(bpa, '#D7191C') # colors are from http://colorbrewer2.org/
    #set_box_color(bpb, '#2C7BB6')
    set_box_color(bpc, '#FB7DD6')
    set_box_color(bpd, '#CB7116')
    
    
    
    plt.title('{0} Arms, {1} Dimension'.format(num_sources,num_dims), size = 20, fontweight='bold')
    plt.ylabel('Average Sample Complexity', size = 18, fontweight='bold')
    #plt.xlabel('Algorithms', size = 16)
    
    plt.yticks(size = 19, fontweight='bold')
    
    #plt.yticks(range(0, 6), size = 16)
    plt.xticks(range(0, len(ticks) * 2, 2), ticks, size = 18, fontweight='bold')
    #plt.xticks(size = 18, fontweight='bold')
    plt.xlim(-2, len(ticks)*2)
    #plt.ylim(0, 8000)
    plt.ticklabel_format(axis='y', style='sci', scilimits=(0,0))
    #plt.yticks(fontsize=24)
    
    ax = plt.gca()
    ax.yaxis.get_offset_text().set_fontsize(18)
    
    plt.tight_layout()
    plt.savefig('../plots/boxcompare_'+filename+'.png')


def plot_sample_complexity1(mm_T, u_T, total_arm_selection, total_arm_selection_xy_oracle, num_sources, num_dims, filename):
    
    A = total_arm_selection
    #B = np.sum(total_arm_count_XY_static,axis = 1)
    #C = np.sum(mm_sample_complexity,axis = 1)
    #D = np.sum(unif_sample_complexity,axis = 1)
    C = mm_T
    D = u_T
    #E = np.sum(total_arm_selection_A_XY,axis = 1)
    #F = total_arm_selection_xy_oracle
    #print(mm_T)
    
    #data_a = [A, B, C]
    data_a = [A]
    #data_b = [B]
    data_c = [C]
    data_d = [D]
    #data_e = [E]
    
    #ticks = ['LinGapE', 'XY-static', 'Max-min', 'Unif', 'XY-adaptive']
    #ticks = ['LinGapE', 'Gen-Chern', 'Unif']
    ticks = ['LG', 'GC', 'U']
    #ticks = ['LinGapE', 'XY-static', 'Max-min', 'Unif',]
    #ticks = ['Max-min', 'Unif',]
             
    def set_box_color(bp, color):
        plt.setp(bp['boxes'], facecolor = color, edgecolor='black', linewidth=1.2)
        plt.setp(bp['whiskers'], color=color)
        plt.setp(bp['caps'], color=color)
        plt.setp(bp['medians'], color='black', linewidth=2)
        plt.setp(bp["fliers"], markerfacecolor = color, markeredgecolor='black')
        plt.setp(bp["means"], markerfacecolor = 'green', markeredgecolor='black', markersize = 15.0)
    
    #meanprops = dict(color="black")
    #plt.plot([np.sum(total_arm_selection_xy_oracle[0]) for i in range(0,50)],np.linspace(0,100,50),'--')
    #plt.axhline(y=np.sum(total_arm_selection_xy_oracle[0]))
    
    
    plt.style.use('ggplot')
    plt.figure(dpi=600)
    
    plt.figure()
    
    
    bpa = plt.boxplot(data_a, positions=np.array(range(len(data_a)))*2.0 , notch = False, vert = True, patch_artist=True, widths=1.6, showmeans=True, showfliers=True)
    #bpb = plt.boxplot(data_b, positions=np.array(range(len(data_b)))*2.0+2.0, sym='', widths=0.6, )
    bpc = plt.boxplot(data_c, positions=np.array(range(len(data_c)))*2.0+2.0, notch = False, vert = True, patch_artist=True, widths=1.6, showmeans=True, showfliers=True)
    bpd = plt.boxplot(data_d, positions=np.array(range(len(data_d)))*2.0+4.0, notch = False,vert = True, patch_artist=True, widths=1.6, showmeans=True, showfliers=True)
    #bpe = plt.boxplot(data_e, positions=np.array(range(len(data_e)))*2.0+8.0, sym='', widths=0.6)
    
    set_box_color(bpa, '#D7191C') # colors are from http://colorbrewer2.org/
    #set_box_color(bpb, '#2C7BB6')
    set_box_color(bpc, '#FB7DD6')
    set_box_color(bpd, '#CB7116')
    #set_box_color(bpe, '#BB1196')
    
    # draw temporary red and blue lines and use them to create a legend
    #plt.plot([], c='#D7191C', label='Apples')
    #plt.plot([], c='#2C7BB6', label='Oranges')
    #plt.legend()
    
    plt.axhline(y=np.sum(total_arm_selection_xy_oracle[0]), linestyle = '--', color = 'g', label='XY-Oracle', linewidth = 2.0)
    
    
    plt.title('{0} Arms, {1} Dimension'.format(num_sources,num_dims), size = 20, fontweight='bold')
    plt.ylabel('Average Sample Complexity', size = 18, fontweight='bold')
    #plt.xlabel('Algorithms', size = 16)
    
    plt.yticks(size = 19, fontweight='bold')
    
    #plt.yticks(range(0, 6), size = 16)
    plt.xticks(range(0, len(ticks) * 2, 2), ticks, size = 18, fontweight='bold')
    #plt.xticks(size = 18, fontweight='bold')
    plt.xlim(-2, len(ticks)*2)
    #plt.ylim(0, 8000)
    plt.ticklabel_format(axis='y', style='sci', scilimits=(0,0))
    #plt.yticks(fontsize=24)
    plt.legend(fontsize = 18)
    
    ax = plt.gca()
    ax.yaxis.get_offset_text().set_fontsize(18)
    
    plt.tight_layout()
    plt.savefig('../plots/boxcompare_'+filename+'.png', bbox_inches='tight', pad_inches=0)


def plot_sample_complexity2(mm_T, u_T, total_arm_selection, total_arm_selection_xys, total_arm_selection_xya, num_sources, num_dims, filename):
 
    A = total_arm_selection
    B = total_arm_selection_xys
    C = total_arm_selection_xya
    #D = np.sum(unif_sample_complexity,axis = 1)
    D = mm_T
    E = u_T
    #E = np.sum(total_arm_selection_A_XY,axis = 1)
    
    #print(mm_T)
    
    #data_a = [A, B, C]
    data_a = [A]
    data_b = [B]
    data_c = [C]
    data_d = [D]
    data_e = [E]
    
    ticks = ['LinGapE', 'XY-static', 'XY-adaptive', 'Max-min', 'Unif']
    #ticks = ['LinGapE', 'Max-min', 'Unif']
    #ticks = ['LinGapE', 'XY-static', 'Max-min', 'Unif',]
    #ticks = ['Max-min', 'Unif',]
             
    def set_box_color(bp, color):
        plt.setp(bp['boxes'], facecolor = color, edgecolor='black', linewidth=1.2)
        plt.setp(bp['whiskers'], color=color)
        plt.setp(bp['caps'], color=color)
        plt.setp(bp['medians'], color='black', linewidth=2)
        plt.setp(bp["fliers"], markerfacecolor = color, markeredgecolor='black')
        plt.setp(bp["means"], markerfacecolor = 'green', markeredgecolor='black')
    
    #meanprops = dict(color="black")
    
    plt.style.use('ggplot')
    plt.figure(dpi=600)
    
    plt.figure()
    
    
    bpa = plt.boxplot(data_a, positions=np.array(range(len(data_a)))*2.0 , notch = False, vert = True, patch_artist=True, widths=0.6, showmeans=True, showfliers=True)
    bpb = plt.boxplot(data_b, positions=np.array(range(len(data_b)))*2.0+2.0, notch = False, vert = True, patch_artist=True, widths=0.6, showmeans=True, showfliers=True)
    
    bpc = plt.boxplot(data_c, positions=np.array(range(len(data_c)))*2.0+4.0, notch = False, vert = True, patch_artist=True, widths=0.6, showmeans=True, showfliers=True)
    bpd = plt.boxplot(data_d, positions=np.array(range(len(data_d)))*2.0+6.0, notch = False,vert = True, patch_artist=True, widths=0.6, showmeans=True, showfliers=True)
    bpe = plt.boxplot(data_e, positions=np.array(range(len(data_e)))*2.0+8.0, notch = False, vert = True, patch_artist=True, widths=0.6, showmeans=True, showfliers=True)
    
    set_box_color(bpa, '#D7191C') # colors are from http://colorbrewer2.org/
    set_box_color(bpb, '#2C7BB6')
    set_box_color(bpc, '#FB7DD6')
    set_box_color(bpd, '#CB7116')
    set_box_color(bpe, '#BB1196')
    
    # draw temporary red and blue lines and use them to create a legend
    #plt.plot([], c='#D7191C', label='Apples')
    #plt.plot([], c='#2C7BB6', label='Oranges')
    #plt.legend()
    
    

    #fig, (ax1, ax2, ax3) = plt.subplots(3, 1, gridspec_kw={'hspace': 2})
    #ax1.set(title='offset_notation', xlim=lim)
    
    plt.title('{0} Arms, {1} Dimension'.format(num_sources,num_dims))
    plt.ylabel('Average Sample Complexity')
    plt.xlabel('Algorithms')
    plt.xticks(range(0, len(ticks) * 2, 2), ticks)
    plt.xlim(-2, len(ticks)*2)
    #plt.ylim(0, 8000)
    plt.tight_layout()
    plt.savefig('../plots/boxcompare_'+filename+'.png')


if __name__ == "__main__":
    
    #top2_err, rand_err, chern_err, njav_err, top2_sample_complexity, rand_sample_complexity, chern_sample_complexity, njav_sample_complexity = file_IO('../main/discrete_env1')
    #plot_sample_complexity(chern_sample_complexity, rand_sample_complexity, top2_sample_complexity, njav_sample_complexity, 50, 6, 'env1')
    
    
    #top2_err, rand_err, chern_err, njav_err, top2_sample_complexity, rand_sample_complexity, chern_sample_complexity, njav_sample_complexity = file_IO('../main/discrete_env2')
    #plot_sample_complexity(chern_sample_complexity, rand_sample_complexity, top2_sample_complexity, njav_sample_complexity, 2, 3, 'env2')
    
    #top2_err, rand_err, chern_err, njav_err, top2_sample_complexity, rand_sample_complexity, chern_sample_complexity, njav_sample_complexity = file_IO('../main/discrete_env3')
    #plot_sample_complexity(chern_sample_complexity, rand_sample_complexity, top2_sample_complexity, njav_sample_complexity, 50, 6, 'env3')
    
    #top2_err, rand_err, chern_err, njav_err, top2_sample_complexity, rand_sample_complexity, chern_sample_complexity, njav_sample_complexity = file_IO('../main/discrete_env4')
    #plot_sample_complexity(chern_sample_complexity, rand_sample_complexity, top2_sample_complexity, njav_sample_complexity, 50, 6, 'env4')
    
    top2_err, rand_err, chern_err, bchern_err, bchern1_err, bchern2_err, njav_err, top2_sample_complexity, rand_sample_complexity, chern_sample_complexity, bchern_sample_complexity, bchern1_sample_complexity, bchern2_sample_complexity, njav_sample_complexity = file_IO('../main/discrete_env1')
    plot_sample_complexity(chern_sample_complexity, bchern_sample_complexity, bchern1_sample_complexity, bchern2_sample_complexity, rand_sample_complexity, top2_sample_complexity, njav_sample_complexity, 50, 6, "env1")
    
    '''
    dim = 8
    arms = 12
    
    mm_armerr, u_armerr, total_error_LinGapE, mm_T, u_T, total_arm_selection = file_IO0("../main/linBandit_dim" + str(dim))
    
    #plot_sample_complexity0(mm_T, u_T, total_arm_selection, arms, dim, "linBandit_dim" + str(dim))
    
    #mm_armerr, u_armerr, total_error_LinGapE, total_error_XY_Oracle, mm_T, u_T, total_arm_selection, total_arm_selection_XY_Oracle = file_IO1("../main/linBandit_dim" + str(dim))
    
    
    file = open("../main/linBandit_xy_oracle_dim" + str(dim), 'rb')
    data = pickle.load(file)
    file.close()
    total_arm_selection_XY_Oracle = data[1][0]
    plot_sample_complexity1(mm_T, u_T, total_arm_selection, total_arm_selection_XY_Oracle, arms, dim, "linBandit_dim" + str(dim))
    
    #mm_armerr, u_armerr, total_error_LinGapE, total_error_XY_Static, total_error_XY_Adaptive, mm_T, u_T, total_arm_selection, total_arm_selection_xys, total_arm_selection_xya = file_IO2('../main/linBandit_dim'+str(dim))
    
    #mm_armerr, u_armerr, total_error_LinGapE, total_error_XY_Static, total_error_XY_Adaptive, mm_T, u_T, total_arm_selection, total_arm_selection_xys, total_arm_selection_xya = file_IO2('../main/linBandit_dim'+str(dim))
    
    
    #plot_sample_complexity1(mm_T, u_T, total_arm_selection, 20, dim, "linBandit_dim" + str(dim))
    
    #plot_sample_complexity2(mm_T, u_T, total_arm_selection, total_arm_selection_xys, total_arm_selection_xya, 20, dim, "linBandit_dim" + str(dim))
    '''
    
    
    
    