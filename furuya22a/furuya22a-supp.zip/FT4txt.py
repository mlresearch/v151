import argparse
import os

import torch
import torch.nn as nn
import yaml

from src import get_module_logger
from src.data.dataloader4txt import BatchfiedPTB, build_vocab
from src.models.train_model4txt import train
from src.utils.model_rnnlm import prepare_trained_rnnlm


def main():
    artifacts = {}

    logger = get_module_logger("FT")
    logger.debug("Begin...")
    parser = argparse.ArgumentParser()
    parser.add_argument("--wts_path", type=str, required=True, help="Path for weight parameter.")
    parser.add_argument("--m", type=int, default=None, help="Compressed hidden_size.")
    parser.add_argument("--lr_decay", type=float, default=1.0, help="Begin with `lr = lr_original / lr_decay`.")
    parser.add_argument(
        "--non_structured_pruned", type=bool, default=False, help="Whether non-structured pruning was applied or not."
    )
    parser.add_argument("--prune_over", type=bool, default=False, help="Whether over pruning was applied or not.")
    parser.add_argument("--experiment", type=str, default=None, help="Experimental name for mlflow.")
    parser.add_argument("--tags", type=dict, default=None, help="Experimental tags to be converted to dictionary type.")
    parser.add_argument("--id", type=str, default=None, help="ID of the model to be finetuned.")
    args = parser.parse_args()

    # Weights to be finetuned
    wts_path = args.wts_path
    m_sharp = args.m
    non_structured_pruned = args.non_structured_pruned
    prune_over = args.prune_over
    experiment = args.experiment
    # Load configure yaml
    cfg = os.path.join(*wts_path.split("/")[:-2], "config.yaml")
    with open(cfg, "r") as f:
        data = yaml.load(f, Loader=yaml.SafeLoader)
    for key in data:
        args.__setattr__(key, data[key])
    logger.debug(args)

    # Model parameters
    # non_structured_pruned = args.non_structured_pruned
    hidden_size = args.hidden_size
    dropout = args.dropout
    # tie_weights = args.tie_weights
    tie_weights = False  # Can turn on True ??

    # Learning parameters
    batch_size = args.batch_size
    eval_batch_size = args.eval_batch_size
    lr = args.lr / args.lr_decay
    epochs = args.epochs
    # clip_value = args.clip_value
    clip_value = None
    clip_norm = args.clip_norm
    bptt = args.bptt

    # Dataset parameters
    # dataset = args.dataset
    data_dir = args.data_dir

    # Log path
    tags = args.tags
    log_dir = os.path.join('models/logs', experiment, 'model')
    logger.info("log_dir = %s" % log_dir)
    # Overwrite configures
    if not non_structured_pruned:
        data["hidden_size"] = m_sharp
    data["lr"] = lr
    data["experiment"] = experiment
    # Make log directory and save configure yaml file
    if not os.path.isdir(log_dir):
        os.makedirs(os.path.join(log_dir, 'best_wts'))
    cfg_path = os.path.join(log_dir, "config.yaml")
    with open(cfg_path, "w") as cfg:
        yaml.dump(data, cfg)
    logger.info("Saved configure yaml.")

    # Prepare dataloader
    vocab = build_vocab(data_dir)
    train_ds = BatchfiedPTB(data_dir, "train", vocab, batch_size, bptt)
    train_dl = torch.utils.data.DataLoader(train_ds, batch_size=bptt, shuffle=False)
    val_ds = BatchfiedPTB(data_dir, "valid", vocab, eval_batch_size, bptt)
    val_dl = torch.utils.data.DataLoader(val_ds, batch_size=bptt, shuffle=False)
    logger.debug("Datasets are loaded.")

    # Check device
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    if torch.cuda.is_available():
        torch.backends.cudnn.benchmark = True
    logger.debug("GPU or CPU: %s" % device)

    # Finetune RNN classifier
    if non_structured_pruned:
        model = prepare_trained_rnnlm(
            torch.load(wts_path, map_location=device),
            dropout=dropout,
            tie_weights=tie_weights,
            requires_grad=True,
            ft=True,
        )
        mask = {}
        if prune_over:
            model.rnn.weight_ih_l0.requires_grad = False
            model.rnn.weight_ih_l0.grad = torch.zeros_like(model.rnn.weight_ih_l0)  # Just a dummy
            mask_key = ["rnn.weight_hh_l0", "decoder.weight", "encoder.weight"]
        else:
            mask_key = ["rnn.weight_hh_l0"]
        for key in mask_key:
            mask[key] = torch.zeros_like(model.state_dict()[key])
            mask[key][model.state_dict()[key] != 0] = 1
            mask[key] = mask[key].to(device)
        model.set_mask(mask, mask_key)
    else:
        model = prepare_trained_rnnlm(
            torch.load(wts_path, map_location=device), dropout=dropout, tie_weights=tie_weights, requires_grad=True
        )

    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.SGD(model.parameters(), lr=lr)
    #     optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, 1.0, gamma=0.95)

    logger.debug("--Begin Finetuning--")
    train(
        model,
        criterion,
        optimizer,
        train_dl,
        val_dl,
        epochs=epochs,
        device=device,
        scheduler=scheduler,
        clip_value=clip_value,
        clip_norm=clip_norm,
        tags=tags,
        artifacts=artifacts,
        experiment=experiment,
    )
    logger.debug("--Finished Finetuning--")

    logger.debug("Done!!")


if __name__ == "__main__":
    main()
