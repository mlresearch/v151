import matplotlib as mpl

mpl.use('Agg')

import pandas as pd
import glob
import matplotlib.pyplot as plt
import seaborn as sns
import tqdm as tqdm
import numpy as np
from math import log, floor
import os
import argparse
import datetime
from matplotlib.patches import Rectangle

sns.set_context("paper", rc={"font.size": 18, "axes.titlesize": 20, "axes.labelsize": 18, 'text.usetex': True})
print(os.getcwd())


# full_stats_fname = './out_dir/full_stats_again.csv'


def arg_parser():
    parser = argparse.ArgumentParser()
    parser.add_argument('--collect_stats', type=str, default='')
    parser.add_argument('--full_stats_fname', type=str,
                        default=f'./out_dir/full_stats_{datetime.datetime.today():%Y_%m_%d}.csv')
    parser.add_argument('--heat_maps_arg', type=str, default='')  # default=np.pi / 8)  # 0.)
    parser.add_argument('--out_dir', type=str, default='')
    return parser.parse_args()


def collect_stats_and_merge(pattern, full_stats_fname):
    if pattern == '':
        pattern = '/scratch/gobi1/davidj/projects/complex_momentum/jax_toy/out_dir/grid_debug/2020-05-24_toy_gan_scale/*/*.csv'
    files = glob.glob(pattern)
    df = []
    assert len(files) > 0, 'no files founded.'

    for fname in tqdm.tqdm(files):
        df.append(pd.read_csv(fname, index_col=0))

    print('concat stats...')
    df = pd.concat(df)

    print(f'saving to {full_stats_fname}')
    df.to_csv(full_stats_fname, index=False, header=True, compression='zip')

    print('ok')
    return


def create_nice_heatmap(full_stats_fname, lr_argz, momentum_argz, out_dir, x_log_axis=True, annotation=False):
    df = pd.read_csv(full_stats_fname, compression='zip')
    df = df.query('epoch<=100001')
    df.reset_index()

    # note here the field neg_log_like corresponds to inception score.....

    df['iscore'] = df['neg_log_like'].apply(lambda x: eval(x))
    # This field has mean, std getting the mean.
    df['iscore'] = df['iscore'].apply(lambda x: x[0] if isinstance(x, tuple) is True else x)
    mmm = df.loc[df.groupby(['lr_mag', 'lr_arg', 'momentum_mag', 'momentum_arg'])['iscore'].idxmax()]

    # mmm['epoch'] = mmm['epoch']

    # if the best neg_log_likelihood was at the first step... it didnt trained at all (nan's)
    # mmm.loc[mmm['epoch'] == 1, 'neg_log_like'] = np.inf

    mmm['epoch'] = mmm['epoch'] / 1000.

    # normalizing
    if annotation is False:
        max_iscore = mmm['iscore'].max()
        if np.isnan(max_iscore) or np.isinf(max_iscore) or max_iscore == 0.:
            annotation = True
        else:
            mmm['iscore'] = mmm['iscore'] / max_iscore

    mmm['momentum_mag'] = np.round(mmm['momentum_mag'], decimals=1)
    # Note Rounding iteration to two decimals will show 0.1.2.3.4. as 0...
    mmm['text'] = mmm['iscore'].apply(lambda x: 'IS:%.2f' % x) + mmm['epoch'].apply(lambda x: '\nIter:%.2f' % x)

    mmm['lr_mag_log'] = np.round(np.log(mmm['lr_mag']), decimals=1)
    mmm['lr_mag'] = np.round(mmm['lr_mag'], 3)

    # args...
    mmm['lr_arg'] = np.round(mmm['lr_arg'], decimals=3)
    mmm['momentum_arg'] = np.round(mmm['momentum_arg'], decimals=3)
    lr_argz = np.round(lr_argz, decimals=3)
    momentum_argz = np.round(momentum_argz, decimals=3)

    # if lr values are really small this may produce rounding issues.fixing.
    mmm['lr_arg'] = mmm['lr_arg'].apply(lambda x: lr_argz if np.linalg.norm(x - lr_argz) < 1e-1 else x)

    mmm_filtered = mmm.query(
        # f"optimizer=='complex_momentum' and "
        f"lr_arg =={lr_argz} and momentum_arg=={momentum_argz} and network=='wgan-gp-cifar10' ")

    print(len(mmm_filtered))
    assert len(mmm_filtered) > 0

    # show log x axis...
    if x_log_axis is True:
        plotdf = mmm_filtered.pivot(
            index='momentum_mag', columns='lr_mag_log')
    else:
        # normal x_axis.
        plotdf = mmm_filtered.pivot(
            index='momentum_mag', columns='lr_mag')

    # cmap = sns.color_palette("coolwarm", 7, as_cmap=True)
    # cmap.set_bad('drakblue')
    # sns.color_palette()
    # cmap = sns.dark_palette('blue',reverse=True, as_cmap=True)
    # cmap = sns.diverging_palette(220, 20, as_cmap=True)
    # cmap.set_bad('black')
    # cmap = plt.get_cmap("YlGn")
    # cmap.set_bad(color='black', alpha=0.9)
    # cmap = plt.get_cmap('viridis_r')
    cmap = plt.get_cmap('viridis')

    plt.figure(figsize=(16, 9))
    ax = sns.heatmap(plotdf['iscore'], annot=plotdf['text'] if annotation is True else False, fmt='s',
                     linewidths=1,
                     annot_kws={"fontsize": 12},
                     vmin=1 if annotation is True else None, vmax=3 if annotation is True else None, cmap=cmap,
                     cbar_kws={'label': 'IScore - higher = better'}
                     )
    cbar = ax.collections[0].colorbar
    cbar.ax.tick_params(labelsize=16)
    best_idx = np.unravel_index(np.argmax(plotdf['iscore'].values), plotdf['iscore'].values.shape)
    best_idx = tuple(reversed(best_idx))
    ax.add_patch(Rectangle(best_idx, 1, 1, fill=False, edgecolor='red', lw=3))

    ax.tick_params(axis='both', which='both', length=0)

    plt.xticks(fontsize=16)
    plt.yticks(fontsize=16)
    # plt.gca().xaxis()

    plt.xlabel(r'$\log|\alpha|$') if x_log_axis is True else plt.xlabel(r'$|\alpha|$')
    plt.ylabel(r'$|\beta|$')
    # argz_t = r'$\frac{\pi}{8}$' if argz == np.round((np.pi / 8.), 3) else f'{argz:2}'
    plt.title(r'$\arg \beta = ' + r'%.2f ' % momentum_argz + r' \arg \alpha = ' + r"%.2f" % lr_argz + ' $')
    if out_dir == '':
        out_fname = f'./out_dir/heatmaps_WGAN_CIFAR10/{datetime.datetime.now():%Y-%m-%d}_annot_{annotation}_heatmap_phase_lr_{lr_argz}_mom_phase_{momentum_argz}'
    else:
        out_fname = f'./{out_dir}/{datetime.datetime.now():%Y-%m-%d}_annot_{annotation}_heatmap_WGAN_CIFAR10_phase_lr_{lr_argz}_mom_phase_{momentum_argz}'

    plt.savefig(out_fname + '.pdf')
    plt.savefig(out_fname + '.png')
    plt.show()

    print('ok')


def main():
    args = arg_parser()
    if args.collect_stats != '':
        print('collecting stats and merging...')
        collect_stats_and_merge(args.collect_stats, args.full_stats_fname)

    if args.heat_maps_arg != '':
        args.heat_maps_arg = eval(args.heat_maps_arg)
        print(f'creating heatmaps for {args.heat_maps_arg}')
        if isinstance(args.heat_maps_arg, float):
            lr_argz = momentum_argz = args.heat_maps_arg
        else:
            lr_argz = args.heat_maps_arg[0]
            momentum_argz = args.heat_maps_arg[1]

        create_nice_heatmap(args.full_stats_fname, lr_argz, momentum_argz, args.out_dir, annotation=True)
        create_nice_heatmap(args.full_stats_fname, lr_argz, momentum_argz, args.out_dir, annotation=False)


if __name__ == "__main__":
    main()
