#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import print_function

import numpy as np
from sklearn.linear_model import Ridge
from sklearn.metrics import accuracy_score


def run_ovpc(x_train_a, x_train_b, y_train, x_test, y_test):
    # l2weights = [1e-1, 1e-4, 1e-7]

    def _basis(x):
        # linear basis
        return np.hstack((x, np.ones((len(x), 1))))

    # Transform pairwise examples
    def vech(A: np.ndarray):
        # assert A.shape[0] == A.shape[1]
        return A[np.triu_indices(A.shape[0])]

    def vech_bar(b: np.ndarray):
        d = np.sqrt(len(b)).astype("i")
        B = b.reshape(d, d)
        # assert B.shape[0] == B.shape[1]
        return vech(B + B.T - np.diag(np.diag(B)))

    def inv_vech(v: np.ndarray, dim: int):
        assert len(v.shape) == 1
        a = np.zeros((dim, dim))
        a[np.triu_indices(dim)] = v
        a[np.tril_indices(dim)] = v
        return a

    d = x_train_a.shape[1]
    x_a, x_b, x_t = _basis(x_train_a), _basis(x_train_b), _basis(x_test)
    z = np.apply_along_axis(
        vech_bar,
        -1,
        (x_a[:, :, None] * x_b[:, None, :]).reshape(-1, (d + 1) * (d + 1)),
    )

    def scoring(clf, X, y):
        y_pred = np.sign(clf.predict(X))
        return accuracy_score(y_pred, y)

    clf = Ridge(alpha=len(z) * 1e-4, fit_intercept=False)
    clf.fit(z, y_train)

    # Compute the least square estimator
    theta = inv_vech(clf.coef_, d + 1)

    # Compute the largest eigenvalue and eigenvector
    w, v = np.linalg.eig(theta)
    max_idx = np.argmax(w)
    alpha = np.sqrt(w[max_idx]) * v[max_idx]

    # evaluation
    y_pred = np.where(np.dot(alpha, x_t.T) >= 0, 1, -1)
    accuracy = accuracy_score(y_test, y_pred)

    return accuracy
