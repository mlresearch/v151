from gpytorch.kernels import RBFKernel
import torch
from PreferentialGP.utility import train_test_split
from PreferentialGP.utility import Conjugate_GD

class PGP(torch.nn.Module):
    """
    Preferential GP defined on Edge space
    """

    def __init__(self, comp_ls, y_ls, phi):
        super().__init__()

        self.comp_ls = comp_ls
        self.y_ls = y_ls
        self.phi = phi
        self.kernel = RBFKernel(ard_num_dims=phi.shape[1])
        self.kernel.lengthscale = torch.tensor([2. for i in range(phi.shape[1])])
        self.f = torch.nn.Parameter(torch.randn(len(comp_ls), 1, requires_grad=True))
        self.T = None
        self.T_inv = None
        self.K = None

    def forward(self):

        K = self.kernel(torch.tensor(self.phi)).evaluate()
        self.K = K

        m = len(self.comp_ls)
        T = torch.zeros((m, m), requires_grad=False)

        for i in range(m):
            for j in range(i, m):
                x1, x2 = self.comp_ls[i]
                l1, l2 = self.comp_ls[j]

                T[i, j] = K[x1, l1] + K[x2, l2] - K[x1, l2] - K[x2, l1]
                T[j, i] = T[i, j]

        self.T = T
        self.T_free = T.detach()


def fit_sskernel_sim(K, comp_ls):
    m = len(comp_ls)
    T = torch.zeros((m, m), requires_grad=False)

    for i in range(m):
        for j in range(i, m):
            x1, x2 = comp_ls[i]
            l1, l2 = comp_ls[j]

            T[i, j] = K[x1, l1] + K[x2, l2] - K[x1, l2] - K[x2, l1]
            T[j, i] = T[i, j]

    return T


def pgp_predict(pgp, new_comp_ls):
    """
    Args:
        pgp: The trained PGP object with f_map computed previously
        new_comp_ls: new competition list to do prediction

    Returns:
        the predicted f_map
    """
    complete_ls = pgp.comp_ls + new_comp_ls
    Tn = fit_sskernel_sim(pgp.K, complete_ls)
    Tno = Tn[len(pgp.comp_ls):, 0:len(pgp.comp_ls)]
    # Tnn = Tn[len(ssgp.comp_ls):, len(ssgp.comp_ls):]
    # Too = Tn[:len(ssgp.comp_ls), :len(ssgp.comp_ls)]

    Too_invf = Conjugate_GD(pgp.T_free, pgp.f, num_rounds=10)

    return Tno @ Too_invf

# Loss function to minimise


def CG_GaussianLoglikelihood(f, T, y_tensor, num_rounds=10):
    """
    Loss function to optimise for f, uses CG.
    """
    sigma = torch.nn.Sigmoid()
    K_invf = Conjugate_GD(T, f, num_rounds=num_rounds)

    L = 0.5 * f.t() @ K_invf - torch.sum(torch.log(sigma(y_tensor * f)))

    return L


def CG_approx_Marginal_log_likelihood(f, T, y_tensor, num_rounds=10):
    sigma = torch.nn.Sigmoid()

    w_elements = (sigma(f) * sigma(-f)).reshape(1, -1)[0]
    W_half = torch.diag(w_elements ** (1 / 2))
    B = torch.eye(T.shape[0]) + W_half @ T @ W_half
    eig_vals, e_vecs = torch.symeig(B, eigenvectors=True)

    # likelihood = torch.sum(torch.log(sigma(y_tensor * f))).detach().numpy()

    mll = 0.5 * f.t() @ Conjugate_GD(T, f, num_rounds=num_rounds) - torch.sum(torch.log(sigma(y_tensor * f))) + 0.5 * torch.log(
        torch.prod(eig_vals))

    return mll


class PreferentialGP(object):
    """
    Latent Function modelled in node space, not product space

    """

    def __init__(self, comp_ls, y_ls, phi):
        self.comp_ls = comp_ls
        self.y_ls = y_ls
        self.phi = phi
        self.kernel = RBFKernel()
        self.kernel.lengthscale = 2
        self.C = train_test_split(comp_ls, 1.)[0]

    def fit(self, epoch=3000, lr=1e-2):

        features = torch.tensor(self.phi)
        K = torch.tensor(self.kernel(
            features).evaluate().detach().numpy()).float()
        self.K = K

        K_inv = torch.inverse(K).float()
        self.K_inv = K_inv

        # Setup GP
        y_tensor = torch.tensor(self.y_ls).reshape(-1, 1).float()
        sigma = torch.nn.Sigmoid()

        p = K_inv.shape[0]
        f = torch.randn(p, 1, requires_grad=True).float()
        e_vec = torch.ones_like(f)

        # Compute f_map
        for rd in range(epoch):
            f_diff = f @ e_vec.t() - e_vec @ f.t()
            smoothness = 0.5 * (f.t()@(K_inv) @f).float()
            likelihood = torch.sum(
                torch.log(sigma(torch.tensor(self.C) * f_diff)))

            L = smoothness - likelihood
            L.backward()

        # Compute the mll
        f_map = f.detach()
        f_diff = f @ e_vec.t() - e_vec @ f.t()
        smoothness = 0.5 * (f_map.t()@(K_inv) @f_map).float()
        likelihood = torch.sum(
            torch.log(sigma(torch.tensor(self.C) * f_diff)))
        component1 = sigma(torch.tensor(self.C) * f_diff)
        component2 = sigma(-torch.tensor(self.C) * f_diff)
        W = (component1 * component2).float()

        B = torch.eye(W.shape[0]) + self.K @ W

        marginallikelihood = -smoothness + \
            likelihood - 0.5 * torch.log(torch.det(B))
        self.mll = marginallikelihood

        self.posterior_mean = f_map