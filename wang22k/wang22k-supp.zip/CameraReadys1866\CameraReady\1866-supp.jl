using Random
using Distributions
using Convex
using Mosek
using MosekTools
using SCS
using Plots




## Plot 1
# This script shows how we ran the experiments.



begin

    n = 400
    lsv = []
    logvals = 1.5:0.3:4.0
    for dist in [Normal(), Bernoulli(), LogNormal()]
        lst = []
        for dv in logvals
            lstt = []
            for _ in 1:20
                d = Integer(round(exp(dv)*n))
                X = (rand(dist,n,d) .- mean(dist))./std(dist)
                y = X[:,1] + randn(n)
                wgt = zeros(d)
                wgt[1]=1
                w = Variable(d)
                prob = minimize(norm(w,1), X*w == y)
                solve!(prob, Mosek.Optimizer)
                res = w.value
                push!(lstt, norm(res - wgt,2)^2)
            end
            push!(lst, mean(lstt))
        end
        push!(lsv, lst)
    end
end



scatter(logvals, lsv[1], label = "Normal")
scatter!(logvals, lsv[3], label = "Log Normal")
scatter!(logvals, lsv[2], label = "Rademacher")
plot!(logvals, 1 ./logvals, linestyle = :dash)




## Plot 2
begin
    n = 400
    d = 20000
    #σvals = 0:0.5:3.5
    σvals = 0:0.5:3.5

    ls1 = []
    ls2 = []
    for σ in σvals
        lst1 =[]
        lst2 = []
        for _ in 1:20
            X = randn(n,d)
            y = X[:,1] + randn(n) .*σ
            wgt = zeros(d)
            wgt[1]=1
            w = Variable(d)
            prob = minimize(norm(w,1), X*w == y)
            solve!(prob, Mosek.Optimizer)
            res = w.value
            push!(lst1, norm(res - wgt,2)^2)

            w = Variable(d)
            prob = minimize(norm(w,2), X*w == y)
            solve!(prob, Mosek.Optimizer)
            res = w.value
            push!(lst2, norm(res - wgt,2)^2)
        end
        push!(ls1, lst1)
        push!(ls2, lst2)
    end
end




plot(σvals.^2, mean.(ls1), ribbons= std.(ls1),fillalpha = 0.5,  label ="L1")
plot!(σvals.^2, mean.(ls2), ribbons= std.(ls2), fillalpha = 0.5, label = "L2")
plot!(σvals.^2, σvals.^2 .* 1/log(d/n), linestyle = :dash, label = "theory")
